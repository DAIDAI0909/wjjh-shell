# -*- coding: utf-8 -*-
"""
fz_crypto.py —— 放置江湖接口响应的**多魔数**加解密（第 143 轮通过）。

由来（实测，不是猜的）
----------------------
客户端启动第一步 `POST /api/service/exchange_publickey` 的响应是 JHHU02 密文，
用已知 key/iv 解开后，里面**就是服务器下发的密钥表**：

    {"errcode":0,"data":"[{\"k\":\"eb42cb65f5a811030770ca7e4a5b7e6f\",\"h\":\"FZJH02\"},
                         {\"k\":\"52100396d57d106c434bbfec3893adc8\",\"h\":\"FZJH03\",\"i\":\"PcIQIZifRalhZ88n\"},
                         {\"k\":\"eb42cb65f5a811030770ca7e4a5b7e6f\",\"h\":\"FXXF03\"}]"}

⇒ 于是 `FZJH03`（get_time / getWebConfig / get_token / get_partition_list2 / report_cheat
   用的就是它）**不再是未知**：key = 52100396d57d106c434bbfec3893adc8，iv 与 JHHU02 相同。
⇒ 以前"FXXF01/FZJH03 解不出来"的结论作废：**密钥是服务器在第一个接口里给我们的**。

容器格式（与 JHHU02 完全一致，已逐字节验证）：
    ASCII hex 文本  ->  hex 解码  ->  b"<MAGIC6>" + AES-256-CBC(明文 + '0' 填充)

用法：
    python fz_crypto.py --decrypt <文件> [--magic FZJH03]
    python fz_crypto.py --encrypt <明文.json> --out <文件> [--magic FZJH03]
    python fz_crypto.py --selftest
"""
import argparse
import binascii
import io
import json
import os
import sys

if __name__ == '__main__':
    # 只在当命令行工具用时换 stdout；被服务器 import 时绝不能动（会把日志流搞坏）
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

try:
    from Crypto.Cipher import AES  # noqa: E402
except ImportError:
    try:
        # Termux 源里没有 pycryptodome，但有 pycryptodomex：
        # 同一套 API，只是包名叫 Cryptodome（一体化 APK 里带的就是它）
        from Cryptodome.Cipher import AES  # noqa: E402
    except ImportError:
        # 最后兜底：cryptography（接口只用到 CBC）
        # ★ 注意缩进：这段垫片**只能**在两种导入都失败时才定义，
        #   否则会把上面成功导入的 AES 覆盖掉（踩过：NameError: Cipher is not defined）
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

        class _AESCipher(object):
            def __init__(self, key, iv):
                self._ctx = Cipher(algorithms.AES(key), modes.CBC(iv))

            def encrypt(self, data):
                e = self._ctx.encryptor()
                return e.update(data) + e.finalize()

            def decrypt(self, data):
                d = self._ctx.decryptor()
                return d.update(data) + d.finalize()

        class _AESModule(object):
            MODE_CBC = 'CBC'

            @staticmethod
            def new(key, mode, iv):
                return _AESCipher(key, iv)

        AES = _AESModule()

# 已知密钥（JHHU02 是我们自己从 .so 破出来的；其余是服务器在 exchange_publickey 里下发的）
KNOWN = {
    b'JHHU02': {'key': b'cbIhHHuYQIJ1JkwlLupIvNIvdQDfNxSF', 'iv': b'PcIQIZifRalhZ88n'},
    b'FZJH03': {'key': b'52100396d57d106c434bbfec3893adc8', 'iv': b'PcIQIZifRalhZ88n'},
    b'FZJH02': {'key': b'eb42cb65f5a811030770ca7e4a5b7e6f', 'iv': b'PcIQIZifRalhZ88n'},
    b'FXXF03': {'key': b'eb42cb65f5a811030770ca7e4a5b7e6f', 'iv': b'PcIQIZifRalhZ88n'},
}

# ★ 2026-10-02 严格加密：资产容器换钥（MJJH01，配套 libcocos2dlua.so 已同步补丁）。
#   旧 JHHU02 保留在上表仅供解密旧备份/诊断文件；新打包一律用 ASSET_MAGIC。
#   密钥本体在 wjjh_asset_keys.json（与 rekey_assets.py 配套，生成时随机）。
try:
    _rk = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'wjjh_asset_keys.json')))
    KNOWN[_rk['magic'].encode()] = {'key': _rk['key'].encode(), 'iv': _rk['iv'].encode()}
    ASSET_MAGIC = _rk['magic'].encode()
except Exception:                                       # noqa: BLE001
    ASSET_MAGIC = b'JHHU02'                             # 兼容：没有 keyfile 时按旧钥走


def encrypt_with(plain: bytes, magic: bytes, key: bytes, iv: bytes) -> bytes:
    """用任意 magic/key/iv 加密（rekey 迁移脚本用）"""
    pad = (-len(plain)) % 16
    if pad == 0:
        pad = 16
    ct = AES.new(key, AES.MODE_CBC, iv).encrypt(plain + b'0' * pad)
    return binascii.hexlify(magic + ct)


def _split(raw: bytes):
    """剥掉 ASCII hex 外壳，返回 (magic, ciphertext)"""
    data = binascii.unhexlify(b''.join(raw.split()))
    return data[:6], data[6:]


def decrypt(raw: bytes, magic: bytes = None) -> bytes:
    mg, ct = _split(raw)
    if magic is not None and mg != magic:
        raise ValueError('magic 不符: %r != %r' % (mg, magic))
    spec = KNOWN.get(mg)
    if spec is None:
        raise ValueError('未知魔数 %r（密钥还没拿到）' % mg)
    return AES.new(spec['key'], AES.MODE_CBC, spec['iv']).decrypt(ct).rstrip(b'0')


def encrypt(plain: bytes, magic: bytes = b'FZJH03') -> bytes:
    spec = KNOWN[magic]
    pad = (-len(plain)) % 16
    if pad == 0:
        pad = 16
    ct = AES.new(spec['key'], AES.MODE_CBC, spec['iv']).encrypt(plain + b'0' * pad)
    return binascii.hexlify(magic + ct)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--decrypt')
    ap.add_argument('--encrypt')
    ap.add_argument('--out')
    ap.add_argument('--magic')
    ap.add_argument('--selftest', action='store_true')
    a = ap.parse_args()
    mg = a.magic.encode() if a.magic else None

    if a.selftest:
        ok = True
        for m in (b'JHHU02', b'FZJH03'):
            for c in (b'{"errcode":0}', b'x' * 16, '中文'.encode()):
                back = decrypt(encrypt(c, m), m)
                ok = ok and back == c
                print('  %s %-16r 往返=%s' % (m.decode(), c[:14], back == c))
        print('自检', '通过' if ok else '★失败')
        return 0 if ok else 1

    if a.decrypt:
        raw = open(a.decrypt, 'rb').read()
        pt = decrypt(raw, mg)
        print(pt.decode('utf-8', 'replace'))
        return 0

    if a.encrypt and a.out:
        pt = open(a.encrypt, 'rb').read()
        enc = encrypt(pt, mg or b'FZJH03')
        open(a.out, 'wb').write(enc)
        print('加密 %s (%d 字节) -> %s (%d 字节) 回读=%s'
              % (a.encrypt, len(pt), a.out, len(enc), decrypt(enc, mg or b'FZJH03') == pt))
        return 0
    print('用法见文件头')
    return 2


if __name__ == '__main__':
    sys.exit(main())
