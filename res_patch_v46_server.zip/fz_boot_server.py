# -*- coding: utf-8 -*-
# ================= 离线包路径根（fz_make_offline_bundle.py 自动注入） =================
# 手机上整个服务端就是一个目录，表在哪、状态写哪，全部相对包根算。
# （有的模块原来把绝对路径写死，本身没 import os —— 这里一并补上）
import os
import os as _osp


def _off_find_bundle(_f):
    """从模块所在目录往上找包根（认 fz_boot_server.py）。
    ★ fz_api/*.py 的 __file__ 在 <根>/fz_api/ 下，直接 dirname 会算错一层。"""
    _d = _osp.path.dirname(_osp.path.abspath(_f))
    for _ in range(6):
        if _osp.path.exists(_osp.path.join(_d, 'fz_boot_server.py')):
            return _d
        _u = _osp.path.dirname(_d)
        if _u == _d:
            break
        _d = _u
    return _osp.path.dirname(_osp.path.abspath(_f))


_OFF_BUNDLE = _off_find_bundle(__file__)
_OFF_FZ_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_fz')
_OFF_INK_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_ink')
_OFF_WORK_ROOT = _OFF_BUNDLE
# =====================================================================================
# ★ 2026-10-04 商城空货架修复：客户端资源表解析——PC 开发树优先，设备上自动回退
#   到包内 client_fz 副本（jhserver/client_fz = fangzhi_lua_dec 的同步拷贝）。
def _fz_res(*parts):
    base = os.path.join(_OFF_FZ_ROOT, 'res', 'script')
    if not os.path.isdir(base):
        base = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            'client_fz', 'res', 'script')
    return os.path.join(base, *parts)

# -*- coding: utf-8 -*-
"""
fz_boot_server.py —— 她客户端启动链的**我们自己的服务端**（L1-b）

她客户端启动时要走这些接口（实测，见 `武动仙途/L1_入口清单_她客户端启动链.md`）：

    POST /api/service/exchange_publickey      ← JHHU02：服务器下发**会话密钥表**
         /v1/checkUpdate                     ← JHHU02
         /v1/getMd5List                      ← JHHU02（2.29MB，md5 清单闸门）
    GET  /api/v5/get_time                    ← FZJH03
         /api/v5/getWebConfig                ← FZJH03
         /api/v5/get_token                   ← FZJH03
         /api/v5/get_partition_list2         ← FZJH03
    POST /api/v5/report_cheat                ← FZJH03

App 侧 `FzLocalServer.rewrite()` 把它们改写到 `http://127.0.0.1:7900`
（设备侧由 `adb reverse tcp:7900 tcp:7900` 接到本进程）。

★ 关键机制（这一轮实测才搞明白，之前"FZJH03 解不出来"是误判）
    * JHHU02 的 key/iv 我们早就掌握（固定）；
    * **FZJH03 的 key 是每会话一把**，由服务器在第一个接口 `exchange_publickey` 的响应里下发：
          {"errcode":0,"data":"[{\"k\":\"...\",\"h\":\"FZJH02\"},
                               {\"k\":\"<32位>\",\"h\":\"FZJH03\",\"i\":\"PcIQIZifRalhZ88n\"},
                               {\"k\":\"...\",\"h\":\"FXXF03\"}]"}
      （实测两局：52100396… 与 06e1e3f8… 不一样）
    * 所以"我们自己的服务端"必须：**自己发一把 FZJH03 key**，再用它加密后面所有 /api/v5/* 响应。
      ——之前直接把官方那把 key 拿来用，客户端会解出乱码、JSON 解析失败、进程 abort。

行为
----
* 认识的接口 -> 我们自己应答（明文来自 `boot_templates/*.json`，我们自己的值现算）；
* 不认识的接口 -> 原样转发官方，并把**请求/响应带标签**落盘到
  `boot_capture/session_<时间>/`（每个会话一个目录，配它自己的 exchange_publickey.bin，
   以后任何时候都能拿该会话的 key 解出来）；
* `boot_answers/<接口名>.bin` 存在时优先回它（原始字节，用来做单点实验）。

用法：
    python fz_boot_server.py --port 7900            # 我们应答 + 其余转发 + 全程落盘
    python fz_boot_server.py --port 7900 --relay-only   # 只当记录代理（全部转发官方）
    python fz_boot_server.py --port 7900 --no-relay     # 不转发，没实现的一律 404
"""

import argparse
import binascii
import hashlib
import http.client
import http.server
import json
import os
import random
import re
import shutil
import ssl
import sys
import time
import urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import importlib.util

_spec = importlib.util.spec_from_file_location('fzc', os.path.join(HERE, 'fz_crypto.py'))
fzc = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(fzc)
ASSET_MAGIC = fzc.ASSET_MAGIC

CAPTURE_DIR = os.path.join(HERE, 'boot_capture')
ANSWERS_DIR = os.path.join(HERE, 'boot_answers')
TEMPLATE_DIR = os.path.join(HERE, 'boot_templates')
LOG_PATH = os.path.join(HERE, 'boot_log.txt')

API_HOST = 'android.fzjh.xiaohoutiaotiao.com'
UPDATE_HOST = 'update.xiaohoutiaotiao.com'
HOP_HEADERS = {
    'host', 'content-length', 'connection', 'keep-alive', 'transfer-encoding',
    'accept-encoding', 'proxy-connection', 'te', 'trailer', 'upgrade',
}

_port = 7900

# ★★★ 对外零外发（2026-09-29 事故后改成默认关）★★★
#   事故：这两个开关以前默认开，于是**我们没实现的接口会被原样转发到官方服务器**，
#   而转发时带着客户端的原始头（pkname=com.zzxxa.mud / userid=9048719784 /
#   uuid=guanfang62c827d2fbb9bc04b8ad4e10）——等于用私服客户端去写老板的官方账号。
#   实测写进去过：upload_user_file_3/kaishi/3（存档上传）、update_unlock_record（解锁记录）、
#   report_cheat（客户端反外挂自报）、create_account。官方因此报「角色数据异常」。
#   ⇒ 现在：默认不转发；要转发必须显式 `--relay`；**即使 `--relay`，写方法（非 GET）也一律不转发**，
#     除非再显式加 `--relay-writes`（双开关，正常开发永远不该打开）。
_relay = False
_relay_writes = False
_relay_only = False
_permissive = True       # 未实现的 /api/v5/* 回 errcode=0（探索用，--strict 关掉）

# 见文件末尾"宽容应答"那段：动作类未实现接口一律回 errcode=1，避免静默卡死。
# 清单由 `work/tmp_gapaudit.py --emit` 生成。
_PERMISSIVE_ACTIONS = set()
try:
    with open(os.path.join(HERE, 'permissive_gap.json'), encoding='utf-8') as _f:
        _PERMISSIVE_ACTIONS = set(json.load(_f).get('action') or [])
except Exception:                           # noqa: BLE001
    pass
SESSION = {'dir': None, 'key': None, 'ts': 0, 'token': ''}

# ★★ 她客户端对**除下面四个之外**的所有接口都要校验响应签名（`app/extends/Http.lua:117-156`）：
#      响应头必须带 time / nonce / signature，
#      signature == md5( time & "&" & nonce & "&" & 响应体 & "&" & T_TOKEN )
#    缺头 -> 客户端自己合成 {"errcode":1002}；签名不符 -> {"errcode":1003}。
#    T_TOKEN 就是 `get_token` 里发的那个 token —— 我们自己发的，所以签名我们算得出来。
SIG_EXEMPT = ('get_time', 'get_token', 'report_cheat', 'getWebConfig')




def log(msg):
    line = '[boot] ' + msg
    try:
        print(line, flush=True)
    except UnicodeEncodeError:
        print(line.encode('utf-8', 'replace').decode('ascii', 'replace'), flush=True)


def name_of(path):
    return path.strip('/').replace('/', '_').replace('?', '_') or 'root'


def append_log(block):
    try:
        with open(LOG_PATH, 'a', encoding='utf-8') as f:
            f.write(block + '\n')
    except OSError as e:
        log('写日志失败 %s' % e)


def hex_or_empty(b, limit=4000):
    if not b:
        return ''
    return b[:limit].hex() + ('...(共 %d 字节)' % len(b) if len(b) > limit else '')


# -----------------------------------------------------------------------------
# 状态页（给老板看的，不开 Termux 也能查）
#   浏览器打开 http://127.0.0.1:7900/status 就行 —— 明文 HTML，不需要签名头。
#   手机上是同一个地址（私服在手机自己身上）。
# -----------------------------------------------------------------------------
BOOT_TS = time.time()
REQ_RING = []                      # 不用 collections.deque，省一个 import
RING_MAX = 40


def _ring_add(item):
    REQ_RING.append(item)
    while len(REQ_RING) > RING_MAX:
        del REQ_RING[0]


def _esc(s):
    return (str(s).replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;'))


def _hm(ts):
    return time.strftime('%H:%M:%S', time.localtime(ts))


def status_page():
    up = time.time() - BOOT_TS
    h, m = int(up // 3600), int((up % 3600) // 60)
    try:
        with open(LOG_PATH, 'r', encoding='utf-8', errors='replace') as f:
            tail = f.read()[-8000:].split('\n')[-40:]
    except OSError:
        tail = ['(还没有日志)']
    rows = ''.join(
        '<tr><td>%s</td><td>%s</td><td>%s %s</td></tr>' % r for r in REQ_RING[::-1])
    tailtxt = _esc('\n'.join(tail))
    role_info = ''
    try:
        p = os.path.join(ROLE_DIR, 'full.json')
        if os.path.exists(p):
            with open(p, 'r', encoding='utf-8') as f:
                r = json.load(f)
            role_info = ('lv=%s  %s  金钱=%s  先天 臂力%s/悟性%s/根骨%s/身法%s  福缘=%s'
                         % (r.get('lv'), r.get('name'), r.get('money'),
                            r.get('str'), r.get('int'), r.get('con'), r.get('dex'), r.get('luck')))
    except Exception as e:                             # noqa: BLE001
        role_info = '（读角色档失败 %s）' % e
    n_saves = len([n for n in os.listdir(SAVE_DIR)]) if os.path.isdir(SAVE_DIR) else 0
    n_tpl = len([n for n in os.listdir(TEMPLATE_DIR)]) if os.path.isdir(TEMPLATE_DIR) else 0
    return '''<!doctype html><html lang="zh"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>我叫江湖 · 私服状态</title>
<style>body{font-family:sans-serif;margin:16px;background:#111;color:#e8e8e8}
h1{font-size:20px} .ok{color:#6f6}.bad{color:#f66} table{border-collapse:collapse;width:100%%;font-size:13px}
td,th{border-bottom:1px solid #333;padding:4px 6px;text-align:left}
pre{background:#000;padding:10px;overflow:auto;font-size:12px;line-height:1.5}
.k{color:#8cf}</style></head><body>
<h1>我叫江湖 · 本地私服状态</h1>
<p><b class="ok">● 正在运行</b>　已运行 %d 小时 %d 分（启动于 %s）<br>
端口 <span class="k">%d</span>　对外转发 relay=%s　写请求转发 relay_writes=%s　角色来源 role=%s<br>
客户端应该连：<span class="k">http://127.0.0.1:%d</span></p>
<p>角色档：%s<br>存档文件 %d 个　模板 %d 个</p>
<h3>最近请求（新→旧）</h3>
<table><tr><th>时间</th><th>来源</th><th>请求</th></tr>%s</table>
<h3>服务端日志（最后 40 行）</h3><pre>%s</pre>
<p style="color:#888;font-size:12px">刷新页面就能看最新状态；手机浏览器把这一页加到桌面更方便。
日志文件也在私服目录里：boot_log.txt</p>
</body></html>''' % (h, m, _hm(BOOT_TS), _port, _relay, _relay_writes, ROLE_MODE, _port,
                     role_info, n_saves, n_tpl, rows, tailtxt)


def load_template(name, default=None):
    p = os.path.join(TEMPLATE_DIR, name + '.json')
    try:
        with open(p, 'r', encoding='utf-8') as f:
            return json.load(f)
    except OSError:
        return default


def enc_jhhu02(obj):
    return fzc.encrypt(json.dumps(obj, ensure_ascii=False, separators=(',', ':')).encode('utf-8'), ASSET_MAGIC)


def enc_session(obj):
    """用**我们这一局发给客户端的** FZJH03 key 加密。

    还没发过密钥（例如有人在 exchange_publickey 之前就打别的接口）时就地生成一把，
    免得抛异常回退成"转发官方"——那种回退会让排查变得很迷惑。
    """
    if SESSION['key'] is None:
        SESSION['key'] = binascii.hexlify(os.urandom(16))
        new_session()
        log('（未走过 exchange_publickey）惰性生成会话密钥 FZJH03 key=%s'
            % SESSION['key'].decode('ascii'))
    fzc.KNOWN[b'FZJH03'] = {'key': SESSION['key'], 'iv': b'PcIQIZifRalhZ88n'}
    return fzc.encrypt(json.dumps(obj, ensure_ascii=False, separators=(',', ':')).encode('utf-8'), b'FZJH03')


def new_session():
    d = os.path.join(CAPTURE_DIR, 'session_' + time.strftime('%H%M%S'))
    os.makedirs(d, exist_ok=True)
    SESSION['dir'] = d
    SESSION['ts'] = time.time()
    return d


# ★ 会话密钥落盘：这样**重启服务端不会把正在玩的客户端踢掉**
#   （客户端只在启动时 exchange_publickey 拿一次 key；重启后我们若换了 key，
#     它后面所有请求都会解不开 ⇒ 面板报错/卡死。落盘后重启即续用同一把 key。）
SESSION_KEY_FILE = os.path.join(HERE, 'session_key.txt')


def save_session_key(key):
    try:
        with open(SESSION_KEY_FILE, 'w', encoding='ascii') as f:
            f.write(key.decode('ascii') if isinstance(key, bytes) else str(key))
    except OSError as e:
        log('会话密钥落盘失败 %s' % e)


def load_session_key():
    try:
        with open(SESSION_KEY_FILE, 'r', encoding='ascii') as f:
            k = f.read().strip()
        return k.encode('ascii') if k else None
    except OSError:
        return None


# 同理：`T_TOKEN` 是客户端**启动时**从 get_token 拿一次就存住的；
# 我们重启后 token 变了的话，签名头就对不上（现在客户端已跳过签名校验，
# 但保持 token 不变更贴近"她的真实服务端"行为，也便于排查）。
SESSION_TOKEN_FILE = os.path.join(HERE, 'session_token.txt')

# 排行榜"尊姓大名"是否已登记过（登记过就不再逼你改名）
NAME_CHANGED_FILE = os.path.join(HERE, 'name_changed.txt')


def save_session_token(tok):
    try:
        with open(SESSION_TOKEN_FILE, 'w', encoding='ascii') as f:
            f.write(tok)
    except OSError as e:
        log('token 落盘失败 %s' % e)


def load_session_token():
    try:
        with open(SESSION_TOKEN_FILE, 'r', encoding='ascii') as f:
            return f.read().strip()
    except OSError:
        return ''


# ---------------------------------------------------------------------------
# 我们自己的应答（返回 bytes；返回 None = 不接管，交给转发/404）
# ---------------------------------------------------------------------------
def answer_exchange_publickey():
    """★ 会话密钥表的发放者：从这一局起，FZJH03 用**我们**的 key。

    ★★ 2026-09-29 修：**不再每次握手都换 key**（这是「网络错误，请重试」的真因）。
      现象：客户端启动到 `get_token` 就失败，画面「网络错误，请重试」，
            右下角一行 `get_token,nil,nil;<userid>`。
      排查：把客户端收到的那条 get_token 应答原文抓出来，用 `session_key.txt`
            解密 —— **完全正常**（`{"errcode":0,"data":{"token":"..."}}`）。
            ⇒ 服务端没问题，是**客户端手里那把 key 跟服务端不一致**，
              所以它解不开任何 FZJH03 应答。
      根因：原来每次 `exchange_publickey` 都生成新 key；而客户端只在启动时拿一次。
            只要某一次握手没被客户端用上（时序/超时），它就永远拿着旧 key。
      处置：这把 key 在私服里只是本地混淆，**没有轮换的必要** ⇒ 只在没有 key 时生成一次，
            之后每次握手都发同一把。客户端无论哪次握手都能对上。
    """
    if SESSION['key'] is None:
        SESSION['key'] = binascii.hexlify(os.urandom(16))
        save_session_key(SESSION['key'])
        log('首次生成会话密钥 FZJH03 key=%s' % SESSION['key'].decode('ascii'))
    else:
        log('复用会话密钥 FZJH03 key=%s（不再轮换）' % SESSION['key'].decode('ascii'))
    key = SESSION['key'].decode('ascii')                        # 32 个 ASCII 字符 = AES-256 key
    table = [
        {'k': 'eb42cb65f5a811030770ca7e4a5b7e6f', 'h': 'FZJH02'},
        {'k': key, 'h': 'FZJH03', 'i': 'PcIQIZifRalhZ88n'},
        {'k': 'eb42cb65f5a811030770ca7e4a5b7e6f', 'h': 'FXXF03'},
    ]
    return enc_jhhu02({'errcode': 0, 'data': json.dumps(table, ensure_ascii=False)})


def our_partitions():
    now = time.time()
    return {
        'errcode': 0,
        'data': {
            'list': [
                {'id': 1, 'partition_name': 'wudong', 'platform': 'android',
                 'channel': 'wudong', 'channel_num': 1,
                 'partition_title': '武动仙途 [1区]',
                 'partition_desc': '水墨江湖 · 我们自己的服务器',
                 'is_open': 'Y', 'should_select_migrate': False},
                {'id': 2, 'partition_name': 'wudong_2', 'platform': 'android',
                 'channel': 'wudong', 'channel_num': 2,
                 'partition_title': '武动仙途 [2区]',
                 'partition_desc': '来自我们服务端的分区',
                 'is_open': 'Y', 'should_select_migrate': False},
            ],
            'user': {'active_partition': 0},
        },
        'rand_t': now,
    }


def create_account_stub(headers):
    """★ `create_account` 的契约（从她的 `StartGameLayer.lua:20-159` 反推，实测同）：

        客户端把 **userid 放在请求头**里：
          userid = -1  -> 没有存档（新号）：只要求 errcode == 0，然后它去 downloadSaveData
          userid = -3  -> 有存档没账号：要求 errcode == 0 **且 data.userid**，它拿这个 userid 去 checkLogin
          userid >  0  -> 已有账号：只要 errcode == 0，然后 checkLogin
        其它 errcode 的语义：2/6/552 = 数据异常→重置；3/4 = 失败；201 = 弹面板(title/body)

    ★★ 2026-10-01 关键修复（老板："重启之后我玩的档案都没存上"）★★
      以前这里按 uuid 派生一个 userid（实测 = 934418），和角色档里那个 userid（783783）
      **不是同一个**。而存档文件名 = `md5(uuid|userid)`：
        · 上传时请求头带 934418 ⇒ 写到 `saves/6558f5aa763e373b.json`
        · 下次全新登录时请求头 userid 还是 0/783783 ⇒ 读到 `saves/4c79e148a9097e0f.json`
      ⇒ **上传和下发根本不是同一个文件**，进度永远回不来。
      私服只有老板一个人，身份就该只有一个：这里直接回 `PRIVATE_USERID`。
    """
    uid_hdr = (headers.get('userid') or '').strip()
    n = PRIVATE_USERID
    # ★★ 2026-10-17 v154b 一次性「强制回档」开关（v154 配套）：
    #   重建实例后客户端本地档是 seed 铺底的（缺传功丹武学），且自动续登**只上传不下载**，
    #   服务端 v154 回填永远到不了客户端。GameStart.lua __force_download_user_data 的官方
    #   流程 = create_account 应答 **errcode=2（"覆盖档案"）→ 客户端自己上传现行档+删本地档+
    #   重新下载**——下载应答走 save_download（模板+存档合并+v154 回填）⇒ 轮回修仙决回归。
    #   用法：`touch files/jhserver/force_redownload.flag` 后重启游戏一次，**用后即焚**。
    _fr_flag = os.path.join(HERE, 'force_redownload.flag')
    if os.path.exists(_fr_flag):
        try:
            os.remove(_fr_flag)
        except OSError:
            pass
        log('★★ create_account：force_redownload.flag 在 → 应答 errcode=2（覆盖档案，'
            '客户端将强制回档重下载，v154 回填随档下发）')
        return {'errcode': 2, 'rand_t': time.time()}
    log('create_account 请求头 userid=%r -> 我们分配 userid=%d（唯一身份）' % (uid_hdr, n))
    return {'errcode': 0, 'data': {'userid': n}, 'rand_t': time.time()}


def _canonical_save_key():
    """★ 本机**唯一**存档位的文件名（不含 .json）。

    私服单机单角色，所以上传 / 下发 / 先天回写 / 存档库**必须都认这一份**，
    否则"存的"和"读的"是两本账（老板踩的就是这个）。
    """
    return hashlib.md5(('%s|%s' % (PRIVATE_UUID, PRIVATE_USERID)).encode()).hexdigest()[:16]


def _canonical_save_path():
    return os.path.join(SAVE_DIR, _canonical_save_key() + '.json')


SAVE_DIR = os.path.join(HERE, 'saves')
ROLE_DIR = os.path.join(HERE, 'roles')
SIGN_FILE = os.path.join(HERE, 'sign_state.json')

# ★★★ 私服专用身份（2026-09-29 事故后的隔离措施）★★★
#   老板的**官方**放置江湖账号是 userid=9048719784 / uuid=guanfang62c827d2fbb9bc04b8ad4e10。
#   以前我们把这两个值原样下发给客户端、客户端又原样放进每个请求头，
#   于是任何一次"漏到官方"的请求都等于替老板本人操作官方账号。
#   现在：对外一律用这套私服自己的号；官方那两个值只存在于 roles/full.json 的原档里，
#   **下发时替换、不落盘**（所以不会动到角色档本身，也不会影响老板的角色数据）。
PRIVATE_UUID = 'guanfangd5056b85e3c2fffc729191fd'
PRIVATE_USERID = 783783


def _sign_load():
    """已签到日期列表（我们服务端自己记账，签到才真的"签上了"）。"""
    try:
        with open(SIGN_FILE, encoding='utf-8') as f:
            return list(json.load(f))
    except Exception:                       # noqa: BLE001
        # 初始给最近 3 天已签，面板一打开就有"已签到"的绿勾
        return [time.strftime('%Y%m%d', time.localtime(time.time() - d * 86400))
                for d in (6, 5, 4)]


def _sign_add(date_str):
    lst = _sign_load()
    if date_str not in lst:
        lst.append(date_str)
        try:
            with open(SIGN_FILE, 'w', encoding='utf-8') as f:
                json.dump(lst, f, ensure_ascii=False)
        except OSError:
            pass
    return lst


# ---------------------------------------------------------------------------
# 家园：房号 → 房型（`get_user_map` 要按这个生成地图）
# ---------------------------------------------------------------------------
HOMELAND_FILE = os.path.join(HERE, 'homeland.json')

try:
    import fz_homeland_map as homeland
except Exception as _e:                     # noqa: BLE001
    homeland = None
    print('[boot] 家园地图生成器加载失败：%s' % _e)


def _homesave(mid, fq_id):
    d = {}
    try:
        with open(HOMELAND_FILE, encoding='utf-8') as f:
            d = json.load(f)
    except Exception:                       # noqa: BLE001
        d = {}
    d[str(mid)] = fq_id
    d['default'] = fq_id
    try:
        with open(HOMELAND_FILE, 'w', encoding='utf-8') as f:
            json.dump(d, f, ensure_ascii=False, indent=1)
    except OSError:
        pass


def _homeland_name(fq_id):
    if not homeland:
        return '家园'
    t = homeland.find_fq(fq_id) or {}
    return re.sub(r'(HIY|NOR|HIW|HIG|HIR|HIB|CYN|YEL|PNK)', '', t.get('name') or '家园')


def _homeland_address(fq_id):
    """地址文本：拿她 `房屋地皮` 里同号的 `place`+`name`，没有就自己编一个。"""
    if not homeland:
        return '扬州城'
    dp = homeland._tables()['dp']
    for _, v in dp.items():
        if v.get('dpId') == fq_id:
            return '%s%s' % (v.get('place') or '', v.get('name') or '')
    return '扬州城·%s' % _homeland_name(fq_id)


def _homeland_default():
    """这台机器上"老板的房"到底是哪个 fqId。

    顺序：`work/homeland.json` 的 default → 里面任意一条 → **最近一份上传存档里的 `fqId`**
    → `yangzhou001`。存档那条很关键：老板是先用旧版服务端买的房，
    存档里 `fq.mid` 是 0，只能靠 `fqId` 认房型。
    """
    try:
        with open(HOMELAND_FILE, encoding='utf-8') as f:
            d = json.load(f)
        if d.get('default'):
            return d['default']
        for k, v in d.items():
            if k.isdigit():
                return v
    except Exception:                       # noqa: BLE001
        pass
    try:
        files = sorted((os.path.join(SAVE_DIR, n) for n in os.listdir(SAVE_DIR)),
                       key=os.path.getmtime, reverse=True)
        for p in files[:5]:
            with open(p, encoding='utf-8', errors='replace') as f:
                m = re.search(r'"?fqId"?\s*[:=]\s*"?\[?\[?([A-Za-z0-9_]+)', f.read())
            if m and homeland and homeland.find_fq(m.group(1)):
                return m.group(1)
    except Exception:                       # noqa: BLE001
        pass
    return 'yangzhou001'


def _homeland_mid_for(fq_id):
    d = {}
    try:
        with open(HOMELAND_FILE, encoding='utf-8') as f:
            d = json.load(f)
    except Exception:                       # noqa: BLE001
        d = {}
    for k, v in d.items():
        if k.isdigit() and v == fq_id:
            return int(k)
    # ★★ 2026-10-01：**绝对不能用 `hash()`** —— Python 的字符串 hash 每个进程都不一样
    #   （PYTHONHASHSEED 随机），所以同一个人在两次登录会拿到**不同的 mid**，
    #   客户端 `Homeland.fq.mid` 和地图里的 mid 就对不上（管家不认人就是这么来的）。
    #   改成 md5 派生：同 fqId 永远同一个数。
    return 100 + (int(hashlib.md5(str(fq_id).encode('utf-8')).hexdigest()[:6], 16) % 900)


def _client_home_mid():
    """★ 玩家存档里写死的家园 mid（`Homeland.fq[1].mid`）——**这个才是权威值**。

    客户端 `BaseMap:isUserMap()`（`BaseMap.lua:4262`）判的是
        `tonumber(self.mid) == tonumber(fq.mid)`
    而 `fq` 就是存档里的 `Homeland.fq[1]`，`fq.mid` 是**买房那天客户端自己写下来的**。

    ★★ 2026-10-01 老板报「管家根本不认识我 / 这个家园不像我的 / 家园事务空白」：
      我们以前**自己现算**一个 mid（按 homeland.json 里第一条 yangzhou003 的键 → 559），
      而存档里是 640 ⇒ `isUserMap()` 恒为 false ⇒ `GuanJiaModule:entryMap`（:624）
      里的 `createInitialGuanJia` 压根不执行 ⇒ 管家那排按钮全都不出现。
      现在一律以**存档里的 mid** 为准。
    """
    try:
        with open(_canonical_save_path(), encoding='utf-8') as f:
            j = json.load(f)
        r = j[0] if isinstance(j, list) and j else j
        if not isinstance(r, dict):
            return 0
        hl = r.get('Homeland') or {}
        fq = hl.get('fq')
        # ★ `fq` 有三种形态都要认：表(dict) / 数组(list) / 混合（表里还留着数字键的老元素）。
        #   优先级：`fq.mid`（就是客户端 `Role:getHouseId()` 读的那个）> 老数组元素里的 mid。
        if isinstance(fq, dict):
            try:
                m = int(fq.get('mid') or 0)
            except (TypeError, ValueError):
                m = 0
            if m > 0:
                return m
            for k, v in fq.items():
                if str(k).isdigit() and isinstance(v, dict):
                    try:
                        m = int(v.get('mid') or 0)
                    except (TypeError, ValueError):
                        m = 0
                    if m > 0:
                        return m
        elif isinstance(fq, list):
            for it in fq:
                try:
                    m = int(it.get('mid') or 0)
                except (TypeError, ValueError, AttributeError):
                    m = 0
                if m > 0:
                    return m
    except Exception:                                                 # noqa: BLE001
        pass
    return 0


def _sticky_home_mid(fq_id=None):   # ★ 允许带参调用（调用点有 _sticky_home_mid(_fq_id)）
    """★ 家园 mid 必须**永远同一个**（2026-10-01 老板：离开家园再回去就"不像自己家"了）。

    客户端 `BaseMap:isUserMap()` 判的是 `usermap.mid == fq.mid`：
    两边只要有一次算得不一样（回家时重新拉房契/地图），管家那排
    「搬家/房屋事务/招募仆人/房屋改造/赏赐/户型图/仆人管理」就会集体消失。
    取值顺序：① 老板存档里记的 mid（`homeland_land_state.on_land.mid`，买房那天就定了）
              ② `homeland.json` 的 fq→mid 映射  ③ 现算一个并**写回 homeland.json** 固定下来。

    ★★ 2026-10-01 追加：**存档里 `Homeland.fq[1].mid` 优先于上面全部**（见 `_client_home_mid`）。
      否则 559 vs 640 对不上，`isUserMap()` 为 false ⇒ 管家不认人。
    """
    m = _client_home_mid()
    if m > 0:
        # 顺手把这个 mid → 当前房契 登记进 homeland.json（地图生成要用）
        try:
            fq = fq_id or _home_fq()
            d = {}
            if os.path.isfile(HOMELAND_FILE):
                with open(HOMELAND_FILE, encoding='utf-8') as f:
                    d = json.load(f)
            if not isinstance(d, dict):
                d = {}
            if d.get(str(m)) != fq:
                d[str(m)] = fq
                d.setdefault('default', fq)
                with open(HOMELAND_FILE, 'w', encoding='utf-8') as f:
                    json.dump(d, f, ensure_ascii=False, indent=1)
        except Exception:                                             # noqa: BLE001
            pass
        return m
    try:
        with open(os.path.join(HERE, 'homeland_land_state.json'), encoding='utf-8') as f:
            st = json.load(f)
        m = int((st.get('on_land') or {}).get('mid') or 0)
        if m > 0:
            return m
    except Exception:                                                  # noqa: BLE001
        pass
    fq = fq_id or _home_fq()
    m = int(_homeland_mid_for(fq))
    try:
        d = {}
        if os.path.isfile(HOMELAND_FILE):
            with open(HOMELAND_FILE, encoding='utf-8') as f:
                d = json.load(f)
        if not isinstance(d, dict):
            d = {}
        if str(m) not in d:
            d[str(m)] = fq
            with open(HOMELAND_FILE, 'w', encoding='utf-8') as f:
                json.dump(d, f, ensure_ascii=False, indent=1)
            log('★ 家（%s）mid 固定为 %d 并写回 homeland.json' % (fq, m))
    except Exception:                                                  # noqa: BLE001
        pass
    return m


# ---------------------------------------------------------------------------
# 家园「房屋管理」状态：改名 / 升级 / 管家门客 雇佣
#   （她客户端这些面板都在：FangJianGaiMingLayer 改名、HouseEnlarge*Layer 升级、
#     HomelandRoleEmployLayer 雇佣管家/门客、ServantRewardLayer 赏赐…）
# ---------------------------------------------------------------------------
HOME_FILE = os.path.join(HERE, 'homeland_state.json')


# ---------------------------------------------------------------------------
# 商城四个货架（限时 / 商城 / 关卡 / 神功）
# ---------------------------------------------------------------------------
# 老板报的真问题：「商城」四个页签只有前两个有货，**关卡和神功是空的**。
# 原因：以前只读 `boot_templates/api_v5_store_goods.json`（16 件），
# 而且把"关卡/神功"直接写成空表。
#
# 页签名是**客户端写死的**：`StoreLayer.lua:902` `{"限时","商城","关卡","神功"}`，
# 下标就是 `self.goodsType`（初值 2 = 商城）⇒ `data.list` 必须是这个顺序的 1..4 数组。
#
# 货架内容在她客户端里**没有一张"货架表"**（原版在服务端 DB），
# 所以按**她自己表里能表达该分类的字段**切，绝不自己编商品：
#   * 限时 = `storeItem.shangchengwupin` 里 `seeCondition == "限时礼包"`
#            （真价 688 元宝；点它走 `get_limit_package/<itemId>`）
#   * 关卡 = 同表 `seeCondition == "guanqiaLimit"`（副本 11-20/21-30/31-35/36-40/46-50，
#            真价 100/300/150/150/150 元宝）
#   * 商城 = 同表里有 `buyPrice`、不是"拜访物品"、也不是上面两类的（真货真价）
#   * 神功 = `shoplist.lua` 里 `itype == 5` 的 8 件书卷（复思之书/精研之书/超群之书…），
#            它们的 `itemId` 正是 `selfCreatedSkill/propMap.lua` 那 10 件自创武学道具
#            （也是 `inherit_skin` 的 `use_create_prop` / `use_improve_prop` 消耗的东西）
#            ★ **价格在原版服务端，客户端资源里没有** ⇒ 显示 0，不瞎编。
_STORE_SHELF_CACHE = {}

# ---------------------------------------------------------------------------
# 元宝到底是多少 —— **全服唯一真源**
# ---------------------------------------------------------------------------
# 老板报的 bug：「商城买东西之后元宝数量异常变动」。
# 根因是三处**各报各的**：
#   * `get_yuanbao`            写死 99999
#   * `get_store_list_4`       写死 99999（客户端 `StoreLayer.lua:107-108` 会
#                              `User:setRoleAttr("yuanbao", data.yuanbao)` **硬覆盖**本地的）
#   * `buy_goods_3`（shop_store）报的是**真钱袋**（`homeland_state.json["currency"]`）
# ⇒ 买之前显示 99999、买完那一下就变成真钱袋（当时是 5 千 4 百万）、再打开商城又跳回 99999。
# 修法：**三处都从 `items_currency` 那份唯一账本读**，谁也别写死。
def _purse_currency(kind='yuanbao', default=0):
    try:
        with open(HOME_FILE, encoding='utf-8') as f:
            cur = (json.load(f) or {}).get('currency') or {}
        return int(float(cur.get(kind, default) or 0))
    except Exception:                            # noqa: BLE001
        return default

# 她表里的商品名带颜色标记（`HIM冰糖葫芦` / `HIY福缘丹`…），商城里要显示干净名字
_COLOR_TAG = re.compile(r'(HIY|NOR|HIW|HIG|HIR|HIB|HIC|CYN|YEL|PNK|HIM|GRN|ORA|PUR|RED)')


def _strip_color(s):
    return _COLOR_TAG.sub('', str(s or '')).strip()


def _store_shelves():
    if _STORE_SHELF_CACHE:
        return _STORE_SHELF_CACHE
    import fz_luatable
    res = _fz_res('store')
    try:
        items = fz_luatable.load_lua_table(os.path.join(res, 'storeItem.lua'))
        shop = fz_luatable.load_lua_table(os.path.join(res, 'shoplist.lua'))
    except Exception as _e:                       # noqa: BLE001
        log('[商城] 读她两张店表失败：%s' % _e)
    else:
        mall = items.get('shangchengwupin') or {}
        shops = shop.get('Sheet1') or {}
        by_item = {}
        for k, v in shops.items():
            if isinstance(v, dict) and v.get('itemId'):
                by_item.setdefault(str(v['itemId']), (str(k), v))
        out = {'限时': [], '商城': [], '关卡': [], '神功': []}
        for k, v in mall.items():
            if not isinstance(v, dict) or not v.get('buyPrice'):
                continue
            item_id = str(v.get('id') or k)
            gk, gv = by_item.get(item_id, ('', {}))
            row = {
                'id': gk or item_id, 'itemId': item_id,
                'name': _strip_color(v.get('name') or gv.get('name') or item_id),
                'dsc': v.get('dsc') or v.get('itemDesc') or gv.get('dsc') or '',
                'icon': gv.get('icon') or '',
                'price': int(v.get('buyPrice') or 0),
                'priceUnit': v.get('priceUnit') or 'yuanbao',
                'number': 1, 'itype': gv.get('itype') or 1,
            }
            cond = str(v.get('seeCondition') or '')
            if cond == '限时礼包':
                # ★ 原版「限时」是一排**礼包**（老板截图），不是单件 `xianshilibao`。
                #   这里跳过，改由下面那张原版清单生成。
                continue
            elif cond == 'guanqiaLimit':
                # ★ 这些 `fuben11-20` 之类的**不是**「关卡」页签的货（我一开始猜错了，
                #   老板拿原版截图纠正：那页卖的是"卷"）。它们也不进商城，跳过。
                continue
            elif str(v.get('itype')) != '拜访物品':
                # ★ 只有**在 `shoplist` 里查得到**的才能上架。
                #   客户端买东西是拿我给的 `id` 去 `get_goods/<id>`，服务端要能把它
                #   归一成 shoplist 键；不在 shoplist 的（`meirongwan`/`fuyuandan`…
                #   44 件里有 35 件）会直接 errcode 1 ⇒ 老板看到的
                #   「获得商品数据出错。」就是这个。宁可少上，不能上买不了的。
                if not gk:
                    continue
                out['商城'].append(row)
        # ---------------------------------------------------------------
        # 关卡页签 = **卷**（老板提供的原版截图 + 她自己的 `newmap/map/world.lua`）
        # ---------------------------------------------------------------
        # `world.lua` 是权威表：`{id=volume_N, name=卷名, includeMap="fbA;fbB;…"}`。
        # 原版「关卡」页签列的就是 volume_2..volume_7 六个卷（和截图**逐个对上**：
        #   声震武林卷 / 柳玄风卷上 / 柳玄风卷下 / 章作之卷 / 折掌镇海卷 / 藏锋破阵卷）。
        # ★ 价格：她客户端资源里**没有**卷的价（原版在服务端），
        #   下面这 6 个价取自**老板给的原版截图**（100/150/150/200/100/100），是真数据不是编的。
        #   剩下没截到的卷（鹊起无名卷/八方风雨卷/门派卷/家园卷/活动卷）不给价、也不上架。
        _VOL_PRICE = {
            '声震武林卷': 100, '柳玄风卷上': 200, '柳玄风卷下': 150,
            '章作之卷': 150, '折掌镇海卷': 100, '藏锋破阵卷': 100,
        }
        # 原版显示带括号：`柳玄风卷(上)`（`world.lua` 里写的是"柳玄风卷上"）
        def _vol_label(nm):
            for suf in ('上', '下'):
                if nm.endswith(suf) and len(nm) > 1:
                    return '%s(%s)' % (nm[:-1], suf)
            return nm
        try:
            world = fz_luatable.load_lua_table(
                _fz_res('newmap', 'map', 'world.lua'))
        except Exception as _e2:                  # noqa: BLE001
            world = []
            log('[商城] 读 world.lua 失败：%s' % _e2)
        for v in (world or []):
            if not isinstance(v, dict):
                continue
            nm = str(v.get('name') or '')
            if nm not in _VOL_PRICE:
                continue
            out['关卡'].append({
                'id': str(v.get('id') or ''), 'itemId': str(v.get('id') or ''),
                'name': _vol_label(nm),
                # 卷没有自己的图标（不在 shoplist 里）⇒ 借用她书卷类的卷轴图，
                # 不然客户端画出来是个缺省金球（老板就是看到金球才问的）
                'icon': 'Image/UI/StoreUI/shujuan1.png',
                'dsc': '包含关卡：%s' % str(v.get('includeMap') or '').replace(';', '、'),
                'price': _VOL_PRICE[nm], 'priceUnit': 'yuanbao',
                # ★ 2026-10-03 修「商场买了关卡解锁不了」：客户端
                #   `StoreLayer:aftreBuyGoodsSuccess` 只在 **itype==11** 时写
                #   `m_volume[itemId]=true`（章节解锁的全部动作）；itype=5 走普通物品
                #   分支把卷塞进背包、m_volume 永远不写。原版发的就是 11。
                'number': 1, 'itype': 11,
            })
        # ---------------------------------------------------------------
        # 限时页签 = **一排礼包**（老板提供了原版截图）
        # ---------------------------------------------------------------
        # 她 `map/mapItemAttr/Items.lua` 里有几百件 `限时礼包(XX)` / `每日礼包` /
        # `兵器秘籍礼包`…（`libao` + 编号），**但基本没有 `buyPrice`**（价在原版服务端）。
        # 下面这 8 件的**名字和价都取自老板给的原版截图**（真数据）：
        #   限时礼包(桂秋)588 / (商吕)588 / (竹春)488 / 兵器秘籍礼包388 /
        #   拳脚秘籍礼包388 / 轻内秘籍礼包388 / 新秀礼包258 / 每日礼包158
        # 截图里还有 `名士礼包(中秋)/(秋分)`，被截断看不到价 ⇒ **不上架**（不编价）。
        # 图标：她客户端 `Image/UI/StoreUI/` 下**没有礼包图**（只有卷轴 juanzhou/shujuan
        # 和元宝图）⇒ 借卷轴图，不然画出来是缺省金球。
        # ---------------------------------------------------------------
        # 「限时」页签 = 合体武学宝箱（**不容易获取**的那一批）
        # ---------------------------------------------------------------
        # 老板 2026-09-28 指示：一半放「限时」、一半放「神功」，
        #   **限时放不容易获取的**。
        # 切分见 `fz_api/combo_box.py` 的 `HARD_IDS` / `EASY_IDS`：
        #   难 = 残篇礼盒 / 器名即武学名的失传神功专箱 / 活动礼包（64 个）
        #   易 = 每日福袋系列（58 个）
        # ⚠️ 判据是**箱子类型**（表里没有 dropScheme 等来源字段），属可辩护近似。
        #
        # ★ 老板 2026-09-28 追加指示：**神功与限时的物品互换**
        #   ⇒ 「限时」放**易**（每日福袋 58），「神功」放**难**（残篇礼盒 64）。
        #
        # 旧注释保留（以免重蹈）：曾把 16 个活动礼包（`libao*`）摆这里，
        #   但它们**内容物在客户端不存在**（`Items.lua` 只有 id+name、
        #   `Rewards.lua` 查不到）⇒ 开了是空的 ⇒ 老板裁定"宁可不卖也不卖空壳"，
        #   那次整栏清空。现在的箱子都是**内容物齐全**的合体箱（`rwId` 已补残页）。
        #
        # ★ 2026-10-01 老板指示：**限时商场清空，改放"通用测试礼包"**
        #   （经验潜能/货币/基础武学/面具/先天丹/满级/随机书页残页），
        #   武学相关的（一门武学一个书页包）放「神功」，资源礼包放「商城」子栏。
        #   四个页签名是客户端写死的（`StoreLayer.lua:902`），顺序不能动。
        try:
            import fz_api.shop_store as _ss0
            out['限时'] = _ss0.test_pack_shelf_rows(groups=('general',))
        except Exception as _le:                  # noqa: BLE001
            log('[商城] 限时（通用测试礼包）上架失败：%s' % _le)
            out['限时'] = []

        # ---------------------------------------------------------------
        # ★★「神功」页签 = 合体武学宝箱（老板 2026-09-28 定的设计）
        # ---------------------------------------------------------------
        # 设计：**一个箱子 = 一门武学的全套书页 + 该武学全部主动技能残页**，
        #   一开就把这门武学练到底。统一 500 元宝。
        # 数据/开箱逻辑见 `fz_api/combo_box.py`（10 个先做，122 个可做）。
        #
        # 为什么 itype=10 而不是 12：`:362` 的 12 是"神功虚拟物品"⇒**不进背包**；
        #   宝箱必须真进背包才能开 ⇒ 走 10（`:366` else ⇒ `addItemCount`）。
        #
        # ⚠️ 旧注释（保留以免重蹈）：`shoplist.itype==5` 那 8 件（复思之书/精研之书/
        #   江湖令…，键 400011–400018）的 itemId **不在客户端认的 10 张 sheet 里**，
        #   一买就报「无法找到该资源」。所以那一批不上架，改上我们的合体箱。
        #   四个页签名是客户端写死的（`StoreLayer.lua:902`），第 4 格必须留着。
        # ---------------------------------------------------------------
        # ★★「书页礼包」（一门武学一个，1 银两、不限购）+「武学总纲」
        # ---------------------------------------------------------------
        # 物品本体在**客户端表**里（`Items.lua` 的 `testpack_books_*` + `Rewards.lua` 的 rid），
        # 这里只负责上架 / 报价；买完真进背包，玩家点开才发书页（开箱是客户端本地行为）。
        # ★ 2026-10-01 老板：原来那 64 个「合体武学宝箱」和新书页包**重合**（它们的武学
        #   100% 都在 172 个书页包里）⇒ 不再上架，神功栏只留书页包（代码保留可回滚）。
        try:
            import fz_api.shop_store as _ss
            out['神功'] = _ss.test_pack_shelf_rows(groups=('books',))
        except Exception as _te:                  # noqa: BLE001
            log('[商城] 书页礼包上架失败：%s' % _te)
            out['神功'] = []
        for k in out:
            out[k].sort(key=lambda r: r['price'])
        _STORE_SHELF_CACHE.update(out)
        log('[商城] 货架：限时 %d / 商城 %d / 关卡 %d / 神功 %d'
            % (len(out['限时']), len(out['商城']), len(out['关卡']), len(out['神功'])))
        return _STORE_SHELF_CACHE
    # 读表失败就退回老模板，至少别让面板空着
    tpl = load_template('api_v5_store_goods') or []
    _STORE_SHELF_CACHE.update({'限时': tpl[:3], '商城': tpl[3:],
                               '关卡': [], '神功': []})
    return _STORE_SHELF_CACHE


def _home_load():
    d = {}
    try:
        with open(HOME_FILE, encoding='utf-8') as f:
            d = json.load(f)
    except Exception:                       # noqa: BLE001
        d = {}
    d.setdefault('name', None)              # 玩家改过的宅院名
    d.setdefault('fqId', None)              # 升级后的房契模板
    d.setdefault('employees', [])           # 已雇佣的管家/门客/仆人
    d.setdefault('currency', {'yinpiao': 200000, 'yuanbao': 99999, 'money': 200000})
    return d


def _home_save(d):
    try:
        with open(HOME_FILE, 'w', encoding='utf-8') as f:
            json.dump(d, f, ensure_ascii=False, indent=1)
    except OSError:
        pass
    return d


def _home_name(fq_id):
    """玩家改过就用改过的名字（`rename_home`）。"""
    st = _home_load()
    return st.get('name') or _homeland_name(fq_id or _homeland_default())


def _home_fq():
    """当前生效的房契 id（升级会换）。"""
    st = _home_load()
    return st.get('fqId') or _homeland_default()


def _home_roomnum(fq_id):
    if not homeland:
        return 9
    t = homeland.find_fq(fq_id) or {}
    return t.get('roomnum') or 9


def _hire_list(npc_id):
    """雇佣候选列表（内容用她自己的门客/仆人模板，缺表就退化成通用三条）。"""
    st = _home_load()
    hired = {str(e.get('objId')) for e in st.get('employees') or []}
    out = []
    base = [('guanjia001', '管家', 500, 'yuanbao'), ('puren001', '仆人', 100, 'yinpiao'),
            ('menke001', '门客', 300, 'yinpiao'), ('puren002', '粗使丫头', 80, 'yinpiao'),
            ('menke002', '护院武师', 400, 'yinpiao')]
    for i, (jt, nm, price, unit) in enumerate(base):
        obj = '%s_%s' % (npc_id or 'npc', i + 1)
        out.append({'objId': obj, 'hid': 0, 'jobType': jt, 'name': nm,
                    'price': price, 'price_unit': unit,
                    'state': 1 if obj in hired else 0})
    return out



#   ★ 关键：**内容是她客户端自己抽的**（`IntelligenceManager:getIntelligenceList` 的
#     `errcode == 2` 分支：从 `script.others.qingbaoku`（235 条）× `qingbaomoban`（4 模板）
#     里随机抽，然后 `uploadIntelligenceData` 传上来）。服务端只要当好"当天的账本"：
#       未上传 → errcode 2（她抽完会自己传上来）
#       已上传未买 → errcode 1 + price/currency_type（她弹购买框）
#       已买 → errcode 0 + intelligence_list（面板就渲染出来了）
# ---------------------------------------------------------------------------
INTEL_FILE = os.path.join(HERE, 'intelligence.json')


def _intel_load():
    d = {}
    try:
        with open(INTEL_FILE, encoding='utf-8') as f:
            d = json.load(f)
    except Exception:                       # noqa: BLE001
        d = {}
    today = time.strftime('%Y%m%d')
    if d.get('day') != today:               # 跨天 ⇒ 今天的还没上传
        d = {'day': today, 'uploaded': False, 'bought': False,
             'intelligence_list': [], 'technique_list': [],
             'currency_type': 1, 'price': 0}
    return d


def _intel_save(d):
    try:
        with open(INTEL_FILE, 'w', encoding='utf-8') as f:
            json.dump(d, f, ensure_ascii=False, indent=1)
    except OSError:
        pass
    return d


def _intel_entries(ids, read):
    """★ 应答里的 `intelligence_list` 条目必须是 **`{id, is_read}` 对象**，
      不是裸 id！`IntelligencePresenter:listSort`（:30-43）会读
       `a.is_read` / `a.id` 排序 ⇒ 给裸数字就 `attempt to compare two nil values`（已实测）。
       （上传上来的是裸 id 数组，服务端负责包成对象。）"""
    rd = {str(x) for x in (read or [])}
    out = []
    for i in (ids or []):
        out.append({'id': i, 'is_read': 1 if str(i) in rd else 0})
    return out


# 技巧类情报（江湖秘辛）—— 她表里 `qingbaoku` 有 50 条 `type == 3`（全部 open=1），
# 但 `qingbaomoban` 那 4 个模板的 `technique_open` **全是 0**，所以她客户端
# `_create_technique_IntelligenceList` 直接 return {} ⇒ 上传的 technique_list 是空的
# ⇒ 江湖秘辛面板一片空白。这里由**服务端补上**（内容仍然全部来自她那 50 条）。
_TECH_CACHE = {'ids': None}


def _intel_technique_ids():
    if _TECH_CACHE['ids'] is None:
        ids = []
        try:
            import fz_luatable
            p = os.path.join(_fz_res('others'), 'qingbaoku.lua')
            t = fz_luatable.load_lua_table(p)
            t = t.get('Sheet1') or t
            for v in t.values():
                if isinstance(v, dict) and v.get('type') == 3 and v.get('open') == 1:
                    ids.append(v.get('id'))
            ids = [i for i in ids if i is not None]
        except Exception as e:              # noqa: BLE001
            log('情报：技巧类表读不出来（%s），江湖秘辛将为空' % e)
        _TECH_CACHE['ids'] = sorted(ids)
    return _TECH_CACHE['ids']


def _intel_seed_techniques(n=14):
    """给江湖秘辛塞一页多一点的起手内容（一页 7 条，给 14 条 ⇒ 翻页按钮也是活的）。"""
    ids = _intel_technique_ids()
    if not ids:
        return []
    random.shuffle(ids)
    return ids[:n]

# 角色来源：official = 客户端自己上传的那份（你官方账号的原样）；
#           ours     = 我们自己的角色档（work/roles/full.json，功能全开）
ROLE_MODE = 'official'
# 主界面皮肤：她 `UISkinlistConfig` 里的 uiId —— default / uijiemian1…6
# （对应她自己的资源 `Image/UI/SkinUI/Skin_N/*`；客户端在 ControllLayer:startGame 里按 usedUiId 切）
OUR_SKIN = 'uijiemian1'


def _decode_client_body(body):
    """客户端上行正文是 `JMForLua:encrypt(data,"FZJH03")`；用本会话 key 解出明文。"""
    if not body:
        return None
    try:
        return fzc.decrypt(body).decode('utf-8', 'replace')
    except Exception:                       # noqa: BLE001
        return None


def save_upload(headers, body):
    """`upload_user_file_3/<类型>/<作弊码>`（还有 `_4`/`_5` 变体）

    契约（`HttpManager.lua:165-190`）：`status==200 且 errcode==0 且 data.primeryKey ~= nil`
    时客户端把 `primeryKey` 记到存档里。我们顺手把这份存档**解密后存在我们服务端**
    （`work/saves/<uuid>.json`）——这就是"存档由我们持有"的第一块。
    """
    os.makedirs(SAVE_DIR, exist_ok=True)
    uuid = headers.get('uuid') or 'nouuid'
    userid = headers.get('userid') or '0'
    plain = _decode_client_body(body)
    # ★★ 2026-10-01：**只写"本机唯一存档位"**（见 `_canonical_save_key`）。
    #   以前按 `md5(uuid|请求头userid)` 落盘 ⇒ 请求头 userid 一变（create_account
    #   给的是另一个号）就写到另一个文件，下次登录读到的是旧的 ⇒ 进度全丢。
    key = _canonical_save_key()
    if plain:
        with open(_canonical_save_path(), 'w', encoding='utf-8') as f:
            f.write(plain)
        log('存档已收到并落盘 saves/%s.json (%d 字节明文)【本机唯一存档位】'
            % (key, len(plain)))
    else:
        log('存档上传：正文没解出明文（len=%d），仍回 primeryKey' % len(body or b''))
    return {'errcode': 0, 'data': {'primeryKey': key}, 'rand_t': time.time()}




def _clear_client_cache():
    """★ v23：启动时清掉**客户端资源缓存**，让"覆盖安装"也能跑到最新的 Lua。

    客户端把上一版的 Lua 缓存在 `files/updatePath_android_2.1.02/`（还有 `luaTablePath/`），
    而我们的 md5 清单里 deploy 是空的（离线包的正确配方）⇒ 它**永远不会去刷新**这些缓存
    ⇒ 我改的 Role_Attr/礼包脚本在客户端那边还是旧版（老板实测："商店里买了打开没效果"）。
    这两个目录是纯缓存，删掉后客户端会从 APK 重新解出来（存档在 files/jhserver/ 下，不受影响）。
    """
    files = None
    try:
        files = os.path.dirname(HERE.rstrip('/\\'))
    except Exception:                                                 # noqa: BLE001
        return
    if not files or not os.path.isdir(files):
        return
    n = 0
    for name in os.listdir(files):
        if name.startswith('updatePath') or name == 'luaTablePath':
            p = os.path.join(files, name)
            try:
                shutil.rmtree(p)
                n += 1
                log('★ 清掉客户端资源缓存：%s（客户端会从 APK 重新解，存档不受影响）' % name)
            except Exception as e:                                    # noqa: BLE001
                log('清缓存失败 %s：%s' % (name, e))
    return n


try:
    pass   # FZ_NO_CACHE_CLEAR 不再清缓存（会触发版本检查 404）
except Exception:                                                     # noqa: BLE001
    pass

def _seed_once():
    """★ v22：把包里的 `seed/`（首次安装的呆呆档/家园/各类进度）**只在目标不存在时**铺出来。

    为什么要：App 现在每次启动都从 APK 重解压服务端（治"覆盖安装不生效"），
    而解压是整体覆盖 —— 如果进度文件还放在包根，每次启动都会被打回打包快照
    （老板实测："重新登录存档就变回去、房子没了"）。
    现在包里只留 `seed/`，运行时文件（saves/ homeland*.json *_state.json）解压碰不到，
    首次安装由这里铺一次，之后就一直是玩家自己的进度。
    """
    seed = os.path.join(HERE, 'seed')
    if not os.path.isdir(seed):
        return
    n = 0
    for dp, _dn, fn in os.walk(seed):
        rel = os.path.relpath(dp, seed)
        dst_dir = HERE if rel == '.' else os.path.join(HERE, rel)
        try:
            os.makedirs(dst_dir, exist_ok=True)
        except Exception:                                             # noqa: BLE001
            continue
        for f in fn:
            src = os.path.join(dp, f)
            dst = os.path.join(dst_dir, f)
            if os.path.exists(dst):
                continue
            try:
                shutil.copy2(src, dst)
                n += 1
            except Exception:                                         # noqa: BLE001
                pass
    if n:
        log('★ 首次铺底：从 seed/ 铺出 %d 个文件（存档/家园/进度）' % n)


_seed_once()

def _norm_homeland(hl):
    """★ 把 `Homeland` 整成**客户端自己认的形状**。

    ★★ 2026-10-01 找到的关键 bug（老板："管家根本不认识我 / 这不像我的家园 / 家园事务空白"）：
      客户端 `Homeland.fq` **是一张表(dict)**，不是数组：
        · `FangQiModel.lua:64-88`   `fq.mid = tonumber(data.mid)` / `fq.fqId = ...` /
                                    `fq.dpId` / `fq.type = "房契"` / `fq.id = "fq100"`
        · `Role:getHouseId()`（`Role.lua:4711`）  `return fq.mid`
        · `BaseMap:isUserMap()`（`BaseMap.lua:4262`）
              `tonumber(self.mid) == tonumber(fq.mid)`
      而玩家存档里是 `fq = [ {fqId=..., mid=640, ...} ]`（数组）⇒ `fq.mid` 取到 **nil**
      ⇒ `isUserMap()` 恒为 false ⇒ `GuanJiaModule:entryMap`（:624）里的
      `createInitialGuanJia` 不执行 ⇒ **管家那排按钮一个都不出现**。
      这里把数组形态合并成一张表（元素里的字段摊平上来），并补齐她代码要读的字段。
    """
    if not isinstance(hl, dict):
        return hl
    fq = hl.get('fq')
    merged = {}
    if isinstance(fq, dict):
        # 混合形态：表里还留着老数组元素（数字键 "1"/"2"…）⇒ 先摊平，再让顶层字段覆盖
        for k in list(fq.keys()):
            if str(k).isdigit():
                v = fq.pop(k)
                if isinstance(v, dict):
                    for kk, vv in v.items():
                        merged.setdefault(kk, vv)
        for kk, vv in fq.items():
            merged[kk] = vv
    elif isinstance(fq, list):
        for it in fq:
            if isinstance(it, dict):
                merged.update(it)
    hl['fq'] = fq = merged
    if not isinstance(fq, dict) or not fq:
        return hl
    fq.setdefault('id', 'fq100')            # `FangQiModel` 写的就是这个
    fq.setdefault('type', '房契')
    fq.setdefault('name', '家园')
    # `Role:getHouseStatus()` 读 `fq.status`：1 = 已搬入（我们私家服天生就算搬进去了）
    if not fq.get('status'):
        fq['status'] = 1
    # `Role:getDpId()` 读 `fq.dpId`，`HomelandRoomUtil:outDoorByDp` 要用
    if not fq.get('dpId'):
        try:
            import fz_homeland_map as _hm
            fq['dpId'] = _hm._pick_dp(str(fq.get('fqId') or '')) or str(fq.get('fqId') or '')
        except Exception:                                             # noqa: BLE001
            fq['dpId'] = str(fq.get('fqId') or '')
    if not isinstance(hl.get('roomnum'), int) or hl.get('roomnum') in (0, None):
        try:
            import fz_homeland_map as _hm
            tpl = _hm.find_fq(str(fq.get('fqId') or '')) or {}
            hl['roomnum'] = int(tpl.get('roomnum') or 0) or hl.get('roomnum') or 0
        except Exception:                                             # noqa: BLE001
            pass
    for k in ('dq', 'yq', 'plant', 'dinner'):
        if not isinstance(hl.get(k), list):
            hl[k] = []
    for k, dv in (('prIdIndex', 0), ('prnum', 0)):
        if not isinstance(hl.get(k), int):
            hl[k] = dv
    return hl


def _norm_meridian(role):
    """★ 把 `meridian` 整成客户端敢吃的结构。

    ★★ 2026-10-01：老版本的服务端通脉丹往这里写过 `activated / chartId / buffs / attached`
      ——**客户端不认这些**。而 `Meridian:initMerdian()`（`Meridian.lua:74`）是
      "`meridian` 为空才初始化"，被写歪以后**表非空 ⇒ 跳过初始化**
      ⇒ `meridian.meridianCount` 是 nil ⇒ 经脉面板 `nil + 1` 报错（"点了没效果"的真身）。
      这里补齐客户端真正要读的键（缺失才补，不动玩家真实进度）。
    """
    if not isinstance(role, dict):
        return role
    m = role.get('meridian')
    if not isinstance(m, dict):
        return role
    changed = []
    for k in ('activated', 'attached', 'buffs', 'chartId'):
        if k in m:
            m.pop(k, None)
            changed.append('-' + k)
    for k, dv in (('meridianCount', 0), ('acupointCount', 0), ('acupointState', 1),
                  ('alreadyDisease', 0), ('alreadyDisorder', 0), ('failCount', 0)):
        if not isinstance(m.get(k), (int, float)):
            m[k] = dv
            changed.append(k)
    if not isinstance(m.get('attrList'), list):
        m['attrList'] = []
        changed.append('attrList')
    if not isinstance(m.get('attrTotal'), dict):
        m['attrTotal'] = {k: 0 for k in ('qiMax', 'neiLiLimit', 'atk',
                                         'dodge', 'def', 'damage', 'protect')}
        changed.append('attrTotal')
    if changed:
        log('★ 经脉结构修复：%s（meridianCount=%s）' % (','.join(changed), m.get('meridianCount')))
    # 玄络印记页：`MeridianRoleSystemImpl:__init`（:50-55）要求 mPageList 至少一页，否则直接 error
    im = role.get('m_meridianImprintings')
    if isinstance(im, dict):
        pl = im.get('mPageList')
        if not isinstance(pl, dict) or not pl:
            im['mPageList'] = {'1': {}}
            log('★ 玄络印记页修复：mPageList 缺失/为空 ⇒ 补第 1 页')
        if not isinstance(im.get('mImprintingMap'), dict):
            im['mImprintingMap'] = {}
        if not isinstance(im.get('mCurrPage'), (int, float)):
            im['mCurrPage'] = 1
    return role


def _overlay_persisted_attrs(role):
    """把客户端上传存档里的**先天属性 / 福缘**盖到角色档上再下发。

    为什么要：先天属性丹/福源丹是**客户端本地**生效的（跟其它测试礼包一样），
    改完的值随存档上传到 saves/。但 `--role ours` 每次下发的是 roles/full.json，
    不盖一下的话重新登录就被打回原样（先天 200/福缘 86）。
    只盖这 5 个字段 + 先天分配方案，别的一概不动 —— full.json 里"功能全开"的部分不能丢。
    """
    try:
        p = _canonical_save_path()
        if not os.path.exists(p):
            return role
        with open(p, 'r', encoding='utf-8') as f:
            j = json.load(f)
        src = (j[0] if isinstance(j, list) and j else j)
        if not isinstance(src, dict):
            return role
        got = {}
        for k in ('str', 'int', 'con', 'dex', 'luck'):
            v = src.get(k)
            if isinstance(v, (int, float)) and not isinstance(v, bool):
                got[k] = v
        if got:
            role.update(got)
            log('★ 先天属性/福缘回写（来自客户端存档）：%s' % got)
        sp = src.get('naturalAttrPlan')
        if isinstance(sp, dict) and isinstance(role.get('naturalAttrPlan'), dict):
            sd = (sp.get('planDict') or {}).get('base')
            if isinstance(sd, dict):
                role['naturalAttrPlan'].setdefault('planDict', {})['base'] = sd
        # ★★ 2026-10-01 老板要「经脉丹（服务端生效）」：经脉 / 奇经 / 天赋这些**存档字段**
        #   以前不下发 ⇒ 服务端改了客户端也看不到（两本账）。这里一并盖上去
        #   （只搬这几个键，full.json 里"功能全开"的部分仍然不动）。
        # ★ 2026-10-01 老板：'买了房子，退出重进就没了' —— 房契/地契字段不在回写名单里，
        #   登录时客户端拿到 roles/full.json（没房子）⇒ 本地房契被覆盖 ⇒ 再上传就真丢。
        # ★ 客户端真正存房子的是 `Homeland`（大写，里面才有 fq/dq/roomnum）
        for k in ('Homeland', 'fq', 'dpId', 'location', 'houseName', 'homelandAttr', 'homeLandRoleData',
                  'homeland', 'meridian', 'hiddenMeridianData', 'm_meridianImprintings',
                  'PrepareTalent', 'DreamTalent', 'meridianExp', 'meridianTalent',
                  # ★ 2026-10-01 两颗冲脉丹的**永久标记**（必须随角色下发，否则重登就失效）
                  'fzBreak100', 'fzHiddenBreak100',
                  # ★ 2026-10-04 疲倦值随存档回写（安神枕 +500 是客户端本地加的，
                  #   不回写的话重登就被服务端模板打回）
                  'pijuan',
                  # ★ 2026-10-05 神兵领取修复：shenBingItems（神兵列表，含打造完未领取的）
                  #   不回写的话客户重登（特别版网络不稳易触发）⇒ 下载把未领取神兵清空
                  #   ⇒ 命名确定后 addItemCount(weapon_N) 查不到 ⇒ 静默领取失败
                  'shenBingItems',
                  # ★ 2026-10-05 锻造材料同理：冶炼箱（smeltBox）/药囊（medicinalBox）里的
                  #   矿石/药材不回写 ⇒ 重登清空 ⇒ 锻造炉材料选择器显示不出材料
                  'smeltBox', 'medicinalBox',
                  # ★ 2026-10-06 锻造知识同理：书匣（literaryBox，锻造图谱的研读等级）
                  #   不回写 ⇒ 重登图谱消失 ⇒ "尚未学习对应技艺，无法锻造材料"
                  'literaryBox',
                  # ★ 2026-10-06 背包神兵可携带上限（老板定 99）：不回写的话客户端改了
                  #   （升级购买/直接置数）重登就被 full.json 模板打回 1 ⇒ 领取又被拦
                  'bagShenBingNumLimit',
                  # ★ 2026-10-06 拥有神兵上限（老板定 99，同上）
                  'shenBingNumLimit'):
            v = src.get(k)
            if v is not None:
                role[k] = v
        # ★★ 2026-10-06 老板定：背包/拥有神兵上限**强制 99**（登录保底，与疲倦值同模式）。
        #   白名单回写只搬存档值——客户的存档还是 1/10，覆盖装新包后上限不会自己变 99；
        #   必须**每次登录强制置 99**，老档新档客户老板一律生效。
        #   （原版升级购买路径买的上限会被这里的 99 覆盖——老板拍板全 99，不再依赖购买。）
        role['bagShenBingNumLimit'] = 99
        role['shenBingNumLimit'] = 99
        # ★★ 2026-10-04 老板：疲倦值**登录保底 500**——入梦门槛 ≥80、入梦一次 -80。
        #   客户实测"用了安神枕疲倦值上去了、重登又被打回 41"⇒ 服务端兜底，
        #   每次登录至少给 500（够入梦 6 次）；存档里更高的照常保留。
        if not isinstance(role.get('pijuan'), (int, float)) or isinstance(role.get('pijuan'), bool) \
                or role.get('pijuan', 0) < 500:
            role['pijuan'] = 500
            log('★ 疲倦值保底 500（入梦门槛 ≥80，入梦一次 -80）')
        # ★★ 2026-10-04 玩家反馈「没有药囊/百毒谱打不开 → 神兵任务卡住」：
        #   背包的药囊页签(medicinalBox)只在 getInheritFlag("毒药系统")>=1 时创建
        #   （MapBag.lua:144），而这个标记官方只有学了门派毒术技能才开
        #   （PoisonUtil:openPoisonSysFromSkill 置 2）⇒ 普通玩家永远没有药囊。
        #   服务端登录时在 _inherit_flags（存档键[21]，Role_Inherit.lua）里保底置 2。
        _iflags = role.get('_inherit_flags')
        if not isinstance(_iflags, dict):
            _iflags = {}
            role['_inherit_flags'] = _iflags
        try:
            _poison = int(_iflags.get('毒药系统') or 0)
        except (TypeError, ValueError):
            _poison = 0
        if _poison < 2:
            _iflags['毒药系统'] = 2
            log('★ 毒药系统标记保底置 2（药囊页签可见，MapBag.lua:144 门槛）')
        # ★★ 2026-10-05 老板实测"我没通过神兵系列任务，不能打造"：神兵系统（锻造/强化/领取）
        #   整体被「唐门之乱」剧情锁着（开始神兵任务=2 才开；=1 还在送贺礼阶段）。
        #   单机版直接保底置 2 —— 免做长剧情，锻造炉/神兵主界面/领取全部解锁。
        try:
            _sbq = int(_iflags.get('开始神兵任务') or 0)
        except (TypeError, ValueError):
            _sbq = 0
        if _sbq < 2:
            _iflags['开始神兵任务'] = 2
            log('★ 开始神兵任务标记保底置 2（神兵系统解锁，免做唐门之乱剧情）')
        # ★★ 2026-10-14 神兵直开的另一个锁（老板：客户老档"开启任务"卡住，直接给开）：
        #   「可进入苏州水底」=1 才开——主界面神兵按钮（MainLayer:673）/地图锻造·熔炉·
        #   加工·修理（SpecialModule）/家具神兵台（FurnitureModule）。跟上面的
        #   「开始神兵任务」成对，缺一个都会"看着开着却用不了"。客户端 repairUserData
        #   里有同款保底（本地老档即时生效），这里兜下载路径 + 开发版。
        try:
            _syd = int(_iflags.get('可进入苏州水底') or 0)
        except (TypeError, ValueError):
            _syd = 0
        if _syd < 1:
            _iflags['可进入苏州水底'] = 1
            log('★ 可进入苏州水底标记保底置 1（神兵系统直开，与开始神兵任务成对）')
        # ★★ 2026-10-01：`Homeland.fq` 必须是表(dict)，不是数组 ——
        #   否则客户端 `BaseMap:isUserMap()` 拿到 `fq.mid = nil` ⇒ 管家不认人。
        if isinstance(role.get('Homeland'), dict):
            _norm_homeland(role['Homeland'])
            _fq1 = role['Homeland'].get('fq')
            if isinstance(_fq1, dict):
                log('★ 家园房契下发：fqId=%s mid=%s dpId=%s status=%s roomnum=%s'
                    % (_fq1.get('fqId'), _fq1.get('mid'), _fq1.get('dpId'),
                       _fq1.get('status'), role['Homeland'].get('roomnum')))
        # ★★ 2026-10-03 老板：**关卡全解锁** —— 客户在 itype=5 的旧版本上买过卷，
        #   解锁标记（m_volume）当时从没写进存档；新版只在"再次购买"时才写。
        #   直接在角色下发时把 m_volume 设成 volume_1..8 全开（客户端收到后随存档
        #   持久化，旧档照用），不再依赖"重新买一遍"。
        role['m_volume'] = {'volume_%d' % i: True for i in range(1, 9)}
        log('★ 关卡全解锁：m_volume volume_1..8 = true（随角色下发）')
        # ★ 经脉 / 玄络印记：修掉老版本写歪的结构（否则经脉面板会报错、丹药"没效果"）
        _norm_meridian(role)
        log('★ 经脉/天赋字段随存档回写：%s'
            % [k for k in ('meridian', 'hiddenMeridianData', 'PrepareTalent', 'DreamTalent')
               if k in src])
        # ★★ 2026-10-17 轮回修仙决回归（v154）：重建模拟器实例后客户端把**传功丹武学**丢了
        #   ——当前档 skills 里恰好只剩 wudushengong 整键消失、activeZhaos 缺轮回 5 招
        #   （其余 27 门都在）。客户端新档上传覆盖服务端档 ⇒ 光修存档文件，下次登录又丢。
        #   这里每次下发前**只补缺失**（键已存在的一概不动，幂等自愈）；
        #   数据来自老板真档 save_now2（2026-10-16 备份）。
        try:
            _sk = role.get('skills')
            if not isinstance(_sk, dict):
                _sk = {}
                role['skills'] = _sk
            _canon_sk = {'wudushengong': {'exp': 3240001, 'id': 'wudushengong'}}
            for _k, _v in _canon_sk.items():
                if not isinstance(_sk.get(_k), dict):
                    _sk[_k] = dict(_v)
            _az = role.get('activeZhaos')
            if not isinstance(_az, dict):
                _az = {}
                role['activeZhaos'] = _az
            _canon_az = {'dumentaishou': {'exp': 999999999, 'id': 'dumentaishou'},
                         'bixuejian': {'exp': 999999999, 'id': 'bixuejian'},
                         'dulangjun': {'exp': 999999999, 'id': 'dulangjun'},
                         'qianhuanshenjue': {'exp': 999999999, 'id': 'qianhuanshenjue'},
                         'canglongzhaxian': {'exp': 999999999, 'id': 'canglongzhaxian'}}
            _az_filled = []
            for _k, _v in _canon_az.items():
                if not isinstance(_az.get(_k), dict):
                    _az[_k] = dict(_v)
                    _az_filled.append(_k)
            log('★ 轮回修仙决回填：skills.wudushengong、activeZhaos+%s'
                % (_az_filled or '无缺'))
        except Exception as _e:
            log('轮回修仙决回填失败（忽略）：%s' % _e)
    except Exception as e:
        log('先天属性回写失败（忽略，照原样下发）: %s' % e)
    return role


def save_download(headers):
    """`download_user_file_2`

    契约（`StartGameLayer.lua:172-224`）：`errcode==0` 时它把 `data` 当**密文**再解一层，
    解出来必须是 JSON **数组**、`[1]` 是角色存档；`errcode!=0` 则置 `isReset="Y"` 去建号。

    ★ `--role ours` 时下发**我们自己的角色档**（`work/roles/full.json`，功能全开）：
      这样客户端读到的是我们的角色，主界面功能区按她的条件全部显示。
    """
    # ★★ 2026-10-04 传承闭环（E2E 实测补上的最后一环）★★
    #   传承成功（finishNextRoleTask）后，原版语义 = 账号的存档被换成**继承人档**，
    #   重启后玩家接档继续玩。以前这里只把继承人档存在 inherit_skin_state 的 nextRole
    #   里、建号下发时仍然给老档 ⇒ 重启后变成种子号（老板实测："传承人叫噜噜，但是
    #   这个不是"）。现在：download 时若 nextRole 有继承人档 ⇒ **一次性下发**（带
    #   inheritCount 计次、身份隔离），发完即清。
    try:
        _st_p = os.path.join(HERE, 'inherit_skin_state.json')
        if os.path.exists(_st_p):
            with open(_st_p, encoding='utf-8') as _f:
                _st = json.load(_f)
            _pl = (_st.get('players') or {})
            _pk = next(iter(_pl)) if _pl else None      # 单机单玩家
            _nr = (_pl.get(_pk) or {}).get('nextRole') if _pk else None
            _heir = None
            if isinstance(_nr, dict):
                _rd = _nr.get('roleData')
                if isinstance(_rd, list) and _rd and isinstance(_rd[0], dict):
                    _heir = dict(_rd[0])     # 客户端上行 roleData={roleData} 多包的一层
                elif isinstance(_rd, dict):
                    _heir = dict(_rd)
            if _heir is not None:
                _cnt = int(_pl.get(_pk, {}).get('inheritCount') or 1)
                _heir['inheritCount'] = _cnt            # 计次回填（700/800...级门槛与历代前辈都读它）
                _heir['userid'] = PRIVATE_USERID        # 身份隔离
                _heir['accountId'] = PRIVATE_USERID
                _st['players'][_pk]['nextRole'] = None   # 一次性，发完即清
                with open(_st_p, 'w', encoding='utf-8') as _f:
                    json.dump(_st, _f, ensure_ascii=False)
                _second = {}
                try:                                    # 老存档第二个元素（jingMaxRecord 等）原样带上
                    with open(_canonical_save_path(), encoding='utf-8') as _f:
                        _old = json.load(_f)
                    if isinstance(_old, list) and len(_old) > 1 and isinstance(_old[1], dict):
                        _second = _old[1]
                except Exception:
                    pass
                _arr = json.dumps([_heir, _second], ensure_ascii=False).encode('utf-8')
                fzc.KNOWN[b'FZJH03'] = {'key': SESSION['key'], 'iv': b'PcIQIZifRalhZ88n'}
                log('★ 传承接档：下发继承人《%s》(sex=%s, inheritCount=%s)，nextRole 已清'
                    % (_heir.get('name'), _heir.get('sex'), _cnt))
                return {'errcode': 0, 'data': fzc.encrypt(_arr, b'FZJH03').decode('ascii'),
                        'rand_t': time.time()}
    except Exception as _e:
        log('传承接档下发失败（按原流程走）：%s' % _e)

    if ROLE_MODE == 'ours':
        p = os.path.join(ROLE_DIR, 'full.json')
        _save_role = None
        # ★★ 2026-10-01 关键修复：「玩了一会重启就没了」= 我们只发模板、没发玩家存档。
        #   现在：**存档为准**（进度是玩家的），模板只**补缺失的键**（功能全开的开关来自模板）。
        try:
            # ★★ 2026-10-01：读**本机唯一存档位**（与 `save_upload` 同一个文件）。
            _sp = _canonical_save_path()
            if not os.path.exists(_sp):
                _uuid = headers.get('uuid') or 'nouuid'
                _uid = headers.get('userid') or '0'
                _alt = os.path.join(SAVE_DIR, hashlib.md5(
                    ('%s|%s' % (_uuid, _uid)).encode()).hexdigest()[:16] + '.json')
                if os.path.exists(_alt):
                    _sp = _alt
            if os.path.exists(_sp):
                with open(_sp, 'r', encoding='utf-8') as f:
                    _j = json.load(f)
                _save_role = _j[0] if isinstance(_j, list) and _j else _j
                if isinstance(_save_role, dict):
                    log('★ 下发角色：以玩家存档为准（%s，%d 个键）'
                        % (os.path.basename(_sp), len(_save_role)))
        except Exception as _e:                                       # noqa: BLE001
            log('读玩家存档失败（退回纯模板）：%s' % _e)
        if os.path.exists(p):
            with open(p, 'r', encoding='utf-8') as f:
                role = json.load(f)
            if isinstance(_save_role, dict):
                _saved_keys = len(_save_role)
                _new = dict(role)
                _new.update(_save_role)        # 存档优先；模板里的键存档没有的仍保留
                role = _new
                log('★ 合并完成：模板 + 玩家存档（存档 %d 键，合并后 %d 键）'
                    % (_saved_keys, len(role)))
            # ★ 下发时替换成私服身份（不写回文件）——官方 userid/accountId 不再出现在客户端
            if role.get('userid') not in (None, PRIVATE_USERID):
                log('★ 身份隔离：下发角色档时把 userid %s -> %s（官方号不外出）'
                    % (role.get('userid'), PRIVATE_USERID))
            role['userid'] = PRIVATE_USERID
            role['accountId'] = PRIVATE_USERID
            role = _overlay_persisted_attrs(role)
            # [M1-v156 2026-10-18] MUD 成长回写并入江湖档（账本取走即清，双向不丢）：
            # MUD 侧 combat_exp/potential 增量经钱庄桥记入 mud_grow.json，这里在下发前
            # 取走并入 exp/pot —— 两世界一个数字（设计文档 M1 实施清单第 1 步）。
            try:
                from fz_api.bridge_bank import take_grow
                _ge, _gp = take_grow(HERE)
                if _ge > 0 or _gp > 0:
                    role['exp'] = int(role.get('exp') or 0) + _ge
                    role['pot'] = int(role.get('pot') or 0) + _gp
                    log('★ MUD 成长回写并入: exp+%d pot+%d (现在 exp=%s pot=%s)'
                        % (_ge, _gp, role.get('exp'), role.get('pot')))
            except Exception as _e:
                log('MUD 成长回写并入失败（忽略）: %s' % _e)
            arr = json.dumps([role], ensure_ascii=False).encode('utf-8')
            fzc.KNOWN[b'FZJH03'] = {'key': SESSION['key'], 'iv': b'PcIQIZifRalhZ88n'}
            log('★ 下发我们自己的角色档 roles/full.json（lv=%s）' % role.get('lv'))
            return {'errcode': 0, 'data': fzc.encrypt(arr, b'FZJH03').decode('ascii'),
                    'rand_t': time.time()}
        log('★ --role ours 但找不到 roles/full.json，回退到客户端上传的存档')

    uuid = headers.get('uuid') or 'nouuid'
    userid = headers.get('userid') or '0'
    key = hashlib.md5(('%s|%s' % (uuid, userid)).encode()).hexdigest()[:16]
    p = os.path.join(SAVE_DIR, key + '.json')
    if not os.path.exists(p):
        return {'errcode': 1, 'errmsg': 'no save', 'rand_t': time.time()}
    with open(p, 'r', encoding='utf-8') as f:
        plain = f.read().encode('utf-8')
    # ★★ 2026-10-03 单机版走的就是这条回退路（--danji 净化掉了 roles/full.json，
    #   `--role ours` 找不到模板 ⇒ 直接回客户端自己上传的存档）——
    #   所以「关卡全解锁」必须**也**在这条路上注入，否则单机版永远不生效：
    #   解出存档（数组 [role] 或对象都兼容）→ m_volume 全开 → 按原形状回写。
    try:
        _j = json.loads(plain)
        if isinstance(_j, list) and _j and isinstance(_j[0], dict):
            _j[0]['m_volume'] = {'volume_%d' % i: True for i in range(1, 9)}
            plain = json.dumps(_j, ensure_ascii=False).encode('utf-8')
            log('★ 关卡全解锁（回退路径）：m_volume volume_1..8 = true')
        elif isinstance(_j, dict):
            _j['m_volume'] = {'volume_%d' % i: True for i in range(1, 9)}
            plain = json.dumps(_j, ensure_ascii=False).encode('utf-8')
            log('★ 关卡全解锁（回退路径）：m_volume volume_1..8 = true')
    except Exception as _e:
        log('关卡全解锁注入失败（按原样下发）: %s' % _e)
    fzc.KNOWN[b'FZJH03'] = {'key': SESSION['key'], 'iv': b'PcIQIZifRalhZ88n'}
    return {'errcode': 0, 'data': fzc.encrypt(plain, b'FZJH03').decode('ascii'),
            'rand_t': time.time()}


def next_dataver():
    """★ 她 `ServerActionSystem:setDataVersion` 要求数字：

        dataVersion = tonumber(dataVersion)
        if type(dataVersion) ~= "number" then error("dataVersion must be number but get:...") end

    凡是走 `__saveAction(data.dataVer, ...)` 的接口（`createFistInfo`、`getFistFootInFo` …），
    应答里**必须**带 `data.dataVer`；否则它 `error()` 打断协程 ⇒ 界面卡死、也不弹错误框
    （本轮就是这么冻住的，logcat：`error:dataVersion must be number but get:nil`）。
    """
    SESSION['dataver'] = SESSION.get('dataver', 1) + 1
    return SESSION['dataver']


def dynamic_answer(path, headers=None, body=b''):
    """返回 (bytes, 说明) 或 None（None = 不接管）

    ★ 注意：不接管时**必须返回 None**，不能返回 (None, '')——否则调用方会
      拿着 None 去 len()，处理线程抛异常、连接被关，客户端只看到 responseCode=0
      （表现就是"网络错误，请重试"）。这个坑本轮踩过一次。
    """
    headers = headers or {}
    if path.endswith('/api/service/exchange_publickey'):
        return answer_exchange_publickey(), '我们发放会话密钥'
    if path.endswith('/api/service_android/get_uuid'):
        return None                       # 还没接：交给转发
    if path.endswith('/v1/checkUpdate'):
        # 官方对我们也回 {"errcode":1,"errmsg":"opps"}，客户端照样往下走；先照抄
        return enc_jhhu02({'errcode': 1, 'errmsg': 'opps'}), 'checkUpdate（照抄官方语义）'
    if path.endswith('/v1/getMd5List'):
        tpl = load_template('v1_getMd5List')
        if tpl is None:
            return None
        return enc_jhhu02(tpl), 'md5 清单（官方内容，我们用 JHHU02 重新加密）'
    if path.endswith('/v1/updateFileList'):
        # ★ 2026-10-02：官方对这道题的应答逐字节抓包解密就是 {"errcode":1,"errmsg":"opps"}
        #   （work/boot_log.txt 13:50:26 官方转发抓包），客户端收到即走登录流程。
        #   没实现 = 404 → C++ 重试循环，卡「版本更新中(404:-1)」/「文件损坏」。
        return enc_jhhu02({'errcode': 1, 'errmsg': 'opps'}), 'updateFileList（照抄官方抓包）'
    # ------------------------------------------------------------------
    # ★★ 功能模块路由（`work/fz_api/*.py`）—— **放在最前面**，模块优先于下面这些旧的浅实现。
    #   1:1 还原有 500+ 接口，全塞这个文件里没法推进；一个功能一个模块，
    #   每个模块自带契约注释 + 从她自己的资源表取内容。
    #   （`fz_api.RESERVED` 里的启动关键接口不会被模块抢走。）
    # ------------------------------------------------------------------
    if path.startswith('/api/v5/'):
        try:
            import fz_api
            _ctx = fz_api.Ctx(path, headers, body, {
                'enc_session': enc_session, 'decode_body': _decode_client_body,
                'next_dataver': next_dataver, 'log': log, 'here': HERE,
                # ★ 2026-10-01：家园那几个"不带 mid"的接口（process_affair /
                #   process_pay_affairs / restore_user_map…）要靠它找回**玩家真正的家**，
                #   否则一律落到 '0' 号房 ⇒ 事务找不到（老板："缴纳地税说没有这项事务"）。
                'home_mid': _sticky_home_mid,
            })
            _r = fz_api.dispatch(_ctx)
            if _r is not None:
                return _r
        except Exception as _e:                     # noqa: BLE001
            log('[api] 路由异常：%s' % _e)

    if path.endswith('/api/v5/create_account'):
        return enc_session(create_account_stub(headers)), '★ 我们自己的建号应答'
    if '/api/v5/upload_user_file_' in path:
        return enc_session(save_upload(headers, body)), '★ 存档上传（我们收下并存盘）'
    if path.endswith('/api/v5/download_user_file_2'):
        return enc_session(save_download(headers)), '★ 存档下载（我们自己的存档库）'
    if path.endswith('/api/v5/get_game_user_info_2'):
        # ★★ 这是**登录数据总契约**：`ControllLayer:startGame()` → `Account:getGameUserInfo`
        #    → `initUserDataFromWeb(data)`（`ControllLayer.lua:2487-2740`）。
        #    它读的字段（全部实测确认）：idauth / account / role / notice / is_cheat /
        #    **jiayuantch** / **hometch** / task / selfCreateSkill / redDot /
        #    bag_level / warehouse_level / arsenal_level / weaponhold_level /
        #    usedUiId / flag_4399 / isWhiteList / transferSign / mcmrestrictId /
        #    meridianTalentPage / challengeMapCompleted
        #    ★ account 里客户端读：guanqialimit（m_volume 同步）/ cid（accountId）/
        #      **createTime（角色创建时间，平安小镇 24h 门槛；2026-10-13 起必须下发，
        #      见下方 _acct_create_time 的注释）**。
        #
        # ★★ 其中两条是**家园系统的生死开关**（`ControllLayer.lua:2633-2648`）：
        #       if data.jiayuantch == true then JIAYUAN_SYSTEM_IS_OPEN = true
        #       else                            JIAYUAN_SYSTEM_IS_OPEN = false end
        #       if data.hometch.switchs == 1 then role:setInheritFlag("家园引导", 2) end
        #    我们以前没给 `jiayuantch` ⇒ 每次登录都把家园**关掉**，
        #    于是点购房 NPC 得到 `HomelandUtil:sysIsOpen()` 的「该系统暂未开放。」
        #    （老板遇到的正是这个 —— 不是引导没做，是开关被我们关了。）
        #    而 `hometch.switchs=1` 会把 `家园引导` 直接补成 2（所以那个标记老是变回 2）。
        #
        # ★ `usedUiId`：换主界面皮肤（`HouseSkin:setSkinId`），
        #   取值 `default` / `uijiemian1..6`（`res/script/skin/UISkinlistConfig.lua`）。
        # ★★ 2026-10-04 方案二（老板定）：家园引导**动态化**——按玩家档里的
        #   「家园引导」可传承标记决定：引导未完成（<2）⇒ switchs=0（**不补标记**）
        #   ⇒ 尤三在通泗门出现、可走完整引导；引导完成（≥2）⇒ switchs=1 ⇒ 引导标记
        #   补齐、家园直接开放。以前写死 switchs=1 ⇒ 每次登录强制把引导补成 2
        #   ⇒ 尤三永远不刷（客户与老板"找不到尤三"的最终根因）。
        #   ★ 2026-10-13 修订（客户反馈：引导半路点购房弹「该系统暂未开放」）：
        #   `jiayuantch`（系统开关）**回官方语义=常开**（Definition.lua:104 默认 true）——
        #   原来捆着引导标记（<2⇒false）反而把"该弹的指路提示"挡死（详见下方返回值注释）。
        #   尤三出现只依赖标记+switchs，与开关无关。
        _jy_flag = 0
        _jy_reset = 0
        _acct_create_time = 0
        try:
            _sp = _canonical_save_path()
            if os.path.exists(_sp):
                with open(_sp, encoding='utf-8') as _f:
                    _sj = json.load(_f)
                _sr = _sj[0] if isinstance(_sj, list) and _sj else _sj
                _jy_flag = int(float((_sr.get('_inherit_flags') or {}).get('家园引导') or 0))
                # ★★ 2026-10-13 平安小镇门槛修复：账号创建时间（`account.createTime`）。
                #   客户端契约（`ControllLayer.lua:2568`）：**每次登录**把
                #   `data.account.createTime`（必须是 number）写进角色属性；
                #   而它唯一的自愈兜底（`Role.lua:823 self:setAttr("createTime", ...)`）
                #   **被官方注释掉了** ⇒ 服务端不下发 = 角色永远没有 createTime。
                #   缺 createTime 的后果（`PingAnTown.lua:18/45` 的进入前检查）：
                #   `getDef(nil→GetTime)` ⇒ 差值 0 < 24h ⇒ 永远弹
                #   「角色创建一天之后，方可进入平安小镇」（客户报的正是它）。
                #   取值：存档里有合法值（数字、0<ct≤now+1天）就用；没有就按
                #   "30 天前"回填 —— 苗子档（本包自带）本来就带老 createTime，
                #   老客户档缺字段的自此一次性放行（真扣真发的动作都在客户端，
                #   这里只修"账号年龄"这一个门槛）。
                try:
                    _ct = float(_sr.get('createTime') or 0)
                except (TypeError, ValueError):
                    _ct = 0
                if 0 < _ct <= time.time() + 86400:
                    _acct_create_time = int(_ct)
        except Exception as _e:
            log('[家园] 读引导标记失败（按 0）：%s' % _e)
        if _acct_create_time <= 0:
            _acct_create_time = int(time.time()) - 30 * 86400
            log('★ 账号创建时间回填：%s（存档缺 createTime，按 30 天前下发）'
                % time.strftime('%Y-%m-%d', time.localtime(_acct_create_time)))
        # 账号 cid（`accountId`）：官方语义=账号号；取请求头 userid（数字），拿不到就用固定号。
        try:
            _acct_cid = int(float(headers.get('userid') or PRIVATE_USERID))
        except (TypeError, ValueError):
            _acct_cid = PRIVATE_USERID
        _jy_done = _jy_flag >= 2
        # ★★ 2026-10-04 家园引导一次性清洗（老板要求：让老玩家也能体验尤三剧情）★★
        #   老客户档里的「家园引导=2」全是当年测试写进去的（种子档遗留），玩家本人
        #   从没走过尤三引导 ⇒ 对"标记已完成"的账号下发一次 reset=1（客户端把标记
        #   归零 ⇒ 尤三重新出现 ⇒ 引导走完标记自然回 ≥2 ⇒ 下次登录按已完成放行）。
        #   每账号只发一次（本账本记账），不会反复重置。
        if _jy_done:
            try:
                _rz_p = os.path.join(HERE, 'jy_reset_state.json')
                _rz = {}
                if os.path.exists(_rz_p):
                    with open(_rz_p, encoding='utf-8') as _f:
                        _rz = json.load(_f)
                _rz_uid = str(headers.get('userid') or PRIVATE_USERID)
                if not _rz.get(_rz_uid):
                    _jy_reset = 1
                    _rz[_rz_uid] = int(time.time())
                    with open(_rz_p, 'w', encoding='utf-8') as _f:
                        json.dump(_rz, _f, ensure_ascii=False)
                    log('[家园] 引导清洗：下发 reset=1（userid=%s，标记 %d→0，尤三将重新出现）'
                        % (_rz_uid, _jy_flag))
            except Exception as _e:
                log('[家园] 引导清洗记账失败（不发 reset）：%s' % _e)
        return enc_session({'errcode': 0, 'data': {
            # ★★ 2026-10-13：`account` 不能再给空表——客户端见非空表后整段处理
            #   （`ControllLayer.lua:2534-2574`）：`guanqialimit`（卷解锁态，给空表=
            #   不改动 m_volume）/`cid`/`createTime`（平安小镇门槛，见上方回填逻辑）。
            #   createTime 必须是 **number**——`Helper:getDef` 按类型兜底，给字符串
            #   会被当成 nil 落回 GetTime()，等于没发。
            'account': {'createTime': _acct_create_time,
                        'guanqialimit': {},
                        'cid': _acct_cid}, 'role': {},
            'usedUiId': OUR_SKIN,
            # ★★ 2026-10-13（客户反馈：传承后找杨掮客购房弹「该系统暂未开放」）：
            #   `jiayuantch` 回**官方语义=常开**（`Definition.lua:104` 默认就是 true）。
            #   原方案二把它跟引导标记捆死（<2 ⇒ false），副作用两头都坏：
            #   ①客户在引导半路点购房/家园功能，被 `HomelandUtil:sysIsOpen` 第一关
            #     弹死胡同式的「该系统暂未开放。」——**原本该弹第二关的**
            #     「需在扬州尤三处完成家园引导方可使用该功能」（明确指路）；
            #   ②家园相关 NPC/入口在引导期间全被这层假门挡住。
            #   ★尤三照常出现不受影响：出没条件是「家园引导」标记本身
            #   （`con_jiayuanyindao1/xy2` 标记<2）+ 下面的 `switchs=0`（不补标记），
            #   跟本开关无关。引导中真正的门都在标记上（sysIsOpen 第二关/管家阻拦）。
            'jiayuantch': True,
            'hometch': {'switchs': 1 if _jy_done else 0,   # ★ 引导中不发补 2（尤三才会出现）
                        'reset': _jy_reset},    # ★ 一次性清洗指令
            'is_cheat': False},
            # ⚠️ 别的字段**不要乱加**：`bag_level/warehouse_level/arsenal_level/weaponhold_level`
            #    给 0 会让她 `Bag:__getBagSpaceByLevel` 找不到 0 级配置直接 `error()`
            #    （实测报 "bagUpgrade 配置表中未找到当前仓库等级对应仓库空间，仓库等级：0"），
            #    登录回调被 xpcall 吞掉 ⇒ 界面弹「网络错误, 请重试」。
            #    `challengeMapCompleted: []` 也会把她的挑战副本通关记录清空。
            'rand_t': time.time()}), '★ 账号信息（皮肤=%s，家园引导=%d/开关常开，reset=%d）' % (OUR_SKIN, _jy_flag, _jy_reset)
    if path.endswith('/api/v5/get_ui_theme_list'):
        # 换肤界面用的皮肤列表（`ChangeHouseSkin.lua:145-168` / `SkinThemeView:__init`）
        # 字段名照 `SkinThemeView:__init(info)` 抄：id/uiId/uiName/rarity/price/button/buttonbg/isBuy/buyTime/endTime/canBuy/type
        # ★★ 2026-09-28 修「苍黄翻复」bug：
        #   原来 `usedUiId` 写死成常量 `OUR_SKIN` ⇒ 点了「使用」之后**"使用中…"标记永不移动**，
        #   而且 `use_ui_theme` 在 `fz_api/inherit_skin.py` 里查的是另一份账（`uiThemes`，实测空）
        #   ⇒ 列表说"你有"、使用说"你没有"（老板报的「尚未拥有该皮肤」）。
        #   现在：`usedUiId` / `isBuy` **都读玩家真账** `work/inherit_skin_state.json`，
        #   与 `use_ui_theme` / `buy_ui_theme` 同源。**两处要改就一起改。**
        _skins_state = None
        try:
            with open(os.path.join(HERE, 'inherit_skin_state.json'), encoding='utf-8') as _f:
                _skins_state = json.load(_f)
        except Exception:                            # noqa: BLE001
            _skins_state = None
        _uid = str(headers.get('userid') or headers.get('uuid') or 'default')
        _sp = {}
        if isinstance(_skins_state, dict):
            _players = _skins_state.get('players')
            if isinstance(_players, dict):
                _sp = _players.get(_uid) or _players.get('default') or {}
        if not isinstance(_sp, dict):
            _sp = {}
        _owned = [str(x) for x in (_sp.get('uiThemes') or []) if x]
        _used = str(_sp.get('usedUiId') or 'default') or 'default'
        lst = [{'id': 0, 'uiId': 'default', 'uiName': '默认界面', 'rarity': 1, 'price': 0,
                'button': '', 'buttonbg': '', 'isBuy': 1, 'buyTime': 0, 'endTime': 0,
                'canBuy': 0, 'type': 3}]
        for i in range(1, 7):
            _uiid = 'uijiemian%d' % i
            lst.append({'id': i, 'uiId': _uiid, 'uiName': '界面皮肤 %d' % i,
                        'rarity': i, 'price': 0,
                        'button': 'Image/UI/SkinUI/Skin_%d/mainBg.png' % i,
                        'buttonbg': 'Image/UI/SkinUI/Skin_%d/mainBg.png' % i,
                        # ★ 开发服档位：**全解锁**（isBuy 恒 1）。
                        #   与 `fz_api/inherit_skin.py` 的 `_skin_is_unlocked()` 同口径 —— 一起改。
                        'isBuy': 1,
                        'buyTime': 0, 'endTime': 0, 'canBuy': 0, 'type': 1})
        return enc_session({'errcode': 0, 'data': {'canghuangling': 999999,
                                                   'usedUiId': _used, 'list': lst},
                            'rand_t': time.time()}), \
            '★ 皮肤列表（7 套；使用中=%s，已购 %d 套；读 inherit_skin_state.json 真账）' \
            % (_used, len(_owned))
    if path.endswith('/api/v5/get_time'):
        now = time.time()
        return enc_session({'errcode': 0, 'data': {'time': int(now)}, 'rand_t': now}), '我们自己的时间'
    if path.endswith('/api/v5/get_token'):
        tok = binascii.hexlify(os.urandom(16)).decode('ascii')
        SESSION['token'] = tok
        save_session_token(tok)
        return enc_session({'errcode': 0, 'data': {'token': tok}, 'rand_t': time.time()}), '我们自己的 token'
    if path.endswith('/api/v5/get_partition_list2'):
        return enc_session(our_partitions()), '★ 我们自己的分区列表'
    if path.endswith('/api/v5/getWebConfig'):
        tpl = load_template('api_v5_getWebConfig')
        if tpl is None:
            return None
        tpl['rand_t'] = time.time()
        # ★ `Game:isCheckNewPackage()` 读的是本配置里的 `PackageChecklist[渠道][版本]`：
        #     本体里没有 "guanfang" 这个渠道 ⇒ `MapIsEmpty(...)` 为真 ⇒ 返回 NOT_NEED_CHECK
        #     ⇒ 排行等界面走"必须绑定邮箱"的分支（`MainLayer` 排行那段）。
        #   补上我们自己的渠道/版本为 true ⇒ 返回 NEED_CHECK_AND_IS_OPEN ⇒ 免绑邮箱即可打开。
        try:
            d = tpl.setdefault('data', {})
            pc = d.setdefault('PackageChecklist', {})
            pc.setdefault('guanfang', {})['2.1.02'] = True
        except Exception:                               # noqa: BLE001
            pass
        return enc_session(tpl), 'getWebConfig（官方内容模板 + 我们的会话密钥 + 渠道开关）'
    if path.endswith('/api/v5/getLianGongState') or path.endswith('/api/v5/getXiuLianState'):
        # `ServerActionSystem.lua`：`getXxxState` 读 `data.state`，客户端再判 `state == 1`
        return enc_session({'errcode': 0, 'data': {'state': 0}, 'rand_t': time.time()}), \
            '状态=0（练功/修行都没开）'
    if path.endswith('/api/v5/getLianGongData') or path.endswith('/api/v5/getXiuLianData'):
        # 同一族的 `getXxxData`：errcode==1 它当成"没有数据"
        # ★ 不能回 errcode=0 + 空 data —— 它会去索引 data.startAction ⇒ nil 报错 ⇒ 弹网络错误
        return enc_session({'errcode': 1, 'errmsg': 'no action', 'rand_t': time.time()}), \
            '数据=无（errcode=1）'
    if path.endswith('/api/v5/report_cheat'):
        return enc_session({'errcode': 0, 'rand_t': time.time()}), 'report_cheat ok'
    if path.endswith('/api/v5/get_user_designation'):
        # `MainLayer:checkIsHaveOfficial` → `getChenHao` 走这个接口；
        # 它直接读 `data.exam.guanzhi` / `data.exam.zhengji`（缺了会 error，主界面按钮就挂不上监听）
        return enc_session({'errcode': 0, 'data': {
            'exam': {'guanzhi': 0, 'zhengji': 0},
            'jiaren': {'is_list': 0},
        }, 'rand_t': time.time()}), '★ 官职/称号（带 exam）'
    if path.endswith('/api/v5/get_user_prestige'):
        # `FamilyPrestige.lua:70` 用 `prestigeData.total`（数字）去跟配置比大小；
        # 少了它就会 `attempt to compare nil with number`，主界面初始化被打断。
        return enc_session({'errcode': 0, 'data': {
            'total': 0, 'prestige': 0, 'weiwang': 0, 'menpai': '', 'rank': 0, 'list': [],
        }, 'rand_t': time.time()}), '★ 门派威望（带 total）'
    if path.endswith('/api/v5/get_config_fuben'):
        # `SelectMapModel:entryMap`（:182-202）：
        #     if status==200 and errcode==0 then
        #         if data.status == 1 then self:_enterMap(mapId) else PopText("此章节暂未开放，敬请期待") end
        # ⇒ 只要 `data.status = 1` 就让进图；地图本体数据来自她**本地表**（Map:getMapById）。
        return enc_session({'errcode': 0, 'data': {'status': 1, 'dataVer': next_dataver()},
                            'rand_t': time.time()}), '★ 副本配置（status=1＝已开放）'
    if path.endswith('/api/v5/get_rank_list_4'):
        # ★ 契约来自她自己的源码：`RankingUI.lua:1077 getTestData()` 内嵌的样例 JSON
        #   （她就是拿这份数据做自测的，结构=权威）。
        #   形状：`data` 是**数组**，每项 {title, type, header[], body={list[], mine={}}}。
        #   `RankingUI:initAndSaveData`（:986）用 `for j,list in pairs(webData)` 遍历，
        #   逐项读 `list.title` ⇒ `data` 回成对象（{title=..,list=..}）会直接
        #   `attempt to index local 'list' (a number value)`（本轮踩到）。
        tpl = load_template('api_v5_get_rank_list_4')
        if tpl is None:
            return None
        # ★ 每块榜还必须带 `nums` / `total_nums` / `total_page` / `board_type`：
        #   `initAndSaveData`（:998）会算 `(webPage-1)*list.nums + i`，
        #   少了 nums 直接 `attempt to perform arithmetic on field 'nums'`（踩到）。
        boards = []
        for b in (tpl.get('data') or []):
            b = dict(b)
            lst = ((b.get('body') or {}).get('list')) or []
            b.setdefault('board_type', 1)
            b['total_nums'] = len(lst)
            b['total_page'] = 1
            b['nums'] = len(lst)
            boards.append(b)
        return enc_session({'errcode': 0, 'data': boards,
                            'rand_t': time.time()}), '★ 排行榜总表（她自带的样例数据+页码字段）'
    if '/api/v5/get_board/' in path:
        # 单榜翻页：`RankingUI:getRankDataWithPage` 只要 body.list + 页码元数据
        return enc_session({'errcode': 0, 'data': {'title': '排行榜', 'type': 'total_board',
                                                   'header': ['名次', '昵称', '武学造诣'],
                                                   'total_nums': 0, 'board_type': 1,
                                                   'total_page': 1, 'nums': 0,
                                                   'body': {'list': [], 'mine': {}},
                                                   'dataVer': next_dataver()},
                            'rand_t': time.time()}), '★ 单榜翻页（空榜，结构正确）'
    if path.endswith('/api/v5/get_user_anecdote'):
        # 「江湖轶闻」进度：`JiangHuAnecdotePresenter:showLayer`（:25-33）
        #   标题栏拼 `"『轶闻』"..data.number.."/"..data.max_number`
        #   ★ 少了这两个字段标题就是「『轶闻』nil/nil」
        return enc_session({'errcode': 0, 'data': {'number': 0, 'max_number': 5,
                                                   'dataVer': next_dataver()},
                            'rand_t': time.time()}), '★ 江湖轶闻进度（0/5）'
    if path.endswith('/api/v5/challengemap_unfinished'):
        # 「江湖轶闻」入口：`SelectMapMenuPresenter:setButtonNewMap`（:42）→
        #   `ChallengeMapSystem:isChallengeMapReconnection` → GET challengemap_unfinished
        #   回调拿 `arg.status`：0=可以进 / 1=上次没打完（问是否继续）/ 2=超时
        #   ★ 少了 `status` 会走到 `error("非法状态" .. status)`（nil 拼接直接报错）
        return enc_session({'errcode': 0, 'data': {'status': 0, 'dataVer': next_dataver()},
                            'rand_t': time.time()}), '★ 江湖轶闻·未完成副本检查（status=0 可进）'
    if path.endswith('/api/v5/get_house_store_list'):
        # 购房列表：`BuyHouseLayer:refreshList`（:264 起）
        #   读 data.list（房型数组）/ data.isBuy / data.point（银票）/ data.removeYb / data.costYb
        #   每个房型至少要有 fqId / name / typedsc / cost（`getFangQi` + `getFangQiTemplateById`）
        # ★ 必须放在下面的 `get_store_list_4` **之前**：
        #   之前我用 `'store_list' in path` 一把抓，把 `get_house_store_list` 也
        #   劫持成了商城的货架数据 ⇒ 她拿到错结构直接弹「网络错误, 请重试」（老板遇到的）。
        _houses = [{'fqId': 'yangzhou001', 'name': '普通房屋', 'cost': 1500, 'roomnum': 5,
                    'typedsc': '这是一间普通的房屋，空间十分狭小，仅有一个卧室、仓库。'},
                   {'fqId': 'yangzhou002', 'name': '简屋(壹)', 'cost': 6000, 'roomnum': 9,
                    'typedsc': '这是一座小户型的房子，内置卧室、仓库、练功房可堪一用。'},
                   {'fqId': 'yangzhou003', 'name': '秀筑(壹)', 'cost': 16000, 'roomnum': 14,
                    'typedsc': '这是一套平房民居，建造考究，颇为灵秀。'}]
        return enc_session({'errcode': 0, 'data': {'list': _houses, 'isBuy': False,
                                                   'point': 99999, 'removeYb': 0, 'costYb': 0,
                                                   'dataVer': next_dataver()},
                            # ⚠️ `isBuy` 必须是 **false / 不出现**：她写的是 `if _isBuy then`
                            #    （`BuyHouseLayer`），而 **Lua 里 0 是真** ⇒ 回 0 会弹出
                            #    「购买新的房屋将会替换你之前的房屋…确定重复购房请输入"确定"」。
                            'rand_t': time.time()}), '★ 购房列表（3 种房型）'
    if '/api/v5/get_npc_store_list' in path:
        # 背包里的「市侩」页签（游商）：`HttpManager:getNewNpcChapmanItemList`（:2265）
        #   契约先给一个"空商铺"的最小结构，别让它拿到商城的货架。
        return enc_session({'errcode': 0, 'data': {'list': [], 'items': [], 'state': 0,
                                                   'dataVer': next_dataver()},
                            'rand_t': time.time()}), '★ 市侩（游商）商品列表（空表）'
    if path.endswith('/api/v5/get_yuanbao'):
        # `StoreLayer:refreshYuanBaoNumber`（:170-181）：
        #   `self.Text_count:setString("我的元宝："..data.yuanbao)` ——
        #   **少 data.yuanbao 就 attempt to concatenate**（冷启动实测抓到，
        #   走宽容兜底只回 dataVer 不够）。同时 `User:setRoleAttr("yuanbao", ...)`。
        _yb = _purse_currency('yuanbao', 99999)
        return enc_session({'errcode': 0, 'data': {'yuanbao': _yb, 'dataVer': next_dataver()},
                            'rand_t': time.time()}), '★ 我的元宝（%d，读真钱袋）' % _yb
    if path.endswith('/api/v5/get_store_list_4'):
        # `StoreLayer:refreshStoreList`（:96-140）：
        #     list = data.list（**数组**，用 ipairs 遍历；每项 {name=..., items={...}}）
        #     User:setRoleAttr("yuanbao", data.yuanbao)；Text_count = "我的元宝："..data.yuanbao
        #     `self.goodsType` 是**数字下标**，初值 2（`StoreLayer.lua:29`），
        #     `createOneType` 里页签名表是 `{"限时","商城","关卡","神功"}`（:902）
        #     ⇒ `list[2]` 必须是"商城"那一格！只给 1 个元素 ⇒ `list[2]["items"]`
        #       直接 `attempt to index a nil value`（本轮抓到的真错）。
        #     setPanelMingShi(data.yueka_expired_time) / setButtonYaShi(data.yashi_*) / 观影堂特权
        # ★ 货架内容：用她自己的两张表 join 出来的（`work/fz_build_store_goods.py`）——
        #     `res/script/store/storeItem.lua` 的 `shangchengwupin`（名字/价格/描述）
        #     × `res/script/store/shoplist.lua`（itemId → icon）
        #   客户端 `createPanelItem` 要的字段：id / itemId / name / icon / price / number / itype
        _goods = _store_shelves()
        _limit = _goods['限时']
        # ★ 2026-09-28：原版「商城」页签是**服务端钦定的 11 件**（老板截图），
        #   不是按 `shangchengwupin` 自动筛（那样会出 9 件且对不上原版）。
        #   清单与 itype 判定见 `fz_api/shop_store.py` 的 `MALL_GOODS` / `mall_shelf_rows()`。
        try:
            import fz_api.shop_store as _shst
            _mall = _shst.mall_shelf_rows()
        except Exception as _me:                      # noqa: BLE001
            log('[商城] 取原版 11 件清单失败，回退自动筛：%s' % _me)
            _mall = _goods['商城']
        # ★ 2026-10-01 老板指示：资源礼包（武器/经脉/神兵/家园建材/图谱/炼制材料/沧浪帖）
        #   单独占「商城」这一栏，放在原版 9 件前面，免得礼包太多不好找。
        try:
            import fz_api.shop_store as _shst2
            _mall = _shst2.test_pack_shelf_rows(groups=('resource',)) + _mall
        except Exception as _re:                      # noqa: BLE001
            log('[商城] 资源礼包上架失败：%s' % _re)
        # ★ 2026-10-03 客户要求：商城里加「江湖名士 / 江湖雅士」特权兑换
        try:
            _mall = _mall + _shst2.privilege_shelf_rows()
        except Exception as _pe:                      # noqa: BLE001
            log('[商城] 特权商品上架失败：%s' % _pe)
        _stage = _goods['关卡']
        _sg = _goods['神功']
        _shelves = [{'name': '限时', 'items': _limit}, {'name': '商城', 'items': _mall},
                    {'name': '关卡', 'items': _stage}, {'name': '神功', 'items': _sg}]
        # ★ 雅士福利点：**两个名字都要给**。同一个 `webRoleData` 里，
        #   `StoreLayer.lua:133` 读下划线 `yashi_welfare_point`，
        #   而 `ControllLayer.lua:2596` 读驼峰 `yashiWelfarePoint`
        #   （`if webRoleData.yashiWelfarePoint then ... setCanExchange(>0)`）。
        #   只给一个 ⇒ 另一个是 nil ⇒ 商城/雅士面板的「可兑换」红点判断落空。
        #   值取 `misc_extra` 的雅士账本（拿不到就 0）。
        _yashi = 0
        try:
            with open(os.path.join(HERE, 'misc_extra_state.json'), encoding='utf-8') as _yf:
                _ys = json.load(_yf)
            _yashi = int((_ys.get('yashi') or {}).get('point') or 0)
        except Exception:                       # noqa: BLE001
            _yashi = 0
        _yb = _purse_currency('yuanbao', 99999)
        # ★ 2026-10-03：名士/雅士到期时间改从 shop_store 的 `privileges` 账本读
        #   （买「特权兑换」后 +30 天就体现在这里；雅士缺省仍视为已拥有——L3d 决策）
        try:
            _priv = _shst2.privilege_expired(None)
        except Exception:                             # noqa: BLE001
            _priv = {'yueka_expired_time': 0,
                     'yashi_expired_time': int(time.time()) + 30 * 86400}
        # ★★ 老板 2026-09-28 报「江湖雅士面板的『领取专属福利』点了没反应」。
        #   根因：`yashi_expired_time` 原来是**硬编码 0**，而客户端
        #   `StoreLayer.lua:783-785` 对 `expired_time <= 0` 会**抬成"现在"**：
        #       if expired_time == nil or expired_time <= 0 then expired_time = GetTime() end
        #   然后 `YaShiLayer:initState()`：
        #       YaShiTime - GetTime() = 0  ⇒  既不 > buyTimeLimit(24h) 也不 ==0
        #       ⇒ state 永远到不了 2（已领取），且 `YaShiTime ~= 0 and > GetTime()` 为假
        #       ⇒ 面板显示「未获得该身份」、领取链路走不通。
        #   雅士身份本来就是"买月卡/雅士后服务端加到期时间"，单机私服没有充值，
        #   所以这里给一个**未来到期时间**（= 视为已拥有雅士权益）。
        # （2026-10-03 起雅士到期时间由 shop_store.privileges 账本决定，见 _priv）
        return enc_session({'errcode': 0, 'data': {
            'status': 'OPEN', 'yuanbao': _yb, 'list': _shelves,
            'yueka_expired_time': _priv['yueka_expired_time'],
            'yashi_expired_time': _priv['yashi_expired_time'],
            'yashi_welfare_point': _yashi,
            'yashiWelfarePoint': _yashi,
            'privilege_expired_time': 0, 'privilege_remaining_watches': 0,
            'dataVer': next_dataver()},
            'rand_t': time.time()}), \
            '★ 商城列表（限时 %d / 商城 %d / 关卡 %d / 神功 %d，雅士点 %d，名士到期 %s，雅士到期 %s）' \
            % (len(_limit), len(_mall), len(_stage), len(_sg), _yashi,
               time.strftime('%Y-%m-%d', time.localtime(_priv['yueka_expired_time']))
               if _priv['yueka_expired_time'] > 0 else '未拥有',
               time.strftime('%Y-%m-%d', time.localtime(_priv['yashi_expired_time'])))
    if path.endswith('/api/v5/is_changed_name'):
        # ★ 她的契约（`RankingUI.lua:217-226`）：
        #       HttpManagerEx:getIsChangedName(function(status, errcode, ...)
        #           if 200 == status then
        #               if 0 == errcode then showSetNameLayer()      -- 弹"请将您的尊姓大名登记在排行榜上"
        #               else                    uploadUserData("paihang") ...
        #   ——**只看 errcode，根本不看 data.isChanged**！
        #   ⇒ 只要回 errcode=0，**每次打开排行都会弹改名框**，骰子一掷名字就变了
        #     （老板反馈的"每次登录名字都变"就是这个）。
        #   正确做法：没登记过 → errcode=0（弹框）；登记过 → errcode≠0（直接进榜）。
        registered = os.path.exists(NAME_CHANGED_FILE)
        return enc_session({'errcode': 1 if registered else 0,
                            'data': {'isChanged': 1 if registered else 0,
                                     'dataVer': next_dataver()},
                            'rand_t': time.time()}), \
            '是否改过名（已登记=%s ⇒ errcode=%d）' % (registered, 1 if registered else 0)
    if path.endswith('/api/v5/update_username'):
        # 登记排行榜名：记下"已登记"，并把她上传的名字存起来备查
        try:
            with open(NAME_CHANGED_FILE, 'w', encoding='utf-8') as f:
                f.write(repr(_decode_client_body(body))[:300])
        except OSError:
            pass
        return enc_session({'errcode': 0, 'data': {'dataVer': next_dataver()},
                            'rand_t': time.time()}), '★ 登记排行榜名字'
    if '/api/v5/get_zhenpinge_lottery_list' in path:
        # 江湖珍品阁：`app/models/Action/JiangHuZhenPinGe.lua` 读这些字段（逐个扫出来的）：
        #   act_name / act_times / lottery_times / detail_time / detail_desc / end_time /
        #   currency / exchange_currency / exchangeCurrencyCount / breakevenNum / button /
        #   buy_good / prize / reward / msg / currencyVersion / dataVer /
        #   lottery_list / exchange_list（条目读 goodsId / icon / id / num / showType / showView）
        # ★ 内容用她自己的 `res/script/activity/shoplist.lua` 抽出来的活动商品
        #   （`work/tmp_actgoods.py` → boot_templates/api_v5_activity_goods.json，2041 件）
        # ★★ 契约来自 `app/models/Action/JiangHuZhenPinGe.lua:33-77`（逐行读出来的）：
        #   currency / exchange_currency 是 **对象** {id, name, count}
        #     （:51-61 读 .id/.name/.count —— 给数字就是 attempt to index a number value）
        #   buy_good 也是 **对象** {id, itemId, name}（:63-67）
        #   button 是 **数组**，`Presenters:__initButton` 定死 `for i = 1, 2`
        #     每项读 removeCurrency / imagePath(nil 有默认) / name / times
        #   lottery_list 条目：`getShowRewards` 读 id(=**商品id**) / num / showType(==1 才展示)
        #   exchange_list 条目：`__initExchangeList` 读 goodsId(=**商品id**)；`__updateExchangeUI`
        #     读 need / exchangeCount / name / title / introText / showView(客户端自算)
        # ★★ 这里的 id 必须是 `res/script/store/shoplist.lua` Sheet1 的**键**（"100001" 这种
        #   数字串），**不是 itemId**（"mianju1180"）—— `GoodsHelper:getGoodsResClass` 用的是键，
        #   拿 itemId 过去会直接 `error(... 未找到商品信息 id : jiu106)`，面板弹不出来。
        #   （`work/tmp_zpggoods.py` 从那张表里挑的货）
        _zp = load_template('api_v5_zhenpinge_goods') or {}
        _ag = _zp.get('lottery') or []
        _ae = _zp.get('exchange') or []
        _lot = [{'id': g['id'], 'num': 1, 'showType': 1} for g in _ag[:8]]
        _exc = []
        for i, g in enumerate(_ae[:8]):
            # ★ `number`（每次兑换**到手数量**）不能少：`JiangHuZhenPinGePresenters:362`
            #   `setTextDesc_3(name, 1 * exchangeRewardInfo.number)` —— nil 就
            #   "attempt to perform arithmetic on field 'number'"，兑换弹窗弹不出来。
            _exc.append({'id': i + 1, 'goodsId': g['id'], 'num': 1, 'number': 1,
                         'need': (i + 1) * 10, 'exchangeCount': 5,
                         'name': g.get('name') or g['id'],
                         # ★ title 在 `confirmExchange`（:318）里是
                         #   `tostring(reward.title)..""..tostring(reward.name)` —— 两个都给名字
                         #   会显示成「笃志笃志」，所以 title 留空。
                         'title': '',
                         'introText': g.get('dsc') or '', 'thankText': ''})
        _cur = {'id': 'zhenpinquan1', 'name': '珍品券', 'count': 9999}
        return enc_session({'errcode': 0, 'data': {
            'act_name': '江湖珍品阁', 'act_times': 1, 'lottery_times': 0,
            'detail_time': '长期开放', 'detail_desc': ['用珍品券兑换珍稀奖励', '每日可免费抽奖一次'],
            # ★ end_time 必须是**未来的 unix 时间戳**：`Presenters:exchangeReward`（:280-285）
            #   判断 `endTime < GetTime()` 就 PopText("活动已结束，无法兑换")，给 0 直接堵死兑换。
            'end_time': int(time.time()) + 30 * 86400,
            'currency': _cur, 'exchange_currency': dict(_cur),
            'exchangeCurrencyCount': 9999, 'breakevenNum': 5,
            'button': [{'times': 1, 'removeCurrency': 50, 'name': '抽1次'},
                       {'times': 5, 'removeCurrency': 240, 'name': '抽5次'}],
            'buy_good': {'id': 1, 'itemId': 'yuanbao', 'name': '元宝'},
            'prize': [], 'reward': {}, 'msg': '',
            'lottery_list': _lot, 'exchange_list': _exc, 'dataVer': next_dataver()},
            'rand_t': time.time()}), '★ 江湖珍品阁（%d 抽奖 + %d 兑换）' % (len(_lot), len(_exc))
    if '/api/v5/do_zhenpinge_lottery' in path:
        # `JiangHuZhenPinGe:doLottery`（:242-252）：
        #   data.prize            -> 发货（GoodsHelper:fromNetworkGrantGoods，数组）
        #   data.exchange_currency-> setExchangeCurrencyCount(数字！)
        #   data.currency         -> setCurrencyCount(数字！)
        #   data.lottery_times    -> setCurrRewardTimes(数字)
        _zp = load_template('api_v5_zhenpinge_goods') or {}
        _r = (_zp.get('lottery') or [{}])[0]
        _prize = ([{'id': _r.get('id'), 'itemId': _r.get('itemId'), 'name': _r.get('name'),
                    'icon': _r.get('icon'), 'num': 1}] if _r.get('id') else [])
        return enc_session({'errcode': 0, 'data': {
            'prize': _prize, 'currency': 9949, 'exchange_currency': 9999,
            'lottery_times': 1, 'currencyVersion': 0, 'dataVer': next_dataver()},
            'rand_t': time.time()}), '★ 珍品阁抽奖（发 %s）' % (_r.get('name') if _r else '空')
    if '/api/v5/exchange_zhenpinge_goods' in path:
        # `JiangHuZhenPinGe:exchangeItem`（:278-296）：data.reward 必须是**单个对象**
        #   （`table.insert(goodsList, rewardInfo)`），另读 msg / exchangeCurrencyCount(数字)
        _zp = load_template('api_v5_zhenpinge_goods') or {}
        _r = (_zp.get('exchange') or [{}])[0]
        return enc_session({'errcode': 0, 'data': {
            'reward': {'id': _r.get('id'), 'itemId': _r.get('itemId'),
                       'name': _r.get('name'), 'icon': _r.get('icon'), 'num': 1},
            'msg': '兑换成功', 'exchangeCurrencyCount': 9999, 'currencyVersion': 0,
            'dataVer': next_dataver()}, 'rand_t': time.time()}), \
            '★ 珍品阁兑换（发 %s）' % (_r.get('name') if _r else '空')
    if path.endswith('/api/v5/get_activity_list') or '/api/v5/get_activity_list/' in path:
        # `get_activity_list/{type}`（`HttpManager:getEventList` :1198）——**红点/事件**用。
        # 它的响应被当作 `showList` 传进 `ActionLayer:afterGetList(activities, showList)`，
        # 里面读 `showList.list`（:1256 `getIsShow(action, showList.list)`）⇒ 要给 **对象带 list**。
        # ★ 真正渲染活动列表的是 `get_spring_festival_list`（见下）。
        return enc_session({'errcode': 0, 'data': {'list': [], 'dataVer': next_dataver()},
                            'rand_t': time.time()}), '★ 活动红点列表（list 空表）'
    # ★★ 活动「上架」清单 —— `name` 必须**逐字命中** `funcTab` 的键（共 **96** 个可选，
    #   用 `work/tmp_actnames.py` 可以把她那份名单全打出来）。
    #   放一个进来 = 玩家在活动面板能点进那个界面；接口没做好就点进去是空的/弹提示。
    #   下面这些的接口都已由 `fz_api/activities.py` 等服务端模块实现（内容取她自己的表）。
    #
    # ⚠️ 这一段**必须放在 `get_spring_festival_list` 那个 if 之外**：
    #   下面的 `get_spring_festival_status` 块也要用它回查 `activity_id`/`name`，
    #   而 Python 里一旦在该函数内赋值 `_all`，它就是**函数局部名** ——
    #   若状态请求先到（list 块没执行），引用它会 `UnboundLocalError`
    #   （`cannot access local variable '_all'`，实测踩到）。
    _all = [
        (1, 'signin', '签到活动', 86400, '每日 0 点刷新', '每日签到可领取奖励'),
        (2, 'growth', '大侠的成长之路', 604800, '长期开放', '完成成长目标领取奖励'),
        (3, 'sanyou', '江湖三友', 604800, '长期开放', '江湖三友，投票有礼'),
        (4, 'zhenpinge', '江湖珍品阁', 604800, '长期开放', '用珍品劵兑换珍稀奖励'),
        (5, 'duobao', '江湖夺宝', 604800, '长期开放', '珍宝玉石，一掷千金'),
        (6, 'mingwulu', '江湖名武录', 604800, '长期开放', '名武录抽奖与兑换'),
        # (7, 'mingrenlu', '江湖名人录', ...)             ← 2026-10-03 老板裁定下架
        # (8, 'cangjingge', '藏经阁', ...)                ← 2026-10-03 老板裁定下架（修了两层仍不稳，直接去掉）
        # (9, 'dicang', '地仓府库', ...)                  ← 2026-10-03 老板裁定下架（探索状态显示错乱）
        (10, 'lixian', '限时历练', 604800, '长期开放', '限时历练任务与奖励'),
        (11, 'danqingge', '丹青阁', 604800, '长期开放', '丹青妙笔，兑换珍品'),
        (12, 'daily', '每日任务', 86400, '每日 0 点刷新', '完成每日任务领取奖励'),
        # ★ 注意：「醉仙秘市」**不是醉仙楼** —— `ActionLayer.lua:1062` 把它派给
        #   `SkillResExchangePresenter`（走路去找商人，落点见 `misc_extra` 的显式映射表）。
        #   真正的喝场叫「**举杯共饮**」，见下面第 17 项。
        (13, 'zuixian', '醉仙秘市', 604800, '长期开放', '醉仙楼秘市，前往商人处兑换'),
        # (14, 'xiangnang', '香囊密阁', ...)              ← 2026-10-03 老板裁定下架
        (15, 'nianshou', '驱赶年兽', 604800, '长期开放', '合力驱赶年兽领奖励'),
        # ★ 老板 2026-09-28 问「拳脚商城在哪」⇒ 它**不在主商城**，是活动面板里的
        #   「**通武积市**」（`ActionLayer.lua:997` → `FistFootShopPresenter`）。
        #   名字已在她的 `funcTab` 与 `ManageActionByName` 里（dispatch 完整），
        #   但**从没上架** ⇒ 玩家永远看不到入口。这里补上。
        (16, 'tongwujishi', '通武积市', 604800, '长期开放', '元宝兑换固身元气与特性见解'),
        # ★★ 老板 2026-09-28 说「没找到醉仙楼」。
        #   纠正我自己上一条的错误说法：活动面板里 **`醉仙秘市` 不是醉仙楼** ——
        #   `ActionLayer.lua:1062` 把「醉仙秘市」派给 `SkillResExchangePresenter`
        #   （**走路去找商人**，所以点它会跑到财神商会）。
        #   真正的喝场（醉仙楼）在 `ActionLayer.lua:825`：
        #       ["举杯共饮"] = function(...) → DrinkMorePresenters
        #   而它**从来没上架** ⇒ 玩家在活动面板里根本找不到。
        #   服务端 `activities.py` 的 `toast_qian`（共饮）早就实现了，
        #   也是我这轮加"醉仙武意 +60/次"的地方 —— 现在把它摆出来。
        (17, 'jiubeigongyin', '举杯共饮', 604800, '长期开放', '醉仙楼共饮，得醉仙武意'),
        # ★★ 老板 2026-09-28：「类似这样的过期的，但是资源库有的，也都展示出来」
        #   下面 16 个是 `work/tmp_activity_audit.py` 全量过完 96 个活动后筛出来的：
        #   **客户端 funcTab 有、服务端接口全部"真实现"（非占位）、且尚未上架**。
        #   它们的原版场次多数已过期（2021~2025），但资源库（她自己的表 + 我方模块）
        #   都在 ⇒ 按老板要求一并摆出来。
        # (18, 'chunfen', '春分风筝活动', ...)            ← 2026-10-03 老板裁定下架
        # (19, 'sailongzhou', '赛龙舟活动', ...)          ← 2026-10-03 老板裁定下架
        # (20, 'chongzhi_jifen', '充值积分兑换', ...)      ← 2026-10-03 老板裁定下架
        # ★ 2026-09-29 老板：「活动里面点不开的就算了，去掉吧」
        #   实据：这三个点开是**空的** —— 服务端 `get_shop_info` 返回结构完整、18 件货，
        #   但服务端日志里**从没有客户端发来的该请求** ⇒ 请求没发出去
        #   （`AnniversaryCelebrationConversionLayer.lua:225` 的
        #    `if actionId == nil then return end` 会让整条链静默中止）。
        #   老板裁定：不查了，直接下架。**服务端 handler 保留**（不删代码，只不上架）。
        #   ⚠️ 上面第 20 项「充值积分兑换」用的是**同一个 presenter**，
        #      理论上同病；老板没报它，暂时留着 —— 若也点开是空的，说一声一起去掉。
        # (21, 'zhounianqing_jifen', '周年庆积分兑换', ...)   ← 已下架
        # (22, 'wudaoqiritan', '武道七日谈', ...)             ← 已下架
        # (23, 'libao_duihuan', '礼包兑换', ...)          ← 2026-10-03 客户反馈下架
        (24, 'jianghu_huanwujie', '江湖换物节', 604800, '长期开放', '江湖好运来，以物换物'),
        # (25, 'huizitc', '汇字天成', ...)                    ← 已下架
        # (26, 'guanzhu_xieli', '馆主的谢礼', ...)        ← 2026-10-03 老板裁定下架
        # (27, 'baoge_shiqie', '宝阁失窃', ...)           ← 2026-10-03 老板裁定下架
        # (28, 'haoli_heguosui', '豪礼贺国岁', ...)       ← 2026-10-03 客户反馈下架
        (29, 'tianyuanqihe', '天缘奇盒', 604800, '长期开放', '自选DIY随机礼包'),
        (30, 'qiri_denglu', '七日登录', 604800, '长期开放', '七日登录领奖'),
        # ★ 2026-09-29 老板：截图「梨园艺馆」点「领取」提示没资源 ⇒「把这些都删掉吧，省事」。
        #   我核过发货数据：`get_login_reward` 的 reward 号在 **shoplist 键**与
        #   **9 张物品表**两条通道**都合法**，所以没能定位到确切根因
        #   （疑似"名士之约/豪侠之约未购买 ⇒ 该页未解锁"那段业务，我们没实现购买）。
        #   老板裁定不追了，直接下架。**服务端 handler 保留**（只不上架）。
        # (31, 'qingyun_baoge', '卿云宝阁', ...)   ← 已下架（同 presenter/同 payload）
        # (32, 'liyi_yiguan', '梨园艺馆', ...)     ← 已下架
        # (33, 'guanyingtang_tequan', '观影堂特权加送', ...) ← 2026-10-03 客户反馈下架
    ]
    if 'get_spring_festival_list' in path:
        # ★★ 谁提供活动列表：**`ActionLayer:show`（:1149-1156）调的是 `getSpringFestivalList`
        #    ⇒ 也就是 `get_spring_festival_list`**，不是 `get_activity_list`！
        # ★ `initActionList(data)` → `for k,action in pairs(list)` 把**响应里的 data 本身**
        #   当活动数组用 ⇒ 必须是 **JSON 数组**（回 `{"list":[]}` 会让她遍历到数字，
        #   报 `attempt to index local 'action' (a number value)`）。
        # ★ 活动行字段（`ActionLayer:createOneRow` :1318-1356）：
        #     name(标题) / time(剩余时间文本) / desc / gift / remain_time(秒) / status=1 / is_open=1
        #   `name` 必须命中她的 `funcTab` 键（共 96 个可选），点进去才有对应界面。
        # ★★ 每个活动必须带 `activity_id`！
        #   `ActionLayer` 点击行（:1281-1287）按名字分支：
        #     if ManageActionByName[action.name]      -> func(action.activity_id, actionRule)
        #     elseif 天缘奇盒/江湖珍品阁               -> func(action.activity_id, action.id, actionRule)
        #     else                                    -> func(action.id, actionRule)
        #   「江湖珍品阁」走第二支 ⇒ `JiangHuZhenPinGePresenters:setActionId(activity_id)`
        #   ⇒ `JiangHuZhenPinGe.lua:29` 调 `HttpManager:getZhenPinGeLotteryList(activity_id)`
        #   ⇒ `HttpManager.lua:3385` 拼 `"get_zhenpinge_lottery_list/"..activity_id`
        #   **activity_id 为 nil 就 attempt to concatenate，面板根本弹不出来**（已实测）。
        #   另外 :412 判断 `activity_id == "jianghumingwu"` 走**旧**珍品阁，所以这里用别的值。
        _acts = [{'id': i, 'activity_id': aid, 'name': nm, 'status': 1, 'is_open': 1,
                  'remain_time': rt, 'time': tm, 'desc': ds, 'gift': ''}
                 for (i, aid, nm, rt, tm, ds) in _all]
        return enc_session({'errcode': 0, 'data': _acts, 'rand_t': time.time()}), \
            '★ 活动列表（%d 个，name 全部命中 funcTab）' % len(_acts)
    if '/api/v5/get_spring_festival_status' in path:
        # 点活动后 `ActionLayer` 会调 `getNewYearFestivalState(action.id)`（:1276）：
        #   `if data.is_open == 1 and data.status == 1 then` 才进对应界面
        #   ⇒ 必须给这两个数字（不是数组！）
        #
        # ★★ 老板 2026-09-28 报「醉仙秘市进去是财神商会，而且提示达到限购条件」。
        #   根因：`ActionLayer.lua:1079` 是 `layer:setActionId(data.activity_id)`
        #   —— 传下去的是**这个应答里的 `activity_id`**；而这里原来**没给**，
        #   于是 `get_merchant_event_info` 收到空 activityId，
        #   `misc_extra._ep_merchant_event_info` 只能按散列**乱挑一个商人**
        #   （固定落到 `25cyshopcaishen` 财神商会）⇒ 位置错 + 限购是那家店的。
        #   ⇒ 这里必须把**活动名与 activity_id** 一起回给客户端。
        #   URL 形如 `get_spring_festival_status/<id>`，用 id 回查 `_all` 清单。
        _st_id = ''
        try:
            _st_id = path.split('get_spring_festival_status', 1)[1].strip('/').split('?')[0]
        except Exception:                       # noqa: BLE001
            _st_id = ''
        _st_name, _st_key = '', ''
        for _i, _k, _n, _rt, _tm, _ds in _all:
            if str(_i) == str(_st_id):
                _st_name, _st_key = _n, _k
                break
        return enc_session({'errcode': 0, 'data': {
            'is_open': 1, 'status': 1,
            'id': int(_st_id) if str(_st_id).isdigit() else 0,
            'activity_id': _st_key, 'name': _st_name,
            'detail_desc': [],
            'start': int(time.time()) - 86400 * 30,
            'end': int(time.time()) + 86400 * 30,
            'dataVer': next_dataver()},
            'rand_t': time.time()}), \
            '★ 活动开关状态（is_open=1,status=1；id=%s → %s / %s）' \
            % (_st_id or '?', _st_name or '?', _st_key or '?')
    if path.endswith('/api/v5/get_sign_list') or 'get_sign_list' in path:
        # ★★ 签到（`SignInLayer.lua`）契约 —— `data` 就是她的 `__markData`：
        #   beginDate(YYYYMMDD，必须 ≤ 今天，否则 getMarkMap 直接 return、面板空)
        #   endDate / seasonId / createDate(账户创建日，比格子日期新 ⇒ 格子变灰禁用)
        #   signedList(已签到日期数组) / historySignCount / prizeId / prizeList / yuanbao(补签价)
        #   `LoadingBar:setPercent(historySignCount/prizeId*100)`、文本 `historySignCount.."/"..prizeId`
        #   `createMarkPanel` 会克隆 **49 个**格子（7x7），markState: 0未签/1已签/2可补签
        _today = time.strftime('%Y%m%d', time.localtime())
        _begin = time.strftime('%Y%m%d', time.localtime(time.time() - 6 * 86400))
        _end = time.strftime('%Y%m%d', time.localtime(time.time() + 42 * 86400))
        _signed = _sign_load()
        return enc_session({'errcode': 0, 'data': {
            'beginDate': _begin, 'endDate': _end, 'seasonId': 1,
            'createDate': '20200101', 'yuanbao': 20,
            'signedList': _signed, 'historySignCount': len(_signed),
            'prizeId': 15, 'prizeList': [], 'dataVer': next_dataver()},
            'rand_t': time.time()}), '★ 签到数据（beginDate=%s 已签 %d 天）' % (_begin, len(_signed))
    if 'get_sign_prize' in path:
        # `SignInLayer:httpForDateMark`（:662-690）读 data.yinpiao / data.yuanbao / data.daily_point
        #   ★ 家园已开（homeland_open == 1）时 **必定** 读 data.yinpiao：
        #     `PopText("获得银票 +"..data.yinpiao)` —— 少这个字段就
        #     "attempt to concatenate field 'yinpiao' (a nil value)"（已实测）。
        _plain = _decode_client_body(body) or ''
        _m = re.search(r'(\d{8})', _plain)
        if _m:
            _sign_add(_m.group(1))
            log('签到落盘：%s（累计 %d 天）' % (_m.group(1), len(_sign_load())))
        return enc_session({'errcode': 0, 'data': {
            'yinpiao': 10, 'yuanbao': 0, 'daily_point': 0, 'dataVer': next_dataver()},
            'rand_t': time.time()}), '★ 签到领奖（银票 +10）'
    if 'get_sign_history_prize' in path:
        # `SignInLayer:getPrizeReward`（:800）只看 errcode
        return enc_session({'errcode': 0, 'data': {
            'yinpiao': 0, 'yuanbao': 0, 'dataVer': next_dataver()},
            'rand_t': time.time()}), '★ 累计签到领奖'
    if 'get_growth_info' in path:
        # `DaXiaChenZhangZhiLuLayer:showLayer`（:970-1008）：
        #   data.homeland.servants -> 家园仆人（`{job, num}`），可空
        #   data.lunjian           -> 论剑排名（**数字**）
        #   ★ `lunjianRanking <= ranking`（:258）—— 这里少给就
        #     "attempt to compare nil with number"（已实测）。
        #   成就条件里论剑那档 `arg1 = 10`，所以给 10 就有一条能达成。
        # ★ 另外 `actionTime` 会 `Helper:date("%Y", tonumber(data.start))`
        #   （`Helper.lua:1383` 断言 time 必须是 number）⇒ 见上面 get_spring_festival_status 已补 start/end。
        return enc_session({'errcode': 0, 'data': {
            'homeland': {'servants': []}, 'lunjian': 10,
            'dataVer': next_dataver()}, 'rand_t': time.time()}), '★ 大侠成长之路（仆从空/论剑第10）'
    if 'get_jhsanyou_list' in path:
        # `JiangHuSanYouLayer:createPanel`（:83-88）：
        #   data.list 每项 = {id, rq, tp}，`id` 必须是
        #   `res/script/others/threefriends.lua` `["Sheet1"]` 的**键**（`npc001` 这种）；
        #   `rq`/`tp` 直接进 `setString` ⇒ **给字符串**。
        #   data.canVote == 1 才能投票（0 会弹"你今天已经投了20票"）。
        _tf = load_template('api_v5_threefriends') or []
        _list = []
        for i, n in enumerate(_tf[:6]):
            _list.append({'id': n['id'], 'rq': str(1800 - i * 137), 'tp': str(320 - i * 21)})
        return enc_session({'errcode': 0, 'data': {
            'list': _list, 'canVote': 1, 'dataVer': next_dataver()},
            'rand_t': time.time()}), '★ 江湖三友（%d 个候选，可投票）' % len(_list)
    if 'vote_to_jhsanyou' in path:
        return enc_session({'errcode': 0, 'data': {'canVote': 1, 'dataVer': next_dataver()},
                            'rand_t': time.time()}), '★ 江湖三友投票'
    if 'festival' in path:
        # 其余节庆接口：给空表（结构对就行）
        return enc_session({'errcode': 0, 'data': {'list': [], 'dataVer': next_dataver()},
                            'rand_t': time.time()}), '★ 节庆（空表）'
    if path.endswith('/api/v5/get_devote_point'):
        # `TeacherLayer:refreshGongXian`（:441-454）会拼 "『师门贡献点』"..tonumber(data.dev_point)
        # ⇒ 必须有数字 dev_point，否则 attempt to concatenate a nil value、师门面板直接不显示
        # ★ 第十一轮第二段起**真账已由 `fz_api/content_fill.py` 接管**
        #   （`gongxiandian` 走 `items_currency` 的唯一钱袋，与 `map_shop` 声望商人同键）。
        #   这里只是模块没加载时的兜底：回 0，至少不崩。
        return enc_session({'errcode': 0, 'data': {'dev_point': 0, 'has_reward': 'N',
                                                   'dataVer': next_dataver()},
                            'rand_t': time.time()}), '★ 师门贡献点（兜底 0；真账在 content_fill）'
    # ------------------------------------------------------------------
    # 家园（HomelandModel / 地图脚本动作「家园开启」）
    # ------------------------------------------------------------------
    if path.endswith('/api/v5/get_home_switch'):
        # `HomelandModule.lua:489 ["家园开启"]` 调它；errcode==0 即视为开启成功，
        # 会读 `data.yinpiao`（>0 就弹"你获得了N银票"）。
        # ★ 真机上「家园开启」是**地图里的一段脚本动作**（扬州尤三的家园引导），
        #   所以这个接口补好只是"她调了就能过"，还要走到那个 NPC 才触发。
        return enc_session({'errcode': 0, 'data': {'yinpiao': 0, 'dataVer': next_dataver()},
                            'rand_t': time.time()}), '★ 家园开启（get_home_switch）'
    if path.endswith('/api/v5/get_common_fuben'):
        # ★★★ 城市地图里「哪些房间是玩家的家」—— **这就是家门口**。
        #   `HomelandModule:entryCommonMap`（:752-770）在进入住宅区（fb301/302/303/304）时调它，
        #   拿到的 `data.usermap` 交给 `changeMapInfo`（:777-821）：
        #       for index, roomInfo in pairs(data.usermap) do
        #           for mRoomId, mRoomInfo in pairs(rooms) do
        #               if mRoomInfo.flag and mRoomInfo.flag == roomInfo.dpId then
        #                   room = Helper:tableCover(map:getRoomById(mRoomId), roomInfo)
        #   ⇒ 城市房间**只要挂上 `mid` + `uid`**，走进去就会
        #     `MapLayer:enterOldMapRoom`（:1516）→ `entryUserRoom(toRoom.mid, toRoom.uid)`
        #     （:2131）→ `UserMap:getUserMap` → 进自己家。
        #   ★ 我们以前走宽容兜底 ⇒ `usermap` 为空 ⇒ `changeMapInfo` 直接 return
        #     ⇒ 城里的地皮房永远显示「一块宽阔的土地，尚未开发。」，也没有"家门口"入口
        #     （老板问的「从大街回来之后没有家门口了」就是这个）。
        #   房间键 `flag` 是她地图资源里写好的（fb301 有 272 个房间带 flag=dpId）。
        _plain = _decode_client_body(body) or ''
        _m = re.search(r'fbId["\']?\s*[:=]\s*["\']?([A-Za-z0-9_]+)', _plain)
        _fb = _m.group(1) if _m else 'fb10'
        _uid = headers.get('userid') or ''
        _fq_id = _home_fq()
        _mid = _sticky_home_mid(_fq_id)
        _dp = {v['dpId']: v for v in homeland._tables()['dp'].values()
               if v.get('dpId')} if homeland else {}
        _info = _dp.get(_fq_id) or {}
        _usermap = {}
        _dp_room = _info.get('dpRoomId') or ''
        _usermap['1'] = {
            'dpId': _fq_id,
            'dpRoomId': _dp_room,
            'mid': _mid,
            'uid': _uid,
            'name': _home_name(_fq_id),
            'desc': '这是%s的宅院，位于%s。' % (_home_name(_fq_id), _homeland_address(_fq_id)),
            'entryRoom': 'fb320_01',
        }
        log('公共地图 %s：登记老板的宅院 dpId=%s（房间 flag 匹配）mid=%d' % (_fb, _fq_id, _mid))
        return enc_session({'errcode': 0, 'data': {'usermap': _usermap, 'fbId': _fb,
                                                   'dataVer': next_dataver()},
                            'rand_t': time.time()}), \
            '★ 公共地图玩家宅院表（%s → %s，含 mid/uid 可进入）' % (_fb, _fq_id)
    # ------------------------------------------------------------------
    # 家园「房屋管理」：查看房契 / 改名 / 升级 / 管家门客
    # ------------------------------------------------------------------
    if 'get_homeland_cost' in path:
        # `FangQiModel:viewFangQi`（:141-237）—— 房契信息面板，读：
        #   data.servants_pay -> `for cost_unit,cost in pairs(ser_pay)`（**必须是表**）
        #   data.land_pay.daily / data.land_pay.total
        # ★ 少了 `servants_pay` 就 `pairs(nil)` ⇒ 报错被吞 ⇒ **点【查看】就卡死**（她面板的"查看"按钮）。
        #
        # ★★ 以前这里回的是写死的空表 ⇒ 面板永远显示「仆役薪资：」后面什么都没有、
        #    地税永远是 0。现在按**她自己的口径**算：
        #    * 仆役薪资：`RoomAffairLayer:169-190` 是从「府务」事务里按
        #      `affair_val.pay_unit` 汇总 `affair.cost`。这里照同一口径，
        #      把**未支付**的发薪事务（affair_id 3/4）按货币单位求和。
        #    * 地税：`房屋地皮[dpId].cost`（元宝/天，她自己那张表）；
        #      欠费总额 = 欠费天数 × 日单价，欠费天数取地税事务（affair_id 2）的 `pay_time`。
        _fq_cc = _home_fq()
        _servants_pay = {}
        _land_pay = {'daily': 0, 'total': 0}
        try:
            with open(os.path.join(HERE, 'homeland_home_state.json'), encoding='utf-8') as _f:
                _hs = json.load(_f)
        except Exception:                       # noqa: BLE001
            _hs = {}
        _now_cc = time.time()
        for _home_cc in (_hs.get('homes') or {}).values():
            if not isinstance(_home_cc, dict):
                continue
            for _a_cc in (_home_cc.get('affairs') or []):
                if not isinstance(_a_cc, dict):
                    continue
                _av_cc = _a_cc.get('affair_val') or {}
                _aid = 0
                try:
                    _aid = int(float(_a_cc.get('affair_id') or 0))
                except (TypeError, ValueError):
                    _aid = 0
                _days_cc = 1
                try:
                    _days_cc = max(1, int((_now_cc - float(_av_cc.get('pay_time') or _now_cc)) // 86400))
                except (TypeError, ValueError):
                    _days_cc = 1
                _unit_cc = str(_av_cc.get('pay_unit') or 'yinpiao')
                _base_cc = 0
                try:
                    _base_cc = int(float(_av_cc.get('pay_base') or 0))
                except (TypeError, ValueError):
                    _base_cc = 0
                if _aid in (3, 4):              # 仆人/门客发薪
                    _servants_pay[_unit_cc] = _servants_pay.get(_unit_cc, 0) + _base_cc * _days_cc
                elif _aid == 2:                 # 地税：日单价 + 欠费总额
                    _land_pay['daily'] = _base_cc
                    _land_pay['total'] = _base_cc * _days_cc
        if not _land_pay['daily'] and homeland:
            # 没有地税事务时退回她 `房屋地皮` 表的 `cost`（元宝/天）
            for _v_cc in homeland._tables()['dp'].values():
                if _v_cc.get('dpId') == _fq_cc:
                    try:
                        _land_pay['daily'] = int(float(_v_cc.get('cost') or 0))
                    except (TypeError, ValueError):
                        _land_pay['daily'] = 0
                    break
        log('房契开销：仆役 %s / 地税 %s' % (_servants_pay or '{}', _land_pay))
        return enc_session({'errcode': 0, 'data': {
            'servants_pay': _servants_pay, 'land_pay': _land_pay,
            'dataVer': next_dataver()}, 'rand_t': time.time()}), \
            '★ 家园每日开销（房契面板：仆役 %d 项 / 地税 %d 元宝每天）' \
            % (len(_servants_pay), _land_pay['daily'])
    if path.endswith('/api/v5/get_all_numrsper'):
        # `FangQiModel:fangJianGaiMing`（:112-143）→ 改名面板 `showLayer(data.rnum, data.pnum)`
        st = _home_load()
        _fq = _home_fq()
        return enc_session({'errcode': 0, 'data': {
            'rnum': _home_roomnum(_fq), 'pnum': len(st.get('employees') or []),
            'rmax': 99, 'pmax': 99, 'dataVer': next_dataver()},
            'rand_t': time.time()}), '★ 家园房间数/仆人数（改名面板）'
    if path.endswith('/api/v5/rename_home'):
        # `FangJianGaiMingLayer:182` 改名；成功后她自己 `updateInfo({houseName, isRename=true})`
        _plain = _decode_client_body(body) or ''
        _m = re.search(r'new_name["\']?\s*[:=]\s*["\']?([^"\',}]*)', _plain)
        st = _home_load()
        if _m and _m.group(1).strip():
            st['name'] = _m.group(1).strip()
            _home_save(st)
            log('家园改名 → %s' % st['name'])
        return enc_session({'errcode': 0, 'data': {'dataVer': next_dataver()},
                            'rand_t': time.time()}), '★ 家园改名（%s）' % st.get('name')
    if path.endswith('/api/v5/upgrande_user_map'):
        # `HouseEnlargeDetailsLayer:112` 升级/扩建：{mid, new_fqId, yinpiao_num}
        #   成功后她把本地 fqId/name/roomnum 覆盖成新房型，并要求重新进入家园。
        _plain = _decode_client_body(body) or ''
        _m = re.search(r'new_fqId["\']?\s*[:=]\s*["\']?([A-Za-z0-9_]+)', _plain)
        st = _home_load()
        if _m and _m.group(1):
            st['fqId'] = _m.group(1)
            _home_save(st)
            log('家园升级 → %s（%d 房间）' % (_m.group(1), _home_roomnum(_m.group(1))))
        return enc_session({'errcode': 0, 'data': {'dataVer': next_dataver()},
                            'rand_t': time.time()}), '★ 家园升级（%s）' % st.get('fqId')
    if path.endswith('/api/v5/view_currency_by_type'):
        # `HouseEnlargeDetailsLayer:154` / `GuanJiaModel` 读 `data.number`
        _plain = _decode_client_body(body) or ''
        _m = re.search(r'currency_type["\']?\s*[:=]\s*["\']?([a-zA-Z_]+)', _plain)
        _cur = (_m.group(1) if _m else 'yinpiao')
        st = _home_load()
        return enc_session({'errcode': 0, 'data': {
            'number': (st.get('currency') or {}).get(_cur, 0), 'currency_type': _cur,
            'dataVer': next_dataver()}, 'rand_t': time.time()}), '★ 货币数量（%s）' % _cur
    if 'get_employee_list' in path:
        # `GuanJiaModel:initEmployList`（:195-217）：`data.list`，条目 `state == 0` 才是可选
        _parts = [p for p in path.split('/api/v5/get_employee_list/')[-1].split('/') if p]
        _npc = _parts[0] if _parts else 'npc'
        return enc_session({'errcode': 0, 'data': {
            'list': _hire_list(_npc), 'dataVer': next_dataver()},
            'rand_t': time.time()}), '★ 雇佣候选（%s，5 人）' % _npc
    if path.endswith('/api/v5/save_employee_list'):
        # `GuanJiaModel:refresh`（:223-260）：**应答 `data` 本身是数组**（`for i=1,#data`）
        _plain = _decode_client_body(body) or ''
        _npc = 'npc'
        _m = re.search(r'npcId["\']?\s*[:=]\s*["\']?([A-Za-z0-9_]+)', _plain)
        if _m:
            _npc = _m.group(1)
        return enc_session({'errcode': 0, 'data': _hire_list(_npc),
                            'rand_t': time.time()}), '★ 刷新雇佣列表（数组直出）'
    if path.endswith('/api/v5/add_employee'):
        _plain = _decode_client_body(body) or ''
        st = _home_load()
        _m = re.search(r'objId["\']?\s*[:=]\s*["\']?([A-Za-z0-9_]+)', _plain)
        if _m:
            st.setdefault('employees', [])
            if _m.group(1) not in [str(e.get('objId')) for e in st['employees']]:
                st['employees'].append({'objId': _m.group(1), 'jobType': 'guanjia001',
                                        'name': '管家'})
            _home_save(st)
            log('雇佣成功 → %s（现在 %d 人）' % (_m.group(1), len(st['employees'])))
        return enc_session({'errcode': 0, 'data': {'dataVer': next_dataver()},
                            'rand_t': time.time()}), '★ 雇佣（add_employee）'
    if path.endswith('/api/v5/delete_employee'):
        _plain = _decode_client_body(body) or ''
        st = _home_load()
        _m = re.search(r'objId["\']?\s*[:=]\s*["\']?([A-Za-z0-9_]+)', _plain)
        if _m:
            st['employees'] = [e for e in (st.get('employees') or [])
                               if str(e.get('objId')) != _m.group(1)]
            _home_save(st)
        return enc_session({'errcode': 0, 'data': {'dataVer': next_dataver()},
                            'rand_t': time.time()}), '★ 辞退（delete_employee）'
    if path.endswith('/api/v5/get_employee_data') or path.endswith('/api/v5/update_employee_data') \
            or path.endswith('/api/v5/update_employee_extra'):
        return enc_session({'errcode': 0, 'data': {'dataVer': next_dataver()},
                            'rand_t': time.time()}), '★ 管家/门客数据'
    if path.endswith('/api/v5/get_intelligence_data'):
        # `IntelligenceManager:getIntelligenceList`（:218-274）三分支：
        #   errcode 0 = 已购买（回 intelligence_list，面板才有内容）
        #   errcode 1 = 已上传未购买（回 price/currency_type，她弹购买框）
        #   errcode 2 = 未上传（她**自己**从 qingbaoku/qingbaomoban 抽一份，再传上来）
        # ★ 以前走宽容兜底回 `errcode:0` 但**没有 intelligence_list** ⇒
        #   `IntelligencePresenter:create(layer, sys, nil)` ⇒ 面板一片空白（老板看到的那个）。
        _d = _intel_load()
        # ★★ `initIntelligenceData(data)`（`IntelligenceManager.lua:27-37`）**无条件**读
        #    `data.bought_intelligence_list` / `data.bought_technique_list` 并 `ipairs` 它们
        #    ⇒ 少一个就 `third/tableProxy/TableProxy.lua:100 bad argument #1 to 'rawget'
        #      (table expected, got nil)`（已实测）。所以**每个分支都要带这两个空表**。
        _base = {'bought_intelligence_list': _d.get('bought_intelligence_list') or [],
                 'bought_technique_list': _d.get('bought_technique_list') or [],
                 'day': _d['day']}
        if not _d.get('uploaded'):
            return enc_session({'errcode': 2, 'data': _base,
                                'rand_t': time.time()}), '★ 情报：今日未上传（让客户端自己抽）'
        if not _d.get('bought'):
            _base.update({'price': _d.get('price') or 0,
                          'currency_type': _d.get('currency_type') or 1,
                          'intelligence_list': _intel_entries(_d.get('intelligence_list'),
                                                              _d.get('read'))})
            return enc_session({'errcode': 1, 'data': _base, 'rand_t': time.time()}), \
                '★ 情报：已上传待购买（%d 条，%s 碎银）' % (len(_d.get('intelligence_list') or []),
                                                          _d.get('price'))
        _base.update({'intelligence_list': _intel_entries(_d.get('intelligence_list'),
                                                          _d.get('read')),
                      'technique_list': _intel_entries(_d.get('technique_list')
                                                       or _intel_seed_techniques(),
                                                       _d.get('read')),
                      'currency_type': _d.get('currency_type') or 1})
        return enc_session({'errcode': 0, 'data': _base, 'rand_t': time.time()}), \
            '★ 情报：已购买（%d 条）' % len(_d.get('intelligence_list') or [])
    if path.endswith('/api/v5/upload_intelligence_data'):
        _plain = _decode_client_body(body) or ''
        try:
            _p = json.loads(_plain)
        except Exception:                   # noqa: BLE001
            _p = {}

        def _ids(key):
            v = _p.get(key)
            if isinstance(v, list):
                return [x for x in v if isinstance(x, (int, float, str))]
            if isinstance(v, str):
                return [x.strip() for x in v.split(',') if x.strip()]
            return []

        _d = _intel_load()
        _d['uploaded'] = True
        _d['bought'] = False
        _d['intelligence_list'] = _ids('intelligence_list')
        _d['technique_list'] = _ids('technique_list')
        _d['currency_type'] = _p.get('currency_type') or 1
        _d['price'] = _p.get('price') or 0
        _d['read'] = []
        # ★ 她传上来的 technique_list **一定是空的**（4 个模板 technique_open 全 0）
        #   ⇒ 江湖秘辛空白。服务端用她自己那 50 条 type=3 情报补上。
        if not _d['technique_list']:
            _d['technique_list'] = _intel_seed_techniques()
        _intel_save(_d)
        log('情报上传：%d 条情报 + %d 条秘辛，价 %s（货币 %s）'
            % (len(_d['intelligence_list']), len(_d['technique_list']),
               _d['price'], _d['currency_type']))
        return enc_session({'errcode': 0, 'data': {'dataVer': next_dataver()},
                            'rand_t': time.time()}), '★ 情报上传（记账）'
    if path.endswith('/api/v5/buy_day_intelligence'):
        # `IntelligenceManager:buyIntelligence`（:294-329）读
        #   data.currency_type / data.remove_price / data.intelligence_list
        _d = _intel_load()
        _d['bought'] = True
        _intel_save(_d)
        return enc_session({'errcode': 0, 'data': {
            'currency_type': _d.get('currency_type') or 1,
            'remove_price': _d.get('price') or 0,
            'intelligence_list': _d.get('intelligence_list') or [],
            'technique_list': _d.get('technique_list') or [],
            'dataVer': next_dataver()}, 'rand_t': time.time()}), \
            '★ 情报购买（%d 条，扣 %s）' % (len(_d.get('intelligence_list') or []), _d.get('price'))
    if path.endswith('/api/v5/get_technique_list'):
        _d = _intel_load()
        if not _d.get('technique_list'):        # 老账本/她没传 ⇒ 现补
            _d['technique_list'] = _intel_seed_techniques()
            _intel_save(_d)
        return enc_session({'errcode': 0, 'data': {
            'technique_list': _intel_entries(_d.get('technique_list'), _d.get('read')),
            'dataVer': next_dataver()}, 'rand_t': time.time()}), \
            '★ 江湖秘辛列表（%d 条）' % len(_d.get('technique_list') or [])
    if path.endswith('/api/v5/read_intelligence'):
        _plain = _decode_client_body(body) or ''
        _m = re.search(r'intelligence_id["\']?\s*[:=]\s*["\']?(\d+)', _plain)
        _d = _intel_load()
        _rd = _d.get('read') or []
        if _m and _m.group(1) not in [str(x) for x in _rd]:
            _rd.append(int(_m.group(1)))
            _d['read'] = _rd
            _intel_save(_d)
        return enc_session({'errcode': 0, 'data': {'dataVer': next_dataver()},
                            'rand_t': time.time()}), '★ 阅读情报'
    if path.endswith('/api/v5/get_house_info') or path.endswith('/api/v5/get_land_info'):
        # 房契 / 地契：`FangQiModel:reapplyFangQi` / `DiQiModel:reapplyDiQi`
        #   `reapplyFangQi` 读 data.fqId / data.mid / data.loc_mark / data.dpId，
        #   并会 `fqTemplate = self:getFangQiTemplateById(data.fqId)`
        #   ⇒ **fqId 必须是 `familylist.房契模板` 里真实存在的**
        _fq_id = _home_fq()
        _mid = _sticky_home_mid(_fq_id)
        return enc_session({'errcode': 0, 'data': {
            'fqId': _fq_id, 'mid': _mid, 'dpId': '', 'loc_mark': {},
            'location': _homeland_address(_fq_id), 'houseName': _home_name(_fq_id),
            'dataVer': next_dataver()},
            'rand_t': time.time()}), '★ 房契信息（%s）' % _fq_id
    if path.endswith('/api/v5/get_user_map'):
        # ★★★ 家园地图 —— **整张图由服务端下发**（客户端没有 fb319 之类的地图文件）。
        #   `UserMap:getWebUserMapInfo`（:74-100）→ `initUserMap(data)`：
        #     data.usermap          Helper:tableCover(BaseMap, usermap)，必须含
        #                           mid / name / mapAppearance / mapAppearanceIndex / entryRoom
        #     data.maproom          房间表（fjId / roomType / desc / 连线 / …）
        #     data.roomfurniture    家具表（可空）
        #     data.roomperson       仆人表（可空）
        #     data.owner / data.ver
        #   ★ 以前这里走宽容兜底只回 dataVer ⇒ `initUserMap` 直接 return nil
        #     ⇒ 回调里 `BaseItem.lua:1271 map._isComingIn = true` 报
        #     `attempt to index local 'map'` ⇒ 被 xpcall 吞掉 ⇒ **客户端 UI 整体卡死**
        #     （老板点房契「前往」，出现"你开始施展奇门遁甲…"后就没反应，就是这个）。
        _plain = _decode_client_body(body) or ''
        _m = re.search(r'mid["\']?\s*[:=]\s*["\']?(\d+)', _plain)
        _mid = _m.group(1) if _m else '0'
        if not _mid or _mid in ('0', ''):
            _mid = str(_sticky_home_mid())   # ★ 与房契同一个 mid
        # 老板是旧版服务端买的房，存档里 `fq.mid = 0` ⇒ 用存档里的 `fqId` 认房型
        if homeland and not homeland.fq_by_mid_exact(_mid):
            _fq = _homeland_default()
            homeland.set_mid(_mid, _fq)
            log('玩家副本 mid=%s 没有登记 → 按存档房契 %s 生成' % (_mid, _fq))
        if homeland is None:
            return enc_session({'errcode': 0, 'data': {'usermap': {}, 'maproom': [],
                                                       'dataVer': next_dataver()},
                                'rand_t': time.time()}), '★ 玩家副本（生成器缺失）'
        _uid = headers.get('userid') or ''
        # 升级过就用新的房型（`upgrande_user_map` 会改 `homeland_state.fqId`）——
        # 这样「升级」不是嘴上说说，**家园地图真的变大**。
        _fq_now = _home_fq()
        if _fq_now and homeland.fq_by_mid(_mid) != _fq_now:
            homeland.set_mid(_mid, _fq_now)
        _data = homeland.build_user_map(_mid, owner=_uid)
        _nm = _home_name(_fq_now)
        if _nm:
            _data['usermap']['name'] = _nm
            _data['usermap']['houseName'] = _nm
        _um = _data['usermap']
        # ★★ 家具 & 屋里的人：`get_user_map` 的 `roomfurniture` / `roomperson` 以前一直是空表
        #   ⇒ **家里空荡荡、没管家没仆人**。现在由功能模块提供（它们各自导出 map_* 函数，
        #   这里容错调用 —— 模块还没到位就先空着，不会报错）。
        #   契约：`UserMap:initFurniture` → `FurnitureModel:initFurnitureForUserMap(map, v)`；
        #         `UserMap:initUserMap` → `HomelandRoleUtil:initHomelandMapRole(roleInfo, map)`。
        try:
            import fz_api
            fz_api.load_modules()
            for _mod, _fn, _key in (('homeland_furniture', 'map_furniture', 'roomfurniture'),
                                    ('homeland_person', 'map_persons', 'roomperson')):
                try:
                    _mm = __import__('fz_api.' + _mod, fromlist=['*'])
                    _f = getattr(_mm, _fn, None)
                    if callable(_f):
                        _ctx2 = fz_api.Ctx(path, headers, body, {
                            'enc_session': enc_session, 'decode_body': _decode_client_body,
                            'next_dataver': next_dataver, 'log': log, 'here': HERE})
                        _lst = _f(_ctx2, _mid) or []
                        _data[_key] = _lst
                        log('家园 %s：%d 项' % (_key, len(_lst)))
                except Exception as _e2:            # noqa: BLE001
                    log('家园 %s 取数失败：%s' % (_key, _e2))
            # ★ 房间改造 / 拆房：`maproom` 是上面按房契户型**重新生成**的，不认识
            #   模块里记的改造结果 ⇒ 不改的话"改造"看起来没生效。就地盖一层。
            try:
                _fixmod = __import__('fz_api.homeland_furniture', fromlist=['*'])
                _patch = getattr(_fixmod, 'patch_maproom', None)
                if callable(_patch):
                    _nc = _patch(fz_api.Ctx(path, headers, body, {
                        'enc_session': enc_session, 'decode_body': _decode_client_body,
                        'next_dataver': next_dataver, 'log': log, 'here': HERE}),
                        _mid, _data['maproom'])
                    if _nc:
                        log('家园 maproom 改造补丁：%d 间' % _nc)
            except Exception as _e4:                # noqa: BLE001
                log('家园 maproom 改造补丁失败：%s' % _e4)
        except Exception as _e3:                    # noqa: BLE001
            log('家园 家具/人员模块未就绪：%s' % _e3)
        log('玩家副本 mid=%s → %s（%d 房间 / 入口 %s / 家具 %d / 人 %d）'
            % (_mid, _nm, len(_data['maproom']), _um.get('entryRoom'),
               len(_data.get('roomfurniture') or []), len(_data.get('roomperson') or [])))
        # ★★ 2026-10-01 老板：跟管家说话只有「交谈」，没有「搬家/房屋事务/招募仆人/房屋改造/
        #   赏赐/户型图/仆人管理」（也没有改名）——因为客户端 `BaseMap:isUserMap()` 判的是
        #       `role:getHomelandAttr("fq").mid == self.mid`
        #   而我们这里把 `usermap.mid` 写成了 **0**，房契上是 **640** ⇒ 判 false ⇒ 那些按钮不出现。
        #   修法：usermap.mid 一律回**客户端请求的那个 mid**（房契下发的 mid 也是同一个），
        #   并把 owner/userid 也补上（好友来访那条路要用）。
        _data.setdefault('usermap', {})['mid'] = _mid   # ★ build 走兜底时可能没有 usermap ⇒ 用 setdefault 防 KeyError(→404)
        if _uid:
            _data['usermap'].setdefault('owner', _uid)
            _data['usermap'].setdefault('userid', _uid)
            _data.setdefault('owner', _uid)
        return enc_session({'errcode': 0, 'data': _data, 'rand_t': time.time()}), \
            '★ 玩家副本/家园地图（mid=%s，%d 房间）' % (_mid, len(_data['maproom']))
    if path.endswith('/api/v5/buy_homeland'):
        # 购房：`BuyHouseLayer.lua:264-279` → `buyHomeland(npcId, fqId)`；
        # 成功后她把响应 `data` 直接喂给 `FangQiModel:getFangQi(data)`：
        #   `getFangQi` 读 `data.mid`（房屋ID）`data.fqId` `data.mapId` `data.location`，
        #   并且要 `data.remove_point`（扣的积分）→ 然后 `role:setHomelandAttr("fq", fq)`。
        # ★ 以前这里 `mid: 0` 且**没回 fqId** ⇒ 存档里 `fq.fqId` 缺、`location` 是 0，
        #   点「前往」时 `mapId = "user_fb_" .. fq.mid` 也没意义。现在记下来。
        _plain = _decode_client_body(body) or ''
        _m = re.search(r'fqId["\']?\s*[:=]\s*["\']?([A-Za-z0-9_]+)', _plain)
        _fq_id = _m.group(1) if _m else 'yangzhou001'
        _mid = _homeland_mid_for(_fq_id)   # ★ 确定性（别用 hash()，每进程都不一样）
        _addr = _homeland_address(_fq_id)
        _homesave(_mid, _fq_id)
        log('购房：fqId=%s mid=%d 地址=%s' % (_fq_id, _mid, _addr))
        return enc_session({'errcode': 0, 'data': {
            'mid': _mid, 'fqId': _fq_id, 'location': _addr, 'remove_point': 0,
            'mapId': 'fb10', 'houseName': _homeland_name(_fq_id),
            'dataVer': next_dataver()},
            'rand_t': time.time()}), '★ 购房（fqId=%s mid=%d）' % (_fq_id, _mid)
    if path.endswith('/api/v5/get_house_store_list'):
        # 购房列表（`getHouseStoreList`）：房型全部来自她自己的 `familylist.房契模板`
        _list = []
        for i, h in enumerate(homeland.list_houses()):
            if not h['fqId']:
                continue
            _list.append({'id': i + 1, 'fqId': h['fqId'], 'name': h['name'],
                          'typedsc': '这是一间%s，共有%d个房间。' % (h['name'], h['roomnum'] or 0),
                          'cost': h['cost'], 'roomnum': h['roomnum'], 'isBuy': False})
        return enc_session({'errcode': 0, 'data': {'list': _list, 'dataVer': next_dataver()},
                            'rand_t': time.time()}), '★ 购房列表（%d 种真房型）' % len(_list)
    if path.endswith('/api/v5/get_user_group') or path.endswith('/api/v5/get_all_intimacy'):
        # 师门任务「邀请同行」：`getAllPersons` / `getUserGroup` / `getAllIntimacy`
        #   我们没有人脉数据 ⇒ 空表，她会显示"你没有可供选择的同门"（正确行为）
        return enc_session({'errcode': 0, 'data': {'list': [], 'dataVer': next_dataver()},
                            'rand_t': time.time()}), '★ 人脉/同门列表（空）'
    if path.endswith('/api/v5/get_all_persons'):
        return enc_session({'errcode': 0, 'data': {'list': [], 'dataVer': next_dataver()},
                            'rand_t': time.time()}), '★ 全部人物（空）'
    if path.endswith('/api/v5/get_all_rooms'):
        return enc_session({'errcode': 0, 'data': {'list': [], 'dataVer': next_dataver()},
                            'rand_t': time.time()}), '★ 全部房间（空）'
    # ------------------------------------------------------------------
    # 师门任务 / 师门商店（TeacherTaskLayer 家族）
    # 契约来自逐文件扫 `data.<字段>`：
    #   TeacherTaskLayer           读 data.dev_point / has_reward / get_point / special_time
    #   AppointTeacherTaskLayer    读 data.user_list / refreshCount / record_id
    #   其余都要 dataVer（她 `ServerActionSystem:setDataVersion` 要求数字）
    # ------------------------------------------------------------------
    if path.endswith('/api/v5/get_same_menpai_user_list'):
        # `getTeacherTaskPointList`（指派任务界面）
        return enc_session({'errcode': 0, 'data': {'user_list': [], 'refreshCount': 0,
                                                   'record_id': 0, 'dataVer': next_dataver()},
                            'rand_t': time.time()}), '★ 同门弟子列表（空）'
    if path.endswith('/api/v5/get_zhipai_task_record') or path.endswith('/api/v5/get_zhipai_task_reward'):
        return enc_session({'errcode': 0, 'data': {'list': [], 'has_reward': 0, 'get_point': 0,
                                                   'special_time': 0, 'dataVer': next_dataver()},
                            'rand_t': time.time()}), '★ 师门任务记录/奖励（空）'
    if path.endswith('/api/v5/add_zhipai_task_record'):
        return enc_session({'errcode': 0, 'data': {'dataVer': next_dataver()},
                            'rand_t': time.time()}), '★ 添加师门任务记录'
    if path.endswith('/api/v5/fresh_task_by_yuanbao'):
        # `refreshTeacherTaskList`（刷新任务列表）
        return enc_session({'errcode': 0, 'data': {'list': [], 'dataVer': next_dataver()},
                            'rand_t': time.time()}), '★ 刷新师门任务（空列表）'
    if path.endswith('/api/v5/get_teacher_shop'):
        return enc_session({'errcode': 0, 'data': {'list': [], 'dataVer': next_dataver()},
                            'rand_t': time.time()}), '★ 师门商店（空货架）'
    # ★ `buy_teacher_good` / `update_menpai_gongxiangdian` / `get_devote_point` /
    #   `add_devote_point` 的**真实现已迁到 `fz_api/content_fill.py`**（模块优先于本文件，
    #   第十一轮第二段：货架与购买必须同一个模块，否则货票两张皮）。下面这几条只剩兜底。
    if path.endswith('/api/v5/buy_teacher_good'):
        return enc_session({'errcode': 0, 'data': {'dataVer': next_dataver()},
                            'rand_t': time.time()}), '★ 购买师门商品（兜底：真实现在 content_fill）'
    if path.endswith('/api/v5/update_menpai_gongxiangdian'):
        return enc_session({'errcode': 0, 'data': {'dataVer': next_dataver()},
                            'rand_t': time.time()}), '★ 更新门派共享点（兜底：真实现在 content_fill）'
    if path.endswith('/api/v5/add_devote_point'):
        return enc_session({'errcode': 0, 'data': {'dev_point': 0, 'dataVer': next_dataver()},
                            'rand_t': time.time()}), '★ 增加师门贡献点（兜底：真实现在 content_fill）'
    if path.endswith('/api/v5/get_teacherBuild_tasks'):
        return enc_session({'errcode': 0, 'data': {'list': [], 'dataVer': next_dataver()},
                            'rand_t': time.time()}), '★ 师门建设任务（空）'
    if path.endswith('/api/v5/get_teacherBuild_items'):
        return enc_session({'errcode': 0, 'data': {'list': [], 'dataVer': next_dataver()},
                            'rand_t': time.time()}), '★ 师门建筑材料（空）'
    if path.endswith('/api/v5/get_teacherBuild_donateInfo'):
        return enc_session({'errcode': 0, 'data': {'buildTeacherExp': 0, 'list': [],
                                                   'dataVer': next_dataver()},
                            'rand_t': time.time()}), '★ 师门建设捐献信息'
    if path.endswith('/api/v5/get_teacherFeat_info'):
        return enc_session({'errcode': 0, 'data': {'list': [], 'count': 0,
                                                   'dataVer': next_dataver()},
                            'rand_t': time.time()}), '★ 师门名绩（空）'
    if path.endswith('/api/v5/get_teacherFeat_reward'):
        return enc_session({'errcode': 0, 'data': {'dataVer': next_dataver()},
                            'rand_t': time.time()}), '★ 领取师门名绩奖励'
    if path.endswith('/api/v5/get_sectGuidance_info'):
        return enc_session({'errcode': 0, 'data': {'list': [], 'dataVer': next_dataver()},
                            'rand_t': time.time()}), '★ 师门指点（空）'
    if path.endswith('/api/v5/get_sectRevitalization_info'):
        return enc_session({'errcode': 0, 'data': {'list': [], 'dataVer': next_dataver()},
                            'rand_t': time.time()}), '★ 振兴门派（空）'
    if path.endswith('/api/v5/get_sectRevitalization_reward'):
        return enc_session({'errcode': 0, 'data': {'dataVer': next_dataver()},
                            'rand_t': time.time()}), '★ 振兴门派奖励'
    if path.endswith('/api/v5/get_sect_supportShop'):
        return enc_session({'errcode': 0, 'data': {'list': [], 'dataVer': next_dataver()},
                            'rand_t': time.time()}), '★ 师门易物堂（空）'
    # ------------------------------------------------------------------
    # 师门建设（TeacherBuildSystem）
    # ------------------------------------------------------------------
    if path.endswith('/api/v5/get_teacherBuild_info'):
        # 契约：`TeacherBuildSystem:__initData(data)`（:96-122）逐个读这些字段；
        #   `getSectLevelData()`（:512）用 `self.__gbpoint >= v.prosperity` 比大小
        #   ⇒ 少了 gbpoint 就是 `TeacherBuildSystem.lua:518 attempt to compare number with nil`
        #     （本轮实测：师门建设面板能开、但协程被打断，四个"预留资源"全是占位符）。
        #   阈值表 `res/script/family/sectLevel.lua`：0/1540/3180/5790/10110/16230/22750/37150/52450/71950
        return enc_session({'errcode': 0, 'data': {
            'gbpoint': 5790,          # 师门昌盛度 → 对应 sectlevel 4
            'sgbpoint': 0,            # 个人贡献昌盛度
            'reputation': 0,          # 威望
            'renown': 0,              # 资历
            'renownLimit': 100,
            'diligent': 10,           # 加速资源
            'diligentLimit': 100,
            'donate': 0,              # 佳绩
            'featscount': 0,          # 名绩点数
            'taskNumDay': 0,
            'taskNumLimit': 4,
            'guajiInfo': {},
            'familyStates': {},
            'bmaterials1': 0, 'bmaterials2': 0, 'bmaterials3': 0,
            'bmaterials4': 0, 'bmaterials5': 0, 'bmaterials6': 0,
            'dataVer': next_dataver()},
            'rand_t': time.time()}), '★ 师门建设信息（含 gbpoint 等全部数值）'
    if path.endswith('/api/v5/get_teacherBuild_list'):
        # `TeacherBuildSystem:getTeacherBuildData`（:684）→ `setBuildList(data)`，
        #   **data 就是整个应答体**，而 `TeacherBuildListPresenter:setListViewBuildList`
        #   是 `for i,v in ipairs(buildList)`（presenter:52）。
        # ★★ 2026-10-01 关键修复（老板截图：师门建筑面板只有「建筑列表」标题、下面全空）：
        #   以前回的是 `{'list': [...], 'dataVer': N}` ⇒ 客户端 `ipairs` 一个**没有数组部分**的表
        #   ⇒ 遍历 0 次 ⇒ 列表永远是空的（服务端日志还写着"17 种"，所以完全看不出来）。
        #   **这里必须回一个裸数组。**
        # 项结构（她 `TeacherBuildSystem.lua:25-32` 的注释就是权威）：
        #   {buildTypeId="建筑类型id", buildTeacherExp=累计建设值, buildLv=个人开放等级, state=0/1}
        # buildTypeId = `sectBuildInfo.lua` 的 buildingid（100 勤务阁 / 103 论武堂 … 116 易物堂，共 17 种）
        #   ★ `getBuildByExp`（:845）里的 `assert(buildId, ...)` 要求 id 必须能在
        #     `TeacherBuildResManager:getBuildMap()` 里查到 —— 上面这 17 个就是表里的原值。
        _builds = [{'buildTypeId': b, 'buildTeacherExp': 0, 'buildLv': 0, 'state': 0}
                   for b in ('100', '101', '102', '103', '104', '105', '106', '107', '108',
                             '109', '110', '111', '112', '113', '114', '115', '116')]
        return enc_session({'errcode': 0, 'data': _builds,
                            'rand_t': time.time()}), '★ 师门建筑列表（%d 种，裸数组）' % len(_builds)
    if 'fist' in path:
        # `ServerActionSystem.lua:456-471` createFistInfo ⇒ 必须带数字 dataVer；
        # 而且她 `FistFootSystem:initData` 会直接读这些字段（缺一个就 nil 报错、界面冻住）：
        #   accpoint / reflectExp / feelPoint / characterPoint / guajiInfo / branchInfo
        #   branchInfo[10010..10050] = {exp, costTechnique, techniqueList, characterInUse, characterUnused}
        #   （分支 id 取自 `FistFootSystem.lua` 顶部默认表：10010 拳法 / 10020 掌法 / 10030 爪法 / …）
        branch = {}
        for b in ('10010', '10020', '10030', '10040', '10050'):
            branch[b] = {'exp': 0, 'costTechnique': 0, 'techniqueList': [],
                         'characterInUse': [], 'characterUnused': []}
        return enc_session({'errcode': 0, 'data': {
            'dataVer': next_dataver(), 'accpoint': 0, 'reflectExp': 0, 'feelPoint': 0,
            'characterPoint': 0, 'guajiInfo': {}, 'branchInfo': branch},
            'rand_t': time.time()}), '★ 拳脚信息（结构完整，带 dataVer）'

    # 探索模式：没实现的 /api/v5/* 一律宽容回 errcode=0，
    # 好让她客户端继续往下走、把"真正的下一个坎"暴露出来（之后逐个换成正式实现）。
    # ★ data 里必须带数字 dataVer —— 很多"服务端行为"接口都会读它。
    if _permissive and path.startswith('/api/v5/'):
        # ★★ 「动作类」未实现接口**不能假装成功**：
        #   她的写法基本是 `if status==200 then if errcode==0 then <读一堆 data.xxx> ...`
        #   ⇒ 我们回 errcode=0 就等于**逼她走成功分支**去读我们没给的字段 ⇒
        #   `attempt to index/concatenate a nil value` ⇒ 被 xpcall 吞掉 ⇒ **客户端 UI 整体卡死**
        #   （老板已经撞过好几次：家园前往、情报面板…）
        #   回 `errcode=1 + errmsg` 时她走的是 `PopText(errmsg)` 分支 —— **弹一句话，不崩**。
        #   清单由 `work/tmp_gapaudit.py --emit` 生成（只列**确实会读我们没给字段**的动作接口）。
        _ep = path.split('/api/v5/', 1)[-1].split('/')[0].split('?')[0]
        if _ep in _PERMISSIVE_ACTIONS:
            return enc_session({'errcode': 1, 'errmsg': '该功能尚未开放（服务端未实现）',
                                'data': {'dataVer': next_dataver()},
                                'rand_t': time.time()}), \
                '（动作接口未实现 ⇒ 回 errcode=1 让它走 PopText，避免卡死：%s）' % _ep
        return enc_session({'errcode': 0, 'data': {'dataVer': next_dataver(), 'list': [],
                                                   'state': 0},
                            'rand_t': time.time()}), '（宽容应答，未实现）'
    return None


# ================= 单机版激活（2026-10-02）=================
# 只有包里有 license_required.flag（打包时 --danji）才启用门；模拟器/开发包没有 = 无门。
_LICENSE_PUB_N = 84817395460251824800067504544633785894525151522743219339953354708918154629943478756410972044397269296284326113574808886988322709700376022199808366459538387980734036418107735280386181091639428406548175853352142068874385347293213298290723827400874975174116636160592286145431295596675889651451934205511296001031
_LICENSE_PUB_E = 65537
_DANJI = os.path.exists(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'license_required.flag'))
_LICENSE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'license.json')
_ADMIN_URL = 'http://134.175.113.201:8966'   # 管理服务端（设备状态面板 + 拉黑）


def _fz_device_code():
    """设备码：android_id + 机型指纹 的 sha256 前 16 位，4x4 分组。无需任何权限。"""
    aid, fp = '', ''
    try:
        import subprocess
        aid = subprocess.run(['settings', 'get', 'secure', 'android_id'],
                             capture_output=True, timeout=5).stdout.decode().strip()
        fp = subprocess.run(['getprop', 'ro.build.fingerprint'],
                            capture_output=True, timeout=5).stdout.decode().strip()
    except Exception:
        pass
    d = hashlib.sha256((aid + '|' + fp).encode()).hexdigest()[:16].upper()
    return '-'.join(d[i:i + 4] for i in range(0, 16, 4))


def _fz_licensed():
    try:
        with open(_LICENSE_PATH, 'r', encoding='utf-8') as f:
            return json.load(f).get('activated') is True
    except Exception:
        return False


def _fz_verify(device_code, code):
    """公钥验签：加密码 = 生成器私钥对 (WJJH1|设备码规范化) 的 PKCS1v1.5(SHA-256) 签名，base32 分组。"""
    import base64
    try:
        DER = bytes.fromhex('3031300d060960864801650304020105000420')
        norm = ''.join(ch for ch in device_code.upper() if ch.isalnum())
        sig = base64.b32decode(code.replace('-', '').replace('=', ''))
        kb = pow(int.from_bytes(sig, 'big'), _LICENSE_PUB_E, _LICENSE_PUB_N).to_bytes(128, 'big')
        t = DER + hashlib.sha256(('WJJH1|' + norm).encode()).digest()
        expect = b'\x00\x01' + b'\xff' * (128 - len(t) - 3) + b'\x00' + t
        return kb == expect
    except Exception:
        return False


def _fz_banned():
    try:
        with open(_LICENSE_PATH, 'r', encoding='utf-8') as f:
            return json.load(f).get('banned') is True
    except Exception:
        return False


def _fz_allowed():
    try:
        with open(_LICENSE_PATH, 'r', encoding='utf-8') as f:
            return json.load(f).get('allowed') is True
    except Exception:
        return False


def _fz_heartbeat():
    """向管理服务端报到（设备码/机型/版本），拉黑状态写回本地。失败保持原状（离线可玩）。"""
    try:
        import subprocess
        import urllib.request
        model = ''
        try:
            model = subprocess.run(['getprop', 'ro.product.model'],
                                   capture_output=True, timeout=5).stdout.decode().strip()
        except Exception:
            pass
        req = urllib.request.Request(
            _ADMIN_URL + '/fz_report',
            data=json.dumps({'device_code': _fz_device_code(), 'model': model,
                             'app': '单机版v2'}).encode('utf-8'),
            headers={'Content-Type': 'application/json'})
        with urllib.request.urlopen(req, timeout=8) as r:
            out = json.loads(r.read().decode('utf-8'))
        try:
            with open(_LICENSE_PATH, 'r', encoding='utf-8') as f:
                st = json.load(f)
        except Exception:
            st = {}
        st['banned'] = out.get('banned') is True
        st['allowed'] = out.get('allowed') is True
        with open(_LICENSE_PATH, 'w', encoding='utf-8') as f:
            json.dump(st, f)
    except Exception:
        pass


def _fz_heartbeat_loop():
    while True:
        _fz_heartbeat()
        time.sleep(6 * 3600)


_LAST_HB = [0.0]


def _fz_heartbeat_async():
    """心跳放后台线程：/fz_license 必须秒回（客户端 XHR 只有 10 秒超时，
    曾经同步等心跳导致响应超时被客户端掐断 → 空响应 → 激活页永远黑屏）。"""
    import threading

    def _run():
        try:
            with _HB_LOCK:
                if time.time() - _LAST_HB[0] < 60:
                    return
                _LAST_HB[0] = time.time()
            _fz_heartbeat()
        except Exception:
            pass

    try:
        threading.Thread(target=_run, daemon=True).start()
    except Exception:
        pass


import threading as _threading

_HB_LOCK = _threading.Lock()


if _DANJI:
    try:
        import threading
        threading.Thread(target=_fz_heartbeat_loop, daemon=True).start()
    except Exception:
        pass


def official_host(path):
    if path.startswith('/v1/'):
        return UPDATE_HOST, False
    return API_HOST, True


def sign_headers(path, body):
    """给响应算它要的签名头（见 SIG_EXEMPT 上面的说明）。

    ★ 只给 `/api/v5/*` 加：那才是她 **Lua Http 层**发的请求。
      `/v1/checkUpdate`、`/v1/getMd5List` 是**引擎自己的更新通道**（C++），
      给它加自定义头会把更新流程卡住（本轮实测：加完就停在 getMd5List）。
    """
    if not path.startswith('/api/v5/'):
        return {}
    if any(k in path for k in SIG_EXEMPT):
        return {}
    t = '%.4f' % time.time()
    n = binascii.hexlify(os.urandom(6)).decode('ascii')
    raw = body if isinstance(body, bytes) else str(body).encode('utf-8')
    sig = hashlib.md5(t.encode() + b'&' + n.encode() + b'&' + raw
                      + b'&' + SESSION.get('token', '').encode()).hexdigest()
    return {'time': t, 'nonce': n, 'signature': sig}


class Handler(http.server.BaseHTTPRequestHandler):
    # ★ HTTP/1.1 长连接：HTTP/1.0 每响应即断，游戏 Java 连接池会拿到已被服务端
    #   关闭的死连接 → 请求写进死Socket → 客户端 30 秒超时收不到任何响应
    #   （单机版拆包后主界面卡「请稍后/无法点击」的根因，2026-10-02）。
    protocol_version = 'HTTP/1.1'

    protocol_version = 'HTTP/1.1'
    server_version = 'FzBootServer/2.0'

    def log_message(self, fmt, *args):
        pass

    def _read_body(self):
        n = int(self.headers.get('Content-Length') or 0)
        return self.rfile.read(n) if n > 0 else b''

    def _handle(self, method):
        # ★ `self.path` 含查询串，`path` 只是路径。`/__probe/xxx?a=b` 靠 `self.path`
        #   取参数（客户端真机是 POST JSON 正文，不受影响）。
        full = self.path
        path = urllib.parse.urlsplit(full).path
        body = self._read_body()
        ts = time.strftime('%H:%M:%S')
        lines = ['=== %s  %s  %s %s' % (ts, self.client_address[0], method, self.path)]
        # 全部请求头都记（她很多接口把 userid/ver 之类放在头里，例如 create_account 的 userid=-1/-3）
        for k, v in self.headers.items():
            if k.lower() in ('host', 'accept-encoding', 'connection'):
                continue
            lines.append('    req.hdr  %s: %s' % (k, v))
        lines.append('    req.body len=%d hex=%s' % (len(body), hex_or_empty(body, 1200)))

        # 给状态页记账（环形缓冲，最多 40 条）
        try:
            _ring_add((ts, self.client_address[0], method, path))
        except Exception:                              # noqa: BLE001
            pass

        # ★ 状态页：手机/电脑浏览器直接看，不用 Termux、不用签名
        if path in ('/', '/status', '/status/', '/health'):
            append_log('    >>> 状态页')
            self._reply(200, status_page().encode('utf-8'), 'text/html;charset=utf-8')
            return

        # ★ 江湖钱庄桥（三世界货币互通 v1，2026-10-05）：MUD(FluffOS) socket→HTTP 调用。
        #   明文 GET + key token；逻辑在 fz_api/bridge_bank.py（热加载，改完不用重启私服）。
        if path == '/bridge/bank':
            qs = urllib.parse.parse_qs(urllib.parse.urlsplit(full).query)
            try:
                # bridge_bank 无 ENDPOINTS 不进 load_modules 的 reload 名单，这里显式热加载
                import importlib as _il, sys as _sys, fz_api as _fz
                if 'fz_api.bridge_bank' in _sys.modules:
                    _il.reload(_sys.modules['fz_api.bridge_bank'])
                from fz_api import bridge_bank as _bb
                out = _bb.handle(HERE, lambda m: append_log('    [钱庄桥] ' + str(m)), qs)
            except Exception as _be:       # noqa: BLE001
                out = {'errcode': 500, 'errmsg': 'bridge: %r' % _be}
            append_log('\n'.join(lines) + '\n    >>> 钱庄桥 %s -> %s' % (full, out))
            self._reply(200, json.dumps(out).encode('utf-8'), 'application/json;charset=utf-8')
            return

        # ★ 单机版激活接口（license_required.flag 存在才有效；模拟器/开发包没有 = 无门直通）
        if path in ('/fz_license', '/fz_activate'):
            dc = _fz_device_code()
            if path == '/fz_license':
                _fz_heartbeat_async()
                act = (_fz_licensed() or _fz_allowed()) is True
                out = {'activated': act, 'device_code': dc, 'danji': _DANJI is True,
                       'banned': _fz_banned() is True, 'allowed': _fz_allowed() is True}
            else:
                body_obj = {}
                try:
                    body_obj = json.loads(_decode_client_body(body) or '{}')
                except Exception:
                    pass
                okk = _fz_verify(dc, str(body_obj.get('code') or '')) and not _fz_banned()
                if okk:
                    with open(_LICENSE_PATH, 'w', encoding='utf-8') as f:
                        json.dump({'activated': True, 'device_code': dc}, f)
                    _fz_heartbeat_async()
                out = {'activated': okk is True, 'device_code': dc,
                       'errcode': 0 if okk else 1, 'errmsg': '激活成功' if okk else '加密码不匹配'}
            append_log('\n'.join(lines) + '\n    >>> 激活接口 %s -> activated=%s' % (path, out.get('activated')))
            self._reply(200, json.dumps(out).encode('utf-8'), 'application/json;charset=utf-8')
            return

        # ★ 单机版总闸：未激活 或 已被拉黑 时，游戏内容接口一律拒绝。
        #   启动必需的无害接口（时间/配置/资源清单/密钥交换）走白名单放行，
        #   否则客户端卡死在「版本更新中」，激活页根本出不来（2026-10-02 实测踩坑）。
        _BOOT_OK = ('get_time', 'getwebconfig', 'exchange_publickey', 'getmd5list',
                    'checkupdate', 'get_token', 'get_partition_list2')
        if _DANJI and (not (_fz_licensed() or _fz_allowed()) or _fz_banned()) and path.startswith('/api/'):
            if path.rsplit('/', 1)[-1].lower() not in _BOOT_OK:
                append_log('\n'.join(lines) + '\n    >>> 激活闸拦截 %s' % path)
                self._reply(200, json.dumps({'errcode': -999, 'errmsg': '未激活，请先激活'}).encode('utf-8'),
                            'application/json;charset=utf-8')
                return

        # 0) 单点实验用的静态应答优先
        ap = os.path.join(ANSWERS_DIR, name_of(path) + '.bin')
        if os.path.exists(ap):
            with open(ap, 'rb') as f:
                resp = f.read()
            lines.append('    >>> boot_answers 接管 %s len=%d' % (os.path.basename(ap), len(resp)))
            hdrs = sign_headers(path, resp)
            append_log('\n'.join(lines))
            self._reply(200, resp, 'application/json;charset=utf-8', hdrs)
            return

        # 0.5) ★ 自检探针：`/__probe/<接口名>` —— 直接走一遍我们的应答，**明文**返回，
        #      方便一次性把几十个接口全测一遍（不用点模拟器）。
        #      可选 `?a=1&b=2` 作为上行参数（会拼成 JSON 正文）。
        #      ★ 注意：**不要在这里 import urllib**（函数里一旦出现 `import urllib.parse`，
        #        `urllib` 就成了本函数的局部名，上面那句 `urlsplit` 会 UnboundLocalError）。
        if path.startswith('/__probe/'):
            u = urllib.parse.urlparse(full)
            ep = u.path.split('/__probe/', 1)[1].strip('/')
            q = urllib.parse.parse_qs(u.query)
            body_obj = {k: (v[0] if len(v) == 1 else v) for k, v in q.items()}
            fake_body = json.dumps(body_obj).encode('utf-8') if body_obj else b''
            out = {'endpoint': ep, 'sent': body_obj}
            try:
                r = dynamic_answer('/api/v5/' + ep, self.headers, fake_body)
            except Exception as e:                   # noqa: BLE001
                out['error'] = repr(e)
                r = None
            if r is None or r[0] is None:
                out['handled'] = False
            else:
                out['handled'] = True
                out['note'] = r[1]
                try:
                    _full = fzc.decrypt(r[0]).decode('utf-8', 'replace')
                    out['len'] = len(_full)
                    try:
                        out['errcode'] = json.loads(_full).get('errcode')
                    except Exception:            # noqa: BLE001
                        out['errcode'] = '?'
                    # ★ 以前截到 4000 字，结果"内容是空列表"这种问题**看不出来**
                    #   （商城四页签里 `items:[]` 排在 3000 多字之后，正好被切掉，
                    #   所以老板截图报"都是空的"时，我的对账脚本还是绿的）。
                    #   现在整段都给（真要用 `/__probe/` 看大应答也无所谓）。
                    out['plain'] = _full
                except Exception as e:               # noqa: BLE001
                    out['plain_error'] = repr(e)
            payload = json.dumps(out, ensure_ascii=False, indent=1).encode('utf-8')
            self._reply(200, payload, 'application/json;charset=utf-8')
            return

        # 1) 我们自己的应答
        if not _relay_only:
            try:
                got = dynamic_answer(path, self.headers, body)
            except Exception as e:                       # noqa: BLE001
                got = None
                lines.append('    !! 生成应答失败 %r' % e)
                # ★ 2026-10-01：把 traceback 写进 boot_log.txt（stdout 在设备上看不到）
                try:
                    import traceback as _tb2
                    for _ln in _tb2.format_exception(type(e), e, e.__traceback__):
                        for _s in _ln.rstrip('\n').split('\n'):
                            lines.append('    !! ' + _s)
                except Exception:                        # noqa: BLE001
                    pass
            if got is not None and got[0] is not None:
                resp, why = got
                if SESSION['key'] is None or 'exchange_publickey' in path:
                    new_session()
                lines.append('    >>> 我们自己的应答：%s len=%d' % (why, len(resp)))
                hdrs = sign_headers(path, resp)
                if hdrs:
                    lines.append('    >>> 已附签名头 time/nonce/signature')
                append_log('\n'.join(lines))
                self._reply(200, resp, 'application/json;charset=utf-8', hdrs)
                return

        if not _relay:
            lines.append('    >>> 未接管且 --no-relay => 404')
            append_log('\n'.join(lines))
            self._reply(404, b'')
            return

        # 2) 转发官方 + 落盘（按会话分目录）
        #    ★ 安全闸门（2026-09-29 事故）：写方法默认永不外发。
        #      官方服务器上那个账号是老板的真实账号，POST 出去就等于替他对官方做操作。
        if method != 'GET' and not _relay_writes:
            lines.append('    >>> 未接管；但 %s 是写方法，安全闸门拦住，不外发官方 => 404' % method)
            append_log('\n'.join(lines))
            self._reply(404, b'')
            return
        host, use_tls = official_host(path)
        fwd = {k: v for k, v in self.headers.items() if k.lower() not in HOP_HEADERS}
        fwd['Accept-Encoding'] = 'identity'
        try:
            conn = (http.client.HTTPSConnection(host, timeout=25, context=ssl.create_default_context())
                    if use_tls else http.client.HTTPConnection(host, timeout=25))
            conn.request(method, self.path, body=body, headers=fwd)
            r = conn.getresponse()
            resp = r.read()
            code = r.status
            lines.append('    <<< 官方 %s code=%d len=%d ct=%s'
                         % (host, code, len(resp), r.getheader('Content-Type')))
            lines.append('    resp.body hex=%s' % hex_or_empty(resp))
            if SESSION['dir'] is None:
                new_session()
            with open(os.path.join(SESSION['dir'], name_of(path) + '.bin'), 'wb') as f:
                f.write(resp)
            conn.close()
        except Exception as e:                           # noqa: BLE001
            lines.append('    <<< 转发失败 %r' % e)
            append_log('\n'.join(lines))
            self._reply(502, b'')
            return

        append_log('\n'.join(lines))
        # 转发回来的官方响应也要按**我们的 token** 重新签名，否则客户端会判 1003
        self._reply(code, resp, extra=sign_headers(path, resp))

    def _reply(self, code, body, ctype='application/octet-stream', extra=None):
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(body)))
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.send_header('Connection', 'close')
        self.end_headers()
        if body:
            self.wfile.write(body)

    def do_GET(self):
        self._handle('GET')

    def do_POST(self):
        self._handle('POST')


class Server(http.server.ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def main():
    global _port, _relay, _relay_writes, _relay_only, _permissive, ROLE_MODE, OUR_SKIN
    ap = argparse.ArgumentParser()
    ap.add_argument('--port', type=int, default=7900)
    ap.add_argument('--relay', action='store_true',
                    help='【危险】允许把未接管的 GET 请求转发官方；默认关。会碰到老板的真实账号，'
                         '只在对照协议时短开，且写方法仍被闸门拦住')
    ap.add_argument('--relay-writes', action='store_true',
                    help='【极其危险】连写方法也转发官方；正常开发永远不要打开')
    ap.add_argument('--no-relay', action='store_true', help='(已废弃，现在是默认行为) 不转发官方')
    ap.add_argument('--relay-only', action='store_true', help='只当记录代理，全部转发官方')
    ap.add_argument('--strict', action='store_true',
                    help='未实现的 /api/v5/* 不宽容应答（转发官方/404），便于看真实缺口')
    ap.add_argument('--role', choices=('official', 'ours'), default='official',
                    help='角色来源：official=客户端上传的那份；ours=work/roles/full.json（功能全开）')
    ap.add_argument('--skin', default='uijiemian1',
                    help='主界面皮肤 uiId：default / uijiemian1..6（她的 UISkinlistConfig）')
    ap.add_argument('--snapshot-only', action='store_true',
                    help='只存一份存档快照然后退出（给计划任务用）')
    ap.add_argument('--no-snapshot', action='store_true', help='启动时不存存档快照')
    a = ap.parse_args()
    _port = a.port
    _relay = (a.relay or a.relay_only) and not a.no_relay
    _relay_writes = a.relay_writes
    _relay_only = a.relay_only
    _permissive = not a.strict
    ROLE_MODE = a.role
    OUR_SKIN = a.skin
    if _relay_writes:
        log('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
        log('!! --relay-writes 已打开：写请求会被转发到官方服务器        !!')
        log('!! 这会把私服数据写进官方账号（2026-09-29 事故就是这么来的）!!')
        log('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
    elif _relay:
        log('!! --relay 已打开：未接管的 GET 会转发官方（写方法已拦）')

    # ★ 续用上次的会话密钥：重启服务端时，正在玩的客户端不会因为 key 变了而全部请求失败
    k = load_session_key()
    if k:
        SESSION['key'] = k
        log('续用已保存的会话密钥 FZJH03 key=%s（客户端可无缝继续）' % k.decode('ascii'))
    tok = load_session_token()
    if tok:
        SESSION['token'] = tok
        log('续用已保存的 token=%s' % tok)

    for d in (ANSWERS_DIR, CAPTURE_DIR, TEMPLATE_DIR):
        os.makedirs(d, exist_ok=True)
    log('监听 0.0.0.0:%d relay=%s relay_writes=%s relay_only=%s 日志=%s'
        % (_port, _relay, _relay_writes, _relay_only, LOG_PATH))
    if not _relay:
        log('★ 对外零外发：没接管的接口一律本地 404，绝不转发官方（官方账号安全）')

    # ★ 存档快照：老板 2026-09-29 问"能不能回到昨天" ⇒ 至少要保证**我们自己**有这个能力。
    #   每次启动存一份（同一天只存一份，不覆盖），放在 work/backups/<日期>/。
    #   还原： python fz_snapshot.py --restore <日期>
    if not a.no_snapshot:
        try:
            import fz_snapshot
            fz_snapshot.snapshot()
        except Exception as e:                       # noqa: BLE001
            log('存档快照失败（不影响服务）：%r' % e)
    if a.snapshot_only:
        return
    try:
        Server(('0.0.0.0', _port), Handler).serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == '__main__':
    main()
