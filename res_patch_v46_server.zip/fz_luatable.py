# -*- coding: utf-8 -*-
"""一个够用的 Lua 表字面量解析器（只吃她 `res/script/**` 那种 `return {...}` 数据文件）。

支持：
  ["key"]=value   /   key=value        （key 含中文、字母数字）
  value: [[长字符串]] / "字符串" / 数字 / true / false / {..} / {} / 负数 / 小数
不支持：函数、表达式运算（这些数据文件里没有）。
"""
import re
import sys

sys.stdout.reconfigure(encoding='utf-8')

_WS = ' \t\r\n'

# ★ 性能：老写法是 `re.match(pat, self.s[self.i:])`，**每次都对剩余全文切片**，
#   在 1.4MB 的 `mapItemAttr/Items.lua` 上是 O(n²)，实测要 24 秒。
#   改成 `PAT.match(self.s, self.i)`（带 pos，不切片）+ 编译一次，同一份表 <1 秒。
_RE_NUM = re.compile(r'-?\d+\.?\d*(?:[eE][-+]?\d+)?')
_RE_WORD = re.compile(r'(true|false|nil)')
_RE_NAME = re.compile(r'[A-Za-z_][A-Za-z0-9_]*')
_RE_WS = re.compile(r'[ \t\r\n]*')
_RE_LONG_OPEN = re.compile(r'\[(=*)\[')


class LuaParser:
    def __init__(self, text):
        self.s = text
        self.i = 0

    # ---------- 低层 ----------
    def skip(self):
        m = _RE_WS.match(self.s, self.i)
        self.i = m.end()

    def peek(self):
        return self.s[self.i] if self.i < len(self.s) else ''

    def expect(self, ch):
        self.skip()
        if self.peek() != ch:
            raise ValueError('位置 %d 期望 %r 但看到 %r' % (self.i, ch, self.s[self.i:self.i + 40]))
        self.i += 1

    # ---------- 值 ----------
    def long_level(self, pos=None):
        """`[[` / `[=[` / `[==[` … 返回等号个数（0/1/2…），不是长括号就返回 -1。

        ★ 她 `mapItemAttr/Items.lua` 里大量出现 `[=[这是一个檀木箱子…]=]` ——
          只认 `[[` 的旧写法会在第一个 `]=]` 处崩（实测位置 1412045）。
        """
        p = self.i if pos is None else pos
        if p >= len(self.s) or self.s[p] != '[':
            return -1
        m = _RE_LONG_OPEN.match(self.s, p)
        return len(m.group(1)) if m else -1

    def parse_value(self):
        self.skip()
        c = self.peek()
        if c == '{':
            return self.parse_table()
        if c == '[':
            p = self.i
            m = _RE_LONG_OPEN.match(self.s, p)
            if m:
                return self.parse_long_string()
        if c == '"' or c == "'":
            return self.parse_quoted()
        m = _RE_NUM.match(self.s, self.i)
        if m:
            txt = m.group(0)
            self.i = m.end()
            return float(txt) if ('.' in txt or 'e' in txt or 'E' in txt) else int(txt)
        m = _RE_WORD.match(self.s, self.i)
        if m:
            self.i = m.end()
            return {'true': True, 'false': False, 'nil': None}[m.group(1)]
        raise ValueError('位置 %d 不认识的值: %r' % (self.i, self.s[self.i:self.i + 40]))

    def parse_long_string(self):
        lv = self.long_level()
        if lv < 0:
            raise ValueError('位置 %d 不是长字符串' % self.i)
        open_len = lv + 2
        close = ']' + '=' * lv + ']'
        end = self.s.find(close, self.i + open_len)
        if end < 0:
            raise ValueError('长字符串没有结束的 %s' % close)
        val = self.s[self.i + open_len:end]
        if val.startswith('\r\n'):          # Lua 会吃掉紧跟开括号的第一个换行
            val = val[2:]
        elif val.startswith('\n'):
            val = val[1:]
        self.i = end + len(close)
        return val

    def parse_quoted(self):
        q = self.s[self.i]
        self.i += 1
        s = self.s
        n = len(s)
        buf = []
        pos = self.i
        while pos < n:
            j = s.find(q, pos)
            if j < 0:
                break
            # 数一下这个引号前面有几个连续反斜杠：偶数个就是真结束
            k = j - 1
            bs = 0
            while k >= pos - 1 and k >= 0 and s[k] == '\\':
                bs += 1
                k -= 1
            if bs % 2 == 0:
                buf.append(s[pos:j])
                self.i = j + 1
                return ''.join(buf)
            buf.append(s[pos:j + 1])
            pos = j + 1
        self.i = n
        return ''.join(buf)

    def parse_table(self):
        self.expect('{')
        arr, mp = [], {}
        n = 0
        while True:
            self.skip()
            if self.peek() == '}':
                self.i += 1
                break
            key = None
            # ["k"]=  /  [=[k]=]=  /  k=   /  [1]=
            if self.peek() == '[' or self.peek() in '"\'':
                save = self.i
                if _RE_LONG_OPEN.match(self.s, self.i):
                    k = self.parse_long_string()
                elif self.peek() == '[':
                    self.i += 1
                    k = self.parse_value()
                    self.expect(']')
                    self.skip()
                    if self.peek() == '=':
                        self.i += 1
                        key = k
                    else:
                        self.i = save
                        key = None
                    val = self.parse_value()
                    if key is None:
                        n += 1
                        arr.append(val)
                    else:
                        mp[key] = val
                    self.skip()
                    if self.peek() in ',;':
                        self.i += 1
                    continue
                else:
                    k = self.parse_quoted()
                self.skip()
                if self.peek() == '=':
                    self.i += 1
                    key = k
                else:                       # 不是键，是个数组元素
                    self.i = save
                    key = None
            else:
                m = _RE_NAME.match(self.s, self.i)
                if m:
                    save = self.i
                    name = m.group(0)
                    self.i = m.end()
                    self.skip()
                    if self.peek() == '=':
                        self.i += 1
                        key = name
                    else:
                        self.i = save
                        key = None
                else:
                    key = None

            val = self.parse_value()
            if key is None:
                n += 1
                arr.append(val)
            else:
                mp[key] = val
            self.skip()
            if self.peek() == ',' or self.peek() == ';':
                self.i += 1
        if arr and not mp:
            return arr
        if arr:
            for idx, v in enumerate(arr, 1):
                mp[idx] = v
        return mp


def load_lua_table(path):
    with open(path, encoding='utf-8', errors='replace') as f:
        text = f.read()
    m = re.search(r'return\s*\{', text)
    if not m:
        raise ValueError('不是 `return {...}` 文件: %s' % path)
    p = LuaParser(text)
    p.i = m.end() - 1
    return p.parse_table()


if __name__ == '__main__':
    t = load_lua_table(sys.argv[1])
    if len(sys.argv) > 2:
        for k in sys.argv[2:]:
            t = t[k]
    import json
    print(json.dumps(t, ensure_ascii=False, indent=1)[:4000])
