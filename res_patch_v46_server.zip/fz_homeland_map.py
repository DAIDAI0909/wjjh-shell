# -*- coding: utf-8 -*-
# ================= 离线包路径根（fz_make_offline_bundle.py 自动注入） =================
# 手机上整个服务端就是一个目录，表在哪、状态写哪，全部相对包根算。
# （有的模块原来把绝对路径写死，本身没 import os —— 这里一并补上）
import os
import os as _osp


def _off_find_bundle(_f):
    """从模块所在目录往上找包根（认 fz_boot_server.py）。
    ★ fz_api/*.py 的 __file__ 在 <根>/fz_api/ 下，直接 dirname 会算错一层。"""
    _d = _osp.path.dirname(_osp.path.abspath(_f))
    for _ in range(6):
        if _osp.path.exists(_osp.path.join(_d, 'fz_boot_server.py')):
            return _d
        _u = _osp.path.dirname(_d)
        if _u == _d:
            break
        _d = _u
    return _osp.path.dirname(_osp.path.abspath(_f))


_OFF_BUNDLE = _off_find_bundle(__file__)
_OFF_FZ_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_fz')
_OFF_INK_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_ink')
_OFF_WORK_ROOT = _OFF_BUNDLE
# =====================================================================================
# -*- coding: utf-8 -*-
"""家园（玩家副本）地图生成器 —— 把 `get_user_map` 的应答真正造出来。

★ 为什么必须自己造：
  `UserMap:initUserMap`（`app/models/map/UserMap.lua:107`）用应答里的
  `mapInfo.usermap` + `mapInfo.maproom` 现拼一张地图。客户端**没有** fb319 这类地图文件
  （`res/script/newmap/map/maps/fb319.lua` 不存在），所以家园地图 100% 由服务端下发。
  回空壳 ⇒ `initUserMap` 返回 nil ⇒ `BaseItem.lua:1271 map._isComingIn` 报
  `attempt to index local 'map'` ⇒ 被 xpcall 吞掉 ⇒ **客户端 UI 整体卡死**（点了没反应）。

★ 数据来源（全是她自己的表）：
  `res/script/others/familylist.lua`
      ["房契模板"]   fqId → {hxId(户型), roomid(房间类型分号表), roomnum, name, typedsc}
      ["普通房间"]   ptfangjianNNN → {name, desc, stepMusic}
      ["特殊房间类型"] 1..26 → {roomtype, admit}   （tsfangjianNNN 的 NNN 就是这张表的键）
      ["房屋地皮"]   dpId → {name, place, fbId, ...}（地址文本）
  `res/script/others/familytype.lua`
      huxingNNN → { "1".."N" → {roomId(fjId), name, up/down/left/right..., specialid} }
"""
import json
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fz_luatable import load_lua_table          # noqa: E402

RES = os.path.join(_OFF_FZ_ROOT, 'res', 'script', 'others')
_FAMILY = os.path.join(RES, 'familylist.lua')
_TYPE = os.path.join(RES, 'familytype.lua')
_STATE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'homeland.json')

_cache = {}

LINK_KEYS = ('center', 'left', 'leftUp', 'up', 'rightUp', 'right', 'rightDown', 'down', 'leftDown')
# 方向 → 坐标偏移（y 向上为正）
OFFSET = {
    'up': (0, 1), 'down': (0, -1), 'left': (-1, 0), 'right': (1, 0),
    'leftUp': (-1, 1), 'rightUp': (1, 1), 'leftDown': (-1, -1), 'rightDown': (1, -1),
    'center': (0, 0),
}


def _tables():
    if not _cache:
        fam = load_lua_table(_FAMILY)
        typ = load_lua_table(_TYPE)
        _cache['fq'] = fam.get('房契模板') or {}
        _cache['pt'] = fam.get('普通房间') or {}
        _cache['ts'] = fam.get('特殊房间类型') or {}
        _cache['dp'] = fam.get('房屋地皮') or {}
        _cache['hx'] = typ
    return _cache


def list_houses():
    """所有可买房型：fqId / 名称 / 户型 / 房间数 / 售价。"""
    t = _tables()
    out = []
    for _, v in t['fq'].items():
        out.append({'fqId': v.get('fqId'), 'name': re.sub(r'(HIY|NOR|HIW|HIG|HIR|HIB|CYN|YEL|PNK)', '', v.get('name') or ''),
                    'hxId': v.get('hxId'), 'roomnum': v.get('roomnum'), 'cost': v.get('cost')})
    return out


def find_fq(fq_id):
    t = _tables()
    for _, v in t['fq'].items():
        if v.get('fqId') == fq_id:
            return v
    return None


def fq_by_mid(mid):
    """我们在 `work/homeland.json` 里记的 mid→fqId。

    没有记录时回 `default`（服务端会把它设成老板真实那张房契），再兜底 `yangzhou001`。
    """
    try:
        with open(_STATE, encoding='utf-8') as f:
            d = json.load(f)
        return d.get(str(mid)) or d.get('default') or 'yangzhou001'
    except Exception:                       # noqa: BLE001
        return 'yangzhou001'


def fq_by_mid_exact(mid):
    """只认**明确登记过**的 mid（给服务端判断要不要补登记用）。"""
    try:
        with open(_STATE, encoding='utf-8') as f:
            d = json.load(f)
        return d.get(str(mid))
    except Exception:                       # noqa: BLE001
        return None


def _pick_dp(fq_id):
    """给家园挑一块**真实存在**的地皮（`房屋地皮` 的键就是 dpId）。

    优先同名（`yangzhou003` 的房一般配 `yangzhou003` 的地）；没有就退到同城第一块。
    `outDoorByDp` 会拿 `dpRoomId`（`fb301;fb301_215`）当"屋外"的出口。
    """
    dp = _tables()['dp']
    if fq_id in dp:
        return fq_id
    # 键是 "1","10",... 数字串，值是 dpId；按 dpId 名字近似匹配
    for _, v in dp.items():
        if v.get('dpId') == fq_id:
            return fq_id
    for _, v in dp.items():
        if str(v.get('dpId') or '').startswith('yangzhou'):
            return v.get('dpId')
    for _, v in list(dp.items())[:1]:
        return v.get('dpId') or ''
    return ''


def set_mid(mid, fq_id):
    try:
        with open(_STATE, encoding='utf-8') as f:
            d = json.load(f)
    except Exception:                       # noqa: BLE001
        d = {}
    d[str(mid)] = fq_id
    d.setdefault('default', fq_id)
    try:
        with open(_STATE, 'w', encoding='utf-8') as f:
            json.dump(d, f, ensure_ascii=False, indent=1)
    except OSError:
        pass
    return d


def _type_maps():
    if 'rev_ts' not in _cache:
        t = _tables()
        rev_ts, rev_pt = {}, {}
        for k, v in t['ts'].items():
            rev_ts.setdefault((v.get('roomtype') or '').strip(), 'tsfangjian%03d' % int(k))
        for k, v in t['pt'].items():
            rev_pt.setdefault((v.get('name') or '').strip(), v.get('roomid'))
        _cache['rev_ts'], _cache['rev_pt'] = rev_ts, rev_pt
    return _cache['rev_ts'], _cache['rev_pt']


def room_type_of(hx_room, tpl, ridx):
    """房间类型（她 UI 靠 `roomType` 决定标题/特殊功能）。

    ★ 判定顺序（`familylist.房契模板.roomid` 那张分号表**顺序本身和她 familytype
      对不上**——huxing002 里 练功房/仓库 就是反的，所以不能只按下标吃）：
        1. `familytype` 自己写了 `roomType`（长廊 = `ptfangjian001`）→ 直接用
        2. 按房间**名字**反查 `特殊房间类型`（练功房→`tsfangjian009`、卧室→`tsfangjian011`）
        3. 按名字反查 `普通房间`
        4. 都不中 ⇒ 才按下标去吃 `房契模板.roomid` 的池子
    """
    if hx_room.get('roomType'):
        return hx_room['roomType'], ridx
    rev_ts, rev_pt = _type_maps()
    name = (hx_room.get('name') or '').strip()
    if name in rev_ts:
        return rev_ts[name], ridx
    if name in rev_pt:
        return rev_pt[name], ridx
    seq = [s for s in (tpl.get('roomid') or '').split(';') if s]
    if ridx < len(seq):
        return seq[ridx], ridx + 1
    return None, ridx


def room_desc(rtype, name):
    t = _tables()
    if rtype and rtype.startswith('pt'):
        e = t['pt'].get(rtype) or {}
        if e.get('desc'):
            return e['desc']
    if rtype and rtype.startswith('ts'):
        num = rtype.replace('tsfangjian', '')
        e = t['ts'].get(str(int(num))) or t['ts'].get(num) or {}
        if e.get('roomtype'):
            return '这里是%s。' % e['roomtype']
    return '这里是%s。' % (name or '房间')


def _rooms_of(hx):
    """把一张户型表摊成**有序房间列表**。

    ★★ 2026-10-01 关键修复（老板："一键提升之后家园还是很小 / 去扬州网络错误"）：
      各户型的键**不是同一种**：
        · huxing001/002/004/010 …  键是序号 `"1" "2" "3"` …
        · **huxing011 / huxing012（顶级户型）** 键是 **roomId**（`fb317_01` / `fb318_01` …）
      老代码只收 `str(k).isdigit()` ⇒ 顶级户型摊出来是**空表** ⇒ 一路兜底到
      huxing001（5 间房）。老板花大价钱升的"阳口悬钟"（63 间）就变成了 5 间小屋。
      这里两种键都认。
    """
    if not isinstance(hx, dict):
        return []
    digs = [k for k in hx.keys() if str(k).isdigit()]
    if digs:
        out = [dict(hx[k]) for k in sorted(digs, key=lambda x: int(x))]
    else:
        out = []
        for k, v in sorted(hx.items()):
            if isinstance(v, dict):
                r = dict(v)
                # ★ roomId-keyed 那种表里，房间号写在 `id` 字段（`fb318_01`），没有 `roomId`
                r.setdefault('roomId', r.get('id') or k)
                out.append(r)
        return out
    for r in out:
        r.setdefault('roomId', r.get('id'))
    return out


def _layout(hx, rooms, fq_id):
    """按房间连线做 BFS 摆格子，返回 (格子字典, 读序房间id列表)。"""
    by_id = {r['roomId']: r for r in rooms}
    start = None
    for r in rooms:
        if r.get('specialid') == 1:
            start = r
            break
    if start is None:
        start = rooms[0]

    pos = {}
    order = []
    queue = [(start['roomId'], 0, 0)]
    pos[start['roomId']] = (0, 0)
    while queue:
        rid, x, y = queue.pop(0)
        order.append(rid)
        r = by_id.get(rid)
        if not r:
            continue
        for key in LINK_KEYS:
            nb = r.get(key)
            if not isinstance(nb, str) or not nb or nb in pos or nb not in by_id:
                continue
            dx, dy = OFFSET[key]
            pos[nb] = (x + dx, y + dy)
            queue.append((nb, x + dx, y + dy))
    # 连线没覆盖到的房间（数据不全时）补在后面
    for r in rooms:
        if r['roomId'] not in pos:
            pos[r['roomId']] = (max(p[0] for p in pos.values()) + 1, 0)
            order.append(r['roomId'])
    return pos, order, by_id


def _render(hx, rooms, pos, order, by_id):
    """生成 mapAppearance（名字网格）和 mapAppearanceIndex（id 网格）。

    ★ `TotalMapUI:createRoomGroupNode`（:354）断言
      `#roomIdArray == #mapRoomNamePosArray` —— 名字分组数必须 = id 个数，
      所以两张网格要**同一个读序**。
    """
    xs = [p[0] for p in pos.values()]
    ys = [p[1] for p in pos.values()]
    name_lines, id_lines = [], []
    for y in range(max(ys), min(ys) - 1, -1):
        row = sorted([rid for rid, p in pos.items() if p[1] == y], key=lambda r: pos[r][0])
        if not row:
            continue
        names, ids = [], []
        for i, rid in enumerate(row):
            r = by_id[rid]
            names.append(r.get('name') or '房间')
            ids.append(rid)
            del i
        # 相邻两格若有左右连线就用「——」连，否则用全角空格隔开（两者都是她的分隔符）
        line = ''
        for i, rid in enumerate(row):
            if i:
                left = by_id[row[i - 1]]
                linked = left.get('right') == rid or by_id[rid].get('left') == row[i - 1]
                line += '——' if linked else '　'
            line += names[i]
        name_lines.append(line)
        id_lines.append(','.join(ids))
    return '\n'.join(name_lines), '\n'.join(id_lines)


def build_user_map(mid, owner=''):
    """造 `get_user_map` 的 `data`。"""
    fq_id = fq_by_mid(mid)
    tpl = find_fq(fq_id)
    if tpl is None:
        fq_id, tpl = 'yangzhou001', find_fq('yangzhou001')
    hx_id = tpl.get('hxId')
    hx = _tables()['hx'].get(hx_id) or _tables()['hx'].get('huxing001')

    rooms = _rooms_of(hx)
    # ★ 2026-10-01：顶级房型（yangzhou152 → huxing012）**没有房间清单** ⇒ rooms 空
    #   ⇒ `_layout` 里 `rooms[0]` 抛 IndexError ⇒ get_user_map 500/404 ⇒ 客户端
    #   「前往房屋」显示"网络连接失败"。这里兜底：
    #     ① 换一个非空户型（huxing001…）；② 实在没有就给一间默认房 + 一个默认户型，
    #   保证地图永远能生成（宁可简陋也不能整条路挂掉）。
    if not rooms:
        for _alt in ('huxing001', 'huxing002', 'huxing003', 'huxing004'):
            _a = _tables()['hx'].get(_alt)
            if isinstance(_a, dict) and _a:
                hx = _a
                rooms = _rooms_of(_a)
                if rooms:
                    break
    if not rooms:
        hx = {'1': {'roomId': 'fb999_01', 'name': '卧室', 'type': 1}}
        rooms = [dict(hx['1'])]

    pos, order, by_id = _layout(hx, rooms, fq_id)
    app_name, app_index = _render(hx, rooms, pos, order, by_id)

    fq_name = re.sub(r'(HIY|NOR|HIW|HIG|HIR|HIB|CYN|YEL|PNK)', '', tpl.get('name') or '家园')
    dp_id = _pick_dp(fq_id)
    dp = {v['dpId']: v for v in _tables()['dp'].values() if v.get('dpId')}.get(dp_id) or {}
    addr = '%s%s' % (dp.get('place') or '', dp.get('name') or '')
    title = dp.get('name') or fq_name

    maproom = []
    ridx = 0
    for r in rooms:
        rid = r['roomId']
        rtype, ridx = room_type_of(r, tpl, ridx)
        # ★ 家园「屋外」这间要**明确写成"你的宅院"**：
        #   `HomelandRoomUtil:outDoorByDp` 会把屋外的 `name` 改写成城市里那个房间名
        #   （我们家门口就在「扬州大街」上，所以她改成"扬州大街"）⇒ 站在家里标题却和街上一样，
        #   很容易以为自己没进去。标题改不了（是她的代码），但 **desc 是我们的**，写清楚。
        if rtype == 'tsfangjian002':
            desc = '这里是你的宅院（%s·%s），往里走可进门前、大门、各间屋子。' % (
                dp.get('place') or '', dp.get('name') or fq_name)
        else:
            desc = room_desc(rtype, r.get('name'))
        room = {
            'fjId': rid,
            'name': r.get('name') or '房间',
            'roomType': rtype or '',
            'desc': desc,
            'stepMusic': 'jiaobu',
            'dirIndex': 0,
            'connectPoint': 0,
            'permission': 0,
            'enterable': 1,
            'visible': 1,
            'canLeave': 1,
            'mapHide': 0,
            'operations': {},
        }
        for key in LINK_KEYS:
            v = r.get(key)
            if isinstance(v, str) and v:
                room[key] = v
        maproom.append(room)

    # 入口：屋外（specialid=1），兜底第一个
    entry = rooms[0]['roomId']
    for r in rooms:
        if r.get('specialid') == 1:
            entry = r['roomId']
            break

    fq_name = re.sub(r'(HIY|NOR|HIW|HIG|HIR|HIB|CYN|YEL|PNK)', '', tpl.get('name') or '家园')
    # ★ `dpId`（地皮）**必须有**：`HomelandModule:entryMap`（:564）会调
    #   `HomelandRoomUtil:updateDoorOutInfo(map)`：
    #     `if map.dpId and map.dpId ~= "" then outDoorByDp(map)`     ← 走这条就够了
    #     `elseif map.mid then outDoorByNoDp(map)`                   ← 这条要 map.loc_mark[3]/loc_sort
    #   没有 dpId 就会去读 `loc_mark` ⇒ `HomelandRoomUtil.lua:761
    #   attempt to index field 'loc_mark' (a nil value)`（已实测）。
    # ★ `fqId`/`houseName`/`location` 也必须有：`HomelandModule:repairData`（:618-638）会
    #   `if map.fqId ~= fq.fqId then local fqtemplate = getFangQiTemplateById(map.fqId)`
    #   ⇒ map.fqId 为 nil 就 `attempt to index local 'fqtemplate'`（已实测）。
    #   顺带把我们算出来的地址写回 `fq.location`，修掉"你的房屋地址为0"。
    usermap = {
        'mid': int(mid) if str(mid).isdigit() else 0,
        'name': title,
        'mapAppearance': app_name,
        'mapAppearanceIndex': app_index,
        'entryRoom': entry,
        'BGM': 'bgm001',
        'roomnum': len(rooms),
        'dpId': dp_id,
        'fqId': fq_id,
        # ★★ 2026-10-01：**`hxId` 必须有**。管家那排按钮里「户型图」的开关是
        #   `HomelandRoleTemplate.lua:477`：
        #       if openHuXing[map.hxId] == true then openOrCloseBtnFunc(role,"户型图","open")
        #   以前没给 ⇒ `map.hxId` 是 nil ⇒ 白名单查不到 ⇒ **户型图按钮永远不出现**
        #   （老板截图里管家只有 交谈/房屋事务/赏赐/仆人管理）。
        'hxId': hx_id,
        'houseName': title,
        'location': addr,
    }
    return {
        'usermap': usermap,
        'maproom': maproom,
        'roomfurniture': [],
        'roomperson': [],
        'owner': owner or '',
        'ver': 1,
    }


if __name__ == '__main__':
    fqid = sys.argv[1] if len(sys.argv) > 1 else 'yangzhou001'
    mid = sys.argv[2] if len(sys.argv) > 2 else '0'
    if fqid != 'auto':
        os.environ['FZ_FQ'] = fqid
    data = build_user_map(mid)
    um = data['usermap']
    print('户型 =', find_fq(fq_by_mid(mid)).get('hxId'), ' 房间数 =', len(data['maproom']))
    print('--- mapAppearanceIndex ---')
    print(um['mapAppearanceIndex'])
    print('--- mapAppearance ---')
    print(um['mapAppearance'])
    print('--- maproom[0] ---')
    print(json.dumps(data['maproom'][0], ensure_ascii=False))
