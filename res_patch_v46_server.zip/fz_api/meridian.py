# -*- coding: utf-8 -*-
# ================= 离线包路径根（fz_make_offline_bundle.py 自动注入） =================
# 手机上整个服务端就是一个目录，表在哪、状态写哪，全部相对包根算。
# （有的模块原来把绝对路径写死，本身没 import os —— 这里一并补上）
import os
import os as _osp


def _off_find_bundle(_f):
    """从模块所在目录往上找包根（认 fz_boot_server.py）。
    ★ fz_api/*.py 的 __file__ 在 <根>/fz_api/ 下，直接 dirname 会算错一层。"""
    _d = _osp.path.dirname(_osp.path.abspath(_f))
    for _ in range(6):
        if _osp.path.exists(_osp.path.join(_d, 'fz_boot_server.py')):
            return _d
        _u = _osp.path.dirname(_d)
        if _u == _d:
            break
        _d = _u
    return _osp.path.dirname(_osp.path.abspath(_f))


_OFF_BUNDLE = _off_find_bundle(__file__)
_OFF_FZ_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_fz')
_OFF_INK_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_ink')
_OFF_WORK_ROOT = _OFF_BUNDLE
# =====================================================================================
# ★ 2026-10-04 商城空货架修复：客户端资源表解析——PC 开发树优先，设备上自动回退
#   到包内 client_fz 副本（jhserver/client_fz = fangzhi_lua_dec 的同步拷贝）。
def _fz_res(*parts):
    base = os.path.join(_OFF_FZ_ROOT, 'res', 'script')
    if not os.path.isdir(base):
        base = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            '..', 'client_fz', 'res', 'script')
    return os.path.join(base, *parts)

# -*- coding: utf-8 -*-
"""经脉 / 静修室 —— 隐脉（冲穴 · 破境 · 玄络解锁 · 师门指点）+ 修炼 xiuLian / 练功 lianGong。

**契约出处（逐个读过她客户端代码，不是猜的）**

1) `app/models/Meridian/HiddenMeridianSystem/HiddenMeridianSystem.lua`
   | 接口(URL 末段)                    | 她读的 `data.字段`                     | 出处行 |
   |---|---|---|
   | `get_hidden_meridian_info`        | `ygpill`（数字，`..` 直接拼字符串）      | :202  |
   | `start_break_through_realm`       | `count` `version` `currencyVersion`     | :572  |
   | `accelerate_break_through_realm`  | `cost` `count` `version`                | :654  |
   | `finish_break_through_realm`      | `version`                               | :726  |
   | `cancel_break_through_realm`      | `version`                               | :608  |
   | `start_thoroughfare_vessel`       | `count` `version`                       | :824  |
   | `accelerate_thoroughfare_vessel`  | `cost` `count` `version`                | :914  |
   | `finish_thoroughfare_vessel`      | `version`                               | :986  |
   | `cancel_thoroughfare_vessel`      | `version`                               | :866  |
   | `unlock_hidden_meridian_gems`     | `count` `version` `currencyVersion`     | :1042 |
   | `execute_sectGuidance`            | `speedUpTime` `version`                 | :700 / :960 |
   另：`TeacherBuildSystem/Guidance/TeacherGuidance.lua`:126/:143 在指点成功后又读
   `data.guidanceCount`（`setGuidanceCount`）⇒ 本模块一并给出。
   `cost` 被 `"成功使用" .. data.cost .. "个"` 拼接、`speedUpTime` 参与减法 ⇒ **都必须是数字**。

2) `app/models/ServerAction/ServerActionSystem.lua`（修炼 / 练功）
   * `xiuLianStart` / `xiuLianFinish` / `xiuLianUseXingGongSan` /
     `lianGongStart` / `lianGongFinish` / `lianGongUseXingGongSan`
     六个都走 `__saveAction(data.dataVer, ...)`（:116/:137/:156/:213/:234/:253）
     ⇒ **必须回数字 `data.dataVer`**：`:44 setDataVersion` 拿不到数字就 `error()`
       ⇒ 协程被打断 ⇒ 界面卡死（没有弹窗，就是彻底没反应）。
   * `lianGongFinish`:137 / `xiuLianFinish`:234 还把 `data.msg` 交给 `PopText` ⇒ 给字符串。

3) 上行字段（`app/extends/Http/HttpManager.lua`）
   * 隐脉系列 :5646-5756：`get_hidden_meridian_info` 无参(GET)；
     start/unlock `{id, version, currencyVersion}`；accelerate `{id, cost, version}`；
     finish/cancel `{id, version}`；execute_sectGuidance `{familyId, id, version}`。
   * 修炼/练功 :4357-4540：`{requestId, dataVer, codeVer, actionData, time}`，
     其中 `actionData` 是完整的行为数据（见 `XiuLianSystem.lua`:360 / `LianGongSystem.lua`:311）。

**内容（数字）全部来自她自己的表**
   * `res/script/meridian/HiddenMeridian/MeridianMapConfig.lua["玄脉图"]`
       → 破境时长 `time`、破境消耗 `resource`（如 `{{"dmartial",19}}` 功法学识）、下一张图按 `class`+1
   * `res/script/meridian/HiddenMeridian/AcupointConfig.lua["玄脉图"]`
       → 冲穴时长 `time`（如 101→60s、102→7200s）
   * `res/script/meridian/HiddenMeridian/MeridianLinkConfig.lua["玄络"]`
       → 玄络解锁消耗 `resource`（如 `{{"amartial",720},{"bmartial",80}}`）
   * `res/script/others/skill.lua["skills"]` / `others/skillName.lua`
       → 修炼/练功的武学名（`data.msg` 里用）、`potEfficiency`（校验经验用）
   * `res/script/skill/liangongParamsConf.lua["通用参数"]`（14=每秒基础经验 15=属性修正基数）
   * 常量 `app/models/Meridian/HiddenMeridianConstants.lua`：`ResItemId="ygpill"`(养真丹)、`SpeedUpTime=300`

**状态推进**：`work/meridian_state.json`（本模块独占）
   记录 `ygpill`（养真丹）、`version`、当前玄络图 `chartId`、每个图已冲穴的窍关、
   已解锁玄络、冲穴/破境的开始与结束时间、师门指点次数（按自然周重置）、
   修炼/练功的开始时间·时长·行功散次数·结算经验。读到就回真值，动作就改状态。

**已知的取舍（表里查不到 / 依赖别的模块）**
   * 养真丹、行功散、玄络解锁消耗的 `amartial/bmartial/dmartial` 属于物品/货币系统
     （本仓目前没有 items 模块）⇒ 这里只在 `spent` 里**记账**，不做"不够就拒绝"，
     否则按钮点了没反应。养真丹初始给 `YGPILL_INIT`，之后按真实消耗递减。
   * 师门指点次数/减时量在她表里**没有**配置（`featClassLevel.lua` 只有名衔本身，
     `sectBuildEffect.lua` 只有 taskul/materialsul/… 没有指点项，客户端默认值 2 次）
     ⇒ 取 `GUIDANCE_PER_WEEK=2`、`GUIDANCE_SPEEDUP=3600`，要调就改这两个常量。
   * `getXiuLianState/getXiuLianData/getLianGongState/getLianGongData/get_sectGuidance_info`
     不在本模块接口表里，而且 **`fz_boot_server.py`:738-746/:1467 在 fz_api 路由之前就拦掉了**
     （State→`state:0`，Data→`errcode:1`，sectGuidance→`{list,dataVer}`）⇒ 模块改了也接不到。
     现状：登录不卡死，但"修炼/练功中途重登不会恢复会话"；而 `get_sectGuidance_info` 少
     `guidanceCount`/`speedUpTime` ⇒ `TeacherGuidancePresenter:148 getTimeStr(nil)` 会抛错（被吞⇒面板卡死）。
     要修得改 `fz_boot_server.py` 那三处分支；本模块已经把可直接复用的数据留在状态文件里：
     `xiuLian.action` / `lianGong.action`（原样 actionData，回 `{'startAction':{'data': action}}`）、
     `guidanceCount` / `GUIDANCE_SPEEDUP`。
"""
import json
import math
import os
import sys
import time

NAME = 'meridian'
TITLE = '经脉/静修室'
ENDPOINTS = [
    'get_hidden_meridian_info',
    'unlock_hidden_meridian_gems',
    'start_thoroughfare_vessel',
    'finish_thoroughfare_vessel',
    'cancel_thoroughfare_vessel',
    'accelerate_thoroughfare_vessel',
    'start_break_through_realm',
    'finish_break_through_realm',
    'cancel_break_through_realm',
    'accelerate_break_through_realm',
    'execute_sectGuidance',
    'xiuLianStart',
    'xiuLianFinish',
    'xiuLianUseXingGongSan',
    'lianGongStart',
    'lianGongFinish',
    'lianGongUseXingGongSan',
    # ★ 路由已挪到 `fz_boot_server.py` 最前面 ⇒ 这三个读数接口由**本模块**接管
    #   （以前服务端写死：sectGuidance 缺 guidanceCount/speedUpTime ⇒ 师门指点面板
    #    `getTimeStr(nil)` 抛错被 xpcall 吞 ⇒ 卡死；XiuLian/LianGongData 回 errcode=1
    #    ⇒ 修炼/练功中途重登不恢复会话。）
    'get_sectGuidance_info',
    'getXiuLianData',
    'getLianGongData',
]

STATE = 'meridian_state.json'

# ---------------------------------------------------------------------------
# 常量（HiddenMeridianConstants.lua）
# ---------------------------------------------------------------------------
RES_ITEM_ID = 'ygpill'          # 养真丹：加速消耗 & 面板显示的都是它
SPEED_UP_SECONDS = 300          # 一颗养真丹 = 300 秒
YGPILL_INIT = 999               # 养真丹初始值（物品系统还没做，先给足，按钮才真的有用）
GUIDANCE_PER_WEEK = 2           # 师门指点：每周次数（她表里没有，客户端默认 2）
GUIDANCE_SPEEDUP = 3600         # 师门指点：每次减少秒数（她表里没有）
XGS_SECONDS = 3600              # 行功散：`__useXgsCount * 3600`

RES_MERIDIAN = _fz_res('meridian', 'HiddenMeridian')
RES_MAP = os.path.join(RES_MERIDIAN, 'MeridianMapConfig.lua')
RES_ACUPOINT = os.path.join(RES_MERIDIAN, 'AcupointConfig.lua')
RES_LINK = os.path.join(RES_MERIDIAN, 'MeridianLinkConfig.lua')
RES_SKILL = _fz_res('skill', 'skill.lua')
RES_SKILLNAME = _fz_res('others', 'skillName.lua')
RES_LIANGGONG_CONF = _fz_res('skill', 'liangongParamsConf.lua')

_TABLES = {}


# ---------------------------------------------------------------------------
# 她的资源表
# ---------------------------------------------------------------------------


def _lua_table(path):
    """用 `work/fz_luatable.py` 解析她的数据表；失败返回 {}（绝不抛）。"""
    if path in _TABLES:
        return _TABLES[path]
    val = {}
    try:
        try:
            import fz_luatable
        except ImportError:
            sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            import fz_luatable
        val = fz_luatable.load_lua_table(path) or {}
        if not isinstance(val, dict):
            val = {}
    except Exception:                          # noqa: BLE001
        val = {}
    _TABLES[path] = val
    return val


def _charts():
    """`MeridianMapConfig.lua["玄脉图"]` → {chartId: 图配置}。"""
    t = _lua_table(RES_MAP)
    return t.get('玄脉图') or {}


def _chart_by_class(lv):
    for v in _charts().values():
        if v.get('class') == lv:
            return v
    return None


def _acupoints():
    """`AcupointConfig.lua["玄脉图"]` → {acupointId: 窍关配置}。"""
    t = _lua_table(RES_ACUPOINT)
    return t.get('玄脉图') or {}


def _buffs():
    """`MeridianLinkConfig.lua["玄络"]` → {buffId: 玄络配置}。"""
    t = _lua_table(RES_LINK)
    return t.get('玄络') or {}


def _skills():
    t = _lua_table(RES_SKILL)
    return t.get('skills') or {}


def _skill_names():
    t = _lua_table(RES_SKILLNAME)
    return t.get('Sheet1') or {}


def _lg_conf():
    """`liangongParamsConf.lua["通用参数"]` → {id: content}。"""
    t = _lua_table(RES_LIANGGONG_CONF)
    conf = t.get('通用参数') or {}
    out = {}
    for k, v in conf.items():
        try:
            out[str(k)] = float((v or {}).get('content'))
        except (TypeError, ValueError):
            pass
    return out


def _skill_name(skill_id):
    sid = str(skill_id or '')
    s = _skills().get(sid)
    if isinstance(s, dict) and s.get('name'):
        return s['name']
    n = _skill_names().get(sid)
    if isinstance(n, dict) and n.get('name'):
        return n['name']
    return sid or '武学'


def _chart_of(acupoint_id):
    """某个窍关属于哪张玄络图（按 groove* 找）。"""
    for cid, chart in _charts().items():
        for i in range(1, 100):
            g = chart.get('groove%d' % i)
            if g is None:
                break
            if str(g) == str(acupoint_id):
                return cid
    return ''


# ---------------------------------------------------------------------------
# 状态
# ---------------------------------------------------------------------------
def _slot():
    return {'state': False, 'id': '', 'startTime': 0, 'finishTime': 0}


def _blank():
    return {
        'version': 0,                  # 每次动作 +1，回给客户端的 data.version
        'ygpill': YGPILL_INIT,         # 养真丹
        'xgsUsed': 0,                  # 累计用掉的行功散
        'chartId': 'minditem1',        # 当前玄络图（客户端初始值也是 minditem1）
        'activated': {},               # {chartId: [已冲穴的窍关 id]}
        'attached': {},                # {窍关id: 玄络id}（调脉是纯客户端行为，这里只记账）
        'buffs': [],                   # 已解锁玄络 id
        'breakThrough': _slot(),       # 破境
        'acupoint': _slot(),           # 冲穴
        'yuQi': False,                 # 余炁状态
        'yuQiChart': '',
        'guidanceCount': GUIDANCE_PER_WEEK,   # 本周剩余师门指点次数
        'guidanceWeek': '',
        'xiuLian': {},
        'lianGong': {},
        'skills': {},                  # {skillId: {'exp': 累计获得, 'last': 上次结算时间}}
        'spent': {},                   # {资源id: 累计消耗}（记账用，物品系统还没接）
        'currencyVersion': 1,
        'log': [],
    }


def _now():
    return int(time.time())


def _num(v, d=0):
    try:
        if v is None or v == '':
            return d
        return int(float(v))
    except (TypeError, ValueError):
        return d


def _uid(ctx):
    return str(ctx.headers.get('userid') or ctx.headers.get('uuid') or 'local')


def _load(ctx):
    st = ctx.load_json(STATE, None)
    if not isinstance(st, dict):
        st = {}
    for k, v in _blank().items():
        if k not in st or st[k] is None:
            st[k] = v
    for k in ('breakThrough', 'acupoint'):
        if not isinstance(st.get(k), dict):
            st[k] = _slot()
        else:
            for kk, vv in _slot().items():
                st[k].setdefault(kk, vv)
    for k in ('activated', 'attached', 'skills', 'spent'):
        if not isinstance(st.get(k), dict):
            st[k] = {}
    for k in ('buffs', 'log'):
        if not isinstance(st.get(k), list):
            st[k] = []
    # 师门指点：每周一 0 点刷新（客户端规则文本「每周一0点…自动获取对应的师门指点次数」）
    wk = time.strftime('%Y%W')
    if st.get('guidanceWeek') != wk:
        st['guidanceWeek'] = wk
        st['guidanceCount'] = GUIDANCE_PER_WEEK
    return st


def _save(ctx, st):
    st['log'] = st.get('log', [])[-80:]
    st['userid'] = _uid(ctx)
    st['updated'] = _now()
    ctx.save_json(STATE, st)


def _bump(st):
    st['version'] = _num(st.get('version')) + 1
    return st['version']


def _mark(st, who, msg):
    st.setdefault('log', []).append('%d %s %s' % (_now(), who, msg))


def _spend(st, res, who):
    """把表里的 `resource`（{{资源id,数量},…}）记到 spent 里（只记账，不拦）。"""
    if not isinstance(res, list):
        return []
    out = []
    for it in res:
        if isinstance(it, (list, tuple)) and len(it) >= 2:
            rid = str(it[0])
            n = _num(it[1])
            st['spent'][rid] = _num(st['spent'].get(rid)) + n
            out.append('%s*%d' % (rid, n))
    if out:
        _mark(st, who, '消耗 ' + ' '.join(out))
    return out


def _remain(slot, now):
    return max(0, _num(slot.get('finishTime')) - now)


def _guidance_count(st):
    """本周还剩几次师门指点（自然周重置）。"""
    import time as _t
    wk = _t.strftime('%Y%W')
    g = st.get('guidance') if isinstance(st.get('guidance'), dict) else {}
    if g.get('week') != wk:
        g = {'week': wk, 'used': 0}
        st['guidance'] = g
    return max(0, GUIDANCE_PER_WEEK - _num(g.get('used')))


def _read_side(ctx, st, ep):
    """三个「读数」接口（原来服务端写死的那三个）。"""
    if ep == 'get_sectGuidance_info':
        # `TeacherGuidance.lua:29-42` 读 `data.guidanceCount` / `data.speedUpTime`
        #   ⇒ `TeacherGuidancePresenter:148 getTimeStr(nil)` 会 `math.floor(nil/3600)` 抛错被吞、面板卡死。
        return ctx.ok({'guidanceCount': _guidance_count(st),
                       'speedUpTime': GUIDANCE_SPEEDUP,
                       'list': []},
                      '★ 师门指点（本周还剩 %d 次，每次减 %ds）'
                      % (_guidance_count(st), GUIDANCE_SPEEDUP))
    if ep in ('getXiuLianData', 'getLianGongData'):
        # `ServerActionSystem:183-200` → `callback(true,"",data.startAction,data.useXgsCount)`
        #   → `XiuLianSystem:142` `if startAction ~= "" and startAction.data ~= "" then initData(...)`
        #   ⇒ `startAction` 必须是**对象**（带 `.data` 字符串），没有进行中的会话就给空串对象。
        key = 'xiuLian' if ep == 'getXiuLianData' else 'lianGong'
        cur = st.get(key) if isinstance(st.get(key), dict) else {}
        if cur.get('active') and cur.get('action'):
            return ctx.ok({'startAction': {'data': json.dumps(cur['action'], ensure_ascii=False)},
                           'useXgsCount': _num(cur.get('useXgsCount'))},
                          '★ %s数据（恢复进行中的会话）' % ('修炼' if key == 'xiuLian' else '练功'))
        return ctx.ok({'startAction': {'data': ''}, 'useXgsCount': 0},
                      '★ %s数据（当前没有进行中的会话）' % ('修炼' if key == 'xiuLian' else '练功'))
    return None


def _do_accelerate(ctx, st, slot, cost, now):
    """加速：一颗养真丹 300 秒；实际消耗 = min(请求量, 还需要的量, 口袋里有的)。

    ★ 统一「两份账」（2026-09-28）：养真丹走 **`items_currency`**（真账本），
      不再只记在本模块的 `st['ygpill']`。
      原来 `YGPILL_INIT=999` 的注释是"物品系统还没做，先给足"，但
      `items_currency` 早就能记账（`aliases('ygpill')=['ygpill','400039']`，
      真账本在 `items_state.json.serverItems`）⇒ 面板 999 / 真账本 30 两本账。
      现改为：读真账本 → 不够再退本地镜像（旧数据兜底）。
    """
    cost = max(0, _num(cost))
    remain = _remain(slot, now)
    max_cost = int(math.ceil(remain / float(SPEED_UP_SECONDS))) if remain > 0 else 0
    have = _ygpill_count(ctx, st)
    real = min(cost, max_cost, have)
    real = max(0, real)
    if real:
        slot['finishTime'] = _num(slot.get('finishTime')) - real * SPEED_UP_SECONDS
        if not _ygpill_spend(ctx, st, real):
            # 真账本扣不动就退回本地镜像（用镜像自身读数，别读真账本）
            st['ygpill'] = _num(st.get('ygpill')) - real
    return real, real * SPEED_UP_SECONDS, max(0, _remain(slot, now))


def _ygpill_count(ctx, st):
    """养真丹余额：**真账本优先**，拿不到再退本模块镜像 `st['ygpill']`。

    ★ 事故记录（2026-09-28）：这里原本写成 `return _ygpill_count(ctx, st)` ——
      **自调用**，一旦真账本拿不到就无限递归（`maximum recursion depth exceeded`）。
      连带 8 个经脉接口全部 500：`get_hidden_meridian_info` / `start_|cancel_|
      accelerate_break_through_realm` / `start_|cancel_|accelerate_thoroughfare_vessel` /
      `unlock_hidden_meridian_gems`。
      是 `/__probe/` 全量探针抓出来的（`tmp_probe_all.py`），logcat 里看不到。
    """
    try:
        import fz_api.items_currency as _ic
        n = _num(_ic().get_count(ctx, RES_ITEM_ID))
        if n > 0:
            return n
    except Exception:                             # noqa: BLE001
        pass
    return _num(st.get('ygpill'))


def _ygpill_spend(ctx, st, n):
    """扣养真丹（真账本）。成功返回 True。"""
    try:
        import fz_api.items_currency as _ic
        return _ic().add_count(ctx, RES_ITEM_ID, -abs(int(n))) is not None
    except Exception:                             # noqa: BLE001
        return False


# ---------------------------------------------------------------------------
# 修炼 / 练功
# ---------------------------------------------------------------------------
_ACTIONS = {
    # 接口名前缀: (状态槽, 中文)
    'xiuLian': ('xiuLian', '修炼'),
    'lianGong': ('lianGong', '练功'),
}


def _action_data(ctx):
    obj = ctx.body_obj if isinstance(ctx.body_obj, dict) else {}
    ad = obj.get('actionData')
    if isinstance(ad, str):
        try:
            ad = json.loads(ad)
        except Exception:                      # noqa: BLE001
            ad = {}
    if not isinstance(ad, dict):
        ad = {}
    return obj, ad


def _expect_exp(skill_id, seconds, variates):
    """按她 `getUnitAddExp()` 的公式粗算一遍应得经验（只用于交叉校验/写日志）。

       unit = conf14 * potEfficiency * (conf15 + int + floor(dsszLv/10))
       见 `XiuLianSystem.lua`:879 / `LianGongSystem.lua`:799
    """
    try:
        conf = _lg_conf()
        s = _skills().get(str(skill_id)) or {}
        pot = float(s.get('potEfficiency') or 80)
        base = float(conf.get('14') or 0.000278)
        corr = float(conf.get('15') or 200.0)
        vi = float((variates or {}).get('int') or 0)
        dssz = float((variates or {}).get('dsszLv') or 0)
        unit = base * pot * (corr + vi + math.floor(dssz / 10.0))
        return int(unit * max(0, seconds))
    except Exception:                          # noqa: BLE001
        return 0


def _start(ctx, ctx_kind, st, now):
    """xiuLianStart / lianGongStart：把开始时间、时长、选择项全记下来。"""
    key, label = _ACTIONS[ctx_kind]
    obj, ad = _action_data(ctx)
    skill_id = str(ad.get('skillId') or '')
    st[key] = {
        'active': True,
        'ver': _num(ad.get('ver')),
        'skillId': skill_id,
        'skillName': _skill_name(skill_id),
        'skillPrepareType': ad.get('skillPrepareType'),
        'xinshen': _num(ad.get('xinshen')),
        'startTime': now,
        'duration': _num(ad.get('duration')),
        'selectJing': _num(ad.get('selectJing')),
        'selectLv': _num(ad.get('selectLv')),
        'selectTiLi': _num(ad.get('selectTiLi')),
        'xinShenCost': _num(ad.get('xinShenCost')),
        'useXgsCount': _num(ad.get('useXgsCount')),
        'startExp': _num(ad.get('startExp')),
        'startLvLimit': _num(ad.get('startLvLimit')),
        'playerLv': _num(ad.get('playerLv')),
        'variates': ad.get('variates') if isinstance(ad.get('variates'), dict) else {},
        'dummy': ad.get('dummy') if isinstance(ad.get('dummy'), dict) else {},
        'codeVer': _num(obj.get('codeVer')),
        'requestId': _num(obj.get('requestId')),
        'action': ad,          # 原样留一份：将来谁实现 getXiuLianData 可直接 `{'data': action}` 回给她
        'exp': 0,
    }
    _mark(st, ctx.endpoint, '%s《%s》开始，时长 %ds（心神 %d，精力 %d）'
          % (label, st[key]['skillName'], st[key]['duration'],
             st[key]['xinShenCost'], st[key]['selectJing']))
    _save(ctx, st)
    return ctx.ok({'msg': '开始%s《%s》' % (label, st[key]['skillName']),
                   'startTime': st[key]['startTime'], 'duration': st[key]['duration']},
                  '★ %s开始《%s》%ds' % (label, st[key]['skillName'], st[key]['duration']))


def _finish(ctx, ctx_kind, st, now):
    """xiuLianFinish / lianGongFinish：按真实经过时间结算，累计经验落盘。"""
    key, label = _ACTIONS[ctx_kind]
    _obj, ad = _action_data(ctx)
    cur = st.get(key) if isinstance(st.get(key), dict) else {}
    start_time = _num(cur.get('startTime'), now)
    elapsed = max(0, now - start_time)
    duration = _num(cur.get('duration'))
    used = _num(cur.get('useXgsCount'))
    # 与客户端 `getResidueTime()` 同口径：行功散每颗顶 1 小时
    effective = min(elapsed + used * XGS_SECONDS, duration) if duration > 0 else elapsed
    skill_id = str(ad.get('skillId') or cur.get('skillId') or '')
    add_exp = _num(ad.get('addExp'))
    csj_exp = _num(ad.get('csjAddExp'))
    back_xs = _num(ad.get('xinShenReturn'))
    back_tl = _num(ad.get('tiLiReture'))
    expect = _expect_exp(skill_id, effective, cur.get('variates'))
    name = _skill_name(skill_id)
    if expected_warn(expect, add_exp):
        _mark(st, ctx.endpoint, '经验交叉校验差异：客户端 %d / 公式 %.0f（忽略，以客户端为准）'
              % (add_exp, expect))
    rec = st['skills'].setdefault(skill_id, {'exp': 0})
    rec['exp'] = _num(rec.get('exp')) + add_exp
    rec['last'] = now
    rec['lastTime'] = effective
    if csj_exp:
        csj = st['skills'].setdefault('changshengjueyang', {'exp': 0})
        csj['exp'] = _num(csj.get('exp')) + csj_exp
    st[key] = {
        'active': False, 'skillId': skill_id, 'skillName': name,
        'startTime': start_time, 'duration': duration,
        'finishTime': now, 'elapsed': elapsed, 'effectiveTime': effective,
        'useXgsCount': used, 'exp': add_exp, 'csjExp': csj_exp,
        'xinShenReturn': back_xs, 'tiLiReture': back_tl,
        'totalExp': _num(rec.get('exp')), 'expectExp': expect,
    }
    if add_exp <= 0:
        # 客户端 `checkXiuLianCanProfit()`：不足一分钟且没练完 ⇒ addExp=0，回它"没收益"
        msg = '你结束了%s，本次%s不足一分钟，没有获得收益。' % (label, label)
    else:
        msg = '本次%s《%s》获得武学经验%d点' % (label, name, add_exp)
        if csj_exp:
            msg += '，长生诀获得经验%d点' % csj_exp
        msg += '（累计%d点）' % _num(rec.get('exp'))
    _mark(st, ctx.endpoint, '%s《%s》结算：%ds（含行功散%d颗）→ 经验 %d'
          % (label, name, effective, used, add_exp))
    _save(ctx, st)
    return ctx.ok({'msg': msg, 'exp': add_exp, 'totalExp': _num(rec.get('exp')),
                   'finishTime': now, 'effectiveTime': effective},
                  '★ %s结算《%s》经验 %d' % (label, name, add_exp))


def expected_warn(expect, got):
    """经验差得离谱才写日志（客户端自己也算了一套，公式有出入很正常）。"""
    if not expect or not got:
        return False
    return got > expect * 1.5 + 10 or got < expect * 0.5 - 10


def _use_xgs(ctx, ctx_kind, st, now):
    """xiuLianUseXingGongSan / lianGongUseXingGongSan：行功散 +1（=1 小时）。"""
    key, label = _ACTIONS[ctx_kind]
    cur = st.get(key) if isinstance(st.get(key), dict) else {}
    cur['useXgsCount'] = _num(cur.get('useXgsCount')) + 1
    st[key] = cur
    st['xgsUsed'] = _num(st.get('xgsUsed')) + 1
    _mark(st, ctx.endpoint, '%s使用行功散，累计 %d 颗' % (label, cur['useXgsCount']))
    _save(ctx, st)
    return ctx.ok({'useXgsCount': cur['useXgsCount'],
                   'msg': '使用一颗行功散，%s时间减少1小时' % label},
                  '★ %s用行功散（第 %d 颗）' % (label, cur['useXgsCount']))


# ---------------------------------------------------------------------------
# 入口
# ---------------------------------------------------------------------------
def handle(ctx):
    ep = ctx.endpoint
    if ep not in ENDPOINTS:
        return None
    now = _now()
    st = _load(ctx)

    # ---------------- 读数（以前服务端写死的那三个） ----------------
    r = _read_side(ctx, st, ep)
    if r is not None:
        _save(ctx, st)
        return r

    # ---------------- 隐脉信息 ----------------
    if ep == 'get_hidden_meridian_info':
        # `data.ygpill` 是数字（`..":"..getYgpillCount()`）
        return ctx.ok({'ygpill': _ygpill_count(ctx, st)},
                      '★ 隐脉信息（养真丹 %d，%s 第 %d 层）'
                      % (_ygpill_count(ctx, st), st.get('chartId'),
                         _num((_charts().get(st.get('chartId')) or {}).get('class'), 1)))

    # ---------------- 冲穴 ----------------
    if ep == 'start_thoroughfare_vessel':
        aid = str(ctx.param('id') or '')
        res = _acupoints().get(aid) or {}
        secs = _num(res.get('time')) or 7200
        st['acupoint'] = {'state': True, 'id': aid, 'startTime': now,
                          'finishTime': now + secs, 'time': secs}
        _spend(st, res.get('resource'), ep)
        _mark(st, ep, '开始冲穴 %s(%s) %ds' % (aid, res.get('name') or '', secs))
        _mark(st, ep, '版本 %d' % _bump(st))
        _save(ctx, st)
        return ctx.ok({'count': _ygpill_count(ctx, st), 'version': st['version']},
                      '★ 开始冲穴 %s(%s) %ds' % (aid, res.get('name') or '', secs))

    if ep == 'finish_thoroughfare_vessel':
        aid = str(ctx.param('id') or (st['acupoint'] or {}).get('id') or '')
        chart = _chart_of(aid) or str(st.get('chartId'))
        act = st['activated'].setdefault(chart, [])
        if not isinstance(act, list):
            act = st['activated'][chart] = []
        if aid and aid not in act:
            act.append(aid)
        st['acupoint'] = _slot()
        all_done = _all_activated(chart, act)
        if all_done:
            st['yuQi'] = False          # 与客户端 `acupointAllActivate() → removeYuQi()` 同步
        _mark(st, ep, '冲穴完成 %s（%s 已激活 %d 个，全通=%s）'
              % (aid, chart, len(act), all_done))
        _mark(st, ep, '版本 %d' % _bump(st))
        _save(ctx, st)
        return ctx.ok({'version': st['version']},
                      '★ 冲穴完成 %s（%s 已激活 %d 个）' % (aid, chart, len(act)))

    if ep == 'cancel_thoroughfare_vessel':
        aid = str(ctx.param('id') or (st['acupoint'] or {}).get('id') or '')
        st['acupoint'] = _slot()
        _mark(st, ep, '终止冲穴 %s' % aid)
        _mark(st, ep, '版本 %d' % _bump(st))
        _save(ctx, st)
        return ctx.ok({'version': st['version'], 'cost': 0, 'count': _ygpill_count(ctx, st)},
                      '★ 终止冲穴 %s' % aid)

    if ep == 'accelerate_thoroughfare_vessel':
        real, secs, remain = _do_accelerate(ctx, st, st['acupoint'], ctx.param('cost'), now)
        _mark(st, ep, '加速冲穴：养真丹 %d 颗 → -%ds（剩 %ds，余丹 %d）'
              % (real, secs, remain, _ygpill_count(ctx, st)))
        _mark(st, ep, '版本 %d' % _bump(st))
        _save(ctx, st)
        return ctx.ok({'cost': real, 'count': _ygpill_count(ctx, st),
                       'version': st['version'], 'speedUpTime': secs,
                       'finishTime': _num((st['acupoint'] or {}).get('finishTime'))},
                      '★ 加速冲穴：用 %d 个养真丹，少 %ds' % (real, secs))

    # ---------------- 破境 ----------------
    if ep == 'start_break_through_realm':
        cid = str(ctx.param('id') or st.get('chartId') or 'minditem1')
        chart = _charts().get(cid) or {}
        secs = _num(chart.get('time')) or 50280
        st['chartId'] = cid
        st['breakThrough'] = {'state': True, 'id': cid, 'startTime': now,
                              'finishTime': now + secs, 'time': secs}
        _spend(st, chart.get('resource'), ep)
        st['currencyVersion'] = _num(st.get('currencyVersion'), 1) + 1
        _mark(st, ep, '开始破境 %s(%s) %ds，版本 %d' % (cid, chart.get('name') or '', secs, _bump(st)))
        _save(ctx, st)
        return ctx.ok({'count': _ygpill_count(ctx, st), 'version': st['version'],
                       'currencyVersion': _num(st.get('currencyVersion'))},
                      '★ 开始破境 %s(%s) %ds' % (cid, chart.get('name') or '', secs))

    if ep == 'finish_break_through_realm':
        cid = str(ctx.param('id') or (st['breakThrough'] or {}).get('id') or st.get('chartId'))
        chart = _charts().get(cid) or {}
        # 幂等：只有"正在破的就是这张图"才升级，重复/过期请求只清状态
        can_advance = cid == str(st.get('chartId')) or cid == str((st['breakThrough'] or {}).get('id') or '')
        nxt = _chart_by_class(_num(chart.get('class'), 1) + 1) if can_advance else None
        st['breakThrough'] = _slot()
        st['yuQi'] = True                 # 破境成功 → 余炁（客户端 `self.__yuQiState = true`）
        st['yuQiChart'] = cid
        if nxt:
            st['chartId'] = str(nxt.get('id'))
            st['activated'][st['chartId']] = []
            st['attached'] = {}           # 客户端 `self.__acupointMap = {}`
        _mark(st, ep, '破境完成 %s → %s(%s) 余炁开启，版本 %d'
              % (cid, st.get('chartId'), (nxt or {}).get('name') or '', _bump(st)))
        _save(ctx, st)
        return ctx.ok({'version': st['version']},
                      '★ 破境完成 %s → %s(%s)'
                      % (cid, st.get('chartId'), (nxt or {}).get('name') or '已达最高层'))

    if ep == 'cancel_break_through_realm':
        cid = str(ctx.param('id') or (st['breakThrough'] or {}).get('id') or st.get('chartId'))
        st['breakThrough'] = _slot()
        _mark(st, ep, '终止破境 %s，版本 %d' % (cid, _bump(st)))
        _save(ctx, st)
        return ctx.ok({'version': st['version'], 'cost': 0, 'count': _ygpill_count(ctx, st)},
                      '★ 终止破境 %s' % cid)

    if ep == 'accelerate_break_through_realm':
        real, secs, remain = _do_accelerate(ctx, st, st['breakThrough'], ctx.param('cost'), now)
        _mark(st, ep, '加速破境：养真丹 %d 颗 → -%ds（剩 %ds，余丹 %d）'
              % (real, secs, remain, _ygpill_count(ctx, st)))
        _mark(st, ep, '版本 %d' % _bump(st))
        _save(ctx, st)
        return ctx.ok({'cost': real, 'count': _ygpill_count(ctx, st),
                       'version': st['version'], 'speedUpTime': secs,
                       'finishTime': _num((st['breakThrough'] or {}).get('finishTime'))},
                      '★ 加速破境：用 %d 个养真丹，少 %ds' % (real, secs))

    # ---------------- 玄络解锁 ----------------
    if ep == 'unlock_hidden_meridian_gems':
        bid = str(ctx.param('id') or '')
        res = _buffs().get(bid) or {}
        if bid and bid not in st['buffs']:
            st['buffs'].append(bid)
        _spend(st, res.get('resource'), ep)
        st['currencyVersion'] = _num(st.get('currencyVersion'), 1) + 1
        _mark(st, ep, '解锁玄络 %s(%s)，共 %d 条，版本 %d'
              % (bid, res.get('name') or '', len(st['buffs']), _bump(st)))
        _save(ctx, st)
        return ctx.ok({'count': _ygpill_count(ctx, st), 'version': st['version'],
                       'currencyVersion': _num(st.get('currencyVersion'))},
                      '★ 解锁玄络 %s(%s)' % (bid, res.get('name') or ''))

    # ---------------- 师门指点 ----------------
    if ep == 'execute_sectGuidance':
        gid = str(ctx.param('id') or '')
        is_chart = gid in _charts() or gid == str(st.get('chartId'))
        slot = st['breakThrough'] if is_chart else st['acupoint']
        if not slot.get('state'):
            # 她那边状态没同步（例如点到的是另一条线）就退到还在跑的那条
            slot = st['breakThrough'] if st['breakThrough'].get('state') else st['acupoint']
        if not slot.get('state'):
            return ctx.fail('当前不在修炼状态，无法进行指点', '★ 师门指点：无进行中的冲穴/破境')
        left = _num(st.get('guidanceCount'))
        if left <= 0:
            return ctx.fail('本周师门指点次数已用尽', '★ 师门指点：次数用尽')
        secs = GUIDANCE_SPEEDUP
        slot['finishTime'] = _num(slot.get('finishTime')) - secs
        st['guidanceCount'] = left - 1
        _mark(st, ep, '师门指点（%s / familyId=%s）：-%ds，剩 %d 次，版本 %d'
              % (slot.get('id'), ctx.param('familyId'), secs, st['guidanceCount'], _bump(st)))
        _save(ctx, st)
        return ctx.ok({'speedUpTime': secs, 'version': st['version'],
                       'guidanceCount': st['guidanceCount']},
                      '★ 师门指点：-%ds（本周还剩 %d 次）' % (secs, st['guidanceCount']))

    # ---------------- 修炼 / 练功 ----------------
    if ep in ('xiuLianStart', 'lianGongStart'):
        return _start(ctx, 'xiuLian' if ep.startswith('xiu') else 'lianGong', st, now)

    if ep in ('xiuLianFinish', 'lianGongFinish'):
        return _finish(ctx, 'xiuLian' if ep.startswith('xiu') else 'lianGong', st, now)

    if ep in ('xiuLianUseXingGongSan', 'lianGongUseXingGongSan'):
        return _use_xgs(ctx, 'xiuLian' if ep.startswith('xiu') else 'lianGong', st, now)

    return None



# ===========================================================================
# ★ 2026-10-01 两颗「服务端生效」的经脉丹（老板选方案 A）
#   客户端只买到物品；真正的效果由服务端直接写进**存档**（saves/*.json 的
#   `meridian` / `hiddenMeridianData` / 天赋页字段），再由
#   `fz_boot_server._overlay_persisted_attrs()` 随角色一起下发 ⇒ 不会两本账。
# ===========================================================================
def _save_files(ctx):
    here = getattr(ctx, 'here', None) or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    d = os.path.join(here, 'saves')
    if not os.path.isdir(d):
        return []
    return [os.path.join(d, f) for f in sorted(os.listdir(d)) if f.endswith('.json')]


def _patch_saves(ctx, fn):
    n = 0
    for p in _save_files(ctx):
        try:
            with open(p, encoding='utf-8') as f:
                j = json.load(f)
            root = j[0] if isinstance(j, list) and j else j
            if not isinstance(root, dict):
                continue
            fn(root)
            with open(p, 'w', encoding='utf-8') as f:
                json.dump(j, f, ensure_ascii=False)
            n += 1
        except Exception as e:                                        # noqa: BLE001
            try:
                ctx.log('经脉丹写存档失败 %s: %s' % (os.path.basename(p), e))
            except Exception:                                         # noqa: BLE001
                pass
    return n


def pill_break100(ctx):
    """经脉冲脉丹：**永久**每次冲穴必定成功（100%）。

    真效果在客户端：`Meridian:getRandomEventState`（`Meridian.lua:665`）里我们加了一句
    "有 `fzBreak100` 标记就 `event = 1`"（1 = 冲穴成功）。
    这里只负责把这个标记**写进存档** ⇒ 跟着档走，重登、换设备都在。
    （游戏自己本来就有一次性的同类钩子：`:698` 的 `getTimeLimitFlag("冲穴成功")`。）
    """
    def fn(root):
        root['fzBreak100'] = 1
        m = root.get('meridian')
        if isinstance(m, dict):
            m['alreadyDisease'] = 0
            m['alreadyDisorder'] = 0

    n = _patch_saves(ctx, fn)
    return '★ 经脉冲脉丹：已开启"冲穴必定成功"（写入 %d 份存档）' % n


def pill_hidden_break100(ctx):
    """隐脉冲脉丹：**永久**每次隐脉冲脉必定成功（100%）。

    隐脉的冲脉是**服务端判定**的（`start_thoroughfare_vessel` 的 errcode），
    所以这里打一个服务端认得的标记；`fz_boot_server` 里那个接口看到标记就一律回成功。
    """
    def fn(root):
        root['fzHiddenBreak100'] = 1

    n = _patch_saves(ctx, fn)
    return '★ 隐脉冲脉丹：已开启"隐脉冲脉必定成功"（写入 %d 份存档）' % n
def _all_activated(chart_id, act):
    """当前玄络图的窍关是否全部冲穴完成（照 `HiddenMeridianChart:getAcupointList()` 的 groove 顺序）。"""
    chart = _charts().get(str(chart_id)) or {}
    ids = []
    for i in range(1, 100):
        g = chart.get('groove%d' % i)
        if g is None:
            break
        ids.append(str(g))
    if not ids:
        return False
    return all(i in act for i in ids)
