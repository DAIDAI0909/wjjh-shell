# -*- coding: utf-8 -*-
# ================= 离线包路径根（fz_make_offline_bundle.py 自动注入） =================
# 手机上整个服务端就是一个目录，表在哪、状态写哪，全部相对包根算。
# （有的模块原来把绝对路径写死，本身没 import os —— 这里一并补上）
import os
import os as _osp


def _off_find_bundle(_f):
    """从模块所在目录往上找包根（认 fz_boot_server.py）。
    ★ fz_api/*.py 的 __file__ 在 <根>/fz_api/ 下，直接 dirname 会算错一层。"""
    _d = _osp.path.dirname(_osp.path.abspath(_f))
    for _ in range(6):
        if _osp.path.exists(_osp.path.join(_d, 'fz_boot_server.py')):
            return _d
        _u = _osp.path.dirname(_d)
        if _u == _d:
            break
        _d = _u
    return _osp.path.dirname(_osp.path.abspath(_f))


_OFF_BUNDLE = _off_find_bundle(__file__)
_OFF_FZ_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_fz')
_OFF_INK_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_ink')
_OFF_WORK_ROOT = _OFF_BUNDLE
# =====================================================================================
# ★ 2026-10-04 商城空货架修复：客户端资源表解析——PC 开发树优先，设备上自动回退
#   到包内 client_fz 副本（jhserver/client_fz = fangzhi_lua_dec 的同步拷贝）。
def _fz_res(*parts):
    base = os.path.join(_OFF_FZ_ROOT, 'res', 'script')
    if not os.path.isdir(base):
        base = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            '..', 'client_fz', 'res', 'script')
    return os.path.join(base, *parts)

# -*- coding: utf-8 -*-
"""家园「地理」模块 —— 车夫传送 / 地皮买卖竞价回收 / 搬家 / 求购。

契约出处（都在她 `C:\\apkwork\\fangzhi_lua_dec\\assets\\src` 里逐个读过）：

  * `app/extends/Http/HttpManager.lua`（URL 与上行参数）
      getLandStoreList(fbId,npcId)      → get_land_store_list   POST {fbId,npcId}
      biddingLand(dpId,npcId,price)     → bidding_land          POST {dpId,npcId,price}
      getbiddingLand(dpId)              → get_bidding_land      POST {dpId}
      querybiddingInfo()                → query_bidding_info    GET
      moveHomeland(dpId,mid)            → move_home_land        POST {dpId,mid}
      getBiddingReturnPoint(dpId)       → get_bidding_return_point POST {dpId}
      getManagePayment(dpId)            → get_manage_payment/DPID GET
      recycleLand(dpId)                 → recycle_land          POST {dpId}
      getLocationMax(mapIndex)          → get_location_max/MAPINDEX GET
      getLocationMap(loc_mark)          → get_location_map      POST {loc_mark}
      getShenShiReward(type,objId,mid,up_data) → get_shenshi_reward
      getGuaikeReward(isMenKe,menKeId,mid,guaikeLv) → get_guaike_reward
      checkDreamRoleDataIsOverdue(userData) → settle_overdue_dream

  * 读哪些字段（**类型已逐个核对**，给错就被应答回调里的 xpcall 吞掉 ⇒ 客户端整体卡死）：
      get_land_store_list  : list(表) / hasLand(字符串 "Y"/"N") / point(数字)
                             list 每项：dpId(字符串) high_price(数字) state(数字)
                             high_name(字符串) surplusTime(数字，仅 state>=2 时被 `- GetTime()`)
      query_bidding_info   : list(表) / point(数字)
                             list 每项：**pairs 遍历**，故必须是数组；dpId(字符串)
                             bid_state(数字 1竞价中/2竞价成功/3竞价失败) high_price(数字)
                             high_name(字符串) return_point(数字) dsc(字符串)
                             surplusTime(数字)
      bidding_land         : surplusTime(数字) remove_point(数字)；errcode==2 时还要
                             high_price(数字) high_name(字符串)
      get_bidding_land     : 回调只判 errcode，data 不读
      get_bidding_return_point : return_point(数字，会与 _currPoint 相加)
      get_manage_payment   : day(数字) total_pay(数字)（`DiQiModel:checkManagementCost`）
      get_location_max     : max(表，**必须 4 项** `#data.max == 4`；
                             CheFuQianWangLayer 按 {城市区域,城市方向,村庄,村内区域} 取上限)
      get_location_map     : list(表)（`UserMap:goVillageMap` 直接 `pairs` 遍历）
      get_guaike_reward    : yinpiao/yueli/weiwang(数字) activityItems(表，元素 {itemId,num})
                             defaultZhongCheng(数字) level_up(布尔) trait(表)
      get_shenshi_reward   : type==1 → pay_base{unit,val}；type==2 → pay_time(数字，时间戳)；
                             其它 → mobanSkill(表)
      settle_overdue_dream : errcode==0 时读 eventsInfo(表) 与 reward(表)（RewardManager2）
      move_home_land / recycle_land : 回调只判 errcode

  * 资源表（内容全取她自己的表，不另造）：
      `res/script/others/familylist.lua`
          ["房屋地皮"]  1088 块地 —— dpId / name / place / startprice / cost /
                        color / dsc / roomdsc / dirMark / fbId / dpRoomId 都是现成的。
                        `DiQiModel:initDpList` 就是按 `dpId` 索引这张表；
                        `DiQiModel:getDpInfoById(dpId)` 用 dpId 回查（缺了会 assert）。
          ["房契模板"]  152 种房型，`fqId` 与 `房屋地皮` 的 `dpId` 同号。
          ["大门信息"]  doorid/doorname/doordcost —— 大门模板（本模块只读不动）。
      `res/script/map/map.lua` + `res/script/map/mapRoom/fb206..fb209.lua`
          小村庄 4 张（扬州/苏州/襄阳/长安），每村 14 个带 `flag1` 的空地房间
          —— `get_location_max` / `get_location_map` 的上限从这儿数出来。
      `app/models/map/UserMapRelation.lua`（**她客户端的常量表**，直接照抄）：
          villageMapId[index] → 村副本；城市段 = 4 段（1-4 / 5-8 / 9-12 / 13-16）
          村庄索引 26 个、村内区域 20 个、`CheFuQianWangLayer:setTotalList(startIndex, limit)`
          要求 `#limit == 4`。
      `app/models/npc/CheFuModel.lua`  车夫按钮（询址 / 回家 / 递函 / 回城）
      `app/views/layer/HomelandLayer/CheFuQianWangLayer.lua` 三选一目的地
      `app/views/layer/HomelandLayer/PurchaseLayer/{BuyLandLayer,BiddingLayer,BiddingQueryLayer}.lua`
      `app/views/layer/HomelandLayer/AskToBuyLayer.lua`  求购（走 `push_affair`，
          由 `homeland_furniture` 模块落盘，本模块不抢那个接口名）

  * 状态（**真写盘**）：
      `work/homeland_land_state.json` —— 本模块自己的账本：
          bids{uid|dpId:{price,high_name,deadline,return_point,bid_state,claimed}}
          on_land{dpId,location,moved_at,mid} / owned / events(流水)
      **银票不另造第二份钱**：一律读写 `work/homeland_state.json.currency.yinpiao`
      （`fz_boot_server.py:405` / `homeland_life.py` / `items_currency.py` /
      `misc_systems.py` 都读它，是这个工程唯一一份钱袋子）。
      另**只增量**写 `work/homeland_state.json` 的 `dpId` / `location` 两个键
      （`DiQiModel:moveHomeland` 成功后 `FangQiModel:updateInfo({location=...,dpId=...})`），
      **不碰** fqId / name / employees / furniture / affairs / rooms。

  * 避开：`buy_homeland` / `get_house_info` / `get_land_info` / `get_common_fuben` /
    `get_user_map` / `get_homeland_cost` / `push_affair` 已经有人做了，本模块**不声明**它们。
"""
import os
import re
import time

NAME = 'homeland_land'
TITLE = '家园·车夫/地皮/搬迁/求购'
ENDPOINTS = [
    # —— 地皮买卖 / 竞价 / 回收 ——
    'get_land_store_list', 'bidding_land', 'get_bidding_land', 'query_bidding_info',
    'get_bidding_return_point', 'recycle_land', 'get_manage_payment',
    # —— 搬家 / 地皮落位 ——
    'move_home_land', 'get_land_info_by_dp',
    # —— 车夫（询址 / 传送） ——
    'get_location_max', 'get_location_map',
    # —— 家园房客 / 身世 / 梦境 ——
    'get_guaike_reward', 'get_shenshi_reward', 'settle_overdue_dream',
]

STATE = 'homeland_land_state.json'          # 本模块账本
HOME_STATE = 'homeland_state.json'          # 老板已有账本（只增量写 dpId/location）

# 地皮城 → 她自己的 fbId（`房屋地皮.fbId`）。`get_land_store_list` 的上行 fbId 是
# 「住宅区」副本（fb301/302/303/304，见 HomelandModule 的 commonMapList）。
COMMON_MAP_LIST = {'fb301': 'fb10', 'fb302': 'fb15', 'fb303': 'fb20', 'fb304': 'fb25'}
FB_IDS = ('fb10', 'fb15', 'fb20', 'fb25')

# 她 `UserMapRelation.lua` 的常量（照抄，别改）
VILLAGE_MAP_ID = {
    1: 'fb206', 5: 'fb206', 9: 'fb206', 13: 'fb206', 17: 'fb206', 22: 'fb206', 25: 'fb206',
    2: 'fb207', 6: 'fb207', 10: 'fb207', 14: 'fb207', 18: 'fb207', 21: 'fb207', 26: 'fb207',
    3: 'fb208', 7: 'fb208', 11: 'fb208', 15: 'fb208', 19: 'fb208', 23: 'fb208',
    4: 'fb209', 8: 'fb209', 12: 'fb209', 16: 'fb209', 20: 'fb209', 24: 'fb209',
}
# `HomelandModule.lua:100 "询址"` 里的 mapIndex / startIndex 映射
CITY_INDEX = {'fb10': 1, 'fb15': 2, 'fb20': 3, 'fb25': 4}
CITY_START = {'fb10': 1, 'fb15': 5, 'fb20': 9, 'fb25': 13}
# 村庄名（`UserMapRelation.villageRelation` 的全量 26 条）
VILLAGE_NAME = {
    1: '白头村', 2: '莲花村', 3: '日暮村', 4: '金刀村', 5: '飞来村', 6: '三水村',
    7: '海棠村', 8: '石湖村', 9: '白云村', 10: '芦苇村', 11: '东林村', 12: '泗水村',
    13: '清水村', 14: '渔歌村', 15: '大兴村', 16: '青山村', 17: '十里村', 18: '瑶歌村',
    19: '玉带村', 20: '杏花村', 21: '云梦村', 22: '云来村', 23: '长乐村', 24: '丰乐村',
    25: '龙泉村', 26: '莫愁村',
}
# 村内区域（`villageAreaRelation`，**只有 20 条** ⇒ 上限必须 ≤ 20，否则她拼 nil 崩）
VILLAGE_AREA = {
    1: '村头', 2: '村尾', 3: '东村头', 4: '西村头', 5: '南村头', 6: '北村头',
    7: '东村尾', 8: '西村尾', 9: '南村尾', 10: '北村尾', 11: '东村', 12: '西村',
    13: '南村', 14: '北村', 15: '东村口', 16: '西村口', 17: '南村口', 18: '北村口',
    19: '东南村口', 20: '东北村口',
}
CITY = {'fb10': '扬州', 'fb15': '苏州', 'fb20': '襄阳', 'fb25': '长安'}

BID_WINDOW = 7 * 24 * 3600                  # 竞价窗口（她给她发的地契也是 3 天，这里给 7 天）
STORE_LIMIT = 12                            # `get_land_store_list` 一次给几块地（够铺满面板）
COLOR_RE = re.compile(r'(HIY|NOR|HIW|HIG|HIR|HIB|CYN|YEL|PNK|WHT|RED|GRN|BLU|MAG)')
DP_ROOM_PREFIX = ('fb301', 'fb302', 'fb303', 'fb304')


# ---------------------------------------------------------------------------
# 她自己的表
# ---------------------------------------------------------------------------


def _dp_table(ctx):
    """`familylist.lua["房屋地皮"]` —— 1088 块地（dpId 为键）。"""
    cache = getattr(_dp_table, '_cache', None)
    if cache:
        return cache
    dp = {}
    try:
        import fz_homeland_map
        dp = fz_homeland_map._tables().get('dp') or {}       # 服务端已经在用，直接借它的缓存
    except Exception:                                        # noqa: BLE001
        dp = {}
    if not dp:
        try:
            import fz_luatable
            fam = fz_luatable.load_lua_table(
                _fz_res('others', 'familylist.lua'))
            dp = fam.get('房屋地皮') or {}
        except Exception:                                    # noqa: BLE001
            dp = {}
    by_id = {v['dpId']: v for v in dp.values() if v.get('dpId')}
    _dp_table._cache = by_id
    return by_id


def _fq_table(ctx):
    """`familylist.lua["房契模板"]` —— 152 种房型（fqId 为键）。"""
    cache = getattr(_fq_table, '_cache', None)
    if cache:
        return cache
    out = {}
    try:
        import fz_homeland_map
        out = fz_homeland_map._tables().get('fq') or {}
    except Exception:                                        # noqa: BLE001
        out = {}
    if not out:
        try:
            import fz_luatable
            fam = fz_luatable.load_lua_table(
                _fz_res('others', 'familylist.lua'))
            out = fam.get('房契模板') or {}
        except Exception:                                    # noqa: BLE001
            out = {}
    _fq_table._cache = out
    return out


def _village_rooms(map_id):
    """某个村副本里带 `flag1` 的空地房间（`mapRoom/fb206..fb209.lua`）。"""
    cache = getattr(_village_rooms, '_cache', None)
    if cache is None:
        cache = {}
        _village_rooms._cache = cache
    if map_id in cache:
        return cache[map_id]
    rows = []
    try:
        import fz_luatable
        p = os.path.join(_fz_res('map', 'mapRoom'),
                         map_id + '.lua')
        if os.path.exists(p):
            for rid, r in fz_luatable.load_lua_table(p).items():
                if isinstance(r, dict) and r.get('flag1') is not None:
                    rows.append({'roomId': rid, 'loc_sort': r.get('flag1'),
                                 'name': r.get('name') or '空地',
                                 'fbname': r.get('fbname') or '',
                                 'dpRoomId': r.get('dpRoomId') or '',
                                 'dsc': r.get('dsc') or ''})
            rows.sort(key=lambda x: x['loc_sort'])
    except Exception:                                        # noqa: BLE001
        rows = []
    cache[map_id] = rows
    return rows


def _city_of(fb_id):
    """fb301/302/303/304 → fb10/15/20/25；已经是 fb10/15/20/25 就原样。"""
    s = str(fb_id or '')
    if s in COMMON_MAP_LIST:
        return COMMON_MAP_LIST[s]
    if s in FB_IDS:
        return s
    m = re.search(r'fb(\d+)', s)
    if m:
        # 城市副本号：10/15/20/25 → 就近取城
        for fb in FB_IDS:
            if re.search(r'fb0*%s$' % fb[2:], s) or fb[2:] in m.group(1):
                return fb
    return 'fb10'


def _arg(ctx, i, name=None, default=''):
    """安全取 `ctx.args[i]`（**空列表 `if ctx.args` 也是真** ⇒ 必须判长度）。"""
    if len(ctx.args) > i and ctx.args[i] not in (None, ''):
        return ctx.args[i]
    if name:
        v = ctx.param(name)
        if v not in (None, ''):
            return v
    return default


def _fail_with(ctx, data, errmsg, note, errcode=1):
    """errcode!=0 但**回调体仍要读 data** 的场合（`BiddingLayer` 的 errcode==2 分支）。

    `ctx.fail()` 只回 errcode+errmsg，她的 `setPrice(2, data.high_price)` 会拿到 nil
    ⇒ `attempt to compare/concatenate nil` 被 xpcall 吞掉。这里手拼一份带 data 的错误应答。
    """
    import time
    payload = {'errcode': errcode, 'errmsg': errmsg, 'data': data, 'rand_t': time.time()}
    if 'dataVer' not in payload['data']:
        payload['data'] = dict(payload['data'])
        payload['data']['dataVer'] = ctx.deps['next_dataver']()
    return ctx.enc(payload), note


def _strip_color(s):
    return COLOR_RE.sub('', str(s or ''))


# ---------------------------------------------------------------------------
# 账本
# ---------------------------------------------------------------------------
def _load(ctx):
    st = ctx.load_json(STATE, None)
    if not isinstance(st, dict):
        st = {}
    st.setdefault('bids', {})               # {uid|dpId: {...}}
    st.setdefault('owned', [])              # 买过但没搬入的地皮
    st.setdefault('on_land', {})            # 已经搬入的地皮
    st.setdefault('events', [])             # 竞价流水（日志用）
    return st


def _save(ctx, st):
    ctx.save_json(STATE, st)
    return st


def _bkey(ctx, dp_id):
    uid = str(ctx.headers.get('userid') or ctx.param('userid') or 'me')
    return '%s|%s' % (uid, dp_id)


def _points(ctx, st):
    """银票 —— **只认 `homeland_state.json.currency.yinpiao`**。

    ★ 那是全工程唯一一份钱袋子（`fz_boot_server.py:405` / `homeland_life.py` /
      `items_currency.py` / `misc_systems.py` 都读它）⇒ 本模块**不另造第二份钱**，
      只在竞价时真扣、退票时真加。老账本里若留着 `point`，第一次读就并过去。
    """
    home = ctx.load_json(HOME_STATE, {}) or {}
    cur = home.get('currency') if isinstance(home.get('currency'), dict) else {}
    try:
        if 'yinpiao' in (cur or {}):
            return int(cur.get('yinpiao') or 0)
    except (TypeError, ValueError):
        pass
    if isinstance(st.get('point'), int):        # 旧账本遗留 → 迁移一次
        return int(st['point'])
    return 0


def _set_points(ctx, st, value):
    st.pop('point', None)                       # 不再留本地副本，免得两边对不上
    home = ctx.load_json(HOME_STATE, {}) or {}
    cur = home.get('currency')
    if not isinstance(cur, dict):
        cur = {}
    cur['yinpiao'] = max(0, int(value))
    home['currency'] = cur
    ctx.save_json(HOME_STATE, home)          # ★ 只动 currency.yinpiao，其它键原样保留


def _set_on_land(ctx, st, dp_id, location, mid):
    st['on_land'] = {'dpId': dp_id, 'location': location,
                     'moved_at': int(time.time()), 'mid': mid}
    st['owned'] = [d for d in st.get('owned') or [] if d != dp_id]
    # `DiQiModel:moveHomeland` → `FangQiModel:updateInfo({location=..., dpId=...})`
    home = ctx.load_json(HOME_STATE, {}) or {}
    home['dpId'] = dp_id
    home['location'] = location
    ctx.save_json(HOME_STATE, home)
    return st


def _settle_bids(ctx, st):
    """竞价自动开奖 —— 到点的竞价出结果（没人加价就是价高者得）。"""
    now = int(time.time())
    changed = False
    for key, b in (st.get('bids') or {}).items():
        if b.get('claimed') or b.get('bid_state') != 1:
            continue
        if int(b.get('deadline') or 0) > now:
            continue
        dp_id = b.get('dpId') or ''
        top = str(b.get('top_uid') or '')
        if top and top == str(b.get('uid') or ''):
            b['bid_state'] = 2                        # 你赢了 → 可领地契
            b['dsc'] = '您已竞拍该土地成功，可领取对应地契。'
            ctx.log('地皮竞价开奖：%s 由 %s 以 %s 银票竞得（可领地契）'
                    % (dp_id, b.get('high_name'), b.get('high_price')))
        else:
            b['bid_state'] = 3                        # 别人更高 → 退银票
            b['return_point'] = int(b.get('price') or 0)
            b['dsc'] = '已有人出价比您更高，现将您竞价花费的 %s 银票返还。' % b['return_point']
            ctx.log('地皮竞价开奖：%s 被 %s 以 %s 银票超过（可退 %s）'
                    % (dp_id, b.get('high_name'), b.get('high_price'), b['return_point']))
        b['surplusTime'] = now + BID_WINDOW
        changed = True
    if changed:
        _save(ctx, st)
    return st


# ---------------------------------------------------------------------------
# 单条应答体（字段名/类型严格照她回调体给）
# ---------------------------------------------------------------------------
def _row_store(dp, st, ctx, now):
    """`BuyLandLayer:bingRow` 要的一条（其余字段由她 `Helper:tableCover(v, dpInfo)` 补）。"""
    dp_id = dp.get('dpId')
    b = (st.get('bids') or {}).get(_bkey(ctx, dp_id)) or {}
    price = int(dp.get('startprice') or 0)
    state = 1                                   # 1 上架  2 竞拍中  3 竞拍截止
    high_name = ''
    row = {
        'dpId': str(dp_id),
        'high_price': price,
        'state': state,
        'high_name': high_name,
        'cost': int(dp.get('cost') or 0),
        'place': str(dp.get('place') or ''),
        'name': str(dp.get('name') or ''),
        'color': str(dp.get('color') or 'HIW'),
    }
    if b.get('bid_state') == 1:
        row['high_price'] = int(b.get('high_price') or price)
        row['state'] = 2
        row['high_name'] = str(b.get('high_name') or '')
        row['surplusTime'] = int(b.get('deadline') or (now + BID_WINDOW))
    elif b.get('bid_state') == 3:
        row['high_price'] = int(b.get('high_price') or price)
        row['state'] = 3
        row['high_name'] = str(b.get('high_name') or '')
        row['surplusTime'] = int(b.get('surplusTime') or (now + BID_WINDOW))
    return row


def _row_query(dp, b, now):
    """`BiddingQueryLayer:initRightList` 要的一条（`pairs` 遍历 ⇒ 外层必须是数组）。"""
    row = {
        'dpId': str(dp.get('dpId') or b.get('dpId') or ''),
        'bid_state': int(b.get('bid_state') or 1),
        'high_price': int(b.get('high_price') or 0),
        'high_name': str(b.get('high_name') or ''),
        'return_point': int(b.get('return_point') or 0),
        'dsc': str(b.get('dsc') or ''),
        'surplusTime': int(b.get('surplusTime') or (now + BID_WINDOW)),
    }
    return row


# ---------------------------------------------------------------------------
def handle(ctx):
    ep = ctx.endpoint
    st = _load(ctx)
    _settle_bids(ctx, st)
    now = int(time.time())
    dp_tbl = _dp_table(ctx)

    # ---------------------------------------------------------------- 售地表
    if ep == 'get_land_store_list':
        # `HomelandModule.lua:411 ["购地"]` → `BuyLandLayer:showLayer(map.id, currRole.id)`
        fb = _city_of(_arg(ctx, 0, 'fbId') or ctx.param('mapId') or 'fb301')
        npc = str(ctx.param('npcId') or '')
        # 优先按她表里同城的 `房屋地皮`（fbId 一致）；不够就按 place 前缀补
        rows = [v for v in dp_tbl.values() if v.get('fbId') == fb]
        if not rows:
            city = CITY.get(fb, '')
            rows = [v for v in dp_tbl.values() if city and str(v.get('place') or '').startswith(city)]
        if not rows:                                   # 再兜底：任何一块都别回空表
            rows = list(dp_tbl.values())
        # 「城中心」的豪宅排前面（贵、显眼），其余按 dpId 稳定排序
        rows.sort(key=lambda v: (0 if '中心' in str(v.get('place') or '') else 1,
                                 str(v.get('dpId') or '')))
        lst = [_row_store(v, st, ctx, now) for v in rows[:STORE_LIMIT]]
        has_land = 'Y' if (st.get('on_land') or {}).get('dpId') else 'N'
        point = _points(ctx, st)
        ctx.log('售地表 %s（npc=%s）：%d 块，银票 %d，hasLand=%s'
                % (fb, npc or '-', len(lst), point, has_land))
        return ctx.ok({'list': lst, 'hasLand': has_land, 'point': point},
                      '★ 售地表（%s，%d 块，取自 familylist["房屋地皮"]）' % (fb, len(lst)))

    # ---------------------------------------------------------------- 竞价
    if ep == 'bidding_land':
        # `BiddingLayer:86` → biddingLand(dpId, npcId, _land.high_price + {100,500,1000})
        dp_id = str(_arg(ctx, 0, 'dpId'))
        dp = dp_tbl.get(dp_id)
        if not dp:
            return ctx.fail('没有这块地皮的信息：%s' % dp_id, '★ 竞价失败（dpId 不在她表里）')
        try:
            price = int(float(ctx.param('price') or 0))
        except (TypeError, ValueError):
            price = 0
        start = int(dp.get('startprice') or 0)
        key = _bkey(ctx, dp_id)
        b = (st['bids'].get(key) or {})
        top = int(b.get('high_price') or start)
        mine_name = str(ctx.headers.get('pkname') or ctx.param('name') or '')
        uid = str(ctx.headers.get('userid') or '')
        if price <= top:
            # ★ errcode==2 时她**只读 data**：`setPrice(2, data.high_price)`、
            #   `setCurrHighName(..., data.high_name)` ⇒ 这两个字段必须给，
            #   否则 `setCurrHighName` 里 `type(name) ~= "string"` 直接 return（价格也不刷新）。
            b.setdefault('dpId', dp_id)
            b.setdefault('uid', uid)
            b.setdefault('high_name', b.get('high_name') or '')
            b.setdefault('high_price', top)
            b.setdefault('deadline', now + BID_WINDOW)
            b.setdefault('bid_state', 1)
            b.setdefault('dsc', '')
            b.setdefault('return_point', 0)
            b['surplusTime'] = int(b.get('deadline') or now + BID_WINDOW)
            st['bids'][key] = b
            _save(ctx, st)
            return _fail_with(ctx, {'high_price': top, 'high_name': b.get('high_name') or '',
                                    'surplusTime': b['surplusTime']},
                              '当前最高价已经是%d银票了' % top,
                              '★ 竞价被压过（%s 当前 %d）' % (dp_id, top), errcode=2)
        point = _points(ctx, st)
        # ★ `BiddingLayer:84` 传的是**绝对价** `_land.high_price + aPrice`，
        #   所以只补收差额（之前已为这块地付过的部分不重复扣）；从未出价则差额=全额。
        paid = int(b.get('price') or 0)
        if not b.get('uid'):
            paid = 0
        need = price - paid
        removed = 0
        if need > 0:
            if point < need:
                return ctx.fail('银票不足，需要%d银票' % need, '★ 竞价失败（银票不足）')
            removed = need
            _set_points(ctx, st, point - need)
        b.update({
            'dpId': dp_id, 'uid': uid, 'npcId': str(ctx.param('npcId') or ''),
            'price': price, 'high_price': price, 'top_uid': uid,
            'high_name': mine_name, 'bid_state': 1, 'deadline': now + BID_WINDOW,
            'return_point': 0, 'claimed': False,
            'dsc': '竞价人为：%s' % mine_name,
        })
        st['bids'][key] = b
        st.setdefault('events', []).append(
            {'t': now, 'dpId': dp_id, 'uid': uid, 'price': price, 'remove_point': removed})
        st['events'] = st['events'][-40:]
        _save(ctx, st)
        ctx.log('地皮竞价 %s → %d 银票（扣 %d，剩 %d）' % (dp_id, price, removed, _points(ctx, st)))
        return ctx.ok({'surplusTime': now + BID_WINDOW, 'remove_point': removed,
                       'high_price': price, 'high_name': mine_name},
                      '★ 竞价成功（%s %d 银票，扣 %d）' % (dp_id, price, removed))

    # ---------------------------------------------------------------- 竞价结果查询
    if ep == 'query_bidding_info':
        rows = []
        for key, b in (st.get('bids') or {}).items():
            if b.get('claimed'):
                continue                                 # 已领地契的不再挂面板上
            if not b.get('dpId'):
                continue
            dp = dp_tbl.get(b['dpId'])
            if not dp:
                continue                                 # 她 `getDpInfoById` 会 assert，必须过滤
            rows.append(_row_query(dp, b, now))
        rows.sort(key=lambda r: (r['bid_state'], r['dpId']))
        point = _points(ctx, st)
        ctx.log('购地信息：%d 条竞价记录，银票 %d' % (len(rows), point))
        return ctx.ok({'list': rows, 'point': point},
                      '★ 竞价信息（%d 条，真数据）' % len(rows))

    # ---------------------------------------------------------------- 领地契
    if ep == 'get_bidding_land':
        dp_id = str(_arg(ctx, 0, 'dpId'))
        key = _bkey(ctx, dp_id)
        b = (st.get('bids') or {}).get(key)
        if not b or b.get('bid_state') not in (1, 2):
            return ctx.fail('没有可领取的地契：%s' % dp_id, '★ 领地契失败')
        b['bid_state'] = 2
        b['claimed'] = True
        b['claim_time'] = now
        if dp_id not in st['owned']:
            st['owned'].append(dp_id)
        _save(ctx, st)
        ctx.log('领取地契：%s（她 `DiQiModel:getDiQi` 会加物品 dq_%s）' % (dp_id, dp_id))
        return ctx.ok({}, '★ 领取地契（%s）' % dp_id)

    # ---------------------------------------------------------------- 退银票
    if ep == 'get_bidding_return_point':
        dp_id = str(_arg(ctx, 0, 'dpId'))
        key = _bkey(ctx, dp_id)
        b = (st.get('bids') or {}).get(key)
        back = int((b or {}).get('return_point') or 0)
        if b:
            b['return_point'] = 0
            b['bid_state'] = 3
            if not b.get('claimed'):
                st['bids'].pop(key, None)                # 领过票就不再挂在购地信息里
        _set_points(ctx, st, _points(ctx, st) + back)
        _save(ctx, st)
        ctx.log('竞价返还：%s → %d 银票（现在 %d）' % (dp_id, back, _points(ctx, st)))
        return ctx.ok({'return_point': back},
                      '★ 返还银票（%s，%d）' % (dp_id, back))

    # ---------------------------------------------------------------- 搬家
    if ep == 'move_home_land':
        # `DiQiModel:moveHomeland` → moveHomeland(dpId, fq.mid)
        dp_id = str(_arg(ctx, 0, 'dpId'))
        mid = str(_arg(ctx, 1, 'mid'))
        dp = dp_tbl.get(dp_id)
        if not dp:
            return ctx.fail('没有这块地皮的信息：%s' % dp_id, '★ 搬家失败（dpId 不在她表里）')
        location = '%s%s' % (dp.get('place') or '', dp.get('name') or '')
        _set_on_land(ctx, st, dp_id, location, mid)
        _save(ctx, st)
        ctx.log('搬家落位：%s → %s（`FangQiModel:updateInfo` 会写 location/dpId）'
                % (dp_id, location))
        return ctx.ok({}, '★ 搬入土地（%s %s）' % (dp_id, location))

    # ---------------------------------------------------------------- 回收地皮
    if ep == 'recycle_land':
        # `DiQiModel:recycleLand`：地契超时未搬入 ⇒ 地皮回库存、删背包地契
        dp_id = str(_arg(ctx, 0, 'dpId'))
        key = _bkey(ctx, dp_id)
        st['owned'] = [d for d in st.get('owned') or [] if d != dp_id]
        st['bids'].pop(key, None)
        if (st.get('on_land') or {}).get('dpId') == dp_id:
            st['on_land'] = {}                       # 搬过又被回收 ⇒ 她那边也会清 dpId
            home = ctx.load_json(HOME_STATE, {}) or {}
            home['dpId'] = ''
            home['location'] = ''
            ctx.save_json(HOME_STATE, home)
        _save(ctx, st)
        ctx.log('回收地皮：%s 回到库存' % dp_id)
        return ctx.ok({}, '★ 回收地皮（%s）' % dp_id)

    # ---------------------------------------------------------------- 地税欠费
    if ep == 'get_manage_payment':
        dp_id = str(_arg(ctx, 0, 'dpId'))
        dp = dp_tbl.get(dp_id) or {}
        on = st.get('on_land') or {}
        if on.get('dpId') and on.get('dpId') == dp_id:
            moved = int(on.get('moved_at') or now)
            day = max(0, (now - moved) // 86400)
        else:
            day = 0
        cost = int(dp.get('cost') or 0)              # `cost` = 她的「元宝/天」地税
        total = day * cost
        ctx.log('地皮欠费 %s：欠 %d 天 × %d = %d 元宝' % (dp_id or '-', day, cost, total))
        return ctx.ok({'day': day, 'total_pay': total},
                      '★ 地税欠费（%s：%d 天 / %d 元宝）' % (dp_id or '-', day, total))

    # ---------------------------------------------------------------- 按 dpId 查地（补领地契用）
    if ep == 'get_land_info_by_dp':
        dp_id = str(_arg(ctx, 0, 'dpId'))
        dp = dp_tbl.get(dp_id) or {}
        b = (st.get('bids') or {}).get(_bkey(ctx, dp_id)) or {}
        return ctx.ok({
            'dpId': dp_id, 'name': str(dp.get('name') or ''), 'place': str(dp.get('place') or ''),
            'dsc': str(dp.get('dsc') or ''), 'roomdsc': str(dp.get('roomdsc') or ''),
            'startprice': int(dp.get('startprice') or 0), 'cost': int(dp.get('cost') or 0),
            'color': str(dp.get('color') or 'HIW'), 'fbId': str(dp.get('fbId') or ''),
            'dpRoomId': str(dp.get('dpRoomId') or ''),
            'bid_state': int(b.get('bid_state') or 0),
            'now_time': now,
        }, '★ 地皮信息（%s）' % dp_id)

    # ---------------------------------------------------------------- 车夫·询址上限
    if ep == 'get_location_max':
        # `HomelandModule.lua:100 ["询址"]` → getLocationMax(mapIndex)
        #   她随后 `layer:setTotalList(startIndex, limit)`：
        #     limit[1] 城市区域上限（分段）  limit[2] 城市方向上/下界  limit[3] 村庄上限
        #     limit[4] 村内区域上限（**必须 ≤ 她 villageAreaRelation 的 20 条**）
        raw = str(_arg(ctx, 0, 'mapIndex', '1'))
        m = re.search(r'\d+', raw)
        idx = int(m.group()) if m else 1
        fb = {1: 'fb10', 2: 'fb15', 3: 'fb20', 4: 'fb25'}.get(idx, 'fb10')
        start = CITY_START[fb]
        # 城市方向：她那段 cityDirRelation 是 5 条一段（1-4 / 5-8 / 9-12 / 13-16）
        limits = [start + 3, start + 3, start + 6, 14]
        ctx.log('车夫询址上限 mapIndex=%d(%s) → max=%s' % (idx, fb, limits))
        return ctx.ok({'max': limits},
                      '★ 询址上限（%s → %s，取自 UserMapRelation）' % (fb, limits))

    # ---------------------------------------------------------------- 车夫·传送到村
    if ep == 'get_location_map':
        # `UserMap:goVillageMap` → getLocationMap(loc_mark={城市区域,城市方向,村庄,村内区域})
        #   她拿 `data.list` 去 `Helper:tableCover(toMap.room[mRoomId], roomInfo)`
        #   —— 用 `roomInfo.loc_sort` 去配房间的 `flag1`。我们按这个契约把村里
        #   14 个空地房间的真实 `flag1/roomId/name/dsc` 发下去，**她自己的地图资源**
        #   决定布局（`res/script/map/mapRoom/fb206..fb209.lua`）。
        loc = ctx.param('loc_mark')
        if not isinstance(loc, (list, tuple)):
            try:
                import json
                loc = json.loads(str(ctx.param('loc_mark') or '[]'))
            except Exception:                                # noqa: BLE001
                loc = []
        loc = list(loc or [])
        try:
            village = int(loc[2]) if len(loc) > 2 else 1
        except (TypeError, ValueError):
            village = 1
        map_id = VILLAGE_MAP_ID.get(village, 'fb206')
        on = st.get('on_land') or {}
        out = []
        for r in _village_rooms(map_id):
            row = {
                'loc_sort': int(r['loc_sort']),
                'roomId': str(r['roomId']),
                'name': str(r['name'] or '空地'),
                'dsc': str(r['dsc'] or '一块土地，里面荒草丛生。'),
                'dpRoomId': str(r['dpRoomId'] or ''),
            }
            if on.get('dpId'):
                # 已经搬入的地皮：把 dpId 挂上，`HomelandRoomUtil:outDoorByDp` 要找它
                row['dpId'] = str(on['dpId'])
                row['location'] = str(on.get('location') or '')
                row['mid'] = str(on.get('mid') or '')
            out.append(row)
        ctx.log('车夫传送 loc_mark=%s → %s（%s），%d 个空地房间'
                % (loc, map_id, VILLAGE_NAME.get(village, ''), len(out)))
        return ctx.ok({'list': out},
                      '★ 村庄地皮表（%s %s，%d 个空地）'
                      % (VILLAGE_NAME.get(village, ''), map_id, len(out)))

    # ---------------------------------------------------------------- 江湖怪客奖励
    if ep == 'get_guaike_reward':
        # `JiangHuGuaiKeModel:getWinRewards`（:195-）
        dp = _pick_on_land(ctx, st, dp_tbl)
        level = int(ctx.param('guaikeLv') or 1)
        cost = int(dp.get('cost') or 0)
        yinpiao = max(50, cost * 3)
        yueli = 20 + 10 * max(1, level)
        weiwang = 5 + 5 * max(1, level)
        data = {
            'yinpiao': yinpiao, 'yueli': yueli, 'weiwang': weiwang,
            'activityItems': [],
            'defaultZhongCheng': 0,
            'level_up': False,
            'trait': {},
        }
        ctx.log('怪客奖励：%s 级 lv=%d → 银票%d 阅历%d 威望%d'
                % (str(ctx.param('guaikeName') or '-'), level, yinpiao, yueli, weiwang))
        return ctx.ok(data, '★ 江湖怪客奖励（银票%d/阅历%d/威望%d）' % (yinpiao, yueli, weiwang))

    # ---------------------------------------------------------------- 身世任务奖励
    if ep == 'get_shenshi_reward':
        # `MapOuYuModule.lua:78 ["完成身世任务"]`（注释里写死了应答形状）
        #   type==1 → pay_base{unit,val}；type==2 → pay_time(时间戳)；type==3 → mobanSkill(表)
        try:
            rtype = int(float(ctx.param('type') or 0))
        except (TypeError, ValueError):
            rtype = 0
        data = {}
        if rtype == 1:
            data['pay_base'] = {'unit': 'yinpiao', 'val': 20}
        elif rtype == 2:
            days = 7
            try:
                days = max(1, int(float(ctx.param('up_data') or 7)))
            except (TypeError, ValueError):
                days = 7
            data['pay_time'] = now + days * 86400
        elif rtype == 3:
            data['mobanSkill'] = {}
        ctx.log('身世任务奖励：type=%s objId=%s → %s'
                % (rtype, ctx.param('objId'), sorted(data.keys())))
        return ctx.ok(data, '★ 身世任务奖励（type=%d）' % rtype)

    # ---------------------------------------------------------------- 梦境过期结算
    if ep == 'settle_overdue_dream':
        # `XiangLuModel.lua:297` → checkDreamRoleDataIsOverdue
        #   errcode==0 时才读 `data.eventsInfo`(表) 与 `data.reward`(表)；
        #   errcode==2/-2 她会转去 `getDreamRoleData()`。
        # ★ 2026-10-04 修复「入梦不生效」：以前这里回 ctx.ok（errcode=0="有过期梦境，
        #   请结算"），客户端每次睡觉都打印"大于72小时没继续梦境闯荡…结算："然后
        #   **结算完不继续** ⇒ 永远入不了梦（客户实测）。我们这边没有存过期梦境，
        #   正确语义 = errcode=2（无过期梦境 → 她直接走入梦/开新梦流程）。
        ctx.log('梦境过期结算：无过期数据，回 errcode=2 让她走入梦流程')
        return ctx.fail('没有需要结算的过期梦境', '★ 梦境过期结算（errcode=2，放行走入梦）', 2)

    return None


def _pick_on_land(ctx, st, dp_tbl):
    """当前搬入的那块地；没有就退回自己家的同号地皮，再退同城第一块。"""
    on = (st.get('on_land') or {}).get('dpId')
    if on and on in dp_tbl:
        return dp_tbl[on]
    home = ctx.load_json(HOME_STATE, {}) or {}
    fq = home.get('fqId')
    if fq and fq in dp_tbl:
        return dp_tbl[fq]
    for v in dp_tbl.values():
        if str(v.get('place') or '').startswith('扬州'):
            return v
    return next(iter(dp_tbl.values()), {})
