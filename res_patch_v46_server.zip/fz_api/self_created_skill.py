# -*- coding: utf-8 -*-
# ================= 离线包路径根（fz_make_offline_bundle.py 自动注入） =================
# 手机上整个服务端就是一个目录，表在哪、状态写哪，全部相对包根算。
# （有的模块原来把绝对路径写死，本身没 import os —— 这里一并补上）
import os
import os as _osp


def _off_find_bundle(_f):
    """从模块所在目录往上找包根（认 fz_boot_server.py）。
    ★ fz_api/*.py 的 __file__ 在 <根>/fz_api/ 下，直接 dirname 会算错一层。"""
    _d = _osp.path.dirname(_osp.path.abspath(_f))
    for _ in range(6):
        if _osp.path.exists(_osp.path.join(_d, 'fz_boot_server.py')):
            return _d
        _u = _osp.path.dirname(_d)
        if _u == _d:
            break
        _d = _u
    return _osp.path.dirname(_osp.path.abspath(_f))


_OFF_BUNDLE = _off_find_bundle(__file__)
_OFF_FZ_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_fz')
_OFF_INK_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_ink')
_OFF_WORK_ROOT = _OFF_BUNDLE
# =====================================================================================
# ★ 2026-10-04 商城空货架修复：客户端资源表解析——PC 开发树优先，设备上自动回退
#   到包内 client_fz 副本（jhserver/client_fz = fangzhi_lua_dec 的同步拷贝）。
def _fz_res(*parts):
    base = os.path.join(_OFF_FZ_ROOT, 'res', 'script')
    if not os.path.isdir(base):
        base = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            '..', 'client_fz', 'res', 'script')
    return os.path.join(base, *parts)

# -*- coding: utf-8 -*-
"""神功·自创武学（书房）—— 1:1 还原她客户端的「自创武学 / 书架 / 招式词缀」接口。

契约出处（都在她 `assets/src` 里，逐个读过）：
  * `app/models/SelfCreatedSkillSystem/SelfCreatedSkillModel.lua`（**每个接口读哪个 data 字段**）
      - getCreateBooks → `data.createdBooks`(数组) / `data.creatingBook`(对象)
      - createZhao     → `data.createdBooks`(数组) / `data.point`(对象:liquan,daily_point)
                       / 回调里 `data.result`(bool) + `data.zhaoData`(对象) + `.zhaos`(单条招式对象)
      - completeBook   → `data.createdBooks[1]`(新书对象，直接 table.insert 进书架)
      - learnSkillBook → `data.createdBooks[1]`(书对象)
      - deleteCompletedBook → `data.skillId`(书数据id，被 tostring)
      - getZhaoColors / unlockZhaoColor / getSkillNameAffixs / unlockSkillNameAffixs
                       → `data.lists`(数组)
      - getZhaoDscs / unlockZhaoDsc → `data.lists`(数组)
      - getZhaoSuccessRate → `data.successRate`(数字，与 0.9/0.7/0.5/0.3 比较)
      - setZhaoAttr    → 回调忽略 data（只当成功信号），本模块仍回真实结果
  * 数据结构：`SelfCreatedSkillSystem.lua` 顶部注释 + `map/MapHandle/Modules/
      SelfCreatedSkillModule/SelfCreatedSkillModule.lua`（她服务端上行数据的原样结构：
      `{id,name,colorId,templateId,outputType,zhaos}`，招式
      `{index,name,colorId,dscId,quality,useType,templateId,atkAffixs,defAffixs}`）。
  * 列表项字段（UI 逐行读出来的）：
      - `get_zhaoColors`      → 每项 `{id(颜色表键), state(1解锁/0待买), price(=yuanbao)}`
        `presenters/selfCreatedSkill/zhaoModify/ZhaoModifyPresenter.lua:108-167`
      - `get_skillName_affixs`→ 每项 `{id(后缀表键), state, price}`
        `presenters/selfCreatedSkill/createdSkill/CreatedSkillPresenter.lua:81-137`
      - `get_zhaoDscs`        → 每项 `{id(文本表键), xiLieId(系列表键), state, price}`
        `presenters/selfCreatedSkill/zhaoSelectDsc/ZhaoSelectDscPresenter.lua:38-105`
        （**列表按系列分组**：已解锁系列列全部 48+ 条描述供挑选；未解锁系列只列 1 条
          代表行（该行 state=0，点它进入"购买整个系列"的 ShoppingDialogLayer），
          否则同一系列会重复出现 50 条一模一样的购买行。）
  * `set_zhao_attr` 上行的 params：`{skillId, zhaoIndex, name, colorId, dscId}`
      （`ZhaoModifyPresenter.lua:173-179` / `CreatedZhaoPresenter.lua:55-59,83-87`）

内容全部取自她自己的资源表（`assets/res/script/selfCreatedSkill/*.lua`，
用 `work/fz_luatable.py` 解析）：
  * `skillTemplates.lua["skills"]`          —— 15 个自创武学模板（thirdType/methods/suffix/baseZhaos）
  * `zhaoTemplates.lua["招式"]`              —— 497 条招式模板（type=武学三型, grade=需求等级,
                                               outputType=1 服务器自创 / 2 历练）
  * `zhaosTrait.lua["新版招式特性"]`          —— 157 条招式特性（affixId → affixName/effextType/Param）
  * `liLianTaskZhaos.lua["词缀规则"]`         —— 特性数值（isRandom=1 的 55 条＝随机词缀池）
  * `liLianTaskZhaos.lua["招式规则"]`         —— 基础招式(baseZhaos)，同时提供"品质→词缀条数"的真实分布
  * `zhaoColors.lua["颜色表"]`               —— 12 种招式颜色（lock/yuanbao/field1-3/image/ywName）
  * `skillAfterAffix.lua["后缀内容"]`         —— 111 个武学名后缀（lock/yuanbao/type/name）
  * `zhaosText.lua["文本内容"]`+`["系列"]`    —— 招式描述文本 3958 条 / 84 个描述系列（wxtype/lock/yuanbao）
  * `nameLibrary.lua["招式"]`                —— 招式随机名字库（复刻 `ZhaoCreator:createRandomName` 的组合规则）
  * `params.lua["通用参数"]`                 —— complete_all_num(6) / creat_zhao_numMax
  * `propMap.lua["Sheet1"]`                  —— 创作/改良道具（本模块只用于 `prop` 字段占位）

持久状态：`work/selfskill_state.json`（按 `userid` 分玩家）
    players[<userid>] = {
        books      : [{id,templateId,name,colorId,outputType,prop,unlocks,zhaos[]}]  已完成的书（真实创作结果）
        creating   : {id,name,templateId,zhaos[],prop,outputType,unlocks} | null   正在创作的书
        nextId     : 下一个书籍数据id（单调递增，从 1 开始）
        colors     : [已解锁的颜料id]
        affixs     : [已解锁的后缀id]
        dscXiLie   : [已解锁的描述系列id]
        learned    : [已学习过的书籍id]
    }

**与原版的已知差异 / 还没做**（她客户端有按钮、但需要别的系统配合的）：
  1. 颜料/后缀/描述系列解锁**没有扣元宝**（角色货币在存档/别的模块里，本模块不碰）。
  2. `create_zhao` 没有做「创作CD(errcode=9)」「每日上限(errcode=10)」，也不扣潜能/精力
     （潜能/精力由客户端本地 `role:addAttr` 处理，服务端没有角色属性通道）。
  3. 用创作道具加成功率 / 改良道具（`use_create_prop` / `use_improve_prop`）不在本模块接口里。
  4. 招式**品质/等级**是按她 `zhaoTemplate` 的 grade 分档 + `tujianLv(maps)` 权重**近似**生成
     （原版公式不在客户端里）；**词缀条数与数值完全照她表里的分布/数据来**（见 `_roll_affixs`）。
  5. **一招必成**：`create_zhao` 在"这本书还没任何招式"时强制成功。理由是她客户端拿到
     `result=false` 时不会给 `SkillCreator` 建模板，紧接着 `ZhaosLibraryPresenter:showLayer`
     会 `ipairs(nil)` / `".."..nil` 崩掉 ⇒ 整个自创 UI 卡死。第二招起才按成功率（`get_successRate`）
     掷骰（0.95 - 0.045×已有招式数 + lv 微调，夹在 0.05~0.95）。
  6. `get_books` 的书 `id` 用**单调递增的字符串**（"1"/"2"/…），和客户端
     `SkillHelper:selfCreatedSkillDataIdToSkillId` 拼出的 `userid_selfCreatedSkill_<id>` 一致。
"""
import os
import random
import threading
import traceback

NAME = 'self_created_skill'
TITLE = '神功·自创武学（书房）'
ENDPOINTS = [
    'get_books',
    'create_zhao',
    'learn_book',
    'delete_book',
    'complete_book',
    'get_skillName_affixs',
    'unlock_skillName_affixs',
    'get_successRate',
    'get_zhaoColors',
    'unlock_zhaoColor',
    'get_zhaoDscs',
    'unlock_zhaoDsc_xiLie',
    'set_zhao_attr',
]

STATE = 'selfskill_state.json'
RES_DIR = _fz_res('selfCreatedSkill')

# ---------------------------------------------------------------------------
# 资源表（懒加载 + 缓存；任何一张表读不到都退化成 {}，绝不让接口抛异常）
# ---------------------------------------------------------------------------
_RES = {}
_RES_READY = False
_RES_LOCK = threading.Lock()




def _num(v, default=0):
    """她表里的数字字段可能是 int/float/数字字符串，统一成 int/float。"""
    if isinstance(v, bool) or v is None:
        return default
    if isinstance(v, (int, float)):
        return v
    try:
        f = float(str(v).strip())
    except (TypeError, ValueError):
        return default
    return int(f) if f.is_integer() else f


def _key(v):
    """表键统一成字符串（她 lua 表里既有 `["1"]` 也有 `[1]`）。"""
    if v is None:
        return ''
    if isinstance(v, bool):
        return 'true' if v else 'false'
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v).strip()


def _load_table(fname, *keys):
    try:
        import fz_luatable
        t = fz_luatable.load_lua_table(os.path.join(RES_DIR, fname))
        for k in keys:
            t = t[k]
        return t if isinstance(t, dict) else {}
    except Exception:                                  # noqa: BLE001
        return {}


def _ensure_res():
    global _RES_READY
    if _RES_READY:
        return
    with _RES_LOCK:
        if _RES_READY:
            return
        lilian = _load_table('liLianTaskZhaos.lua')
        _RES['skill_tpl'] = _load_table('skillTemplates.lua', 'skills')
        _RES['zhao_tpl'] = _load_table('zhaoTemplates.lua', '招式')
        _RES['trait'] = _load_table('zhaosTrait.lua', '新版招式特性')
        _RES['color'] = _load_table('zhaoColors.lua', '颜色表')
        _RES['affix_txt'] = _load_table('skillAfterAffix.lua', '后缀内容')
        zhaos_text = _load_table('zhaosText.lua')
        _RES['dsc_txt'] = zhaos_text.get('文本内容') or {}
        _RES['dsc_series'] = zhaos_text.get('系列') or {}
        _RES['name_lib'] = _load_table('nameLibrary.lua', '招式')
        params = _load_table('params.lua', '通用参数')
        _RES['params'] = params
        # 她 lua 表里键既有 `["1"]` 也有 `[1]`，统一成字符串键，查表时不会再"明明有却查不到"
        for name in ('skill_tpl', 'zhao_tpl', 'trait', 'color', 'affix_txt',
                     'dsc_txt', 'dsc_series'):
            t = _RES.get(name)
            if isinstance(t, dict):
                _RES[name] = {_key(k): v for k, v in t.items()}
        # 随机词缀池：她 `LiLianMapPropSystem.lua:74` 用的就是这 55 条 isRandom=1 的规则
        affix_rule = lilian.get('词缀规则') or {}
        trait = _RES['trait']
        _RES['affix_rule'] = affix_rule
        _RES['affix_random'] = [
            r for r in affix_rule.values()
            if _num(r.get('isRandom'), 0) == 1 and _key(r.get('affixId')) in trait
        ]
        # 参数：完成需要的总招式数 / 每种武学三型的招式上限
        _RES['complete_all_num'] = _num(
            (params.get('complete_all_num') or {}).get('param'), 6) or 6
        zhao_max = {}
        for seg in str((params.get('creat_zhao_numMax') or {}).get('param') or '').split('|'):
            parts = seg.split('#')
            if len(parts) >= 2:
                zhao_max[_key(parts[0])] = _num(parts[1], 49)
        _RES['zhao_max'] = zhao_max
        # 索引：武学三型 → 招式模板；描述系列 → 文本；武学三型 → 描述系列
        zhao_by_type = {}
        for tpl in _RES['zhao_tpl'].values():
            if _num(tpl.get('outputType'), 0) != 1:       # 只要"服务器自创"的招式模板
                continue
            zhao_by_type.setdefault(_key(tpl.get('type')), []).append(tpl)
        _RES['zhao_by_type'] = zhao_by_type
        skill_by_third = {}
        for tpl in _RES['skill_tpl'].values():
            skill_by_third.setdefault(_key(tpl.get('thirdType')), tpl)
        _RES['skill_by_third'] = skill_by_third
        # 文本表：id 必须是纯数字才安全（客户端要拿它当 tostring 键）
        text_by_series, all_texts = {}, []
        for tid, txt in _RES['dsc_txt'].items():
            if not _key(tid).isdigit():
                continue
            sid = _key(txt.get('seriesId'))
            all_texts.append(_key(tid))
            text_by_series.setdefault(sid, []).append(_key(tid))
        _RES['text_by_series'] = text_by_series
        _RES['all_text_ids'] = all_texts
        series_by_type = {}
        for sid, s in _RES['dsc_series'].items():
            series_by_type.setdefault(_key(s.get('wxtype')), []).append(_key(sid))
        _RES['series_by_type'] = series_by_type
        _RES_READY = True


def _res(name, default=None):
    _ensure_res()
    v = _RES.get(name)
    return default if v is None else v


# ---------------------------------------------------------------------------
# 状态
# ---------------------------------------------------------------------------
def _load(ctx):
    st = ctx.load_json(STATE, {})
    if not isinstance(st, dict):
        st = {}
    if not isinstance(st.get('players'), dict):
        st['players'] = {}
    return st


def _uid(ctx):
    """她客户端上行头就是 `userid` / `uuid`（`BaseHttp.lua:145-146`），大小写兜一下。"""
    h = ctx.headers if isinstance(ctx.headers, dict) else {}
    for k in ('userid', 'uuid'):
        if h.get(k):
            return _key(h[k])
    for k, v in h.items():
        if str(k).lower() in ('userid', 'uuid') and v:
            return _key(v)
    return _key(ctx.param('userid')) or 'default'


def _me(ctx, st):
    uid = _uid(ctx)
    p = st['players'].setdefault(uid, {})
    if not isinstance(p.get('books'), list):
        p['books'] = []
    if not isinstance(p.get('creating'), dict):
        p['creating'] = None
    for k in ('colors', 'affixs', 'dscXiLie', 'learned'):
        if not isinstance(p.get(k), list):
            p[k] = []
    p['nextId'] = _num(p.get('nextId'), 1) or 1
    return p


def _save(ctx, st):
    ctx.save_json(STATE, st)


def _find_book(p, book_id):
    bid = _key(book_id)
    if not bid:
        return None
    for b in p['books']:
        if _key(b.get('id')) == bid:
            return b
    return None


def _find_zhao(book, zhao_index):
    if not isinstance(book, dict):
        return None
    zhaos = book.get('zhaos')
    if not isinstance(zhaos, list):
        return None
    idx = _num(zhao_index, 0)
    for z in zhaos:
        if _num(z.get('index'), -1) == idx:
            return z
    i = int(idx) - 1
    if 0 <= i < len(zhaos):
        return zhaos[i]
    return None


# ---------------------------------------------------------------------------
# 她的资源表里"生成一条真招式"需要的东西
# ---------------------------------------------------------------------------
def _unlocked_series(p, wxtype):
    """这个武学三型下、当前已解锁的描述系列id列表。"""
    out = []
    series = _res('dsc_series', {})
    owned = set(_key(x) for x in p.get('dscXiLie') or [])
    for sid in _res('series_by_type', {}).get(_key(wxtype), []):
        s = series.get(sid) or {}
        if _num(s.get('lock'), 1) == 0 or sid in owned:
            out.append(sid)
    return out


def _unlocked_colors(p):
    out = []
    owned = set(_key(x) for x in p.get('colors') or [])
    for cid, c in _res('color', {}).items():
        if _num(c.get('lock'), 1) == 0 or cid in owned:
            out.append(cid)
    return out


def _random_name(rng, max_len=5):
    """复刻 `ZhaoCreator:createRandomName` 的词序（`nameLibrary.lua["招式"]`）。

    她客户端 `CreatedZhaoPresenter:checkZhaoName` 限招式名 ≤5 个汉字，所以这里重试到
    合法长度（不足则退化成最短词序 `words1+words2`）。
    """
    lib = _res('name_lib', {})
    if not lib:
        return '无名招式'
    orders = [
        ('words1', 'words2'),
        ('words1', 'words1', 'words2'),
        ('words1', 'words1', 'words1', 'words2'),
        ('words3', 'words2'),
        ('words1', 'words3', 'words2'),
        ('words3', 'words1', 'words2'),
        ('words3', 'words3', 'words2'),
        ('words1', 'words3'),
    ]
    pool = {}
    for row in lib.values():
        if not isinstance(row, dict):
            continue
        for w in ('words1', 'words2', 'words3', 'words4'):
            if row.get(w):
                pool.setdefault(w, []).append(row[w])
    tries = list(orders)
    rng.shuffle(tries)
    tries += [orders[0]] * 6                            # 兜底：最短词序 words1+words2 一定合法
    for order in tries:
        name = ''
        for w in order:
            vals = pool.get(w) or []
            if vals:
                name += str(rng.choice(vals))
        if 0 < len(name) <= max_len:
            return name
    return '无名招式'


def _roll_quality(maps, rng):
    """品质受"图鉴lv(maps)"影响：图鉴越高越容易出高品质（原版公式不在客户端里）。"""
    m = max(0, min(12, int(_num(maps, 1))))
    weights = [max(1, 35 - 2 * m), 30 + 2 * m, 18 + 3 * m, 3 + 2 * m]
    return rng.choices([1, 2, 3, 4], weights=weights)[0]


def _pick_zhao_tpl(third, lv, quality, rng):
    """从她 `zhaoTemplates.lua` 里按武学三型挑一条真模板，品质决定等级档位。"""
    pool = _res('zhao_by_type', {}).get(_key(third)) or []
    if not pool:
        return None
    lv = max(1, int(_num(lv, 1)))
    cand = [t for t in pool if _num(t.get('grade'), 1) <= lv]
    if len(cand) < 4:
        cand = list(pool)
    cand.sort(key=lambda t: _num(t.get('grade'), 0))
    n = len(cand)
    band = {1: (0.00, 0.30), 2: (0.25, 0.60), 3: (0.55, 0.88), 4: (0.80, 1.00)}[int(quality)]
    lo = min(int(n * band[0]), n - 1)
    hi = max(lo + 1, int(round(n * band[1])))
    sub = cand[lo:min(hi, n)] or cand
    return rng.choice(sub)


def _roll_affixs(quality, rng):
    """招式特性（词缀）：条数/位置取自她自己的数据，不另造。

    * 条数：`liLianTaskZhaos.lua["招式规则"]` 里 (品质→条数) 的真实分布
      —— 品质1:0 条（14 例）/ 品质2:1~2 条 / 品质3:3、4、6 条（6 条占 9/12）/
      品质4(神通):6 条（她 `ZhaoInfoUI` 就是 6 个特性槽，`ZhaoInfoPresenter:showAffix` 写死 1..6）。
    * 数值：`liLianTaskZhaos.lua["词缀规则"]`（isRandom=1 的 55 条）
      —— 与她客户端 `LiLianMapPropSystem.lua:59-94` 取随机词缀用的是同一批。
    * 位置：前 3 条进 `atkAffixs`、后 3 条进 `defAffixs`（她 `SelfCreatedSkill:getBaseZhaos`
      与 `LiLianMapPropSystem` 都是 `if i <= 3` 这么分的）。
    """
    q = _num(quality, 1)
    if q <= 1:
        count = 0
    elif q == 2:
        count = rng.randint(1, 2)
    elif q == 3:
        count = rng.choices([3, 4, 6], weights=[2, 1, 9])[0]
    else:
        count = 6
    pool = _res('affix_random', [])
    trait = _res('trait', {})
    picked = [rng.choice(pool) for _ in range(count)] if (count and pool) else []
    atk, dfn = [], []
    for i, rule in enumerate(picked):
        eff = _key(rule.get('affixId'))
        if eff not in trait:                            # 客户端 SelfCreatedZhaoAffix 会 index，必须存在
            continue
        item = {
            'id': _num(rule.get('id'), 0),
            'needLv': _num(rule.get('needLv'), 0),
            'effectId': eff,
            'value1': _num(rule.get('effect1'), 0),
            'value2': _num(rule.get('effect2'), 0),
            'value3': _num(rule.get('effect3'), 0),
        }
        (atk if i < 3 else dfn).append(item)
    return atk, dfn


def _best_effort_zhao(third, rng=None):
    """最后兜底：从她的表里拼一条"绝对安全"的招式（所有字段都能在她表里查到键）。

    只在内部异常/资源缺失时用。返回 None 表示连兜底都做不到。
    """
    rng = rng or random.Random()
    by_type = _res('zhao_by_type', {})
    tpls = by_type.get(_key(third)) or []
    if not tpls:
        for v in by_type.values():
            tpls = v
            break
    if not tpls:
        return None
    tpl = min(tpls, key=lambda t: _num(t.get('grade'), 0))
    colors = _unlocked_colors({'colors': []}) or list(_res('color', {}).keys())
    series = _res('series_by_type', {}).get(_key(tpl.get('type')), [])
    texts = []
    for sid in series:
        texts.extend(_res('text_by_series', {}).get(sid, []))
    if not texts:
        texts = _res('all_text_ids', [])
    if not colors or not texts:
        return None
    return {
        'index': 1,
        'name': '无名招式',
        'colorId': _num(rng.choice(colors), 1),
        'dscId': _num(texts[0], 1),
        'quality': 1,
        'lv': _num(tpl.get('grade'), 1),
        'useType': 0,
        'templateId': _num(tpl.get('id'), 0),
        'atkAffixs': [],
        'defAffixs': [],
    }


def _success_rate(p, lv):
    """创作成功率：0~1 的浮点（客户端拿它跟 0.9/0.7/0.5/0.3 比文字档位）。"""
    c = p.get('creating') or {}
    n = len(c.get('zhaos') or []) if isinstance(c, dict) else 0
    rate = 0.95 - 0.045 * n + min(0.25, max(0.0, _num(lv, 1)) / 1000.0)
    return round(max(0.05, min(0.95, rate)), 4)


# ---------------------------------------------------------------------------
# 列表构造（她 UI 逐行读的 state/price）
# ---------------------------------------------------------------------------
def _color_lists(p):
    owned = set(_key(x) for x in p.get('colors') or [])
    out = []
    for cid, c in _res('color', {}).items():
        out.append({
            'id': _num(c.get('id'), _num(cid, 0)),
            'state': 1 if (_num(c.get('lock'), 1) == 0 or cid in owned) else 0,
            'price': _num(c.get('yuanbao'), 0),
        })
    out.sort(key=lambda d: _num(d.get('id'), 0))
    return out


def _affix_lists(p):
    owned = set(_key(x) for x in p.get('affixs') or [])
    out = []
    for aid, a in _res('affix_txt', {}).items():
        if not _key(aid).isdigit():
            continue
        out.append({
            'id': _num(a.get('id'), _num(aid, 0)),
            'state': 1 if (_num(a.get('lock'), 1) == 0 or aid in owned) else 0,
            'price': _num(a.get('yuanbao'), 0),
        })
    out.sort(key=lambda d: _num(d.get('id'), 0))
    return out


def _dsc_lists(p, wxtype):
    """招式描述列表：已解锁系列列全部描述；未解锁系列只列 1 条代表行（点它买整个系列）。

    每项 `{id(文本id), xiLieId(系列id), state(1可选/0待买), price(=系列yuanbao)}`
    ——`ZhaoSelectDscPresenter.lua:38-105` 逐字段读。
    """
    series = _res('dsc_series', {})
    texts = _res('text_by_series', {})
    owned = set(_key(x) for x in p.get('dscXiLie') or [])
    out = []
    for sid in _res('series_by_type', {}).get(_key(wxtype), []):
        s = series.get(sid) or {}
        unlocked = (_num(s.get('lock'), 1) == 0) or (sid in owned)
        price = _num(s.get('yuanbao'), 0)
        ids = texts.get(sid, [])
        if not unlocked:
            ids = ids[:1]                               # 未解锁：只留一条"购买此系列"的行
        for tid in ids:
            out.append({
                'id': _num(tid, 0),
                'xiLieId': _num(sid, 0),
                'state': 1 if unlocked else 0,
                'price': price,
            })
    out.sort(key=lambda d: (0 if d['state'] else 1, _num(d.get('id'), 0)))
    return out


def _wxtype_of_zhao_tpl(template_id):
    tpl = _res('zhao_tpl', {}).get(_key(template_id))
    if isinstance(tpl, dict):
        return tpl.get('type')
    return None


def _wxtype_of_creating(p):
    """拿不到 templateId 时，退回"正在创作的武学"的三型。"""
    c = p.get('creating')
    if not isinstance(c, dict):
        return None
    tpl = _res('skill_tpl', {}).get(_key(c.get('templateId')))
    if isinstance(tpl, dict):
        return tpl.get('thirdType')
    return None


# ---------------------------------------------------------------------------
# 接口
# ---------------------------------------------------------------------------
def _get_books(ctx, st, p):
    # `SelfCreatedSkillSystem:setBooksData` 逐字段读：createdBooks(数组) / creatingBook(对象)
    return ctx.ok({
        'createdBooks': p['books'],
        'creatingBook': p['creating'] or {},
    }, '★ 书架书籍（已完成 %d 本）' % len(p['books']))


def _create_zhao(ctx, st, p):
    rng = random.Random()
    third = _num(ctx.param('methods'), 0)
    lv = _num(ctx.param('lv'), 1)
    maps = _num(ctx.param('maps'), 1)

    skill_tpl = _res('skill_by_third', {}).get(_key(third))
    if not isinstance(skill_tpl, dict):
        # 兜底：退回她表里的第一条武学模板（宁可武学种类不对，也不能让她客户端拿不到 templateId）
        all_skill = list(_res('skill_tpl', {}).values())
        if not all_skill:
            return ctx.fail('没有这种武学（methods=%s）' % ctx.param('methods'),
                            '★ 自创招式失败：武学模板表为空')
        skill_tpl = all_skill[0]
        third = _num(skill_tpl.get('thirdType'), third)
        ctx.log('create_zhao: methods=%s 没有对应武学模板，退回 %s'
                % (ctx.param('methods'), skill_tpl.get('id')))

    c = p.get('creating')
    if not isinstance(c, dict):
        c = None
    if c is not None:
        # 服务端状态优先：用正在创作的这本武学的类型出招，保证招式 type 与武学一致
        tpl_now = _res('skill_tpl', {}).get(_key(c.get('templateId')))
        if isinstance(tpl_now, dict):
            third = _num(tpl_now.get('thirdType'), third)
    if c is None:
        c = {
            'id': _key(p['nextId']),
            'name': '无名武学',
            'templateId': _num(skill_tpl.get('id'), 0),
            'zhaos': [],
            'prop': 0,
            'outputType': 1,
            'unlocks': [],
        }
        p['creating'] = c
        p['nextId'] = _num(p['nextId'], 1) + 1

    def _resp(result, zhao_obj):
        # `SelfCreatedSkillSystem:createZhao` 读 `data.result` / `data.zhaoData.zhaos`
        return {
            'result': bool(result),
            'zhaoData': {
                'id': c['id'],
                'name': c.get('name') or '无名武学',
                'templateId': c['templateId'],
                'outputType': c.get('outputType') or 1,
                'prop': c.get('prop') or 0,
                'unlocks': c.get('unlocks') or [],
                'zhaos': zhao_obj,
            },
            'createdBooks': p['books'],
            'point': {'liquan': 0, 'daily_point': 0},
        }

    zhaos = c.setdefault('zhaos', [])
    if not isinstance(zhaos, list):
        zhaos = c['zhaos'] = []

    limit = _res('zhao_max', {}).get(_key(third), 49)
    if len(zhaos) >= int(_num(limit, 49)):
        _save(ctx, st)
        return ctx.fail('你的招式已经足够多了。', '★ 招式已达上限（%s）' % limit)

    # 第一招必成：她客户端拿到 result=false 时不会给 SkillCreator 建模板，
    # 接着 ZhaosLibraryUI 会读空的 creating skill（ipairs(nil)/拼接 nil）⇒ 整个 UI 卡死。
    first = (len(zhaos) == 0)
    rate = _success_rate(p, lv)
    if not first and rng.random() >= rate:
        _save(ctx, st)
        return ctx.ok(_resp(False, {}), '★ 自创招式失败（成功率 %.2f）' % rate)

    quality = _roll_quality(maps, rng)
    tpl = _pick_zhao_tpl(third, lv, quality, rng)
    if tpl is None:
        _save(ctx, st)
        return ctx.ok(_resp(False, {}), '★ 自创招式失败：没有可选招式模板')
    # 颜色 / 描述只从"已解锁"里挑（颜料与描述系列都是要花元宝解锁的）
    colors = _unlocked_colors(p) or ['1']
    series = _unlocked_series(p, tpl.get('type'))
    cand_texts = []
    for sid in series:
        cand_texts.extend(_res('text_by_series', {}).get(sid, []))
    if not cand_texts:
        cand_texts = _res('all_text_ids', [])
    atk_affixs, def_affixs = _roll_affixs(quality, rng)

    zhao = {
        'index': len(zhaos) + 1,
        'name': _random_name(rng),
        'colorId': _num(rng.choice(colors), 1),
        'dscId': _num(rng.choice(cand_texts), 0) if cand_texts else 0,
        'quality': quality,
        'lv': _num(tpl.get('grade'), 1),
        'useType': 1 if (tpl.get('activeId') and rng.random() < 0.2) else 0,
        'templateId': _num(tpl.get('id'), 0),
        'atkAffixs': atk_affixs,
        'defAffixs': def_affixs,
    }
    if not zhao['dscId']:                               # 兜底：她表里 id 形如 "1"
        try:
            zhao['dscId'] = int(_res('all_text_ids', ['1'])[0])
        except (TypeError, ValueError):
            zhao['dscId'] = 1
    zhaos.append(zhao)
    _save(ctx, st)
    ctx.log('自创武学：%s 第 %d 招「%s」（模板 %s / 品质 %d / 颜色 %s / 词缀 %d+%d）'
            % (c.get('templateId'), zhao['index'], zhao['name'], zhao['templateId'],
               quality, zhao['colorId'], len(atk_affixs), len(def_affixs)))
    return ctx.ok(_resp(True, zhao), '★ 自创招式「%s」（第%d招）' % (zhao['name'], zhao['index']))



def improve_zhao_public(ctx, prop_id, skill_id, zhao_index):
    """★ 2026-10-17 v36c：改良书「真变换」公共入口（inherit_skin._use_improve_prop 调）。

    按 propMap.functionType 对**正在创作的书**的指定招式做真变换，返回 (new_zhao, err)：
      ft=2 品质提升（精研 普→精妙 / 超群 普→超凡 / 跃兴 精妙→超凡，按 createToQ*Weights）
      ft=3 复思（同品质整体重构：新模板/新名字/新颜色描述/重掷词缀）
      ft=4 弃定(精妙)/重思(超凡) 词缀重置（品质不变）
    品质不符按她 inconformityText 拒绝（返回 (None, 文案)，调用方**不要扣道具**）。
    成功时书/招式已写回本模块 state（zhaos 条目与 _create_zhao 产出同形）。
    """
    _s = lambda v: (str(v).strip() if v is not None else '')  # 本模块没有 _s 助手
    # ★ prop_map 不在本模块 _RES 缓存（那是 inherit_skin 的）——直接读表。
    _pm = _load_table('propMap.lua', 'Sheet1') or {}
    rec = _pm.get(_key(prop_id))
    if not isinstance(rec, dict):
        return None, '道具不存在'
    ft = _num(rec.get('functionType'), 0)
    if ft not in (2, 3, 4):
        return None, '创作卷轴请在创招时使用'

    st = _load(ctx)
    p = _me(ctx, st)
    book = _find_book(p, skill_id) if _s(skill_id) else None
    if book is None:
        c = p.get('creating')
        book = c if isinstance(c, dict) else None
    if book is None:
        return None, '没有正在创作的武学'
    zhao = _find_zhao(book, zhao_index)
    if not isinstance(zhao, dict):
        return None, '招式不存在'
    q = _num(zhao.get('quality'), 1)
    need = _num(rec.get('needZhaoQuality'), 0)
    if ft in (2, 4) and need and q != need:
        return None, _s(rec.get('inconformityText')) or '招式品质不符合使用条件'

    rng = random.Random()
    # 招式所属武学三型（换模板要用）：书 templateId → 武学模板 → thirdType
    third = 0
    tpl_now = _res('skill_tpl', {}).get(_key(book.get('templateId')))
    if isinstance(tpl_now, dict):
        third = _num(tpl_now.get('thirdType'), 0)
    lv = _num(zhao.get('lv'), 1)

    def _new_affixs(nq):
        a, d = _roll_affixs(nq, rng)
        return a, d

    if ft == 2:
        # 品质提升：按 createToQ2/Q3/Q4Weights 掷目标品质（她表里是 100/0/0 的确定性配置）
        cands, ws = [], []
        for tgt, wk in ((2, rec.get('createToQ2Weights')), (3, rec.get('createToQ3Weights')),
                        (4, rec.get('createToQ4Weights'))):
            w = _num(wk, 0)
            if w > 0 and tgt > q:
                cands.append(tgt)
                ws.append(w)
        if not cands:
            return None, '这一招的品质已经到顶，无需再提升'
        newq = rng.choices(cands, weights=ws)[0]
        new = dict(zhao)
        new['quality'] = newq
        nt = _pick_zhao_tpl(third, lv, newq, rng)
        if isinstance(nt, dict):
            new['templateId'] = _num(nt.get('id'), _num(zhao.get('templateId'), 0))
            new['lv'] = _num(nt.get('grade'), lv)
        new['atkAffixs'], new['defAffixs'] = _new_affixs(newq)
    elif ft == 3:
        # 复思：同品质整体重构（新模板/新名字/新颜色/新描述/重掷词缀）
        newq = q
        new = dict(zhao)
        nt = _pick_zhao_tpl(third, lv, newq, rng)
        if isinstance(nt, dict):
            new['templateId'] = _num(nt.get('id'), _num(zhao.get('templateId'), 0))
            new['lv'] = _num(nt.get('grade'), lv)
        new['name'] = _random_name(rng)
        colors = _unlocked_colors(p) or ['1']
        new['colorId'] = _num(rng.choice(colors), 1)
        series = _unlocked_series(p, None)
        cand_texts = []
        for sid in series:
            cand_texts.extend(_res('text_by_series', {}).get(sid, []))
        if not cand_texts:
            cand_texts = _res('all_text_ids', ['1'])
        new['dscId'] = _num(rng.choice(cand_texts), _num(zhao.get('dscId'), 1)) if cand_texts else _num(zhao.get('dscId'), 1)
        new['useType'] = zhao.get('useType', 0)
        new['atkAffixs'], new['defAffixs'] = _new_affixs(newq)
    else:
        # 词缀重置（弃定=精妙 / 重思=超凡）：品质/模板/名字不变，只重掷词缀
        new = dict(zhao)
        new['atkAffixs'], new['defAffixs'] = _new_affixs(q)

    # 写回（creating 与 books 里的同一本书都指向同一份 dict，改 zhaos 即可）
    zhaos = book.setdefault('zhaos', [])
    idx = _num(zhao.get('index'), _num(zhao_index, 0))
    replaced = False
    for i, zz in enumerate(zhaos):
        if _num(zz.get('index'), i + 1) == idx:
            new['index'] = zz.get('index', idx)
            zhaos[i] = new
            replaced = True
            break
    if not replaced:
        return None, '招式不存在'
    _save(ctx, st)
    try:
        ctx.log('自创改良：%s「%s」第%s招 → 品质 %s（书 %s）'
                % (_s(rec.get('name')), zhao.get('name'), idx, new.get('quality'), book.get('id')))
    except Exception:                                   # noqa: BLE001
        pass
    return new, None

def _complete_book(ctx, st, p):
    name = str(ctx.param('skillName') or '').strip()
    c = p.get('creating')
    if not isinstance(c, dict) or not c.get('zhaos'):
        return ctx.fail('尚未开始自创武学', '★ 完成创作失败：没有正在创作的武学')
    need = int(_num(_res('complete_all_num', 6), 6))
    if len(c['zhaos']) < need:
        return ctx.fail('招式数量不足，至少需要%d式' % need, '★ 完成创作失败：招式不足')
    if not name:
        return ctx.fail('武学名称不能为空', '★ 完成创作失败：名称为空')
    for b in p['books']:
        if _key(b.get('name')) == name:
            # errcode=6 在她客户端就是"重名"
            return ctx.fail('该武学名称已存在', '★ 完成创作失败：重名', errcode=6)
    if len(p['books']) >= 10:                           # SelfCreatedSkillConstants.SelfCreatedSkillCountMax
        return ctx.fail('你的书架已经满了', '★ 完成创作失败：书架已满')

    zhaos = c['zhaos']
    book = {
        'id': _key(c.get('id')),
        'templateId': _num(c.get('templateId'), 0),
        'name': name,
        'colorId': _num((zhaos[0] or {}).get('colorId'), 1),
        'outputType': 1,
        'prop': 0,
        'unlocks': [],
        'zhaos': zhaos,
    }
    p['books'].append(book)
    p['creating'] = None
    _save(ctx, st)
    ctx.log('自创武学完成：《%s》 id=%s，共 %d 招' % (name, book['id'], len(zhaos)))
    # 她 `SelfCreatedSkillSystem:completeSkillCreate` 用的是 `data.createdBooks[1]`，
    # 只回这一本（否则客户端 addSelfCreatedBook 会与本地列表重复）
    return ctx.ok({'createdBooks': [book]}, '★ 完成自创武学《%s》' % name)


def _learn_book(ctx, st, p):
    sid = _key(ctx.param('skillId'))
    book = _find_book(p, sid)
    if book is None:
        # 也允许用 "userid_selfCreatedSkill_x" 形式
        book = _find_book(p, _key(sid).split('_')[-1])
    if book is None:
        return ctx.fail('书籍不存在', '★ 学习失败：书籍不存在')
    if _key(book.get('id')) not in p['learned']:
        p['learned'].append(_key(book.get('id')))
    _save(ctx, st)
    # `SelfCreatedSkillModel:learnSkillBook` 直接取 `data.createdBooks[1]`
    return ctx.ok({'createdBooks': [book]}, '★ 学习自创武学《%s》' % book.get('name'))


def _delete_book(ctx, st, p):
    sid = _key(ctx.param('skillId'))
    book = _find_book(p, sid)
    if book is None:
        # errcode=2 ⇒ 她客户端提示"需要丢弃的书籍未找到。"
        return ctx.fail('需要丢弃的书籍未找到', '★ 丢弃失败：书不存在', errcode=2)
    if not book.get('zhaos'):
        # errcode=1 ⇒ "该书籍未创建完成，无法丢弃。"
        return ctx.fail('该书籍未创建完成，无法丢弃', '★ 丢弃失败：书未完成', errcode=1)
    p['books'] = [b for b in p['books'] if _key(b.get('id')) != _key(book.get('id'))]
    _save(ctx, st)
    ctx.log('丢弃自创武学：《%s》 id=%s' % (book.get('name'), book.get('id')))
    return ctx.ok({'skillId': _key(book.get('id'))}, '★ 丢弃自创武学《%s》' % book.get('name'))


def _set_zhao_attr(ctx, st, p):
    sid = _key(ctx.param('skillId'))
    idx = _num(ctx.param('zhaoIndex'), 0)
    book = None
    c = p.get('creating')
    if isinstance(c, dict) and _key(c.get('id')) == sid:
        book = c
    if book is None:
        book = _find_book(p, sid)
    if book is None:
        return ctx.fail('武学不存在', '★ 设置招式属性失败：武学不存在')
    zhao = _find_zhao(book, idx)
    if zhao is None:
        return ctx.fail('招式不存在', '★ 设置招式属性失败：招式不存在')

    name = ctx.param('name')
    if isinstance(name, str) and name.strip():
        zhao['name'] = name.strip()
    color_id = _num(ctx.param('colorId'), 0)
    if color_id and _key(color_id) in [x for x in _res('color', {})]:
        if _key(color_id) in _unlocked_colors(p):
            zhao['colorId'] = _num(_res('color', {})[_key(color_id)].get('id'), color_id)
        else:
            ctx.log('设置招式颜色被拒（%s 未解锁）' % color_id)
    dsc_id = _num(ctx.param('dscId'), 0)
    if dsc_id:
        txt = _res('dsc_txt', {}).get(_key(dsc_id))
        if isinstance(txt, dict):
            wt = _wxtype_of_zhao_tpl(zhao.get('templateId')) or _wxtype_of_creating(p)
            if _key(txt.get('seriesId')) in _unlocked_series(p, wt):
                zhao['dscId'] = dsc_id
            else:
                ctx.log('设置招式描述被拒（系列 %s 未解锁）' % txt.get('seriesId'))
    _save(ctx, st)
    return ctx.ok({
        'result': True,
        'skillId': book.get('id'),
        'zhaoIndex': _num(zhao.get('index'), idx),
        'name': zhao.get('name') or '',
        'colorId': _num(zhao.get('colorId'), 0),
        'dscId': _num(zhao.get('dscId'), 0),
    }, '★ 设置招式属性：第%s式「%s」' % (idx, zhao.get('name')))


def _get_success_rate(ctx, st, p):
    # `getZhaoSuccessRate` → 回调读 `data.successRate`（数字）
    rate = _success_rate(p, _num(ctx.param('lv'), 1))
    return ctx.ok({'successRate': rate}, '★ 创作成功率 %.2f' % rate)


def _get_zhao_colors(ctx, st, p):
    return ctx.ok({'lists': _color_lists(p)}, '★ 招式颜色列表')


def _unlock_zhao_color(ctx, st, p):
    cid = _key(ctx.param('colorId'))
    rec = _res('color', {}).get(cid)
    if not isinstance(rec, dict):
        return ctx.fail('颜料不存在', '★ 解锁颜色失败：颜料不存在')
    if cid not in p['colors']:
        p['colors'].append(cid)
    _save(ctx, st)
    ctx.log('解锁招式颜色：%s %s' % (cid, rec.get('name')))
    return ctx.ok({'lists': _color_lists(p)}, '★ 解锁颜色《%s》' % rec.get('name'))


def _get_skill_name_affixs(ctx, st, p):
    return ctx.ok({'lists': _affix_lists(p)}, '★ 武学名后缀列表')


def _unlock_skill_name_affixs(ctx, st, p):
    aid = _key(ctx.param('affixsId'))
    rec = _res('affix_txt', {}).get(aid)
    if not isinstance(rec, dict):
        return ctx.fail('后缀不存在', '★ 解锁后缀失败：后缀不存在')
    if aid not in p['affixs']:
        p['affixs'].append(aid)
    _save(ctx, st)
    return ctx.ok({'lists': _affix_lists(p)}, '★ 解锁武学名后缀《%s》' % rec.get('name'))


def _get_zhao_dscs(ctx, st, p):
    wxtype = _wxtype_of_zhao_tpl(ctx.param('templateId'))
    if wxtype is None:
        wxtype = _wxtype_of_creating(p)
    return ctx.ok({'lists': _dsc_lists(p, wxtype)}, '★ 招式描述列表')


def _unlock_zhao_dsc(ctx, st, p):
    sid = _key(ctx.param('xiLieId'))
    rec = _res('dsc_series', {}).get(sid)
    if not isinstance(rec, dict):
        return ctx.fail('描述系列不存在', '★ 解锁描述失败：系列不存在')
    if sid not in p['dscXiLie']:
        p['dscXiLie'].append(sid)
    _save(ctx, st)
    ctx.log('解锁招式描述系列：%s %s' % (sid, rec.get('name')))
    wxtype = _wxtype_of_zhao_tpl(ctx.param('templateId'))
    if wxtype is None:
        wxtype = rec.get('wxtype')
    return ctx.ok({'lists': _dsc_lists(p, wxtype)}, '★ 解锁描述系列《%s》' % rec.get('name'))


_HANDLERS = {
    'get_books': _get_books,
    'create_zhao': _create_zhao,
    'learn_book': _learn_book,
    'delete_book': _delete_book,
    'complete_book': _complete_book,
    'get_skillName_affixs': _get_skill_name_affixs,
    'unlock_skillName_affixs': _unlock_skill_name_affixs,
    'get_successRate': _get_success_rate,
    'get_zhaoColors': _get_zhao_colors,
    'unlock_zhaoColor': _unlock_zhao_color,
    'get_zhaoDscs': _get_zhao_dscs,
    'unlock_zhaoDsc_xiLie': _unlock_zhao_dsc,
    'set_zhao_attr': _set_zhao_attr,
}


def handle(ctx):
    ep = ctx.endpoint
    fn = _HANDLERS.get(ep)
    if fn is None:
        return None                                     # 不是我的接口
    try:
        st = _load(ctx)
        p = _me(ctx, st)
        return fn(ctx, st, p)
    except Exception as e:                              # noqa: BLE001
        ctx.log('[self_created_skill] %s 异常：%s\n%s' % (ep, e, traceback.format_exc()))
        # 读接口给"空但类型正确"的兜底，避免她回调里 index/拼接 nil 直接卡死 UI
        if ep == 'get_books':
            return ctx.ok({'createdBooks': [], 'creatingBook': {}},
                          '★ 书架兜底（内部异常）')
        if ep in ('get_zhaoColors', 'get_skillName_affixs', 'get_zhaoDscs',
                  'unlock_zhaoColor', 'unlock_skillName_affixs', 'unlock_zhaoDsc_xiLie'):
            return ctx.ok({'lists': []}, '★ 列表兜底（内部异常）')
        if ep == 'get_successRate':
            return ctx.ok({'successRate': 0.5}, '★ 成功率兜底（内部异常）')
        if ep == 'create_zhao':
            return _create_zhao_fallback(ctx)
        if ep == 'complete_book':
            return ctx.ok({'createdBooks': []}, '★ 完成创作兜底（内部异常）')
        if ep == 'learn_book':
            return ctx.ok({'createdBooks': []}, '★ 学习兜底（内部异常）')
        if ep == 'delete_book':
            return ctx.ok({'skillId': ''}, '★ 丢弃兜底（内部异常）')
        return ctx.fail('服务器内部错误：%s' % e, '★ set_zhao_attr 异常')


def _create_zhao_fallback(ctx):
    """create_zhao 内部异常时的兜底应答。

    她客户端拿到 `result=false` 时**不会**给 `SkillCreator` 建模板，接着
    `ZhaosLibraryPresenter:showLayer` 会 `ipairs(nil)`/拼接 nil ⇒ 整个 UI 卡死。
    所以兜底也尽量回一条"各字段都能在她表里查到键"的合法招式，并落盘。
    """
    z = _best_effort_zhao(ctx.param('methods'))
    if z is None:
        return ctx.ok({
            'result': False,
            'zhaoData': {'zhaos': {}},
            'createdBooks': [],
            'point': {'liquan': 0, 'daily_point': 0},
        }, '★ 自创招式兜底（内部异常）')
    ztpl = _res('zhao_tpl', {}).get(_key(z.get('templateId'))) or {}
    stpl = _res('skill_by_third', {}).get(_key(ztpl.get('type')))
    all_skill = list(_res('skill_tpl', {}).values())
    tpl_id = _num((stpl or (all_skill[0] if all_skill else {})).get('id'), 0)
    book_id = '0'
    try:
        st = _load(ctx)
        p = _me(ctx, st)
        c = p.get('creating')
        if not isinstance(c, dict):
            c = {'id': _key(p['nextId']), 'name': '无名武学', 'templateId': tpl_id,
                 'zhaos': [], 'prop': 0, 'outputType': 1, 'unlocks': []}
            p['creating'] = c
            p['nextId'] = _num(p['nextId'], 1) + 1
        zhaos = c.setdefault('zhaos', [])
        z['index'] = len(zhaos) + 1
        zhaos.append(z)
        book_id = c['id']
        _save(ctx, st)
    except Exception:                                   # noqa: BLE001
        pass
    return ctx.ok({
        'result': True,
        'zhaoData': {'id': book_id, 'name': '无名武学', 'templateId': tpl_id,
                     'outputType': 1, 'prop': 0, 'unlocks': [], 'zhaos': z},
        'createdBooks': [],
        'point': {'liquan': 0, 'daily_point': 0},
    }, '★ 自创招式兜底（内部异常，已回一条安全招式）')
