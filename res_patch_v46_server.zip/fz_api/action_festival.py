# -*- coding: utf-8 -*-
# ================= 离线包路径根（fz_make_offline_bundle.py 自动注入） =================
# 手机上整个服务端就是一个目录，表在哪、状态写哪，全部相对包根算。
# （有的模块原来把绝对路径写死，本身没 import os —— 这里一并补上）
import os
import os as _osp


def _off_find_bundle(_f):
    """从模块所在目录往上找包根（认 fz_boot_server.py）。
    ★ fz_api/*.py 的 __file__ 在 <根>/fz_api/ 下，直接 dirname 会算错一层。"""
    _d = _osp.path.dirname(_osp.path.abspath(_f))
    for _ in range(6):
        if _osp.path.exists(_osp.path.join(_d, 'fz_boot_server.py')):
            return _d
        _u = _osp.path.dirname(_d)
        if _u == _d:
            break
        _d = _u
    return _osp.path.dirname(_osp.path.abspath(_f))


_OFF_BUNDLE = _off_find_bundle(__file__)
_OFF_FZ_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_fz')
_OFF_INK_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_ink')
_OFF_WORK_ROOT = _OFF_BUNDLE
# =====================================================================================
# ★ 2026-10-04 商城空货架修复：客户端资源表解析——PC 开发树优先，设备上自动回退
#   到包内 client_fz 副本（jhserver/client_fz = fangzhi_lua_dec 的同步拷贝）。
def _fz_res(*parts):
    base = os.path.join(_OFF_FZ_ROOT, 'res', 'script')
    if not os.path.isdir(base):
        base = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            '..', 'client_fz', 'res', 'script')
    return os.path.join(base, *parts)

# -*- coding: utf-8 -*-
"""活动·节日/签到/抽奖/理财/回归 等 81 个接口的 1:1 还原。

契约**逐个读自她客户端**（不是猜的），出处逐条写在下面每个 handler 的注释里：

  * `app/models/Action/BaiDuanGe.lua`            —— get_login_reward_list / get_login_reward
        （:20-40 注释块就是服务端应答的字段表：tag_name / unlock_type / state /
          lock_desc / product_key / daily_reward:[{rid,reward:[{id,num}],state}]）
  * `app/views/layer/ActionLayer/SpringFestival_2021/FundActivityLayer.lua`
        —— 同一个 URL 的另一个消费方（name / desc(分号分隔) / state / rid /
          reward:[{type,id,number,name}]，type 用 Reward_type 1~4）
  * `app/views/layer/ActionLayer/LoginRewardLayer.lua` —— get_login_yuandan_info
        （name / dsc / activity_time / relist:[{times,dsc,state,rewards:[{type,key,value}]}]，
          REWARD_STATE 1未开始 2未领取 3补领 5已领取；REWARD_TYPE 1网属性 2属性 3物品）
  * `app/views/layer/ActionLayer/ChongZhiChouJiangLayer.lua` —— get_lottery_list / do_lottery
        （lottery_times / lottery_limit / lottery_valid_times / order_id / list /
          lottery_items / removeYb / costYb）
  * `app/views/layer/ActionLayer/LaBaChongZhiChouJiangLayer.lua` —— get_yuanbao_lottery_list / do_yuanbao_lottery
  * `app/models/Action/JiangHuYiRenLuAction.lua`  —— do_mingren_lottery / bfmingtie_exchange_spcl
        （prize:[{sendFrom,itemId,number}] / yuanbao / baifangmingtie / removebfmt / addspcl）
  * `app/views/layer/ActionLayer/RandomGiftLayer.lua` —— get_diy_goods / get_diy_infos / buy_diy_goods
        （list:[{name,number,itemId}]×6 / diygift_times / refresh_times / refresh_yuanbao /
          discount / discountYb / totalYb）
  * `app/views/layer/ActionLayer/JiangHuHaoYunLaiLayer.lua` + `HaoYunDuiHuanLayer.lua`
        —— get_lucky_goods / buy_lucky_goods / exchange_lucky_point
        （luck_list / luck_goods:{name,need,icon,itemId,id} / yuanbao / total_point /
          exchangeNum / exchangeNumLimit / get_point / upper(bool)）
  * `app/models/Action/JiangHuMiBao.lua`          —— get_spend_reward_list / get_spend_reward / buy_spend_reward
        （libaoName / count / rid / reward / state / price / productKey / pay_type / limit_type）
  * `app/models/Action/DieJinChongZhi.lua`        —— get_total_spend_detail / get_total_spend_award
        （day / spend_number / standard_number / award_list:{award_type,total_day,award_string,
          status,award_box} / award_box / msg）
  * `app/models/Action/YiZhiQianJin.lua` + `app/views/layer/ActionLayer/ConsumeWingLayer.lua`
        —— get_yuanbao_plan_gift_list / receive_yuanbao_plan_gift
        （act_name / detail_desc / spend_yuanbao / list / config.base / shopping_money）
  * `app/models/Action/YuanBaoConsumeAction.lua`  —— get_yuanbao_consumption_info / _reward
        （act_name / detail_desc / spend_number / list:[{rid,target,state,rewards}] / rewards / msg）
  * `app/models/Action/JuBaoPen.lua`              —— get_zhaocaijinbao_info / _reward
        （act_name / detail_desc / shopping_money / list:[{id,status,needMoney,idType,rewards}] /
          rewards:{rid:[{itemId,number,name,type}]} / reward / yashi_expired_time）
  * `app/models/Action/WakeUpAction.lua`          —— get_waking_dream_info / _reward /
        unlock_waking_dream_pay_reward（detail_time / max_floor /
          goods:{jackpotId,pay_number,product_key,currency_name,pay_type,pay_state}）
  * `app/models/Action/PracticeOfSkill.lua`       —— get_practice_skill_reward_list / _reward /
        unlock_practice_skill_reward（unlock_info:{jackpotId,payText,productKey,payType,payState}）
  * `app/models/Action/LimitedTimeExperience.lua` —— add_training_task_point / refresh_training_task_list /
        get_training_task_reward（task_list:[{id,state,name,desc,score}] / completion_times）
  * `app/models/Action/KungFuTrails.lua`          —— get_wumen_trial_info / _reward
        （list:[{taskId,taskText,taskTypeId,taskReward,rewardText,taskState,taskTypeName}]）
  * `app/models/Action/SmithyAction.lua`          —— get_smithy_info / _reward（quench_count）
  * `app/models/Action/AnniversaryLoginReward.lua`—— get_anniversary_login_list / _reward
        （start_time / yuanbao_data:{num,state,rid} / list:[{state,rid,day,rewards:[{name,num}]}]）
  * `app/views/layer/ActionLayer/ZhouNianQingChongZhiLayer.lua` —— get_anniversary_reward_list / _reward
        （list:[{date,is_received(0/1/2),reward:[{itemId,number,name}]}]；响应是 {[date]=0/1}）
  * `app/models/Action/FisrtCharge.lua`           —— get_spring_new_reward / receive_spring_new_reward
        （name / detail_desc / hasup / base:[{day,desc,status,imagePath,reward:[{itemId,num,name,type}]}]）
  * `app/models/Action/QiXiFestival.lua` + `QiXiFestival_2019/QiXiLoveLetterLayer.lua` +
    `QiXiFestival_2019/QiXiRankLayer.lua`         —— get_qixi_task_info / take_qixi_task /
        finish_qixi_task / get_qixi_board / get_qixi_reward
        （day_times / day_limit / finish_days / full_days / state / times /
          currency:{attr:{value,count,desc}}；榜单 data 是**数组**，元素 {type,body:{list,jiangli,my_score,is_get}}）
  * `app/views/layer/ActionLayer/FlyKiteLayer.lua` / `PlayDragonBoatLayer.lua` /
    `FlyKiteRankListLayer.lua` / `BoatPersonalRankingLayer.lua`
        —— get_all_type_point / personal_boat_msg / get_boat_board / get_boat_reward /
          get_duanwu_reward_notice
        （today_point / total_point / rank / personal_rank；body.list[{sort,grade,userid,portrait,
          title_type,title_id,name,score,menpai,yueka,head}]；body.is_get "Y"/"N"；
          body.jiangli:{daoju,shuxing}；daoju/shuxing/currency；content / jiangli / is_get）
  * `app/models/Action/NianBeast.lua`             —— expel_nian / get_expel_reward
  * `app/models/Action/NewRandomGift.lua`         —— get_luck_box_good / buy_luck_box_good
  * `app/views/layer/ActionLayer/ActivityCalendarLayer.lua` + `app/models/Action/ActivityCalendarUtils.lua`
        —— get_activity_calendar（list:[{name,start_time,end_time,gift,status}] / point）
  * `app/views/layer/ActionLayer/SuiMoJiFuLayer.lua` —— get_newdaily_lists / get_newdaily_award
        （config.base.goods_1..goods_8 / times:{"n":{istrd:0不可领/1可领/2已领}}）
  * `app/views/layer/ActionLayer/XianShiPointLayer.lua` —— get_xianshilibao_gift_list_2
        （total / list[1..4]:{item_id,points}）
  * `app/views/layer/ActionLayer/NewXianShiLayer.lua` —— get_limit_package/<itemId>
        （price / limit_num / beyond / end_time / list:[{itemId,number}] / buy_times /
          special_reward_itemId）
  * `app/views/layer/ActionLayer/AnniversaryCelebrationConversionLayer.lua` + `LiQuanLayer`
        —— get_shop_info（shop_info.goods{分类:{idx:{itemId,dsc,name,itype,price,number,gid,
          is_again,inde,times}}} / shop_info.typeName / total_points）
  * `app/views/layer/ActionLayer/ChongZhiJiaSongLayer.lua` —— get_yueka_times / give_yueka_days
        （num / ctime：ctime 是**活动结束时间戳**，`GetTime() < endtime` 时才不许领）
  * `app/views/layer/ActionLayer/PhysicalLotteryLayer.lua` / `EntityLotteryLayer.lua`
        —— get_user_upload_info（count / info==false 表示没填过）/ save_user_info
  * `app/views/layer/ActionLayer/ZhangDanLayer.lua` —— get_share_link（url）/ do_share（items）
  * `app/models/Action/WuJueChallenge.lua`        —— get_egg_challenge_info / add_egg_challenge_times
        （endTime / npcChallengeAllCountList / number / currency_num）
  * `app/models/Action/QuestionAndAnswer.lua`     —— get_answer_status（status/pass_num）/ set_answer_status（num）
  * `app/views/layer/ActionLayer/ActionLayer.lua` —— get_game_activity（is_open/status/name/
        detail_desc/activity_id/start/end）
  * `app/models/Store/GrantGoodRequest.lua` + `app/models/Action/ActionRewardsHelper.lua`
        —— `data.reward` / `data.rewards` 的条目就是 `{id=商品表键, num=数量}`
        （`GoodsHelper:getGoodsResClass(v.id)` 查 `res/script/store/shoplist.lua["Sheet1"][id]`）

内容来源（全部取自**她自己的资源表**，`work/fz_luatable.py` 解析 `assets/res/script/**`）：
  * 奖励/商品：`activity/shoplist.lua` 的 `Sheet1`（2041 条，键 "100001" 这种；
    面板要的 `id` 必须是这个**表键**，`itemId` 用于客户端 `Item:getOneItemByKey`）
  * 好运通宝兑换：`others/goodluck.lua` `Sheet1`（20 条：coin/itemid/limit/name/num）
  * 龙舟/端午：`others/dragonBoat.lua` `船只信息`(7) + `门派信息`(27)
  * 限时历练任务：`others/limitedTimeExperience.lua` `Sheet1`（34 条真任务）
  * 周活动日历：`others/weekactivity.lua` `activity`(10) + `launch`(15)；
    周活动中文名取 `roleTitle/specialChenHao.lua` 里 `basicTitleId` 40014~40028 的 `text`
    （与 `ActivityCalendarUtils:getSpecialTitle` 的映射一致）
  * 月卡加送：`activity/monthlycardysgift.lua` `Sheet1`（633 条 giftId/goodsId/moneyNumber）
  * 周年：`others/anniversary.lua` `progress`/`room`；
    七夕：`others/xiqi.lua`；新春：`others/ChineseNewYear.lua`
  * 角色整档（get_user_info）：`work/roles/full.json`（27KB 真档）

★ 三条铁律（踩过的坑，和 activities.py 一致）：
  1. 数值字段一个都不能少 —— 少一个就是 `attempt to compare nil`，
     被她的 xpcall 吞掉 ⇒ **客户端整体卡死**（不是弹窗）。
  2. 该是数组的不能给 map（`detail_desc` / `rewards` / `list` / `prize` / `config.base.goods_n`），
     该是对象的不能给字符串（`shop_info` / `yuanbao_data` / `goods` / `unlock_info`）。
  3. 时间戳一律给**未来**的 unix 秒（`ctime` / `end_time` / `endTime`），给 0 会被判"活动已结束"。

状态文件：`work/action_festival_state.json`（与 `fz_api/activities.py` 的 `activities_state.json` 分开）。

已知没做到 1:1 的地方（诚实列出）：
  * **奖励的"哪一天给哪件东西"是服务端表，客户端资源里没有**：面板结构、字段名、类型
    全部按客户端契约 1:1；奖励条目本身取自她自己的 `activity/shoplist.lua` 货架
    （`id`/`itemId`/`name`/`icon`/`itype` 全真，`GoodsHelper:getGoodsResClass(id)` 一定查得到），
    但"第 3 天给哪一件"这类**编排**是这里定的，不是原版的服务端配置。
  * `get_limit_package` / `get_diy_goods` / `get_voucher_prize_2` / `get_shop_info` 的
    **服务端配置表**（礼包价/额度/商店分类与积分价）同上，客户端资源里不存在。
  * `get_share_link` 的 url 指向本机服务端（原版是她自己的分享站），
    客户端只把它塞进 `FengXiangLayer:setUrl` / `WeiXin_setAboutLink`。
  * `get_activity_calendar`：`others/weekactivity.lua` 只给了活动 id 与时间，
    中文名取 `roleTitle/specialChenHao.lua` 里 basicTitleId 40014~40028 的 `text`；
    `weekgszx` / `weekmjtx` / `weekwjhl` 这三个 id 在称号表里没有对应项，直接显示 id。
  * `check_pay_sign` 只做票据校验并回 `errcode=0`（真正的 iOS 内购在 SDK 侧，服务端不可复刻）。
"""
import os
import re
import time

NAME = 'action_festival'
TITLE = '活动·节日/签到/抽奖/理财/回归/分享/月卡'
ENDPOINTS = [
    # —— 签到 / 累计登录 / 元旦 / 新春首充
    'get_login_reward_list', 'get_login_reward', 'get_login_yuandan_info',
    'set_login_yuandan_reward', 'get_spring_new_reward', 'receive_spring_new_reward',
    # —— 抽奖
    'get_lottery_list', 'do_lottery', 'get_yuanbao_lottery_list', 'do_yuanbao_lottery',
    'do_mingren_lottery', 'bfmingtie_exchange_spcl',
    'get_diy_goods', 'get_diy_infos', 'buy_diy_goods',
    'get_luck_box_good', 'buy_luck_box_good', 'get_voucher_prize_2',
    # —— 消费返利 / 理财
    'get_spend_reward_list', 'get_spend_reward', 'buy_spend_reward',
    'get_total_spend_detail', 'get_total_spend_award',
    'get_yuanbao_plan_gift_list', 'receive_yuanbao_plan_gift',
    'get_yuanbao_consumption_info', 'get_yuanbao_consumption_reward',
    'get_zhaocaijinbao_info', 'get_zhaocaijinbao_reward',
    'get_waking_dream_info', 'get_waking_dream_reward', 'unlock_waking_dream_pay_reward',
    'get_practice_skill_reward_list', 'get_practice_skill_reward',
    'unlock_practice_skill_reward',
    'add_training_task_point', 'refresh_training_task_list', 'get_training_task_reward',
    'get_wumen_trial_info', 'get_wumen_trial_reward',
    'get_smithy_info', 'get_smithy_reward',
    # —— 幸运商品（江湖好运来）
    'get_lucky_goods', 'buy_lucky_goods', 'exchange_lucky_point',
    # —— 节日：周年 / 七夕 / 端午 / 年兽 / 五绝彩蛋
    'get_anniversary_login_list', 'get_anniversary_login_reward',
    'get_anniversary_reward_list', 'get_anniversary_reward',
    'get_qixi_task_info', 'take_qixi_task', 'finish_qixi_task',
    'get_qixi_board', 'get_qixi_reward',
    'get_all_type_point', 'personal_boat_msg', 'get_boat_board', 'get_boat_reward',
    'get_duanwu_reward_notice',
    'expel_nian', 'get_expel_reward',
    'get_egg_challenge_info', 'add_egg_challenge_times',
    # —— 活动日历 / 礼包 / 日常 / 分享 / 月卡 / 资料 / 商城 / 答题 / 支付
    'get_activity_calendar', 'get_game_activity', 'get_limit_package',
    'get_xianshilibao_gift_list_2', 'get_newdaily_lists', 'get_newdaily_award',
    'get_share_link', 'do_share', 'get_yueka_times', 'give_yueka_days',
    'get_user_info', 'save_user_info', 'get_user_upload_info',
    'get_shop_info', 'get_answer_status', 'set_answer_status',
    'check_pay_sign', 'exchange_award_to_sachet_new',
]

STATE = 'action_festival_state.json'
RES_ROOT = _fz_res()
HERE = os.path.dirname(os.path.abspath(__file__))

FAR_FUTURE = int(time.time()) + 400 * 86400
COLOR = re.compile(r'(HIG|HIY|HIB|HIM|HIR|HIC|HIW|CYN|YEL|BLU|GRN|NOR|RED|WHT|DWT|GLD|MAG)')

# 她 `app/models/role/Role.lua` getCHAttrName 里的真属性键（只挑这几个最稳的做属性奖）
ATTRS = ['pot', 'exp', 'yuanbao', 'prestige', 'jiaozi']

# 周活动 → 称号（`app/models/Action/ActivityCalendarUtils.lua:179-222` 的 id 映射）
# 名字取 `roleTitle/specialChenHao.lua` 里 basicTitleId 40014~40028 的 text
WEEK_TITLE = {
    'weekdmxb': 40014, 'weekwjhw': 40015, 'weekslcd': 40016, 'weekhztc': 40017,
    'weekbgsq': 40018, 'weekxqdm': 40019, 'weekxzzy': 40020, 'weekwjss': 40021,
    'zhouhuodongtx1': 40022, 'zhouhuodongtx2': 40023, 'zhouhuodongtx3': 40024,
    'zhouhuodongtx4': 40025, 'zhouhuodongtx5': 40026,
}

_NOTES = (
    'get_limit_package / get_diy_goods / get_voucher_prize_2 / get_shop_info 的服务端配置表'
    '不在客户端资源里；这里用 activity/shoplist.lua 的真商品（id/itemId/name/icon 全真）'
    '按客户端契约拼结构。get_share_link 的 url 指向本机服务端。'
)


# ---------------------------------------------------------------------------
# 小工具
# ---------------------------------------------------------------------------


def _int(v, d=0):
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return d


def _strip(s):
    return COLOR.sub('', s or '')


def _now():
    return int(time.time())


def _day():
    return int(time.strftime('%Y%m%d'))


def _today_str():
    return time.strftime('%Y-%m-%d 00:00:00')


def _stamp(yyyymmdd, hhmm):
    """她表里 'YYYYMMDD;HH;MM' → unix 秒（失败给 0）。"""
    try:
        d, h, m = (str(yyyymmdd).split(';') + ['0', '0'])[:3]
        return int(time.mktime(time.strptime('%s %s:%s:00' % (d, h, m), '%Y%m%d %H:%M:%S')))
    except Exception:                                    # noqa: BLE001
        return 0


def _fmt(ts):
    try:
        return time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(ts))
    except Exception:                                    # noqa: BLE001
        return ''


def _lua(rel):
    """解析她 `res/script/**` 的数据表（自动吃 Sheet1），失败返回 {}。"""
    cache = getattr(_lua, '_c', None)
    if cache is None:
        cache = {}
        _lua._c = cache
    if rel in cache:
        return cache[rel]
    val = {}
    try:
        import fz_luatable
        t = fz_luatable.load_lua_table(os.path.join(RES_ROOT, rel.replace('/', os.sep)))
        if isinstance(t, dict):
            val = t.get('Sheet1') or t
        else:
            val = t
    except Exception:                                    # noqa: BLE001
        val = {}
    cache[rel] = val
    return val


def _rows(rel):
    """Lua 表 → 有序行列表（数字键按数值排序）。"""
    t = _lua(rel)
    if isinstance(t, dict):
        keys = list(t.keys())
        try:
            keys.sort(key=lambda k: float(k))
        except (TypeError, ValueError):
            keys.sort(key=lambda k: str(k))
        return [t[k] for k in keys if isinstance(t[k], dict)]
    if isinstance(t, list):
        return [v for v in t if isinstance(v, dict)]
    return []


def _sect(rel, name):
    """取她表里的具名分节（非 Sheet1），如 `others/dragonBoat.lua` 的 `门派信息`。"""
    cache = getattr(_sect, '_c', None)
    if cache is None:
        cache = {}
        _sect._c = cache
    key = (rel, name)
    if key in cache:
        return cache[key]
    val = {}
    try:
        import fz_luatable
        t = fz_luatable.load_lua_table(os.path.join(RES_ROOT, rel.replace('/', os.sep)))
        if isinstance(t, dict):
            val = t.get(name) or {}
    except Exception:                                    # noqa: BLE001
        val = {}
    cache[key] = val
    return val


# ---------------------------------------------------------------------------
# 商品目录（她 `activity/shoplist.lua` 的 2041 条）
# ---------------------------------------------------------------------------
def _cat():
    c = getattr(_cat, '_c', None)
    if c is None:
        c = []
        for r in _rows('activity/shoplist.lua'):
            gid = r.get('id')
            iid = r.get('itemId')
            if gid is None or not iid:
                continue
            name = _strip(r.get('name')) or str(iid)
            c.append({
                'id': str(gid), 'itemId': str(iid), 'name': name,
                'dsc': _strip(r.get('dsc')), 'icon': r.get('icon') or '',
                'itype': _int(r.get('itype'), 1),
            })
        if not c:                          # 表读不到时的最小兜底（仍是真表键）
            c = [{'id': '100001', 'itemId': 'mianju1180', 'name': '醉仙', 'dsc': '',
                  'icon': 'Image/UI/AttrUI/mianju/zuixian.png', 'itype': 1}]
        _cat._c = c
    return c


def _g(i):
    c = _cat()
    return c[i % len(c)]


def _gid(gid):
    """按商品表键取；找不到就绕回 0（绝不给客户端一个查不到的 id）。"""
    for g in _cat():
        if g['id'] == str(gid):
            return g
    try:
        return _g(int(str(gid)))
    except (TypeError, ValueError):
        return _g(0)


def _gn(start, n, step=1):
    total = len(_cat())
    return [_g((start + i * step) % total) for i in range(n)]


def _rw(g, num=1):
    """`data.reward` / `data.rewards` 的条目：她只读 `id`(商品表键) 和 `num`。

    ★★ 2026-10-03 注意：这条**只准喂"显示"路径**。凡是客户端拿来
      `addItemCount(id, num)` 的发货应答，`id` 必须是**真物品 id**（用 `_gr`），
      否则查无此 id 静默失败 ⇒ 弹字照出、背包空（客户实测一批活动中招）。
    """
    return {'id': g['id'], 'num': num}


def _gr(g, num=1):
    """发货版（A2 直发路径）：`id` = **真物品 id**（客户端 addItemCount 认它）。

    ★★ 2026-10-03 二轮审计定的铁律：客户端发货有**两条路**——
      A1 `GoodsHelper:fromNetworkGrantGoods`（百段阁/江湖秘宝/一掷千金/基金/年兽/
         限时历练/藏经阁/醉仙楼 等）：按 **shoplist 商品键**查表换算入包，
         还会用商品键拼弹字 ⇒ 必须**商品键**（用 `_rw/_rwl`）；
      A2 模型回调直接 `addItemCount(v.id)`（JiangHuDuoBao/DanQingGe/NewRandomGift/
         YuanBaoConsume/WakeUp/PracticeOfSkill/KungFuTrails/Smithy/AnniversaryLogin）：
         按真物品 id 查物品表 ⇒ 必须**真物品 id**（用本函数）。
      每个接口对一遍客户端再选，别想当然。"""
    return {'id': g['itemId'], 'num': _int(num, 1), 'number': _int(num, 1),
            'name': g.get('name') or '', 'type': 1, 'itype': 1,
            'icon': g.get('icon') or ''}


def _rwx(g, num=1, rtype=1):
    """面板条目用的宽版奖励（多给 type/itemId/name/number，UI 直接 setString）。"""
    return {'id': g['id'], 'itemId': g['itemId'], 'name': g['name'], 'num': num,
            'number': num, 'type': rtype, 'itype': g['itype'], 'icon': g['icon']}


def _rwl(start, n, num=1, rtype=1):
    return [_rwx(g, num, rtype) for g in _gn(start, n)]


def _ratio_rewards(start, n):
    """`data.reward`（窄版，GrantGood 要的 {id,num}）。"""
    return [_rw(g, 1 + (i % 3)) for i, g in enumerate(_gn(start, n))]


# ---------------------------------------------------------------------------
# 状态
# ---------------------------------------------------------------------------
def _state(ctx):
    st = ctx.load_json(STATE, {})
    if not isinstance(st, dict):
        st = {}
    st.setdefault('login', {'got': {}})
    st.setdefault('yuandan', {'got': {}})
    st.setdefault('spring', {'got': {}})
    st.setdefault('pay_lottery', {'times': 0, 'valid': 3, 'used': 0, 'cost': 0, 'pool': None})
    st.setdefault('yb_lottery', {'daily': 0, 'total': 0, 'yb': 9999})
    st.setdefault('diy', {'refresh': 0, 'bought': 0, 'list': None})
    st.setdefault('luckbox', {'got': {}})
    st.setdefault('voucher', {'got': {}})
    st.setdefault('spend', {'got': {}, 'bought': {}})
    st.setdefault('total_spend', {'got': {}, 'spent': 0})
    st.setdefault('plan', {'got': {}})
    st.setdefault('ybconsume', {'got': {}, 'spent': 0})
    st.setdefault('zhaocai', {'got': {}})
    st.setdefault('waking', {'got': {}, 'unlocked': 0})
    st.setdefault('practice', {'got': {}, 'unlocked': 0})
    st.setdefault('training', {'point': 0, 'tasks': None, 'got': {}})
    st.setdefault('wumen', {'got': {}})
    st.setdefault('smithy', {'got': {}, 'count': 0})
    st.setdefault('lucky', {'total': 0, 'exchange': 0, 'refresh': 0, 'goods': None})
    # ★ 2026-10-03 老板定案：好运通宝常驻 99999（每次装载强制回满）
    st['lucky']['total'] = 99999
    st.setdefault('anniv', {'got': {}, 'login_got': {}})
    st.setdefault('qixi', {'day': 0, 'finish': 0, 'state': 0, 'got': {}})
    st.setdefault('boat', {'got': {}})
    st.setdefault('nian', {'bianpao': 0, 'got': {}})
    st.setdefault('egg', {'number': 0, 'counts': {}})
    st.setdefault('calendar', {'point': 0})
    st.setdefault('newdaily', {'got': {}})
    st.setdefault('yueka', {'num': 0, 'days': 0})
    st.setdefault('upload', {'count': 0, 'info': False})
    st.setdefault('userinfo', {})
    st.setdefault('share', {'times': 0})
    st.setdefault('answer', {'status': 0, 'pass': 0})
    st.setdefault('sachet', {'got': {}, 'bfmt': 21, 'spcl': 0})
    st.setdefault('limitpkg', {'bought': {}})
    st.setdefault('pay_sign', {'times': 0})
    return st


def _save(ctx, st):
    ctx.save_json(STATE, st)


def _aid(ctx, default=0):
    """活动 id：优先 URL 尾段，其次正文。"""
    if ctx.args:
        try:
            return int(ctx.args[0])
        except (TypeError, ValueError):
            return ctx.args[0]
    v = ctx.param('activity_id', ctx.param('activityId', ctx.param('actionId', default)))
    try:
        return int(v)
    except (TypeError, ValueError):
        return v


def _arg_int(ctx, idx, name, default=0):
    if len(ctx.args) > idx:
        return _int(ctx.args[idx], default)
    return ctx.int_param(name, default)


# ===========================================================================
# 1. 签到 / 累计登录 / 元旦 / 新春首充
# ===========================================================================
def _login_pages(ctx, st):
    """同一个 URL 被两个面板用（`get_login_reward_list/<activity_id>`）：
      * `app/models/Action/BaiDuanGe.lua:20-40` 的注释块就是服务端 `list` 条目契约：
        `{tag_name, unlock_type(1免费/3月卡/2人民币), state(0未解锁/1已解锁), lock_desc,
          product_key, daily_reward:[{rid, reward:[{id,num}], state}]}`
      * `SpringFestival_2021/FundActivityLayer.lua:initList/initPanel` 需要
        `{name, desc(分号最多4段), state, rid, reward:[{type,id,number,name}]}` +
        顶层 `unlock_condition:{state,desc}`。
    两边字段一起给（同一页即同一档），`rid` 用页号（Fund 用）+ 每日用页号*100+天（BaiDuanGe 用）。
    """
    got = st['login'].setdefault('got', {})
    tags = [('布衣之约', 1, ''), ('名士之约', 3, ''), ('豪侠之约', 2, 'com.mkjump.fzjha.product119')]
    pages = []
    for pi, (tag, unlock, pkey) in enumerate(tags):
        daily = []
        merged = []
        for d in range(1, 8):
            g = _g(pi * 7 + d + 3)
            num = 1 + (d % 2)
            rid = (pi + 1) * 100 + d
            daily.append({'rid': rid, 'reward': [_rw(g, num)],
                          'state': 2 if str(rid) in got else 0})
            merged.append(_rwx(g, num, 1))
            merged[-1]['number'] = num
        pages.append({
            'rid': pi + 1,
            'name': '%s（七日）' % tag,
            'desc': ';'.join('%sX%d' % (r['name'], r['number']) for r in merged[:4]),
            'reward': merged,
            'state': 1 if pi == 0 else 0,
            'tag_name': tag, 'unlock_type': unlock,
            'lock_desc': '' if unlock == 1 else
                         ('需成为江湖名士才能领取此页奖励。' if unlock == 3
                          else '需购买豪侠之约才能领取此页奖励。'),
            'product_key': pkey,
            'daily_reward': daily,
        })
    return pages


def _h_get_login_reward_list(ctx, st):
    pages = _login_pages(ctx, st)
    _save(ctx, st)
    return ctx.ok({
        'act_name': '百段阁·每日登录福利',
        'detail_desc': ['每日登录即可领取当日奖励，漏领的可以补领。',
                        '购买名士之约/豪侠之约可解锁对应的一页奖励。'],
        'list': pages,
        'unlock_condition': {'state': 1, 'desc': '购买名士之约',
                             'product_key': 'com.mkjump.fzjha.product119'},
    }, '★ 每日登录奖励列表（契约：BaiDuanGe.lua:20-40 注释 + FundActivityLayer:initPanel）')


def _h_get_login_reward(ctx, st):
    """BaiDuanGe 传的是 `daily_reward[i].rid`（页号*100+天）；Fund 传的是页号 rid。"""
    rid = ctx.int_param('rid', 0) or _arg_int(ctx, 0, 'rid', 0)
    if not rid:
        return ctx.fail('奖励参数错误', '★ get_login_reward 缺 rid（她 :161 传的是 rid）')
    pages = _login_pages(ctx, st)
    page = pages[min(2, max(0, rid // 100 - 1))] if rid >= 100 else \
        pages[min(2, max(0, rid - 1))]
    rewards = [_rwx(_gid(r['id']), r['num'], 1) for r in page['reward']]
    if rid < 100:
        rewards = rewards[:2]
    st['login'].setdefault('got', {})[str(rid)] = 1
    _save(ctx, st)
    return ctx.ok({
        'reward': rewards,
        'msg': '', 'dataVer': _int(ctx.param('dataVer'), 0),
        'currencyVersion': _int(ctx.param('currencyVersion'), 0),
        'yashi_expired_time': 0,
    }, '★ 领取每日登录奖励（GrantGoodRequest 要 reward:[{id,num}]；Fund 读 type/id/number/name）')


# 元旦登录：LoginRewardLayer:showLayer 读 name / dsc / activity_time / relist
#: ★ 2026-10-03 客户报「七日登录领取的也没有」：原来固定发 shoplist 第 21..27 行
#:   （7 张戏曲面具）——面具是**外观类**，进了面具库、普通背包看不见 ⇒ 像"没发"。
#:   改成 7 天发**日常真消耗品**（下面 7 个都核过：既在 shoplist、又是客户端
#:   物品表认得的真 itemId——ygpill/笃志/凝神丹那些是纯商品键，发下去客户端
#:   addItemCount 查无此物，又是一个"领了没有"）。
_YUANDAN_ITEMS = ['qiannengdan', 'xinggongsan', 'liuyunganlu', 'jingxinwan',
                  'jingmai101', 'jingmai103', 'sancaidan']


def _yuandan_g(i):
    iid = _YUANDAN_ITEMS[(max(1, i) - 1) % len(_YUANDAN_ITEMS)]
    for g in _cat():
        if g['itemId'] == iid:
            return g
    return _g(20 + max(1, i))


def _h_get_login_yuandan_info(ctx, st):
    got = st['yuandan'].setdefault('got', {})
    relist = []
    for i in range(1, 8):
        g = _yuandan_g(i)
        state = 5 if str(i) in got else (2 if i <= 3 else 1)
        relist.append({
            'rid': i,
            # ★ 客户端 `initList/initPanel` 读的是 `rewardId`（不是 rid），
            #   不给它领取请求里就永远是 nil ⇒ 点的档和发的档错位。
            'rewardId': i,
            'times': '元旦第%d天' % i,
            'dsc': '%s X1' % g['name'],
            'state': state,
            'rewards': [{'type': 3, 'key': g['itemId'], 'value': 1,
                         'id': g['itemId'], 'num': 1, 'name': g['name'], 'number': 1}],
        })
    return ctx.ok({
        'name': '元旦登录礼',
        'dsc': '元旦期间每日登录即可领取一份贺礼，共七日。',
        'activity_time': '%s ~ %s' % (_fmt(_now() - 86400 * 3), _fmt(FAR_FUTURE)),
        'relist': relist,
    }, '★ 元旦登录面板（LoginRewardLayer:showLayer/initPanel；REWARD_STATE 1/2/3/5）')


def _h_set_login_yuandan_reward(ctx, st):
    """领取「元旦登录礼」（活动名「七日登录」）某一档。

    ★★ 老板 2026-09-28 报「领取时显示奖励参数错误」。实测：
      客户端**确实**会 POST `{rewardId=N}`（`HttpManager:setLoginYuandaReward`），
      但那次请求的正文**没能解出可解析的参数**（同一次运行里其它请求解密都成功，
      只有这一个小 body 例外），于是这里读不到 rid ⇒ 直接回 "奖励参数错误"，
      玩家点了等于白点。

      用户可感知的行为不该卡在协议细节上 ⇒ **读不到时退化为"下一个可领的档位"**
      （`state != 5` 的最小 rid）。这样点击总是有反馈；真拿到了 rewardId 就照它走。
    """
    rid = ctx.int_param('rewardId', 0) or _arg_int(ctx, 0, 'rewardId', 0)
    if not rid:
        got = st['yuandan'].setdefault('got', {})
        for i in range(1, 8):
            if str(i) not in got:
                rid = i
                break
        rid = rid or 1
    st['yuandan'].setdefault('got', {})[str(rid)] = 1
    _save(ctx, st)
    g = _yuandan_g(max(1, rid))
    return ctx.ok({
        'reward': [{'type': 3, 'key': g['itemId'], 'value': 1, 'id': g['itemId'],
                    'name': g['name'], 'num': 1, 'number': 1}],
    }, '★ 领取元旦登录奖励（她读 v.type(REWARD_TYPE) / v.key / v.value）')


# 新春首充：FisrtCharge.__dealWithRewardInfo / __dealWithReward
def _spring_base(ctx):
    base = []
    for d in range(1, 8):
        g = _g(30 + d)
        base.append({
            'day': d, 'rid': d, 'desc': '%s X%d' % (g['name'], 1 + d % 2),
            'status': 0, 'state': 0, 'imagePath': g['icon'],
            'reward': [{'itemId': g['itemId'], 'id': g['id'], 'num': 1 + d % 2,
                        'number': 1 + d % 2, 'name': g['name'], 'type': 1}],
        })
    return base


def _h_get_spring_new_reward(ctx, st):
    base = _spring_base(ctx)
    got = st['spring'].setdefault('got', {})
    for row in base:
        if str(row['day']) in got:
            row['status'] = 2
            row['state'] = 2
        elif row['day'] == 1:
            row['status'] = 1
            row['state'] = 1
    return ctx.ok({
        'name': '新春首充礼',
        'detail_desc': ['活动期间首次充值即可领取第一份贺礼。',
                        '累计充值天数越多，可领取的贺礼越多。'],
        'detail_time': '%s ~ %s' % (_fmt(_now()), _fmt(FAR_FUTURE)),
        'hasup': 1, 'base': base, 'end_time': FAR_FUTURE,
    }, '★ 新春首充面板（FisrtCharge:__dealWithRewardInfo 读 day/desc/status/imagePath/reward）')


def _h_receive_spring_new_reward(ctx, st):
    rid = _arg_int(ctx, 0, 'rid', 0) or ctx.int_param('rid', 0)
    if not rid:
        return ctx.fail('奖励参数错误', '★ receive_spring_new_reward 缺 rid（URL 尾段）')
    st['spring'].setdefault('got', {})[str(rid)] = 1
    _save(ctx, st)
    g = _g(30 + max(1, rid))
    return ctx.ok({
        'reward': [{'itemId': g['itemId'], 'id': g['id'], 'num': 1, 'number': 1,
                    'name': g['name'], 'type': 1}],
    }, '★ 领取新春首充（FisrtCharge:__dealWithReward 读 itemId/num/name/type）')


# ===========================================================================
# 2. 抽奖
# ===========================================================================
def _pay_lottery(ctx, st):
    """ChongZhiChouJiangLayer:setLoadingBar/setRewardPanel/setButtonTotalPrize/setshowAllRewardList。"""
    d = st['pay_lottery']
    rows = []
    for i in range(8):
        g = _g(40 + i)
        rows.append({'rid': g['id'], 'id': g['id'], 'itemId': g['itemId'], 'name': g['name'],
                     'icon': g['icon'], 'number': 1, 'num': 1, 'showType': 1 if i < 6 else 0})
    return {
        'lottery_times': d['times'], 'lottery_limit': max(1, d['valid'] + d['times']),
        'lottery_valid_times': max(0, d['valid'] - d['used']),
        'order_id': 'order_%d_%d' % (d['times'], _day()),
        'list': rows,
        'lottery_items': [{'name': g['name'], 'number': 1, 'id': g['id'],
                           'itemId': g['itemId'], 'icon': g['icon']} for g in _gn(40, 8)],
        'removeYb': 100, 'costYb': d['cost'],
        'lottery_total_times': d['times'],
    }


def _h_get_lottery_list(ctx, st):
    body = _pay_lottery(ctx, st)
    if _int(ctx.param('is_refresh'), 0) or str(ctx.param('is_refresh', 'N')).upper() == 'Y':
        st['pay_lottery']['pool'] = _now()
        _save(ctx, st)
    return ctx.ok(body, '★ 累计充值抽奖面板（ChongZhiChouJiangLayer:setLoadingBar/setRewardPanel/'
                        'setButtonTotalPrize/setshowAllRewardList）')


def _h_do_lottery(ctx, st):
    d = st['pay_lottery']
    if d['valid'] - d['used'] <= 0:
        return ctx.fail('抽奖次数不足', '★ do_lottery 业务门：累计充值可抽次数用尽')
    d['used'] += 1
    d['times'] += 1
    _save(ctx, st)
    g = _g(40 + d['times'])
    # ChongZhiChouJiangLayer:getReward 按 pairs 读 v.itemId / v.number / v.name
    return ctx.ok([{'itemId': g['itemId'], 'id': g['id'], 'name': g['name'],
                    'number': 1, 'num': 1}],
                  '★ 充值抽奖结果（getReward 遍历数组读 itemId/number/name）')


def _h_get_yuanbao_lottery_list(ctx, st):
    d = st['yb_lottery']
    rows = []
    for i in range(8):
        g = _g(48 + i)
        rows.append({'rid': g['id'], 'id': g['id'], 'itemId': g['itemId'], 'name': g['name'],
                     'icon': g['icon'], 'number': 1, 'num': 1, 'showType': 1})
    return ctx.ok({
        'lottery_daily_times': d['daily'], 'lottery_total_times': d['total'],
        'lottery_limit': 10, 'removeYb': 50, 'yuanbao': d['yb'],
        'list': rows,
        'lottery_items': [{'name': g['name'], 'number': 1, 'id': g['id'],
                           'itemId': g['itemId'], 'icon': g['icon']} for g in _gn(48, 8)],
    }, '★ 腊八元宝抽奖面板（LaBaChongZhiChouJiangLayer 逐字段读 6 个数字 + lottery_items）')


def _h_do_yuanbao_lottery(ctx, st):
    d = st['yb_lottery']
    if d['daily'] >= 10:
        return ctx.fail('今日抽奖次数已用完', '★ do_yuanbao_lottery 业务门：每日上限 10 次')
    if d['yb'] < 50:
        return ctx.fail('元宝不足', '★ do_yuanbao_lottery 业务门：元宝 < 50')
    d['daily'] += 1
    d['total'] += 1
    d['yb'] -= 50
    _save(ctx, st)
    g = _g(48 + d['total'])
    return ctx.ok({'lottery_daily_times': d['daily'], 'lottery_total_times': d['total'],
                   'lottery_limit': 10, 'removeYb': 50, 'yuanbao': d['yb'],
                   'list': [{'rid': g['id'], 'id': g['id'], 'itemId': g['itemId'],
                             'name': g['name'], 'icon': g['icon'], 'number': 1, 'num': 1,
                             'showType': 1}],
                   'lottery_items': []},
                  '★ 元宝抽奖结果（她先读 6 个数字再 getReward(data)）')


def _h_do_mingren_lottery(ctx, st):
    """JiangHuYiRenLuAction.lua: 读 prize:[{sendFrom,itemId,number}] / yuanbao / baifangmingtie。
    名人录的币与次数状态在 `activities.py`（`get_mingren_lottery_list`），这里只读不写。"""
    times = _arg_int(ctx, 0, 'times', 1) or 1
    if times not in (1, 5):
        times = 1
    cost = 80 * times if times == 5 else 80
    st['sachet']['bfmt'] = max(0, _int(st['sachet'].get('bfmt'), 21))
    if st['sachet']['bfmt'] < 1 and ctx.param('baifangmingtie') is None:
        return ctx.fail('拜会名帖不足', '★ do_mingren_lottery 业务门：拜会名帖为 0')
    prize = []
    for i in range(times):
        g = _g(56 + i)
        prize.append({'sendFrom': 'client', 'itemId': g['itemId'], 'id': g['id'],
                      'name': g['name'], 'number': 1, 'num': 1, 'type': 1,
                      'icon': g['icon']})
    _save(ctx, st)
    return ctx.ok({
        'prize': prize,
        'yuanbao': 9999,
        'baifangmingtie': st['sachet']['bfmt'],
        'times': times, 'cost': cost,
    }, '★ 名人录抽奖（JiangHuYiRenLuAction:doMingRenLottery 读 prize/yuanbao/baifangmingtie）')


def _h_bfmingtie_exchange_spcl(ctx, st):
    """JiangHuYiRenLuAction: `{baifangmingtie, removebfmt, addspcl}`（注释里写死的三字段）。"""
    cur = _int(st['sachet'].get('bfmt'), 21)
    if cur < 2:
        return ctx.fail('拜会名帖不足', '★ bfmingtie_exchange_spcl 业务门：需要 2 张拜会名帖')
    st['sachet']['bfmt'] = cur - 2
    st['sachet']['spcl'] = _int(st['sachet'].get('spcl'), 0) + 333
    _save(ctx, st)
    return ctx.ok({'baifangmingtie': st['sachet']['bfmt'], 'removebfmt': 2,
                   'addspcl': 333, 'spcl': st['sachet']['spcl']},
                  '★ 拜会名帖换特殊帖（她读 baifangmingtie/removebfmt/addspcl）')


# —— DIY 礼包（RandomGiftLayer）——
def _diy_list(ctx, st=None):
    """刷新（is_refresh=Y）真的换一批货：按刷新次数在货架上平移。"""
    off = 64
    if st is not None:
        off += 3 * _int(st['diy'].get('refresh'), 0)
    out = []
    for i in range(6):
        g = _g(off + i)
        out.append({'name': g['name'], 'number': 1 + (i % 3), 'num': 1 + (i % 3),
                    'itemId': g['itemId'], 'id': g['id'], 'icon': g['icon']})
    return out


def _h_get_diy_goods(ctx, st):
    refresh = str(ctx.param('is_refresh', 'N')).upper()
    if refresh == 'Y':
        st['diy']['refresh'] = _int(st['diy'].get('refresh'), 0) + 1
    lst = _diy_list(ctx, st)
    st['diy']['list'] = [r['itemId'] for r in lst]
    _save(ctx, st)
    total = sum(r['number'] for r in lst)
    discount = 80
    return ctx.ok({
        'list': lst,
        'diygift_times': _int(st['diy'].get('bought'), 0),
        'refresh_times': _int(st['diy'].get('refresh'), 0),
        'refresh_yuanbao': 50,
        'discount': discount,
        'discountYb': 300,
        'totalYb': total * 100,
        'bought': 1 if _int(st['diy'].get('bought'), 0) > 0 else 0,
    }, '★ DIY 随机礼包（RandomGiftLayer:setInfo/showList 逐字段读）')


def _h_get_diy_infos(ctx, st):
    # `RandomGiftLayer:getDiyInfos` 是 `for i,v in ipairs(data)` ⇒ 顶层必须是**数组**
    lst = st['diy'].get('list') or [r['itemId'] for r in _diy_list(ctx, st)]
    rows = []
    for iid in lst:
        for g in _cat():
            if g['itemId'] == iid:
                rows.append({'itemId': g['itemId'], 'number': 1, 'name': g['name'],
                             'id': g['id'], 'icon': g['icon']})
                break
    return ctx.ok(rows, '★ DIY 奖励内容（getDiyInfos 用 ipairs 遍历 ⇒ 顶层是数组）')


def _h_buy_diy_goods(ctx, st):
    if _int(st['diy'].get('bought'), 0) > 0:
        return ctx.ok(_diy_body(ctx, st, 1),
                      '★ 已购买过（她 errcode==1 也走 setInfo，所以仍需完整面板字段）')
    st['diy']['bought'] = _int(st['diy'].get('bought'), 0) + 1
    _save(ctx, st)
    return ctx.ok(_diy_body(ctx, st, 0), '★ 购买 DIY 礼包（buy_diy_goods 回调同样调 setInfo(data)）')


def _diy_body(ctx, st, bought):
    lst = _diy_list(ctx, st)
    total = sum(r['number'] for r in lst)
    return {
        'list': lst, 'diygift_times': _int(st['diy'].get('bought'), 0),
        'refresh_times': _int(st['diy'].get('refresh'), 0), 'refresh_yuanbao': 50,
        'discount': 0, 'discountYb': 0, 'totalYb': total * 100, 'bought': bought,
    }


# —— 幸运宝箱（NewRandomGift）——
def _h_get_luck_box_good(ctx, st):
    """★ 2026-10-03 重写（客户报「天缘奇盒领取的物品背包没有」）。原实现两处断：
      ① 面板（activities._luck_box）给的 rid 是**活动目录商品键**（如 500001），
         这里却当**整数下标**扔进另一张全量目录 `_g(70+rid)` ⇒ 发什么货随机；
      ② 回包 `reward.id` 是商品表键，客户端 `NewRandomGift.lua:157
         addItemCount(reward.id)` 按真物品 id 查 ⇒ 查无静默失败，背包永远空。
      现在：按商品键回**activities 同一份目录**取货 + `id` 给真物品 id +
      已领标记写进 activities_state（与面板同源，不再无限重复领）。
    """
    rid = str(ctx.param('rid', '') or '')
    if not rid:
        return ctx.fail('奖励参数错误', '★ get_luck_box_good 缺 rid')
    import fz_api.activities as _act
    g = _act._goods_by_id(ctx, rid)
    act_st = ctx.load_json(_act.STATE, {})
    if not isinstance(act_st, dict):
        act_st = {}
    box = act_st.setdefault('luckbox', {})
    if str(rid) in (box.setdefault('state', {})):
        pass                                    # 已有状态（0/1/2），照常给面板语义
    box['state'][str(rid)] = 2
    ctx.save_json(_act.STATE, act_st)
    return ctx.ok({
        # `NewRandomGift.lua:157` 读 reward.itype/id/number → addItemCount(id, number)
        'reward': {'itype': 1, 'id': g['itemId'], 'itemId': g['itemId'], 'number': 1,
                   'num': 1, 'name': g['name'], 'icon': g['icon'], 'rid': g['id']},
        'dataVer': _int(ctx.param('dataVer'), 0),
        'currencyVersion': _int(ctx.param('currencyVersion'), 0),
        'msg': '',
    }, '★ 幸运宝箱开奖（%s → %s）' % (g['name'], g['itemId']))


def _h_buy_luck_box_good(ctx, st):
    """★ 2026-10-03：购买后把该商品状态翻成 1（可领取）——原来回空包、状态不动，
      玩家买完面板还停在"购买"按钮上，永远走不到领取那一步。
      （rid 是活动目录商品键，与面板 `_luck_box` 的 state 键同源。）"""
    rid = str(ctx.param('rid', '') or '')
    if not rid:
        return ctx.fail('参数错误', '★ buy_luck_box_good 缺 rid')
    import fz_api.activities as _act
    act_st = ctx.load_json(_act.STATE, {})
    if not isinstance(act_st, dict):
        act_st = {}
    box = act_st.setdefault('luckbox', {})
    box.setdefault('state', {})[str(rid)] = 1
    ctx.save_json(_act.STATE, act_st)
    return ctx.ok({}, '★ 购买幸运盒商品 %s（state→1 可领取）' % rid)


def _h_get_voucher_prize_2(ctx, st):
    """NewSignInGiftBagLayer / RedeemActivityLayer：`data.yuanbao` 或 `data.itemId` 二选一。"""
    vid = str(ctx.param('voucher', '') or (ctx.args[0] if ctx.args else ''))
    if not vid:
        return ctx.fail('兑换券参数错误', '★ get_voucher_prize_2 缺 voucher')
    if vid in st['voucher'].setdefault('got', {}):
        return ctx.fail('该兑换券已使用', '★ get_voucher_prize_2 业务门：已兑换过')
    st['voucher']['got'][vid] = 1
    _save(ctx, st)
    return ctx.ok({'yuanbao': 88}, '★ 兑换券开奖（她先判 data.yuanbao，再有 data.itemId）')


# ===========================================================================
# 3. 消费返利 / 理财
# ===========================================================================
def _spend_list(ctx, st):
    """JiangHuMiBao:__dealWithRewardInfo 读 libaoName/count/rid/reward/state/price/
    productKey/pay_type/limit_type。"""
    got = st['spend'].setdefault('got', {})
    bought = st['spend'].setdefault('bought', {})
    out = []
    for i in range(4):
        g = _g(80 + i)
        rid = i + 1
        state = 2 if str(rid) in got else (0 if i < 2 else 1)
        cnt = max(0, 3 - _int(bought.get(str(rid)), 0))
        out.append({
            'rid': rid, 'libaoName': '秘宝·%s' % g['name'],
            'count': cnt if state != 2 else 0,
            'reward': [_rw(g, 1 + i)], 'state': state,
            'price': '%d元宝' % (100 * (i + 1)),
            'productKey': str(100 * (i + 1)), 'pay_type': 3, 'limit_type': 1,
            'text1': '秘宝·%s' % g['name'], 'text2': '本日剩余购买%d次' % cnt,
        })
    return out


def _h_get_spend_reward_list(ctx, st):
    lst = _spend_list(ctx, st)
    return ctx.ok({
        'act_name': '江湖秘宝', 'detail_desc': ['活动期间消耗/购买可领取秘宝。',
                                            '每日购买次数有限，次日重置。'],
        'act_end': _fmt(FAR_FUTURE), 'end_time': FAR_FUTURE,
        'list': lst, 'act_times': 1,
    }, '★ 秘宝返利列表（JiangHuMiBao:__dealWithRewardInfo 逐字段）')


def _h_get_spend_reward(ctx, st):
    rid = ctx.int_param('rid', 0)
    if not rid:
        return ctx.fail('奖励参数错误', '★ get_spend_reward 缺 rid')
    st['spend'].setdefault('got', {})[str(rid)] = 1
    _save(ctx, st)
    return ctx.ok({
        'reward': _ratio_rewards(80 + rid, 2), 'msg': '',
        'dataVer': _int(ctx.param('dataVer'), 0),
        'currencyVersion': _int(ctx.param('currencyVersion'), 0),
    }, '★ 领取秘宝（GrantGoodRequest 要 reward:[{id,num}]）')


def _h_buy_spend_reward(ctx, st):
    rid = ctx.int_param('rid', 0)
    if not rid:
        return ctx.fail('参数错误', '★ buy_spend_reward 缺 rid')
    b = st['spend'].setdefault('bought', {})
    if _int(b.get(str(rid)), 0) >= 3:
        return ctx.fail('购买次数已达上限', '★ buy_spend_reward 业务门：单档限购 3 次')
    b[str(rid)] = _int(b.get(str(rid)), 0) + 1
    _save(ctx, st)
    return ctx.ok({}, '★ 购买秘宝档位（她只看 errcode，成功后本地扣钱刷新）')


def _h_get_total_spend_detail(ctx, st):
    """DieJinChongZhi:__dealWithRewardInfo 读 award_type/total_day/award_string/status/award_box。"""
    got = st['total_spend'].setdefault('got', {})
    award = {}
    for i in range(1, 8):
        g = _g(84 + i)
        rid = str(i)
        box = [_rwx(g, 1, 1)]
        award[rid] = {
            'award_type': 1 if i <= 5 else 2, 'total_day': i * 2,
            'award_string': '%s X1' % g['name'],
            'status': 2 if rid in got else (1 if i <= 2 else 0),
            'award_box': box, 'id': i, 'needMoney': 100 * i,
        }
    return ctx.ok({
        'name': '叠金充值', 'detail_desc': ['累计充值达到指定天数可领取对应奖励。',
                                        '每日充值奖励当天可领，隔日重置。'],
        'day': 0, 'spend_number': _int(st['total_spend'].get('spent'), 0),
        'standard_number': 16, 'award_list': award, 'list': award,
    }, '★ 叠金充值明细（DieJinChongZhi:__dealWithRewardInfo 逐字段）')


def _h_get_total_spend_award(ctx, st):
    rid = str(ctx.param('award_id', '') or ctx.param('rid', ''))
    if not rid:
        return ctx.fail('奖励参数错误', '★ get_total_spend_award 缺 award_id')
    if rid in st['total_spend'].setdefault('got', {}):
        return ctx.fail('该奖励已领取', '★ get_total_spend_award 业务门：已领')
    st['total_spend']['got'][rid] = 1
    _save(ctx, st)
    g = _g(84 + _int(rid, 1))
    return ctx.ok({'award_box': [_gr(g, 1)], 'msg': '',
                   'reward': [_gr(g, 1)]},
                  '★ 领取叠金充值奖励（她读 data.award_box 数组的 type/id/number/name）')


def _h_get_yuanbao_plan_gift_list(ctx, st):
    """YiZhiQianJin 读 act_name/detail_desc/spend_yuanbao/list；
    ConsumeWingLayer 读 config.base{k}{i}{id,count,name,image,showType,nameDes} +
    shopping_money + list。"""
    got = st['plan'].setdefault('got', {})
    lst = []
    for i in range(1, 9):
        g = _g(92 + i)
        lst.append({'rid': i, 'id': i, 'state': 2 if str(i) in got else (1 if i <= 2 else 0),
                    'text': '累计消耗 %d 元宝' % (i * 500),
                    'need_money': i * 500,
                    'rewards': [_rwx(g, 1, 1)], 'reward': [_rwx(g, 1, 1)],
                    'name': g['name'], 'desc': '%s X1' % g['name'], 'number': 1})
    base = {}
    for k in range(1, 9):
        base[str(k)] = {str(i): [{'itemId': _g(92 + k)['itemId'], 'id': _g(92 + k)['id'],
                                  'name': _g(92 + k)['name'], 'count': 1, 'number': 1,
                                  'image': _g(92 + k)['icon'], 'showType': 1,
                                  'nameDes': '', 'getType': 1}] for i in range(1, 2)}
    return ctx.ok({
        'act_name': '一元计划·消耗返礼', 'detail_desc': [
            '活动期间累计消耗元宝达到指定额度即可领取奖励。', '奖励需手动领取，活动结束后失效。'],
        'spend_yuanbao': _int(st['total_spend'].get('spent'), 0),
        'shopping_money': _int(st['total_spend'].get('spent'), 0),
        'list': lst,
        'config': {'base': base, 'strategy_id': 1},
        'end_time': FAR_FUTURE,
    }, '★ 元宝理财计划（YiZhiQianJin + ConsumeWingLayer:initGiftTable/setLoadBasr）')


def _h_receive_yuanbao_plan_gift(ctx, st):
    rid = ctx.int_param('rid', 0)
    if not rid:
        return ctx.fail('奖励参数错误', '★ receive_yuanbao_plan_gift 缺 rid')
    if str(rid) in st['plan'].setdefault('got', {}):
        return ctx.fail('该奖励已领取', '★ receive_yuanbao_plan_gift 业务门：已领')
    st['plan']['got'][str(rid)] = 1
    _save(ctx, st)
    return ctx.ok({
        'reward': _ratio_rewards(92 + rid, 2), 'msg': '',
        'dataVer': _int(ctx.param('dataVer'), 0),
        'currencyVersion': _int(ctx.param('currencyVersion'), 0),
    }, '★ 领取理财奖励（GrantGoodRequest + printGetRewardsText 都要 reward:[{id,num}]）')


def _h_get_yuanbao_consumption_info(ctx, st):
    """YuanBaoConsumeAction:__dealWithRewardInfo 读 rid/target/state/rewards。"""
    got = st['ybconsume'].setdefault('got', {})
    lst = []
    for i in range(1, 9):
        g = _g(100 + i)
        lst.append({'rid': i, 'target': i * 1000, 'state': 2 if str(i) in got else
                    (1 if i <= 2 else 0), 'rewards': [_rwx(g, 1, 1)],
                    'reward': [_rwx(g, 1, 1)], 'text': '累计消耗 %d 元宝' % (i * 1000)})
    return ctx.ok({
        'act_name': '元宝消耗返利',
        'detail_desc': ['活动期间累计消耗元宝达到额度即可领取返利。', '每档限领一次。'],
        'detail_time': '%s ~ %s' % (_fmt(_now()), _fmt(FAR_FUTURE)),
        'spend_number': _int(st['ybconsume'].get('spent'), 0),
        'list': lst, 'end_time': FAR_FUTURE,
    }, '★ 元宝消耗面板（YuanBaoConsumeAction:__dealWithRewardInfo 读 rid/target/state/rewards）')


def _h_get_yuanbao_consumption_reward(ctx, st):
    rid = ctx.int_param('rid', 0) or _arg_int(ctx, 0, 'rid', 0)
    if not rid:
        return ctx.fail('奖励参数错误', '★ get_yuanbao_consumption_reward 缺 rid')
    if str(rid) in st['ybconsume'].setdefault('got', {}):
        return ctx.fail('该奖励已领取', '★ 业务门：已领')
    st['ybconsume']['got'][str(rid)] = 1
    _save(ctx, st)
    return ctx.ok({
        'rewards': [_gr(g, 1) for g in _gn(100 + rid, 2)],
        'msg': '', 'dataVer': _int(ctx.param('dataVer'), 0),
    }, '★ 领取消耗返利（A2 直发，真物品 id）')


def _h_get_zhaocaijinbao_info(ctx, st):
    """JuBaoPen: list:[{id,status,needMoney,idType,rewards}] + rewards:{rid:[{itemId,...}]}。"""
    got = st['zhaocai'].setdefault('got', {})
    lst = []
    rewards = {}
    for i in range(1, 7):
        g = _g(110 + i)
        lst.append({'id': i, 'status': 2 if str(i) in got else (1 if i <= 2 else 0),
                    'needMoney': i * 500, 'idType': 1,
                    # ★ 二轮审计：JuBaoPenPresenter:93 getRewardById 按**顶层 rewards
                    #   map 的键**（"1".."6"）查，发商品键会 nil 崩面板
                    'rewards': [str(i + 1)], 'rewardType': 1})
        rewards[str(i)] = [{'itemId': g['itemId'], 'id': g['id'], 'number': 1, 'num': 1,
                            'name': g['name'], 'type': 1}]
    return ctx.ok({
        'act_name': '招财进宝',
        'detail_desc': ['消耗元宝聚宝，达到额度即可开箱。', '每档奖励限领一次。'],
        'shopping_money': _int(st['total_spend'].get('spent'), 0),
        'list': lst, 'rewards': rewards, 'end_time': FAR_FUTURE,
    }, '★ 招财进宝面板（JuBaoPen:__dealWithRewardLevelInfo + __dealWithRewardInfo）')


def _h_get_zhaocaijinbao_reward(ctx, st):
    rid = ctx.int_param('id', 0) or ctx.int_param('reward_id', 0)
    if not rid:
        return ctx.fail('奖励参数错误', '★ get_zhaocaijinbao_reward 缺 id')
    if str(rid) in st['zhaocai'].setdefault('got', {}):
        return ctx.fail('该奖励已领取', '★ 业务门：已领')
    st['zhaocai']['got'][str(rid)] = 1
    _save(ctx, st)
    g = _g(110 + _int(rid, 1))
    return ctx.ok({
        'reward': [{'type': 1, 'itemId': g['itemId'], 'id': g['id'], 'number': 1,
                    'num': 1, 'name': g['name']}],
        'msg': '', 'dataVer': _int(ctx.param('dataVer'), 0),
        'currencyVersion': _int(ctx.param('currencyVersion'), 0),
        'yashi_expired_time': 0,
    }, '★ 开招财宝箱（她读 v.type/v.itemId/v.number/v.name + yashi_expired_time）')


def _h_get_waking_dream_info(ctx, st):
    """WakeUpAction:__initShowRewardList（list）+ goods{jackpotId,pay_number,product_key,
    currency_name,pay_type,pay_state} + max_floor + detail_time。"""
    got = st['waking'].setdefault('got', {})
    lst = []
    for i in range(1, 9):
        g = _g(120 + i)
        lst.append({'rid': i, 'state': 2 if str(i) in got else (1 if i <= 2 else 0),
                    'rewards': [_rwx(g, 1, 1)], 'jackpotId': 1,
                    'jackpotName': '醒梦堂', 'giftText': '%sX1' % g['name'],
                    'text': '第%d层' % i})
    return ctx.ok({
        'act_name': '醒梦堂', 'detail_time': '长期开放',
        'detail_desc': ['层层向上挑战，每层首次通关可领一份奖励。', '购买醒梦令可额外解锁奖励。'],
        'list': lst, 'max_floor': 8,
        'goods': {'jackpotId': 1, 'pay_number': 100, 'product_key': 'com.mkjump.fzjha.product120',
                  'currency_name': '元宝', 'pay_type': 1,
                  'pay_state': 2 if _int(st['waking'].get('unlocked'), 0) else 1},
        'end_time': FAR_FUTURE,
    }, '★ 醒梦堂面板（WakeUpAction:__initShowRewardList + data.goods 六个字段）')


def _h_get_waking_dream_reward(ctx, st):
    rid = ctx.int_param('rid', 0) or _arg_int(ctx, 0, 'rid', 0)
    if not rid:
        return ctx.fail('奖励参数错误', '★ get_waking_dream_reward 缺 rid')
    if str(rid) in st['waking'].setdefault('got', {}):
        return ctx.fail('该奖励已领取', '★ 业务门：已领')
    st['waking']['got'][str(rid)] = 1
    _save(ctx, st)
    return ctx.ok({'rewards': [_gr(g, 1) for g in _gn(120 + rid, 2)], 'msg': '',
                   'dataVer': _int(ctx.param('dataVer'), 0)},
                  '★ 领取醒梦堂奖励（A2 直发，真物品 id）')


def _h_unlock_waking_dream_pay_reward(ctx, st):
    if _int(st['waking'].get('unlocked'), 0):
        return ctx.fail('已解锁，无需重复购买', '★ 业务门：已解锁')
    st['waking']['unlocked'] = 1
    _save(ctx, st)
    return ctx.ok({'msg': '解锁成功'}, '★ 解锁醒梦堂付费奖励（她只读 data.msg）')


def _h_get_practice_skill_reward_list(ctx, st):
    """PracticeOfSkill:__initShowRewardList: rid/state/text/jackpotId/jackpotName/rewards/giftText
    + unlock_info{jackpotId,payText,productKey,payType,payState}。"""
    got = st['practice'].setdefault('got', {})
    lst = []
    for i in range(1, 9):
        g = _g(130 + i)
        lst.append({'rid': i, 'state': 2 if str(i) in got else (1 if i <= 2 else 0),
                    'text': '练功第%d重' % i, 'jackpotId': 1 + (i % 2),
                    'jackpotName': '练功奖励' if i % 2 else '进阶奖励',
                    'rewards': [_rwx(g, 1, 1)], 'giftText': '%sX1' % g['name']})
    return ctx.ok({
        'act_name': '武学练习', 'detail_desc': ['提升武学等级可领取对应奖励。', '每档限领一次。'],
        'detail_time': '%s ~ %s' % (_fmt(_now()), _fmt(FAR_FUTURE)),
        'list': lst,
        'unlock_info': {'jackpotId': 1, 'payText': '解锁进阶奖励',
                        'productKey': 'com.mkjump.fzjha.product121', 'payType': 1,
                        'payState': 2 if _int(st['practice'].get('unlocked'), 0) else 1},
        'end_time': FAR_FUTURE,
    }, '★ 武学练习面板（PracticeOfSkill:__initShowRewardList 逐字段 + unlock_info）')


def _h_get_practice_skill_reward(ctx, st):
    rid = ctx.int_param('rid', 0) or _arg_int(ctx, 0, 'rid', 0)
    if not rid:
        return ctx.fail('奖励参数错误', '★ get_practice_skill_reward 缺 rid')
    if str(rid) in st['practice'].setdefault('got', {}):
        return ctx.fail('该奖励已领取', '★ 业务门：已领')
    st['practice']['got'][str(rid)] = 1
    _save(ctx, st)
    return ctx.ok({'rewards': [_gr(g, 1) for g in _gn(130 + rid, 2)], 'msg': '',
                   'dataVer': _int(ctx.param('dataVer'), 0)},
                  '★ 领取武学练习奖励（A2 直发，真物品 id）')


def _h_unlock_practice_skill_reward(ctx, st):
    if _int(st['practice'].get('unlocked'), 0):
        return ctx.fail('已解锁，无需重复购买', '★ 业务门：已解锁')
    st['practice']['unlocked'] = 1
    _save(ctx, st)
    return ctx.ok({'msg': '解锁成功'}, '★ 解锁练功付费奖励（她只读 data.msg）')


# —— 限时历练（LimitedTimeExperience）——
def _training_tasks(ctx, st):
    got = st['training'].setdefault('got', {})
    rows = _rows('others/limitedTimeExperience.lua')
    out = []
    for i, r in enumerate(rows[:12]):
        rid = i + 1
        out.append({'id': rid, 'state': 2 if str(rid) in got else (1 if i < 3 else 0),
                    'name': _strip(r.get('name')) or ('历练任务%d' % rid),
                    'desc': _strip(r.get('dsc')),
                    'score': _int(r.get('needpoints'), 1),
                    'text1': _strip(r.get('name')), 'text2': _strip(r.get('dsc')),
                    'text3': '可获得历练分：%d分' % _int(r.get('needpoints'), 1)})
    if not out:
        for i in range(6):
            g = _g(140 + i)
            out.append({'id': i + 1, 'state': 0, 'name': g['name'], 'desc': g['dsc'][:40],
                        'score': i + 1, 'text1': g['name'], 'text2': g['dsc'][:40],
                        'text3': '可获得历练分：%d分' % (i + 1)})
    return out


def _h_add_training_task_point(ctx, st):
    tid = ctx.param('tid', ctx.param('taskId', ''))
    add = max(1, _int(ctx.param('taskList'), 1))
    st['training']['point'] = _int(st['training'].get('point'), 0) + add
    if tid:
        # ★ 2026-10-03：任务完成状态写 `done`（面板 `_training_info` 的任务 state 读它）。
        #   原来写 `got` —— 而 `got` 同时被"领档位奖励"用（键都是 1~4）⇒ 交任务 1
        #   会把奖励档 1 顶成"已领"，两边互相污染。
        st['training'].setdefault('done', {})[str(tid)] = 1
    _save(ctx, st)
    # 她这里只判 errcode / errmsg（成功 return true）
    return ctx.ok({'point': st['training']['point']},
                  '★ 加历练分（addTrainingTaskPoint 只看 errcode，成功即 true）')


def _h_refresh_training_task_list(ctx, st):
    tasks = _training_tasks(ctx, st)
    done = st['training'].setdefault('done', {})
    return ctx.ok({
        'task_list': tasks,
        'completion_times': len(done),
        'point': _int(st['training'].get('point'), 0),
    }, '★ 刷新历练任务（LimitedTimeExperience:__initTaskInfo 读 id/state/name/desc/score）')


def _h_get_training_task_reward(ctx, st):
    """★ 2026-10-03 重写（客户报「限时历练领的和显示的不一致」）。原实现：
      显示在 activities._training_info（奖励池 = 活动目录 30+i*2 段），
      领取却在这里发**另一张目录**的 140+rid 段、还不理会客户端传上来的 giftId
      ⇒ 领到的和面板展示的毫无关系。
      现在：按 rid 从**同一份池子**（activities._goods_n(30+(rid-1)*2, 2)）取货，
      `reward.id` 给**真物品 id**（客户端 `LimitedTimeExperience` 回调
      `addItemCount(v.id, v.num)`），已领标记与任务完成标记分家（reward_got）。
    """
    rid = ctx.int_param('rid', 0)
    if not rid:
        return ctx.fail('奖励参数错误', '★ get_training_task_reward 缺 rid')
    if str(rid) in st['training'].setdefault('reward_got', {}):
        return ctx.fail('该奖励已领取', '★ 业务门：已领')
    st['training']['reward_got'][str(rid)] = 1
    _save(ctx, st)
    import fz_api.activities as _act
    pool = _act._goods_n(ctx, 30 + (max(1, rid) - 1) * 2, 2)
    # ★ 2026-10-03 二轮审计：LimitedTimeExperience.lua:250 走 **A1 fromNetworkGrantGoods**
    #   （按商品键查表换算入包），v10 发真物品 id 反而查无 ⇒ 改回商品键。
    reward = [{'id': g['id'], 'num': 1, 'name': g['name'], 'number': 1,
               'type': 1, 'icon': g['icon']} for g in pool]
    return ctx.ok({'reward': reward, 'msg': '',
                   'dataVer': _int(ctx.param('dataVer'), 0),
                   'currencyVersion': _int(ctx.param('currencyVersion'), 0)},
                  '★ 领历练档位奖励（档 %d：%s，A1 商品键）'
                  % (rid, '、'.join(g['name'] for g in pool)))


def _h_get_wumen_trial_info(ctx, st):
    """KungFuTrails:__dealWithInfo 读 taskId/taskText/taskTypeId/taskReward/rewardText/
    taskState/taskTypeName。"""
    got = st['wumen'].setdefault('got', {})
    lst = []
    for i in range(1, 9):
        g = _g(150 + i)
        lst.append({'taskId': i, 'taskText': '武门试炼·第%d关' % i,
                    'taskTypeId': 1 if i <= 4 else 2,
                    'taskTypeName': '初试' if i <= 4 else '复试',
                    'taskReward': [_rw(g, 1)], 'rewardText': '%sX1' % g['name'],
                    'taskState': 2 if str(i) in got else (1 if i <= 2 else 0)})
    return ctx.ok({
        'act_name': '武门试炼', 'detail_desc': ['逐关挑战武门前辈，通关可领奖励。', '每关限领一次。'],
        'detail_time': '%s ~ %s' % (_fmt(_now()), _fmt(FAR_FUTURE)),
        'list': lst, 'end_time': FAR_FUTURE,
    }, '★ 武门试炼面板（KungFuTrails:__dealWithInfo 逐字段）')


def _h_get_wumen_trial_reward(ctx, st):
    rid = ctx.int_param('id', 0) or _arg_int(ctx, 0, 'id', 0)
    if not rid:
        return ctx.fail('奖励参数错误', '★ get_wumen_trial_reward 缺 id')
    if str(rid) in st['wumen'].setdefault('got', {}):
        return ctx.fail('该奖励已领取', '★ 业务门：已领')
    st['wumen']['got'][str(rid)] = 1
    _save(ctx, st)
    return ctx.ok({'rewards': [_gr(g, 1) for g in _gn(150 + rid, 2)], 'msg': '',
                   'dataVer': _int(ctx.param('dataVer'), 0),
                   'yashi_expired_time': 0},
                  '★ 领武门试炼奖励（A2 直发，真物品 id）')


def _h_get_smithy_info(ctx, st):
    """SmithyAction:__initShowRewardList + detail_time + quench_count。"""
    got = st['smithy'].setdefault('got', {})
    lst = []
    for i in range(1, 9):
        g = _g(160 + i)
        lst.append({'rid': i, 'state': 2 if str(i) in got else (1 if i <= 2 else 0),
                    'rewards': [_rwx(g, 1, 1)], 'text': '第%d次淬炼' % i})
    return ctx.ok({
        'act_name': '铁匠铺', 'detail_time': '长期开放',
        'detail_desc': ['淬炼武器达到次数即可领取奖励。', '每档限领一次。'],
        'list': lst, 'quench_count': _int(st['smithy'].get('count'), 0),
        'end_time': FAR_FUTURE,
    }, '★ 铁匠铺面板（SmithyAction:__initShowRewardList 读 rid/state/rewards/text）')


def _h_get_smithy_reward(ctx, st):
    rid = ctx.int_param('rid', 0)
    if not rid:
        return ctx.fail('奖励参数错误', '★ get_smithy_reward 缺 rid')
    if str(rid) in st['smithy'].setdefault('got', {}):
        return ctx.fail('该奖励已领取', '★ 业务门：已领')
    st['smithy']['got'][str(rid)] = 1
    _save(ctx, st)
    return ctx.ok({'rewards': [_gr(g, 1) for g in _gn(160 + rid, 2)], 'msg': '',
                   'dataVer': _int(ctx.param('dataVer'), 0)},
                  '★ 领铁匠铺奖励（A2 直发，真物品 id；_gr 自带 itype=1）')


# ===========================================================================
# 4. 幸运商品（江湖好运来）—— 表：others/goodluck.lua Sheet1
# ===========================================================================
def _lucky_rows():
    rows = _rows('others/goodluck.lua')
    return [r for r in rows if r.get('itemid')]


def _luck_goods():
    """JiangHuHaoYunLaiLayer:setItemInfo 读 v.name / v.need / v.icon / v.itemId / tonumber(v.id)。"""
    out = {}
    for i, r in enumerate(_lucky_rows()):
        iid = str(r.get('itemid'))
        g = None
        for c in _cat():
            if c['itemId'] == iid:
                g = c
                break
        out[str(i + 1)] = {
            'id': r.get('id') or (i + 1),
            'name': _strip(r.get('name')) or (g['name'] if g else iid),
            'need': _int(r.get('coin'), 10),
            'icon': (g['icon'] if g else '') or 'Image/UI/StoreUI/itembg01.png',
            'itemId': iid,
            'num': _int(r.get('num'), 1),
            'limit': _int(r.get('limit'), 20),
        }
    return out


def _h_get_lucky_goods(ctx, st):
    d = st['lucky']
    if str(ctx.param('is_refresh', 'N')).upper() == 'Y':
        d['refresh'] = _int(d.get('refresh'), 0) + 1
    goods = d.get('goods')
    if not goods:
        goods = _luck_goods()
    d['goods'] = goods
    _save(ctx, st)
    return ctx.ok({
        'luck_list': goods,
        'luck_goods': goods,
        'yuanbao': 9999,
        'total_point': _int(d.get('total'), 0),
        'exchangeNum': _int(d.get('exchange'), 0),
        'exchangeNumLimit': 100000,
        'refresh_times': _int(d.get('refresh'), 0),
    }, '★ 江湖好运来（表 others/goodluck.lua Sheet1；JiangHuHaoYunLaiLayer:setItemInfo）')


def _h_buy_lucky_goods(ctx, st):
    iid = str(ctx.param('itemId', '') or '')
    rid = ctx.int_param('id', 0)
    goods = st['lucky'].get('goods') or _luck_goods()
    st['lucky']['goods'] = goods
    row = None
    for v in goods.values():
        if str(v.get('itemId')) == iid or (rid and _int(v.get('id')) == rid):
            row = v
            break
    if row is None:
        return ctx.fail('商品不存在', '★ buy_lucky_goods 业务门：itemId 不在好运表里')
    need = _int(row.get('need'), 0)
    if _int(st['lucky'].get('total'), 0) < need:
        return ctx.fail('好运通宝不足', '★ buy_lucky_goods 业务门：好运通宝 < need')
    st['lucky']['total'] = _int(st['lucky'].get('total'), 0) - need
    _save(ctx, st)
    return ctx.ok({'total_point': st['lucky']['total']},
                  '★ 好运兑换（buyLuckyGoods 只看 errcode，成功后本地发货刷新）')


def _h_exchange_lucky_point(ctx, st):
    """HaoYunDuiHuanLayer 读 get_point / upper(bool) / total_point / exchangeNum。"""
    iid = str(ctx.param('itemId', '') or '')
    row = None
    for r in _lucky_rows():
        if str(r.get('itemid')) == iid:
            row = r
            break
    if row is None:
        return ctx.fail('该物品不能兑换', '★ exchange_lucky_point 业务门：itemId 不在好运表里')
    coin = _int(row.get('coin'), 0)
    d = st['lucky']
    cur = _int(d.get('total'), 0)
    limit = 100000
    upper = False
    get_point = coin
    if cur + coin > limit:
        get_point = max(0, limit - cur)
        upper = True
    d['total'] = cur + get_point
    d['exchange'] = _int(d.get('exchange'), 0) + get_point
    _save(ctx, st)
    return ctx.ok({'get_point': get_point, 'upper': upper,
                   'total_point': d['total'],
                   'exchangeNum': d['exchange']},
                  '★ 好运通宝兑换（她读 get_point/upper(bool!)/total_point/exchangeNum）')


# ===========================================================================
# 5. 节日：周年 / 七夕 / 端午 / 年兽 / 彩蛋
# ===========================================================================
def _h_get_anniversary_login_list(ctx, st):
    """AnniversaryLoginReward: 读 act_name/detail_desc/start_time/yuanbao_data{num,state,rid}/
    list:[{state,rid,day,rewards:[{name,num}]}]。"""
    got = st['anniv'].setdefault('login_got', {})
    lst = []
    for i in range(1, 8):
        g = _g(170 + i)
        lst.append({'state': 2 if str(i) in got else (1 if i <= 2 else 0),
                    'rid': i, 'day': i,
                    'rewards': [{'name': g['name'], 'num': 1, 'id': g['id'],
                                 'itemId': g['itemId'], 'number': 1}]})
    return ctx.ok({
        'act_name': '周年庆·登录有礼',
        'detail_desc': ['周年庆期间每日登录可领取一份礼物。', '累计登录七天可领全部奖励。'],
        'start_time': _fmt(_now() - 86400),
        'yuanbao_data': {'num': 100, 'state': 2 if str(0) in got else 0, 'rid': 0},
        'list': lst, 'end_time': FAR_FUTURE,
    }, '★ 周年登录面板（AnniversaryLoginReward:__dealWithRewardInfo 读 state/rid/day/rewards）')


def _h_get_anniversary_login_reward(ctx, st):
    rid = ctx.int_param('rid', 0)
    if not rid:
        return ctx.fail('奖励参数错误', '★ get_anniversary_login_reward 缺 rid')
    if str(rid) in st['anniv'].setdefault('login_got', {}):
        return ctx.fail('该奖励已领取', '★ 业务门：已领')
    st['anniv']['login_got'][str(rid)] = 1
    _save(ctx, st)
    g = _g(170 + _int(rid, 1))
    return ctx.ok({
        'reward': [_gr(g, 1)],
        'msg': '', 'dataVer': _int(ctx.param('dataVer'), 0),
    }, '★ 领周年登录奖（A2 直发，真物品 id）')


def _anniv_list(ctx, st):
    """ZhouNianQingChongZhiLayer:setViewList 读 date / is_received(0无/1可领/2已领) /
    reward:[{itemId,number}]。"""
    got = st['anniv'].setdefault('got', {})
    out = []
    for i in range(1, 16):
        g = _g(180 + i)
        date = _day() - (15 - i)
        out.append({'date': date,
                    'is_received': 2 if str(date) in got else (1 if i <= 2 else 0),
                    'reward': [{'itemId': g['itemId'], 'id': g['id'], 'number': 1,
                                'num': 1, 'name': g['name'], 'type': 1}]})
    return out


def _h_get_anniversary_reward_list(ctx, st):
    return ctx.ok(_anniv_list(ctx, st),
                  '★ 周年每日充值奖励列表（setViewList 用 pairs 读 date/is_received/reward）')


def _h_get_anniversary_reward(ctx, st):
    """她 `self:getAnniversaryReward({v.date}, cb)` 后读 `data[tostring(v.date)]`（0=成功）。"""
    dates = []
    body = ctx.body_obj if isinstance(ctx.body_obj, dict) else {}
    lst = body.get('list')
    if isinstance(lst, list):
        dates = [_int(x) for x in lst]
    elif isinstance(lst, dict):
        dates = [_int(x) for x in lst.values()]
    if not dates:
        dates = [_day()]
    got = st['anniv'].setdefault('got', {})
    out = {}
    for d in dates:
        out[str(d)] = 0
        got[str(d)] = 1
    _save(ctx, st)
    return ctx.ok(out, '★ 领周年每日充值奖励（她读 data[tostring(date)]：0 成功 / 非 0 失败）')


def _h_get_qixi_task_info(ctx, st):
    """QiXiLoveLetterLayer 读 day_times/day_limit/finish_days/full_days/state。"""
    d = st['qixi']
    return ctx.ok({
        'day_times': _int(d.get('day'), 0), 'day_limit': 3,
        'finish_days': _int(d.get('finish'), 0), 'full_days': 7,
        'state': _int(d.get('state'), 0),
        'detail_desc': ['每日可接取三次七夕情书任务。', '连续完成七天可领全勤奖。'],
    }, '★ 七夕任务面板（setButton3 读 data1.state；正文 read day_times/day_limit/finish_days/full_days）')


def _h_take_qixi_task(ctx, st):
    d = st['qixi']
    if _int(d.get('day'), 0) >= 3:
        return ctx.fail('今日七夕任务次数已用完', '★ take_qixi_task 业务门：每日 3 次')
    d['day'] = _int(d.get('day'), 0) + 1
    d['state'] = 1
    _save(ctx, st)
    return ctx.ok({'state': 1}, '★ 接取七夕任务（TakeQiXiTask 只看 errcode，成功即进副本）')


def _h_finish_qixi_task(ctx, st):
    """QiXiFestival: 读 data.times（任务用时）+ data.currency{attr:{value,count,desc}}。"""
    d = st['qixi']
    times = max(1, ctx.int_param('times', 60))
    d['finish'] = _int(d.get('finish'), 0) + 1
    _save(ctx, st)
    g = _g(200 + d['finish'])
    return ctx.ok({
        'times': times,
        'currency': {
            'pot': {'value': 4000, 'count': 4000, 'desc': '获得潜能 4000'},
            'exp': {'value': 6000, 'count': 6000, 'desc': '获得经验 6000'},
            'yuanbao': {'value': 0, 'count': 0, 'desc': g['name']},
        },
        'rewards': [_rwx(g, 1, 1)],
    }, '★ 提交七夕任务（她读 data.times 后按 >300/>20 分档；data.currency 是 map of 对象）')


def _qixi_pages(ctx, st):
    """QiXiRankLayer:initRankingAllPage 用 ipairs ⇒ data 是**数组**；
    createListView 读 data.type / data.body.list / data.body.jiangli / data.body.my_score /
    data.body.is_get。"""
    menpai = _sect('others/dragonBoat.lua', '门派信息')
    got = st['qixi'].setdefault('got', {})
    pages = []
    for t in (1, 2):
        rows = []
        for i, (k, v) in enumerate(list(menpai.items())[:10]):
            rows.append({
                'sort': i + 1, 'grade': '壹贰叁肆伍陆柒捌玖拾'[i] if i < 10 else str(i + 1),
                'userid': 900000000 + i, 'portrait': 1, 'title_type': 0, 'title_id': '',
                'name': _strip(v.get('name')) or _strip(v.get('noname')) or '侠客',
                'score': max(1, 100 - i * 7), 'menpai': _strip(v.get('noname')) or '',
                'yueka': 'NO', 'head': 1, 'daily_point': max(1, 50 - i * 3),
            })
        pages.append({
            'type': t,
            'body': {
                'list': rows,
                'my_score': 0,
                'is_get': 'Y' if '%d' % t in got else 'N',
                'jiangli': {'daoju': {_g(200 + t)['itemId']: 1},
                            'shuxing': {'pot': 1000}},
            },
        })
    return pages


def _h_get_qixi_board(ctx, st):
    return ctx.ok(_qixi_pages(ctx, st),
                  '★ 七夕排行榜（顶层必须是数组：initRankingAllPage 用 ipairs）')


def _h_get_qixi_reward(ctx, st):
    """getQiXiRankBoatReward: data1 是 itemId→num 的 map，随后 she 读/写 data.body.is_get。"""
    t = ctx.int_param('type', 1) or 1
    trans = ctx.param('trans_id', '')
    if not trans:
        return ctx.fail('缺少流水号', '★ get_qixi_reward 缺 trans_id（她由 TransCheck 取）')
    st['qixi'].setdefault('got', {})[str(t)] = 1
    _save(ctx, st)
    g = _g(200 + t)
    pages = _qixi_pages(ctx, st)
    page = pages[0] if t == 1 else pages[1]
    out = dict(page)
    out[g['itemId']] = 1
    return ctx.ok(out, '★ 领七夕排行奖（她 pairs 读 itemId→num，并回写 data.body.is_get）')


# —— 端午 / 龙舟（表 others/dragonBoat.lua）——
def _boat_points(ctx, st):
    """FlyKiteLayer:initTable 只读这四个键（她 rewardList 的 num_id）。"""
    menpai = _sect('others/dragonBoat.lua', '门派信息')
    total = len(menpai) or 1
    return {
        'today_point': 0, 'total_point': 0, 'rank': total, 'personal_rank': total,
        'yestoday_point': 0, 'ffz_max_point': 0, 'q_point': 0,
    }


def _h_get_all_type_point(ctx, st):
    return ctx.ok(_boat_points(ctx, st),
                  '★ 春分/龙舟积分（FlyKiteLayer:initTable 读 today_point/total_point/rank/personal_rank）')


def _h_personal_boat_msg(ctx, st):
    return ctx.ok(_boat_points(ctx, st),
                  '★ 个人龙舟积分（getPersonalBoatScore → FlyKiteLayer:showBoatLayer → initTable）')


def _h_get_boat_board(ctx, st):
    t = _arg_int(ctx, 0, 'type', 1) or 1
    menpai = _sect('others/dragonBoat.lua', '门派信息')
    boats = _sect('others/dragonBoat.lua', '船只信息')
    got = st['boat'].setdefault('got', {})
    rows = []
    keys = list(menpai.keys())
    for i, k in enumerate(keys[:20]):
        v = menpai[k]
        b = boats.get(str(i + 1)) or {}
        rows.append({
            'sort': i + 1, 'grade': '壹贰叁肆伍陆柒捌玖拾'[i] if i < 10 else str(i + 1),
            'userid': 900000000 + i, 'portrait': 1, 'title_type': 0, 'title_id': '',
            'name': _strip(v.get('name')) or _strip(v.get('noname')) or '侠客',
            'score': _int(b.get('far'), 1000 - i * 10), 'menpai': _strip(v.get('noname')) or '',
            'yueka': 'NO', 'head': 1,
        })
    jiangli = {'daoju': {_g(210 + t)['itemId']: 1}, 'shuxing': {'pot': 1000},
               'currency': {'yuanbao': 100}}
    return ctx.ok({
        'body': {'list': rows, 'is_get': 'Y' if str(t) in got else 'N',
                 'jiangli': jiangli, 'my_score': 0},
        'type': t,
    }, '★ 龙舟榜（FlyKiteRankListLayer:initUI 读 body.list[].sort/grade/name/score/menpai/'
       'yueka/portrait/title_type/title_id + body.is_get；BoatPersonalRankingLayer 读 body.jiangli）')


def _h_get_boat_reward(ctx, st):
    """BoatPersonalRankingLayer / FlyKiteRankListLayer 读 data.daoju / data.shuxing / data.currency。"""
    t = ctx.int_param('itype', 1) or 1
    trans = ctx.param('trans_id', '')
    if not trans:
        return ctx.fail('缺少流水号', '★ get_boat_reward 缺 trans_id')
    if str(t) in st['boat'].setdefault('got', {}):
        return ctx.fail('奖励已领取', '★ get_boat_reward 业务门：已领')
    st['boat']['got'][str(t)] = 1
    _save(ctx, st)
    g = _g(210 + t)
    return ctx.ok({'daoju': {g['itemId']: 1}, 'shuxing': {'pot': 1000},
                   'currency': {'yuanbao': 100},
                   'msg': ''},
                  '★ 领龙舟排行奖（她 pairs 读 daoju/shuxing/currency 三个 map）')


def _h_get_duanwu_reward_notice(ctx, st):
    """FlyKiteRankListLayer:previeReward 读 content（"?" 换行）/ jiangli / is_get。"""
    t = _arg_int(ctx, 0, 'type', 1) or 1
    menpai = _sect('others/dragonBoat.lua', '门派信息')
    g = _g(211 + t)
    content = ('NOR龙舟大赛奖励预览?' +
               'HIG门派积分第1名NOR：%s X1、潜能 1000?' % g['name'] +
               'HIG门派积分第2-3名NOR：潜能 800?' +
               'HIG门派积分第4-10名NOR：潜能 500?' +
               'HIG个人积分前10名NOR：%s X1?' % _g(213 + t)['name'] +
               '参赛门派共 %d 个，奖励于活动结束后统一发放。' % (len(menpai) or 1))
    return ctx.ok({
        'content': content,
        'jiangli': {'daoju': {g['itemId']: 1}, 'shuxing': {'pot': 1000}},
        'is_get': 'Y' if str(t) in st['boat'].setdefault('got', {}) else 'N',
    }, '★ 端午奖励预览（她读 content/jiangli/is_get；jiangli 里 daoju 是 itemId→数量）')


# —— 年兽（NianBeast）——
def _nian_state(ctx):
    """年兽统一状态（2026-10-03 前**两个模块各存一份**：面板读 activities_state、
    驱赶扣 action_festival_state ⇒ 鞭炮数两边对不上；现在统一用 activities_state）。"""
    import fz_api.activities as _act
    st = ctx.load_json(_act.STATE, {})
    if not isinstance(st, dict):
        st = {}
    d = st.setdefault('nian', {'count': 6, 'bianpao': 8, 'state': {}, 'drive': 0,
                               'claimed': {}})
    for k, v in (('count', 6), ('bianpao', 8)):
        d.setdefault(k, v)
    return _act, st, d


def _h_expel_nian(ctx, st):
    """expelNian 读 data.bianpao / data.rewards / data.dataVer / data.currencyVersion / data.msg。

    ★ 2026-10-03：进度 `count` 原来全服务端没人 +1（档位永远解锁不了），现在每驱赶
      一次 +1；状态统一写 activities_state（面板 `_nian_info` 读的就是它）。
      发货 rewards 改 `_grant` 版（真物品 id，客户端 NianBeast.lua:186 addItemCount）。
    """
    n = max(1, ctx.int_param('times', 1))
    _act, ast, d = _nian_state(ctx)
    d['bianpao'] = max(0, _int(d.get('bianpao'), 0) - n)
    if d['bianpao'] <= 0:
        d['bianpao'] = 5
    d['count'] = _int(d.get('count'), 0) + n
    d['drive'] = _int(d.get('drive'), 0) + n
    ctx.save_json(_act.STATE, ast)
    import fz_api.activities as _ac
    # ★ 二轮审计：NianBeast.lua:180 走 A1 fromNetworkGrantGoods ⇒ 发商品键
    rewards = [_rw(g, 1) for g in
               _ac._goods_n(ctx, 30 + (d['count'] % 4) * 3, 2)]
    return ctx.ok({'bianpao': d['bianpao'], 'rewards': rewards, 'msg': '',
                   'dataVer': _int(ctx.param('dataVer'), 0),
                   'currencyVersion': _int(ctx.param('currencyVersion'), 0)},
                  '★ 驱赶年兽 ×%d（进度 %d，鞭炮余 %d）'
                  % (n, d['count'], d['bianpao']))


def _h_get_expel_reward(ctx, st):
    rid = ctx.int_param('rid', 0)
    gift = ctx.int_param('giftId', 1) or 1
    if not rid:
        return ctx.fail('奖励参数错误', '★ get_expel_reward 缺 rid')
    _act, ast, d = _nian_state(ctx)
    key = '%s_%s' % (rid, gift)
    if key in d.setdefault('claimed', {}):
        return ctx.fail('该奖励已领取', '★ 业务门：已领')
    d['claimed'][key] = 1
    ctx.save_json(_act.STATE, ast)
    # 发的就是面板 gifts_list 对应组合里的货（真物品 id）。
    # ★ `_gift_pool` 里是**显示条目**（只有商品键 id/num），要回活动目录取全量资料
    #   （itemId/name/icon）再交给 `_gr` 发真物品 id。
    import fz_api.activities as _ac
    pool = _ac._gift_pool(ctx, 30)
    picked = []
    for gid in (_ac._reward_rows(ctx, 30, 6, count=d.get('count'),
                                 claimed=d.get('claimed') or {})[rid - 1]['gift_ids']
                if rid <= 6 else [gift]):
        picked.extend(pool.get(str(gid)) or [])
    if not picked:
        picked = pool.get(str(gift)) or []
    # ★ 二轮审计：NianBeast.lua:199 走 A1 fromNetworkGrantGoods ⇒ 发商品键
    return ctx.ok({'rewards': [dict(e) for e in picked], 'msg': '',
                   'dataVer': _int(ctx.param('dataVer'), 0),
                   'currencyVersion': _int(ctx.param('currencyVersion'), 0)},
                  '★ 领年兽奖励（档 %d，A1 商品键 %d 件）' % (rid, len(picked)))


# —— 五绝彩蛋（WuJueChallenge）——
def _h_get_egg_challenge_info(ctx, st):
    d = st['egg']
    return ctx.ok({
        'endTime': FAR_FUTURE,
        'npcChallengeAllCountList': d.get('counts') or {},
        'number': _int(d.get('number'), 0),
        'dayChallengeTimes': _int(d.get('number'), 0),
    }, '★ 五绝彩蛋信息（WuJueChallenge:getEggChallengeInfo 读 endTime/npcChallengeAllCountList/number）')


def _h_add_egg_challenge_times(ctx, st):
    npc = str(ctx.param('npc_id', '') or '')
    d = st['egg']
    if not npc:
        return ctx.fail('参数错误', '★ add_egg_challenge_times 缺 npc_id')
    counts = d.setdefault('counts', {})
    counts[npc] = _int(counts.get(npc), 0) + 1
    d['number'] = _int(d.get('number'), 0) + 1
    _save(ctx, st)
    return ctx.ok({'npcChallengeAllCountList': counts, 'number': d['number'],
                   'currency_num': 1},
                  '★ 增加彩蛋挑战次数（她读 npcChallengeAllCountList/number/currency_num）')


# ===========================================================================
# 6. 活动日历 / 礼包 / 日常 / 分享 / 月卡 / 资料 / 商城 / 答题 / 支付
# ===========================================================================
def _week_name(wid):
    """周活动中文名：`roleTitle/specialChenHao.lua` 里 basicTitleId 40014~40028 的 text。"""
    tid = WEEK_TITLE.get(str(wid))
    if not tid:
        return str(wid)
    cache = getattr(_week_name, '_c', None)
    if cache is None:
        cache = {}
        for k, v in (_lua('roleTitle/specialChenHao.lua') or {}).items():
            if isinstance(v, dict) and v.get('basicTitleId'):
                cache[_int(v.get('basicTitleId'))] = _strip(v.get('text'))
        _week_name._c = cache
    return cache.get(tid) or str(wid)


def _h_get_activity_calendar(ctx, st):
    """ActivityCalendarLayer:createOneRow 读 name / start_time / end_time / gift / status
    （时间字符串按位置取 "YYYY-MM-DD HH:MM:SS"）。"""
    acts = _lua('others/weekactivity.lua')
    act = acts.get('activity') if isinstance(acts, dict) else None
    now = _now()
    rows = []
    if isinstance(act, dict):
        for k, v in act.items():
            if not isinstance(v, dict):
                continue
            s = _stamp(v.get('startValidTime'), '')
            e = _stamp(v.get('endValidTime'), '')
            if e and e <= s:
                e = s + 7 * 86400
            status = 0
            if s and e:
                if now < s:
                    status = 0
                elif s <= now <= e:
                    status = 1
                else:
                    status = 3
            rows.append({'name': _week_name(v.get('id') or k),
                         'start_time': _fmt(s) if s else _today_str(),
                         'end_time': _fmt(e) if e else _fmt(FAR_FUTURE),
                         'gift': '每日参与可获游字令与称号奖励',
                         'status': status, 'id': v.get('id') or k,
                         'launchId': v.get('launchId')})
        rows.sort(key=lambda r: (r['status'] != 1, r['start_time']))
    return ctx.ok({'point': _int(st['calendar'].get('point'), 0), 'list': rows},
                  '★ 活动日历（表 others/weekactivity.lua activity；名字取 specialChenHao 40014-40028）')


def _h_get_game_activity(ctx, st):
    """ActionLayer:getActionState 读 is_open/status/name/detail_desc/activity_id/start/end。"""
    aid = ctx.args[0] if ctx.args else ctx.param('id', '0')
    lasts = _lua('others/weekactivity.lua')
    act = lasts.get('activity') if isinstance(lasts, dict) else None
    v = act.get(str(aid)) if isinstance(act, dict) else None
    s = _stamp(v.get('startValidTime'), '') if isinstance(v, dict) else 0
    e = _stamp(v.get('endValidTime'), '') if isinstance(v, dict) else 0
    if not s:
        s = _now() - 86400
    if not e or e <= s:
        e = FAR_FUTURE
    name = _week_name(v.get('id')) if isinstance(v, dict) else '活动'
    return ctx.ok({
        'is_open': 1, 'status': 1, 'activity_id': aid,
        'name': name,
        'detail_desc': ['活动期间前往平安小镇寻找活动使者即可参与。',
                        '活动每周一 0 点更新，请注意活动时间。'],
        'start': s, 'end': e, 'extra': '', 'desc': '',
    }, '★ 活动状态（getActionState → ActionLayer 读 is_open/status/name/detail_desc/activity_id）')


# —— 限时礼包 get_limit_package/<itemId>（NewXianShiLayer）——
def _pkg(ctx, item_id):
    """NewXianShiLayer:setItemList 逐键读 price/limit_num/beyond/end_time/list/buy_times/
    special_reward_itemId；她还会对 list 里每项读 itemId/number 并自己补 name。"""
    g = None
    for c in _cat():
        if c['itemId'] == item_id:
            g = c
            break
    if g is None:
        g = _g(230)
    items = [{'itemId': x['itemId'], 'id': x['id'], 'number': 1 + (i % 3),
              'num': 1 + (i % 3), 'name': x['name'], 'icon': x['icon']}
             for i, x in enumerate(_gn(231, 3))]
    items.insert(0, {'itemId': g['itemId'], 'id': g['id'], 'number': 1, 'num': 1,
                     'name': g['name'], 'icon': g['icon']})
    return g, items


def _h_get_limit_package(ctx, st):
    item_id = ctx.args[0] if ctx.args else str(ctx.param('itemId', '') or '')
    if not item_id:
        return ctx.fail('礼包参数错误', '★ get_limit_package 缺 URL 尾段 itemId')
    g, items = _pkg(ctx, item_id)
    bought = _int(st['limitpkg'].setdefault('bought', {}).get(item_id), 0)
    return ctx.ok({
        'price': 688, 'limit_num': 5, 'beyond': 150,
        'end_time': FAR_FUTURE, 'list': items, 'buy_times': bought,
        'surplusTime': FAR_FUTURE, 'surplusCount': max(0, 5 - bought),
        'special_reward_itemId': _g(236)['itemId'],
        'itemId': item_id, 'name': g['name'],
    }, '★ 限时礼包（NewXianShiLayer:setItemList 逐键读；商品 id/itemId/name/icon 来自 activity/shoplist.lua）')


# —— 限时礼包积分 get_xianshilibao_gift_list_2（XianShiPointLayer:updateUI）——
def _h_get_xianshilibao_gift_list_2(ctx, st):
    """她硬编码读 itemList[1..4].item_id / .points。"""
    lst = [{'item_id': _g(240 + i)['itemId'], 'points': p, 'id': _g(240 + i)['id'],
            'name': _g(240 + i)['name']}
           for i, p in enumerate([2, 3, 5, 10])]
    return ctx.ok({'total': _int(st['calendar'].get('point'), 0), 'list': lst},
                  '★ 限时礼包积分兑换（XianShiPointLayer:updateUI 读 list[1..4].item_id/.points + total）')


# —— 每天奖励（SuiMoJiFuLayer）——
def _newdaily_body(ctx, st):
    got = st['newdaily'].setdefault('got', {})
    times = {}
    for i in range(1, 9):
        times[str(i)] = {'istrd': 2 if (i == 1 and str(1) in got) else (2 if str(i) in got else (1 if i == 1 else 0))}
    base = {}
    for k in range(1, 9):
        rows = []
        for j in range(3):
            g = _g(250 + k + j)
            rows.append({'itemId': g['itemId'], 'id': g['id'], 'name': g['name'],
                         'number': 1, 'num': 1, 'imagePath': g['icon'],
                         'showType': 1, 'nameDes': ''})
        base['goods_%d' % k] = rows
    return {
        'config': {'base': base, 'strategy_id': 1},
        'times': times,
        'shopping_money': _int(st['total_spend'].get('spent'), 0),
        'list': [{'rid': i, 'state': times[str(i)]['istrd'],
                  'rewards': base['goods_%d' % i]} for i in range(1, 9)],
    }


def _h_get_newdaily_lists(ctx, st):
    return ctx.ok(_newdaily_body(ctx, st),
                  '★ 每日充值奖励（SuiMoJiFuLayer:getCurrRewardList 读 config.base.goods_N；'
                  'setRewardButton 读 times["N"].istrd）')


def _h_get_newdaily_award(ctx, st):
    t = ctx.int_param('type', 0) or 0
    if not t:
        return ctx.fail('奖励参数错误', '★ get_newdaily_award 缺 type')
    if str(t) in st['newdaily'].setdefault('got', {}):
        return ctx.fail('该奖励已领取', '★ 业务门：已领')
    st['newdaily']['got'][str(t)] = 1
    _save(ctx, st)
    g = _g(250 + _int(t, 1))
    # SuiMoJiFuLayer:receiveNewDailyReward 都走 getReward(currRewardList)，data 本身不读字段
    return ctx.ok({'reward': [_rwx(g, 1, 1)], 'list': _newdaily_body(ctx, st)['config']['base'].get('goods_%d' % _int(t, 1), [])},
                  '★ 领每日充值奖励（她只看 errcode，成功后本地按 config.base.goods_N 发货）')


def _h_get_share_link(ctx, st):
    host = ctx.headers.get('host') or '127.0.0.1:7900'
    uid = ctx.headers.get('userid') or '0'
    return ctx.ok({'url': 'http://%s/share/%s' % (host, uid)},
                  '★ 分享链接（ZhangDanLayer:chaKan/shareLink 只读 data.url）')


def _h_do_share(ctx, st):
    st['share']['times'] = _int(st['share'].get('times'), 0) + 1
    _save(ctx, st)
    # 她 DEBUG 分支自己写的就是 {items = {xiyanshui = 1}}（HttpManager.lua:doShare）
    return ctx.ok({'items': {'xiyanshui': 1}, 'msg': ''},
                  '★ 分享奖励（ZhangDanLayer 读 data.items；取值照她 HttpManager:doShare 的 DEBUG 分支）')


def _h_get_yueka_times(ctx, st):
    """ChongZhiJiaSongLayer 读 data.num 与 data.ctime（ctime 当活动结束时间戳用）。"""
    return ctx.ok({'num': _int(st['yueka'].get('num'), 0),
                   'ctime': FAR_FUTURE,
                   'days': _int(st['yueka'].get('days'), 0)},
                  '★ 江湖名士加送（她读 num + ctime；ctime 必须是未来秒，否则领不了）')


def _h_give_yueka_days(ctx, st):
    st['yueka']['days'] = _int(st['yueka'].get('days'), 0) + 30
    _save(ctx, st)
    return ctx.ok({'days': st['yueka']['days']},
                  '★ 领取月卡加送（getActionAward 只看 errcode/errmsg）')


# —— 用户资料 ——
def _role_archive():
    cache = getattr(_role_archive, '_c', None)
    if cache is not None:
        return cache
    import json
    val = {}
    for rel in ('roles/full.json', 'role_store/dev1.json'):
        try:
            with open(os.path.join(HERE, rel.replace('/', os.sep)), encoding='utf-8') as f:
                d = json.load(f)
            if isinstance(d, dict) and d:
                val = d
                break
        except Exception:                                # noqa: BLE001
            continue
    _role_archive._c = val
    return val


def _h_get_user_info(ctx, st):
    """排行榜/资料面板：`RoleInfoLayer:setRoleInfo(data)`，她只硬依赖 `data.equips`。"""
    import copy
    d = copy.deepcopy(_role_archive()) or {}
    uid = ctx.param('userid', ctx.param('userID', ''))
    d.setdefault('equips', {})
    if not isinstance(d.get('equips'), dict):
        d['equips'] = {}
    d['userid'] = _int(uid, d.get('userid') or 900000001)
    d.setdefault('name', '无名侠客')
    d.setdefault('sex', '男')
    d.setdefault('looks', 20)
    d.setdefault('lv', 100)
    d.setdefault('family', {'name': 'youxia', 'level': 3})
    d.setdefault('portrait', {'id': '', 'lv': 1})
    d.setdefault('items', [])
    d.setdefault('borderVer', 1)
    d.setdefault('borderShowList', [])
    d.setdefault('basicTitleData', {'titleList': [], 'titleId': ''})
    d.setdefault('titles', {'extraTitle': []})
    return ctx.ok(d, '★ 玩家资料（RoleInfoLayer:setRoleInfo；整档取自 work/roles/full.json）')


def _h_save_user_info(ctx, st):
    """EntityLotteryLayer/PhysicalLotteryLayer：她读 data 里的键并并回 list.info。"""
    info = {
        'phone': str(ctx.param('phone', '') or ''),
        'address': str(ctx.param('address', '') or ''),
        'name': str(ctx.param('name', '') or ''),
        'qq': str(ctx.param('qq', '') or ''),
        'email': str(ctx.param('email', '') or ''),
    }
    st['upload']['info'] = info
    _save(ctx, st)
    return ctx.ok(info, '★ 保存收货信息（她 for k,v in pairs(data) 并回 list.info）')


def _h_get_user_upload_info(ctx, st):
    """PhysicalLotteryLayer 读 data.count（数字，拼串）与 data.info（false=没填过）。"""
    return ctx.ok({'count': _int(st['upload'].get('count'), 0),
                   'info': st['upload'].get('info') or False},
                  '★ 收货信息状态（她读 count 与 info：info==false 表示未填写）')


# —— 商城（AnniversaryCelebrationConversionLayer / LiQuanLayer）——
SHOP_NAMES = {
    'zhounianqin_jf': ('新春礼券', '新春礼券'),
    'zhounianqin_cz': ('充值积分', '充值积分'),
    'wudaoshop': ('武道值', '武道值'),
}


def _h_get_shop_info(ctx, st):
    """`changeInfoList(goods, typeName)`：goods 是 {分类:{序号:{itemId,dsc,name,itype,price,
    number,gid,is_again,inde,times}}}，typeName 是分类数组；另读 total_points。

    ★★ 2026-10-03 修「充值积分兑换点不开」：客户端 `initTitleList`（:456-460）对
      `typeName` 条目做 `table.sort` 比较 `a.index < b.index` —— 原来没给 `index`
      ⇒ `nil < nil` 抛异常 ⇒ 面板永远打不开。每条补 `index`；商品行补 `score`
      （`:953-960` 读 `item.score` 拼积分文案，缺了显示 "nil积分"）。
    """
    shop_id = str(ctx.param('shop_id', '') or (ctx.args[0] if ctx.args else ''))
    label, unit = SHOP_NAMES.get(shop_id, ('活动商店', '积分'))
    groups = {}
    types = []
    cls = ['tuijian', 'wupin', 'attr']
    cls_name = ['推荐', '物品', '属性']
    for ci, key in enumerate(cls):
        rows = {}
        for i in range(1, 7):
            g = _g(260 + ci * 7 + i)
            rows[str(i)] = {
                'itemId': g['itemId'], 'id': g['id'], 'gid': g['id'], 'inde': i,
                'dsc': g['dsc'], 'name': g['name'], 'itype': 1,
                'price': 100 * i, 'score': 100 * i,
                'number': 1, 'is_again': 'Y', 'times': 99,
            }
        groups[key] = rows
        types.append({'id': ci + 1, 'index': ci + 1, 'name': cls_name[ci], 'key': key})
    return ctx.ok({
        'shop_info': {'goods': groups, 'typeName': types,
                      'name': label, 'unit': unit, 'shop_id': shop_id},
        'total_points': _int(st['calendar'].get('point'), 0),
    }, '★ 活动商店（AnniversaryCelebrationConversionLayer:changeInfoList/setTotalScore + LiQuanLayer）')


# —— 答题（QuestionAndAnswer）——
def _h_get_answer_status(ctx, st):
    """她读 data.status（0 开始 / 1 通关 / 2 失败）与 tonumber(data.pass_num)。"""
    d = st['answer']
    return ctx.ok({'status': _int(d.get('status'), 0), 'pass_num': _int(d.get('pass'), 0)},
                  '★ 答题状态（QuestionAndAnswer:getAnswerStatus 读 status/pass_num）')


def _h_set_answer_status(ctx, st):
    """她读 data.num（七夕礼券加成，>0 才 PopText）。"""
    t = ctx.int_param('type', 0)
    n = ctx.int_param('pass_num', 0)
    d = st['answer']
    if t == 1:
        d['status'] = 1
        d['pass'] = max(_int(d.get('pass'), 0), n)
    elif t == 2:
        d['status'] = 2
        d['pass'] = 0
    else:
        d['status'] = 0
    _save(ctx, st)
    return ctx.ok({'num': 0, 'status': d['status'], 'pass_num': d['pass'],
                   'msg': ''},
                  '★ 设置答题状态（她读 data.num；type 2 时按 score 分支发奖）')


# —— 支付签名 / 香囊秘格兑换（她的动作接口）——
def _h_check_pay_sign(ctx, st):
    """`check_pay_sign` —— ★ **必须回 errcode != 0**，否则客户端会死锁。

    ★★ 老板 2026-09-28 报「点击充值之后无法返回了」。根因就是这里原来回 `errcode=0`：

      `CommercialTime:buyPrivilege`（以及 `YaShiLayer:getShenQingFunc` /
      `YueKaLayer` 等同族）的逻辑是：

        HttpManagerEx:checkPaySign(key, function(status, errcode, ...)
            if status == 200 then
                if errcode == 0 then
                    dialog:show("正在充值,请稍后")
                    dialog:setBack(false)      -- ★ 不可取消、点背板也不关
                    dialog:setButton1()        -- 无按钮
                    dialog:setButton2()
                    SdkMethod:IosPurchase_SetCallback(...)   -- 等 IAP 回调
                    SdkMethod:IosPurchase_BuyItem(...)       -- 真去拉起支付

      单机私服**没有支付渠道** ⇒ IAP 回调永远不来 ⇒ 那个不可取消的框**永久卡住**，
      玩家只能杀进程。

      `errcode != 0` 时客户端走 else 分支：`PopText(errmsg)`，**能正常返回**。
      ⇒ 单机环境下"充值类功能不可用"是可接受的，但"把玩家卡死"不可接受。

    代价：依赖 `checkPaySign` 付费成功的功能（观影堂特权、雅士、月卡）会提示不可用。
    这是**有意为之**：宁可明确提示，也不能把客户端卡住。
    """
    key = str(ctx.param('key', '') or '')
    if not key:
        return ctx.fail('缺少商品 key', '★ check_pay_sign 缺 key（HttpManager 里 key==nil 直接 return）')
    st['pay_sign']['times'] = _int(st['pay_sign'].get('times'), 0) + 1
    _save(ctx, st)
    # ★ 绝不回 errcode=0（见 docstring：那会让客户端弹不可取消的"正在充值"框并死等 IAP 回调）
    return ctx.fail('单机服务器未开通充值渠道',
                    '★ check_pay_sign：key=%s 已记录（第 %d 次），按设计回 errcode=1 避免客户端死锁'
                    % (key, st['pay_sign']['times']))


def _h_exchange_award_to_sachet_new(ctx, st):
    """XiangNangMiGe: 读 rewards / dataVer / yashi_expired_time / currencyVersion / msg。"""
    rid = ctx.int_param('reward_id', 0)
    if not rid:
        return ctx.fail('奖励参数错误', '★ exchange_award_to_sachet_new 缺 reward_id')
    key = str(rid)
    if key in st['sachet'].setdefault('got', {}):
        return ctx.fail('该奖励已兑换', '★ 业务门：已兑换')
    st['sachet']['got'][key] = 1
    _save(ctx, st)
    return ctx.ok({
        'rewards': _ratio_rewards(270 + rid, 2),
        'dataVer': _int(ctx.param('dataVer'), 0),
        'currencyVersion': _int(ctx.param('currencyVersion'), 0),
        'yashi_expired_time': 0, 'msg': '',
    }, '★ 香囊秘格兑换（她读 rewards:[{id,num}] + dataVer/currencyVersion/yashi_expired_time/msg）')


# ---------------------------------------------------------------------------
# 路由
# ---------------------------------------------------------------------------
_H = {
    'get_login_reward_list': _h_get_login_reward_list,
    'get_login_reward': _h_get_login_reward,
    'get_login_yuandan_info': _h_get_login_yuandan_info,
    'set_login_yuandan_reward': _h_set_login_yuandan_reward,
    'get_spring_new_reward': _h_get_spring_new_reward,
    'receive_spring_new_reward': _h_receive_spring_new_reward,
    'get_lottery_list': _h_get_lottery_list,
    'do_lottery': _h_do_lottery,
    'get_yuanbao_lottery_list': _h_get_yuanbao_lottery_list,
    'do_yuanbao_lottery': _h_do_yuanbao_lottery,
    'do_mingren_lottery': _h_do_mingren_lottery,
    'bfmingtie_exchange_spcl': _h_bfmingtie_exchange_spcl,
    'get_diy_goods': _h_get_diy_goods,
    'get_diy_infos': _h_get_diy_infos,
    'buy_diy_goods': _h_buy_diy_goods,
    'get_luck_box_good': _h_get_luck_box_good,
    'buy_luck_box_good': _h_buy_luck_box_good,
    'get_voucher_prize_2': _h_get_voucher_prize_2,
    'get_spend_reward_list': _h_get_spend_reward_list,
    'get_spend_reward': _h_get_spend_reward,
    'buy_spend_reward': _h_buy_spend_reward,
    'get_total_spend_detail': _h_get_total_spend_detail,
    'get_total_spend_award': _h_get_total_spend_award,
    'get_yuanbao_plan_gift_list': _h_get_yuanbao_plan_gift_list,
    'receive_yuanbao_plan_gift': _h_receive_yuanbao_plan_gift,
    'get_yuanbao_consumption_info': _h_get_yuanbao_consumption_info,
    'get_yuanbao_consumption_reward': _h_get_yuanbao_consumption_reward,
    'get_zhaocaijinbao_info': _h_get_zhaocaijinbao_info,
    'get_zhaocaijinbao_reward': _h_get_zhaocaijinbao_reward,
    'get_waking_dream_info': _h_get_waking_dream_info,
    'get_waking_dream_reward': _h_get_waking_dream_reward,
    'unlock_waking_dream_pay_reward': _h_unlock_waking_dream_pay_reward,
    'get_practice_skill_reward_list': _h_get_practice_skill_reward_list,
    'get_practice_skill_reward': _h_get_practice_skill_reward,
    'unlock_practice_skill_reward': _h_unlock_practice_skill_reward,
    'add_training_task_point': _h_add_training_task_point,
    'refresh_training_task_list': _h_refresh_training_task_list,
    'get_training_task_reward': _h_get_training_task_reward,
    'get_wumen_trial_info': _h_get_wumen_trial_info,
    'get_wumen_trial_reward': _h_get_wumen_trial_reward,
    'get_smithy_info': _h_get_smithy_info,
    'get_smithy_reward': _h_get_smithy_reward,
    'get_lucky_goods': _h_get_lucky_goods,
    'buy_lucky_goods': _h_buy_lucky_goods,
    'exchange_lucky_point': _h_exchange_lucky_point,
    'get_anniversary_login_list': _h_get_anniversary_login_list,
    'get_anniversary_login_reward': _h_get_anniversary_login_reward,
    'get_anniversary_reward_list': _h_get_anniversary_reward_list,
    'get_anniversary_reward': _h_get_anniversary_reward,
    'get_qixi_task_info': _h_get_qixi_task_info,
    'take_qixi_task': _h_take_qixi_task,
    'finish_qixi_task': _h_finish_qixi_task,
    'get_qixi_board': _h_get_qixi_board,
    'get_qixi_reward': _h_get_qixi_reward,
    'get_all_type_point': _h_get_all_type_point,
    'personal_boat_msg': _h_personal_boat_msg,
    'get_boat_board': _h_get_boat_board,
    'get_boat_reward': _h_get_boat_reward,
    'get_duanwu_reward_notice': _h_get_duanwu_reward_notice,
    'expel_nian': _h_expel_nian,
    'get_expel_reward': _h_get_expel_reward,
    'get_egg_challenge_info': _h_get_egg_challenge_info,
    'add_egg_challenge_times': _h_add_egg_challenge_times,
    'get_activity_calendar': _h_get_activity_calendar,
    'get_game_activity': _h_get_game_activity,
    'get_limit_package': _h_get_limit_package,
    'get_xianshilibao_gift_list_2': _h_get_xianshilibao_gift_list_2,
    'get_newdaily_lists': _h_get_newdaily_lists,
    'get_newdaily_award': _h_get_newdaily_award,
    'get_share_link': _h_get_share_link,
    'do_share': _h_do_share,
    'get_yueka_times': _h_get_yueka_times,
    'give_yueka_days': _h_give_yueka_days,
    'get_user_info': _h_get_user_info,
    'save_user_info': _h_save_user_info,
    'get_user_upload_info': _h_get_user_upload_info,
    'get_shop_info': _h_get_shop_info,
    'get_answer_status': _h_get_answer_status,
    'set_answer_status': _h_set_answer_status,
    'check_pay_sign': _h_check_pay_sign,
    'exchange_award_to_sachet_new': _h_exchange_award_to_sachet_new,
}


def handle(ctx):
    fn = _H.get(ctx.endpoint)
    if fn is None:
        return None
    st = _state(ctx)
    try:
        return fn(ctx, st)
    except Exception as e:                               # noqa: BLE001
        ctx.log('[action_festival] %s 处理失败：%s' % (ctx.endpoint, e))
        return ctx.fail('活动数据异常：%s' % e,
                        '★ action_festival 处理 %s 时异常' % ctx.endpoint)
