# -*- coding: utf-8 -*-
# ================= 离线包路径根（fz_make_offline_bundle.py 自动注入） =================
# 手机上整个服务端就是一个目录，表在哪、状态写哪，全部相对包根算。
# （有的模块原来把绝对路径写死，本身没 import os —— 这里一并补上）
import os
import os as _osp


def _off_find_bundle(_f):
    """从模块所在目录往上找包根（认 fz_boot_server.py）。
    ★ fz_api/*.py 的 __file__ 在 <根>/fz_api/ 下，直接 dirname 会算错一层。"""
    _d = _osp.path.dirname(_osp.path.abspath(_f))
    for _ in range(6):
        if _osp.path.exists(_osp.path.join(_d, 'fz_boot_server.py')):
            return _d
        _u = _osp.path.dirname(_d)
        if _u == _d:
            break
        _d = _u
    return _osp.path.dirname(_osp.path.abspath(_f))


_OFF_BUNDLE = _off_find_bundle(__file__)
_OFF_FZ_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_fz')
_OFF_INK_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_ink')
_OFF_WORK_ROOT = _OFF_BUNDLE
# =====================================================================================
# ★ 2026-10-04 商城空货架修复：客户端资源表解析——PC 开发树优先，设备上自动回退
#   到包内 client_fz 副本（jhserver/client_fz = fangzhi_lua_dec 的同步拷贝）。
def _fz_res(*parts):
    base = os.path.join(_OFF_FZ_ROOT, 'res', 'script')
    if not os.path.isdir(base):
        base = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            '..', 'client_fz', 'res', 'script')
    return os.path.join(base, *parts)

# -*- coding: utf-8 -*-
"""家园「家具 / 房间改造 / 事务 / 悬兵洞藏衣阁」模块 —— 1:1 还原她的接口契约。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
一、每个接口：上行参数 / 下行 `data.字段`（都从她 assets/src 里逐行读出来的）
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

【putin_furniture】`HttpManager:putinFurniture(mid,roomId,furnitureId,extra,localVer)`
  上行 `{mid, fjId, jjId, extra, ver}`
  调用方 `FurnitureModel:palceUserMap`（FurnitureModel.lua:297-345）读：
    data.furn_info  → 对象。喂给 `FurnitureModel:initFurnitureForUserMap(map, data.furn_info)`
    data.furn_info.itype → **数字**。`map:addFurTypeCount(data.furn_info.itype, 1)`
                           → `BaseMap:addFurTypeCount` 里 `math.abs(furType)` ⇒ nil 会崩
    data.ver        → **数字**。写回 `sCk_ver["homeland"]`（下次上行的 ver）

【remove_furniture】`HttpManager:removeFurniture(mid,fid,localVer)`
  上行 `{mid, fid, ver}`
  调用方 `FurnitureModel:pickUpUserMap`（:105-175）/ `FurnitureModule["假人销毁"]`（:1063）
    data.ver → **数字**（同上写回 sCk_ver）

【upload_furniture_extra】`HttpManager:uploadFurnitureExtra(mid,attr)`
  上行 `{mid, attr}`，attr 是**数组**：`{ {fid=家具实例id, attr={...}}, ... }`
  调用方 `SkillXiuLianUtil.lua:314` / `XiangLuModel.lua:518,550` / `XiuLianSystem.lua:1000`
    只判 errcode，**不读 data**

【revamp_room_attr】`HttpManager:revampRoomAttr(fjId,mid,attr)`
  上行 `{fjId, mid, attr}`（attr 是对象，如 `{desc=...}`）
  调用方 `HomelandRoomUtil.lua:590,631`（书房 / 仓库描述）只判 errcode，**不读 data**

【transform_room】`HttpManager:transformRoom(fjId,mid,attr,point,upload)`
  上行 `{fjId, mid, attr, upload, point}`；attr 是**房间模板整行**（含 roomid / roomname /
   upgradecost / furniturelimit …），point 就是 `attr.upgradecost`
  调用方 `RoomUpgradeModel:upgradeRoom`（RoomUpgradeModel.lua:71-126）读：
    data.specialFurn → **数组**（`if data.specialFurn and not MapIsEmpty(...) then for k,furn in pairs(...)`）
                       数组元素 = 家具实例（下面 `map_furniture` 同结构），代码还会给它塞 `furn.fjId = fjId`
    data.remove_point → **数字**。`RichPrint("main","您花费了"..data.remove_point.."银票。")`

【update_home_attr】`HttpManager:updateHomeAttr(mid,fj_update,pr_update,jj_update,cost)`
  上行 `{mid, fj_update, pr_update, jj_update, cost}`
    fj_update:  `roomId  → {isdeleted="Y", up="", down="", ...}`（RoomRemoveModel:59-78）
    pr_update:  `rwId    → {fjId=新房间}`（RoomRemoveModel:110）
    jj_update:  `fid     → {isdeleted="Y"}`（家具 id 去掉 "f_" 前缀，RoomRemoveModel:113-118）
    cost:       `{value=num, unit="yinpiao"}`（TaiQingTaiModel:163-166 也走这个接口）
  调用方 `RoomRemoveModel:removeRoom`（:158-219）/ `TaiQingTaiModel:showTaiQingTai`（:181）
    只判 errcode，**不读 data**

【push_affair】`HttpManager:pushAffair(affairTb)` —— affairTb 就是整个正文
  上行 `{userid, affair_id, affair_val, biz_type, from_id, objId, [expired_time, count]}`
  来源 `HomelandRoomUtil:currRoomCanExtend`（:416-425）/ `AffairFactory`（:27-110）
    affair_id: 1房屋升级 2地税 3仆人发薪 4门客发薪 5求购 6拜访 7闯门 8邀请函 9仆人离开
               10土地回收 11土地转让 12异常离开 13登门拜年 14安闲而游（Affair.lua:79-114）
  调用方只判 errcode，**不读 data**

【process_affair】`HttpManager:processRoomAffair(aid,deal_type,process_type)`
  上行 `{aid, deal_type, process_type}`；deal_type = "read" | "process"
  调用方 `Affair:processEvent`（Affair.lua:221-246）：回调 **只判 errcode**，data 可选

【process_pay_affairs】`HttpManager:processPayAffairs(aids)` —— aids 是**数组**
  调用方 `RoomAffairLayer:initRegisterTextAndButtonComfirm`（:202-235）
    只判 errcode，**不读 data**

【get_affair_list】URL 是 `get_affair_list/<limit>`（HttpManager.lua:2527）
  上行 `{biz_type, mid}`；`ctx.args[0]` = limit
  调用方 `GuanJiaModule["房屋事务"]`（:283-318，biz_type=1，limit=10）→ `RoomAffairLayer:showLayer(data)`
        `HomelandModule:getPostmanAffair`（:880）/ `["信差事务"]`（:210，biz_type=3，limit=5）
    ★ data **必须是数组**：`RoomAffairLayer:initAffairList` 里
      `table.sort(server_data, ...)` + `ipairs`，给对象直接崩
    ★ 每条元素的字段（`Affair:create` → `Affair:init` → `initByConf` 全量读）：
      id(**数字**, `processRoomAffair(self.id,...)`) / affair_id(**数字**,决定文案与类型)
      biz_type(**数字**,`a.biz_type == 1` 比较的是数字) / from_id(**字符串**,
        `affair.from_id == tostring(User:getUserId())`) / affair_val(**对象**) /
      is_read(**数字** 0/1) / is_handle(**数字**) / is_local(**数字**) / create_time(**字符串**,排序比大小)
      另有按 affair_id 分支要的：
        affair_id=2 地税: affair_val.pay_time(数字) / pay_unit("yinpiao"/"yuanbao") / pay_base(数字)
        affair_id=3,4 发薪: affair_val.pay_time / pay_base / pay_unit / rwId / name
        affair_id=5 求购: affair_val.dpId / from_name / number；from_id==自己时还要 state(0/1/2)
        affair_id=12 异常离开: affair_val.number(数字) / unit / name
        affair_id=13 拜年: affair_val.visit_time(数字) / gift_type(数字) / from_name
        affair_id=14 安闲而游: affair_val.rwId / name / rest_time(数字)
        其余(6,7,8,9,10,11): affair_val.from_name / name / jobType / location

【restore_user_map】`HttpManager:restoreUserMap(mid)` 上行 `{mid}`
  调用方 `RoomRenovationLayer:setRestoreButton`（:343-356）只判 errcode，**不读 data**

【upload_map_extra】`HttpManager:uploadMapExtra(mid,attr,point)` 上行 `{mid, attr, point}`
  调用方 `DuiLianLayer:setChangeButton`（:198-219，attr={couplet=对联id}）
        `DamenRenovationLayer:setChangeButton`（:271-291，attr={doorId=大门id}）
    data.remove_point → **数字**。`self._currYinPiao - data.remove_point`

【use_homebw】`HttpManager:useHomeBw(zc_val,prId,mid,bwid)` 上行 `{zc_val,prId,mid,bwid}`
  调用方 `ServantRewardLayer.lua:239-282`（宝物赏赐）读：
    data.defaultZhongCheng → **数字**（`HomelandRoleUtil:updateFidelity`）
    data.trait             → **对象**（`DeblockRoleTrait` 里 `for k,v in pairs(traits) do role[k]=v`）
    data.activity          → **对象**（`for k,v in pairs(data.activity)`，值是数字）

【get_client_data】`HttpManager:getClientData(tb)` 上行 `{type, offset, count}`
  调用方 `FurnitureModule["查看悬兵洞"/"查看藏衣阁"]`（:172,245）
        `NewShenBingLayer:ButtonXuanbing/ButtonCangyi`（:238,272）读：
    data.flag → **数字**（1=新版界面，非 1 走 `XuanBingDongOld:show(data.item)`）
    data.item → `XuanBingDongOld:setRightList` 里 `for k,v in pairs(items)` 读 `v.itemId`/`v.info`
                ⇒ 给**对象**（key=服务器物品id，value=`{itemId, info}`），不是数组

【get_ckitems_list_by_uid】`HttpManager:getCkItemsListByUid(uid,ckname)`
  上行 `{uid, ckname}`（ckname = "xuanbingdong" | "cangyige"）
  调用方 `FurnitureModule["查看悬兵洞"/"查看藏衣阁"]`（:213,293）：
    `XuanBingDong:showLayer(data.list, collectScore)` / `UserArmorItemLayer:showLayer(data.list, ...)`
    data.list → **数组**；`UserEquipItemLayer:initList` 读 `v.total`/`v.itemId`/`v.update_time`

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
二、内容来自她哪张表（**没有一处是我编的**）
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
* `res/script/others/familylist.lua`
    ["家具"]      450 件：`jjId`(真键) `name` `dsc` `itype` `grade` `price` `shouqi`
                  `usepossible` `useName` `usedsc` `shouqitext` `fangzhitext` `takelimit`(可放房间)
    ["普通房间"]  42 条：`roomid`(ptfangjianNNN) `name` `desc` `furniturelimit` `upgradecost`
    ["特殊房屋"]  26 条：`roomid`(tsfangjianNNN) `roomname` `roomtype` `roomdsc` `furniturelimit`
                  `upgradecost` `upgrade1/2` `neizhiitem`(改造后内置家具) `flimit`(家具类型白名单)
    ["特殊房间类型"] `roomtype` 中文 → `tsfangjianNNN`（就是 familytype 里 roomId 的后缀）
    ["对联"]      23 条：`id` `dsc` `cost` `roomdsc` `doordsc`
    ["大门信息"]  31 条：`doorid` `doorname` `doorcost` `doordsc` `doorroomdsc`
* `res/script/map/mapItemAttr/homeland.lua` 484 条：`id`(==jjId) `name` `dsc` `type="家具"`
  （`Item:initOneItem` 的 `itemList["homeland"]`，她客户端就是靠它把 jjId 变成物品的）

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
三、★ `map_furniture(ctx, mid)` —— 接到 `get_user_map` 的 `roomfurniture`
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
她客户端路径：`UserMap:initFurniture(map, mapInfo.roomfurniture)`
            → `FurnitureModel:initFurnitureForUserMap(map, furnitrue)`
            → `FurnitureModel:initFurnitureData(map, furniture)`

`initFurnitureData` **真正读到的**（漏一个就 `error()`，而错在应答回调里会被 xpcall
吞掉 ⇒ **客户端 UI 整体卡死**，不是弹错）：
    furniture.jjId   —— 必须是她表里的**真键**。
                        `Item:getOneItemByKey(jjId)`；为空只 print，
                        但下面 `FurnitureModel:initItemData` 里
                        `if not res_data then assert(false, "家具表中不存在"..id) end` ⇒ **硬崩**
    furniture.fjId   —— 必须非 nil 且**是 maproom 里真存在的 fjId**
                        （`UserMap.lua:214` 若 `map.room[fjId]==nil` ⇒ `error("数据错误, 房间ID…不在副本内")`）
    furniture.fid    —— 拼 `id = "f_" .. furniture.fid`，并 `table.insert(room.roleList, "f_"..fid)`
                        ⇒ 同一房间内 **fid 必须唯一**，否则 `map.roles` 互相覆盖
    furniture.itype  —— 数字（`map:addFurTypeCount(itemInfo.itype,1)` → `math.abs()`）
    furniture.extra  —— 对象（`initChuWuXiang` 读 `item.extra.itemId`；`initRoleItem` 读
                        `item.extra.durable`）⇒ 给 `{}`，别给 nil / 字符串
    furniture.conditionAndResults —— 她那边 `if not furnitrue.conditionAndResults then ... = {}` 会补，
                        但我们照样给 `{}`，省一次判断
    其余字段（name/dsc/itype/iType/grade/shouqi/usepossible/useName/fangzhitext…）她那边
    全部用 `Item:getOneItemByKey(jjId)` + `familylist["家具"][jjId]` 自己覆盖，
    我们多给无害（`Helper:tableCover` 不覆盖已有值）、少给不崩 —— 所以这里**按她表原样给全**。

返回：`roomfurniture` 数组（**数组！**她 `for k,itemInfo in pairs(...)` 也吃对象，但数组更稳）。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
四、状态（**我自己的文件名，绝不和 homeland_person.py / 服务端抢键**）
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`work/homeland_home_state.json`：
    {
      "ver": 3,                        # 版本号（她 sCk_ver["homeland"] 要的数字）
      "homes": {
        "<mid>": {
          "furniture": [ {fid, jjId, fjId, itype, extra, ...} ],   # 已摆放
          "rooms":     { "<fjId>": {roomType, desc, ...} },          # 改造过的房间
          "map_extra": { doorId, couplet },                          # 大门 / 对联
          "affairs":   [ {id, affair_id, biz_type, ...} ],           # 事务
          "special":   [ "<jjId>" ],                                 # 已由房间改造内置的家具
          "homebw":    [ {prId, bwid, zc_val} ]                      # 已赏赐的家园宝物
        }
      }
    }
`homes` 里的键是 mid ⇒ 每个家园各自记账，`map_furniture` 能精确按 mid 取。
"""

import os
import sys
import time

NAME = 'homeland_furniture'
TITLE = '家园·家具/房间改造/事务'
ENDPOINTS = [
    'putin_furniture', 'remove_furniture', 'upload_furniture_extra',
    'revamp_room_attr', 'transform_room', 'update_home_attr',
    'push_affair', 'process_affair', 'process_pay_affairs',
    'get_affair_list', 'restore_user_map', 'upload_map_extra',
    # ★ `use_homebw`（珍宝赏赐）**已让给 `homeland_person`**：
    #   它的语义是"给某个仆人加忠诚度"，账本（`defaultZhongCheng` / 每日次数 /
    #   特性解锁）全在 `homeland_person_state.json`，放在这边只能自己再存一份假账。
    #   原来这里回的是 `{'defaultZhongCheng': 累计增量}`，没有上限、没有日限、
    #   没有 errcode 1/2/3 —— 客户端那三条分支（需拥有珍宝 / 已达上限 / 今日够多）
    #   永远走不到。见 `homeland_person._use_homebw`。
    'get_client_data', 'get_ckitems_list_by_uid',
]

# ★ 自己的状态文件（不带中文值以外的花活，纯 ASCII 结构 + 中文 name 字段）
STATE = 'homeland_home_state.json'

# 资源根（她自己的表）
_RES = _fz_res()
_FAMILYLIST = os.path.join(_RES, 'others', 'familylist.lua')
_HOMELAND_ITEMS = os.path.join(_RES, 'map', 'mapItemAttr', 'homeland.lua')

# 她 `familylist["家具"]` 的 itype → 中文（`FurnitureModel:getItypeCN`，FurnitureModel.lua:448-485）
ITYPE_CN = {
    0: '普通家具', 1: '床', 2: '书案', 3: '药炉', 4: '蒲团', 5: '熔炼炉',
    6: '储物箱', 7: '土地', 8: '背包木人', 9: '副本木人', 10: '永久木人',
    11: '灶台', 12: '门', 13: '饰品箱', 14: '茶案', 15: '井', 16: '饭桌',
    17: '庭院', 18: '锻造炉', 19: '墙壁', 20: '衣柜', 21: '晶台', 22: '书柜',
    23: '香炉', 24: '假人', 25: '梦境香炉', 26: '神功书案', 27: '神功书架',
}

# 装饰用的普通家具（itype=0 共 326 件）—— 给新家园铺一批**真书桌/真挂画**，
# 免得一进屋四面墙。全是 `familylist["家具"]` 里的真键。
_FILLER_JJID = [
    'zhuozi001', 'zhuozi004', 'zhuozi010', 'zihua030', 'zihua031',
    'zhuozi002', 'zhuozi006', 'zhuozi014', 'zihua032', 'zihua033',
]

# 房间内置家居：`特殊房屋.neizhiitem` 已经给了，这里只兜底按 roomType 补
_ROOM_FALLBACK = {
    'tsfangjian011': 'chuang001',      # 卧室
    'tsfangjian009': 'jiaren001',      # 练功房
    'tsfangjian014': 'zhaotai001',     # 厨房
    'tsfangjian013': 'tudi01',         # 田圃
    'tsfangjian015': 'putuan001',      # 调息室
    'tsfangjian018': 'putuan001',      # 闭关室
    'tsfangjian005': 'cangku001',      # 仓库
    'tsfangjian006': 'zhuozi001',      # 书房
    'tsfangjian010': 'shipingxiang001',  # 饰品房
    'tsfangjian012': 'chuang001',      # 客房
}

_PAY_UNIT_CN = {'yinpiao': '银票', 'yuanbao': '元宝'}




def _payload(ctx, data, note):
    """`ctx.ok` 的**数组安全**包装。

    ★ 坑（实测）：`fz_api.Ctx.ok`（`__init__.py:106-108`）里有
        `if 'dataVer' not in data: data = dict(data); data['dataVer'] = ...`
      给 `list` 就直接
        `ValueError: dictionary update sequence element #0 has length 13; 2 is required`
      ⇒ 整个接口 500。而 `get_affair_list` 的 `data` **必须是数组**
      （`RoomAffairLayer:initAffairList` 里 `table.sort(server_data,…)` + `ipairs`）。
      所以数组这里**照抄 `Ctx.ok` 的逻辑**自己做应答（`errcode:0` + 原样数组 + `dataVer`），
      避开那个 `dict()`。服务端 `fz_boot_server.py:140-152` 的 `enc_session` 直接
      `json.dumps(obj)`，数组能正常编码。
      万一 deps 里没有 `enc_session`（单测环境），退回 dict（客户端 `MapIsEmpty` 判空，
      不会崩，只是面板空 —— 总比 500 好）。
    """
    if isinstance(data, list):
        deps = getattr(ctx, 'deps', None) or {}
        enc = deps.get('enc_session')
        ndv = deps.get('next_dataver')
        if callable(enc) and callable(ndv):
            return enc({'errcode': 0, 'data': data, 'rand_t': time.time()}), note
        return ctx.ok({'list': data}, note)
    return ctx.ok(data, note)


# ===========================================================================
# 一、她自己的表
# ===========================================================================
def _lua(path):
    """用 `fz_luatable` 解她的表；任何异常都不让接口挂掉。"""
    try:
        import fz_luatable
        return fz_luatable.load_lua_table(path) or {}
    except Exception:                          # noqa: BLE001
        return {}


def _tables():
    """一次性把用得到的表都读进来（进程内缓存）。"""
    t = _tables.__dict__.get('_c')
    if t:
        return t
    fam = _lua(_FAMILYLIST)
    t = {
        'furniture': fam.get('家具') or {},          # jjId → 家具行
        'normal_room': fam.get('普通房间') or {},     # ptfangjianNNN → 行
        'special_room': fam.get('特殊房屋') or {},    # 数字键 → 行（roomid=tsfangjianNNN）
        'room_kind': fam.get('特殊房间类型') or {},   # 数字键 → {roomtype,admit}
        'duilian': fam.get('对联') or {},
        'door': fam.get('大门信息') or {},
        'item': _lua(_HOMELAND_ITEMS),               # jjId → 物品行（Item:initOneItem 用的那张）
    }
    _tables._c = t
    return t


def furniture_templates():
    """她 `familylist["家具"]` 的全部 450 件（附上 `mapItemAttr/homeland.lua` 的行）。"""
    t = _tables()
    out = []
    for key, row in t['furniture'].items():
        if not isinstance(row, dict):
            continue
        r = dict(row)
        r.setdefault('jjId', r.get('id') or key)
        it = t['item'].get(r['jjId'])
        if isinstance(it, dict):
            for k, v in it.items():              # 物品行只补缺，不覆盖家具行
                r.setdefault(k, v)
        r.setdefault('type', '家具')
        r['iType'] = ITYPE_CN.get(_int(r.get('itype'), 0), '普通家具')
        out.append(r)
    return out


def furniture_by_jjid():
    d = furniture_by_jjid.__dict__.get('_c')
    if d is None:
        d = {}
        for r in furniture_templates():
            d[str(r.get('jjId'))] = r
        # ★ 2026-10-17 v36：神功书案（自创武学入口家具，itype=26）。
        #   她表里没有 itype=26 的家具（官方在服务端目录），这里补一条虚构模板。
        #   ★★ v36d 关键修正：**jjId 必须是客户端物品表里真实存在的家具**——
        #   `FurnitureModel:initFurnitureData` 第一步 `Item:getOneItemByKey(jjId)`
        #   查不到直接 error("数据错误, 家具ID : xxx 不存在") ⇒ 被 xpcall 吞 ⇒
        #   进家园过场（EntryMapLayer"你心有所感…"）**永久卡死**（老板实测）。
        #   改用真实物品 shuan008（黄杨木书案）当 jjId/外观，条目自身的
        #   itype=26 / iType=神功书案 会在她 `tableCover(f_template, furniture)`
        #   时**覆盖**物品行 ⇒ 交互仍走 `FunitureTemplate["神功书案"]`（创作/查看/收起）。
        _sg = dict(d.get('shuan008') or {})
        _sg.update({'jjId': 'shuan008', 'id': 'shuan008',
                    'name': '神功书案', 'itype': 26, 'iType': '神功书案',
                    'takelimit': '', 'buyPrice': 0,
                    'dsc': '一张散发着淡淡灵光的书案，伏案于此，可自创属于自己的神功。',
                    'type': '家具'})
        d['shengongshuan001'] = _sg
        # ★ 2026-10-23 v41b：**锻造炉放宽摆放限制**。
        #   原版 `duanzaolu001` 的 `takelimit=tsfangjian027`（只能放"昭阳轩"），
        #   而昭阳轩是**特殊房间**（要玩家自己花资源建）⇒ 绝大多数玩家家园里根本没有
        #   这间房 ⇒ 永远看不到锻造炉 ⇒ 神兵改名/换颜色/修理/熔兵 全找不到入口
        #   （客户报"找不到换颜色"的真因）。
        #   这里把 takelimit 清空（=任意房间可摆），让它能像普通家具一样摆进家园。
        _dz = d.get('duanzaolu001')
        if isinstance(_dz, dict):
            _dz = dict(_dz)
            _dz['takelimit'] = None      # ★ None ⇒ `_s()` 出空串、`_furn_record` 输出空串；
                                          #   客户端 `if not itemAttr.takelimit` 对空串是**真值**
                                          #   （Lua 空串为 true）⇒ 会去 split 空串后不匹配任何房间！
                                          #   所以必须让它**不出现**在该字段上（见 _furn_record 处理）
            _dz['shouqi'] = 1          # 允许收起，摆错房能挪
            d['duanzaolu001'] = _dz
        furniture_by_jjid._c = d
    return d


def _deco_pool(roomtype):
    """能给这间房摆的**装饰家具**（itype=0 的普通家具）。

    ★ 必须先按房间 `takelimit` + `flimit` 过滤：她 `familylist["家具"]` 里
      `zhuozi001`（书桌）的 takelimit 只有书房/客房那些，**摆不进长廊**；
      而 `zhuozi004`（八仙桌）就含 `ptfangjian001`。所以不能拿一个固定清单硬塞。
    """
    key = 'deco_' + _s(roomtype)
    c = _deco_pool.__dict__.get(key)
    if c is not None:
        return c
    pref, rest = [], []
    # ① 手挑的装饰（书桌 / 挂画 / 翘头案）
    for k in _FILLER_JJID:
        r = furniture_by_jjid().get(k)
        if r is not None and _placeable(roomtype, r):
            pref.append(r)
    # ② 她表里**其余 itype=0 的家具**里挑最像摆设的：
    #     - 优先有 `dsc` 的（陈设/字画/摆件一般都有描述，兵器类 `bingqiNNN` 多半没有）
    #     - 其次按 `price` 降序（贵的更像摆设）、`jjId` 升序保证稳定
    cand = []
    for r in furniture_templates():
        if _int(r.get('itype'), 0) != 0:
            continue
        if not _placeable(roomtype, r):
            continue
        cand.append(r)
    cand.sort(key=lambda r: (0 if _s(r.get('dsc')) else 1,
                             -_int(r.get('price'), 0), _s(r.get('jjId'))))
    # 手挑的以后不再重复
    pref_ids = {_s(r.get('jjId')) for r in pref}
    rest = [r for r in cand if _s(r.get('jjId')) not in pref_ids]
    out = pref + rest
    _deco_pool.__dict__[key] = out
    return out


def _room_rows():
    """全部房间模板：roomid → 行（普通 + 特殊各补上自己的键名）。"""
    t = _tables()
    out = {}
    for _, row in t['normal_room'].items():
        if isinstance(row, dict) and row.get('roomid'):
            r = dict(row)
            r['roomdsc'] = r.get('roomdsc') or r.get('desc') or ''
            out[r['roomid']] = r
    for _, row in t['special_room'].items():
        if isinstance(row, dict) and row.get('roomid'):
            r = dict(row)
            r['name'] = r.get('name') or r.get('roomname') or ''
            out[r['roomid']] = r
    return out


def _room_type_of(roomid):
    """tsfangjianNNN ←→ `特殊房间类型` 的中文 roomtype（familytype 的 roomId 就是它）。"""
    t = _tables()
    if not isinstance(roomid, str) or not roomid.startswith('tsfangjian'):
        return ''
    num = roomid.replace('tsfangjian', '')
    row = t['room_kind'].get(str(int(num))) if num.isdigit() else None
    return (row or {}).get('roomtype') or ''


def _door_list():
    t = _tables()
    out = [dict(v) for v in t['door'].values() if isinstance(v, dict)]
    out.sort(key=lambda d: _int(d.get('doorcost'), 0))
    return out


def _duilian_list():
    t = _tables()
    out = [dict(v) for v in t['duilian'].values() if isinstance(v, dict)]
    out.sort(key=lambda d: _int(d.get('cost'), 0))
    return out


def _int(v, default=0):
    """她那一堆 `a+1` / `a<b` 的地方，给字符串会崩 ⇒ 一律转数字。"""
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return default


def _s(v, default=''):
    if v is None:
        return default
    if isinstance(v, str):
        return v
    if isinstance(v, bool):
        return '1' if v else '0'
    if isinstance(v, (int, float)):
        return '%d' % v if float(v).is_integer() else str(v)
    return default


def _num_list(v):
    """`aids` / `fids` 之类的数组参数。

    ★ 除了真数组和 `1,2,3`，还要吃 **JSON 数组字符串** `'[2,3]'`：
      真实上行是 JSON（`aids=[2,3]`），但探针/手搓请求会把整段 JSON 当字符串塞进来，
      老写法按逗号切会得到 `['[2', '3]']` ⇒ 全部转成 -1 ⇒ **一条都不匹配**（已实测）。
    """
    if isinstance(v, (list, tuple)):
        return [_int(x, -1) for x in v]
    if isinstance(v, str):
        s = v.strip()
        if s.startswith('['):
            import json
            try:
                o = json.loads(s)
                if isinstance(o, list):
                    return [_int(x, -1) for x in o]
            except Exception:                  # noqa: BLE001
                pass
            s = s.strip('[]')
        return [_int(x, -1) for x in s.replace('，', ',').split(',') if x.strip() != '']
    if v is None:
        return []
    return [_int(v, -1)]


def _dict(v):
    """给对象的字段一律保证是 dict（给字符串会 `attempt to index`）。"""
    if isinstance(v, dict):
        return v
    if isinstance(v, str):
        import json
        try:
            o = json.loads(v)
            return o if isinstance(o, dict) else {}
        except Exception:                      # noqa: BLE001
            return {}
    return {}


def _obj_list(v):
    """给数组的字段一律保证是 list。"""
    if isinstance(v, list):
        return v
    if isinstance(v, dict):
        # 她有的地方传 `{[roomId]={...}}` 的字典，转成带 key 的数组
        return [dict(x, roomId=k) if isinstance(x, dict) else {'roomId': k, 'value': x}
                for k, x in v.items()]
    return []


# ===========================================================================
# 二、状态
# ===========================================================================
def _state(ctx):
    st = ctx.load_json(STATE, None)
    if not isinstance(st, dict):
        st = {}
    st.setdefault('ver', 1)
    if not isinstance(st.get('homes'), dict):
        st['homes'] = {}
    return st


def _home(st, mid):
    """取（必要时新建）某个家园的账本。"""
    if not isinstance(st.get('homes'), dict):
        st['homes'] = {}
    key = _s(mid) or '0'
    h = st['homes'].get(key)
    if not isinstance(h, dict):
        h = {}
        st['homes'][key] = h
    h.setdefault('furniture', [])
    h.setdefault('rooms', {})
    h.setdefault('affairs', [])
    h.setdefault('special', [])
    h.setdefault('homebw', [])
    h.setdefault('map_extra', {})
    if not isinstance(h['furniture'], list):
        h['furniture'] = []
    if not isinstance(h['rooms'], dict):
        h['rooms'] = {}
    if not isinstance(h['affairs'], list):
        h['affairs'] = []
    return h


def _bump_ver(st):
    st['ver'] = _int(st.get('ver'), 1) + 1
    return st['ver']


def _affair_id(h):
    """给她一条事务分配 id（`processRoomAffair(self.id, ...)` 要数字）。"""
    mx = 0
    for a in h['affairs']:
        if isinstance(a, dict):
            mx = max(mx, _int(a.get('id'), 0))
    return mx + 1


# ===========================================================================
# 三、地图房间（从 `fz_homeland_map` 拿，保证 fjId 在 maproom 里真的存在）
# ===========================================================================
def _map_rooms(ctx, mid):
    """返回 [ {fjId, name, roomType, link{...}} ] —— 就是 `get_user_map` 下发的房间。

    ★ 必须用**同一个生成器**：`UserMap.lua:214` 一旦发现 `map.room[fjId] == nil`
      就 `error("数据错误, 房间ID…不在副本内")` ⇒ 应答回调里被 xpcall 吞掉 ⇒ 客户端卡死。
    """
    try:
        here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        if here not in sys.path:
            sys.path.insert(0, here)
        import fz_homeland_map as H
        data = H.build_user_map(mid)
        rooms = []
        for r in data.get('maproom') or []:
            if isinstance(r, dict) and r.get('fjId'):
                rooms.append(r)
        if rooms:
            return rooms
    except Exception as e:                     # noqa: BLE001
        try:
            ctx.log('家园家具：地图生成器取房间失败（%s），退回 familylist 顺序' % e)
        except Exception:                      # noqa: BLE001
            pass
    # 兜底：按 familytype 的读序手搓房间 id / 类型（houseId 名字近似，够用）
    t = _tables()
    rows = _room_rows()
    out = []
    for i, rid in enumerate(['fb320_%02d' % n for n in range(1, 10)]):
        rows_i = list(rows.keys())
        rt = rows_i[i % len(rows_i)] if rows_i else ''
        out.append({'fjId': rid, 'name': t['special_room'].get(str(i + 1), {}).get('roomname', '房间'),
                    'roomType': rt, 'link': {}})
    return out


def _entry_room(ctx, mid):
    """入口房间 = `specialid==1` 那间（房契户型里就是「屋外」），拿不到就用第一个。"""
    rooms = _map_rooms(ctx, mid)
    if not rooms:
        return ''
    # build_user_map 已经把「屋外」排在读序首位（specialid=1 起点）
    for r in rooms:
        if _room_type_of(r.get('roomType') or '') in ('屋外',):
            return r['fjId']
    return rooms[0]['fjId']


def _room_tpl(roomtype):
    """roomType(tsfangjianNNN) → 房间模板行。"""
    return _room_rows().get(roomtype or '') or {}


def _eff_room_type(h, room):
    """这个房间**现在**是什么房型（改造过的以我们记的为准）。

    ★ 为什么需要：`get_user_map` 每次都拿 `fz_homeland_map.build_user_map(mid)` 按房契户型
      **重新生成** `maproom`（那是服务端的活，不在本模块），它不认识我们记的改造结果。
      所以「改造过的房型」只存在本模块状态里 ⇒ 摆放校验 / 家具上限都要叠一层。
      读的键是 `roomType`（客户端 `map.room[fjId].roomType` 用的是它；
      `transform_room` 上行给的却是 `roomid`，两个都认）。
    """
    rid = _s(room.get('fjId'))
    rec = (h.get('rooms') or {}).get(rid) or {}
    if _s(rec.get('isdeleted')).upper() == 'Y':
        return ''
    return _s(rec.get('roomType') or rec.get('roomid')) or _s(room.get('roomType'))


def _furn_limit(roomtype):
    """`HomelandRoomUtil:getRoomFurnitureLimit` —— 房间能放几件家具。"""
    return _int(_room_tpl(roomtype).get('furniturelimit'), 4)


def _can_place_type(roomtype, itype):
    """`HomelandRoomUtil:checkCanPlaceFurnitureType` —— 特殊房间的 flimit 白名单。"""
    tpl = _room_tpl(roomtype)
    flimit = tpl.get('flimit')
    if not flimit or not isinstance(flimit, str):
        return True
    return str(_int(itype)) in [x.strip() for x in flimit.split(';') if x.strip() != '']


def _builtin_jjid(roomtype):
    """房间改造后自带的家具（`特殊房屋.neizhiitem`）。"""
    tpl = _room_tpl(roomtype)
    v = tpl.get('neizhiitem')
    if isinstance(v, str) and v:
        return v
    return _ROOM_FALLBACK.get(roomtype or '', '')


def _placeable(roomtype, jj):
    """她那两条校验：`takelimit`（家具能进哪些房间）+ 房间 `flimit`（白名单）。"""
    if not isinstance(jj, dict):
        return False
    take = jj.get('takelimit')
    if isinstance(take, str) and take.strip():
        if (roomtype or '') not in [x.strip() for x in take.split(';') if x.strip() != '']:
            return False
    if not _can_place_type(roomtype, jj.get('itype')):
        return False
    return True


# ===========================================================================
# 四、`map_furniture` —— 摆过的家具真出现在家里
# ===========================================================================
def _furn_record(fid, jj, fjid, extra=None, **more):
    """一条 `roomfurniture` 元素。

    ★ 她 `initFurnitureData` 真读的四个字段（jjId / fjId / fid / itype）+ 一个对象
      `extra`（`initChuWuXiang` / `initRoleItem` 读），**类型全对**：
        jjId 字符串、fjId 字符串、fid 字符串、itype 数字、extra 对象。
      其余按她 `familylist["家具"]` 原样带上（她那边 `Helper:tableCover` 会用物品行覆盖）。
    """
    jj = jj or {}
    out = {
        'fid': _s(fid),
        'jjId': _s(jj.get('jjId')),
        'fjId': _s(fjid),
        'itype': _int(jj.get('itype'), 0),
        'iType': ITYPE_CN.get(_int(jj.get('itype'), 0), '普通家具'),
        'name': _s(jj.get('name'), '家具'),
        'dsc': _s(jj.get('dsc')),
        'usedsc': _s(jj.get('usedsc'), '无'),
        'useName': _s(jj.get('useName')),
        'shouqi': _int(jj.get('shouqi'), 0),
        'shouqitext': _s(jj.get('shouqitext')),
        'fangzhitext': _s(jj.get('fangzhitext')),
        'usepossible': _int(jj.get('usepossible'), 0),
        'grade': _int(jj.get('grade'), 0),
        'value': _s(jj.get('value'), ''),
        'special': _s(jj.get('special'), 'N'),
        # ★ 2026-10-23 v41b：takelimit 为空 ⇒ **不写这个键**（Lua 空串是真值，
        #   客户端 `checkFurIsInRightRoom` 会 split 空串后判定失败 ⇒ 家具"摆不进去/点了没反应"）
        **({'takelimit': _s(jj.get('takelimit'))} if _s(jj.get('takelimit')) else {}),
        'price': _int(jj.get('price'), 0),
        'type': 'item',
        'subType': '家具',
        'extra': _dict(extra),
        'conditionAndResults': {},
    }
    out.update(more)
    return out


def _new_fid(h):
    """她那边 `id = "f_" .. fid` ⇒ fid 在**整个副本内**唯一（否则 map.roles 互相覆盖）。"""
    used = set()
    for f in h['furniture']:
        if isinstance(f, dict):
            used.add(_s(f.get('fid')))
    n = 1
    while str(n) in used:
        n += 1
    return str(n)


def _starter_furniture(ctx, mid, h):
    """第一次进家园时，用**她表里的真家具**铺一间像样的屋子。

    ★ 每条都过她那两条校验（`takelimit` + 房间 `flimit`），并受 `furniturelimit` 约束，
      所以看到的布局她客户端自己也认。
    """
    rooms = _map_rooms(ctx, mid)
    if not rooms:
        return
    by = furniture_by_jjid()
    placed = {}
    for f in h['furniture']:
        if isinstance(f, dict):
            rid = _s(f.get('fjId'))
            placed[rid] = placed.get(rid, 0) + 1

    # ★ 哪些房**能摆**装饰：她 `HomelandRoomUtil:getRoomFurnitureLimit` 对
    #   `getSpeciaRoomAttr`/`getNormalRoomAttr` **都取不到**的房型返回 0
    #   （实测：屋外 tsfangjian002 / 大门 tsfangjian004 的 furniturelimit 是 0）
    #   ⇒ 一点装饰都不铺，免得她客户端里出现"摆不进去的家具"。
    def _decorable(rtype):
        return _furn_limit(rtype) > 0

    # 1) 每间房先放它自己的内置家具（`特殊房屋.neizhiitem`）
    for room in rooms:
        rid = room['fjId']
        rtype = _eff_room_type(h, room)
        if not _decorable(rtype) or placed.get(rid, 0) >= _furn_limit(rtype):
            continue
        jjid = _builtin_jjid(rtype)
        jj = by.get(jjid)
        if jj and _placeable(rtype, jj):
            fid = _new_fid(h)
            h['furniture'].append(_furn_record(fid, jj, rid))
            placed[rid] = placed.get(rid, 0) + 1
            if jjid not in h['special']:
                h['special'].append(jjid)

    # 2) 再拿普通装饰家具（书桌/挂画/盆栽）填满还有空位的房间；
    #    候选池**按房间类型**过滤（`takelimit` + `flimit`），摆进去的她客户端一定认
    for room in rooms:
        rid = room['fjId']
        rtype = _eff_room_type(h, room)
        if not _decorable(rtype):
            continue
        limit = _furn_limit(rtype)
        pool = _deco_pool(rtype)
        if not pool:
            continue
        # 每间房每件装饰只摆一次（她表里 326 件 itype=0 的家具，够铺了）
        cap = min(limit, len(pool))
        i = 0
        while placed.get(rid, 0) < cap:
            jj = pool[i % len(pool)]
            i += 1
            fid = _new_fid(h)
            h['furniture'].append(_furn_record(fid, jj, rid))
            placed[rid] = placed.get(rid, 0) + 1


def patch_maproom(ctx, mid, maproom):
    """把**房间改造 / 拆房**的结果盖到服务端刚生成的 `maproom` 上。

    ★ 为什么需要：`maproom` 是 `fz_homeland_map.build_user_map(mid)` 按**房契户型**
      每次重新生成的，它不认识我们在 `homeland_home_state.json["homes"][mid]["rooms"]`
      里记的改造结果 ⇒ 改完房间再进家，看到的还是老户型（点了「改造」像是没生效）。
      这里就地改 `maproom` 的 `roomType` / `name` / `desc`，并删掉已拆的房间。
    返回改了几间，方便日志。
    """
    st = _state(ctx)
    h = _home(st, mid)
    recs = h.get('rooms') or {}
    if not isinstance(recs, dict) or not isinstance(maproom, list):
        return 0
    changed = 0
    keep = []
    for room in maproom:
        if not isinstance(room, dict):
            continue
        rid = _s(room.get('fjId'))
        rec = recs.get(rid) if isinstance(recs.get(rid), dict) else None
        if rec and _s(rec.get('isdeleted')).upper() == 'Y':
            changed += 1
            continue                        # 已拆：不再下发这间房
        if rec:
            new_type = _s(rec.get('roomType') or rec.get('roomid'))
            if new_type and new_type != _s(room.get('roomType')):
                room['roomType'] = new_type
                changed += 1
            nm = _s(rec.get('roomname'))
            if nm:
                room['name'] = nm
            dsc = _s(rec.get('roomdsc') or rec.get('desc') or rec.get('dsc'))
            if dsc:
                room['desc'] = dsc
        keep.append(room)
    if changed:
        maproom[:] = keep
        ctx.save_json(STATE, st)
        ctx.log('家园房间改造已生效：%d 间（mid=%s，下发 %d 间）' % (changed, mid, len(maproom)))
    return changed


def map_furniture(ctx, mid):
    """`get_user_map` 应答里的 `roomfurniture` 数组。
    ★ 签名/返回被服务端 `fz_boot_server.py:1397` 这样用：
        `_lst = _f(ctx, _mid) or []`  →  `_data['roomfurniture'] = _lst`
    所以**必须**返回数组，元素字段见模块 docstring 第三节。
    """
    st = _state(ctx)
    h = _home(st, mid)
    rooms = _map_rooms(ctx, mid)
    room_ids = [r['fjId'] for r in rooms]
    room_map = {r['fjId']: r for r in rooms}
    by = furniture_by_jjid()

    # 1) 修状态里那些**非法**的家具（旧实现留下的 fjId="" / jjId 缺失）：
    #    她的客户端会因为 `fjId` 不在副本内直接 error ⇒ 宁可搬到入口房，也别让 UI 卡死
    entry = _entry_room(ctx, mid)
    dirty = False
    for f in list(h['furniture']):
        if not isinstance(f, dict):
            h['furniture'].remove(f)
            dirty = True
            continue
        jj = by.get(_s(f.get('jjId')))
        if jj is None:
            # jjId 丢了就按 name 反查她表里同名那件（旧实现只存了 name）
            nm = _s(f.get('name'))
            cand = None
            if nm:
                for r in furniture_templates():
                    if _s(r.get('name')) == nm:
                        cand = r
                        break
            if cand is None:
                h['furniture'].remove(f)
                dirty = True
                continue
            f['jjId'] = cand['jjId']
            dirty = True
        if _s(f.get('fjId')) not in room_map:
            f['fjId'] = entry or (room_ids[0] if room_ids else '')
            dirty = True
        # ★ 房间改造过（有效房型变了）⇒ 原来那件家具可能**摆不进新户型**了，
        #   她客户端 `checkFurIsInRoomAction` 会把操作全禁掉（点了没反应）。
        #   所以这里主动搬回一件摆得进且没满的房间；实在没地方就丢掉。
        eff = _eff_room_type(h, room_map.get(_s(f.get('fjId')), {}))
        if not eff or not _placeable(eff, by.get(_s(f.get('jjId')))):
            moved = ''
            for r in rooms:
                nrt = _eff_room_type(h, r)
                if not nrt or not _placeable(nrt, by.get(_s(f.get('jjId')))):
                    continue
                used = sum(1 for x in h['furniture']
                           if isinstance(x, dict) and _s(x.get('fjId')) == r['fjId'])
                if used < _furn_limit(nrt):
                    moved = r['fjId']
                    break
            if moved:
                f['fjId'] = moved
            else:
                h['furniture'].remove(f)
            dirty = True
        if not _s(f.get('fid')):
            f['fid'] = _new_fid(h)
            dirty = True
        f['itype'] = _int((by.get(_s(f.get('jjId'))) or {}).get('itype'), 0)
        if not isinstance(f.get('extra'), dict):
            f['extra'] = {}
            dirty = True

    # 2) 一次都没摆过 ⇒ 用她表里的真家具铺一批（否则进屋四面墙）
    if not h['furniture'] and room_ids:
        _starter_furniture(ctx, mid, h)
        dirty = True

    # ★ 2026-10-17 v36：家园必备「神功书案」（自创武学入口家具，itype=26）。
    #   模板已在 furniture_by_jjid() 注入（shengongshuan001）。玩家没摆过就自动放一张：
    #   书房优先，书房满/没有就找第一间摆得进且未满的房，再不行放入口房。
    #   书房（tsfangjian006）房型表**没有 flimit 白名单** ⇒ itype=26 摆得进、客户端也认。
    # ★ 2026-10-23 v41b：**锻造炉自动摆放**（神兵改名/换颜色/修理/熔兵的入口）。
    #   原版只能放"昭阳轩"（特殊房间，多数玩家没有）⇒ 找不到入口。
    #   这里与神功书案同法：没摆过就自动放一张（优先炼器房，其次任意能摆且未满的房间）。
    if room_ids and not any(
            isinstance(f, dict) and _s(f.get('jjId')) == 'duanzaolu001'
            for f in h['furniture']):
        _jj_dz = by.get('duanzaolu001')
        if _jj_dz:
            _tgt = ''
            for r in rooms:
                if _eff_room_type(h, r) == '炼器房' and _placeable('炼器房', _jj_dz):
                    _tgt = r['fjId']
                    break
            if not _tgt:
                for r in rooms:
                    _rt = _eff_room_type(h, r)
                    if _rt and _placeable(_rt, _jj_dz) and sum(
                            1 for x in h['furniture'] if isinstance(x, dict)
                            and _s(x.get('fjId')) == r['fjId']) < _furn_limit(_rt):
                        _tgt = r['fjId']
                        break
            if not _tgt:
                _tgt = entry or (room_ids[0] if room_ids else '')
            h['furniture'].append(_furn_record(_new_fid(h), _jj_dz, _tgt))
            dirty = True
            ctx.log('家园 %s：自动放置锻造炉（神兵改名入口，房间 %s）' % (mid, _tgt))

    if room_ids and not any(
            isinstance(f, dict) and _int(f.get('itype'), 0) == 26
            for f in h['furniture']):
        jj = by.get('shengongshuan001')
        target = ''
        if jj:
            for r in rooms:
                if _eff_room_type(h, r) == '书房' and _placeable('书房', jj):
                    target = r['fjId']
                    break
            if not target:
                for r in rooms:
                    rt = _eff_room_type(h, r)
                    if rt and _placeable(rt, jj) and sum(
                            1 for x in h['furniture'] if isinstance(x, dict)
                            and _s(x.get('fjId')) == r['fjId']) < _furn_limit(rt):
                        target = r['fjId']
                        break
            if not target:
                target = entry or (room_ids[0] if room_ids else '')
            h['furniture'].append(_furn_record(_new_fid(h), jj, target))
            dirty = True
            ctx.log('家园 %s：自动放置神功书案（自创武学入口，房间 %s）' % (mid, target))

    if dirty:
        ctx.save_json(STATE, st)

    # 3) 输出（★ 房间必须是 maproom 里真存在的，fid 必须唯一）
    out = []
    seen_fid = set()
    for f in h['furniture']:
        if not isinstance(f, dict):
            continue
        jj = by.get(_s(f.get('jjId')))
        if jj is None:
            continue
        rid = _s(f.get('fjId'))
        if rid not in room_map:
            continue
        # 已拆掉的房间不再下发家具（她拆房时会把 `type=="item"` 的全清掉）
        if _s((h['rooms'].get(rid) or {}).get('isdeleted')).upper() == 'Y':
            continue
        fid = _s(f.get('fid'))
        if not fid or fid in seen_fid:
            fid = _new_fid(h)
            f['fid'] = fid
        seen_fid.add(fid)
        rec = _furn_record(fid, jj, rid, f.get('extra'))
        # 状态里可能还有她下发过的额外字段（durable / itemId / 香炉的火 …），一并带上
        for k in ('itemId', 'durable', 'xiangId'):
            if f.get(k) is not None:
                rec[k] = f[k]
        for k, v in (f.get('extra') or {}).items():
            rec.setdefault(k, v)
        out.append(rec)
    return out


# ===========================================================================
# 五、事务（`Affair` 那条链路）
# ===========================================================================
def _days_since(t):
    """`Helper:getDaysBetweenTwoDate2` 的近似（她拿它算欠了几天薪 / 地税）。"""
    t = _int(t, 0)
    if t <= 0:
        return 0
    return max(int((time.time() - t) // 86400), 0)


def _affair_text(a):
    """`Affair:initByConf` 里各分支要的文案（照她 Lua 的原话拼，变量用真值）。"""
    av = _dict(a.get('affair_val'))
    if a.get('affair_id') == 1:
        return '管家：#ch#，我们的房屋已经可以进行扩建了，不知您意下如何？'
    if a.get('affair_id') == 2:
        d = _days_since(av.get('pay_time'))
        unit = _PAY_UNIT_CN.get(_s(av.get('pay_unit')), '银票')
        return ('管家：#ch#，咱这已是%d天未缴地税了，如今已是欠下了%d%s，'
                '若是连续15日未缴地税，这土地只怕要被收回了。'
                % (d, _int(av.get('pay_base'), 0) * d, unit))
    if a.get('affair_id') in (3, 4):
        d = _days_since(av.get('pay_time'))
        cost = _int(av.get('pay_base'), 0)
        unit = _PAY_UNIT_CN.get(_s(av.get('pay_unit')), '银票')
        mx = min(d, 30)
        return ('管家：#ch#，%s入住我们家已有%d日了，薪资尚未发放，是否现在就发薪？'
                '现在发的话，需要发薪%d%s（欠薪太多，会导致仆人闹事甚至离开）'
                % (_s(av.get('name'), '仆人'), d, cost * mx, unit))
    if a.get('affair_id') == 5:
        return ('管家：#ch#，%s出%d银票想要购买咱这块土地，您看，要不要答应？'
                % (_s(av.get('from_name'), '有人'), _int(av.get('number'), 0)))
    if a.get('affair_id') == 6:
        return '管家：#ch#，今日%s携邀请函来拜访了您。' % _s(av.get('from_name'), '有人')
    if a.get('affair_id') == 7:
        return '管家：#ch#，您不在家的时候，%s来闯门了。' % _s(av.get('from_name'), '有人')
    if a.get('affair_id') == 8:
        return '这是%s给你发的一份邀请函。' % _s(av.get('from_name'), '有人')
    if a.get('affair_id') == 9:
        return ('管家：#ch#，您的%s，因为您未及时发放薪水，已经离开了。'
                % _s(av.get('name'), '仆人'))
    if a.get('affair_id') == 10:
        return ('管家：#ch#，由于您已15天未缴纳地税，您的土地已被官府收回了，'
                '我们搬至了%s。' % _s(av.get('location'), '别处'))
    if a.get('affair_id') == 11:
        return ('管家：#ch#，您已经答应了%s的%d银票出价请求，如今这块土地已经转让给%s了。'
                % (_s(av.get('from_name'), '对方'), _int(av.get('number'), 0),
                   _s(av.get('from_name'), '对方')))
    if a.get('affair_id') == 12:
        n = _int(av.get('number'), 0)
        if n == 0:
            return '管家：您的门客%s因不耐寂寞，已是独自一人云游四方去了。' % _s(av.get('name'), '门客')
        return ('管家：您的门客%s因不耐寂寞，已是独自一人云游四方去了，'
                '临走之际将%d/%s的薪资退还给了您。'
                % (_s(av.get('name'), '门客'), n, _PAY_UNIT_CN.get(_s(av.get('unit')), '银票')))
    if a.get('affair_id') == 13:
        return ('管家：#ch#，%s特意前来登门拜年，并留下一份厚礼。'
                % _s(av.get('from_name'), '有人'))
    if a.get('affair_id') == 14:
        d = _days_since(av.get('rest_time'))
        nm = _s(av.get('name'), '门客')
        return ('管家：#ch#，%s入住宅府已有%d日，但近些时日%s似乎无事可做，'
                '此刻是否派遣%s去做一些事情？若是这般悠闲下去，%s恐怕会耐不住闲散，云游而去。'
                % (nm, d, nm, nm, nm))
    return _s(a.get('text'), '管家：#ch#，府中有一件事需要您定夺。')


def _affair_row(a, idx):
    """把状态里的一条事务补成她 `Affair:create` 能整条读完的对象（**类型全对**）。"""
    av = _dict(a.get('affair_val'))
    aid = _int(a.get('affair_id'), 1)
    btype = _int(a.get('biz_type'), 1)
    row = {
        'id': _int(a.get('id'), idx + 1),
        'affair_id': aid,
        'biz_type': btype,
        'from_id': _s(a.get('from_id')),
        'affair_val': av,
        'is_read': _int(a.get('is_read'), 0),
        'is_handle': _int(a.get('is_handle'), 0),
        'is_local': _int(a.get('is_local'), 0),
        'create_time': _s(a.get('create_time') or time.strftime('%Y-%m-%d %H:%M:%S')),
        'expired_time': _s(a.get('expired_time') or time.strftime('%Y-%m-%d %H:%M:%S',
                                                                  time.localtime(time.time() + 172800))),
        'count': _s(a.get('count'), ''),
        'objId': _s(a.get('objId')),
        'text': _affair_text(a),
    }
    # 求购（5）时她读 `self.state`
    if aid == 5:
        row['state'] = _int(a.get('state'), 0)
    # 发薪 / 门客 这些她读 `self.affair_val.rwId`
    if aid in (3, 4, 14):
        av.setdefault('rwId', _s(a.get('rwId')))
    return row


def _employees(mid):
    """府上**已雇的人**（读 `homeland_person` 的账本，只读不改）。

    ★ 为什么要读别人的状态：发薪事务是**服务端生成**的（`Affair:paySalaryForPuRen`
      整条从 `affair_val` 读），而人名册在 `homeland_person_state.json`。
      两个模块各写各的文件，这里只**读**，写还是写自己的。
    """
    import json
    import os
    p = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..',
                     'homeland_person_state.json')
    try:
        with open(p, encoding='utf-8') as f:
            st = json.load(f)
    except Exception:                       # noqa: BLE001
        return []
    out = []
    want = _s(mid)
    for e in (st.get('employees') or []):
        if not isinstance(e, dict):
            continue
        if want and want != '0' and _s(e.get('mid')) not in ('', want):
            continue
        out.append(e)
    return out


def _daily_wage(emp):
    """日薪 = **雇佣价 / 14**。

    ★ 这是她自己的规矩，不是我编的：
      `PuRenModel.lua:606`「雇佣%s首次需支付…，之后每7天需要发一次薪，%s的日薪是(price/14)」。
      `HomelandRoleUtil.lua:1094-1100` 也是先看 `role.pay_base.val/unit`，没有才用 `price/14`。
    """
    price = _int(emp.get('price'), 0)
    unit = _s(emp.get('price_unit')) or 'yinpiao'
    if unit not in ('yinpiao', 'yuanbao'):
        unit = 'yinpiao'
    if _s(emp.get('jobType')) == 'guanjia001':
        return 0, unit                       # 管家不管自己发薪（她客户端也不给管家算）
    return max(1, price // 14), unit


def _sync_salary_affairs(ctx, mid, h):
    """按**真雇员名册**对齐发薪事务（她自己的规矩：每 7 天发一次薪）。

    * 名册里没有事务的人补一条；发过薪的（`h['paid'][rwId]` 记着日子）
      要等满 7 天才再生成 —— 不然「欠薪名册」会刚发完薪又冒出来。
    * 已经不在名册上的（被辞退/离开）事务一并清掉，免得点发薪发到空气上。
    """
    emps = _employees(mid)
    h.setdefault('paid', {})
    now = time.time()
    alive = set()
    for e in emps:
        wage, unit = _daily_wage(e)
        if wage > 0:
            alive.add(_s(e.get('rwId')))
    keep, dropped = [], 0
    for a in h['affairs']:
        if not isinstance(a, dict) or _int(a.get('affair_id'), 0) not in (3, 4):
            keep.append(a)
            continue
        rw = _s(_dict(a.get('affair_val')).get('rwId'))
        if rw in alive:
            keep.append(a)
        else:
            dropped += 1
    h['affairs'] = keep
    have = {_s(_dict(a.get('affair_val')).get('rwId'))
            for a in h['affairs'] if isinstance(a, dict)
            and _int(a.get('affair_id'), 0) in (3, 4)}
    added = 0
    for e in emps:
        wage, unit = _daily_wage(e)
        if wage <= 0:
            continue
        rw = _s(e.get('rwId'))
        if rw in have:
            continue
        last = _int(h['paid'].get(rw), 0) or (int(now) - 7 * 86400)
        if now - last < 7 * 86400:
            continue
        aid = 4 if _s(e.get('jobType')) == 'menke001' else 3
        h['affairs'].append({
            'id': _affair_id(h),
            'affair_id': aid, 'biz_type': 1, 'from_id': '', 'is_read': 0,
            'is_handle': 0, 'is_local': 0,
            'affair_val': {
                'rwId': rw, 'name': _s(e.get('name')),
                'pay_base': wage, 'pay_unit': unit, 'pay_time': last,
            },
            'objId': _s(mid),
        })
        added += 1
    if added or dropped:
        ctx.log('家园发薪事务对齐：新增 %d 条 / 清掉 %d 条（名册 %d 人）'
                % (added, dropped, len(alive)))
    return added


def _push_default_affairs(ctx, mid, h):
    """把「欠薪名册 / 府务定夺」两张面板填成**真数据**。

    * 每个仆人/门客一条发薪事务（`affair_id` 3=仆人、4=门客），
      `affair_val`：`pay_base`=**日薪**（雇佣价/14）、`pay_unit`、`pay_time`=上次发薪日、
      `name`、`rwId`。她客户端读的正是这几个字段，欠薪额 = `pay_base * min(今天-pay_time,30)`。
      **`pay_base` 是日薪不是月薪** —— 给错数额面板就会显示成 14 倍。
    * 一条地税事务（`affair_id=2`）：`pay_base` 取她 `房屋地皮` 的 `cost`（元宝/天），
      单位是**元宝**（她面板写的是「需缴地税：X元宝/天」）。
    """
    now = time.time()
    # 地税事务：没有就补一条（房契开销面板读的就是它）
    _tax = [a for a in h['affairs']
            if isinstance(a, dict) and _int(a.get('affair_id'), 0) == 2]
    # ★ 2026-10-01：已经"处理过"的那条（老逻辑只置 is_handle=1）要**救回来** ——
    #   客户端只显示未处理的事务，置了 1 就等于从面板上消失（老板："没有缴纳地税的事项了"）。
    #   它既然是"处理过"的，说明当时缴过了 ⇒ 把 pay_time 推到今天（欠款归零）再挂回面板。
    for _a in _tax:
        if _int(_a.get('is_handle'), 0) == 1:
            _av = _dict(_a.get('affair_val'))
            _av['pay_time'] = int(now)
            _a['affair_val'] = _av
            _a['is_handle'] = 0
    if not _tax:
        tax = 0
        try:
            fam = _lua(_FAMILYLIST)
            for _, v in (fam.get('房屋地皮') or {}).items():
                if isinstance(v, dict) and _int(v.get('cost'), 0) > 0:
                    tax = _int(v.get('cost'), 0)
                    break
        except Exception:                      # noqa: BLE001
            tax = 0
        h['affairs'].append({
            'id': _affair_id(h),
            'affair_id': 2, 'biz_type': 1, 'from_id': '', 'is_read': 0,
            'is_handle': 0, 'is_local': 0,
            'affair_val': {
                'pay_base': tax or 150, 'pay_unit': 'yuanbao',
                'pay_time': int(now) - 86400 * 2,
            },
            'objId': _s(mid),
        })
    _sync_salary_affairs(ctx, mid, h)




# ===========================================================================
# 六、接口
# ===========================================================================
def _find_furniture(h, fid):
    for f in h['furniture']:
        if isinstance(f, dict) and _s(f.get('fid')) == _s(fid):
            return f
    return None


def _storage_list(ctx, ckname):
    """悬兵洞 / 藏衣阁的**真实**存物。

    ★ 服务端不掌握背包（背包在她客户端存档里，由 `get_game_user_info_2` 下发），
      所以这里只回我们已经收下过的东西（`use_homebw` / 别的模块写进来的），
      没有就回空 —— 宁可空着，也不编假装备。
    """
    st = _state(ctx)
    box = st.get('storage')
    if not isinstance(box, dict):
        return []
    lst = box.get(ckname)
    return lst if isinstance(lst, list) else []


def _ic():
    """共用钱袋子/物品账本（`items_currency` 模块）。拿不到就回 None。"""
    try:
        from fz_api import items_currency as _m
        return _m
    except Exception:                          # noqa: BLE001
        return None


def _wallet_all(ctx):
    ic = _ic()
    if ic is None:
        return {}
    try:
        return {k: ic.get_currency(ctx, k)
                for k in ('yinpiao', 'yuanbao', 'money')}
    except Exception:                          # noqa: BLE001
        return {}


def _wallet_spend(ctx, unit, amount):
    """从**共用钱袋子**扣钱（真正的唯一账本）。不够返回 False，且不改盘。"""
    if amount <= 0:
        return True
    ic = _ic()
    if ic is None:
        return True                            # 模块不在位就不拦（宁可放行也别卡死面板）
    try:
        return ic.add_currency(ctx, unit, -int(amount)) is not None
    except Exception:                          # noqa: BLE001
        return True


def _resolve_mid(ctx, st):
    """★ 定"这是哪个家"。

    ★★ 2026-10-01 关键修复（老板：师门建筑好了，但**缴纳地税弹"没有这项事务"**）：
      客户端很多家园接口**根本不带 mid**（`process_affair` 只发
      `{aid, deal_type, process_type}`，见 `HttpManager.lua:2525`；
      `process_pay_affairs` 只发 `aids`；`restore_user_map` 更是什么都不发）。
      老代码这里一律落到 `'0'` 号房 ⇒ 账本里当然找不到那条事务
      ⇒ 日志 `★ 处理事务：aid=1 不在账本里` ⇒ 客户端弹"没有这项事务"。
      现在：没带 mid 就回**玩家真正的家**（与 `get_user_map` / 房契同一个 mid），
      再退到账本里已经存在的那个家。
    """
    mid = _s(ctx.param('mid') or ctx.headers.get('houseid') or '')
    if mid and mid != '0':
        return mid
    try:
        _hm = (ctx.deps or {}).get('home_mid')
        if callable(_hm):
            mid = _s(_hm())
    except Exception:                                                  # noqa: BLE001
        mid = ''
    if mid and mid != '0':
        return mid
    homes = st.get('homes') if isinstance(st, dict) else None
    if isinstance(homes, dict):
        cand = [k for k in homes if k not in ('0', '')]
        if cand:
            # 多个家就挑"东西最多的那个"（事务/家具/房间），至少保证不是空壳
            cand.sort(key=lambda k: len((homes.get(k) or {}).get('affairs') or [])
                      + len((homes.get(k) or {}).get('furniture') or []), reverse=True)
            return _s(cand[0])
    return '0'


def handle(ctx):
    ep = ctx.endpoint
    st = _state(ctx)
    mid = _resolve_mid(ctx, st)
    h = _home(st, mid)
    by = furniture_by_jjid()

    # ---------------------------------------------------------------- 摆家具
    if ep == 'putin_furniture':
        jjid = _s(ctx.param('jjId') or ctx.param('furnitureId') or '')
        jj = by.get(jjid)
        if jj is None:
            return ctx.fail('没有这种家具：%s' % (jjid or '?'), '★ 摆放家具：jjId 不在她的表里')
        rooms = _map_rooms(ctx, mid)
        room_map = {r['fjId']: r for r in rooms}
        rid = _s(ctx.param('fjId') or ctx.param('roomId') or '')
        if rid not in room_map:
            rid = _entry_room(ctx, mid)
        if rid not in room_map:
            return ctx.fail('找不到要放置的房间', '★ 摆放家具：副本里没有这个房间')
        # ★ 用**有效房型**（改造过的以我们记的为准；`get_user_map` 不认改造结果）
        rtype = _eff_room_type(h, room_map[rid])
        if not rtype:
            return ctx.fail('该房间已被拆除', '★ 摆放家具：房间已拆')
        # 她那两条前置校验（她客户端也做，服务端再兜一次，避免脏状态）
        if not _placeable(rtype, jj):
            return ctx.fail('该房间不可放置该类型家具。', '★ 摆放家具：房间类型不允许')
        cnt = sum(1 for f in h['furniture']
                  if isinstance(f, dict) and _s(f.get('fjId')) == rid)
        if cnt >= _furn_limit(rtype):
            return ctx.fail('当前房间家具放置已达上限，不可放入。', '★ 摆放家具：房间已满')

        extra = _dict(ctx.param('extra') if isinstance(ctx.param('extra'), dict) else {})
        bo = ctx.body_obj.get('extra') if isinstance(ctx.body_obj, dict) else None
        if isinstance(bo, dict):
            extra = bo
        fid = _new_fid(h)
        rec = _furn_record(fid, jj, rid, extra)
        h['furniture'].append({
            'fid': fid, 'jjId': jjid, 'fjId': rid, 'itype': _int(jj.get('itype'), 0),
            'extra': extra,
        })
        ver = _bump_ver(st)
        ctx.save_json(STATE, st)
        ctx.log('家园摆家具：%s(%s) → 房间 %s(%s)，现共 %d 件（ver=%d）'
                % (jj.get('name'), jjid, rid, rtype, len(h['furniture']), ver))
        # ★ 她读 `data.furn_info`（对象）+ `data.furn_info.itype`（数字）+ `data.ver`（数字）
        return ctx.ok({'furn_info': rec, 'ver': ver},
                      '★ 摆放家具（%s → %s）' % (_s(jj.get('name')), rid))

    # ---------------------------------------------------------------- 收家具
    if ep == 'remove_furniture':
        fid = _s(ctx.param('fid') or '')
        target = _find_furniture(h, fid)
        if target is None:
            return ctx.fail('这件家具不在屋里', '★ 收起家具：fid=%s 没找到' % fid)
        h['furniture'] = [f for f in h['furniture'] if _s(f.get('fid')) != fid]
        ver = _bump_ver(st)
        ctx.save_json(STATE, st)
        ctx.log('家园收家具：fid=%s(%s)，剩 %d 件（ver=%d）'
                % (fid, target.get('name') or by.get(_s(target.get('jjId')), {}).get('name'),
                   len(h['furniture']), ver))
        # ★ 她读 `data.ver`（数字）
        return ctx.ok({'ver': ver, 'fid': fid}, '★ 收起家具（fid=%s）' % fid)

    # ------------------------------------------------- 家具附加数据（香炉的火…）
    if ep == 'upload_furniture_extra':
        attr = ctx.body_obj.get('attr') if isinstance(ctx.body_obj, dict) else None
        attr = _obj_list(attr)
        n = 0
        for item in attr:
            if not isinstance(item, dict):
                continue
            f = _find_furniture(h, item.get('fid'))
            if f is None:
                continue
            a = item.get('attr')
            f['extra'] = _dict(a)
            for k, v in f['extra'].items():          # 香炉的火直接挂在家具上（她那边也是）
                f[k] = v
            n += 1
        ver = _bump_ver(st)
        ctx.save_json(STATE, st)
        ctx.log('家园家具附加数据：更新 %d 件（ver=%d）' % (n, ver))
        return ctx.ok({'ver': ver}, '★ 家具附加数据（%d 件）' % n)

    # ---------------------------------------------------------------- 房间改造
    if ep == 'revamp_room_attr':
        rid = _s(ctx.param('fjId') or ctx.param('roomId') or ctx.param('id') or '')
        attr = _dict(ctx.body_obj.get('attr')) if isinstance(ctx.body_obj, dict) else {}
        if not attr:
            attr = {'desc': _s(ctx.param('desc'))} if ctx.param('desc') else {}
        # ★ 必须有房间 id：她两处调用都是 `revampRoomAttr(room.id, map.mid, {desc=...})`
        #   （HomelandRoomUtil.lua:590,631）。没 id 就写进 `rooms[""]` 是脏数据。
        if not rid:
            return ctx.fail('缺少房间 id', '★ 房间属性变更：没有 fjId')
        # 房间必须在副本里（否则她 `map.room[fjId]` 是 nil，描述改了也看不到）
        if rid not in {r['fjId'] for r in _map_rooms(ctx, mid)}:
            return ctx.fail('副本里没有这个房间：%s' % rid, '★ 房间属性变更：fjId 不在副本内')
        if not attr:
            return ctx.fail('没有要修改的房间属性', '★ 房间属性变更：attr 为空')
        room = h['rooms'].setdefault(rid, {})
        room.update(attr)
        room['desc'] = _s(room.get('desc'))
        room['dsc'] = room['desc']
        ver = _bump_ver(st)
        ctx.save_json(STATE, st)
        ctx.log('家园房间属性变更：%s ← %s（ver=%d）' % (rid, list(attr.keys()), ver))
        return ctx.ok({'ver': ver, 'fjId': rid, 'attr': room},
                      '★ 房间属性变更（%s）' % rid)

    if ep == 'transform_room':
        rid = _s(ctx.param('fjId') or ctx.param('roomId') or '')
        attr = _dict(ctx.body_obj.get('attr')) if isinstance(ctx.body_obj, dict) else {}
        new_type = _s(attr.get('roomid') or attr.get('roomType'))
        if not rid:
            rooms = _map_rooms(ctx, mid)
            rid = rooms[0]['fjId'] if rooms else ''
        if not rid:
            return ctx.fail('缺少房间 id', '★ 房间改造：没有 fjId')
        if not new_type:
            return ctx.fail('缺少目标房间类型', '★ 房间改造：attr.roomid 为空')
        tpl = _room_tpl(new_type)
        if not tpl:
            return ctx.fail('没有这种房间：%s' % new_type, '★ 房间改造：不在她的房间里表')
        cost = _int(attr.get('upgradecost'), _int(ctx.param('point'), 0))
        # 记下改造：房型 + 她整行模板（她拿它 tableCover 覆盖本地房间，并读 roomdsc）
        room = h['rooms'].setdefault(rid, {})
        room.update({
            'roomType': new_type,
            'roomid': new_type,
            'roomname': _s(tpl.get('name') or tpl.get('roomname')),
            'roomdsc': _s(tpl.get('roomdsc') or tpl.get('desc')),
            'desc': _s(tpl.get('roomdsc') or tpl.get('desc')),
            'dsc': _s(tpl.get('roomdsc') or tpl.get('desc')),
            'furniturelimit': _int(tpl.get('furniturelimit'), 4),
        })
        # 房间里的旧家具：她 `processPrUpdateData` 会把 `type=="item"` 的全清掉 ⇒ 我们也撤走
        h['furniture'] = [f for f in h['furniture']
                          if not (isinstance(f, dict) and _s(f.get('fjId')) == rid)]
        # ★ 改造后内置家具（她 `data.specialFurn` → `initFurnitureForUserMap`）
        special = []
        jjid = _builtin_jjid(new_type)
        jj = by.get(jjid)
        if jj is not None:
            fid = _new_fid(h)
            h['furniture'].append({
                'fid': fid, 'jjId': jjid, 'fjId': rid,
                'itype': _int(jj.get('itype'), 0), 'extra': {},
            })
            if jjid not in h['special']:
                h['special'].append(jjid)
            rec = _furn_record(fid, jj, rid)
            rec.pop('fjId', None)          # 她那边会自己塞 `furn.fjId = fjId`
            special.append(rec)
        ver = _bump_ver(st)
        ctx.save_json(STATE, st)
        ctx.log('家园房间改造：%s → %s(%s)，内置家具 %d 件，花费 %d 银票（ver=%d）'
                % (rid, _s(tpl.get('name') or tpl.get('roomname')), new_type,
                   len(special), cost, ver))
        # ★ 她读 `data.specialFurn`（数组）+ `data.remove_point`（数字）
        return ctx.ok({'specialFurn': special, 'remove_point': cost,
                       'roomType': new_type, 'fjId': rid, 'ver': ver},
                      '★ 房间改造（%s → %s）' % (rid, _s(tpl.get('name') or tpl.get('roomname'))))

    # -------------------------------------- 房屋属性批量变更（拆房 / 设宴忠诚度）
    if ep == 'update_home_attr':
        fj_update = _dict(ctx.body_obj.get('fj_update')) if isinstance(ctx.body_obj, dict) else {}
        pr_update = _dict(ctx.body_obj.get('pr_update')) if isinstance(ctx.body_obj, dict) else {}
        jj_update = _dict(ctx.body_obj.get('jj_update')) if isinstance(ctx.body_obj, dict) else {}
        cost = _dict(ctx.body_obj.get('cost')) if isinstance(ctx.body_obj, dict) else {}

        # 1) 拆房间：`{roomId: {isdeleted="Y", ...}}`
        gone_rooms = []
        for rid, upd in fj_update.items():
            u = _dict(upd)
            if _s(u.get('isdeleted')).upper() == 'Y':
                gone_rooms.append(rid)
                room = h['rooms'].setdefault(rid, {})
                room['isdeleted'] = 'Y'
                # 她 `initNpcAndFurUpdateData` 会把房间里的家具写进 jj_update
                h['furniture'] = [f for f in h['furniture']
                                  if not (isinstance(f, dict) and _s(f.get('fjId')) == rid)]
            else:
                room = h['rooms'].setdefault(rid, {})
                for k, v in u.items():
                    if k != 'isdeleted':
                        room[k] = _s(v)
        # 2) 家具删除：`{fid: {isdeleted="Y"}}`（她的键是去掉 "f_" 的 fid）
        for fid, upd in jj_update.items():
            if _s(_dict(upd).get('isdeleted')).upper() == 'Y':
                h['furniture'] = [f for f in h['furniture']
                                  if _s(f.get('fid')) != _s(fid)]
        # 3) 仆人搬房间：`{rwId: {fjId: 新房间}}`（人员账本在 homeland_person，那边自己用）
        h.setdefault('pr_update', {})
        for rwid, upd in pr_update.items():
            h['pr_update'][_s(rwid)] = _s(_dict(upd).get('fjId'))

        ver = _bump_ver(st)
        ctx.save_json(STATE, st)
        ctx.log('家园属性批量变更：拆 %d 间 / 删 %d 家具 / 搬 %d 人，花费 %s%s（ver=%d）'
                % (len(gone_rooms), len(jj_update), len(pr_update),
                   _int(cost.get('value'), 0), _s(cost.get('unit'), 'yinpiao'), ver))
        # ★ 她只判 errcode，**不读 data**
        return ctx.ok({'ver': ver}, '★ 房屋属性变更（拆 %d 间 / 删 %d 件家具）'
                      % (len(gone_rooms), len(jj_update)))

    # ---------------------------------------------------------------- 插入事务
    if ep == 'push_affair':
        src = ctx.body_obj if isinstance(ctx.body_obj, dict) else {}
        if isinstance(src.get('data'), dict):
            src = src['data']
        aid = _int(src.get('affair_id'), _int(ctx.param('affair_id'), 1))
        row = {
            'id': _affair_id(h),
            'affair_id': aid,
            'biz_type': _int(src.get('biz_type'), 1),
            'from_id': _s(src.get('from_id')),
            'affair_val': _dict(src.get('affair_val')),
            'objId': _s(src.get('objId')),
            'userid': _s(src.get('userid') or ctx.headers.get('userid')),
            'is_read': 0, 'is_handle': 0,
            'is_local': _int(src.get('is_local'), 0),
            'state': _int(src.get('state'), 0),
            'create_time': time.strftime('%Y-%m-%d %H:%M:%S'),
        }
        if src.get('expired_time'):
            row['expired_time'] = _s(src.get('expired_time'))
        h['affairs'].append(row)
        ver = _bump_ver(st)
        ctx.save_json(STATE, st)
        ctx.log('家园插入事务：id=%s affair_id=%s biz_type=%s（现 %d 条，ver=%d）'
                % (row['id'], aid, row['biz_type'], len(h['affairs']), ver))
        # ★ 她只判 errcode
        return ctx.ok({'id': row['id'], 'ver': ver},
                      '★ 插入事务（affair_id=%s，现 %d 条）' % (aid, len(h['affairs'])))

    # ---------------------------------------------------------------- 处理事务
    if ep == 'process_affair':
        aid = _int(ctx.param('aid'), -1)
        deal = _s(ctx.param('deal_type'), 'process')
        ptype = ctx.param('process_type')
        hit = None
        for a in h['affairs']:
            if isinstance(a, dict) and _int(a.get('id'), -1) == aid:
                hit = a
                break
        if hit is None:
            return ctx.fail('没有这条事务', '★ 处理事务：aid=%s 不在账本里' % aid)
        if deal == 'read':
            hit['is_read'] = 1
        else:
            # ★★ 2026-10-01：**缴纳地税要真的结清**（老板："房屋事务里没有缴纳地税的事项了"）。
            #   `AffairEvent:payLandTax`（`AffairEvent.lua:36-65`）→ `affair:processEvent()`
            #   → 就是我们这里。以前一律只把 `is_handle` 置 1 ⇒ 客户端只显示**未处理**的事务
            #   ⇒ 缴完那条就从面板上消失了（看起来像"事务没了"）。
            #   现在：按「日税 × 欠的天数」扣元宝，`pay_time` 推到今天（欠款归零），
            #   并且**保持 `is_handle = 0`** —— 事务留在面板上，欠款显示 0。
            if _int(hit.get('affair_id'), 0) == 2:
                av = _dict(hit.get('affair_val'))
                unit = _s(av.get('pay_unit')) or 'yuanbao'
                days = min(_days_since(av.get('pay_time')), 30)
                cost = _int(av.get('pay_base'), 0) * days
                if cost > 0 and not _wallet_spend(ctx, unit, cost):
                    return ctx.fail('%s不足，缴纳地税需要 %d' % (unit, cost),
                                    '★ 缴纳地税：%s 不足（需 %d）' % (unit, cost))
                av['pay_time'] = int(time.time())
                hit['affair_val'] = av
                hit['is_handle'] = 0          # ★ 留在面板上（不要让它消失）
                hit['is_read'] = 1
                ver = _bump_ver(st)
                ctx.save_json(STATE, st)
                ctx.log('家园缴纳地税：aid=%s 欠 %d 天 扣 %d %s，pay_time 归零（ver=%d）'
                        % (aid, days, cost, unit, ver))
                return ctx.ok({'ver': ver, 'id': aid, 'is_handle': 0, 'is_read': 1,
                               'cost': cost, 'pay_unit': unit,
                               'currency': _wallet_all(ctx)},
                              '★ 缴纳地税（%d 天 / %d %s）' % (days, cost, unit))
            hit['is_handle'] = 1
            hit['is_read'] = 1
            if ptype is not None:
                hit['process_type'] = _int(ptype, 0)
            # 求购 / 邀请函这类「处理完就消失」
            if _int(hit.get('affair_id'), 1) in (5, 6, 7, 8, 9, 10, 11, 12, 13):
                h['affairs'] = [a for a in h['affairs'] if a is not hit]
        ver = _bump_ver(st)
        ctx.save_json(STATE, st)
        ctx.log('家园处理事务：aid=%s deal_type=%s process_type=%s ⇒ %s（ver=%d）'
                % (aid, deal, ptype, deal, ver))
        return ctx.ok({'ver': ver, 'id': aid, 'is_handle': _int(hit.get('is_handle'), 0),
                       'is_read': _int(hit.get('is_read'), 0)},
                      '★ 处理事务（aid=%s %s）' % (aid, deal))

    if ep == 'process_pay_affairs':
        ids = _num_list(ctx.body_obj.get('aids') if isinstance(ctx.body_obj, dict)
                        else ctx.param('aids'))
        # 排障用：只打解析出来的 aids 与账本 id（**不打上行原文**，正文里有她的存档字段）
        ctx.log('家园发薪上行：aids=%r 账本 id=%r'
                % (ids, [_int(a.get('id'), -1) for a in h['affairs'] if isinstance(a, dict)]))
        done, by_unit, short = [], {}, []
        keep = []
        h.setdefault('paid', {})
        now = int(time.time())
        for a in h['affairs']:
            if not isinstance(a, dict):
                continue
            if _int(a.get('id'), -1) in ids and _int(a.get('affair_id'), 0) in (3, 4):
                av = _dict(a.get('affair_val'))
                unit = _s(av.get('pay_unit')) or 'yinpiao'
                if unit not in ('yinpiao', 'yuanbao'):
                    unit = 'yinpiao'
                cost = _int(av.get('pay_base'), 0) * min(_days_since(av.get('pay_time')), 30)
                # ★ 以前这里不分币种、一律扣银票 ⇒ 元宝薪水的门客会把银票扣光。
                #   现在按 `pay_unit` 扣**对应**的那种钱，钱袋子是 `items_currency`
                #   那份共用的（`homeland_state.json["currency"]`），不再各存一份。
                if cost > 0 and not _wallet_spend(ctx, unit, cost):
                    short.append(_s(av.get('name')) or _s(av.get('rwId')))
                    keep.append(a)
                    continue
                by_unit[unit] = by_unit.get(unit, 0) + cost
                # ★ 发完薪把「上次发薪日」记到今天：她自己的规矩是**每 7 天发一次薪**，
                #   下次 `_sync_salary_affairs` 满 7 天才再生成事务（否则欠薪名册
                #   会刚发完又冒出来，且仆役薪资面板永久为空）。
                rw = _s(av.get('rwId'))
                if rw:
                    h['paid'][rw] = now
                done.append(_int(a.get('id'), -1))
            else:
                keep.append(a)
        h['affairs'] = keep
        ver = _bump_ver(st)
        ctx.save_json(STATE, st)
        ctx.log('家园发薪：处理 %d 条 %s，钱袋子 %s（ver=%d）'
                % (len(done), by_unit or '{}', _wallet_all(ctx), ver))
        if short and not done:
            return ctx.fail('%s的薪水暂时发不出（钱不够）。' % '、'.join(short),
                            '★ 家园发薪：%s 余额不足' % '、'.join(short))
        # ★ 她只判 errcode
        return ctx.ok({'ver': ver, 'aids': done, 'by_unit': by_unit,
                       'paid': sum(by_unit.values()),
                       'currency': _wallet_all(ctx)},
                      '★ 批量发薪（%d 条 / %s）'
                      % (len(done), by_unit or '{}'))

    if ep == 'get_affair_list':
        _push_default_affairs(ctx, mid, h)
        btype = _int(ctx.body_obj.get('biz_type') if isinstance(ctx.body_obj, dict)
                     else ctx.param('biz_type'), -1)
        # ★ 她两个调用点一定带 biz_type（管家=1、信差=3）；万一没带，按「房屋事务」给，
        #   免得面板一片空白（`RoomAffairLayer:initAffairList` 空表会走 Panel_none）。
        if btype in (-1, None):
            btype = 1
        limit = _int(ctx.args[0] if ctx.args else ctx.param('limit'), 0)
        if limit <= 0:
            limit = 20
        rows = []
        for a in h['affairs']:
            if not isinstance(a, dict):
                continue
            if btype not in (-1, None) and _int(a.get('biz_type'), 1) != btype:
                continue
            rows.append(a)
        rows.sort(key=lambda a: (_int(a.get('affair_id'), 0), _s(a.get('create_time'))))
        rows = rows[:limit]
        # ★ data 必须是**数组**（`table.sort` + `ipairs`）—— 见 `_payload`
        out = [_affair_row(a, i) for i, a in enumerate(rows)]
        ctx.save_json(STATE, st)
        return _payload(ctx, out, '★ 事务列表（biz_type=%s，%d 条）' % (btype, len(out)))

    # ---------------------------------------------------------------- 房屋还原
    if ep == 'restore_user_map':
        n = len(h['furniture'])
        h['furniture'] = []
        h['rooms'] = {}
        h['special'] = []
        h['map_extra'] = {}
        h['affairs'] = []
        ver = _bump_ver(st)
        ctx.save_json(STATE, st)
        ctx.log('家园还原：撤销 %d 件家具 / 全部改造（mid=%s，ver=%d）' % (n, mid, ver))
        # ★ 她只判 errcode
        return ctx.ok({'ver': ver, 'removed': n}, '★ 房屋还原（撤销 %d 件家具）' % n)

    # ------------------------------------------------------- 大门 / 对联（地图附加）
    if ep == 'upload_map_extra':
        attr = _dict(ctx.body_obj.get('attr')) if isinstance(ctx.body_obj, dict) else {}
        point = _int(ctx.param('point'), 0)
        extra = h.setdefault('map_extra', {})
        if 'doorId' in attr:
            door_id = _s(attr.get('doorId'))
            if door_id and not any(_s(d.get('doorid')) == door_id for d in _door_list()):
                return ctx.fail('没有这种大门：%s' % door_id, '★ 大门改造：doorId 不在她的表里')
            extra['doorId'] = door_id
            extra['doorName'] = next((_s(d.get('doorname')) for d in _door_list()
                                      if _s(d.get('doorid')) == door_id), '')
        if 'couplet' in attr:
            dl_id = _s(attr.get('couplet'))
            if dl_id and not any(_s(d.get('id')) == dl_id for d in _duilian_list()):
                return ctx.fail('没有这副对联：%s' % dl_id, '★ 对联改造：id 不在她的表里')
            extra['couplet'] = dl_id
            extra['coupletDsc'] = next((_s(d.get('dsc')) for d in _duilian_list()
                                        if _s(d.get('id')) == dl_id), '')
        for k, v in attr.items():
            if k not in ('doorId', 'couplet'):
                extra[_s(k)] = v
        # 真扣银票
        cur = st.setdefault('currency', {'yinpiao': 200000, 'yuanbao': 99999})
        remain = _int(cur.get('yinpiao'), 0)
        if point > 0:
            point = min(point, remain)
            cur['yinpiao'] = remain - point
        ver = _bump_ver(st)
        ctx.save_json(STATE, st)
        ctx.log('家园地图附加：%s，扣 %d 银票（余 %s，ver=%d）'
                % (list(attr.keys()), point, cur.get('yinpiao'), ver))
        # ★ 她读 `data.remove_point`（数字）
        return ctx.ok({'remove_point': point, 'ver': ver, 'extra': extra,
                       'yinpiao': _int(cur.get('yinpiao'), 0)},
                      '★ 大门/对联改造（扣 %d 银票）' % point)

    # ---------------------------------------------------------------- 家园宝物
    # ★ `use_homebw` 已迁到 `homeland_person`（那边才有仆人账本、每日次数、特性表）。
    #   这里保留一小段说明，防止以后又被"顺手补回来"。
    if ep == 'use_homebw':
        return None                                    # 交给 homeland_person

    # ------------------------------------------------- 悬兵洞 / 藏衣阁（客户端数据）
    if ep == 'get_client_data':
        ctype = _s(ctx.param('type') or '')
        listed = _storage_list(ctx, ctype)
        # ★ 她读 `data.flag`（数字）+ `data.item`（对象：key→{itemId, info}）
        items = {}
        for i, it in enumerate(listed):
            if isinstance(it, dict) and it.get('itemId'):
                items[_s(it.get('web_id') or (i + 1))] = {
                    'itemId': _s(it.get('itemId')),
                    'info': _dict(it.get('info')) or None,
                }
        return ctx.ok({'flag': 1, 'item': items, 'type': ctype,
                       'count': len(items), 'offset': _int(ctx.param('offset'), 0)},
                      '★ %s 客户端数据（%d 件）' % (ctype or '?', len(items)))

    if ep == 'get_ckitems_list_by_uid':
        uid = _s(ctx.param('uid') or '')
        ckname = _s(ctx.param('ckname') or '')
        listed = _storage_list(ctx, ckname)
        # ★ 她读 data.list（数组，元素 `{itemId, total, update_time}`）
        out = []
        for it in listed:
            if not isinstance(it, dict) or not it.get('itemId'):
                continue
            out.append({
                'itemId': _s(it.get('itemId')),
                'total': _int(it.get('total'), 1),
                'update_time': _int(it.get('update_time'), int(time.time())),
                'uid': uid,
            })
        return ctx.ok({'list': out, 'uid': uid, 'ckname': ckname},
                      '★ %s 物品列表（uid=%s，%d 件）' % (ckname or '?', uid, len(out)))

    return None
