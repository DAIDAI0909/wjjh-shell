# -*- coding: utf-8 -*-
# ================= 离线包路径根（fz_make_offline_bundle.py 自动注入） =================
# 手机上整个服务端就是一个目录，表在哪、状态写哪，全部相对包根算。
# （有的模块原来把绝对路径写死，本身没 import os —— 这里一并补上）
import os
import os as _osp


def _off_find_bundle(_f):
    """从模块所在目录往上找包根（认 fz_boot_server.py）。
    ★ fz_api/*.py 的 __file__ 在 <根>/fz_api/ 下，直接 dirname 会算错一层。"""
    _d = _osp.path.dirname(_osp.path.abspath(_f))
    for _ in range(6):
        if _osp.path.exists(_osp.path.join(_d, 'fz_boot_server.py')):
            return _d
        _u = _osp.path.dirname(_d)
        if _u == _d:
            break
        _d = _u
    return _osp.path.dirname(_osp.path.abspath(_f))


_OFF_BUNDLE = _off_find_bundle(__file__)
_OFF_FZ_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_fz')
_OFF_INK_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_ink')
_OFF_WORK_ROOT = _OFF_BUNDLE
# =====================================================================================
# ★ 2026-10-04 商城空货架修复：客户端资源表解析——PC 开发树优先，设备上自动回退
#   到包内 client_fz 副本（jhserver/client_fz = fangzhi_lua_dec 的同步拷贝）。
def _fz_res(*parts):
    base = os.path.join(_OFF_FZ_ROOT, 'res', 'script')
    if not os.path.isdir(base):
        base = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            '..', 'client_fz', 'res', 'script')
    return os.path.join(base, *parts)

# -*- coding: utf-8 -*-
"""家族 / 社交 / 好感 / 帮助 —— 1:1 还原放置江湖的这组接口。

契约**逐个读过她客户端源码**（不是猜的），出处写在每个分支的注释里：

| 接口                            | 上行参数（`HttpManager.lua` 行） | 她回调里读的 `data.xxx` | 出处 |
|---------------------------------|-----------------------------------|--------------------------|------|
| `get_gift`             | POST `{from_uid}`  (:2993) | `gainGifts`(**数组** `{gift,num}`) | `TeacherFamilyModule.lua:251` |
| `send_gift`            | POST `{to_uid,num,gift,addIntimacy,addPrestige}` (:2984) | `addIntimacy`(数) `addPrestige`(数) `totalIntimacy`(数) | `TeacherFamilyModule.lua:205` |
| `check_has_gift`       | POST `{from_uid}` (:3002) | **`data` 本身是数组**，元素 `{gift,num}` | `FamilyGroup.lua:276` |
| `get_user_intimacy`    | POST `{to_uid}` (:2940) | 原样转交（本模块回 `{intimacy,total,userid}`） | `FamilyGroup.lua:160` |
| `update_user_intimacy` | POST `{to_uid,intimacy,event}` (:2951) | 原样转交（回 `{intimacy,total,userid}`） | `FamilyGroup.lua:221` |
| `add_user_prestige`    | POST `{addPrestige,event}` (:3010) | `num`(数) `upper`(bool) `title`(数组) `total`(数) | `TeacherFamilyModule.lua:307` / `FamilyPrestige.lua:39-70` |
| `get_group_rank`       | GET (:2967) | **`data` 是数组**，元素 `{userid,kongfu,prestige,…}` | `RoleObserveModel.lua:1148` / `FamilyGroupRankLayer.lua:28-42` |
| `get_devote_list`      | POST `{type,menpai}` (:1275) | `list`(数组) `yuanbao`(数) | `FamilySalesInfoLayer.lua:320` / `SalesLayer.lua:631,826` |
| `get_devote_list_by_yuanbao` | POST `{order_id,type,menpai}` (:1302) | `list`(数组) `yuanbao`(数) | `SalesLayer.lua:659` |
| `get_help_document`    | GET (:1380) | `url`(**字符串**) | `SetupUI.lua:559` / `RoleObserveLayer.lua:539` |
| `get_history_notice`   | GET (:934)  | `url`(**字符串**) | `SetupUI.lua:623,881` |
| `get_wish_list`(1)     | GET `get_wish_list/1` (:1831) | 数组，元素 `{wish_type,create_time,wished_times}` | `ChineseValentineMyQiyuanDialog.lua:35,57` |
| `get_wish_list`(2)     | GET `get_wish_list/2` (:1825) | 数组，元素 `{name,real_menpai,wish_type,wished_users,portrait,yueka,lv,record_id,userid,sex,looks,head,polymorph}` | `ChineseValentineCheckListLayer.lua:25,59` |
| `upload_wish_data`     | POST `{wish_val,wish_type,wish_id}` (:1837) | `total_wish`(数) | `PrayTreeLayer.lua:180,190` |
| `record_wished_data`   | POST `{record_id,wish_userid}` (:1843) | 只看 errcode（奖励她客户端自己加） | `ChineseValentineCheckListLayer.lua:107` |
| `add_qixi_record`      | POST `{uploadStr}` (:2713) | 只看 errcode | `MatchLayer.lua:251` |
| `get_qixi_record`      | GET (:2704) | **二维数组** `[天][条]`，条 `{day,info,ratio}` | `QiXiUtil.lua:902` / `QiXiResultLayer.lua:114-133` |
| `realname_send`        | POST `{phone}`（`sendPhoneVerifyCode` :819） | `expired_time`(数) | `BindingIdcardLayer.lua:271` |
| `realname_auth`        | POST `{username,idcard,phone,code}`（`bindShiMingInfo` :825） | `isadult`(bool，回调参数名被当事件名用) | `BindingIdcardLayer.lua:316` |

═══════════════════════════════════════════════════════════════════════════
内容从她哪张表来（**没有一处是我编的数值**）
═══════════════════════════════════════════════════════════════════════════
1. `res/script/map/mapItemAttr/Items.lua`（按 itemId 索引，**649 张 `*canye` 残页**）
   —— 师门贡献点商人的全部货。她的物品表里已经写死了价格与归属：
     `{"id":"FleePainCagecanye","name":"渡恶清神残页","type":"秘籍残页",
       "priceUnit":"gongxiandian","buyPrice":1000,"salePrice":500,
       "zhaoId":"FleePainCage","dsc":"记载着「明王圣法」的特殊招式——「渡恶清神」的秘籍残页。"}`
   ⇒ `price`(=buyPrice) / `itemId` / `name` / `number`(1) / `icon` / `dsc` 全部来自这一条。
   她的客户端原话（`GiftPagePresenter.lua:320`）："门派武学主动技能残页可通过师门处寻找商人
   花费师门贡献点购买。" —— 所以商人货 = `priceUnit == "gongxiandian"` 的残页。
2. `res/script/book/bookSkills.lua["activeZhao"]` —— `pageName1/pageName2 → zhaoId`，
   用来给残页补一个 `zhaoId`（她 `BookSkillsHelper` 就是靠 `item.zhaoId` 找学习残页的）。
   ★ **这张表里没有门派字段**（只有 `type1=neigong/qinggong/bingqi`），所以做不了
     "这张残页属于哪个门派"的反查。
3. `res/script/family/family.lua["familys"]`（30 个门派，键=门派 id，
   每条 `{id,name,...}`：`{"id":"shaolin","name":"少林派"}`）
   —— 门派中文名 ↔ 门派 id，给 `add_user_prestige` 的头衔过滤 + 状态记录用。
   ★ 注意别拿 `others/familytype.lua` 当门派表：那其实是**家园户型房间图**
     （`huxing001` → `{1={name="屋外",roomId="fb319_01"},...}`），我第一版踩过这个坑。
4. `res/script/roleTitle/shengwangtouxian.lua["Sheet1"]`（126 条）
   —— 师门声望头衔（`{title,basicTitleId,shengwang,rank,family,weiwang,sex,skill,text}`）。
     `add_user_prestige` 回的 `title` 数组给的正是这里的 `title` 字段（她
     `FamilyPrestige:__updateOnlyTitle` 拿 `v.title == title` 去比对）。
5. `res/script/others/fgTemplate.lua["moban"]`（按门派一行）
   —— 舍友送礼模板：`item1..item20`（可选礼物）/ `haveGift` / `noGift` / `words*` / `getWords*`。
     这是她**客户端**读的；服务端 `get_gift` 发的 `gainGifts` 里的 `gift` 必须落在这一行 itemN 上。
6. 七夕祈福物品 `qixiqifu1..36` 的 `value/type/tape`：她客户端表
   `app/models/Action/ChineseValentine/CVModel.lua:78-117`（**客户端表，不是 res 表**）。
7. 七夕牵线结果 `info` 串的格式 `天数;左npc;右npc;等级;文本键`：`QiXiUtil:calResultStr`（:708）；
   等级→文本键→文本 在 `res/script/others/xiqi.lua`（`People` / `final`）。

═══════════════════════════════════════════════════════════════════════════
状态
═══════════════════════════════════════════════════════════════════════════
`work/social_family_state.json`，按 userid 分账户：

    {
      "users": {
        "<uid>": {
          "devote": 贡献点, "prestige": 师门声望, "titles": [...],
          "intimacy": {"<对方uid>": 亲密度},
          "sentGiftDate": {"<对方uid>": "20250101"},     # 每日一次送礼门（errcode=2）
          "pendingGift": {"<送礼人uid>": [{"gift","num"}]},
          "wishes": [{"record_id","wish_type","wish_id","value","create_time","create_ts",
                      "wished_users":[], "lv","name","real_menpai","userid","sex","looks",
                      "portrait","yueka","total_wish"}],
          "qixi": [ [ {"day","info","ratio"} ] ],        # 按天分页，跟她 createResultDataList 对齐
          "prestigeDay": {"date":"20250101","got":N}     # 每日上限判定（回 upper）
        }
      },
      "help_doc":   {"url": "..."},     # get_help_document
      "history_notice": {"url": "..."}  # get_history_notice
    }

═══════════════════════════════════════════════════════════════════════════
已知还没做到 1:1 的地方（**诚实列出，没有用假数据糊**）
═══════════════════════════════════════════════════════════════════════════
1. **师门商人的"当日随机货架 / 按门派挑货"没有权威表**。她 `get_devote_list` 的服务端
   算法（每天从池子里随机挑若干张残页、`id` 用商品自增号、`status` 标记是否买过）**只在
   服务端**，客户端和 res 表里都没有这份配置。而且"这张残页属于哪个门派"也**反查不出来**
   （`bookSkills.activeZhao` 无门派字段；`family.lua.familySkill` 给的是内功 id
   `shaolin→chanzongxinfa`，和残页的 `zhaoId` 对不上）。本模块因此**不做随机、不做门派
   过滤**：把 `Items.lua` 里所有 `priceUnit == "gongxiandian"` 的 **390 张残页**原样铺出来
   （`price`=她表里的 `buyPrice`、`name`/`type`/`unit`/`dsc` 全是她表里的真值），
   `status` 一律 0（=未购买，`SalesLayer:setSellerItems` 只显示 status==0 的行）。
   `menpai` 参数照收但**不参与过滤**（不猜）。要改成"每天随机 N 张"，把
   `SHOP_PICK_PER_DAY` 从 0 改掉即可（用当天日期当种子 ⇒ 同一天货架稳定）。
2. `get_devote_list` / `get_devote_list_by_yuanbao` 的 `yuanbao`（刷新价）她表里没有
   ⇒ 给 0（她 `SalesLayer:setTextDesc` 读 0 时显示"此次刷新免费"，是**正常文案**，不是错误）。
3. `devote`（师门贡献点）没有"获取"入口落在我的清单里（`add_devote_point` / `get_devote_point`
   是老代码 `fz_boot_server.py` 的，不属于我）。所以本模块只**读**自己 state 里的 `devote`；
   点数增减请由那两处去写。`add_user_prestige` 是首次真正开始记账的师门声望。
4. `get_group_rank`：同门名单来自 `get_user_group`（老代码里恒为空表）⇒ 只能回"自己"一条。
   这不是本模块能修的（改它会撞车）。
5. `get_history_notice`：她客户端只认 `data.url`，原版是运营后台填的 URL，她的资源表里
   **没有**这个字符串 ⇒ 默认 `{url: ""}`（她走 `PopText("没有历史公告")` 分支，是正常行为）。
   要放真公告就往 state 的 `history_notice.url` 写。
6. `realname_auth` 只做**格式校验**（姓名非空 / 身份证 18 位 / 手机 11 位 / 验证码 6 位），
   不接公安部实名接口；回 `isadult`（按身份证出生日期算，≥18 才算成年）。
   `realname_send` 的 `expired_time` = `GetTime() + 60`（她 `BindingIdcardLayer:update`
   就是按 60 秒倒数：`60 - (GetTime() - sendTime)`）。
7. `add_user_prestige` 的"今日上限"她表里没有数值 ⇒ 用常量 `PRESTIGE_DAILY_CAP = 500`
   （只影响 `upper` 这个 bool 提示，不影响 `num`/`total`/`title`）。
"""
import datetime
import json
import os
import random
import re
import sys
import time

NAME = 'social_family'
TITLE = '家族/社交/七夕/好感/帮助'
ENDPOINTS = [
    # —— 舍友送礼 / 收礼 ——
    'get_gift',
    'send_gift',
    'check_has_gift',
    # —— 好感度 ——
    'get_user_intimacy',
    'update_user_intimacy',
    # —— 师门声望 ——
    'add_user_prestige',
    # —— 进境排行 ——
    'get_group_rank',
    # —— 师门贡献点商人 ——
    # ★ `get_devote_list` 与 `get_devote_list_by_yuanbao` **两个都让给 `shop_store`**：
    #   它们是同一张贡献点商店货架（一个用贡献点、一个用元宝），`shop_store` 那边
    #   配套写了 `_sect_seed`/`_sect_currencies`/`get_sect_merit_store`，
    #   两半放在同一个模块里才不会出现"货架不一致"。本模块原先声明了它们，
    #   但 `dispatch` 按模块名排序取第一个 ⇒ `shop_store` 生效、这边是死代码。
    #   （处理函数 `_ep_get_devote_list*` 仍留在文件里，要收回来把名字加回本表即可。）
    # —— 帮助 / 公告 ——
    'get_help_document',
    'get_history_notice',
    # —— 七夕：祈福 ——
    'get_wish_list',
    'upload_wish_data',
    'record_wished_data',
    # —— 七夕：牵线 ——
    'add_qixi_record',
    'get_qixi_record',
    # —— 实名认证 ——
    'realname_auth',
    'realname_send',
]

STATE = 'social_family_state.json'

LUA_ROOT = _fz_res()
P_ITEMS = os.path.join(LUA_ROOT, 'map', 'mapItemAttr', 'Items.lua')
P_BOOKSKILLS = os.path.join(LUA_ROOT, 'book', 'bookSkills.lua')
P_TITLES = os.path.join(LUA_ROOT, 'roleTitle', 'shengwangtouxian.lua')
P_FAMILY = os.path.join(LUA_ROOT, 'family', 'family.lua')
P_FGTEMPLATE = os.path.join(LUA_ROOT, 'others', 'fgTemplate.lua')
P_XIQI = os.path.join(LUA_ROOT, 'others', 'xiqi.lua')

# 她客户端 `CVModel.lua:78-117` 的祈福物品表（qixiqifu1..36）。
# 字段：itemId -> (value, type, tape)。value/type 在客户端是**权威**的
# （`PrayTreeLayer:180` 直接把 itemAttr.value / itemAttr.type 当上行参数发给我们）。
PRAY_ITEMS = {}
for _i, _t in enumerate([
    'caiyuanguangjin', 'wugongyoucheng', 'huarongyuemao', 'jinglichongpei',
    'juexuezhaoshi', 'shangdenghaojiu', 'shenbingliqi', 'meishijiayao',
    'xuefuwuche', 'shimenxingwang', 'jianghumeiyu', 'jingmaiyoucheng',
]):
    PRAY_ITEMS['qixiqifu%d' % (_i + 1)] = (5, _t, 'qixiqiyuan1')
    PRAY_ITEMS['qixiqifu%d' % (_i + 13)] = (10, _t, 'qixiqiyuan2')
    PRAY_ITEMS['qixiqifu%d' % (_i + 25)] = (20, _t, 'qixiqiyuan3')
del _i, _t

# 她 `Role.lua:1934` 的 `getCHAttrName` 同口径中文名（提示文案用）
PRESTIGE_CN = '师门声望'

# 每日师门声望上限（她表里没写；只影响 `add_user_prestige` 的 `upper` 提示）
PRESTIGE_DAILY_CAP = 500

# 师门商人每天上架几张（0 = 全上，见文件头"已知还没做到"第 1 条）
SHOP_PICK_PER_DAY = 0

_COLOR_TAG = re.compile(r'(?:HI[A-Z]|NOR|YEL|RED|CYN|BLU|GRE|PUR|WHT|HIG|HIC|HIR|HIY|HIW)')

_TABLES = {}
_ITEM_BY_ID = None
_ZHAO_FAMILY = None
_FAMILY_CN2ID = None


# ===========================================================================
# 她自己的资源表（一律用 work/fz_luatable.py 解析，解析不了就空，绝不编）
# ===========================================================================


def _lua(path):
    if path in _TABLES:
        return _TABLES[path]
    val = {}
    try:
        try:
            import fz_luatable
        except ImportError:
            sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            import fz_luatable
        val = fz_luatable.load_lua_table(path) or {}
        if not isinstance(val, dict):
            val = {}
    except Exception:                          # noqa: BLE001
        val = {}
    _TABLES[path] = val
    return val


def _s(v, d=''):
    """统一成字符串（她很多 id 是数字，直接 `tostring` 比对）。"""
    if v is None:
        return d
    if isinstance(v, bool):
        return '1' if v else '0'
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v)


def _n(v, d=0):
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return d


def _clean(text):
    if not isinstance(text, str):
        return ''
    return _COLOR_TAG.sub('', text).strip()


def item_attrs():
    """`map/mapItemAttr/Items.lua`（按 itemId 索引）—— 师门残页/任务物品的家。"""
    return _lua(P_ITEMS)


def _items_by_id():
    global _ITEM_BY_ID
    if _ITEM_BY_ID is None:
        m = {}
        for k, v in item_attrs().items():
            if isinstance(v, dict):
                iid = _s(v.get('id') or k)
                if iid and iid not in m:
                    m[iid] = v
        _ITEM_BY_ID = m
    return _ITEM_BY_ID


def _zhao_family():
    """`book/bookSkills.lua["activeZhao"]` → {zhaoId: {'belong':n,'pages':[...]}}。

    她的 `belong` 是门派/来源标记，`pageName1/2` 是那张招式对应的残页 itemId。
    """
    global _ZHAO_FAMILY
    if _ZHAO_FAMILY is not None:
        return _ZHAO_FAMILY
    out = {}
    az = _lua(P_BOOKSKILLS).get('activeZhao') or {}
    for k, v in az.items():
        if not isinstance(v, dict):
            continue
        zid = _s(v.get('id') or k)
        pages = []
        for i in range(1, 6):
            pn = _s(v.get('pageName%d' % i))
            if pn:
                pages.append(pn)
        out[zid] = {'belong': _n(v.get('belong')), 'pages': pages,
                    'name': _s(v.get('name'))}
    _ZHAO_FAMILY = out
    return out


def _family_cn2id():
    """门派中文名 → 门派 id（`少林派` → `shaolin`）。

    ★ 权威表是 `family/family.lua["familys"]`（30 个门派，键就是门派 id，
      每条带 `{id, name}`：`{"id":"shaolin","name":"少林派",...}`）。
    ★ 我一开始拿 `others/familytype.lua` 当过门派表 —— **那是错的**：它其实是
      **家园户型房间图**（`huxing001..` → `{1={name="屋外",roomId="fb319_01"},...}`），
      拿它做映射会得到 `屋外→1` 这种垃圾映射。已修掉。
    取不到就退化成"原样小写"，绝不硬编门派列表。
    """
    global _FAMILY_CN2ID
    if _FAMILY_CN2ID is not None:
        return _FAMILY_CN2ID
    out = {}
    rows = _lua(P_FAMILY).get('familys') or {}
    if isinstance(rows, dict):
        for k, v in rows.items():
            if not isinstance(v, dict):
                continue
            rid = _s(v.get('id') or k)
            cn = v.get('name')
            if isinstance(cn, str) and cn and rid:
                out.setdefault(cn, rid)
    _FAMILY_CN2ID = out
    return out


def sect_key(menpai):
    """把 `menpai`（可能是 `少林派` / `shaolin` / 空）归一成她表里的门派 id。"""
    s = _s(menpai).strip()
    if not s:
        return ''
    hit = _family_cn2id().get(s)
    if hit:
        return hit
    return s.lower()


def canye_catalog():
    """师门贡献点商人的全部真货 —— `Items.lua` 里 `priceUnit == "gongxiandian"` 的残页。

    返回 [{'itemId','name','price','salePrice','type','unit','icon','dsc',
           'zhaoId','sect'}...]，**每个字段都来自她表**。

    ★ `sect` 这里**故意留空**：她的 `bookSkills.activeZhao` 里根本没有门派字段
      （只有 `pageName*/pageCount*/type*`），`family.lua["familys"].familySkill`
      给的是**内功 id**（`shaolin → chanzongxinfa`、`wudang → daoxuexinfa`），
      和残页的 `zhaoId` 对不上（`FleePainCagecanye.zhaoId = "FleePainCage"`，
      且 `activeZhao` 里连这条都没有）。也就是说"这张残页属于哪个门派"在她
      **客户端资源里无法反查** ⇒ 不猜，留空；`get_devote_list` 也就不按门派过滤
      （见文件头"已知还没做到"第 1 条）。
    """
    zhao = _zhao_family()
    page2zhao = {}
    for zid, info in zhao.items():
        for p in info['pages']:
            page2zhao.setdefault(p, zid)

    out = []
    for iid, v in _items_by_id().items():
        if _s(v.get('priceUnit')) != 'gongxiandian':
            continue
        out.append({
            'itemId': iid,
            'name': _s(v.get('name')),
            'price': _n(v.get('buyPrice')),
            'salePrice': _n(v.get('salePrice')),
            'type': _s(v.get('type')),
            'unit': _s(v.get('unit')),
            'icon': _s(v.get('icon')),
            'dsc': _s(v.get('dsc')),
            'zhaoId': _s(v.get('zhaoId')) or page2zhao.get(iid, ''),
            'sect': '',
        })
    out.sort(key=lambda d: d['itemId'])
    return out


def titles_res():
    """`roleTitle/shengwangtouxian.lua["Sheet1"]` —— 师门声望头衔表（126 条）。"""
    t = _lua(P_TITLES)
    sh = t.get('Sheet1') if isinstance(t, dict) else None
    return sh if isinstance(sh, dict) else {}


def titles_for(prestige, sect):
    """按声望/门派挑出她该解锁的 `title`（`rank == 0` 的"普通头衔"，服务器解锁）。

    她 `FamilyPrestige:rankCondition` 里 `needRank ~= 0` 直接 return false ⇒ 只有
    `rank == 0` 的才由服务器下发；`rank ~= 0` 的是排行榜头衔（另一套逻辑）。
    """
    got = []
    sk = sect_key(sect)
    for k, v in titles_res().items():
        if not isinstance(v, dict):
            continue
        if _n(v.get('rank')) != 0:
            continue
        need = _n(v.get('shengwang'))
        if need and prestige < need:
            continue
        fam = _s(v.get('family'))
        if sk and fam and sect_key(fam) != sk:
            continue
        t = _s(v.get('title'))
        if t and t not in got:
            got.append(t)
    return got


# ===========================================================================
# state
# ===========================================================================
def _now():
    return int(time.time())


def _today(ts=None):
    return time.strftime('%Y%m%d', time.localtime(ts if ts is not None else _now()))


def _fmt_time(ts):
    """她 `ChineseValentineMyQiyuanDialog:62` 是 `string.split(data.create_time," ")[1]`
    ⇒ 必须是**带空格的时间串**，给数字会 `attempt to index`/`split` 崩。"""
    try:
        return time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(_n(ts)))
    except (ValueError, OSError, OverflowError):
        return time.strftime('%Y-%m-%d %H:%M:%S')


def _state(ctx):
    st = ctx.load_json(STATE, None)
    if not isinstance(st, dict):
        st = {}
    if not isinstance(st.get('users'), dict):
        st['users'] = {}
    return st


def _save(ctx, st):
    ctx.save_json(STATE, st)
    return st


def _uid(ctx):
    """当前用户 id。

    她自己发的请求里 `userid` 既可能在**请求头**（`create_account` 那套），也可能在
    **正文**（`retryPostWithHeader` 会塞 `userid`）。两处都看。
    """
    for k in ('userid', 'userId', 'uid', 'UserId'):
        v = ctx.headers.get(k)
        if v:
            return _s(v).strip()
    v = ctx.param('userid') or ctx.param('uid')
    if v:
        return _s(v).strip()
    return '0'


def _user(st, uid=''):
    """取（必要时建）某个账户的记账块。"""
    uid = _s(uid or '0')
    u = st['users'].get(uid)
    if not isinstance(u, dict):
        u = {}
    # —— 归一化（她那边 id 有数字有字符串，统一成字符串键，避免 `1` vs `"1"` 对不上）——
    for key in ('intimacy', 'sentGiftDate', 'pendingGift', 'prestigeDay'):
        if not isinstance(u.get(key), dict):
            u[key] = {}
    for key in ('titles', 'wishes'):
        if not isinstance(u.get(key), list):
            u[key] = []
    if not isinstance(u.get('qixi'), list):
        u['qixi'] = []
    u['devote'] = _n(u.get('devote'))
    u['prestige'] = _n(u.get('prestige'))
    st['users'][uid] = u
    return u


def _intimacy(u, other):
    return _n(u['intimacy'].get(_s(other)))


def _set_intimacy(u, other, val):
    u['intimacy'][_s(other)] = max(0, _n(val))


# ===========================================================================
# 舍友送礼 / 收礼
# ===========================================================================
def _pending(u, from_uid):
    """「`from_uid` 送给我的礼物」列表（`{gift,num}`）。"""
    lst = u['pendingGift'].get(_s(from_uid))
    if not isinstance(lst, list):
        lst = []
        u['pendingGift'][_s(from_uid)] = lst
    return lst


def _shop_list(menpai=''):
    """师门商人的货架（**全部来自 `Items.lua`**，见文件头说明）。

    ★ `menpai` **故意不参与过滤** —— 见 `canye_catalog()` 的说明：这张残页属于哪个
      门派，她的资源表里反查不出来，所以不做"按门派挑货"的猜测。
      要按门派筛，就在 `canye_catalog()` 里补一份她**真的有的**映射（别硬编）。
    """
    cat = canye_catalog()
    if SHOP_PICK_PER_DAY and SHOP_PICK_PER_DAY > 0 and len(cat) > SHOP_PICK_PER_DAY:
        # 只在**她表里的真货**里挑，挑法用当天日期当种子（同一天同一货架）
        rnd = random.Random(int(_today()))
        cat = rnd.sample(cat, SHOP_PICK_PER_DAY)
        cat.sort(key=lambda d: d['itemId'])
    out = []
    for i, c in enumerate(cat):
        out.append({
            'id': i + 1,                    # 商品自增号（她 `SalesLayer:buy` 的 `itemData.id`）
            'itemId': c['itemId'],
            'name': c['name'],
            'price': c['price'],            # 她表里的 buyPrice
            'salePrice': c['salePrice'],
            'number': 1,
            'count': 1,                     # `setBagList2` 要 `v.count > 0`
            'status': 0,                    # 0 = 未购买（她 `setSellerItems` 只收 status==0）
            'itype': 4,                     # `HttpManager.lua:1269` 注释里的类型（秘籍残页）
            'type': c['type'],
            'unit': c['unit'],
            'icon': c['icon'],
            'dsc1': c['type'],
            'dsc2': c['dsc'],
            'dsc': c['dsc'],
            'zhaoId': c['zhaoId'],
        })
    return out


def _wish_public(uid, w, cur):
    return {
        'record_id': w.get('record_id'),
        'userid': _s(w.get('userid')),
        'name': _s(w.get('name') or ('侠客' + _s(w.get('userid')))),
        'real_menpai': _s(w.get('real_menpai')),
        'wish_type': _s(w.get('wish_type')),
        'create_time': _fmt_time(w.get('create_ts')),
        'wished_users': [x for x in (w.get('wished_users') or [])],
        'lv': _n(w.get('lv')),
        # 她 `HVDPresent` 读这些（缺 sex/looks 会 `tonumber(nil)`→0，但给全更稳）
        'sex': _s(w.get('sex')) or '男',
        'looks': _n(w.get('looks')),
        'portrait': w.get('portrait') or '',
        'head': w.get('head') or {},
        'polymorph': w.get('polymorph') or {},
        'yueka': bool(w.get('yueka')),
    }


def _qixi_days(u):
    """`u['qixi']` 是按天分的**二维**列表；她 `createResultDataList` 用 `ipairs(data)`
    再对每层 `ipairs(day_info)`，条里读 `{day,info,ratio}`。"""
    days = u.get('qixi')
    return days if isinstance(days, list) else []


# ===========================================================================
# 主分发
# ===========================================================================
def handle(ctx):
    ep = ctx.endpoint
    if ep not in ENDPOINTS:
        return None
    uid = _uid(ctx)
    st = _state(ctx)
    u = _user(st, uid)

    # -----------------------------------------------------------------------
    # 舍友：检查是否有人给我送礼
    #   她 `FamilyGroup:getGift`（:302）先 `checkHasGift`，回调里：
    #     `if MapIsEmpty(checkData) == false then for _,temp in ipairs(checkData) do
    #          list[temp.gift] = list[temp.gift] + temp.num`  ⇒ **data 必须是数组**
    #   给 `{}`(table) 时 `MapIsEmpty` 判空也走 else 分支，但给 `[]` 最干净。
    # -----------------------------------------------------------------------
    if ep == 'check_has_gift':
        frm = _s(ctx.param('from_uid') or ctx.param('userid') or _s(ctx.args[0] if ctx.args else ''))
        _save(ctx, st)
        return ctx.ok(_pending(u, frm),
                      '★ 舍友送礼检查（%d 件，来自 %s）' % (len(_pending(u, frm)), frm or '?'))

    # -----------------------------------------------------------------------
    # 舍友：收礼
    #   她 `TeacherFamilyModule.lua:251-268` 读 `data.gainGifts`，元素 `{gift,num}`
    #   （`giftList[gift.gift] = gift.num` ⇒ gift 是**物品 id 字符串**、num 是数字）
    # -----------------------------------------------------------------------
    if ep == 'get_gift':
        frm = _s(ctx.param('from_uid') or _s(ctx.args[0] if ctx.args else ''))
        gains = _pending(u, frm)
        u['pendingGift'][frm] = []
        _save(ctx, st)
        return ctx.ok({'gainGifts': [{'gift': _s(g.get('gift')), 'num': _n(g.get('num'), 1),
                                      'from_uid': frm} for g in gains if isinstance(g, dict)]},
                      '★ 收礼（%d 件，来自 %s）' % (len(gains), frm or '?'))

    # -----------------------------------------------------------------------
    # 舍友：送礼
    #   上行 `{to_uid,num,gift,addIntimacy,addPrestige}`（`HttpManager.lua:2984`）
    #   她回调（`TeacherFamilyModule.lua:211-235`）读：
    #     `serverData.addIntimacy`(数, `~=0` 时 PopText) `serverData.addPrestige`(数)
    #     `serverData.totalIntimacy`(数, 塞进 `updateLocalUserIntimacy`)
    #   失败分支 `errcode == 2` ⇒ 她弹"您今日已对X送过一次礼物了。"（:230）
    # -----------------------------------------------------------------------
    if ep == 'send_gift':
        to_uid = _s(ctx.param('to_uid') or ctx.param('userid') or '')
        gift = _s(ctx.param('gift') or ctx.param('itemId') or '')
        num = max(1, _n(ctx.param('num') or ctx.param('itemCount'), 1))
        add_intimacy = _n(ctx.param('addIntimacy'))
        add_prestige = _n(ctx.param('addPrestige'))
        if not to_uid:
            return ctx.fail('收礼人不存在', '★ 送礼：上行没带 to_uid')
        if not gift:
            return ctx.fail('礼物不存在', '★ 送礼：上行没带 gift')
        # 她客户端只让送 `fgTemplate["moban"][该门派].item1..item20` 里的东西；
        # 服务端只做"这件东西在她物品表里存在吗"的校验（表里没有就是非法 id）
        if gift not in _items_by_id() and not gift.startswith('canye'):
            return ctx.fail('没有这件礼物', '★ 送礼：%s 不在她的 Items.lua 里' % gift)
        # 每日一次（她客户端用 dayFlag 拦，服务端也要拦，否则改包可刷）
        today = _today()
        if u['sentGiftDate'].get(to_uid) == today:
            _save(ctx, st)
            return ctx.fail('您今日已对TA送过一次礼物了。',
                            '★ 送礼：今日已送过（errcode=2 门，她 :230 会弹这句）', errcode=2)

        u['sentGiftDate'][to_uid] = today
        # 礼物进"对方待收"槽（对方 uid 的 pendingGift[我] 追加）
        other = _user(st, to_uid)
        _pending(other, uid).append({'gift': gift, 'num': num,
                                     'from': uid, 'ts': _now()})
        # 亲密度：客户端把 addIntimacy 算好当参数发上来（`TeacherFamilyModule.lua:196-201`：
        #   期望礼物 random(30,70)，非期望 0）——服务端只在 0 时不动，>0 时才记账
        total = _intimacy(u, to_uid)
        if add_intimacy:
            total += add_intimacy
            _set_intimacy(u, to_uid, total)
            _set_intimacy(other, uid, total)
        # 声望：非期望 +5 / 期望 +20，同理由客户端传（:197-200）
        if add_prestige:
            u['prestige'] = _n(u.get('prestige')) + add_prestige
        u['titles'] = titles_for(_n(u.get('prestige')), ctx.param('menpai') or '')
        _save(ctx, st)
        return ctx.ok({'addIntimacy': add_intimacy, 'addPrestige': add_prestige,
                       'totalIntimacy': total, 'intimacy': total,
                       'prestige': _n(u.get('prestige'))},
                      '★ 送礼 %s x%d → %s（亲密度 +%d，声望 +%d）'
                      % (gift, num, to_uid, add_intimacy, add_prestige))

    # -----------------------------------------------------------------------
    # 好感度
    #   她 `FamilyGroup:getUserIntimacy`（:160）把 data 原样交给回调；
    #   实际读法在 `TeacherFamilyModule:509-515`：`intimacyList[roleData.userid]`
    #   ⇒ 本模块回对象 `{userid,intimacy,total}`（给数组也不会崩，但对象信息更全）。
    # -----------------------------------------------------------------------
    if ep == 'get_user_intimacy':
        to_uid = _s(ctx.param('to_uid') or _s(ctx.args[0] if ctx.args else ''))
        v = _intimacy(u, to_uid)
        _save(ctx, st)
        return ctx.ok({'userid': to_uid, 'intimacy': v, 'total': v},
                      '★ 好感度 %s = %d' % (to_uid or '?', v))

    if ep == 'update_user_intimacy':
        to_uid = _s(ctx.param('to_uid') or '')
        delta = _n(ctx.param('intimacy'))
        event = _s(ctx.param('event'))
        if not to_uid:
            return ctx.fail('目标不存在', '★ 更新好感度：上行没带 to_uid')
        v = _intimacy(u, to_uid) + delta
        _set_intimacy(u, to_uid, v)
        other = _user(st, to_uid)
        _set_intimacy(other, uid, v)
        _save(ctx, st)
        return ctx.ok({'userid': to_uid, 'intimacy': v, 'total': v,
                       'add': delta, 'event': event, 'clientIntimacy': v},
                      '★ 更新好感度 %s %+d → %d（%s）' % (to_uid, delta, v, event or '-'))

    # -----------------------------------------------------------------------
    # 师门声望
    #   上行 `{addPrestige,event}`（`HttpManager.lua:3010`）
    #   她 `FamilyPrestige:addUserPrestige`（:39-62）读：
    #     data.num（:311 `local addPrestige = data.num`，`~=0` 时 PopText）
    #     data.upper（:50 `if data.upper == true then PopText("今日可获得声望已经达到上限！")`）
    #     data.title（:69 `self:__updateOnlyTitle(prestigeData.title)`，**数组**，元素是 title 串）
    #     data.total（:70 `__updateNoramlTitle(prestigeData.total)`，**数字**，跟她头衔表比大小）
    #   ⇒ 四个字段**一个都不能少**（少了 nil 比较/遍历会崩在应答回调里 ⇒ UI 卡死）
    # -----------------------------------------------------------------------
    if ep == 'add_user_prestige':
        add = _n(ctx.param('addPrestige'))
        event = _s(ctx.param('event'))
        sd = u['prestigeDay']
        if sd.get('date') != _today():
            sd['date'] = _today()
            sd['got'] = 0
        sd['got'] = _n(sd.get('got')) + max(0, add)
        upper = sd['got'] >= PRESTIGE_DAILY_CAP
        u['prestige'] = _n(u.get('prestige')) + add
        menpai = _s(ctx.param('menpai'))
        u['titles'] = titles_for(_n(u.get('prestige')), menpai)
        _save(ctx, st)
        return ctx.ok({'num': add, 'total': _n(u.get('prestige')),
                       'title': [t for t in (u.get('titles') or [])],
                       'upper': bool(upper), 'event': event,
                       'todayGet': _n(sd.get('got'))},
                      '★ 师门声望 %+d → %d（%s，今日已得 %d）'
                      % (add, _n(u.get('prestige')), event or '-', _n(sd.get('got'))))

    # -----------------------------------------------------------------------
    # 进境排行
    #   她 `RoleObserveModel.lua:1154-1180` 用 `ipairs(rank)` 遍历，逐条读
    #     rank_data.userid / kongfu / prestige，再 `Helper:tableCover(rank_value, rank_data)`
    #   `FamilyGroupRankLayer:38-42` 又读 `rank.name`(串) `rank.kongfu`(数) `rank.prestige`(串)
    #   ⇒ **data 必须是数组**，元素带 name/kongfu/prestige/userid。
    #   同门名单来自 `get_user_group`（老代码恒空）⇒ 只能回自己一条。
    # -----------------------------------------------------------------------
    if ep == 'get_group_rank':
        u['titles'] = titles_for(_n(u.get('prestige')), _s(ctx.param('menpai')))
        _save(ctx, st)
        row = {
            'userid': _s(uid),
            'name': _s(ctx.headers.get('pkname') or ctx.param('name') or ('侠客' + _s(uid))),
            'kongfu': 0,                       # 她 `getLevelText(kongfu)`：0 → "停滞不前"
            'prestige': _s(_n(u.get('prestige'))),
            'total': _n(u.get('prestige')),
            'rank': 1,
        }
        return ctx.ok([row], '★ 进境排行（自己 1 条；同门名单接口恒空，见文件头说明）')

    # -----------------------------------------------------------------------
    # 师门贡献点商人
    #   她 `FamilySalesInfoLayer.lua:320-352` / `SalesLayer.lua:631-651`：
    #     data.list  → `role.zhaoShuXiang = data.list` → `setSellerItems`
    #                  （逐条读 `v.status`（只收 0）/ `v.itemId` / `v.count`；**
    #                    `setBagList2` 里 `if v.count > 0` ⇒ count 必须是数字**）
    #     data.yuanbao → `setTextDesc(yuanbao)`（0 ⇒ "此次刷新免费"）
    #   `HttpManager.lua:1269` 的注释是原版应答样例（id/itemId/itype/inde/name/price/
    #     number/dsc1/dsc2/share/icon/strong）—— 本模块按那份形状给全。
    # -----------------------------------------------------------------------
    if ep == 'get_devote_list':
        dtype = _n(ctx.param('type'), 1)
        menpai = _s(ctx.param('menpai'))
        _save(ctx, st)
        return ctx.ok({'list': _shop_list(menpai), 'yuanbao': 0, 'type': dtype,
                       'menpai': menpai, 'devote': _n(u.get('devote'))},
                      '★ 师门贡献点商人（%d 件真残页）' % len(_shop_list(menpai)))

    if ep == 'get_devote_list_by_yuanbao':
        # 上行 `{order_id,type,menpai}`；失败码她只 PopText（errcode 2=元宝不足 3=扣费失败
        # 4=刷新失败，见 `HttpManager.lua:1296-1300`）。刷新价她表里没有 ⇒ 免费（yuanbao=0）。
        menpai = _s(ctx.param('menpai'))
        _save(ctx, st)
        return ctx.ok({'list': _shop_list(menpai), 'yuanbao': 0,
                       'order_id': _s(ctx.param('order_id'))},
                      '★ 元宝刷新商人货架（%d 件，刷新价 0=免费）' % len(_shop_list(menpai)))

    # -----------------------------------------------------------------------
    # 帮助 / 历史公告
    #   她 `SetupUI.lua:559-568`、`RoleObserveLayer.lua:539-548`：
    #     `MapIsEmpty(data)==false and data.url ~= nil` → `GameHelpLayer:setUrl(data.url)`
    #   ⇒ `data.url` 必须是**字符串**（给数字会 `setUrl` 里崩）。
    #   历史公告同款（`SetupUI.lua:623`/`:881`），没有就 `PopText("没有历史公告")`。
    # -----------------------------------------------------------------------
    if ep == 'get_help_document':
        doc = st.get('help_doc')
        if not isinstance(doc, dict):
            doc = {}
        return ctx.ok({'url': _s(doc.get('url'))},
                      '★ 攻略客栈 URL（state.help_doc.url；她资源表里没有这个串，'
                      '所以默认空=她那边正常提示）')

    if ep == 'get_history_notice':
        hn = st.get('history_notice')
        if not isinstance(hn, dict):
            hn = {}
        return ctx.ok({'url': _s(hn.get('url'))},
                      '★ 历史公告 URL（state.history_notice.url；默认空='
                      '她 PopText("没有历史公告")，正常分支）')

    # -----------------------------------------------------------------------
    # 七夕：我的祈福记录（`get_wish_list/1`）
    #   她 `ChineseValentineMyQiyuanDialog.lua:35-65`：`ipairs(data)`，每条读
    #     data.wish_type（当 key 查 prayMap → 12 个愿望名之一）
    #     data.create_time（`string.split(...," ")` ⇒ **必须带空格的时间串**）
    #     data.wished_times（直接 `setString` ⇒ 数字/串都行，给数字）
    # -----------------------------------------------------------------------
    if ep == 'get_wish_list':
        which = _s(ctx.args[0]) if ctx.args else ''
        if which == '2':
            # 她 `ChineseValentineCheckListLayer.lua:59-104` 逐条读：
            #   name(串) real_menpai(串) wish_type(串) wished_users(**表**，`pairs` 里
            #   跟 `User:getUserId()` 比) portrait(串或表) yueka(bool) lv(**数**，
            #   `:113-114` 做 `lv + 50` / `lv * 10`) record_id userid
            #   + `HVDPresent` 的 sex/looks/head/polymorph
            rows = []
            for ouid, ou in st['users'].items():
                if not isinstance(ou, dict):
                    continue
                for w in (ou.get('wishes') or []):
                    if not isinstance(w, dict):
                        continue
                    if _s(w.get('userid')) == _s(uid):
                        continue          # 自己的许愿在 /1 里看
                    rows.append(_wish_public(ouid, w, uid))
            rows.sort(key=lambda d: -_n(d.get('record_id')))
            _save(ctx, st)
            return ctx.ok(rows, '★ 七夕·查看祈福榜（%d 条别人的愿）' % len(rows))

        rows = []
        for w in (u.get('wishes') or []):
            if not isinstance(w, dict):
                continue
            rows.append({
                'record_id': w.get('record_id'),
                'wish_type': _s(w.get('wish_type')),
                'wish_id': _s(w.get('wish_id')),
                'create_time': _fmt_time(w.get('create_ts')),   # 带空格的时间串
                'wished_times': _n(w.get('wished_times')),
                'total_wish': _n(w.get('total_wish')),
                'userid': _s(uid),
            })
        rows.sort(key=lambda d: -_n(d.get('record_id')))
        _save(ctx, st)
        return ctx.ok(rows, '★ 七夕·我的祈福（%d 条）' % len(rows))

    # -----------------------------------------------------------------------
    # 七夕：上祈福树
    #   上行 `{wish_val,wish_type,wish_id}`（她 `PrayTreeLayer.lua:170-172`：
    #   三个值全部来自她客户端 `CVModel:getPrayData()[itemId]` 的 value/type 与 itemId）
    #   她回调只读 `data.total_wish`（:190 `tonumber(data.total_wish) == 7` ⇒ 给数字）
    # -----------------------------------------------------------------------
    if ep == 'upload_wish_data':
        wish_id = _s(ctx.param('wish_id'))
        wish_type = _s(ctx.param('wish_type'))
        wish_val = _n(ctx.param('wish_val'))
        # 她客户端表是权威；表里有就以上行值为准（客户端就是这么发的），
        # 表里没有就说明上行被改过 ⇒ 用表里的真值兜底
        known = PRAY_ITEMS.get(wish_id)
        if known is None:
            return ctx.fail('祈福物品不存在',
                            '★ 七夕祈福：%s 不在她 CVModel.prayData 的 qixiqifu1..36 里' % wish_id)
        if not wish_val:
            wish_val = known[0]
        if not wish_type:
            wish_type = known[1]
        rid = int('%d%03d' % (_now() % 1000000, random.randint(0, 999)))
        total_wish = _n(u.get('wishes') and len(u['wishes'])) + 1
        u['wishes'].append({
            'record_id': rid,
            'wish_id': wish_id,
            'wish_type': wish_type,
            'value': wish_val,
            'tape': known[2],
            'create_ts': _now(),
            'wished_users': [],
            'wished_times': 0,
            'total_wish': total_wish,
            'userid': _s(uid),
            'name': _s(ctx.headers.get('pkname') or ('侠客' + _s(uid))),
            'real_menpai': _s(ctx.param('menpai')),
            'lv': _n(ctx.param('lv')),
            'sex': _s(ctx.param('sex')) or '男',
            'looks': _n(ctx.param('looks')),
            'portrait': _s(ctx.param('portrait')),
            'yueka': bool(_n(ctx.param('yueka'))),
        })
        _save(ctx, st)
        return ctx.ok({'total_wish': total_wish, 'record_id': rid, 'wish_type': wish_type},
                      '★ 七夕祈福上树（%s，第 %d 次）' % (wish_id, total_wish))

    # -----------------------------------------------------------------------
    # 七夕：祝福别人的愿
    #   上行 `{record_id,wish_userid}`（她 `ChineseValentineCheckListLayer.lua:107`）
    #   她回调**只看 errcode**，奖励她客户端自己加：
    #     `prizePot = userData.lv + 50` / `prizeMoney = userData.lv * 10`（:113-116）
    # -----------------------------------------------------------------------
    if ep == 'record_wished_data':
        rid = _n(ctx.param('record_id'))
        owner = _s(ctx.param('wish_userid') or ctx.param('userid'))
        target = None
        ou = st['users'].get(owner)
        if isinstance(ou, dict):
            for w in (ou.get('wishes') or []):
                if isinstance(w, dict) and _n(w.get('record_id')) == rid:
                    target = w
                    break
        if target is None:
            return ctx.fail('该祈福已不存在', '★ 七夕祝福：找不到 record_id=%s' % rid,
                            errcode=1)
        wu = target.get('wished_users')
        if not isinstance(wu, list):
            wu = []
        if _s(uid) in [_s(x) for x in wu]:
            return ctx.fail('你已经祝福过TA了', '★ 七夕祝福：重复祝福（同一 uid）', errcode=1)
        wu.append(_s(uid))
        target['wished_users'] = wu
        target['wished_times'] = _n(target.get('wished_times')) + 1
        _save(ctx, st)
        return ctx.ok({'record_id': rid, 'wished_times': _n(target.get('wished_times')),
                       'userid': owner},
                      '★ 七夕祝福（record=%s，被祝福 %d 次）'
                      % (rid, _n(target.get('wished_times'))))

    # -----------------------------------------------------------------------
    # 七夕：牵线上报
    #   上行正文是**一整串** `uploadStr`（她 `MatchLayer.lua:232,246-251`：
    #   `QiXiUtil:calResultStr` → `"天数;左npc;右npc;等级;文本键"`，末尾再拼一个时间戳）
    #   她回调**只看 errcode**（:253-262 之后全是本地奖励/动画）
    # -----------------------------------------------------------------------
    if ep == 'add_qixi_record':
        info = _s(ctx.param('uploadStr') or ctx.param('upload_str') or ctx.body_text)
        parts = [p for p in info.split(';') if p != '']
        if len(parts) < 5:
            return ctx.fail('数据格式有误',
                            '★ 七夕牵线：uploadStr 不是"天数;左;右;等级;文本键"（收到 %r）'
                            % info[:60], errcode=1)
        day = _n(parts[0], 1)
        days = _qixi_days(u)
        while len(days) < day:
            days.append([])
        row = {'day': day, 'info': ';'.join(parts[:5]),
               'ratio': _n(ctx.param('ratio'), 1)}
        days[day - 1].append(row)
        u['qixi'] = days
        _save(ctx, st)
        return ctx.ok({'day': day, 'levels': _n(parts[3]),
                       'record': row, 'total': sum(len(d) for d in days)},
                      '★ 七夕牵线上报（第 %d 天，等级 %s）' % (day, parts[3]))

    if ep == 'get_qixi_record':
        # 她 `QiXiUtil:createResultDataList`（:902）先 `ipairs(data)`（按天分页），
        # 再 `ipairs(day_info)`，逐条 `string.split(result_info.info,";")` 取
        # `[2]/[3]` 去 `qixi_res.People` 查 npcName1/npcName2，`[4]`=level `[5]`=textIndex，
        # 另有 `result_info.day` 和 `result_info.ratio`（`QiXiResultLayer.lua:122-133`）。
        days = _qixi_days(u)
        _save(ctx, st)
        return ctx.ok(days, '★ 七夕结果（%d 天 / %d 条牵线）'
                      % (len(days), sum(len(d) for d in days)))

    # -----------------------------------------------------------------------
    # 实名认证
    #   `sendPhoneVerifyCode`（:819）POST `{phone}` ⇒ 她 `BindingIdcardLayer.lua:276`
    #     读 `data.expired_time`，随后 `update()` 按 **60 秒**倒数（:339）
    #   `bindShiMingInfo`（:825）POST `{username,idcard,phone,code}` ⇒ :322 读
    #     `data.isadult`，并 `self:callCallbacks(isadult)` 当事件名
    #     （`ControllLayer.lua` / `MenuLayer.lua` 里是 `eventName == "成年"`/"未成年" 这套）
    # -----------------------------------------------------------------------
    if ep == 'realname_send':
        phone = _s(ctx.param('phone'))
        if not re.match(r'^\d{11}$', phone):
            return ctx.fail('手机号格式有误', '★ 实名·发码：手机号不是 11 位数字（%r）' % phone,
                            errcode=1)
        return ctx.ok({'expired_time': _now() + 60, 'phone': phone},
                      '★ 实名·发送验证码（60 秒有效，与她 update() 的倒数一致）')

    if ep == 'realname_auth':
        username = _s(ctx.param('username'))
        idcard = _s(ctx.param('idcard'))
        phone = _s(ctx.param('phone'))
        code = _s(ctx.param('code') or ctx.param('verify_code'))
        if not username:
            return ctx.fail('请填写正确的姓名', '★ 实名·认证：姓名为空', errcode=1)
        if not re.match(r'^\d{17}[\dXx]$', idcard):
            return ctx.fail('请填写正确的身份证号码',
                            '★ 实名·认证：身份证不是 18 位（%r）' % idcard, errcode=1)
        if not re.match(r'^\d{11}$', phone):
            return ctx.fail('请填写正确的手机号码',
                            '★ 实名·认证：手机号不是 11 位（%r）' % phone, errcode=1)
        if not re.match(r'^\d{4,6}$', code):
            return ctx.fail('请填写正确的验证码',
                            '★ 实名·认证：验证码不是 4~6 位数字（%r）' % code, errcode=1)
        isadult = False
        try:
            birth = datetime.date(int(idcard[6:10]), int(idcard[10:12]), int(idcard[12:14]))
            today = datetime.date.today()
            age = today.year - birth.year - ((today.month, today.day) < (birth.month, birth.day))
            isadult = age >= 18
        except ValueError:
            return ctx.fail('请填写正确的身份证号码',
                            '★ 实名·认证：身份证生日段非法（%r）' % idcard, errcode=1)
        st.setdefault('realname', {})[_s(uid)] = {
            'name': username, 'idcard': idcard, 'phone': phone,
            'isadult': isadult, 'ts': _now(),
        }
        _save(ctx, st)
        return ctx.ok({'isadult': ('成年' if isadult else '未成年'),
                       'adult': bool(isadult), 'name': username},
                      '★ 实名·认证成功（%s）' % ('成年' if isadult else '未成年'))

    return None
