# -*- coding: utf-8 -*-
# ================= 离线包路径根（fz_make_offline_bundle.py 自动注入） =================
# 手机上整个服务端就是一个目录，表在哪、状态写哪，全部相对包根算。
# （有的模块原来把绝对路径写死，本身没 import os —— 这里一并补上）
import os
import os as _osp


def _off_find_bundle(_f):
    """从模块所在目录往上找包根（认 fz_boot_server.py）。
    ★ fz_api/*.py 的 __file__ 在 <根>/fz_api/ 下，直接 dirname 会算错一层。"""
    _d = _osp.path.dirname(_osp.path.abspath(_f))
    for _ in range(6):
        if _osp.path.exists(_osp.path.join(_d, 'fz_boot_server.py')):
            return _d
        _u = _osp.path.dirname(_d)
        if _u == _d:
            break
        _d = _u
    return _osp.path.dirname(_osp.path.abspath(_f))


_OFF_BUNDLE = _off_find_bundle(__file__)
_OFF_FZ_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_fz')
_OFF_INK_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_ink')
_OFF_WORK_ROOT = _OFF_BUNDLE
# =====================================================================================
# ★ 2026-10-04 商城空货架修复：客户端资源表解析——PC 开发树优先，设备上自动回退
#   到包内 client_fz 副本（jhserver/client_fz = fangzhi_lua_dec 的同步拷贝）。
def _fz_res(*parts):
    base = os.path.join(_OFF_FZ_ROOT, 'res', 'script')
    if not os.path.isdir(base):
        base = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            '..', 'client_fz', 'res', 'script')
    return os.path.join(base, *parts)

# -*- coding: utf-8 -*-
"""content_fill —— 补掉「结构性空壳」的那批接口（1:1 还原，内容一律取她自己的表）。

来源：`work/tmp_content_audit.py` 扫出来的「接口通了、应答是空列表」。
本模块**只**声明下面这 20 个接口，全部先确认过 `fz_api` 里没有别的模块声明
（`settle_overdue_dream` 已被 `homeland_land` 声明 ⇒ 本模块**不碰**，见文末「不归我」）。
第十一轮第二段把**师门商人的「购买」链 + 贡献点账**（`buy_teacher_good` /
`update_menpai_gongxiangdian` / `get_devote_point` / `add_devote_point`）也收进来了
—— 它们原来是 `fz_boot_server.py` 的空动作，而货架在本模块，**放一起才不会货票两张皮**；
详见第四节。

============================================================================
一、契约表（逐个读她解密的客户端源码读出来的，URL 取 `extends/Http/HttpManager.lua`）
============================================================================
| 接口(URL 末段) | 上行 | 她读的 `data.字段`（类型） | 出处 |
|---|---|---|---|
| `get_teacher_shop` | POST `{type("normal"/"refresh"),menpai}` | `goods_list`(数组 `{id,itemId,name,dsc,buyPrice,salePrice,number,priceUnit,unit,status}`) `need_yuanbao`(数) | `views/layer/TeacherTaskLayer/TeacherTaskSales/TeacherTaskSalesLayer.lua:413-460`(:419 `v.status==0`) + `:254-278`(:271 `.price` / `:274` `.buyPrice` / `:263` `.name` / `:305` `.dsc`) |
| `get_npc_store_list/<npcId>` | GET（npcId 在 URL 里） | `list`(数组 `{itemId,price,unit}`) `point`(数，当前币额) `unit`(串，币种) | `models/Chapman/Chapman.lua:288-344`(:304/:313/:330) `views/layer/MapLayer/NpcMapBagLayer.lua:1335-1392`(:1348/:1355) |
| `get_activity_list/<type>` | POST `{type,currencyVersion}` | `list`(数组**串** = 活动名) `isSign`(串 "Y"/"N") `isClick`(串 "Y"/"N") | `views/layer/MainLayer.lua:205-217`(:207) + `views/ui/TitleUI.lua:434` + `views/layer/ActionLayer/ActionLayer.lua:1186-1193`(`getIsShow` 拿 `action.name` 跟 `showList.list` 的**元素**比) |
| `get_festivalmap_info` | POST `{groupId}` | **数组**，元素 `{dayTime(数),finalTime(数)}` | `presenters/ChallengeMap/FestivalMapDetailPresenter.lua:39-40/:208/:213` |
| `get_first_festival_gift` | GET | `status`(数：**0 未充值 / 1 可领 / 2 已领**) | `views/layer/ActionLayer/NewShouChongLayer.lua:197-233`(:207/:217/:223) 等三个同款面板 |
| `receive_first_festival_gift` | POST `{order_id,key=1}` | —（只看 errcode） | `NewShouChongLayer.lua:257-266` |
| `get_multi_festival_gift_list` | GET | `list`(**表**：档位金额串→状态数 0未达成/1可领/2已领) `shopping_money`(数) `gift_list`(**表**：档位金额串→数组) `config`(对象 `{strategy_id,base}`) | `views/layer/ActionLayer/NewLeiJiChongZhiLayer.lua:82-98` + `:123-135` + `:581-615` |
| `receive_multi_festival_gift` | POST `{key,order_id,item_id?}` | `itemId`(串) | `NewLeiJiChongZhiLayer.lua:373-396`(:379/:389) |
| `init_test_festival_data` | POST `{key}` | —（只看 errcode） | `HttpManager.lua:1059-1062`（客户端**零调用点**，是原版测试后门） |
| `clean_test_festival_data` | POST | —（只看 errcode） | `HttpManager.lua:1065-1068`（同上） |
| `get_teacherBuild_items` | POST `{familyId}` | **数组**，元素 `{itemId(属性名),count(数),countLimit(数)}` | `presenters/TeacherBuild/TeacherBuildItemPresenter.lua:34-49`(:37/:38) |
| `get_teacherFeat_info` | POST `{familyId}` | `list`(数组 `{id,state(数0未达成/1可领/2已领)}) `featscount`(数) | `models/TeacherBuildSystem/TeacherBuildSystem.lua:1019-1037`(:1025/:1027) + `presenters/TeacherBuild/TeacherFeatPresenter.lua:57-171`(:58/:84-93/:108/:118-145) |
| `get_teacherFeat_reward` | POST `{familyId,featId,dataVer}` | `featscount`(数) `reward`(数组 `{id,num}`，`id` 是 shoplist 键) `dataVer`(数) `msg`(串) | `TeacherBuildSystem.lua:1045-1068`(:1053/:1059) |
| `get_sectRevitalization_info` | POST `{familyId}` | `buildReward`(数组 `{id,number}`) `buildConditionText`(串，可空) `buildingList`(数组 `{buildTypeId,state(数),buildName,buildLv,buildCurrentExp,buildMaxExp}`) | `models/TeacherBuildSystem/TeacherBuildPromote/TeacherBuildPromote.lua:34-55`(:36/:37/:42) + `:97-126` + `presenters/TeacherBuild/TeacherBuildPromotePresenter.lua:45-115`(:63-68/:103-108/:127-131) |
| `get_sectRevitalization_reward` | POST `{familyId,buildTypeId}` | —（只看 errcode） | `TeacherBuildPromote.lua:81-95` + `TeacherBuildPromotePresenter.lua:78-91` |
| `fresh_task_by_yuanbao` | POST `{yuanbao}` | —（只看 errcode；她拿到 errcode=0 后**本地重掷**师门任务列表） | `views/layer/TeacherTaskLayer/ReceiveTeacherTaskLayer.lua:263-275`(:268 `TeacherTask:initTeacherTask()`) |

★ 所有给客户端的商品 **id 一律是 `store/shoplist.lua["Sheet1"]` 的键**（"300004" 这种），
  不是 `itemId` —— `models/Store/GoodsHelper.lua:34-44` 查的就是那个键，拿 `itemId` 过去
  直接 `error()`，被 xpcall 吞掉 ⇒ 面板冻住。

============================================================================
二、内容取自她哪张表
============================================================================
* `store/shoplist.lua["Sheet1"]`（2228 件真商品）—— 一切货源与 `id`/`icon`/`itemId`。
* `store/storeItem.lua["shangchengwupin"]`（194 件）—— 真价 `buyPrice` / `salePrice` / `priceUnit`。
* `store/storeConfig.lua["Sheet1"]`（70 个商人）—— `displaycurrency`（真币种）/ `shownums` / `Refreshtype`。
* `challengeMap/mapInfo.lua["map"]`（155 个副本，其中 `type==2` 的 136 个是节庆副本）——
  `daily` / `activity` / `section`：`get_festivalmap_info` 的 `dayTime`/`finalTime` 计数上限。
* `family/sectBuildInfo.lua` + `family/sectBuildDonate.lua` + `family/sectBuildEffect.lua` +
  `family/sectLevel.lua` —— 师门建筑的等级/效果/捐献档位（与 `fz_api/teacher_build.py` **同一份存档**
  `work/teacherbuild_state.json`，不另记）。
* `family/featInfo.lua`（名绩：`featsid/label/camp/title/text/awardtext/awards/Completion`）
  + `family/featClassLevel.lua`（职阶：`featscount` 门槛）—— 师门名绩面板。
* `views/layer/ActionLayer/ActionLayer.lua` 的 `initActionList.funcTab`（**94 个**活动名）——
  `get_activity_list` 的名单合法性校验（只放行她 `funcTab` 里真有的名字，
  否则 `ActionLayer` 点进去无界面）。
* `views/layer/ActionLayer/LeiJiChongZhiLayer.lua:12-117` 的 `rewardList` —— 累计充值 5 个档位
  （30/100/300/500/800）的**真实奖励内容**（她客户端里那张写死的表）。
* `views/layer/ActionLayer/NewShouChongLayer.lua:13-41` 的 `rewardList` + `minaju` —— 首充奖励。
* 货币/物品走 `fz_api/items_currency.py` 的 `get_count/add_count/spend/grant/get_currency/
  add_currency/currency_name/currency_limit/goods()`（**不另造第二份账**）。

============================================================================
三、诚实说明：哪些是「确定性推算」、哪些还没做到 1:1
============================================================================
1. **师门商店 / 市侩游商的货架排布不是原版配置**。原版货架在她服务端 DB 里，
   `storeConfig.goodsshelf` 给的只是货架号（10000–10069），这个号在她 1 万多个
   `res/script/**` 里查不到内容表（`misc_extra.py` 的 docstring 第 1 条已核实）。
   本模块用 `shoplist` 的**真商品**按 `md5(npcId|货架号|刷新次数)` 做**确定性抽签**：
   同一商人永远同一批货，不重启不换脸。**商品是真的，排布是推算的**。
2. **价格**：优先用 `storeItem.buyPrice`（她表里写的真价）；她表里没价的按商品 `viewtype`
   档位给稳定基数。`get_npc_store_list` 的 `price` 原版在服务端，客户端只负责显示。
3. **累计充值（`get_multi_festival_gift_list`）的档位与奖励内容来自她客户端写死的
   `LeiJiChongZhiLayer.rewardList`**（30/100/300/500/800 五档，真物品 id）。
   其中 `chunjieleiji1` / `mianju1010` / `mianju1011` 三个 id **不在 `store/shoplist.lua` 里**
   （它们是 `map/mapItemAttr/Items.lua` 与 `map/mapItemAttr/mask.lua` 的条目，
   客户端 `Item:getOneItemByKey` 能认，但 `GoodsHelper:getGoodsResClass` 查的是 shoplist）
   ⇒ 这三件**不能走 `reward[{id,num}]` 的服务器发放通道**，本模块把它们换成 shoplist 里
   **同类的真货**（`chunjieleiji2`=200056 / `mianju1013`=100048 / `mianju1012`=100084），
   并在 note 里点名。**这是替代，不是原版数值，不谎称 1:1。**
4. **`shopping_money`（累计充值额）本服没有真实充值通道**（`shop_store.py` docstring 第 1/2 条：
   充值商品表与支付签名都在官方 SDK 侧）⇒ 它取 `work/misc_extra_state.json` 的
   `recharge.totalRecharge`（`misc_extra` 那份累充账本），没有就是 0。**不假装充值成功。**
   同理 `get_first_festival_gift` 的 `status`：累充额 > 0 才是"去充值"之后的 1（可领），
   领过就是 2，否则 0（面板显示「去充值」并按设计跳商城）。
5. **`get_activity_list` 的红点**：`MainLayer.lua:207` 是
   `if data.isSign == "N" or data.isClick == "Y" then 亮红点`。本模块按
   `content_fill_state.json` 的 `signin_signed` 作答（默认未签 ⇒ `isSign="N"` ⇒ 红点亮），
   点过活动面板后写完 `signin_signed` 就灭。**这是"红点状态"，不是奖励发放**。
6. **`init_test_festival_data` / `clean_test_festival_data`** 是她原版的测试后门
   （**客户端零调用点**，全量 grep 过）。本模块让它们**真的**在
   `content_fill_state.json` 上建/清测试账，而不是空回一个 0 —— 但要说清：
   **它们影响的只是本模块自己的测试账，不会篡改玩家存档或货币。**
7. **师门名绩的 `state` 是保守判定**：`featInfo.Completion` 里是
   `[["sgbpoint", 190]]` 这类**累计值**门槛（同一 `label` 档位递增），所以按
   "sgbpoint ≥ 门槛 ⇒ 可领" 判定；`featscount` 从 `teacherbuild_state.json` 读，领了就加。
   判据全部来自她表里的 `Completion`，**没有自己编阈值**。
8. **`get_sectRevitalization_info` 的 `buildReward`（今日可分配）** 原版是服务端每日额度，
   客户端/资源表里没有这个数 ⇒ 取她表里**每个建筑档位 `cescalation`（每日可分配修筑度）**
   的最小档（表里 150/384/… 的真值），两个资源是 `upresources`(修筑度) 与 `gbpoint`(门派昌盛度)。
   面板会真的显示出来，但**发放额度不是原版 DB 值**。
9. **`fresh_task_by_yuanbao`**：她只看 errcode，拿到 0 就自己
   `TeacherTask:initTeacherTask()` 重掷列表 ⇒ 本模块**只**扣她上行的 `yuanbao`（真扣，
   不够回 errcode≠0）并回 0，不伪造任务列表（列表本身是客户端本地掷的，
   服务端那份 `fresh_task_by_yuanbao` 的原版语义就是"扣钱放行"）。
10. **跟 `fz_api/teacher_build.py` 的关系**：师门建材数量 / 名绩点数 / 建筑修筑度
    **一律读它那份 `work/teacherbuild_state.json`**（结构是 `{familyId: {..., builds:{buildingId:{...}}}}`），
    本模块**不另记一份师门资源**。`get_sectRevitalization_reward` 是唯一会**写**它的接口
    （分配修筑度 → `builds[buildTypeId].buildTeacherExp`；门派昌盛度 → 门派节点 `gbpoint`），
    写的是她客户端真会读的字段（`TeacherBuildSystem:getBuildByExp` / `getSectLevelData`），
    并且**同一天不重复发**（`content_fill_state.json` 的 `revitalization` 记账）。
    两边读同一份存档 ⇒ 面板数值和按钮结果不会打架（`teacher_build.py` docstring 的
    第 3 条要求的就是这个）。

============================================================================
四、师门商人的「购买」链（**第十一轮第二段补完**，原来这一环是空的）
============================================================================
`get_teacher_shop` 把货架摆出来之后，点「购买」本来是**没反应**的：上游
`fz_boot_server.py` 的 `buy_teacher_good` 回的是"什么都没有"的 data（审计判 `empty`），
而面板那条路径**只看 errcode** ⇒ 界面不动。本节四个接口把它接通。

| 接口 | 上行 | 她读的 `data.字段` | 出处 |
|---|---|---|---|
| `buy_teacher_good` | POST `{rid}` | —（只看 `errcode`；`!=0` 就 `PopText(errmsg)`） | `TeacherTaskSalesLayer.lua:109-157` |
| `update_menpai_gongxiangdian` | POST `{order_id,itemId,points,orderInfo}` | —（同上） | `SalesLayer.lua:703-729` + `TeacherTaskSalesLayer.lua:497-522` |
| `get_devote_point` | GET | `dev_point`(数) `has_reward`(**串** "Y"/"N") | `TeacherTaskSalesLayer.lua:399-410` + `TeacherTaskLayer.lua:107-124` + `TeacherLayer.lua:443` + `SalesLayer.lua:586` |
| `add_devote_point` | POST `{type,point}` | `get_point`(数) `msg`(串) | `TeacherTaskLayer.lua:227-235`(:230 `+data.get_point`) + `FamilySalesInfoLayer.lua:228-241` |

★★ **`rid` 不是 `id`，是"**当前应答里 `goods_list` 的数组下标**"**
   （`TeacherTaskSalesLayer.lua:422` `v.index = k`，`:129` 上行 `bagItem.index`）。
   她买走一件后本地 `popItemByIndex`，下一次上行的号会**塌缩** ⇒ 服务端若按"商品键"
   记 `rid` 就会被错位顶掉一件货。本模块因此把 `id` 编成**只数在售行的连续号**
   （`_teacher_rows` 的 `i` 只对 `status==0` 的行自增），`rid == index == 在售行数`，
   两边永远同一个数（这是本节最容易翻车的地方，已按客户端原文对齐）。

**贡献点只有一份账**：`work/homeland_state.json["currency"]["gongxiandian"]`，
经 `items_currency.get_currency/add_currency` 读写 —— 与 `map_shop` 的声望商人
（`map_shop.py:770/794-800` 同键）**同一个钱包**，不另造第二份。

**每日上限 4000 的出处**：她 `TeacherTaskLayer.lua:33` 把 "已获得/上限" 写死成
`"...".."/4000"`，`ReceiveTeacherTaskLayer.lua:242` 写 "已获得贡献点：.../4000"，
`teacherTask.lua:684` 是 `point = math.min(4000 - ContributionPoint, point)`
⇒ 4000 是**客户端承认的每日师门任务贡献点上限**（不是编的数）。
`add_devote_point` 按这个上限截断（`point` 由客户端掷出、服务端只做封顶与记账，
因为 `teacherTask.lua:147-172` 的档位区间 100~1200 是客户端自己算的）。

============================================================================
五、★ 不归我（别人已声明，**没碰**）
============================================================================
* `settle_overdue_dream` —— 已被 `fz_api/homeland_land.py` 声明（`_YIELD` 让位规则同源），
  本模块**不声明**，避免撞车。
* `get_propList/1`、`get_propList/2` —— **审计误判**：它是"玩家**已拥有**的创作/改良道具"
  （客户端 `addProp(propId,count)`），一件都没有时回空数组是**正确**的。**本模块不改它。**
* `get_teacherBuild_tasks` / `get_teacherBuild_donateInfo` —— 由 `fz_api/teacher_build.py`
  负责，**没碰**。
* 审计里同面板的 `get_same_menpai_user_list`（指派任务）/ `get_sectGuidance_info`（师门指点）
  也不在我的清单里，**没碰**（它们仍在 `fz_boot_server.py` 的浅分支上）。

============================================================================
六、本模块的状态（`work/content_fill_state.json`）与**别人**的存档
============================================================================
本模块自己只记"货架/红点/领取"这类**本模块独有的进度**：

    teacher_shop   —— {menpai: {week, keys:[shoplist 键], bought:{键: 数}}}
    npc_store      —— {npcId: {day, keys:[shoplist 键]}}
    activity       —— {signin_signed: 0/1, seen:{活动名: 时间戳}}
    festival       —— {first_claimed: 0/1, multi_claimed:[档位…], test:{…}}
    feat           —— {claimed:[featsid…], featscount: 数}
    revitalization —— {userid: 最近一次分配的"天"}
    devote         —— {last_day: 数, today: 数, order: {order_id: {"itemId":…,"points":…}}}
                      ↑ 每日师门贡献点**发放**账（上限 4000）；`order` 是
                        `update_menpai_gongxiangdian` 的 order_id 幂等表（防重复扣）

**只读不写**别人的存档：
  * `work/teacherbuild_state.json`（`fz_api/teacher_build.py`）—— 建材数量 / 名绩点数 /
    建筑等级；**唯一例外**是 `get_sectRevitalization_reward` 会把分配结果写回去（见第 10 条）。
  * `work/misc_extra_state.json`（`fz_api/misc_extra.py`）—— 累充额 `recharge.totalRecharge`。
**钱和物品**一律走 `fz_api/items_currency.py`（`items_state.json`），本模块不另造第二份账。
"""
import hashlib
import json
import os
import re
import time

NAME = 'content_fill'
TITLE = '空壳补全（师门商店+购买/贡献点账/市侩游商/活动红点/节庆/师门建材/名绩/振兴门派/刷新任务）'

ENDPOINTS = [
    # A. 空货架
    'get_teacher_shop',
    'get_npc_store_list',
    # A2. 师门商人的「购买」链 + 贡献点账（第十一轮第二段补完，见 docstring 第四节）
    'buy_teacher_good',
    'update_menpai_gongxiangdian',
    'get_devote_point',
    'add_devote_point',
    # B. 活动红点
    'get_activity_list',
    # C. 节庆那一族
    'get_festivalmap_info',
    'get_first_festival_gift',
    'get_multi_festival_gift_list',
    'receive_first_festival_gift',
    'receive_multi_festival_gift',
    'init_test_festival_data',
    'clean_test_festival_data',
    # D. 其它被判"结构性空"的
    'get_teacherBuild_items',
    'get_teacherFeat_info',
    'get_teacherFeat_reward',
    'get_sectRevitalization_info',
    'get_sectRevitalization_reward',
    'fresh_task_by_yuanbao',
]

# 本模块**不声明**（别人已实现，抄 `shop_store.py` 的做法只留说明，避免误报撞车）
ENDPOINTS_DELEGATED = [
    'settle_overdue_dream',      # → `fz_api/homeland_land.py`
]

STATE = 'content_fill_state.json'

RES = _fz_res()
APP = os.path.join(_OFF_INK_ROOT, 'src', 'app')

P_SHOPLIST = os.path.join(RES, 'store', 'shoplist.lua')
P_STOREITEM = os.path.join(RES, 'store', 'storeItem.lua')
P_STORECONF = os.path.join(RES, 'store', 'storeConfig.lua')
P_MAPINFO = os.path.join(RES, 'challengeMap', 'mapInfo.lua')
P_FAMILY = os.path.join(RES, 'family')
P_ACTIONLAYER = os.path.join(APP, 'views', 'layer', 'ActionLayer', 'ActionLayer.lua')
P_LEIJI = os.path.join(APP, 'views', 'layer', 'ActionLayer', 'LeiJiChongZhiLayer.lua')
P_SHOUCHONG = os.path.join(APP, 'views', 'layer', 'ActionLayer', 'NewShouChongLayer.lua')
P_TEACHERBUILD_STATE = 'teacherbuild_state.json'      # `fz_api/teacher_build.py` 的那份存档
P_MISC_STATE = 'misc_extra_state.json'                # `fz_api/misc_extra.py` 的累充账本

DAY = 86400
WEEK = 7 * DAY

# 她 `TeacherTaskSalesLayer:initAll` 的默认货币（:48 `self.currency = "gongxian"`），
# 对应 `items_currency` 的师门贡献点。
GONGXIANDIAN = 'gongxiandian'
YUANBAO = 'yuanbao'
MONEY = 'money'

# 她 `Role.lua:1980-1985` 的建材属性名（`getBuildItemName(id)` → `role:getCHAttrName(id)`）
BMATERIALS = ('bmaterials1', 'bmaterials2', 'bmaterials3', 'bmaterials4',
              'bmaterials5', 'bmaterials6')
# `sectBuildInfo` 建筑 101「储宝库」1 级 `effecttext` 的真值："建筑材料储存上限到360个"；
# 表里读不到时的兜底（不是编的，就是她 1 级的那个数）。
MATERIAL_LIMIT_BASE = 360
# 累计充值 5 个档位（她 `LeiJiChongZhiLayer.rewardList` 的键：30/100/300/500/800）
CHARGE_TIERS = (30, 100, 300, 500, 800)

# 她客户端里那三个**不在 shoplist** 的奖励 id → shoplist 里同类的真货键（见 docstring 第 3 条）
REWARD_KEY_SUB = {
    'chunjieleiji1': '200056',   # 五煞神掌宝箱（Items.lua）→ 太玄经书卷（chunjieleiji2）
    'mianju1010': '100048',      # 戏曲面具(华山首徒)（mask.lua）→ 古陵掌门 100048
    'mianju1011': '100084',      # 戏曲面具(岳小妹)（mask.lua）→ 杨大侠 100084
}

_MTIME_CACHE = {}


# ===========================================================================
# 一、读她的表（进程内缓存；热加载不重复解析 622KB）
# ===========================================================================


def _lua(path, key=None):
    cache = getattr(_lua, '_cache', None)
    if cache is None:
        cache = {}
        _lua._cache = cache
    if path not in cache:
        val = {}
        try:
            import sys
            here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            if here not in sys.path:
                sys.path.insert(0, here)
            import fz_luatable
            t = fz_luatable.load_lua_table(path) or {}
            if key:
                val = t.get(key) or {}
            else:
                val = t
        except Exception:                       # noqa: BLE001
            val = {}
        cache[path] = val if isinstance(val, (dict, list)) else {}
    return cache[path]


def _s(v, d=''):
    if v is None:
        return d
    if isinstance(v, bool):
        return 'true' if v else 'false'
    if isinstance(v, (int, float)):
        return str(v)
    return str(v)


def _num(v, d=0):
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return d


def _fnum(v, d=0.0):
    try:
        return float(v)
    except (TypeError, ValueError):
        return d


def _seed(*parts):
    raw = '|'.join(_s(p) for p in parts).encode('utf-8')
    return int(hashlib.md5(raw).hexdigest()[:8], 16)


def _pick(seed, pool, n, rotate=0):
    """确定性抽签（同一 seed 永远同一批；不用内建 hash，跨重启可复现）。"""
    if not pool:
        return []
    ordered = sorted(pool, key=lambda k: _seed('pick', seed, k))
    if rotate:
        rotate = rotate % len(ordered)
        ordered = ordered[rotate:] + ordered[:rotate]
    return ordered[:n] if n < len(ordered) else ordered


def goods():
    """`store/shoplist.lua["Sheet1"]` —— 2228 件真商品，键就是 `GoodsHelper` 查的那个。"""
    return _lua(P_SHOPLIST, 'Sheet1')


def store_items():
    """`store/storeItem.lua["shangchengwupin"]` —— 按 itemId 索引的真价表。"""
    return _lua(P_STOREITEM, 'shangchengwupin')


def store_config():
    """`store/storeConfig.lua["Sheet1"]` —— 70 个商人（`displaycurrency`/`shownums`/…）。"""
    return _lua(P_STORECONF, 'Sheet1')


def _by_item_id():
    m = getattr(_by_item_id, '_cache', None)
    if m is None:
        m = {}
        for gid, g in goods().items():
            if isinstance(g, dict) and g.get('itemId'):
                m.setdefault(_s(g['itemId']), _s(gid))
        _by_item_id._cache = m
    return m


# 她客户端 `Item:initOneItem`（`models/item/Item.lua:304-374`）认物品时，itemId 只会查
# 两张表：`store/storeItem.shangchengwupin`（按 itemId）+ `script.map.mapItemAttr` 下的
# 这 10 张 sheet（`Items/drItems/drequipment/mask/equipment/homeland/appearance/
# created/fondDrItems/fondDrequipment`），键就是 itemId。
# ★ 拿 itemId 过去查不到 ⇒ `Item:getOneItemByKey` 返回 nil ⇒
#   `role:addItemCount` 直接 `return nil`（`Role_Item.lua:338-344`，**静默不加**），
#   商店面板还会 `PopText("没有这个物品 …")`（`TeacherTaskSalesLayer.lua:146-150`）。
#   ⇒ 货架池必须先按这张表筛一遍（2228 件里有 60 件 itemId 她客户端认不出）。
_ITEM_SHEETS = ('Items', 'drItems', 'drequipment', 'mask', 'equipment',
                'homeland', 'appearance', 'created', 'fondDrItems', 'fondDrequipment')


def _client_item_keys():
    """她客户端 `Item:getOneItemByKey` 能认的键集（10 张 sheet ∪ storeItem）。"""
    cached = getattr(_client_item_keys, '_cache', None)
    if cached is not None:
        return cached
    keys = set()
    for s in _ITEM_SHEETS:
        for cand in (os.path.join(RES, 'map', 'mapItemAttr', s + '.lua'),
                     os.path.join(RES, 'selfCreatedSkill', s + '.lua')):
            if not os.path.exists(cand):
                continue
            t = _lua(cand)
            if isinstance(t, dict) and isinstance(t.get('Sheet1'), dict):
                t = t['Sheet1']
            if isinstance(t, dict):
                keys.update(k for k in t if isinstance(k, str))
            break
    keys.update(store_items().keys())
    _client_item_keys._cache = keys
    return keys


def _item_ok(key):
    """这件商品的 `itemId` 她客户端**真的认**（能进包袱、能画图）。"""
    info = _info(key)
    return bool(info['itemId']) and info['itemId'] in _client_item_keys()


def _key_of(gid):
    """把上行/表里的 id 归一成 **shoplist 键**（`GoodsHelper:getGoodsResClass` 只认它）。"""
    g = goods()
    k = _s(gid)
    if k in g:
        return k
    if k in REWARD_KEY_SUB:
        return REWARD_KEY_SUB[k]
    hit = _by_item_id().get(k)
    if hit:
        return hit
    try:
        import fz_api.items_currency as ic
        c = ic.canon(k)
        if c and c in g:
            return c
    except Exception:                           # noqa: BLE001
        pass
    return k


def _info(gid):
    """一件真商品的信息（键 / itemId / 名 / 描述 / 图标 / 真价）。"""
    key = _key_of(gid)
    g = goods().get(key) or {}
    if not isinstance(g, dict):
        g = {}
    iid = _s(g.get('itemId')) or key
    it = store_items().get(iid) or {}
    if not isinstance(it, dict):
        it = {}
    return {
        'key': key,
        'itemId': iid,
        'name': _s(g.get('name')) or _s(it.get('name')) or key,
        'dsc': _s(g.get('dsc')) or _s(it.get('dsc')) or _s(it.get('itemDesc')),
        'icon': _s(g.get('icon')),
        'itype': _num(g.get('itype'), 1),
        'viewtype': _num(g.get('viewtype'), 0),
        'buyPrice': _num(it.get('buyPrice'), 0),
        'salePrice': _num(it.get('salePrice'), 0),
        'priceUnit': _s(it.get('priceUnit')) or YUANBAO,
    }


# ===========================================================================
# 二、钱与物品：**不另造第二份账**
# ===========================================================================
def _ic():
    from fz_api import items_currency
    return items_currency


def _uid(ctx):
    return _s(ctx.headers.get('userid') or ctx.headers.get('uuid') or 'local', 'local')


def _st(ctx):
    st = ctx.load_json(STATE, None)
    if not isinstance(st, dict):
        st = {}
    st.setdefault('teacher_shop', {})       # {menpai: {'week':int,'keys':[键],'bought':{键:数}}}
    st.setdefault('npc_store', {})          # {npcId: {'day':int,'keys':[键]}}
    st.setdefault('activity', {})           # {'signin_signed':0/1,'seen':{活动名:时间}}
    st.setdefault('festival', {})           # {'first_claimed':0/1,'multi_claimed':[档位],'test':{}}
    st.setdefault('feat', {})               # {'claimed':[featsid],'featscount':int}
    st.setdefault('revitalization', {})     # {buildTypeId: 上次分配时间}
    st.setdefault('devote', {})             # {'last_day':int,'today':int,'order':{order_id:{...}}}
    for k in ('teacher_shop', 'npc_store', 'activity', 'festival', 'feat', 'revitalization',
              'devote'):
        if not isinstance(st.get(k), dict):
            st[k] = {}
    if not isinstance(st['festival'].get('multi_claimed'), list):
        st['festival']['multi_claimed'] = []
    if not isinstance(st['feat'].get('claimed'), list):
        st['feat']['claimed'] = []
    if not isinstance(st['devote'].get('order'), dict):
        st['devote']['order'] = {}
    return st


def _save(ctx, st):
    try:
        ctx.save_json(STATE, st)
    except Exception:                           # noqa: BLE001
        pass
    return st


def _dataver(ctx):
    """宿主服务端注入的 dataVer 自增器（`fz_boot_server.py` 的 `next_dataver`）。"""
    try:
        v = ctx.deps['next_dataver']()
        return _num(v, 1) or 1
    except Exception:                           # noqa: BLE001
        return 1


def _cur(ctx, kind):
    try:
        return _num(_ic().get_currency(ctx, kind))
    except Exception:                           # noqa: BLE001
        return 0


def _cname(kind):
    try:
        n = _ic().currency_name(kind)
        if n:
            return n
    except Exception:                           # noqa: BLE001
        pass
    return kind


def _spend_cur(ctx, kind, n):
    try:
        return _ic().add_currency(ctx, kind, -abs(int(n))) is not None
    except Exception:                           # noqa: BLE001
        return False


def _grant(ctx, gid, n=1):
    """真发货：按 shoplist 键进她的包袱（`items_currency` 自己会做别名归一）。"""
    try:
        key = _key_of(gid)
        r = _ic().add_count(ctx, key, abs(int(n)))
        if r is None:
            r = _ic().add_count(ctx, _info(key)['itemId'], abs(int(n)))
        return r
    except Exception:                           # noqa: BLE001
        return None


def _load_work_json(ctx, name):
    """读 `work/<name>`（别人模块落盘的存档；读不到就 {}，**不写**）。"""
    try:
        with open(ctx.data_file(name), encoding='utf-8') as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:                           # noqa: BLE001
        return {}


# ===========================================================================
# 三、师门商店（`get_teacher_shop`）
# ===========================================================================
# 她面板的货币是"师门贡献点"（`:48 self.currency="gongxian"`，
# `:399 refreshMoney` → `get_devote_point` 的 `dev_point`）。
TEACHER_SHOP_ITEMS = 10
TSHOP_NODE = 'shop'               # ★ 货架状态节点：全局一份（不再按门派分，见 _teacher_rows 注释）
TEACHER_REFRESH_YUANBAO = 0       # ★ 2026-10-03 老板要求：师门刷新改**零元宝**（原 20）


def _teacher_pool():
    """师门商店的货：**能进她包袱**的真商品（`itype` 1道具/2客户端特殊道具/4服务器物品/7解锁，
    且 `itemId` 她客户端认得出 —— 她面板会 `Item:getOneItemByKey(v.itemId)`）。"""
    out = []
    for gid, g in goods().items():
        if not isinstance(g, dict):
            continue
        if _num(g.get('itype'), 0) in (1, 2, 4, 7) and _s(g.get('name')) and _item_ok(gid):
            out.append(_s(gid))
    return out


def _teacher_price(key):
    """价格：优先她 `storeItem.buyPrice`（真价），没写就按 `viewtype` 档位给稳定基数。

    `storeItem` 里 `buyPrice` 是**元宝**价；师门商店用的是贡献点，
    原版兑换比在服务端 ⇒ 这里按"元宝价 × 档位"折贡献点，并在 note 里标明是折算。
    """
    info = _info(key)
    if info['buyPrice'] > 0:
        return max(1, info['buyPrice'] * 2)
    tier = {0: 1, 1: 2, 2: 2, 3: 3, 4: 2}.get(info['viewtype'], 1)
    return 60 * tier


def _teacher_rows(ctx, st, menpai, refresh):
    """师门商店当前货架（按**周**刷新，她 `TeacherTaskSalesLayer:setTextDesc` 写的是"每天0点自动刷新"，
    但原版货架号来自服务端；这里用周刷新减少闪动，`type="refresh"` 时真扣元宝换一批）。"""
    t = st['teacher_shop']
    week = int(time.time()) // WEEK
    # ★★ 2026-10-03 修「买完背包没有/买错东西」：货架原来**按门派各存一份**，
    #   但她客户端买的时候只上行 `{rid}`、**不带门派** ⇒ `_teacher_row_by_rid` 只能落
    #   到缺省 'sect' 的另一张货架 ⇒ 面板看的是 A 货架、实际买的是 B 货架的东西
    #   （真机实测：点名买霞盈九霄残页，扣 60 贡献点发来的是 yidefurencanye）。
    #   单人离线服没有"分门派货架"的必要 ⇒ 改成**全局一张货架**，看和买必然同一张。
    node = t.get(TSHOP_NODE)
    if not isinstance(node, dict) or _num(node.get('week'), -1) != week or not node.get('keys'):
        node = {'week': week,
                'keys': _pick('teacher-%d' % week, _teacher_pool(), TEACHER_SHOP_ITEMS),
                'bought': {}}
        t[TSHOP_NODE] = node
        _save(ctx, st)
    # ★ 老存档/手改过的 state 可能没有 `bought`（或不是 dict）⇒ 就地补上，
    #   否则 `_ep_buy_teacher_good` 的 `node.setdefault('bought', {})` 会写在**临时副本**上、丢了。
    if not isinstance(node.get('bought'), dict):
        node['bought'] = {}
        _save(ctx, st)
    if not isinstance(node.get('keys'), list):
        node['keys'] = []
    rows = []
    onsale = 0
    for key in [k for k in (node.get('keys') or []) if k in goods()]:
        info = _info(key)
        bought = _num((node.get('bought') or {}).get(key), 0)
        sold_out = bought > 0
        if not sold_out:
            onsale += 1
        rows.append({
            # ★★ `id` **只数在售行**（1..N 连续）：她 `:422 v.index = k` / `:129` 上行
            #   `bagItem.index` 是"她在售数组里的下标"，买走一件后本地会塌缩一格。
            #   服务端若按"商品位置"编号就会错位顶掉一件货（见 docstring 第四节）。
            'id': 0 if sold_out else onsale,
            'itemId': info['itemId'],
            'goodsKey': key,                   # 本模块内部用，客户端不读
            'name': info['name'],
            'dsc': info['dsc'],
            'icon': info['icon'],
            'buyPrice': _teacher_price(key),
            'salePrice': max(1, _teacher_price(key) // 2),
            'number': 1,
            'count': 1,
            'priceUnit': GONGXIANDIAN,
            'unit': '份',
            # ★ 她 `:419` 只收 `status == 0`（或 `true`）的条目 ⇒ 买过的给 1 就不再上架
            'status': 0 if bought <= 0 else 1,
        })
    return rows, node


def _ep_get_teacher_shop(ctx, st):
    """`get_teacher_shop`：`TeacherTaskSalesLayer:getSellerItems`(:439-460) 读
    `data.need_yuanbao`（`:444`）与 `data.goods_list`（`:445` → `setSellerItems`），
    列表元素读 `status`(:419) / `number`(:420) / `name`(:263/271) / `price`(:271) /
    `buyPrice`(:274/:296) / `dsc`(:305)。
    """
    menpai = _s(ctx.param('menpai') or ctx.param('familyId') or 'sect')
    stype = _s(ctx.param('type') or 'normal')
    if stype == 'refresh':
        # 她 `refreshSalesItem`(:463) 走 `TransCheck:setTransWithWebOrderId`，刷新是**真花钱**
        if not _spend_cur(ctx, YUANBAO, TEACHER_REFRESH_YUANBAO):
            return ctx.fail('元宝不足', '★ 师门商店刷新：需要 %d 元宝' % TEACHER_REFRESH_YUANBAO)
        node = st['teacher_shop'].get(TSHOP_NODE) or {}
        node['keys'] = _pick('teacher-refresh-%d' % int(time.time()),
                             _teacher_pool(), TEACHER_SHOP_ITEMS)
        node['bought'] = {}
        st['teacher_shop'][TSHOP_NODE] = node
        _save(ctx, st)
    rows, node = _teacher_rows(ctx, st, menpai, stype == 'refresh')
    left = [r for r in rows if r['status'] == 0]
    return ctx.ok({
        'need_yuanbao': TEACHER_REFRESH_YUANBAO,
        'goods_list': rows,
        'list': rows,                          # 她的老面板有读 `list` 的版本，两个都给她
    }, '★ 师门商店 %s：%d 件在售（shoplist 真商品，货币=师门贡献点，价=storeItem.buyPrice×2）%s'
       % (menpai, len(left), '（本次为刷新，-%d 元宝）' % TEACHER_REFRESH_YUANBAO
          if stype == 'refresh' else ''))


# ===========================================================================
# 三之二、师门商人的「购买」链 + 贡献点账（第十一轮第二段补完）
# ===========================================================================
# 她 `TeacherTaskSalesLayer.lua:129` 上行的是 `bagItem.index`，
# 而 `:422 v.index = k` 的 `k` 是**她在售数组的下标**（买走一件后本地 `popItemByIndex`
# 会塌缩）⇒ 服务端的 `rid` 必须与"在售后仍连续的编号"对齐，就是 `_teacher_rows` 的 `id`。
#
# 每日贡献点上限：她 `TeacherTaskLayer.lua:33` / `ReceiveTeacherTaskLayer.lua:242`
# 把 "已获得/上限" 写死成 `/4000`，`teacherTask.lua:684` 也是 `math.min(4000 - ContributionPoint, point)`
# ⇒ 4000 是她客户端承认的上限（不是编的）。
DEVOTE_DAILY_CAP = 4000
# `add_devote_point` 的 `ptype`（她 `HttpManager.lua:1246-1255` 的注释）：
#   1 请安 / 2 每日挑战任务 / 3 飞贼任务 / 5 师门任务（`TeacherTaskLayer.lua:227`）。
# 她 `point` 传 0 的（请安、每日挑战、飞贼）是"由服务端决定给多少"。
# ⚠ 原版每个 ptype 给多少分**只在原版服务端**，她的 res 表里没有 ⇒ 这三个用**常量**兜底，
#   并在 note 里点名（**不谎称 1:1**；`type==5` 的师门任务是客户端掷的真值，原样收）。
DEVOTE_GIFT = {1: 10, 2: 20, 3: 30}
DEVOTE_TYPES = (1, 2, 3, 5)


def _devote_today(ctx, st):
    """今日贡献点**发放**账（跨天重置）。返回 `(今日已发, 节点)`。"""
    d = st['devote']
    day = int(time.time()) // DAY
    if _num(d.get('last_day'), -1) != day:
        d['last_day'] = day
        d['today'] = 0
        d['order'] = {}
        _save(ctx, st)
    return _num(d.get('today')), d


def _ep_get_devote_point(ctx, st):
    """`get_devote_point`：她读 `data.dev_point`（数）与 `data.has_reward`（串 Y/N）。

    * `TeacherTaskSalesLayer.lua:400-402` → `setTextMoney(tonumber(data.dev_point))`
      ⇒ **必须是数字**，否则 `tonumber(nil)` 变 nil、面板上"师门贡献点："后面是空的。
    * `TeacherTaskLayer.lua:112` 是 `Helper:getDef(data.dev_point, 0)`、`:116` 是
      `Helper:getDef(data.has_reward, "N") == "Y"` ⇒ 红点；`Helper:getDef` 类型不符会**换回默认值**，
      所以 `dev_point` 别给字符串、`has_reward` 别给 bool。
    * 钱只有一份：`items_currency` 的 `gongxiandian`（与 `map_shop` 声望商人同键）。
    """
    today, _ = _devote_today(ctx, st)
    have = _cur(ctx, GONGXIANDIAN)
    full = today >= DEVOTE_DAILY_CAP
    return ctx.ok({
        'dev_point': have,                     # 数（她 tonumber / setString 都要数字）
        'has_reward': 'N' if full else 'Y',    # 串（`getDef(..,"N")=="Y"`）
        'today_point': today,
        'daily_cap': DEVOTE_DAILY_CAP,
    }, '★ 师门贡献点 %d（今日已发 %d/%d，%s）'
       % (have, today, DEVOTE_DAILY_CAP, '已达上限' if full else '仍可获取'))


def _ep_add_devote_point(ctx, st):
    """`add_devote_point`：请安 / 每日挑战 / 飞贼 / **师门任务**发贡献点。

    她读的字段（`TeacherTaskLayer.lua:230-235`）：
      * `data.get_point`（数）—— **以服务器的数为准**（`setTeacherTaskAttr(...,+data.get_point)`）
      * `data.msg`（串）—— 直接 `PopText(data.msg)`
    错误码按她 `HttpManager.lua:1246-1255` 的注释：2 类型为空 / 3 已达当日上限 / 4 类型错误。
    """
    ptype = _num(ctx.param('type'), 0)
    if not ptype:
        return ctx.fail('类型参数为空', '★ add_devote_point：没给 type（她注释 errcode=2）', errcode=2)
    if ptype not in DEVOTE_TYPES:
        return ctx.fail('类型错误', '★ add_devote_point：type=%s 不在她注释的 1/2/3/5 里（errcode=4）'
                        % ptype, errcode=4)
    today, d = _devote_today(ctx, st)
    if today >= DEVOTE_DAILY_CAP:
        return ctx.fail('已达到当日贡献点获取上限',
                        '★ add_devote_point：今日已发 %d，达上限 %d（errcode=3）'
                        % (today, DEVOTE_DAILY_CAP), errcode=3)
    # 她 `point` 有传数（师门任务 = 客户端掷出的真值）也有传 0（请安一族）
    point = max(0, _num(ctx.param('point'), 0))
    src = '她上行'
    if point <= 0:
        point = DEVOTE_GIFT.get(ptype, 0)
        src = '常量兜底（原版在服务端 DB，她表里没有）'
    point = min(point, DEVOTE_DAILY_CAP - today)
    if point <= 0:
        return ctx.fail('已达到当日贡献点获取上限',
                        '★ add_devote_point：截断后为 0（今日 %d/%d）' % (today, DEVOTE_DAILY_CAP),
                        errcode=3)
    try:
        left = _ic().add_currency(ctx, GONGXIANDIAN, point)
    except Exception:                           # noqa: BLE001
        left = None
    if left is None:
        return ctx.fail('获取贡献点失败', '★ add_devote_point：写钱包失败（items_currency.add_currency 回 None）')
    d['today'] = today + point
    _save(ctx, st)                              # ★ 放在 add_currency 之后：两者写不同文件
    msg = '获得%d贡献点' % point
    return ctx.ok({
        'get_point': point,                    # 数（她 +data.get_point）
        'point': point,
        'msg': msg,                            # 串（她 PopText）
        'dev_point': _cur(ctx, GONGXIANDIAN),
        'today_point': d['today'],
        'daily_cap': DEVOTE_DAILY_CAP,
    }, '★ %s +%d 贡献点（type=%d，%s）→ 共 %d，今日 %d/%d'
       % (msg, point, ptype, src, _cur(ctx, GONGXIANDIAN), d['today'], DEVOTE_DAILY_CAP))


def _teacher_row_by_rid(ctx, st, rid):
    """把 `rid`（她在售数组下标 = `_teacher_rows` 的 `id`）落成一行。

    同时吃 `menpai`（有时没有 ⇒ 用她面板那一局的缺省 `'sect'`）。
    返回 `(row, node, menpai)`；找不到就是 `(None, None, menpai)`。
    """
    menpai = _s(ctx.param('menpai') or ctx.param('familyId') or 'sect')
    rows, node = _teacher_rows(ctx, st, menpai, False)
    # 1) 按 `id` 找（正常路径）
    for r in rows:
        if r['status'] == 0 and _num(r.get('id'), -1) == rid:
            return r, node, menpai
    # 2) 兜底：她本地列表与我的应答不同步时，`rid` 可能仍是 1..N 序号 ——
    #    按"在售行里的第 rid 个"再试一次（同一批货，不会串到已售出的那件）
    onsale = [r for r in rows if r['status'] == 0]
    if 1 <= rid <= len(onsale):
        return onsale[rid - 1], node, menpai
    return None, node, menpai


def _grant_with_refund(ctx, key, price):
    """真发货；`_grant` 失败（她客户端认不出这件）就**原价退回**，不留半截交易。"""
    got = _grant(ctx, key, 1)
    if got is None:
        try:
            _ic().add_currency(ctx, GONGXIANDIAN, price)
        except Exception:                       # noqa: BLE001
            pass
        return False, ('这件货发不进你的包袱（%s 的 itemId 客户端认不出）⇒ 已原价退回 %d 贡献点'
                       % (key, price))
    return True, ''


def _ep_buy_teacher_good(ctx, st):
    """`buy_teacher_good`：师门商人的**购买**按钮（她上行 `{rid}`，回调只看 errcode）。

    `TeacherTaskSalesLayer.lua:109-157`：`errcode==0` 才 `pushItem` + `popItemByIndex`
    + `PopText("你购买X花费了Y贡献点")`；`errcode!=0` 走 `PopText(errmsg)`。
    `rid` 的语义与对齐规则见本节开头注释。
    """
    rid = _num(ctx.param('rid') or ctx.param('id'), 0)
    if rid <= 0:
        return ctx.fail('商品数据出错', '★ 师门购买：没给 rid（她上行 {rid}）')
    row, node, menpai = _teacher_row_by_rid(ctx, st, rid)
    if row is None:
        onsale = [r for r in _teacher_rows(ctx, st, menpai, False)[0] if r['status'] == 0]
        return ctx.fail('获得商品数据出错。',
                        '★ 师门购买：rid=%s 不在 %s 当前货架上（她面板该货架共 %d 件在售）'
                        % (rid, menpai, len(onsale)))
    key = _s(row.get('goodsKey'))
    price = _num(row.get('buyPrice'))
    bought = _num((node.get('bought') or {}).get(key), 0)
    if bought > 0:
        return ctx.fail('这件商品已经售出了', '★ 师门购买：%s 已售出（status=1，她面板不会再显示）' % key)
    have = _cur(ctx, GONGXIANDIAN)
    if have < price:
        return ctx.fail('师门贡献点不足',
                        '★ 师门购买 %s：需要 %d 贡献点，当前 %d（差 %d）'
                        % (_info(key)['name'], price, have, price - have))
    if not _spend_cur(ctx, GONGXIANDIAN, price):
        return ctx.fail('师门贡献点不足',
                        '★ 师门购买 %s：扣 %d 贡献点失败（当前 %d）' % (_info(key)['name'], price, have))
    ok, why = _grant_with_refund(ctx, key, price)
    if not ok:
        return ctx.fail('获得商品数据出错。', '★ 师门购买 %s：%s' % (key, why))
    node.setdefault('bought', {})[key] = bought + 1
    _save(ctx, st)
    info = _info(key)
    return ctx.ok({
        'itemId': info['itemId'],               # 串（她 `addItemCount` 只认 itemId）
        'count': 1,
        'rid': rid,
        'dev_point': _cur(ctx, GONGXIANDIAN),   # 数（她买完会刷新贡献点显示）
    }, '★ 师门购买「%s」×1：扣 %d 贡献点（余 %d），已进包袱（itemId=%s）—— 货架编号 rid=%d'
       % (info['name'], price, _cur(ctx, GONGXIANDIAN), info['itemId'], rid))


def _ep_update_menpai_gongxiangdian(ctx, st):
    """`update_menpai_gongxiangdian`：**贡献点商人**（`get_devote_list` 那条路）买/卖后结算。

    她 `SalesLayer.lua:703-729` / `TeacherTaskSalesLayer.lua:497-522`：
    `dealOneItem(itemData.id, -buyPrice | +salePrice, {itemId,time,count,price,type,userid}, func)`
    ⇒ 上行 `{order_id, itemId, points, orderInfo}`，回调**只看 errcode**（0 才 `refreshLayer`）。

    ★ `points` 的符号就是她的意图：**买是负**（`-buyPrice`）、**卖是正**（`salePrice`）
      ⇒ 这里按符号增减 `gongxiandian`。`order_id` 来自 `TransCheck:setTransWithWebOrderId`，
      同一单重复上行**只结算一次**（幂等表在 state 的 `devote.order`）。

    ⚠ **与 `buy_teacher_good` 不重叠**：师门任务商人那条路走 `buy_teacher_good`
      （她的 `TeacherTaskSalesLayer:buy` 已把 `dealOneItem` 整段注释掉了），
      这条只服务 `SalesLayer` 的贡献点商人。
    """
    order_id = _s(ctx.param('order_id') or ctx.param('orderid'))
    item_id = _s(ctx.param('itemId') or ctx.param('itemid'))
    points = _num(ctx.param('points'), 0)
    info = ctx.param('orderInfo')
    if isinstance(info, str) and len(info) > 400:      # 别把一整坨日志塞进 state
        info = info[:400]
    _, d = _devote_today(ctx, st)
    if order_id and order_id in d['order']:
        # 同一单重复上行：**不再扣钱**，但仍回 0（她那边要继续走 refreshLayer）
        return ctx.ok({
        'special_reward': {'itemId': _s((ctx.param('itemId') or (ctx.param('orderInfo') or {}).get('itemId') if isinstance(ctx.param('orderInfo'), dict) else ctx.param('itemId'))), 'num': 1},
        'gainList': [{'itemId': _s(ctx.param('itemId')), 'number': 1}],
'itemId': item_id, 'points': points, 'duplicated': 1,
                       'dev_point': _cur(ctx, GONGXIANDIAN)},
                      '★ 门派共享点：order_id=%s 已结算过，**不重复扣/加**（余 %d）'
                      % (order_id, _cur(ctx, GONGXIANDIAN)))
    if points:
        try:
            left = _ic().add_currency(ctx, GONGXIANDIAN, points)   # 买=负 / 卖=正
        except Exception:                       # noqa: BLE001
            left = None
        if left is None:
            return ctx.fail('师门贡献点不足',
                            '★ 门派共享点：需要 %d 贡献点，当前 %d（order_id=%s）'
                            % (abs(points), _cur(ctx, GONGXIANDIAN), order_id))
    if order_id:
        d['order'][order_id] = {'itemId': item_id, 'points': points,
                                'info': info, 't': int(time.time())}
        # 幂等表只留最近 200 单，避免 state 无限膨胀
        if len(d['order']) > 200:
            for k in sorted(d['order'], key=lambda x: _num((d['order'][x] or {}).get('t')))[:100]:
                d['order'].pop(k, None)
        _save(ctx, st)
    return ctx.ok({
        'itemId': item_id,
        'points': points,
        'dev_point': _cur(ctx, GONGXIANDIAN),
    }, '★ 门派共享点结算：itemId=%s points=%+d（买为负/卖为正）→ 余 %d 贡献点%s'
       % (item_id, points, _cur(ctx, GONGXIANDIAN), '（order_id=%s）' % order_id if order_id else ''))


# ===========================================================================
# 四、市侩 / 游商（`get_npc_store_list/<npcId>`）
# ===========================================================================
NPC_STORE_ITEMS = 8


def _npc_cfg(npc_id):
    cfg = store_config().get(npc_id)
    return cfg if isinstance(cfg, dict) else {}


def _npc_unit(cfg):
    """真币种：`storeConfig.displaycurrency[0]`（她 `Chapman:getNpcChapman` 把它丢进 `priceUnit`）。"""
    dc = cfg.get('displaycurrency') or []
    if isinstance(dc, list) and dc:
        u = _s(dc[0])
        if u:
            return u
    return MONEY


def _npc_rows(ctx, st, npc_id):
    cfg = _npc_cfg(npc_id)
    n = st['npc_store']
    day = int(time.time()) // DAY
    node = n.get(npc_id)
    if not isinstance(node, dict) or _num(node.get('day'), -1) != day or not node.get('keys'):
        # 货架排布原版在服务端（`storeConfig.goodsshelf` 只是货架号）；
        # 用 shoplist 真商品做确定性抽签，`shownums` 是她的真"上架数量"。
        cnt = _num(cfg.get('shownums'), -1)
        cnt = cnt if 4 <= cnt <= 30 else NPC_STORE_ITEMS
        shelves = cfg.get('goodsshelf') or []
        shelf_no = ''
        if isinstance(shelves, list) and shelves:
            first = shelves[0]
            shelf_no = _s(first[0]) if isinstance(first, list) and first else _s(first)
        pool = [_s(k) for k, v in goods().items()
                if isinstance(v, dict) and _num(v.get('itype'), 0) in (1, 2, 4, 7)
                and _item_ok(k)]
        node = {'day': day, 'keys': _pick('npc-%s-%s' % (npc_id, shelf_no), pool, cnt)}
        n[npc_id] = node
        _save(ctx, st)
    unit = _npc_unit(cfg)
    rows = []
    for key in [k for k in (node.get('keys') or []) if k in goods()]:
        info = _info(key)
        base = info['buyPrice']
        price = max(1, base * 2) if base > 0 else 20 + (_seed('npcprice', npc_id, key) % 480)
        rows.append({
            'itemId': info['itemId'],
            'id': _num(key, 0),
            'name': info['name'],
            'icon': info['icon'],
            'price': price,
            'unit': unit,
            'count': 1,
        })
    return rows, unit, cfg


def _ep_get_npc_store_list(ctx, st):
    """`get_npc_store_list/<npcId>`：`Chapman:getNpcChapman`(:288-344) 与
    `NpcMapBagLayer:refreshList2`(:1335-1392) 读 `data.list`（元素 `itemId`/`price`/`unit`）
    + `data.point` + `data.unit`。**`list` 空 ⇒ 背包里「市侩」页签什么都没有。**
    """
    npc_id = _s(ctx.args[0] if ctx.args else '')
    if not npc_id:
        npc_id = _s(ctx.param('npcId') or ctx.param('npc_id'))
    if not npc_id:
        return ctx.fail('缺少商人 id', '★ 市侩游商：URL 没给 npcId，无法定货架', errcode=1)
    rows, unit, cfg = _npc_rows(ctx, st, npc_id)
    return ctx.ok({
        'list': rows,
        'items': rows,
        'point': _cur(ctx, unit),
        'unit': unit,
        'state': 1,
        'npc_id': npc_id,
    }, '★ 市侩游商 %s：%d 件（shoplist 真商品，货币=%s%s）'
       % (npc_id, len(rows), unit,
          '（storeConfig 真配置）' if cfg else '（npcId 不在 storeConfig，用通用货架）'))


# ===========================================================================
# 五、活动红点（`get_activity_list/<type>`）
# ===========================================================================
# 她 `ActionLayer:initActionList` 的 `funcTab` 里 **94 个**合法活动名（点进去才有界面）。
# 本模块只放行"名字真在 funcTab 里"的活动，`ActionLayer:getIsShow` 拿它跟 `data.list` 逐字比。
#
# `_ACTIVITIES` 的**名字**与 `fz_boot_server.py` 的 `get_spring_festival_list` 逐个对齐
# （那份是活动面板真正的上架清单），`activity_id` 同源。
_ACTIVITIES = [
    (1, 'signin', '签到活动'),
    (2, 'growth', '大侠的成长之路'),
    (3, 'sanyou', '江湖三友'),
    (4, 'zhenpinge', '江湖珍品阁'),
    (5, 'duobao', '江湖夺宝'),
    (6, 'mingwulu', '江湖名武录'),
    (7, 'mingrenlu', '江湖名人录'),
    (8, 'cangjingge', '藏经阁'),
    (9, 'dicang', '地仓府库'),
    (10, 'lixian', '限时历练'),
    (11, 'danqingge', '丹青阁'),
    (12, 'daily', '每日任务'),
    (13, 'zuixian', '醉仙秘市'),
    (14, 'xiangnang', '香囊密阁'),
    (15, 'nianshou', '驱赶年兽'),
    # ★ 下面这几个是本轮补的节庆一族入口（首充/累充/限时礼包累充/充值福利），
    #   名字必须**逐字**命中 `funcTab`，否则 `ActionLayer` 点行时 `ManageActionByName`
    #   与 `funcTab` 都不命中 ⇒ 什么都不发生。
    (16, 'shouchong', '首充活动'),
    (17, 'leijichongzhi', '累计充值'),
    (18, 'xianshilibao', '限时礼包累计奖励'),
    (19, 'chongzhifuli', '充值福利'),
    # ★「拳脚商城」的真名是「通武积市」（`ActionLayer.lua:997` → `FistFootShopPresenter`），
    #   在 `fz_boot_server.py` 的 `get_spring_festival_list` 上架清单里同时补了第 16 项。
    (20, 'tongwujishi', '通武积市'),
]


def _functab_names():
    """抠她 `ActionLayer.lua` 的 `funcTab` 键（**94 个**合法活动名）——缓存在函数属性上。"""
    cached = getattr(_functab_names, '_cache', None)
    if cached is not None:
        return cached
    names = set()
    try:
        with open(P_ACTIONLAYER, encoding='utf-8', errors='replace') as f:
            t = f.read()
        i = t.index('local funcTab')
        names = set(re.findall(r'^\s*\["([^"]+)"\]\s*=\s*function', t[i:], re.M))
    except Exception:                           # noqa: BLE001
        names = set()
    _functab_names._cache = names
    return names


def _activity_rows():
    """活动上架清单：名字必须命中她 `funcTab`（拿不到 funcTab 就原样放行，至少不空）。"""
    valid = _functab_names()
    out = []
    for aid, key, name in _ACTIVITIES:
        if valid and name not in valid:
            continue
        out.append({'id': aid, 'activity_id': key, 'name': name})
    return out or [{'id': a, 'activity_id': k, 'name': n} for a, k, n in _ACTIVITIES]


def _ep_get_activity_list(ctx, st):
    """`get_activity_list/<type>`：**红点专用**。

    `MainLayer.lua:205-217`：
        if data.isSign == "N" or data.isClick == "Y" then 亮红点
    她 `TitleUI.lua:434` 也是同一个接口。`data.list` 是**活动名数组**，被她
    `ActionLayer:getIsShow`(:1186-1193) 拿 `action.name` 逐个比 ⇒ 每行红点。
    """
    atype = _s(ctx.args[0] if ctx.args else '') or _s(ctx.param('type') or '1')
    act = st['activity']
    signed = _num(act.get('signin_signed'), 0)
    rows = _activity_rows()
    # `isSign="N"` ⇒ 今日未签到 ⇒ 亮；`isClick="Y"` ⇒ 有新活动 ⇒ 亮。
    # 两者都取真状态（`signin_signed` 由本模块的账本记），不是永远亮。
    is_sign = 'Y' if signed else 'N'
    is_click = 'Y' if not signed else 'N'
    _save(ctx, st)
    return ctx.ok({
        'list': [r['name'] for r in rows],
        'isSign': is_sign,
        'isClick': is_click,
        'type': _num(atype, 1),
    }, '★ 活动红点：%d 个上架活动（名字全部命中她 funcTab），isSign=%s（签到未领=%s）'
       % (len(rows), is_sign, '否' if is_sign == 'N' else '是'))


# ===========================================================================
# 六、节庆地图（`get_festivalmap_info`）
# ===========================================================================
def _festival_maps(group_id):
    """从 `challengeMap/mapInfo.lua["map"]` 取这个 `groupId`（= `section[1]`）下的节庆副本。"""
    t = _lua(P_MAPINFO, 'map')
    gid = _num(group_id, -1)
    out = []
    for v in t.values():
        if not isinstance(v, dict) or _num(v.get('type'), 0) != 2:
            continue
        sec = v.get('section') or []
        if not isinstance(sec, list) or not sec:
            continue
        if _num(sec[0], -1) != gid:
            continue
        out.append(v)
    out.sort(key=lambda v: (_num((v.get('section') or [0, 0])[1]), _s(v.get('id'))))
    return out


def _ep_get_festivalmap_info(ctx, st):
    """`get_festivalmap_info`：`FestivalMapDetailPresenter`(:35-45) 用
    `festivalGroupData[i].dayTime < mapData.daily and .finalTime < mapData.activity`
    逐个比 ⇒ **必须是与 mapGroup 等长的数组**，元素 `{dayTime,finalTime}` 都是**数字**。
    `daily` / `activity` 的上限直接取她 `mapInfo.lua` 的真值。

    ★ 已通关次数（`dayTime`/`finalTime`）是**玩家服务端进度**，本服没有这张账
      ⇒ 给 0（= 今天/本次活动一次都没打），面板显示 `0/上限`，按钮可用。**不瞎编进度。**
    """
    gid = _s(ctx.param('groupId') or (ctx.args[0] if ctx.args else ''))
    maps = _festival_maps(gid)
    if not maps:
        return ctx.fail('该节庆副本组不存在',
                        '★ 节庆地图：groupId=%r 在 challengeMap/mapInfo.lua 里没有 type=2 的组' % gid,
                        errcode=1)
    rows = [{'dayTime': 0, 'finalTime': 0} for _ in maps]
    return ctx.ok(rows, '★ 节庆地图 group=%s：%d 个难度（上限 daily/activity 取她 mapInfo 真值；'
                        '已打次数为服务端进度，本模块无账 ⇒ 0）' % (gid, len(rows)))


# ===========================================================================
# 七、首充（`get_first_festival_gift` / `receive_first_festival_gift`）
# ===========================================================================
def _recharge_total(ctx):
    """累计充值额：读 `misc_extra` 那份累充账本（**不另造第二份**）。"""
    d = _load_work_json(ctx, P_MISC_STATE)
    rc = d.get('recharge') if isinstance(d.get('recharge'), dict) else {}
    return _num(rc.get('totalRecharge'), 0)


def _first_gift_items():
    """首充奖励：她 `NewShouChongLayer.lua:13-41` 写死的 `rewardList` + `minaju` 表
    （菩提子×2 / 潜能丹×2 / 武林秘籍×1 / 戏曲面具×1）。

    返回 (shoplist 键, **她那件货的真名**, 数量, 原 id) —— 数量、件数**照抄她的表**，
    但名字与 id 一起换成 shoplist 那件真货的（`chunjieleiji1` / `mianju1010` / `mianju1011`
    不在 shoplist 里，见 docstring 第 3 条：换同类真货，**名字也跟着换真名**，
    否则会向她报"获得 武林秘籍"却实际发出太玄经，那是假数据）。
    """
    raw = [
        ('putizi1', 2),
        ('qiannengdan', 2),
        ('chunjieleiji1', 1),
        ('mianju1010', 1),
    ]
    out = []
    for rid, cnt in raw:
        key = _key_of(rid)
        if key not in goods():
            continue
        out.append((key, _info(key)['name'], cnt, rid))
    return out


def _ep_get_first_festival_gift(ctx, st):
    """`get_first_festival_gift`：`NewShouChongLayer:updateShowChongList`(:195-234) 读
    `data.status`：**0 = 未充值（按钮变「去充值」）/ 1 = 可领 / 2 = 已领取**。

    ★ `status` 必须是数字：她写的是 `if data.status == 0 then ... elseif == 1 ... elseif == 2`，
      给字符串 "1" 三个分支都不进 ⇒ 按钮无反应。
    """
    claimed = _num(st['festival'].get('first_claimed'), 0)
    total = _recharge_total(ctx)
    if claimed:
        status = 2
    elif total > 0:
        status = 1
    else:
        status = 0
    items = _first_gift_items()
    return ctx.ok({
        'status': status,
        'reward': [{'id': k, 'num': n, 'name': nm} for (k, nm, n, _r) in items],
        'msg': '' if status != 2 else '已经领取过首充奖励',
    }, '★ 首充活动：status=%d（0 未充值 / 1 可领 / 2 已领；累充额=%d 读 misc_extra 账本），'
       '奖励 %d 件照抄她 NewShouChongLayer.rewardList' % (status, total, len(items)))


def _ep_receive_first_festival_gift(ctx, st):
    """`receive_first_festival_gift`：`NewShouChongLayer:receiveFirstFestivalGift`(:257-266)
    **只看 errcode**（errcode=0 后她自己 `getReward` 往本地包袱加东西）。
    所以这里必须"真发 + 真记账"，否则她会重复领。
    """
    if _num(st['festival'].get('first_claimed'), 0):
        return ctx.fail('已经领取过首充奖励', '★ 首充领取：本账号已领过（first_claimed=1）')
    total = _recharge_total(ctx)
    if total <= 0:
        return ctx.fail('尚未充值，无法领取首充奖励',
                        '★ 首充领取：累充额为 0（本服无真实充值通道，见 docstring 第 4 条）')
    items = _first_gift_items()
    if not items:
        return ctx.fail('首充奖励配置读取失败',
                        '★ 首充领取：shoplist 里连一件替换货都取不到（她表读失败）')
    got = []
    for key, name, cnt, _r in items:
        _grant(ctx, key, cnt)
        got.append('%s×%d' % (name, cnt))
    st['festival']['first_claimed'] = 1
    _save(ctx, st)
    # ★ `reward` 里两个 id 都给（理由见 `receive_multi_festival_gift` 的注释）：
    #   `goodsKey` = shoplist 键，`id` = itemId。
    return ctx.ok({
        'status': 2,
        'reward': [{'id': _info(k)['itemId'], 'goodsKey': k, 'num': n, 'name': nm}
                   for (k, nm, n, _r) in items],
        'msg': '首充奖励已发放',
    }, '★ 首充领取：真发货 %s（订单号 %s）'
       % ('、'.join(got), _s(ctx.param('order_id'), '-')))


# ===========================================================================
# 八、累计充值（`get_multi_festival_gift_list` / `receive_multi_festival_gift`）
# ===========================================================================
# 她 `LeiJiChongZhiLayer.lua:12-117` 的 `rewardList`（客户端写死的真表），
# 每档两件：**先潜能丹/醉梦生，后"武功秘籍"+戏曲面具**（数量全是 1/2/3，逐个核过）。
#   元组 = (shoplist 键, 她表里原本写的 id)。原本那个 id 有时是 shoplist 键、
#   有时是 itemId，两种都归一过（我逐个在她 `store/shoplist.lua` 里查过）。
#   ★ 只有 300/500/800 的第二件的原 id 是 `mianju1011`（她表里有这件面具，
#     但它**不在 shoplist**）⇒ 用 `100048`（古陵掌门）顶上，`substituted=True`。
_LEIJI_TABLE = {
    30: [('300004', 'qiannengdan'), ('300003', 'jiu106')],
    100: [('300004', 'qiannengdan'), ('300003', 'jiu106')],
    300: [('100084', 'mianju1012'), ('100048', 'mianju1011')],
    500: [('100084', 'mianju1012'), ('100084', 'mianju1012')],
    800: [('100084', 'mianju1012'), ('100048', 'mianju1013')],
}
# 每档**按条目顺序**的数量（她表里的 `count`，逐条抄下来；下标与 `_LEIJI_TABLE` 一一对应）
# ★ `500` 档她表里两条都是 `id = "mianju1012"`（她表字段写重了，`count` 各 1）
#   —— 我**原样保留**成两条，不合并，免得"悄悄改掉她的配置"。
_LEIJI_COUNT = {
    30: [2, 1],
    100: [3, 2],
    300: [1, 1],
    500: [1, 1],
    800: [1, 1],
}


def _multi_tier_rows():
    """档位 → 真商品列表（shoplist 键 / 真名 / 每件数量列表）。

    ★ 键是我核对出来的：她表里的 `id` 有时是 shoplist 键（"100084"），
      有时是 `itemId`（"qiannengdan" / "jiu106" / "mianju1013"）——
      两种都归一成 shoplist 键（`GoodsHelper:getGoodsResClass` 只认后者）。
    ★ 名字用 **shoplist 那件真货的名字**；她表里那个 `name` 只是面板标签
      （"武功秘籍" 那两条实际都是面具）⇒ 绝不对着面具报"武功秘籍"。
    ★ 同一档同一件出现两次（她 `500` 档两个条目都是 `mianju1012`）⇒ 展开成两条
      （各 1 件，合计 2 件），保住"面板显示几件就发几件"。
    """
    out = {}
    for money in CHARGE_TIERS:
        rows = []
        entries = _LEIJI_TABLE.get(money, [])
        counts = _LEIJI_COUNT.get(money) or [1] * len(entries)
        for i, (key, rid) in enumerate(entries):
            if key not in goods():
                continue
            info = _info(key)
            rows.append({
                'key': key,
                'itemId': info['itemId'],
                'name': info['name'],
                'count': counts[i] if i < len(counts) else 1,
                'image': info['icon'],
                'showType': 1,
                'origItem': rid,
                # 她表里的 id 归一后**还是**这件货 ⇒ 没替换（她表里真有这件）
                'substituted': not (_s(rid) == _s(key) or _by_item_id().get(_s(rid)) == _s(key)),
            })
        out[money] = rows
    return out


def _ep_get_multi_festival_gift_list(ctx, st):
    """`get_multi_festival_gift_list`：`NewLeiJiChongZhiLayer:getNultiFestivalGiftList`(:82-98)
    读 `data.config`(:90) / `data.list`(:91/:137) / `data.shopping_money`(:125/:137) /
    `data.gift_list`(:126/:137)。

    ★ `list` 与 `gift_list` 都是**表**（键是档位金额的字符串），不是数组：
        `:127 MapIsEmpty(list)`（`list` 空 ⇒ 面板直接 return，什么都不显示）
        `:157 list[tostring(nowMoney)]` → 0 未达成 / 1 可领 / 2 已领
        `:498 for k,v in pairs(list) do if tonumber(k) < min` ⇒ **键必须能 tonumber**
        `:581 initGiftTable(tab)` 读 `tab.base[档位][i].itemId/number/name/imagePath/showType/nameDes`
    """
    total = _recharge_total(ctx)
    claimed = set(_num(x) for x in (st['festival'].get('multi_claimed') or []))
    tiers = _multi_tier_rows()

    row_map, gift_map = {}, {}
    for money in CHARGE_TIERS:
        rows = tiers.get(money) or []
        if not rows:
            continue
        if money in claimed:
            state = 2
        elif total >= money:
            state = 1
        else:
            state = 0
        row_map[str(money)] = state
        # ★ `gift_list` 的 `itemId` 必须是 **itemId**（"qiannengdan"），不是 shoplist 键：
        #   `NewLeiJiChongZhiLayer:initGiftTable`(:588-604) 把这个字段直接当
        #   `rewardList[档位][i].id`，然后 `getReward`(:433) `role:addItemCount(reward.id, count)`
        #   ⇒ 给 shoplist 键（"300004"）她客户端 `Item:getOneItemByKey` 查不到、
        #     `addItemCount` 静默 `return nil`（`Role_Item.lua:338-344`），奖励看不见。
        #   （服务端那份发放通道要的是 shoplist 键，见 `receive_*` 的 `reward`。）
        gift_map[str(money)] = [{
            'itemId': r['itemId'],
            'number': r['count'],
            'name': r['name'],
            'imagePath': r['image'],
            'showType': 1,
            'nameDes': '',
            'goodsKey': r['key'],
            'origItem': r['origItem'],
        } for r in rows]

    now = 0
    for money in sorted(CHARGE_TIERS):
        if row_map.get(str(money)) in (0, 1):
            now = money
            break
    else:
        now = CHARGE_TIERS[-1]

    _save(ctx, st)
    return ctx.ok({
        'list': row_map,
        'gift_list': gift_map,
        'shopping_money': total,
        'config': {'strategy_id': 1, 'base': gift_map, 'now_money': now},
        'now_money': now,
        'msg': '',
    }, '★ 累计充值：%d 档（30/100/300/500/800，内容照抄她 LeiJiChongZhiLayer.rewardList），'
       '已充 %d，当前档位 %d，可领 %d 档'
       % (len(row_map), total, now,
          sum(1 for m in row_map if row_map[m] == 1)))


def _ep_receive_multi_festival_gift(ctx, st):
    """`receive_multi_festival_gift`：`NewLeiJiChongZhiLayer:receiveNultiFestivalGift`(:373-396)
    读 `data.itemId`（`:379`/`:389` 拿去 `PopText` 和 `getReward`）。

    ★ 上下行：`{key=档位金额, order_id, item_id?}` —— `item_id` 是**她选的那件**（可选，
      多选礼包才有）。这里按档位真发货，并把选中的那件的 `itemId` 原样回给她。
    """
    money = _num(ctx.param('key'), 0)
    if money not in CHARGE_TIERS:
        return ctx.fail('档位不存在', '★ 累计充值领取：key=%r 不在 30/100/300/500/800 里' % _s(ctx.param('key')))
    total = _recharge_total(ctx)
    if total < money:
        return ctx.fail('累计充值未达到该档位',
                        '★ 累计充值领取：已充 %d < 档位 %d' % (total, money))
    if money in set(_num(x) for x in (st['festival'].get('multi_claimed') or [])):
        return ctx.fail('该档位奖励已领取', '★ 累计充值领取：%d 档已领过' % money)
    rows = (_multi_tier_rows().get(money) or [])
    if not rows:
        return ctx.fail('奖励配置为空', '★ 累计充值领取：%d 档在 shoplist 里取不到货' % money)
    chosen = _s(ctx.param('item_id'))
    back = rows[0]['itemId']
    got = []
    for r in rows:
        _grant(ctx, r['key'], r['count'])
        got.append('%s×%d' % (r['name'], r['count']))
        if chosen and chosen == r['itemId']:
            back = r['itemId']
    st['festival'].setdefault('multi_claimed', []).append(money)
    _save(ctx, st)
    # ★ `reward` 里两个 id 都给，避免"两套 id 体系"踩坑（这是实测出来的）：
    #     `goodsKey` = shoplist 键 —— 服务端发放通道 `GoodsHelper:getGoodsResClass(id)` 只认它；
    #     `id`       = itemId     —— 服务端 `items_currency` 两份账不一致（`bag` 存 shoplist 键、
    #                                `serverItems` 存 itemId，`add_count` 两处都试），
    #                                而客户端 `role:addItemCount(id)` 只认 itemId。
    #   `get_multi_festival_gift_list` 的 `gift_list.itemId` 同理给 itemId。
    return ctx.ok({
        'itemId': back,
        'reward': [{'id': r['itemId'], 'goodsKey': r['key'],
                    'num': r['count'], 'name': r['name']} for r in rows],
        'msg': '领取成功',
        'shopping_money': total,
    }, '★ 累计充值 %d 档领取：真发货 %s（返回 itemId=%s）' % (money, '、'.join(got), back))


# ===========================================================================
# 九、节庆测试后门（`init_test_festival_data` / `clean_test_festival_data`）
# ===========================================================================
def _ep_init_test_festival_data(ctx, st):
    """`init_test_festival_data`：`HttpManager.lua:1059-1062`（`{key=productId}`）。
    **客户端零调用点**（全量 grep 过）⇒ 原版是压测/联调后门。

    本模块让它做**真事**：在 `content_fill_state.json` 的 `festival.test` 下建一份
    模拟充值额（`productId` 就是她传的商品/档位键），供首充/累充面板联调。
    ★ 它**不动**玩家货币、不动存档、不动 `misc_extra` 的累充账本。
    """
    key = _s(ctx.param('key') or ctx.param('productId') or '')
    if not key:
        return ctx.fail('参数错误', '★ 节庆测试数据：上行缺 key（productId）', errcode=1)
    tid = _key_of(key)
    st['festival']['test'] = {'key': key,
                              'goodsKey': tid if tid in goods() else '',
                              'name': _info(tid)['name'] if tid in goods() else '',
                              't': int(time.time())}
    _save(ctx, st)
    return ctx.ok({'test': 1, 'key': key},
                  '★ 节庆测试数据已建：key=%s%s（只落在本模块的测试账里，不动货币/存档）'
                  % (key, '（对应商品 %s）' % _info(tid)['name'] if tid in goods() else ''))


def _ep_clean_test_festival_data(ctx, st):
    """`clean_test_festival_data`：`HttpManager.lua:1065-1068`（无参，**客户端零调用点**）。
    清掉 `festival.test` 那份测试账；没有测试账也回 0（后门幂等）。"""
    had = st['festival'].pop('test', None)
    _save(ctx, st)
    return ctx.ok({'clean': 1},
                  '★ 节庆测试数据已清（原有测试账=%s）' % ('有，已删' if had else '无'))


# ===========================================================================
# 十、师门建材（`get_teacherBuild_items`）
# ===========================================================================
def _tb_root(ctx):
    """读 `fz_api/teacher_build.py` 那**同一份**存档（不另记一份师门资源）。

    ★ 它的结构是 `{familyId: {gbpoint, sgbpoint, ..., builds:{buildingid:{...}}}, ...}`
      —— 根下**直接按门派 id 分档**（我实测 `teacherbuild_state.json` 的根键就是
      `['1','huashan',...]`），不是 `{families:{...}}`。
    """
    return _load_work_json(ctx, P_TEACHERBUILD_STATE)


def _fam_key(d):
    """从存档里认出**当前生效的门派 id**（读不到就空串；`_fam_node` 会退到第一个门派）。"""
    if not isinstance(d, dict):
        return ''
    for k in d:
        if isinstance(d.get(k), dict) and 'builds' in d[k]:
            return _s(k)
    return ''


def _fam_node(d, fam_id=None, create=False):
    """取某个门派的存档节点（**只在 create=True 时回落建一个**，读的时候绝不写）。"""
    if not isinstance(d, dict):
        return {}
    keys = [k for k in d if isinstance(d.get(k), dict) and 'builds' in d[k]]
    fid = _s(fam_id)
    if fid and isinstance(d.get(fid), dict):
        return d[fid]
    if keys:
        return d[keys[0]]
    if create and fid:
        d[fid] = {'builds': {}}
        return d[fid]
    return {}


def _mat_limit_table(family_id):
    """建材储存上限 —— **她表里写着真值**，不用编。

    `family/sectBuildInfo.lua` 的建筑 `101`（**储宝库**）每级 `effecttext` 就是上限：
        1级 → 360 / 2级 → 420 / 3级 → 510 / 4级 → 600 / 5级 → 720
    另有三种窑坊的 6 级把这**单种**建材的上限抬到另一个真值：
        104 土窑 → 三合土(bmaterials1) 870 / 105 砖窑 → 青石砖(bmaterials2) 870 /
        106 木坊 → 楠木(bmaterials3) 870
    （那三条 `effecttext` 写的是"…储存上限增加150个"，但 720+150=870 才是她那份文案里的
      数值口径 ⇒ 按**覆盖**取，不去加。）
    ⇒ 返回 ({属性名: 上限}, 基础上限)。
    """
    entries = _build_grade(family_id).get('101') or []
    base = 0
    base_by_lv = {}
    for e in entries:
        m = re.search(r'储存上限到(\d+)个', _s(e.get('effecttext')))
        if m:
            base_by_lv[_num(e.get('buildlv'))] = _num(m.group(1))
    if base_by_lv:
        base = base_by_lv[max(base_by_lv)]
    override = {}
    attr_of = {'104': 'bmaterials1', '105': 'bmaterials2', '106': 'bmaterials3'}
    for bid, attr in attr_of.items():
        for e in _build_grade(family_id).get(bid) or []:
            m = re.search(r'储存上限增加(\d+)个', _s(e.get('effecttext')))
            if m:
                override[attr] = max(override.get(attr, 0), _num(m.group(1)))
    out = {}
    for attr in BMATERIALS:
        out[attr] = override.get(attr) or (base or MATERIAL_LIMIT_BASE)
    return out, base or MATERIAL_LIMIT_BASE


def _ep_get_teacherBuild_items(ctx, st):
    """`get_teacherBuild_items`：`TeacherBuildItemPresenter:showPanelItem`(:31-51) 对
    `data` 做 `ipairs`，每项读 `v.itemId`(:37) 与 `v.count`/`v.countLimit`(:38)。
    `itemId` 是角色属性名（`Role.lua:1980-1985` 的 bmaterials1..6 → 三合土…生漆），
    数量取 `teacherbuild_state.json`（`fz_api/teacher_build.py` 的真账）。
    ⚠ `countLimit` 为 0/nil 会让她显示成 "3/nil" —— 必须给数字。
    """
    _d = _tb_root(ctx)
    node = _fam_node(_d, ctx.param('familyId') or ctx.param('menpai'))
    fam_id = _s(ctx.param('familyId') or ctx.param('menpai'))
    limits, base = _mat_limit_table(fam_id or _fam_key(_d))
    rows = []
    for attr in BMATERIALS:
        rows.append({
            'itemId': attr,
            'name': _cname(attr),
            'count': _num(node.get(attr), 0),
            'countLimit': limits.get(attr, base),
        })
    return ctx.ok(rows, '★ 师门建材 %d 种（bmaterials1..6 = 三合土/青石砖/楠木/汉白玉/琉璃瓦/生漆，'
                        '数量读 teacherbuild_state.json；上限是她 sectBuildInfo 建筑101 储宝库 '
                        'effecttext 里的真值 %d）' % (len(rows), base))


# ===========================================================================
# 十一、师门名绩（`get_teacherFeat_info` / `get_teacherFeat_reward`）
# ===========================================================================
def _feat_info():
    """`family/featInfo.lua`（名绩表：`featsid/label/camp/title/text/awardtext/awards/Completion`）。"""
    t = _lua(os.path.join(P_FAMILY, 'featInfo.lua'))
    fam = t.get('1') if isinstance(t.get('1'), dict) else t
    return {k: v for k, v in fam.items() if isinstance(v, dict) and v.get('featsid')}


def _feat_class_levels(family_id):
    """`family/featClassLevel.lua` —— 职阶门槛（`featscount`），按 `familyId` 取。"""
    t = _lua(os.path.join(P_FAMILY, 'featClassLevel.lua'))
    if not isinstance(t, dict):
        return []
    fam = t.get('1') if isinstance(t.get('1'), dict) else t
    rows = []
    for v in fam.values():
        if isinstance(v, dict) and v.get('classlevel') is not None:
            rows.append(v)
    if not rows:
        return []
    fid = _s(family_id)
    same = [v for v in rows if _s(v.get('familyId')) == fid]
    use = same or rows
    use.sort(key=lambda v: _num(v.get('classlevel')))
    return use


def _feat_scount(ctx, st, node, feat_info):
    """名绩点数（可花的）：**优先 `teacherbuild_state.json` 的 `featscount`**
    （`fz_api/teacher_build.py` 那份真账，`get_teacherBuild_info` 也回它）⇒ 面板与按钮同源；
    没有就用本模块账本兜底。"""
    if node.get('featscount') is not None and 'featscount' in node:
        return _num(node.get('featscount'), 0)
    return _num(st['feat'].get('featscount'), 0)


def _feat_judge_value(node, st):
    """**判"够不够领"用的累计量** —— 她 `featInfo.Completion` 是
    `[["sgbpoint", 190]]`（"累计提供门派昌盛度190点"），对应角色属性 `sgbpoint`
    （`Role.lua` 的 `getCHAttrName`，师门建设面板也读它）⇒ 用 `sgbpoint` 判门槛，
    **不是**可花的 `featscount`（那是 `awards` 发下来的名绩点道具数）。
    """
    if 'sgbpoint' in node:
        return _num(node.get('sgbpoint'), 0)
    return _num(st['feat'].get('sgbpoint'), 0)


def _completion_value(entry):
    """`Completion = [["sgbpoint", 190]]` → 取第一条的 (属性, 门槛值)。"""
    comp = entry.get('Completion')
    if isinstance(comp, list) and comp and isinstance(comp[0], list) and len(comp[0]) >= 2:
        return _s(comp[0][0]), _num(comp[0][1], 0)
    return '', 0


def _ep_get_teacherFeat_info(ctx, st):
    """`get_teacherFeat_info`：`TeacherBuildSystem:getTeacherFeatData`(:1019-1037) 读
    `data.list`(:1025) 与 `data.featscount`(:1027)；`TeacherFeatPresenter:initFeatList`(:57-71)
    按每项 `v.id` 去 `featInfo` 查 `label`（1="日积月累" / 2="千里之任"），
    `showListViewFeat`(:84-145) 读 `v.state`（0 未达成 / 1 可领 / 2 已完成）。
    ★ 她**不读** `list` 里的 title/text，那些由客户端从 `featInfo` 自己取 ⇒
      本模块只要给对 `id`（= `featsid`）与 `state`。
    """
    fam_id = _s(ctx.param('familyId') or ctx.param('menpai'))
    _d = _tb_root(ctx)
    node = _fam_node(_d, fam_id)
    scount = _feat_scount(ctx, st, node, None)
    judge = _feat_judge_value(node, st)
    claimed = set(_s(x) for x in (st['feat'].get('claimed') or []))
    rows = []
    for fid, entry in _feat_info().items():
        attr, need = _completion_value(entry)
        if _s(fid) in claimed:
            state = 2
        elif need and judge >= need:
            state = 1
        elif need:
            state = 0
        else:
            # `Completion` 为空的条目（她表里有少量）⇒ 视为可领（没有门槛就是不设门槛）
            state = 1
        rows.append({
            'id': _num(fid, 0),
            'goodsId': _s(fid),
            'state': state,
            'label': _num(entry.get('label'), 1),
            'camp': _num(entry.get('camp'), 0),
            'title': _s(entry.get('title')),
            'text': _s(entry.get('text')),
            'awardtext': entry.get('awardtext') if isinstance(entry.get('awardtext'), list) else [],
        })
    rows.sort(key=lambda r: (r['label'], r['id']))
    cls = _feat_class_levels(fam_id)
    clsname = ''
    for v in cls:
        if scount >= _num(v.get('featscount'), 0):
            clsname = _s(v.get('text'))
    return ctx.ok({
        'list': rows,
        'count': scount,
        'featscount': scount,
        'classLevel': _num(cls[-1].get('classlevel'), 0) if cls else 0,
        'className': clsname,
        'dataVer': _dataver(ctx),
    }, '★ 师门名绩：%d 条（featInfo.lua 真表；可领 %d / 已领 %d，名绩点数 %d%s）'
       % (len(rows), sum(1 for r in rows if r['state'] == 1),
          sum(1 for r in rows if r['state'] == 2), scount,
          '，职阶「%s」' % clsname if clsname else ''))


def _entry_awards(entry):
    """`awards = [["400030", 35]]` → shoplist 键 + 数量（`awards` 的第一项就是商品 id）。"""
    out = []
    for a in (entry.get('awards') or []):
        if not isinstance(a, list) or len(a) < 2:
            continue
        key = _key_of(a[0])
        if key not in goods():
            continue
        out.append({'id': key, 'num': max(1, _num(a[1], 1))})
    return out


def _ep_get_teacherFeat_reward(ctx, st):
    """`get_teacherFeat_reward`：`TeacherBuildSystem:getTeacherFeatReward`(:1045-1068) 读
    `data.featscount`(:1053)、`data.reward`(:1059 → `GoodsHelper:fromNetworkGrantGoods`，
    元素 `{id,num}` 且 `id` 是 shoplist 键)、`data.dataVer`(:1059)、`data.msg`(:1061)。

    ★ 发货用的是"名绩点"（`featInfo.awards` 里的 `["400030", N]`），所以必须**真发**
      并记账，否则她重复点会给重复奖励。名绩点数同时 +`N`（`awards` 第二项）。
    """
    fid = _s(ctx.param('featId') or ctx.param('featid'))
    entry = _feat_info().get(fid)
    if not isinstance(entry, dict):
        return ctx.fail('名绩不存在', '★ 师门名绩领取：featId=%r 不在 family/featInfo.lua 里' % fid)
    claimed = st['feat'].setdefault('claimed', [])
    if _s(fid) in set(_s(x) for x in claimed):
        return ctx.fail('该名绩奖励已领取', '★ 师门名绩领取：featsid=%s 已领过' % fid)
    _d = _tb_root(ctx)
    node = _fam_node(_d, ctx.param('familyId') or ctx.param('menpai'))
    scount = _feat_scount(ctx, st, node, entry)
    judge = _feat_judge_value(node, st)
    _attr, need = _completion_value(entry)
    if need and judge < need:
        return ctx.fail('尚未达成该名绩条件',
                        '★ 师门名绩领取：需要 %s ≥ %d，当前 %d（判据读 teacherbuild_state.json）'
                        % (_attr or 'cumulative', need, judge))
    rewards = _entry_awards(entry)
    if not rewards:
        return ctx.fail('奖励配置读取失败',
                        '★ 师门名绩领取：awards %s 里没有一件能落到 shoplist 上的货'
                        % _s(entry.get('awards')))
    got = []
    for r in rewards:
        _grant(ctx, r['id'], r['num'])
        got.append('%s×%d' % (_info(r['id'])['name'], r['num']))
    claimed.append(_s(fid))
    # 名绩点数：她 `awards` 就是名绩点道具，点数直接 +N（面板 `Text_FeatPoint` 显示它）
    add = 0
    for a in (entry.get('awards') or []):
        if isinstance(a, list) and len(a) >= 2 and _s(a[0]) in ('400030',):
            add += max(0, _num(a[1], 0))
    st['feat']['featscount'] = scount + add
    _save(ctx, st)
    return ctx.ok({
        'reward': rewards,
        'featscount': st['feat']['featscount'],
        'dataVer': _dataver(ctx),
        'msg': '领取成功，获得%s' % '、'.join(got),
    }, '★ 师门名绩 %s 领取：真发货 %s，名绩点数 %d→%d'
       % (_s(entry.get('title')) or fid, '、'.join(got), scount, st['feat']['featscount']))


# ===========================================================================
# 十二、振兴门派 / 兴建建筑（`get_sectRevitalization_info` / `_reward`）
# ===========================================================================
def _build_grade(family_id):
    """`family/sectBuildInfo.lua` → {buildingid: [各等级条目，按 buildlv 升序]}。"""
    t = _lua(os.path.join(P_FAMILY, 'sectBuildInfo.lua'))
    fam = t.get('1') if isinstance(t.get('1'), dict) else t
    idx = {}
    for v in fam.values():
        if isinstance(v, dict):
            idx.setdefault(_s(v.get('buildingid')), []).append(v)
    for k in idx:
        idx[k].sort(key=lambda e: _num(e.get('buildlv')))
    return idx


def _build_exp_lv(family_id, build_type_id, exp):
    """照抄她 `TeacherBuildSystem:getBuildByExp`：exp >= maxupresources 的最高等级。"""
    entries = _build_grade(family_id).get(_s(build_type_id)) or []
    lv = 0
    for e in entries:
        if _num(exp) >= _num(e.get('maxupresources')):
            lv = _num(e.get('buildlv'))
    nxt = None
    for e in entries:
        if _num(e.get('buildlv')) > lv:
            nxt = _num(e.get('maxupresources'))
            break
    return lv, nxt, entries


def _daily_reward(family_id):
    """今日可分配资源：取她表里建筑 `cescalation`（每日可分配修筑度）的**真值档位**。

    原版每日额度在服务端 DB，客户端与资源表里没有这个数 ⇒ 用表里最小的 `cescalation`
    （真值，如 150 / 384），两个资源是 `upresources`(修筑度) 与 `gbpoint`(门派昌盛度)。
    """
    idx = _build_grade(family_id)
    vals = []
    for bid, entries in idx.items():
        for e in entries:
            v = _num(e.get('cescalation'))
            if v > 0:
                vals.append(v)
    base = min(vals) if vals else 0
    return [{'id': 'upresources', 'number': base},
            {'id': 'gbpoint', 'number': max(1, base // 3)}]


def _ep_get_sectRevitalization_info(ctx, st):
    """`get_sectRevitalization_info`：`TeacherBuildPromote:init`(:34-55) 读
    `data.buildReward`(:36) / `data.buildConditionText`(:37-38) / `data.buildingList`(:42)；
    `__dealWithInfo`(:97-126) 逐项读 `v.buildTypeId` / `v.state` / `v.buildName` /
    `v.buildLv` / `v.buildCurrentExp` / `v.buildMaxExp`；`TeacherBuildPromotePresenter`(:63-68)
    还读 `rewards[i].id` / `rewards[i].number`（`string.gsub` 填进弹窗文案）。

    ★ `state` 是她判"已满级"的开关（`:134 if v.state == 1 then 该建筑已达到满级`），
      必须是数字：0 可兴建 / 1 已满级。
    """
    fam_id = _s(ctx.param('familyId') or ctx.param('menpai'))
    _d = _tb_root(ctx)
    node = _fam_node(_d, fam_id)
    builds = node.get('builds') if isinstance(node.get('builds'), dict) else {}
    idx = _build_grade(fam_id)
    rows = []
    for bid in sorted(idx):
        b = builds.get(_s(bid)) if isinstance(builds.get(_s(bid)), dict) else {}
        exp = _num(b.get('buildTeacherExp'), 0)
        lv, nxt, entries = _build_exp_lv(fam_id, bid, exp)
        max_lv = max([_num(e.get('buildlv')) for e in entries] or [0])
        name = ''
        for e in entries:
            if _num(e.get('buildlv')) == lv:
                name = _s(e.get('buildname'))
                break
        if not name and entries:
            name = _s(entries[0].get('buildname'))
        rows.append({
            'buildTypeId': _s(bid),
            'state': 1 if (nxt is None and lv >= max_lv) else 0,
            'buildName': name,
            'buildLv': lv,
            'buildCurrentExp': exp,
            'buildMaxExp': nxt if nxt is not None else exp,
        })
    rewards = _daily_reward(fam_id)
    conds = []
    for e in (idx.get(sorted(idx)[0]) if idx else []):
        for c in (e.get('condition') or []):
            if isinstance(c, list) and len(c) >= 2:
                conds.append('%s ≥ %s' % (_cname(_s(c[0])), _s(c[1])))
        if conds:
            break
    return ctx.ok({
        'buildReward': rewards,
        'buildConditionText': '；'.join(conds) if conds else '',
        'buildingList': rows,
        'dataVer': _dataver(ctx),
    }, '★ 振兴门派：%d 种建筑（sectBuildInfo 真表），今日可分配 %s；'
       '分配额度取表里 cescalation 真值（原版每日额度在服务端）'
       % (len(rows), '、'.join('%s×%d' % (_s(r['id']), r['number']) for r in rewards)))


def _ep_get_sectRevitalization_reward(ctx, st):
    """`get_sectRevitalization_reward`：`TeacherBuildPromote:doReward`(:81-95) **只看 errcode**
    （回调 `callback(errcode, errmsg)`，`:79-84` errcode=0 才弹「兴建成功」）。
    本模块：把今日可分配额度**真加**到 `teacherbuild_state.json`（与 `teacher_build.py` 同源），
    并记"今日已分配"，同一天不重复发。
    """
    fam_id = _s(ctx.param('familyId') or ctx.param('menpai'))
    bid = _s(ctx.param('buildTypeId') or ctx.param('buildtypeid'))
    if not bid:
        return ctx.fail('参数错误', '★ 振兴门派领取：上行缺 buildTypeId', errcode=1)
    idx = _build_grade(fam_id)
    if bid not in idx:
        return ctx.fail('建筑不存在',
                        '★ 振兴门派领取：buildTypeId=%r 不在 family/sectBuildInfo.lua 里' % bid)
    day = int(time.time()) // DAY
    rv = st['revitalization']
    if _num(rv.get(_uid(ctx)), -1) == day:
        return ctx.fail('今日已分配过', '★ 振兴门派领取：本账号今天(%d)已分配' % day)
    rewards = _daily_reward(fam_id)
    # ★ 与 `fz_api/teacher_build.py` 共用**同一份**存档 `work/teacherbuild_state.json`：
    #   读-改-写。落的字段全是她客户端真会读的：
    #     `upresources` → 选中建筑的 `builds[buildTypeId].buildTeacherExp`
    #        （`:38` 里的 "res1 也会增加"，客户端 `TeacherBuildSystem:getBuildByExp` 用它算等级）
    #     `gbpoint`     → 门派级 `gbpoint`（门派昌盛度，师门建设面板的 `getSectLevelData` 读它）
    try:
        with open(ctx.data_file(P_TEACHERBUILD_STATE), encoding='utf-8') as f:
            tb = json.load(f)
        if not isinstance(tb, dict):
            tb = {}
    except Exception:                           # noqa: BLE001
        tb = {}
    node = _fam_node(tb, fam_id, create=True)
    if not isinstance(node.get('builds'), dict):
        node['builds'] = {}
    rec = node['builds'].get(bid)
    if not isinstance(rec, dict):
        rec = {'buildTypeId': bid, 'buildTeacherExp': 0, 'buildLv': 0, 'state': 0}
        node['builds'][bid] = rec
    applied = []
    for r in rewards:
        n = _num(r['number'], 0)
        if _s(r['id']) == 'upresources':
            before = _num(rec.get('buildTeacherExp'), 0)
            # 照她 `isMaxBuildLevel` 的口径：超出下一级门槛的部分无法返还
            _lv, nxt, _e = _build_exp_lv(fam_id, bid, before)
            after = before + n
            if nxt is not None and after > nxt:
                applied.append('修筑度 %d→%d（超出 %d 无法返还，上限 %d）'
                               % (before, nxt, after - nxt, nxt))
                after = nxt
            else:
                applied.append('修筑度 %d→%d' % (before, after))
            rec['buildTeacherExp'] = after
        else:
            before = _num(node.get(r['id']), 0)
            node[r['id']] = before + n
            applied.append('%s %d→%d' % (_s(r['id']), before, node[r['id']]))
            # 真货币账也要同步（`items_currency._purse` 与这里不是同一个账本，
            # 面板读的是后者；两边都给才一致）
            try:
                _ic().add_currency(ctx, _s(r['id']), n)
            except Exception:                   # noqa: BLE001
                pass
    # 名绩点数（`featscount`）在全服面板上显示，这里同步一份到 `teacher_build` 的账本
    node.setdefault('featscount', _num(node.get('featscount'), 0))
    try:
        with open(ctx.data_file(P_TEACHERBUILD_STATE), 'w', encoding='utf-8') as f:
            json.dump(tb, f, ensure_ascii=False, indent=1)
    except OSError:
        pass
    rv[_uid(ctx)] = day
    _save(ctx, st)
    return ctx.ok({
        'reward': rewards,
        'buildTypeId': bid,
        'buildTeacherExp': _num(rec.get('buildTeacherExp'), 0),
        'gbpoint': _num(node.get('gbpoint'), 0),
        'msg': '兴建成功',
        'dataVer': _dataver(ctx),
    }, '★ 振兴门派分配 → 建筑 %s：真加 %s（写进 teacherbuild_state.json，与师门建设面板同源）'
       % (bid, '、'.join(applied)))


# ===========================================================================
# 十三、元宝刷新师门任务（`fresh_task_by_yuanbao`）
# ===========================================================================
REFRESH_FREE_TIMES = 3          # 她 `ReceiveTeacherTaskLayer:setRefreshButton`(:249) `count >= 3`


def _ep_fresh_task_by_yuanbao(ctx, st):
    """`fresh_task_by_yuanbao`：`ReceiveTeacherTaskLayer:setRefreshButton`(:244-286) ——
    她 `count >= 3`（免费次数用完）时弹框，`HttpManagerEx:refreshTeacherTaskList(count)`
    (:263) 上行 `{yuanbao = count}`；回调**只看 errcode**，errcode=0 就
    `TeacherTask:initTeacherTask()` 本地重掷列表(:268)。

    ⇒ 服务端该做的就是"**真扣元宝 + 放行**"（原版语义）。
    扣款额以她上行的 `yuanbao` 为准（她按 `(count-2)*10` 算，`setRefreshCount` :238），
    但用 `min(…, 100)` 封顶（她 `:238 math.min((count-2)*10,100)` 同口径）。
    """
    cost = _num(ctx.param('yuanbao'), 0)
    cost = max(0, min(cost, 100))
    if cost and not _spend_cur(ctx, YUANBAO, cost):
        return ctx.fail('元宝不足', '★ 师门任务刷新：需要 %d 元宝，当前 %d'
                        % (cost, _cur(ctx, YUANBAO)))
    left = 0
    if not cost:
        left = REFRESH_FREE_TIMES
    # ★ 不回 `list`：她这条路径**一个字段都不读**（只判 `errcode == 0`，然后自己
    #   `TeacherTask:initTeacherTask()` 本地重掷），而空 `list` 反而会让"内容空壳审计"
    #   把它算成 list-empty —— 那是审计口径问题，不是内容缺失。宁可字段少，别给空表。
    return ctx.ok({
        'yuanbao': _cur(ctx, YUANBAO),
        'cost': cost,
        'free_times': REFRESH_FREE_TIMES,
        'left': left,
        'dataVer': _dataver(ctx),
    }, '★ 师门任务刷新：真扣 %d 元宝（她只看 errcode，列表由客户端 initTeacherTask 本地重掷；'
       '余 %d 元宝）' % (cost, _cur(ctx, YUANBAO)))


# ===========================================================================
# 路由
# ===========================================================================
_HANDLERS = {
    'get_teacher_shop': _ep_get_teacher_shop,
    'buy_teacher_good': _ep_buy_teacher_good,
    'update_menpai_gongxiangdian': _ep_update_menpai_gongxiangdian,
    'get_devote_point': _ep_get_devote_point,
    'add_devote_point': _ep_add_devote_point,
    'get_npc_store_list': _ep_get_npc_store_list,
    'get_activity_list': _ep_get_activity_list,
    'get_festivalmap_info': _ep_get_festivalmap_info,
    'get_first_festival_gift': _ep_get_first_festival_gift,
    'get_multi_festival_gift_list': _ep_get_multi_festival_gift_list,
    'receive_first_festival_gift': _ep_receive_first_festival_gift,
    'receive_multi_festival_gift': _ep_receive_multi_festival_gift,
    'init_test_festival_data': _ep_init_test_festival_data,
    'clean_test_festival_data': _ep_clean_test_festival_data,
    'get_teacherBuild_items': _ep_get_teacherBuild_items,
    'get_teacherFeat_info': _ep_get_teacherFeat_info,
    'get_teacherFeat_reward': _ep_get_teacherFeat_reward,
    'get_sectRevitalization_info': _ep_get_sectRevitalization_info,
    'get_sectRevitalization_reward': _ep_get_sectRevitalization_reward,
    'fresh_task_by_yuanbao': _ep_fresh_task_by_yuanbao,
}


def handle(ctx):
    ep = ctx.endpoint
    fn = _HANDLERS.get(ep)
    if fn is None or ep not in ENDPOINTS:
        return None
    st = _st(ctx)
    try:
        return fn(ctx, st)
    except Exception as e:                      # noqa: BLE001
        # ★ 绝不让异常穿出去（`fz_api.dispatch` 会回 errcode=1 且把栈打到日志）——
        #   这里明确回一个带说明的失败，方便排障时一眼看出是本模块哪一步。
        ctx.log('[content_fill] %s 抛异常：%s' % (ep, e))
        return ctx.fail('服务器内部错误：%s' % e,
                        '★ content_fill 处理 %s 时异常（已捕获）' % ep)
