# -*- coding: utf-8 -*-
# ================= 离线包路径根（fz_make_offline_bundle.py 自动注入） =================
# 手机上整个服务端就是一个目录，表在哪、状态写哪，全部相对包根算。
# （有的模块原来把绝对路径写死，本身没 import os —— 这里一并补上）
import os
import os as _osp


def _off_find_bundle(_f):
    """从模块所在目录往上找包根（认 fz_boot_server.py）。
    ★ fz_api/*.py 的 __file__ 在 <根>/fz_api/ 下，直接 dirname 会算错一层。"""
    _d = _osp.path.dirname(_osp.path.abspath(_f))
    for _ in range(6):
        if _osp.path.exists(_osp.path.join(_d, 'fz_boot_server.py')):
            return _d
        _u = _osp.path.dirname(_d)
        if _u == _d:
            break
        _d = _u
    return _osp.path.dirname(_osp.path.abspath(_f))


_OFF_BUNDLE = _off_find_bundle(__file__)
_OFF_FZ_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_fz')
_OFF_INK_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_ink')
_OFF_WORK_ROOT = _OFF_BUNDLE
# =====================================================================================
# ★ 2026-10-04 商城空货架修复：客户端资源表解析——PC 开发树优先，设备上自动回退
#   到包内 client_fz 副本（jhserver/client_fz = fangzhi_lua_dec 的同步拷贝）。
def _fz_res(*parts):
    base = os.path.join(_OFF_FZ_ROOT, 'res', 'script')
    if not os.path.isdir(base):
        base = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            '..', 'client_fz', 'res', 'script')
    return os.path.join(base, *parts)

# -*- coding: utf-8 -*-
"""misc_systems —— 面具/炼形、账号绑定、观影堂、官职政绩、通用货币兑换。

契约出处（客户端 `assets/src`，行号为注释里那一版）：
  * `app/models/mask/MaskSystem.lua`
  * `app/models/account/Account.lua`
  * `app/models/CommercialTime/CommercialTime.lua`
  * `app/models/map/MapHandle/Modules/CommonModule/CommonResults.lua`

== 接口 → 客户端读哪些 `data.字段`（类型） ==
| 接口 | 她读的字段 |
|---|---|
| `get_makeMask_info` | `spNum`(数) `payNum`(数) `randomList`(数组，元素 `{name(串), list(数组 {id(串goodsId), odds(数)})}`) `payMaskList`(数组，元素 `{name(串), list(数组 {id(数syntheticId), state(数0/1)})}`) |
| `make_randomMask` | `spNum`(数) `goodsId`(串，`shoplist.lua["Sheet1"]` 的真键) |
| `make_payMask` | `spNum`(数) `payNum`(数) `goodsId`(串) |
| `get_payMask_gift_info` | `activityName`(串) `activityDesc`(**数组**，逐条 `..` 拼串) `giftList`(数组) |
| `receive_payMask_gift` | `rewards`(数组 `{id(串goodsId), num(数)}`) `giftList`(数组) `msg`(串) `currencyVersion`(数)。`giftList[i]={id(数), state(数0~4), nextReceiveTime(数)}` |
| `mask_upgrade` | `currencyVersion`(数)；请求体 `{params=conditions, currencyVersion}` |
| `get_bind_info` | `email`(串，未绑定 **必须是字符串 "0"**) `phone`(数) `is_bind`(数0/1) `is_logout`(数0/1) `auth`(数) |
| `get_email` | `email`(串) `is_bind`(数) `is_logout`(数) |
| `send_email` / `send_verify_code` | `expired_time`(数，unix 秒) |
| `bind_device` / `bind_device_2` / `login_device` / `logout_device` | 只看 errcode |
| `check_has_yashi` | `yashi`(数，unix 秒，0=没有) |
| `get_viewing_hall` | `ruleDesc`(**数组**) `lastViewTime`(数) `coolDown`(数) `isReachLimit`(数0/1) `guanyingquan`(数) `isPromotionActive`(数，`==1` 才开) `privilege_expired_time`(**数**) `privilege_remaining_watches`(数) `rewards`(**数组**，元素 `{id(数rid), itemId(串), name(串), number(数), icon(串), itemType(数), awardType(数), getTimes(数), maxTimes(数), endTime(数未来秒)}`) |
| `get_viewing_reward` | `reward`(**对象** `{itemType(数), id(串itemId), name(串), number(数)}`，可空) + `msg`(串)；errcode 1=没有观影券 2=特权过期 |
| `get_viewing_privilege_info` | `act_name`(串) `rule_desc`(**数组**) `detail_time`(串) `detail_desc`(**数组，至少 4 条**) `privilege_expired_time`(数) `buy_times`(数) `status`(数，**只能 0/1/2**) |
| `get_viewing_privilege_reward` | `privilege_expired_time`(数) `status`(数0/1/2) |
| `get_user_guanzhi` | `guanzhi`(数) `zhengji`(数) |
| `upload_zhengji` | `zhengji`(数，累计值)；请求体 `{zhengji, guanzhi}` |
| `delete_my_guanzhi` | 只看 errcode |
| `get_guanzhi_fenlu` | `guanzhi`(数) `zhengji`(数) `is_normal`(**串**，"N"=俸禄减半) `meiyu`(数) `yinpiao`(数) |
| `add_zhounian_jifen` | `number`(数) `total`(数) |
| `martial_upgrade_add_currency` | `reward`(**数组**，元素 `{id(串), name(串), num(数)}`) `currencyVersion`(数) `msg`(串) |
| `get_youxia_upgradeCondition` / `youxia_upgrade_condition` | `id`(数，`mcmrestrictLevel.lua["1"]` 的键) `currencyVersion`(数) |
| `delete_youxia_upgradeCondition` | 只看 errcode |
| `get_config_times` | `num`(数，已用次数) `remove`(数，本次花费元宝，>0 才弹确认) `yuanbao`(数，拥有元宝) |
| `get_fond_dream_role` | 故意 errcode 2 = 没有进行中的南柯梦境，她开 `ChessboardLayer` 新棋局 |
| `settle_overdue_fond_dream` | 故意 errcode 2 = 没有要结算的过期梦境 |
| `get_random_userdata` | `name`(串) `sex`(串 "男"/"女") `id`(串，`role.id == nil` 就 return，**必须给**) |
| `get_discount_coupon` | `success`(数，`==0` 才发券) |
| `add_user_mingbi` | `number`(数) `total`(数) |
| `shop_exchange_goods` | `romove_point`(数，>0 才弹提示) `reward`(**对象** `{itemId(串), name(串), number(数), itype(数1/2/3)}`，可空) |

== 内容取自她哪张表（全部用 `work/fz_luatable.py` 的 `load_lua_table` 解析） ==
* `res/script/store/shoplist.lua["Sheet1"]`（2228 条，键形如 `"400001"`）
  —— 所有 `goodsId` / `itemId` / `name` / `icon` / `itype` 的**唯一来源**。
* `res/script/others/maskUpgrade.lua["Sheet1"]`（401 条面具，`maskId`=`mianju1180`…）
  —— `randomList` 的货架；用 `shoplist` 里 `itemId == maskId` 反查真键；
  大类名「戏曲面具 / 百花焕颜」出自 `MaskInfoPresenter.lua:159-171` 的文案。
* `res/script/others/specialSyntheticMask.lua["面具配置"]`（id 只能 1/2/3，
  `goodsId`/`series`/`sorts`/`makecondition`）—— `payMaskList` 的货架；
  `makecondition` 里 `[7,x]`=饰品材料、`[11,x]`=付费制作材料（`MaskConst.lua:13-25`）。
* `res/script/activity/specialMaskgift.lua["Sheet1"]`（id 1/2/3，
  `goodsId`/`rewards`/`rewardsdays`/`begintime`/`finishtime`/`limit`）
  —— `giftList` 与 `receive_payMask_gift` 的 `rewards`（原样 `[[goodsId,num]]` 转 `{id,num}`）。
  ★ 她 `SyntheticMask.lua:16-18` 对这两张表都 `assert`，所以 id **只能**是 1/2/3。
  ★ 这张表的 `begintime/finishtime`（2025-02~2026-04）在我们这份包里已全部过期，
    因此 `_gift_stale_window()` 把「全过期」视为「窗口常开」（否则赠礼面板永远点不动）。
* `res/script/activity/viewingHallactivity.lua["Sheet1"]["viewingHallactivity"]`
  —— 观影堂特权：`threshold`(10 次解锁加送)、`days`(加送 42 天)、`productkey`。
* `res/script/roleTitle/officialChenHao.lua["Sheet1"]`（21 条，`type` 1/2/3=翰林/庶吉士/县令，
  `integral` 政绩门槛，`number` 称号档位，`text` 称号名）
  —— 俸禄里的 `meiyu`/`is_normal` 就是按政绩在这张表里命中档位算出来的。
* `res/script/others/mcmrestrictLevel.lua["1"]`（`100`/`101`，`count`/`mcmrestrict`/`unlockcondition`）
  —— 散人提升门外武学的 `id`。
* `res/script/skill/breakThroughItems.lua["Items"]`（`skillUpItem01`…）—— 武学上限突破奖励的道具名。
* `res/script/npc/npc.lua["npcs"]`（`name`/`sex`）—— 中原花会 `get_random_userdata` 借一个真 NPC 名。
* **钱**：元宝/银两与 `fz_api/homeland_life.py` 共用 `work/homeland_state.json` 的 `currency`
  （`{'yinpiao':..,'yuanbao':..,'money':..}`），**不另造第二份钱**。

== 状态（真写盘 `work/misc_state.json`） ==
`mask`(饰品材料/付费材料/已制作/已获得/赠礼领取记录)、`account`(邮箱/手机/验证码/雅士)、
`viewing`(观影券/上次观影/各档已领次数/特权到期/购买次数)、`official`(官职/政绩/今日俸禄)、
`action_times`(各 `com_config` 已用次数)、`jifen`(周年积分)、`mingbi`(冥币)、
`martial_currency`(武学突破道具)、`youxia`(散人已提升档位)、`coupon`(已发优惠券)。

== 已知没做 / 需要别的模块配合 ==
1. **授官**（科举/殿试 → `officialType`）属科举模块；本模块只按她上送的存档读官职，
   并保证 `upload_zhengji` 真记事。新号 `guanzhi=0`，她客户端会自己弹「因政绩考评太差…」。
2. **`shop_exchange_goods` 的 `romove_point`**：价格由她服务端 `map/mapConditionAndResult/*.lua`
   里 `21wjtrade*` 那一档保管，客户端只上传 `itemId/client_trans_id/shop_id` 不上传价格
   ⇒ 回 0（她只在 >0 时弹一句提示）。
3. `settle_overdue_fond_dream` / `get_fond_dream_role` 故意回 **errcode=2**
   （「没有过期/进行中的南柯梦境」），这正是她真实服务端对新号的语义，探针会记成
   「errcode≠0」，属预期。
4. `get_config_times` 只**报**花费不扣钱（真正扣钱是 `remove_config_point`，不属本模块）；
   元宝数读 `homeland_state.json`。
5. 邮箱/验证码是**离线模拟**：`send_email`/`send_verify_code` 直接把验证码写进
   `misc_state.json`（不真发信），`bind_device*` 校验它就是。
6. `special_item_exchange` **不在本模块**（已归 `fz_api/items_currency.py`，避免重复声明）。
"""
import os
import random
import time

NAME = 'misc_systems'
TITLE = '面具/炼形/账号绑定/观影堂/装饰'
ENDPOINTS = [
    # 面具制作 / 墨千秋赠礼 / 面具升级（MaskSystem.lua）
    'get_makeMask_info',
    'make_randomMask',
    'make_payMask',
    'get_payMask_gift_info',
    'receive_payMask_gift',
    'mask_upgrade',
    # 账号绑定 / 邮箱验证（Account.lua）
    'get_bind_info',
    'get_email',
    'send_email',
    'send_verify_code',
    'bind_device',
    'bind_device_2',
    'login_device',
    'logout_device',
    'check_has_yashi',
    # 观影堂 / 商业时间（CommercialTime.lua）
    'get_viewing_hall',
    'get_viewing_reward',
    'get_viewing_privilege_info',
    'get_viewing_privilege_reward',
    # 官职 / 政绩（CommonResults.lua）
    'get_user_guanzhi',
    'upload_zhengji',
    'delete_my_guanzhi',
    'get_guanzhi_fenlu',
    # 周年积分 / 武学突破 / 散人提升 / 通用
    'add_zhounian_jifen',
    'martial_upgrade_add_currency',
    'get_youxia_upgradeCondition',
    'youxia_upgrade_condition',
    'delete_youxia_upgradeCondition',
    # ★ special_item_exchange 归 fz_api/items_currency.py（重复声明会撞车）
    'get_config_times',
    'get_fond_dream_role',
    'settle_overdue_fond_dream',
    'get_random_userdata',
    'get_discount_coupon',
    'add_user_mingbi',
    'shop_exchange_goods',
]

RES_ROOT = _fz_res()
WORK = _OFF_WORK_ROOT
STATE = 'misc_state.json'                 # 本模块独有状态
HOME_STATE = 'homeland_state.json'        # 与 homeland_life.py 共用的钱袋

COOL_DOWN = 30                            # 观影堂广告冷却（秒）
DAILY_VIEW_LIMIT = 8                      # 每天可免费观影 8 次
PRIVILEGE_WATCHES = 8                     # 特权生效时每日免广告 8 次
ACTION_COST = {                           # `get_config_times` 的元宝价（她服务端配置）
    'JingMaiChongZhu': 50,
    'refreshFuben': 30,
    'FishingGame': 20,
    'RiverLamp': 20,
    'LadderLantern': 20,
    'YinYangHuHuang': 100,
}
DEFAULT_COST = 20

_CACHE = {}


# ---------------------------------------------------------------- 她自己的表


def _lua(rel, *keys):
    """读 `res/script/<rel>`，顺着 key 一层层走；失败就回空表（绝不抛）。"""
    ck = (rel, keys)
    if ck in _CACHE:
        return _CACHE[ck]
    val = {}
    try:
        import sys
        if WORK not in sys.path:
            sys.path.insert(0, WORK)
        from fz_luatable import load_lua_table
        val = load_lua_table(os.path.join(RES_ROOT, rel))
        for k in keys:
            if isinstance(val, dict):
                val = val.get(k)
            else:
                val = None
            if val is None:
                break
    except Exception:                          # noqa: BLE001
        val = {}
    if not isinstance(val, dict):
        val = {}
    _CACHE[ck] = val
    return val


def _shop():
    """她 `store/shoplist.lua["Sheet1"]` —— 所有 goodsId/itemId/name/icon 的唯一来源。"""
    return _lua(r'store/shoplist.lua', 'Sheet1')


def _goods(gid):
    return _shop().get(str(gid)) or {}


def _pick(d, key):
    """她有些表用 `[1]=`（解析成 int 键），有些用 `["1"]=`（str 键）——两种都试。"""
    if not isinstance(d, dict):
        return None
    for k in (key, str(key), _num(key, -999999)):
        if k in d:
            return d[k]
    return None


def _num(v, d=0):
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return int(d)


# ---------------------------------------------------------------- 状态
def _st(ctx):
    st = ctx.load_json(STATE, None)
    if not isinstance(st, dict):
        st = {}
    m = st.setdefault('mask', {})
    m.setdefault('spcl', 1200)                 # 饰品材料（MaskConst.Condition.Spcl = 7）
    m.setdefault('paymaskmake', 300)           # 付费制作材料（= 11）
    m.setdefault('made', [])                   # 已制作的特殊面具 syntheticId
    m.setdefault('gained', [])                 # 随机制作拿到的 goodsId 流水
    m.setdefault('gift', {})                   # syntheticId -> {count, next}
    a = st.setdefault('account', {})
    a.setdefault('email', '0')                 # 未绑定必须是字符串 "0"（Account.lua:245）
    a.setdefault('phone', 0)                   # 必须给数字（Account.lua:250）
    a.setdefault('is_bind', 0)
    a.setdefault('is_logout', 0)
    a.setdefault('auth', 0)
    a.setdefault('code', '')
    a.setdefault('code_key', '')
    a.setdefault('code_expire', 0)
    a.setdefault('yashi', 0)
    v = st.setdefault('viewing', {})
    v.setdefault('guanyingquan', 30)
    v.setdefault('lastViewTime', 0)
    v.setdefault('getTimes', {})               # rid -> 已领次数
    v.setdefault('privilege_expired_time', 0)
    v.setdefault('privilege_got', 0)
    v.setdefault('buy_times', 0)
    v.setdefault('daily', {'day': '', 'n': 0})
    st.setdefault('official', {})
    st.setdefault('action_times', {})
    st.setdefault('jifen', {})
    st.setdefault('mingbi', 0)
    st.setdefault('martial_currency', {})
    st.setdefault('coupon', {})
    st.setdefault('youxia', 0)
    st.setdefault('log', [])
    return st


def _save(ctx, st):
    st['log'] = (st.get('log') or [])[-80:]
    ctx.save_json(STATE, st)
    return st


def _log(st, text):
    st.setdefault('log', []).append({'t': int(time.time()), 'msg': text})


def _role_save(ctx):
    """她客户端上传的存档 `work/roles/full.json`（`officialType` 等就在里面）。"""
    try:
        d = ctx.load_json(os.path.join('roles', 'full.json'), {})
        return d if isinstance(d, dict) else {}
    except Exception:                          # noqa: BLE001
        return {}


def _cv(ctx):
    return _num(_role_save(ctx).get('currencyVersion'), 1)


def _wallet(ctx, name):
    st = ctx.load_json(HOME_STATE, None)
    if not isinstance(st, dict):
        st = {}
    return _num((st.get('currency') or {}).get(name), 0)


def _wallet_add(ctx, name, delta):
    st = ctx.load_json(HOME_STATE, None)
    if not isinstance(st, dict):
        st = {}
    cur = st.setdefault('currency', {'yinpiao': 200000, 'yuanbao': 99999, 'money': 200000})
    cur[name] = _num(cur.get(name), 0) + int(delta)
    ctx.save_json(HOME_STATE, st)
    return int(cur[name])


def _today():
    return int(time.strftime('%Y%m%d'))


# ---------------------------------------------------------------- 面具货架
def _random_mask_list():
    """`randomList`：按她 `maskUpgrade.lua` 的 `maskType` 分大类。

    大类名「戏曲面具 / 百花焕颜」出自 `MaskInfoPresenter.lua:159-171`；
    `id` 用 `shoplist.lua` 的真键（`itemId == maskId` 反查），`odds` 按 `maskLevel` 推算。
    """
    if getattr(_random_mask_list, '_cache', None) is not None:
        return _random_mask_list._cache
    mu = _lua(r'others/maskUpgrade.lua', 'Sheet1')
    by_item = {}
    for k, g in _shop().items():
        by_item.setdefault(str(g.get('itemId') or ''), []).append(str(k))
    names = {1: '戏曲面具', 2: '百花焕颜'}
    groups = {}
    for _k, v in mu.items():
        if not isinstance(v, dict):
            continue
        keys = by_item.get(str(v.get('maskId') or ''))
        if not keys:
            continue
        lv = max(1, _num(v.get('maskLevel'), 1))
        mt = _num(v.get('maskType'), 1)
        groups.setdefault(mt, []).append({
            'id': keys[0],
            'odds': max(1, 100 // (2 ** (lv - 1))),
        })
    out = []
    for mt in sorted(groups):
        out.append({'name': names.get(mt, '面具'), 'list': groups[mt]})
    _random_mask_list._cache = out
    return out


def _mask_pool():
    pool = []
    for grp in _random_mask_list():
        for it in grp['list']:
            pool.append(it['id'])
    return pool


def _pay_mask_list(st):
    """`payMaskList`：按她 `specialSyntheticMask.lua` 的 `series` 分组。

    `id` 必须能被 `SyntheticMask:create` 的 `tonumber(id)` 吃下，且两张表都只认 1/2/3。
    """
    cfg = _lua(r'others/specialSyntheticMask.lua', '面具配置')
    made = set(_num(x, -1) for x in (st['mask'].get('made') or []))
    groups = {}
    for k, v in cfg.items():
        if not isinstance(v, dict):
            continue
        sid = _num(v.get('id'), _num(k, 1))
        series = _num(v.get('series'), 1)
        groups.setdefault(series, []).append({'id': sid, 'state': 1 if sid in made else 0})
    out = []
    for s in sorted(groups):
        out.append({'name': '墨千秋', 'list': sorted(groups[s], key=lambda d: d['id'])})
    return out


def _gift_cfg(gid):
    return _pick(_lua(r'activity/specialMaskgift.lua', 'Sheet1'), gid) or {}


def _makecondition(sid):
    cfg = _pick(_lua(r'others/specialSyntheticMask.lua', '面具配置'), sid) or {}
    cond = cfg.get('makecondition') or []
    return cond if isinstance(cond, list) else []


def _gift_stale_window():
    """她 `specialMaskgift.lua` 的 `begintime/finishtime` 是 YYYYMMDD。

    我们这份包比线上旧：三个档位的窗口（2025-02-01~2025-05-01 / 2025-07-01~2025-10-01 /
    2026-01-01~2026-04-01）现在**全都过期**了。返回 True 表示「忽略窗口」，
    否则赠礼面板永远显示「未到领取时间」，按钮点不动。
    """
    table = _lua(r'activity/specialMaskgift.lua', 'Sheet1')
    finishes = [_num(v.get('finishtime'), 0) for v in table.values() if isinstance(v, dict)]
    finishes = [f for f in finishes if f]
    if not finishes:
        return True
    return _today() > max(finishes)


def _gift_state(st, gid):
    """回 (state, nextReceiveTime)，state 用她 `MaskConst.MakeMaskGiftState`。"""
    cfg = _gift_cfg(gid)
    now = int(time.time())
    day = _today()
    begin = _num(cfg.get('begintime'), 0)
    finish = _num(cfg.get('finishtime'), 0)
    limit = _num(cfg.get('limit'), 0)
    got = st['mask']['gift'].get(str(gid)) or {}
    if not _gift_stale_window():
        if begin and day < begin:
            return 0, None
        if finish and day > finish:
            return 0, None
    if _num(gid, -1) not in set(_num(x, -1) for x in (st['mask'].get('made') or [])):
        return 1, None
    if limit and _num(got.get('count'), 0) >= limit:
        return 4, None
    nxt = _num(got.get('next'), 0)
    if now >= nxt:
        return 3, None
    return 2, nxt


def _gift_list(st):
    out = []
    for k, v in _lua(r'activity/specialMaskgift.lua', 'Sheet1').items():
        if not isinstance(v, dict):
            continue
        gid = _num(v.get('id'), _num(k, 1))
        state, nxt = _gift_state(st, gid)
        it = {'id': gid, 'state': state}
        if nxt:
            it['nextReceiveTime'] = nxt
        out.append(it)
    out.sort(key=lambda d: d['id'])
    return out


# ---------------------------------------------------------------- 观影堂
def _view_rewards(st):
    """观影堂奖励位。奖励组是她服务端的配置（客户端里没这张表），
    所以固定挑几个 `shoplist.lua` 里的真货当奖励位 —— 名称/图标/itemId 全来自她的表。"""
    picks = ['400001', '400002', '400005', '400056', '400045']
    now = int(time.time())
    end = now + 30 * 86400
    got = st['viewing'].get('getTimes') or {}
    out = []
    for i, gid in enumerate(picks):
        g = _goods(gid)
        rid = i + 1
        out.append({
            'id': rid,
            'itemId': str(g.get('itemId') or gid),
            'name': str(g.get('name') or '奖励'),
            'number': 1,
            'icon': str(g.get('icon') or ''),
            'itemType': 1,                      # 1=物品（CommercialTime.lua:119）
            'awardType': 1,
            'getTimes': _num(got.get(str(rid)), 0),
            'maxTimes': 3,
            'endTime': end,
        })
    return out


def _privilege_expired(st):
    return _num(st['viewing'].get('privilege_expired_time'), 0)


def _privilege_active(st):
    return _privilege_expired(st) - int(time.time()) > 1


def _daily(st):
    d = st['viewing'].get('daily') or {}
    if d.get('day') != _today():
        d = {'day': _today(), 'n': 0}
        st['viewing']['daily'] = d
    return d


def _privilege_cfg():
    return _lua(r'activity/viewingHallactivity.lua', 'Sheet1').get('viewingHallactivity') or {}


# ---------------------------------------------------------------- 官职
def _official_row(guanzhi, zhengji):
    """在 `officialChenHao.lua` 里按 `type==官职` + 政绩门槛命中的那一档。

    照抄 `Role_Title.lua:209-236` 的命中条件：政绩与门槛**同号**且政绩不低于门槛；
    多档命中时取 `number`（她表里的称号档位）最大的那一档。
    """
    table = _lua(r'roleTitle/officialChenHao.lua', 'Sheet1')
    best = None
    for _k, v in table.items():
        if not isinstance(v, dict):
            continue
        if _num(v.get('type'), -1) != _num(guanzhi, -1):
            continue
        val = _num(v.get('integral'), 0)
        if val >= 0 and zhengji >= val and zhengji >= 0:
            pass
        elif val < 0 and zhengji <= val and zhengji < 0:
            pass
        else:
            continue
        if best is None or _num(v.get('number'), 0) > _num(best.get('number'), 0):
            best = v
    return best or {}


def _official(ctx, st):
    o = st['official']
    if o.get('guanzhi') is None:
        rs = _role_save(ctx)
        o['guanzhi'] = _num(rs.get('officialType'), 0)
    if o.get('zhengji') is None:
        rs = _role_save(ctx)
        o['zhengji'] = _num(rs.get('officialAchievement'), 0)
    return o


# ---------------------------------------------------------------- 主入口
def handle(ctx):
    ep = ctx.endpoint
    st = _st(ctx)
    now = int(time.time())

    # ============================================================ 面具 / 炼形
    if ep == 'get_makeMask_info':
        return ctx.ok({
            'spNum': _num(st['mask'].get('spcl')),
            'payNum': _num(st['mask'].get('paymaskmake')),
            'randomList': _random_mask_list(),
            'payMaskList': _pay_mask_list(st),
        }, '★ 面具制作信息')

    if ep == 'make_randomMask':
        cost = ctx.int_param('cost', 100)
        pool = _mask_pool()
        gid = random.choice(pool) if pool else '100001'
        st['mask']['spcl'] = max(0, _num(st['mask'].get('spcl')) - cost)
        st['mask'].setdefault('gained', []).append(gid)
        _log(st, '随机制作面具 → %s（消耗饰品材料 %d）' % (_goods(gid).get('name'), cost))
        _save(ctx, st)
        return ctx.ok({'spNum': _num(st['mask'].get('spcl')), 'goodsId': str(gid)},
                      '★ 随机制作面具：%s' % _goods(gid).get('name'))

    if ep == 'make_payMask':
        sid = ctx.int_param('id', 1)
        sp_cost = ctx.int_param('spCost', 0)
        cfg = _pick(_lua(r'others/specialSyntheticMask.lua', '面具配置'), sid) or {}
        goods_id = str(cfg.get('goodsId') or '')
        if not goods_id or not _goods(goods_id):
            return ctx.fail('特殊面具数据异常', '★ 特殊制作：syntheticId=%s 不在她的表里' % sid)
        pay = 0
        for cond in _makecondition(sid):
            if isinstance(cond, list) and len(cond) >= 2 and _num(cond[0]) == 11:
                pay += _num(cond[1])
        st['mask']['spcl'] = max(0, _num(st['mask'].get('spcl')) - sp_cost)
        st['mask']['paymaskmake'] = max(0, _num(st['mask'].get('paymaskmake')) - pay)
        made = st['mask'].setdefault('made', [])
        if sid not in made:
            made.append(sid)
        _log(st, '特殊制作面具 id=%s → %s（饰品 %d / 付费材料 %d）'
                 % (sid, _goods(goods_id).get('name'), sp_cost, pay))
        _save(ctx, st)
        return ctx.ok({
            'spNum': _num(st['mask'].get('spcl')),
            'payNum': _num(st['mask'].get('paymaskmake')),
            'goodsId': goods_id,
        }, '★ 特殊制作面具：%s' % _goods(goods_id).get('name'))

    if ep == 'get_payMask_gift_info':
        lines = ['活动期间，制作下列特殊面具后可在发放时间内领取相应赠礼：']
        rows = sorted(_lua(r'activity/specialMaskgift.lua', 'Sheet1').items(),
                      key=lambda kv: _num(kv[1].get('id'), 0) if isinstance(kv[1], dict) else 0)
        for _k, v in rows:
            if not isinstance(v, dict):
                continue
            goods = _goods(v.get('goodsId'))
            rw = []
            for r in (v.get('rewards') or []):
                if isinstance(r, list) and len(r) >= 2:
                    rw.append('%s*%s' % (_goods(r[0]).get('name'), _num(r[1])))
            lines.append('%s：%s，每%s天可领取一次，共%s次'
                         % (goods.get('name'), '，'.join(rw),
                            _num(v.get('rewardsdays')), _num(v.get('limit'))))
        return ctx.ok({
            'activityName': '墨千秋的赠礼',      # 见 ActionLayer.lua:1005 的活动名
            'activityDesc': lines,
            'giftList': _gift_list(st),
        }, '★ 墨千秋赠礼信息')

    if ep == 'receive_payMask_gift':
        gid = ctx.int_param('id', 1)
        cfg = _gift_cfg(gid)
        if not cfg:
            return ctx.fail('没有找到墨千秋合成奖励配置 id = %s' % gid, '★ 领赠礼：id 不在她表里')
        state, _nxt = _gift_state(st, gid)
        if state != 3:
            return ctx.fail('现在还不能领取', '★ 领赠礼：state=%d 不可领' % state)
        rewards = []
        for r in (cfg.get('rewards') or []):
            if isinstance(r, list) and len(r) >= 2:
                rewards.append({'id': str(r[0]), 'num': _num(r[1])})
        rec = st['mask']['gift'].setdefault(str(gid), {'count': 0, 'next': 0})
        rec['count'] = _num(rec.get('count'), 0) + 1
        rec['next'] = now + _num(cfg.get('rewardsdays'), 7) * 86400
        _log(st, '领取墨千秋赠礼 id=%s → %s' % (gid, rewards))
        _save(ctx, st)
        return ctx.ok({
            'rewards': rewards,
            'giftList': _gift_list(st),
            'msg': '领取成功',
            'currencyVersion': _cv(ctx),
        }, '★ 领取墨千秋赠礼（%d 件）' % len(rewards))

    if ep == 'mask_upgrade':
        obj = ctx.body_obj or {}
        conds = obj.get('params')
        if not isinstance(conds, list):
            conds = ctx.param('params') or []
        spend = {1: 0, 5: 0, 7: 0, 11: 0}
        if isinstance(conds, list):
            for c in conds:
                if isinstance(c, list) and len(c) >= 2:
                    t = _num(c[0])
                    if t in spend:
                        spend[t] += _num(c[1])
        if spend[7]:
            st['mask']['spcl'] = max(0, _num(st['mask'].get('spcl')) - spend[7])
        if spend[11]:
            st['mask']['paymaskmake'] = max(0, _num(st['mask'].get('paymaskmake')) - spend[11])
        if spend[5]:
            _wallet_add(ctx, 'money', -spend[5])
        _log(st, '面具升级：饰品 %d / 付费材料 %d / 碎银 %d' % (spend[7], spend[11], spend[5]))
        _save(ctx, st)
        return ctx.ok({'currencyVersion': _cv(ctx)}, '★ 面具升级')

    # ============================================================ 账号绑定
    if ep == 'get_bind_info':
        a = st['account']
        return ctx.ok({
            'email': str(a.get('email') or '0'),
            'phone': _num(a.get('phone'), 0),
            'is_bind': _num(a.get('is_bind'), 0),
            'is_logout': _num(a.get('is_logout'), 0),
            'auth': _num(a.get('auth'), 0),
        }, '★ 设备绑定信息')

    if ep == 'get_email':
        a = st['account']
        return ctx.ok({
            'email': str(a.get('email') or '0'),
            'is_bind': _num(a.get('is_bind'), 0),
            'is_logout': _num(a.get('is_logout'), 0),
        }, '★ 绑定邮箱')

    if ep in ('send_email', 'send_verify_code'):
        key = str(ctx.param('email') or ctx.param('phone') or ctx.param('send_key') or '')
        ev = _num(ctx.param('event_type'), 1)
        code = '%06d' % random.randint(0, 999999)
        st['account']['code'] = code
        st['account']['code_key'] = key
        st['account']['code_expire'] = now + 30 * 60
        _log(st, '%s：key=%s event=%d code=%s（离线模拟，不真发信）' % (ep, key, ev, code))
        _save(ctx, st)
        return ctx.ok({'expired_time': st['account']['code_expire']},
                      '★ 发送验证码到 %s（30 分钟内有效）' % key)

    if ep in ('bind_device', 'bind_device_2'):
        a = st['account']
        key = str(ctx.param('email') or ctx.param('phone') or '')
        code = str(ctx.param('verify_code') or '')
        if not key:
            return ctx.fail('请填写邮箱地址和验证码', '★ 绑定：缺少账号')
        if not code:
            return ctx.fail('验证码不能为空', '★ 绑定：缺少验证码')
        if code != str(a.get('code') or '') or now > _num(a.get('code_expire'), 0):
            return ctx.fail('验证码错误或已过期', '★ 绑定：验证码不匹配')
        if ep == 'bind_device':
            a['email'] = key
            a['is_bind'] = 1
        else:
            a['phone'] = _num(key, 0)
            a['auth'] = 1
        a['code'] = ''
        _log(st, '绑定成功：%s' % key)
        _save(ctx, st)
        return ctx.ok({}, '★ 绑定成功：%s' % key)

    if ep == 'login_device':
        st['account']['is_logout'] = 0
        _save(ctx, st)
        return ctx.ok({}, '★ 设备登录')

    if ep == 'logout_device':
        st['account']['is_logout'] = 1
        _save(ctx, st)
        return ctx.ok({}, '★ 设备登出')

    if ep == 'check_has_yashi':
        return ctx.ok({'yashi': _num(st['account'].get('yashi'), 0)}, '★ 雅士到期时间')

    # ============================================================ 观影堂
    if ep == 'get_viewing_hall':
        v = st['viewing']
        d = _daily(st)
        _save(ctx, st)
        return ctx.ok({
            'ruleDesc': [
                '每日可免费观看 %d 次，观看广告后可领取一份奖励' % DAILY_VIEW_LIMIT,
                '广告冷却 %d 秒，使用观影券或观影堂特权可跳过广告' % COOL_DOWN,
                '购买观影堂特权后，每日额外 8 次持续 42 天',
                '同一档奖励每日最多领 3 次，每日 0 点重置',
            ],
            'lastViewTime': _num(v.get('lastViewTime'), 0),
            'coolDown': COOL_DOWN,
            'isReachLimit': 1 if _num(d.get('n'), 0) >= DAILY_VIEW_LIMIT else 0,
            'guanyingquan': _num(v.get('guanyingquan'), 0),
            'isPromotionActive': 1,
            'privilege_expired_time': _privilege_expired(st),
            'privilege_remaining_watches': PRIVILEGE_WATCHES if _privilege_active(st) else 0,
            'rewards': _view_rewards(st),
        }, '★ 观影堂（观影券 %d）' % _num(v.get('guanyingquan'), 0))

    if ep == 'get_viewing_reward':
        rid = ctx.int_param('id', 0) or 1          # 客户端永远会给 id；裸探针按第 1 档算
        is_free = ctx.int_param('is_free', 1)      # 0=观影券 1=免费广告 2=特权
        is_email = ctx.int_param('is_email', 0)
        v = st['viewing']
        d = _daily(st)
        rewards = _view_rewards(st)
        hit = next((r for r in rewards if _num(r.get('id')) == rid), None)
        if hit is None:
            return ctx.fail('奖励配置错误', '★ 观影领奖：rid=%s 不存在' % rid)
        if _num(d.get('n'), 0) >= DAILY_VIEW_LIMIT:
            return ctx.fail('达到总观影上限了', '★ 观影领奖：今日已达上限')
        if _num(hit.get('getTimes'), 0) >= _num(hit.get('maxTimes'), 0):
            return ctx.fail('此奖励本日已兑换完毕，明天再来', '★ 观影领奖：该档已领完')
        if is_free == 0:
            if _num(v.get('guanyingquan'), 0) < 1:
                return ctx.fail('观影券不足', '★ 观影领奖：没有观影券', errcode=1)
            v['guanyingquan'] = _num(v.get('guanyingquan'), 0) - 1
        elif is_free == 2:
            if not _privilege_active(st):
                return ctx.fail('没有观影堂特权', '★ 观影领奖：特权已过期', errcode=2)
        v.setdefault('getTimes', {})
        v['getTimes'][str(rid)] = _num(v['getTimes'].get(str(rid)), 0) + 1
        v['lastViewTime'] = now
        d['n'] = _num(d.get('n'), 0) + 1
        _log(st, '观影领奖 rid=%d is_free=%d is_email=%d → %s'
                 % (rid, is_free, is_email, hit.get('itemId')))
        _save(ctx, st)
        return ctx.ok({
            'reward': {
                'itemType': 1,
                'id': hit['itemId'],              # 她拿这个 id 去 addItemCount
                'name': hit['name'],
                'number': _num(hit.get('number'), 1),
            },
            'msg': '获得%sX%s' % (hit['name'], _num(hit.get('number'), 1)),
        }, '★ 观影领奖：%s' % hit['name'])

    if ep == 'get_viewing_privilege_info':
        cfg = _privilege_cfg()
        v = st['viewing']
        buy = _num(v.get('buy_times'), 0)
        threshold = _num(cfg.get('threshold'), 10)
        if _num(v.get('privilege_got'), 0):
            status = 2
        elif buy >= threshold:
            status = 1
        else:
            status = 0
        days = _num(cfg.get('days'), 42)
        return ctx.ok({
            'act_name': '观影堂特权加送',          # 见 ActionLayer.lua:1020 的活动名
            'rule_desc': [
                '活动期间，本角色每购买 1 次「观影堂特权」即可记 1 次购买次数',
                '购买次数达到 %d 次后，可在此领取 %d 天观影堂特权加送' % (threshold, days),
                '特权期间每日额外 8 次广告直接领取奖励',
                '每档加送活动期间仅可领取一次',
            ],
            'detail_time': '长期有效',
            'detail_desc': [
                '1.每日%d次跳过广告直接领取奖励次数' % PRIVILEGE_WATCHES,
                '2.每购买一次，持续时间加4天',
                '3.本角色活动期间内购买次数达到%d次即可领取加送' % threshold,
                '4.加送的天数直接累加到当前特权到期时间上',
            ],
            'privilege_expired_time': _privilege_expired(st),
            'buy_times': buy,
            'status': status,
        }, '★ 观影堂特权加送（status=%d）' % status)

    if ep == 'get_viewing_privilege_reward':
        cfg = _privilege_cfg()
        v = st['viewing']
        buy = _num(v.get('buy_times'), 0)
        threshold = _num(cfg.get('threshold'), 10)
        if _num(v.get('privilege_got'), 0):
            return ctx.fail('已领取加送天数', '★ 特权加送：已领过')
        if buy < threshold:
            return ctx.fail('未达到领取条件', '★ 特权加送：购买次数 %d < %d' % (buy, threshold))
        days = _num(cfg.get('days'), 42)
        base = max(_privilege_expired(st), now)
        v['privilege_expired_time'] = base + days * 86400
        v['privilege_got'] = 1
        _save(ctx, st)
        return ctx.ok({
            'privilege_expired_time': _privilege_expired(st),
            'status': 2,
        }, '★ 领取观影堂特权加送 %d 天' % days)

    # ============================================================ 官职 / 政绩
    if ep == 'get_user_guanzhi':
        o = _official(ctx, st)
        _save(ctx, st)
        return ctx.ok({'guanzhi': _num(o.get('guanzhi')), 'zhengji': _num(o.get('zhengji'))},
                      '★ 当前官职 %d / 政绩 %d' % (_num(o.get('guanzhi')), _num(o.get('zhengji'))))

    if ep == 'upload_zhengji':
        o = _official(ctx, st)
        add = _num(ctx.param('zhengji'), 0)
        gz = _num(ctx.param('guanzhi'), _num(o.get('guanzhi')))
        o['guanzhi'] = gz
        o['zhengji'] = _num(o.get('zhengji'), 0) + add
        _log(st, '政绩 %+d → 累计 %d（官职 %d）' % (add, o['zhengji'], gz))
        _save(ctx, st)
        return ctx.ok({'zhengji': o['zhengji']}, '★ 上传政绩 %+d（累计 %d）' % (add, o['zhengji']))

    if ep == 'delete_my_guanzhi':
        o = _official(ctx, st)
        o['guanzhi'] = 0
        o['zhengji'] = 0
        o['fenlu_day'] = ''
        _log(st, '辞官')
        _save(ctx, st)
        return ctx.ok({}, '★ 辞官成功')

    if ep == 'get_guanzhi_fenlu':
        o = _official(ctx, st)
        gz = _num(o.get('guanzhi'))
        zj = _num(o.get('zhengji'))
        if gz == 0:
            # 照 `CommonResults.lua:1827-1830`：errcode 0 且 guanzhi==0 → 她客户端自己弹「已无官职」
            _save(ctx, st)
            return ctx.ok({'guanzhi': 0, 'zhengji': zj,
                           'is_normal': 'N' if zj < 0 else 'Y',
                           'meiyu': 0, 'yinpiao': 0},
                          '★ 领俸禄：当前没有官职（她客户端会自己弹「已无官职」）')
        if str(o.get('fenlu_day') or '') == str(_today()):
            return ctx.fail('你已经领过俸禄了，明日再来！', '★ 领俸禄：今日已领')
        row = _official_row(gz, zj)
        o['fenlu_day'] = str(_today())
        _log(st, '领俸禄：官职 %d 政绩 %d 称号档 %s' % (gz, zj, row.get('text')))
        _save(ctx, st)
        return ctx.ok({
            'guanzhi': gz,
            'zhengji': zj,
            'is_normal': 'N' if zj < 0 else 'Y',
            'meiyu': _num(row.get('number'), 0),   # officialChenHao 命中档位的 number
            'yinpiao': 0,                          # 她表里没有银票档位配置 → 0
        }, '★ 领取俸禄：%s' % (row.get('text') or '无称号'))

    # ============================================================ 周年 / 货币 / 兑换
    if ep == 'add_zhounian_jifen':
        add_type = str(ctx.param('addType') or ctx.param('type') or '')
        num = _num(ctx.param('number'), 0)
        jf = st.setdefault('jifen', {})
        jf[add_type] = _num(jf.get(add_type), 0) + num
        _log(st, '周年/七夕礼券 %s %+d → %d' % (add_type, num, jf[add_type]))
        _save(ctx, st)
        return ctx.ok({'number': num,
                       'total': jf[add_type]},
                      '★ 礼券 %s +%d（累计 %d）' % (add_type, num, jf[add_type]))

    if ep == 'martial_upgrade_add_currency':
        kind = _num(ctx.param('type'), 1)
        items = _lua(r'skill/breakThroughItems.lua', 'Items')
        want = 'skillUpItem01' if kind == 1 else 'skillUpItem05'
        if want not in items:
            want = next(iter(items), 'skillUpItem01')
        name = str((items.get(want) or {}).get('name') or want)
        st.setdefault('martial_currency', {})
        st['martial_currency'][want] = _num(st['martial_currency'].get(want), 0) + 1
        _save(ctx, st)
        return ctx.ok({
            'reward': [{'id': want, 'name': name, 'num': 1}],
            'currencyVersion': _cv(ctx),
            'msg': '武学上限突破，获得%s' % name,
        }, '★ 武学突破奖励：%s' % name)

    if ep in ('get_youxia_upgradeCondition', 'youxia_upgrade_condition'):
        table = _lua(r'others/mcmrestrictLevel.lua', '1')
        keys = sorted(_num(k, 0) for k in table.keys())
        cur = _num(st.get('youxia'), 0)
        nxt = next((k for k in keys if k > cur), keys[-1] if keys else 100)
        if ep == 'youxia_upgrade_condition':
            st['youxia'] = nxt
            _log(st, '散人提升门外武学 → mcmrestrictId=%s' % nxt)
            _save(ctx, st)
        return ctx.ok({'id': nxt, 'currencyVersion': _cv(ctx)},
                      '★ 散人提升门外武学（id=%s）' % nxt)

    if ep == 'delete_youxia_upgradeCondition':
        st['youxia'] = 0
        _save(ctx, st)
        return ctx.ok({}, '★ 清除散人武学限制')

    if ep == 'get_config_times':
        action = str(ctx.param('com_config') or ctx.param('action') or '')
        used = _num((st.get('action_times') or {}).get(action), 0)
        cost = 0 if used <= 0 else ACTION_COST.get(action, DEFAULT_COST)
        return ctx.ok({
            'num': used,
            'remove': cost,
            'yuanbao': _wallet(ctx, 'yuanbao'),
        }, '★ %s 次数（已用 %d，本次 %d 元宝）' % (action, used, cost))

    # ============================================================ 南柯一梦
    if ep == 'settle_overdue_fond_dream':
        # 她：errcode 0=有要结算的；2/-2=没有 → 客户端去拉梦境数据
        return ctx.fail('没有需要结算的过期梦境', '★ 南柯一梦：无过期梦境（预期 errcode=2）',
                        errcode=2)

    if ep == 'get_fond_dream_role':
        return ctx.fail('没有进行中的梦境数据', '★ 南柯一梦：无进行中梦境（她开新棋局）',
                        errcode=2)

    # ============================================================ 花会 / 优惠券 / 冥币 / 商店
    if ep == 'get_random_userdata':
        npcs = _lua(r'npc/npc.lua', 'npcs')
        pool = [v for v in npcs.values()
                if isinstance(v, dict) and v.get('name') and v.get('sex')]
        who = random.choice(pool) if pool else {'id': 'ghost01', 'name': '无名', 'sex': '男'}
        _save(ctx, st)
        return ctx.ok({
            'id': str(who.get('id') or 'ghost01'),
            'name': str(who.get('name') or '无名'),
            'sex': str(who.get('sex') or '男'),
        }, '★ 随机玩家：%s' % who.get('name'))

    if ep == 'get_discount_coupon':
        obj = ctx.body_obj or {}
        got = {k: _num(v) for k, v in obj.items() if isinstance(k, str) and not k.startswith('_')}
        cp = st.setdefault('coupon', {})
        for k, v in got.items():
            cp[k] = _num(cp.get(k), 0) + v
        _log(st, '双十一优惠券发放 %s' % got)
        _save(ctx, st)
        return ctx.ok({'success': 0}, '★ 优惠券发放（%s）' % (got or '空'))

    if ep == 'add_user_mingbi':
        num = _num(ctx.param('number'), 0)
        st['mingbi'] = _num(st.get('mingbi'), 0) + max(0, num)
        _log(st, '冥币 +%d（type=%s isNeed=%s）'
                 % (num, ctx.param('type'), ctx.param('isNeed')))
        _save(ctx, st)
        return ctx.ok({'number': num, 'total': st['mingbi']}, '★ 冥币 +%d' % num)

    if ep == 'shop_exchange_goods':
        item = str(ctx.param('itemId') or '')
        shop_id = str(ctx.param('shop_id') or '')
        g = _goods(item)
        if not g:
            # 她有的店配的是 itemId 而不是 shoplist 的键 —— 反查一下
            for _k, v in _shop().items():
                if str(v.get('itemId') or '') == item:
                    g = v
                    break
        if not g:
            return ctx.fail('商品不存在', '★ 商店兑换：%s 不在她的表里' % item)
        itype = _num(g.get('itype'), 1)
        _log(st, '商店兑换 shop=%s itemId=%s → %s' % (shop_id, item, g.get('name')))
        _save(ctx, st)
        return ctx.ok({
            'romove_point': 0,                 # 价格在她 mapConditionAndResult 里，客户端不上传
            'reward': {
                'itemId': str(g.get('itemId') or item),
                'name': str(g.get('name') or ''),
                'number': 1,
                'itype': 1 if itype in (1, 2) else 3,
            },
        }, '★ 商店兑换：%s' % g.get('name'))

    return None
