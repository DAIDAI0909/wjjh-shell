# -*- coding: utf-8 -*-
# ================= 离线包路径根（fz_make_offline_bundle.py 自动注入） =================
# 手机上整个服务端就是一个目录，表在哪、状态写哪，全部相对包根算。
# （有的模块原来把绝对路径写死，本身没 import os —— 这里一并补上）
import os
import os as _osp


def _off_find_bundle(_f):
    """从模块所在目录往上找包根（认 fz_boot_server.py）。
    ★ fz_api/*.py 的 __file__ 在 <根>/fz_api/ 下，直接 dirname 会算错一层。"""
    _d = _osp.path.dirname(_osp.path.abspath(_f))
    for _ in range(6):
        if _osp.path.exists(_osp.path.join(_d, 'fz_boot_server.py')):
            return _d
        _u = _osp.path.dirname(_d)
        if _u == _d:
            break
        _d = _u
    return _osp.path.dirname(_osp.path.abspath(_f))


_OFF_BUNDLE = _off_find_bundle(__file__)
_OFF_FZ_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_fz')
_OFF_INK_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_ink')
_OFF_WORK_ROOT = _OFF_BUNDLE
# =====================================================================================
# ★ 2026-10-04 商城空货架修复：客户端资源表解析——PC 开发树优先，设备上自动回退
#   到包内 client_fz 副本（jhserver/client_fz = fangzhi_lua_dec 的同步拷贝）。
def _fz_res(*parts):
    base = os.path.join(_OFF_FZ_ROOT, 'res', 'script')
    if not os.path.isdir(base):
        base = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            '..', 'client_fz', 'res', 'script')
    return os.path.join(base, *parts)

# -*- coding: utf-8 -*-
"""账号 / 存档（多存档位） / 分区 / 客户端本地数据清理 —— 27 个接口的 1:1 还原。

===========================================================================
一、契约出处（全部来自**已解密的客户端源码** `C:\\apkwork\\ink_dec\\src\\app\\`）
===========================================================================
★ URL 定义一律查 `extends\\Http\\HttpManager.lua`（`Loader.lua:272` 载入的那份；
  `extends\\HttpManager.lua` 是同名旧副本，参数有出入，**不用它**）。
  方法名驼峰 → URL 下划线，一对一：

| 接口 | HttpManager 函数 | 行 | 上行 | 回调里读的字段（= 应答契约） |
|---|---|---|---|---|
| `create_role` | `createRole` | :66 | POST 空 | `data.userid`（`CreateRoleLayer.lua:135-190`） |
| `get_archive_list` | `getArchiveList` | :452 | GET | errcode=0 ⇒ `data` 是**数组**；errcode=1 ⇒ `data` 是**单个对象**+`data.yuanbao`（`ArchiveLayer.lua:35-100`） |
| `switch_archive/<index>` | `switchArchive` | :458 | GET | 只看 `errcode`（`ArchiveLayer.lua:108-136`） |
| `get_login_reward_info` | `getLoginRewardInfo` | :2190 | GET | `data.name` / `data.dsc` / `data.item`（对象）（`MainLayer.lua:835-849`） |
| `login` | `checkLogin` | :377 | POST `{exp,pot,money}` | `errcode`：0 成功 / 1 黑名单 / 550 userid 非法 / 551 uuid 非法 / 552 无此 userid；成功时 `data.account`、`data.role`（`StartGameLayer.lua:233-345`） |
| `get_partition_list` | `getServerList` | :1667 | GET | `data.list[]`（`{id,partition_title,partition_desc,channel,partition_name,should_select_migrate}`）+ `data.user.email/active_partition`（`SwitchServerController.lua:57-87,248-276`） |
| `switch_partition/<id>` | `switchServer` | :1685 | GET | `errcode`、`data.msg`、`data.uuid`（`SwitchServerController.lua:118-216`，v1 无 Lua 调用点） |
| `switch_partition2/<id>` | `switchServer2` | :1704 | GET | 同上（**真调用点**就是它） |
| `partition_clear` | `partitionClear` | :1722 | GET | 注释「清除分区记录」，只看 `errcode` |
| `migrate_to_new_package` | `migrateToNewPackage` | :1676 | POST `{email,verify_code}` | 只看 `errcode`/`errmsg`（`SwitchServerController.lua:93-112`） |
| `migrate_to_new_package2` | `migrateToNewPackage2` | :1713 | POST `{email,verify_code,serverId}` | 同上（**真调用点**是它） |
| `login_device_2` | `loginDevice2` | :890 | POST `{send_type,[send_type]=key,verify_code}` | 只看 `errcode` |
| `logout_device_2` | `logoutDevice2` | :906 | POST 同上 | 只看 `errcode`；`logoutUnbindDevice2`(:922) 用**请求头 `isBind=0`** 调同一 URL |
| `get_logoutAccount_url` | `getLogoutAccountUrl` | :5475 | GET（NEED_ENCRYPT） | `data.url`（`Account.lua:537-564` → `SetupUIInMenuLayer.lua:814-820` 拿它开网页） |
| `clear_api_data` | `clearApiData` | :1575 | POST `{act}` | 注释「清除江湖好友的投票次数」 |
| `clear_my_shop_record` | `clearShopRecord` :1631 / `clearPointRecord` :1643 | POST `{shop_id}` | 注释「清除兑换次数，测试使用」/「重置活动积分」 |
| `del_activity_cache` | `delActivityCache` | :1220 | GET | 紧跟在「获取是否有未查看的活动」后面 ⇒ 清活动缓存 |
| `clean_voucher_record_2` | `cleanVoucherRecord` | :1392 | GET | 注释「测试接口不提交正式服」 |
| `del_all_data` | `delAllData` | :2050 | POST `{type}` | 注释「删除数据库对应标识的数据」 |
| `del_data_by_type` | `deleteClientData` | :2152 | POST `{type}` | 注释「清除统计数据」 |
| `addSingleRecord` | `addSingleRecord` | :2008 | POST **正文就是记录本身** | 注释「调查问卷·添加单条记录」 |
| `delete_day_intelligence` | `deleteDayIntelligence` | :3650 | GET | 注释「删除今日已购买情报」 |
| `delete_bought_intelligence` | `deleteIntelligence` | :3656 | POST `{type}` | 注释「删除购买过的情报」 |
| `delete_login_yuanbao_cache` | `deleteLoginYuanbaoCache` | :2201 | GET | 注释「清除今天领取次数」 |
| `modify_qixi_ctime/<daynum>` | `testModifyQiXiCtime` | :2727 | GET | 注释「测试接口」，改七夕 ctime |
| `up_day_gametime` | `upDayGameTime` | :875 | POST `{time}` | 注释「上传当日游戏累计时间」 |
| `set_product_mark` | `setProductMark` | :3601 | POST `{activity_id,key}` | 无注释；语义=给活动打一个服务端标记 |

===========================================================================
二、存档放在哪（★ 与 `fz_boot_server.py` **同一份存档**，不另造一套）
===========================================================================
她客户端把存档固定传/取在两个路径上（`fz_boot_server.py` 的 `save_upload` /
`save_download`，两者同源；`HttpManager.lua:175-223` 的上行/下行 URL 是
`upload_user_file_3`(`_5`) / `download_user_file_2`）：

  * `work/saves/<md5("%s|%s" % (uuid, 请求头userid))[:16]>.json` ← 客户端上传的明文存档
    （正文是 `{userAttr, recordInfo}` 的**数组**，`[1]` 才是角色：`HttpManager.lua:189`）
  * `work/roles/full.json` ← `--role ours` 时 `download_user_file_2` 下发的我们自己的角色档

本模块**不新建存档目录**，而是把上面这个 `saves/` 当"当前正在玩的那份"，
再给账号加一层**存档位快照**（多存档 = 每个存档位一份 `saves/` 里的文件）：

  * `_flush`：把本机存档**复制**成当前存档位的快照文件（`saves/<md5(uuid|位userid)>.json`）
  * `_materialize`：切位时把目标位的快照**复制**回本机存档路径；目标位是空的就删掉本机存档
    ⇒ `download_user_file_2` 回 `errcode=1` ⇒ 她 `isReset="Y"` 去走建号流程
    （`StartGameLayer.lua:207-212`）。这正是原版"切到一个空存档位 = 在那个位建新号"的语义。
  * `create_role`：分配一个新的 userid（`100000 + md5(uuid)[:8]%%900000 + 位序号-1`，
    与 `create_account` 派生规则同源），把该位与本机存档清空，等她 `upload_user_file_3` 落盘。

★ 为什么是"复制"而不是"移动"：本机存档路径同时也是 `download_user_file_2` 的读取路径，
  移走它下一次登录就"没有存档"了。所以本机存档**永远留在原位**，位文件只是快照。

===========================================================================
三、状态：`work/account_archive_state.json`（`ctx.load_json/save_json`）
===========================================================================
```
accounts:      uuid -> {userid, slots:[{index,userid,file,createTime,saveTime}], active,
                        slots_bought, email, phone, partition, login_count, last_login,
                        bound, is_logout, created:[], migrated:{}}
records:       act -> [记录]           # addSingleRecord 写、del_all_data / del_data_by_type / clear_api_data 清
counters:      act -> 次数
product_marks: activity_id -> {key,t,uuid}
gametime:      uuid -> {"YYYYMMDD": {total,last,count}}   # up_day_gametime
partitions:    分区表（见 `_default_partitions`）
blacklist:     [userid]                # login 命中就回 errcode=1（她弹封号框）
```
★ 有几个接口**原版就是"清别的系统的账本"**（它们没有 Lua 调用点，是运维/测试接口）。
  这类我不糊 errcode=0，而是去清**真正持有那份记录的文件**（只改那一个 key，写完再落盘）：
  * `clean_voucher_record_2` → `action_festival_state.json` 的 `voucher.got`（兑换券已用记录，
    就是 `action_festival.py:_h_get_voucher_prize_2` 用来判"该兑换券已使用"的那本账）
  * `del_activity_cache` → `action_festival_state.json` 的 `diy.list` / `lucky.goods`
    （这两个是**纯缓存**：`action_festival.py:757,1295` 里 `x or 重新生成`，置 None 不会丢进度）
  * `delete_day_intelligence` / `delete_bought_intelligence` → `intelligence.json`
    （`fz_boot_server.py:_intel_load/_intel_save` 的当天的账本：`bought`/`uploaded`/两个 list）
  * `delete_login_yuanbao_cache` → `misc_daily_state.json` 的 `login.{got,last,days[today]}`
    （`misc_daily.py:_ep_get_login_yuanbao` 的防重复闸门）
  * `modify_qixi_ctime` → `action_festival_state.json` 的 `qixi.ctime`
  * 验证码校验（`login_device_2` / `migrate_to_new_package*`）读 `misc_state.json` 的
    `account.{code,code_key,code_expire}` —— 这是 `misc_systems.py` 的 `send_email` /
    `send_verify_code` 离线模拟发的码，我们校验同一本账（校验通过后把那一个 key 清掉）。

===========================================================================
四、已知的取舍 / 还没做的地方（诚实报，不含假数据）
===========================================================================
1. `year` / `time`：`ArchiveLayer.lua:160-161` 只是 `setString(params.year/time)`，
   客户端里**没有**任何计算它们的地方，她的 res 表里也没有这张配置。这两个字段是
   **纯展示字符串**，我用存档文件里的 `createTime` 和文件 mtime 按
   `%Y` / `%Y-%m-%d %H:%M` 生成（不是编数值，是从真实时间戳推的展示串）。
2. `get_archive_list` 的 `data.yuanbao`（第 2 个存档位的价格）取 **300**：
   `ArchiveLayer.lua:34` 自己写的默认值 `local yuanbao = 300`。她的 shoplist/商店表里
   **没有** `cundangwei` 这个商品（我递归 grep 过 `res/script/**`，0 命中），
   所以"买存档位"这条链（`PopYuanBaoBuyItemLayer("cundangwei")` → `get_goods_2` +
   `buy_goods_3`，属 `shop_store` 的清单）在我们服上**目前走不通**。
   本模块的做法：`slots_bought` 记在我们自己的 state 里；`create_role` 在"已有角色的账号"
   上会自动把档位开到下一个并抬 `slots_bought`（宁可可用，不要卡死）。
3. `login` 的应答**只给 `data.role`（月卡），不给 `data.account`**：她
   `StartGameLayer.lua:299-313` 里 `account`/`role` 是 **elseif** 关系，而
   `account.guankaLimit` 分支会做 `tonumber(本地guanqiaLimit) < tonumber(服务端)` ——
   本地存档缺这个字段时就是 `nil < number`，抛异常被 xpcall 吞掉 ⇒ **界面卡死**。
   而它唯一的作用是"服务端关卡上限 > 本地时才覆盖"，我们服务端的值就是从她自己上传的
   存档里读的 ⇒ 恒等 ⇒ 没有任何功能收益。所以只回 `role`。
4. `get_logoutAccount_url`：原版给的是官方**注销协议页**地址，抓不到；我们还没有自己的
   注销页，所以默认给**她自己 `getWebConfig` 里的官网地址**
   （`boot_templates/api_v5_getWebConfig.json` 的 `data.FenXiangList.default`）。
   要换成我们自己的页面，改 state 里的 `logout_account_url` 即可。
5. `login_device_2` / `logout_device_2` / `partition_clear` / `up_day_gametime` /
   `set_product_mark` / `addSingleRecord` / `clear_api_data` / `del_all_data` /
   `del_data_by_type` / `clear_my_shop_record`：**在这份客户端里 0 个 Lua 调用点**
   （我 grep 过整个 `src/app`，只有 HttpManager 里的定义，`boot_log.txt` 里也从没出现过
   这些请求）。它们是原版的运维/GM/埋点接口，所以契约只能从 URL 名 + HttpManager 上方的
   注释 + 数据落在哪本账来还原，代码里每一条都注明了依据。
6. `switch_archive` 之后她 `User:reset()` + `Game:restart()`（`ArchiveLayer.lua:108-135`），
   重启后是否能把新档案下下来，还取决于 `download_user_file_2` 按
   `md5(uuid|请求头userid)` 取档这件事 —— 真机实测请求头 `userid` 是 **0**
   （`boot_log.txt:4752`），所以本机存档路径事实上是"一设备一份"。我们的位快照
   就是围着这个事实做的（见第二节）。
7. `login` 的 userid 有**兜底**：请求头 userid 缺/为 0 时按 uuid 认本设备的账号
   （我们本来就按 uuid 记存档），真认不出来才回 550。理由见 `_ep_login` 的 docstring；
   这是为了不让"请求头没带 userid 但本设备确实有账号"把玩家踢回建号流程。
8. `get_archive_list` 在"只有 1 个存档位"时回 **errcode=1**，这是**她期望的**分支
   （`ArchiveLayer.lua:40-45` 用它渲染"未启用 / 将花费 N 元宝"那一行），
   不是错误 —— 自检探针会把它记成"errcode≠0"。
"""
import hashlib
import json
import os
import shutil
import time

NAME = 'account_archive'
TITLE = '账号/存档/分区/本地数据清理'
ENDPOINTS = [
    # A. 角色与存档（玩家真会点）
    'create_role',
    'get_archive_list',
    'switch_archive',
    'get_login_reward_info',
    'login',
    # B. 分区与设备
    'get_partition_list',
    'switch_partition',
    'switch_partition2',
    'partition_clear',
    'migrate_to_new_package',
    'migrate_to_new_package2',
    'login_device_2',
    'logout_device_2',
    'get_logoutAccount_url',
    # C. 客户端本地数据清理 / 运维
    'clear_api_data',
    'del_all_data',
    'del_data_by_type',
    'clear_my_shop_record',
    'del_activity_cache',
    'clean_voucher_record_2',
    'delete_bought_intelligence',
    'delete_day_intelligence',
    'delete_login_yuanbao_cache',
    'modify_qixi_ctime',
    'up_day_gametime',
    'set_product_mark',
    'addSingleRecord',
]

WORK = _OFF_WORK_ROOT
RES_ROOT = _fz_res()

STATE = 'account_archive_state.json'          # 本模块独占
SAVE_SUB = 'saves'                            # ★ 与 fz_boot_server 共用
ROLE_SUB = 'roles'                            # ★ 与 fz_boot_server 共用（full.json）
FESTIVAL_STATE = 'action_festival_state.json'  # 兑换券/活动缓存/七夕（action_festival.py）
INTEL_STATE = 'intelligence.json'             # 江湖情报当天账本（fz_boot_server.py）
DAILY_STATE = 'misc_daily_state.json'         # 登录元宝闸门（misc_daily.py）
MISC_STATE = 'misc_state.json'                # 离线验证码账本（misc_systems.py）
WEB_CONFIG = os.path.join('boot_templates', 'api_v5_getWebConfig.json')

# `ArchiveLayer.lua:34` 自己写的存档位默认价（她的表里没有 cundangwei 这个商品）
SLOT_PRICE = 300

# ★ 与 `fz_boot_server.py` 的 PRIVATE_UUID / PRIVATE_USERID 保持一致（唯一身份 / 唯一存档位）
_PRIVATE_UUID = 'guanfangd5056b85e3c2fffc729191fd'
_PRIVATE_USERID = 783783

_MENPAI_CACHE = {}


# ---------------------------------------------------------------- 小工具


def _num(v, d=0):
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return int(d)


def _s(v):
    return '' if v is None else str(v)


def _today():
    return time.strftime('%Y%m%d')


def _now():
    return int(time.time())


def _hget(ctx, name):
    """请求头取值（大小写不敏感）。`ctx.headers` 可能是 HTTPMessage，也可能是 dict。"""
    h = ctx.headers or {}
    try:
        v = h.get(name)
    except Exception:                            # noqa: BLE001
        v = None
    if v is None:
        try:
            for k, val in h.items():
                if _s(k).lower() == name.lower():
                    return val
        except Exception:                        # noqa: BLE001
            pass
    return v


def _uuid(ctx):
    """设备 uuid（`fz_boot_server.save_upload` 用的就是它）。探针没有这个头 ⇒ 'default'。"""
    return _s(_hget(ctx, 'uuid') or ctx.param('uuid') or 'default').strip() or 'default'


def _hdr_userid_raw(ctx):
    """请求头 userid 的**原文**（存档 key 是 `md5(uuid|原文)`，所以不能先转 int）。"""
    v = _hget(ctx, 'userid')
    if v is None:
        v = ctx.param('userid')
    return _s(v if v is not None else '')


def _work(ctx, *parts):
    base = None
    try:
        base = (ctx.deps or {}).get('here')
    except Exception:                            # noqa: BLE001
        base = None
    return os.path.join(base or WORK, *parts)


def _save_key(uuid, userid):
    """★ 与 `fz_boot_server.py:562` 完全一致：`md5("%s|%s" % (uuid, userid))[:16] + .json`。"""
    return hashlib.md5(('%s|%s' % (uuid, userid)).encode('utf-8')).hexdigest()[:16] + '.json'


def _canonical_key():
    """★ 与 `fz_boot_server.py` 的 `_canonical_save_key()` 完全一致：本机**唯一**存档位。

    私服单机单角色 ⇒ 上传/下发/存档库都认这一份（老板踩过"存的是一本、读的是另一本"）。
    """
    return hashlib.md5(('%s|%s' % (_PRIVATE_UUID, _PRIVATE_USERID)).encode('utf-8')).hexdigest()[:16]


def _device_file(ctx, uuid):
    """本机正在玩的那份存档 = `download_user_file_2` 会读、`upload_user_file_3` 会写的路径。

    ★ 2026-10-01：改成**唯一存档位**。以前按 `md5(uuid|请求头userid)` 算，
      `create_account` 给的 userid 和角色档里的 userid 不一致 ⇒ 上传、下发各写一份，
      两边永远对不上（这就是"重启后进度没了"）。
    """
    p = _work(ctx, SAVE_SUB, _canonical_key() + '.json')
    if os.path.exists(p):
        return p
    # 兼容：老包里按 uuid 算出来的那一份，如果更新就先用它（迁移期兜底）
    old = _work(ctx, SAVE_SUB, _save_key(uuid, _hdr_userid_raw(ctx) or '0'))
    if os.path.exists(old) and (not os.path.exists(p)
                                or os.path.getmtime(old) > os.path.getmtime(p)):
        return old
    return p


def _read_json(path, default=None):
    try:
        with open(path, encoding='utf-8', errors='replace') as f:
            return json.load(f)
    except Exception:                            # noqa: BLE001
        return default


def _write_json(path, obj):
    try:
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(obj, f, ensure_ascii=False, indent=1)
        return True
    except OSError:
        return False


def _read_role(path):
    """存档正文是 `{userAttr, recordInfo}` 数组（`HttpManager.lua:189`），`[1]` 才是角色。"""
    d = _read_json(path)
    if isinstance(d, list):
        for x in d:
            if isinstance(x, dict) and x:
                return x
        return None
    return d if isinstance(d, dict) and d else None


def _menpai_name(fid):
    """`family.name`（huashan…）→ 中文门派名，取自她自己的 `res/script/family/family.lua`。"""
    fid = _s(fid)
    if not fid:
        return ''
    if fid in _MENPAI_CACHE:
        return _MENPAI_CACHE[fid]
    name = fid
    try:
        import sys
        if WORK not in sys.path:
            sys.path.insert(0, WORK)
        from fz_luatable import load_lua_table
        t = load_lua_table(os.path.join(RES_ROOT, 'family', 'family.lua'))
        fam = (t or {}).get('familys') or {}
        row = fam.get(fid) or {}
        if isinstance(row, dict) and row.get('name'):
            name = _s(row['name'])
    except Exception:                            # noqa: BLE001
        name = fid
    _MENPAI_CACHE[fid] = name
    return name


def _shared(ctx, name):
    """读一份**别的模块/宿主**的状态（只读、只改我们负责的那个 key，写完落盘）。"""
    d = _read_json(_work(ctx, name))
    return d if isinstance(d, dict) else None


def _shared_save(ctx, name, d):
    return _write_json(_work(ctx, name), d)


# ---------------------------------------------------------------- 状态
def _default_partitions():
    """分区是**服务端资源**（她客户端没有分区配置表）。这一份与
    `fz_boot_server.py:our_partitions()`（`get_partition_list2` 用的那份）**保持一致** ——
    v1/v2 是同一个"服务器列表"，不能各回一套。字段名照官方抓包
    `work/boot_templates/api_v5_get_partition_list2.json` 抄。"""
    return [
        {'id': 1, 'partition_name': 'wudong', 'platform': 'android', 'channel': 'wudong',
         'channel_num': 1, 'partition_title': '武动仙途 [1区]',
         'partition_desc': '水墨江湖 · 我们自己的服务器', 'is_open': 'Y',
         'should_select_migrate': False},
        {'id': 2, 'partition_name': 'wudong_2', 'platform': 'android', 'channel': 'wudong',
         'channel_num': 2, 'partition_title': '武动仙途 [2区]',
         'partition_desc': '来自我们服务端的分区', 'is_open': 'Y',
         'should_select_migrate': False},
    ]


def _state(ctx):
    st = ctx.load_json(STATE, {})
    if not isinstance(st, dict):
        st = {}
    st.setdefault('accounts', {})
    st.setdefault('records', {})
    st.setdefault('counters', {})
    st.setdefault('product_marks', {})
    st.setdefault('gametime', {})
    st.setdefault('activity_cache', {})
    st.setdefault('voucher_records', {})
    st.setdefault('partitions', _default_partitions())
    st.setdefault('logout_account_url', '')
    st.setdefault('blacklist', [])
    st.setdefault('log', [])
    for k in ('accounts', 'records', 'counters', 'product_marks', 'gametime'):
        if not isinstance(st[k], dict):
            st[k] = {}
    if not isinstance(st['partitions'], list) or not st['partitions']:
        st['partitions'] = _default_partitions()
    if not isinstance(st['blacklist'], list):
        st['blacklist'] = []
    return st


def _save(ctx, st):
    ctx.save_json(STATE, st)
    return st


def _log(st, msg):
    lg = st.setdefault('log', [])
    lg.append({'t': _now(), 'msg': _s(msg)})
    del lg[:-200]


def _acct(st, uuid):
    accs = st.setdefault('accounts', {})
    a = accs.get(uuid)
    if not isinstance(a, dict):
        a = {}
        accs[uuid] = a
    a.setdefault('userid', 0)
    a.setdefault('slots', [])
    a.setdefault('active', 1)
    a.setdefault('slots_bought', 1)
    a.setdefault('email', '')
    a.setdefault('phone', '')
    a.setdefault('partition', 0)
    a.setdefault('login_count', 0)
    a.setdefault('last_login', 0)
    a.setdefault('bound', '')
    a.setdefault('is_logout', 0)
    a.setdefault('created', [])
    a.setdefault('migrated', {})
    if not isinstance(a['slots'], list):
        a['slots'] = []
    a['slots'] = [s for s in a['slots'] if isinstance(s, dict)]
    return a


def _slot(a, idx):
    idx = _num(idx, 0)
    if idx <= 0:
        return None
    for s in a.get('slots') or []:
        if _num(s.get('index'), 0) == idx:
            return s
    return None


def _slot_path(ctx, slot):
    f = os.path.basename(_s((slot or {}).get('file')))
    return _work(ctx, SAVE_SUB, f) if f else ''


def _occupied(ctx, uuid, a, slot):
    """这一位是不是**真有本账号的存档**。

    ★ `roles/full.json` 播种出来的位（`file` 为空）**不算占用**：它由
      `download_user_file_2` 的 `--role ours` 分支下发，不是本账号上传的存档，
      所以 `create_role` 还能填它。别的设备的存档文件绝不会被拿来当占用依据。
    """
    p = _slot_path(ctx, slot)
    if p and os.path.exists(p):
        return True
    if _num((slot or {}).get('index'), 0) == _num(a.get('active'), 0):
        return os.path.exists(_device_file(ctx, uuid))
    return False


def _seed(ctx, st, a, uuid):
    """给账号补第 1 个存档位。

    优先级：**本机存档**（`saves/<md5(uuid|请求头userid)>.json`，也就是
    `download_user_file_2` 此刻会下发的那份）→ `roles/full.json`（`--role ours` 时
    客户端真正在玩的那份角色档）→ 空位。
    """
    if a.get('slots'):
        return
    slot = {'index': 1, 'userid': 0, 'file': '', 'createTime': _now()}
    dev = _device_file(ctx, uuid)
    if os.path.exists(dev):
        slot['file'] = os.path.basename(dev)
        r = _read_role(dev) or {}
        slot['userid'] = _num(r.get('userid'), 0)
        slot['createTime'] = _num(r.get('createTime'), slot['createTime'])
    else:
        r = _read_role(_work(ctx, ROLE_SUB, 'full.json')) or {}
        if r:
            # ★ 打上播种标记：这份角色由 `download_user_file_2` 的 `--role ours` 分支下发，
            #   不是本账号上传的存档 ⇒ `_occupied` 判它"没占用"，`create_role` 还能填这一位。
            slot['seed'] = 'role_full'
            slot['userid'] = _num(r.get('userid'), 0)
            slot['createTime'] = _num(r.get('createTime'), slot['createTime'])
    a['slots'] = [slot]
    a['active'] = 1
    a['slots_bought'] = max(1, _num(a.get('slots_bought'), 1))
    if _num(a.get('userid'), 0) <= 0:
        a['userid'] = slot['userid']


def _flush(ctx, st, a, uuid):
    """把**本机存档**复制成当前存档位的快照（★ 复制，不移走：这个路径同时是
    `download_user_file_2` 的读取路径，移走下一次登录就没存档了）。"""
    dev = _device_file(ctx, uuid)
    if not os.path.exists(dev):
        return None
    slot = _slot(a, a.get('active'))
    if slot is None:
        return None
    role = _read_role(dev)
    tgt = _s(slot.get('file'))
    if not tgt:
        uid = _num((role or {}).get('userid') or slot.get('userid'), 0)
        if uid <= 0:
            uid = _num(_hdr_userid_raw(ctx), 0)
        if uid <= 0:
            return role
        slot['userid'] = uid
        tgt = _save_key(uuid, uid)
        slot['file'] = tgt
    if os.path.basename(dev) != os.path.basename(tgt):
        try:
            shutil.copyfile(dev, _work(ctx, SAVE_SUB, os.path.basename(tgt)))
        except OSError:
            pass
    if role and _num(role.get('userid'), 0) > 0:
        slot['userid'] = _num(role.get('userid'), 0)
    slot['saveTime'] = _now()
    return role


def _materialize(ctx, uuid, a, idx):
    """切到第 idx 位：把该位的快照复制回本机存档路径。该位是空的就删掉本机存档
    ⇒ `download_user_file_2` 回 `errcode!=0` ⇒ 她 `isReset="Y"` 去建号
    （`StartGameLayer.lua:207-212`）—— 这就是"切到空存档位 = 在那个位建新号"。"""
    dev = _device_file(ctx, uuid)
    slot = _slot(a, idx)
    src = _slot_path(ctx, slot)
    if src and os.path.exists(src):
        if os.path.basename(src) != os.path.basename(dev):
            try:
                shutil.copyfile(src, dev)
            except OSError:
                return False
        return True
    if os.path.exists(dev):
        try:
            os.remove(dev)
        except OSError:
            pass
    return False


def _slot_role(ctx, uuid, a, slot):
    """该存档位对应的角色（dict）或 None。"""
    if slot is None:
        return None
    p = _slot_path(ctx, slot)
    if p:
        r = _read_role(p)
        if r:
            return r
    if _num(slot.get('index'), 0) == _num(a.get('active'), 0):
        r = _read_role(_device_file(ctx, uuid))
        if r:
            return r
    if _s(slot.get('seed')) == 'role_full':      # 只有播种出来的那一位才认 roles/full.json
        return _read_role(_work(ctx, ROLE_SUB, 'full.json'))
    return None


def _meta(ctx, uuid, a, slot):
    """`ArchiveLayer:createOneArchiveItem`（:139-181）逐字段读的东西：

        Text_name:setString(params.name)     Text_menpai:setString(params.menpai)
        Text_exp:setString(math.floor(params.exp))   ← **必须是数字**
        Text_year:setString(params.year)     Text_time:setString(params.time)
        点击时比较 `params.userid`（`== nil` ⇒ 走"-- -- --"空位分支）

    ⇒ 每个字段都必须存在且类型正确；`userid` **只在真有角色时才给**
      （给了 0 她会当成"有角色"而不是空位）。
    """
    r = _slot_role(ctx, uuid, a, slot) or {}
    ct = _num(r.get('createTime'), _num(slot.get('createTime'), _now()))
    p = _slot_path(ctx, slot)
    mt = ct
    if p and os.path.exists(p):
        try:
            mt = int(os.path.getmtime(p))
        except OSError:
            mt = ct
    fam = r.get('family') if isinstance(r.get('family'), dict) else {}
    out = {
        'index': _num(slot.get('index'), 1),
        'name': _s(r.get('name')),
        'menpai': _menpai_name(_s(fam.get('name'))),
        'exp': _num(r.get('exp'), 0),
        'lv': _num(r.get('lv'), 0),
        'year': time.strftime('%Y', time.localtime(ct)),
        'time': time.strftime('%Y-%m-%d %H:%M', time.localtime(mt)),
    }
    uid = _num(r.get('userid') or slot.get('userid'), 0)
    if uid > 0:
        out['userid'] = uid
    return out


def _bought(a):
    """已购买/已开的存档位数（至少 1，且不小于已有位的最大序号）。"""
    n = max(1, _num(a.get('slots_bought'), 1))
    for s in a.get('slots') or []:
        n = max(n, _num(s.get('index'), 0))
    return n


def _slot_or_new(a, idx):
    s = _slot(a, idx)
    if s is None:
        s = {'index': idx, 'userid': 0, 'file': '', 'createTime': _now()}
        a.setdefault('slots', []).append(s)
    return s


# ================================================================ A. 角色与存档
def _ep_create_role(ctx, st):
    """`create_role`（POST 空正文，NEED_ENCRYPT）—— 建号：**分配一个 userid**。

    契约（`CreateRoleLayer.lua:135-190`）：`errcode==0 且 data.userid` 时
    她 `DataBase:resetRoleData()` → 把 `data.userid` 写进角色 → `User:save()` →
    `Account:startGameUpload()` 上传 ⇒ 存档由 `save_upload` 落在
    `saves/<md5(uuid|请求头userid)>.json`。所以这里**不能**自己造存档，
    只负责发号 + 把该存档位清干净（等她上传）。
    """
    uuid = _uuid(ctx)
    a = _acct(st, uuid)
    _seed(ctx, st, a, uuid)
    _flush(ctx, st, a, uuid)                     # 先把当前这份收进当前位，别丢

    idx = _num(ctx.param('index'), 0)
    if idx <= 0:
        cur = _slot(a, a.get('active'))
        if cur is not None and not _occupied(ctx, uuid, a, cur):
            idx = _num(cur.get('index'), 1)
        else:
            free = [s for s in a.get('slots') or [] if not _occupied(ctx, uuid, a, s)]
            if free:
                idx = _num(free[0].get('index'), 1)
            else:
                idx = max([_num(s.get('index'), 0) for s in a.get('slots') or []] or [0]) + 1
    idx = max(1, idx)
    slot = _slot_or_new(a, idx)

    used = {_num(s.get('userid'), 0) for s in a.get('slots') or []}
    cand = 100000 + (int(hashlib.md5(uuid.encode('utf-8')).hexdigest()[:8], 16) % 900000) + (idx - 1)
    while cand in used or os.path.exists(_work(ctx, SAVE_SUB, _save_key(uuid, cand))):
        cand += 1

    # 这一位要建新角色：清掉旧快照 + 清掉本机存档，让 `download_user_file_2` 回 errcode!=0
    old = _slot_path(ctx, slot)
    if old and os.path.exists(old):
        try:
            os.remove(old)
        except OSError:
            pass
    dev = _device_file(ctx, uuid)
    if os.path.exists(dev):
        try:
            os.remove(dev)
        except OSError:
            pass

    slot.update({'index': idx, 'userid': cand, 'file': _save_key(uuid, cand),
                 'createTime': _now()})
    slot.pop('seed', None)                       # 这一位现在开始就归上传的存档了
    a['active'] = idx
    a['userid'] = cand
    a['slots_bought'] = max(_num(a.get('slots_bought'), 1), idx)
    a.setdefault('created', []).append({'index': idx, 'userid': cand, 't': _now()})
    _log(st, 'create_role uuid=%s 存档位=%d 新 userid=%d' % (uuid, idx, cand))
    _save(ctx, st)
    return ctx.ok({'userid': cand, 'index': idx, 'slots_bought': a['slots_bought']},
                  '★ 建号：分配 userid=%d（存档位 %d；她读 data.userid 后自己上传存档）'
                  % (cand, idx))


def _ep_get_archive_list(ctx, st):
    """`get_archive_list`（GET）—— 多存档面板（`ArchiveLayer.lua`）。

    ★ 两个分支**形状完全不同**（`:35-100`）：
      * `errcode == 0` ⇒ `data` 是**数组**，每项一个存档位
        （`setListIsBuy` 用 `pairs` 遍历；`userid == nil` 的项渲染成 "-- -- --" 空位）
      * `errcode == 1` ⇒ `data` 是**单个**存档对象（就是当前那份）+ `data.yuanbao`
        （= 第 2 个存档位的价格），她再补一行"未启用 / 将花费 N 元宝"
      * `errcode` 其它 ⇒ 她 `PopText(errmsg)` 或 `PopText("- - - - - -")`
    """
    uuid = _uuid(ctx)
    a = _acct(st, uuid)
    _seed(ctx, st, a, uuid)
    _flush(ctx, st, a, uuid)

    bought = _bought(a)
    slots = list(a.get('slots') or [])
    for i in range(1, bought + 1):
        if _slot(a, i) is None:
            slots.append({'index': i, 'userid': 0, 'file': '', 'createTime': _now()})
    slots.sort(key=lambda s: _num(s.get('index'), 0))

    occ = [s for s in slots if _occupied(ctx, uuid, a, s)]
    _save(ctx, st)
    if bought <= 1 and len(occ) <= 1:
        d = dict(_meta(ctx, uuid, a, slots[0] if slots else {'index': 1}))
        d['yuanbao'] = SLOT_PRICE
        return (ctx.enc({'errcode': 1, 'data': d, 'rand_t': time.time()}),
                '★ 存档列表（只有 1 个存档位：回单个存档 + 第 2 位价格 %d 元宝，'
                '她渲染成"未启用/将花费 N 元宝"）' % SLOT_PRICE)
    arr = [_meta(ctx, uuid, a, s) for s in slots]
    return ctx.ok(arr, '★ 存档列表（%d 个位，%d 个有角色；data 是数组，空位不带 userid）'
                  % (len(arr), len(occ)))


def _ep_switch_archive(ctx, st):
    """`switch_archive/<index>`（GET）—— 切存档（`ArchiveLayer.lua:103-136`）。

    她 `errcode==0` ⇒ `User:reset()` + `Game:restart()` + PopText("切换成功")，
    否则 PopText("切换失败")。所以真实语义 = 把该存档位变成"本机正在玩的那份"：
    先把当前这份快照收好，再把目标位的快照铺回 `saves/<md5(uuid|请求头userid)>.json`。
    """
    uuid = _uuid(ctx)
    a = _acct(st, uuid)
    _seed(ctx, st, a, uuid)
    idx = _num(ctx.args[0] if ctx.args else 0, 0) or _num(ctx.param('index'), 0)
    if idx <= 0:
        return ctx.fail('切换存档 参数使用出错 switchArchive',
                        '★ switch_archive 业务门：没给存档位序号（她 HttpManager:458 也是直接 return）')
    if idx > _bought(a):
        return ctx.fail('该存档位尚未购买',
                        '★ switch_archive 业务门：第 %d 位还没开（已开 %d 位）' % (idx, _bought(a)))
    if idx == _num(a.get('active'), 1):
        return ctx.ok({'index': idx, 'userid': _num(a.get('userid'), 0), 'changed': 0},
                      '★ 切换存档：本来就在第 %d 位（幂等）' % idx)
    _flush(ctx, st, a, uuid)                     # 当前这份先收进当前位
    a['active'] = idx
    has = _materialize(ctx, uuid, a, idx)
    slot = _slot(a, idx) or {}
    a['userid'] = _num(slot.get('userid') or a.get('userid'), 0)
    _log(st, 'switch_archive uuid=%s -> 位%d (有存档=%s)' % (uuid, idx, has))
    _save(ctx, st)
    return ctx.ok({'index': idx, 'userid': _num(slot.get('userid'), 0), 'changed': 1},
                  '★ 切换存档到第 %d 位（%s；她收到 errcode=0 就 User:reset + Game:restart）'
                  % (idx, '已铺回该位存档' if has else '该位是空的 ⇒ 她重启后走建号流程'))


def _ep_get_login_reward_info(ctx, st):
    """`get_login_reward_info`（GET）—— 新春/周年"登陆送元宝"弹窗的信息。

    ★ 契约来自**她自己的源码注释**（`MainLayer.lua:837` 原话：
      `-- "name":"周年庆登陆得奖励","dsc":"谨此献上一份薄礼，还望大侠笑纳。","item":{"exp":10000,"gold":888}`），
      读法在 `MainLayer.lua:835-849`：`data.name and data.dsc and data.item` 三件套齐了才弹
      `DengLuJiangLiLayer:showlayer(data.dsc, data.item, cb)`；
      `DengLuJiangLiLayer.lua:66-77` 又 `pairs` 遍历 `item`（**对象**，属性名→数值）拼描述。
      真正发奖是 `get_login_yuanbao`（`misc_daily`），本接口只给"信息"。
    ★ 她客户端自己会按日期卡这段（`MainLayer.lua:818` 限 20200928~20201025），服务端不重复卡。
    """
    return ctx.ok({'name': '周年庆登陆得奖励',
                   'dsc': '谨此献上一份薄礼，还望大侠笑纳。',
                   'item': {'exp': 10000, 'gold': 888}},
                  '★ 登陆奖励信息（name/dsc/item{对象} 三件套，取自她 MainLayer.lua:837 的注释样例；'
                  '发奖在 get_login_yuanbao）')


def _ep_login(ctx, st):
    """`login`（POST `{exp,pot,money}`）—— 登录校验（`HttpManager:checkLogin` :377，
    调用点 `StartGameLayer.lua:233-345`）。

    `errcode` 语义（她逐条分支）：0 成功（`initUserDataFromWeb(data)`）/ 1 黑名单（弹封号框）
    / 550 userid 非法 / 551 uuid 非法 / 552 该 userid 不存在（重置去建号）/ 其它 `PopText("网络出错")`。

    ★ 请求头 userid 缺/为 0 时的兜底：真机实测她客户端在**没有本地存档**时请求头 userid
      就是 `0`（`boot_log.txt:4752`），而 `login` 只在本地 userid > 0 时才会被调用
      （`StartGameLayer.lua:264`）。为了不让"她请求头没带上 userid、但本服这台设备确实有账号"
      这种情况把玩家踢回建号流程，这里按 **uuid** 兜底认账号（我们本来就按 uuid 记存档）；
      真的什么都认不出来才回 550 —— 那是合约里 `invalid userid` 的正确语义。
    """
    uuid = _s(_hget(ctx, 'uuid') or ctx.param('uuid') or '')
    raw = _hdr_userid_raw(ctx)
    uid = _num(raw, 0)
    src = '请求头'
    if not uuid:
        return ctx.fail('invalid uuid',
                        '★ login 业务门：缺 uuid（她 StartGameLayer:277 的 551 分支）', errcode=551)
    if uid <= 0:
        a0 = _acct(st, uuid)
        _seed(ctx, st, a0, uuid)
        for s in a0.get('slots') or []:
            if _num(s.get('userid'), 0) > 0:
                uid = _num(s.get('userid'), 0)
                break
        if uid <= 0:
            uid = _num(a0.get('userid'), 0)
        if uid <= 0:
            r = _read_role(_device_file(ctx, uuid)) or {}
            uid = _num(r.get('userid'), 0)
        if uid > 0:
            src = '按 uuid 兜底'
    if uid <= 0:
        return ctx.fail('invalid userid',
                        '★ login 业务门：userid 非法且本设备也没有账号（她 StartGameLayer:272 的 550 分支）',
                        errcode=550)
    if uid in [_num(x, 0) for x in (st.get('blacklist') or [])]:
        return ctx.fail('blacklist',
                        '★ login 业务门：userid=%d 在我们 state 的封号名单里（她弹"数据存在异常"框）' % uid,
                        errcode=1)

    a = _acct(st, uuid)
    _seed(ctx, st, a, uuid)
    _flush(ctx, st, a, uuid)
    known = {_num(s.get('userid'), 0) for s in a.get('slots') or []}
    known.add(_num(a.get('userid'), 0))
    exists = uid in known or os.path.exists(
        _work(ctx, SAVE_SUB, _save_key(uuid, raw or '0'))) or \
        os.path.exists(_work(ctx, SAVE_SUB, _save_key(uuid, uid)))
    if not exists:
        return ctx.fail('userid not exists',
                        '★ login 业务门：userid=%d 在本服没有存档（552 ⇒ 她置 isReset=Y 去建号）' % uid,
                        errcode=552)

    role = _slot_role(ctx, uuid, a, _slot(a, a.get('active'))) or {}
    a['last_login'] = _now()
    a['login_count'] = _num(a.get('login_count'), 0) + 1
    a['userid'] = uid
    days = a.setdefault('login_days', {})
    if isinstance(days, dict):
        days[_today()] = _num(days.get(_today()), 0) + 1
    _log(st, 'login uuid=%s userid=%d(%s) 第%d次' % (uuid, uid, src, a['login_count']))
    _save(ctx, st)
    # ★ 只回 data.role，**不回** data.account —— 理由见模块 docstring 第 4 节
    #   （她那两个分支是 elseif，且 account.guankaLimit 会拿本地值做 tonumber 比较，
    #    本地缺字段时 nil < number 直接抛异常被 xpcall 吞掉 ⇒ 界面卡死）。
    return ctx.ok({'role': {'yueka': False,
                            'expired_time': _num(role.get('yuekaTime'), 0)}},
                  '★ 登录校验通过（userid=%d，来源=%s，第 %d 次；只回 data.role：她 account/role 是'
                  'elseif，account.guankaLimit 有 nil 比较炸点，理由见模块头）'
                  % (uid, src, a['login_count']))


# ================================================================ B. 分区与设备
def _partition_of(st, pid):
    for p in st.get('partitions') or []:
        if _num(p.get('id'), 0) == _num(pid, 0):
            return p
    return None


def _ep_get_partition_list(ctx, st):
    """`get_partition_list`（GET）—— 服务器/分区列表（`SwitchServerController.lua:57-87`）。

    她读：`data.list[]` 里每项的 `id / partition_title / partition_desc / channel /
    partition_name / should_select_migrate`（`:248-256` 转成 name/desc/channel），
    以及 `data.user.email / data.user.active_partition`（`:271-276`，migrate 流程要用 email）。
    """
    uuid = _uuid(ctx)
    a = _acct(st, uuid)
    lst = [dict(p) for p in (st.get('partitions') or []) if isinstance(p, dict)]
    for p in lst:
        p.setdefault('should_select_migrate', False)
    _save(ctx, st)
    return ctx.ok({'list': lst,
                   'user': {'should_migrate': False,
                            'email': _s(a.get('email')),
                            'active_partition': _num(a.get('partition'), 0)}},
                  '★ 分区列表（%d 个；与我们 get_partition_list2 同一份表，'
                  'active_partition=%s）' % (len(lst), a.get('partition')))


def _switch_partition(ctx, st, ep):
    """`switch_partition/<id>` / `switch_partition2/<id>` —— 切分区
    （`SwitchServerController.lua:118-216`，真调用点是 switchServer2）。

    她读 `errcode`（0=成功）、`data.msg`（非空就 PopText）、`data.uuid`（换 uuid + 重连）。
    我们先 `_flush` 存档再记分区 ⇒ 切区不会丢当前这份存档。
    """
    uuid = _uuid(ctx)
    a = _acct(st, uuid)
    pid = _num(ctx.args[0] if ctx.args else 0, 0) or _num(ctx.param('id'), 0)
    p = _partition_of(st, pid)
    if p is None:
        return ctx.fail('分区不存在',
                        '★ %s 业务门：id=%s 不在我们的分区表里（表里是 %s）'
                        % (ep, pid, [x.get('id') for x in st.get('partitions') or []]))
    _seed(ctx, st, a, uuid)
    _flush(ctx, st, a, uuid)
    a['partition'] = _num(p.get('id'), 0)
    hist = a.setdefault('partition_history', [])
    if isinstance(hist, list):
        hist.append({'id': a['partition'], 't': _now()})
        del hist[:-50]
    _log(st, '%s uuid=%s -> 分区 %s(%s)' % (ep, uuid, p.get('id'), p.get('partition_title')))
    _save(ctx, st)
    return ctx.ok({'msg': '已切换到服务器：%s' % _s(p.get('partition_title')),
                   'serverId': _num(p.get('id'), 0),
                   'partition_name': _s(p.get('partition_name')),
                   'uuid': uuid},
                  '★ 切分区到 %s（她读 data.msg 弹提示、data.uuid 重连；存档已先快照）'
                  % _s(p.get('partition_title')))


def _ep_partition_clear(ctx, st):
    """`partition_clear`（GET）—— 注释「清除分区记录」（`HttpManager.lua:1721`）。"""
    uuid = _uuid(ctx)
    a = _acct(st, uuid)
    old = _num(a.get('partition'), 0)
    a['partition'] = 0
    a['partition_history'] = []
    _log(st, 'partition_clear uuid=%s（原分区 %s）' % (uuid, old))
    _save(ctx, st)
    return ctx.ok({'active_partition': 0, 'cleared': old},
                  '★ 清除分区记录（原 active_partition=%s ⇒ 0，切换历史一并清掉）' % old)


def _verify_code(ctx, key, code):
    """验证码校验：账本是 `misc_systems.py` 的 `send_email` / `send_verify_code`
    **离线模拟**发出来的那一份（`misc_state.json` 的 `account.code/code_key/code_expire`）。
    """
    d = _shared(ctx, MISC_STATE) or {}
    acc = d.get('account') if isinstance(d.get('account'), dict) else {}
    real = _s(acc.get('code'))
    if not real:
        return False, '请先获取验证码'
    exp = _num(acc.get('code_expire'), 0)
    if exp and _now() > exp:
        return False, '验证码已过期'
    if _s(code) != real:
        return False, '验证码错误'
    ck = _s(acc.get('code_key'))
    if ck and _s(key) and ck != _s(key):
        return False, '验证码与账号不匹配'
    return True, ''


def _consume_code(ctx):
    """用掉验证码（一次性），只改 `account.code` 这一个 key 再落盘。"""
    d = _shared(ctx, MISC_STATE)
    if not isinstance(d, dict):
        return
    acc = d.get('account')
    if isinstance(acc, dict):
        acc['code'] = ''
        acc['code_expire'] = 0
        _shared_save(ctx, MISC_STATE, d)


def _acct_by_email(st, email):
    em = _s(email).strip().lower()
    if not em:
        return None, None
    for u, a in (st.get('accounts') or {}).items():
        if isinstance(a, dict) and _s(a.get('email')).strip().lower() == em:
            return u, a
    return None, None


def _migrate(ctx, st, ep):
    """`migrate_to_new_package` / `2`（POST `{email,verify_code[,serverId]}`）—— 注释「继承角色」。

    `SwitchServerController.lua:93-112` 只看 `errcode`（0=成功，否则 PopText(errmsg)）。
    真实语义 = 用**邮箱 + 验证码**把该邮箱名下账号的角色继承到这台服务器/分区：
      * 邮箱在我们账本里存在（且不是本设备）⇒ 把它**当前存档位的存档铺到本设备**
        （她随后 `switchServer2` → 重启 → `download_user_file_2` 就能拿到那份角色）
      * 不存在 ⇒ 只记"这个邮箱迁到了我们服"（官方包迁进来就是这种情况）
    """
    email = _s(ctx.param('email')).strip()
    code = _s(ctx.param('verify_code') or ctx.param('code'))
    if not email:
        return ctx.fail('请填写邮箱',
                        '★ %s 业务门：缺 email（她 SwitchServerEmailLayer 让玩家填）' % ep)
    if not code:
        return ctx.fail('验证码不能为空',
                        '★ %s 业务门：缺 verify_code（她 `sendEmail("继承", email)` 先发码）' % ep)
    ok, why = _verify_code(ctx, email, code)
    if not ok:
        return ctx.fail(why, '★ %s 业务门：%s（校验 misc_state.json 的离线验证码账本）' % (ep, why))

    sid_raw = ctx.param('serverId')
    sid = _num(sid_raw, 0)
    if sid_raw is not None and _s(sid_raw) != '' and _partition_of(st, sid) is None:
        return ctx.fail('分区不存在', '★ %s 业务门：serverId=%s 不在我们的分区表里' % (ep, sid_raw))

    uuid = _uuid(ctx)
    a = _acct(st, uuid)
    _seed(ctx, st, a, uuid)
    src_uuid, src = _acct_by_email(st, email)
    moved = 0
    if src_uuid and src_uuid != uuid and isinstance(src, dict):
        _flush(ctx, st, src, src_uuid)
        sslot = _slot(src, src.get('active'))
        sfile = _slot_path(ctx, sslot)
        if sfile and os.path.exists(sfile):
            try:
                shutil.copyfile(sfile, _device_file(ctx, uuid))
                moved = 1
            except OSError:
                moved = 0
        a['slots'] = [dict(s) for s in (src.get('slots') or []) if isinstance(s, dict)] or a['slots']
        a['active'] = _num(src.get('active'), 1)
        a['slots_bought'] = max(_num(src.get('slots_bought'), 1), _bought(a))
        a['userid'] = _num(src.get('userid'), a.get('userid'))
    a['email'] = email
    a['migrated'] = {'email': email, 'serverId': sid, 't': _now(),
                     'from': src_uuid or '', 'save_moved': moved}
    _consume_code(ctx)
    _log(st, '%s uuid=%s email=%s serverId=%s 源账号=%s 铺存档=%s'
         % (ep, uuid, email, sid, src_uuid or '-', moved))
    _save(ctx, st)
    return ctx.ok({'msg': '角色继承成功', 'email': email, 'serverId': sid,
                   'save_moved': moved},
                  '★ %s：邮箱 %s 的账号已迁到本服%s（验证码来自 misc_systems 的离线账本）'
                  % (ep, email, '（源账号存档已铺到本设备）' if moved else ''))


def _device_keys(ctx):
    send_type = _s(ctx.param('send_type')).strip()
    key = _s(ctx.param(send_type) if send_type else '') or \
        _s(ctx.param('email') or ctx.param('phone') or ctx.param('send_key'))
    code = _s(ctx.param('verify_code'))
    return send_type, key, code


def _ep_login_device(ctx, st):
    """`login_device_2`（POST `{send_type,[send_type]=key,verify_code}`）—— 注释「登录设备」
    （`HttpManager.lua:886-899`；本客户端 0 个 Lua 调用点，是账号中心用的）。

    真实语义：用**绑定邮箱/手机 + 验证码**把这台设备登进那个账号 ⇒ 记下
    `邮箱 → uuid` 的绑定关系（`Account:getBindInfo` / `getEmail` 那一族读的就是它）。
    """
    send_type, key, code = _device_keys(ctx)
    if not send_type or not key:
        return ctx.fail('请填写邮箱或手机号',
                        '★ login_device_2 业务门：缺 send_type/账号（她 HttpManager:891 直接 return）')
    if not code:
        return ctx.fail('验证码不能为空', '★ login_device_2 业务门：缺 verify_code')
    ok, why = _verify_code(ctx, key, code)
    if not ok:
        return ctx.fail(why, '★ login_device_2 业务门：%s' % why)
    uuid = _uuid(ctx)
    bindings = st.setdefault('bindings', {})
    if not isinstance(bindings, dict):
        bindings = {}
        st['bindings'] = bindings
    bindings[_s(key).lower()] = uuid
    a = _acct(st, uuid)
    if send_type == 'phone':
        a['phone'] = _s(key)
    else:
        a['email'] = _s(key)
    a['is_logout'] = 0
    a['bound'] = _s(key)
    _consume_code(ctx)
    _log(st, 'login_device_2 %s=%s uuid=%s' % (send_type, key, uuid))
    _save(ctx, st)
    return ctx.ok({'send_type': send_type, 'is_logout': 0, 'uuid': uuid},
                  '★ 设备登录：%s=%s 已绑到本设备 uuid=%s（验证码已消费）' % (send_type, key, uuid))


def _ep_logout_device(ctx, st):
    """`logout_device_2`（POST 同上）—— 注释「登出设备」。

    ★ 同一个 URL 还有 `logoutUnbindDevice2`（:922）：**不带正文**、用请求头 `isBind=0`
      调，语义是"登出未绑定的设备" ⇒ 不校验验证码。
    """
    uuid = _uuid(ctx)
    a = _acct(st, uuid)
    is_bind = _s(_hget(ctx, 'isBind')).strip()
    send_type, key, code = _device_keys(ctx)
    if is_bind == '0' or (not send_type and not key and not code):
        a['is_logout'] = 1
        a['bound'] = ''
        _log(st, 'logout_device_2（isBind=%s）uuid=%s 免验证码登出' % (is_bind or '?', uuid))
        _save(ctx, st)
        return ctx.ok({'is_logout': 1, 'send_type': send_type},
                      '★ 登出未绑定设备（isBind=%s）：本设备已登出，不校验验证码'
                      % (is_bind or '无'))
    if not send_type or not key:
        return ctx.fail('请填写邮箱或手机号',
                        '★ logout_device_2 业务门：缺 send_type/账号（她 HttpManager:907 直接 return）')
    if not code:
        return ctx.fail('验证码不能为空', '★ logout_device_2 业务门：缺 verify_code')
    ok, why = _verify_code(ctx, key, code)
    if not ok:
        return ctx.fail(why, '★ logout_device_2 业务门：%s' % why)
    bindings = st.setdefault('bindings', {})
    if isinstance(bindings, dict) and _s(bindings.get(_s(key).lower())) == uuid:
        bindings.pop(_s(key).lower(), None)
    a['is_logout'] = 1
    a['bound'] = ''
    _consume_code(ctx)
    _log(st, 'logout_device_2 %s=%s uuid=%s' % (send_type, key, uuid))
    _save(ctx, st)
    return ctx.ok({'is_logout': 1, 'send_type': send_type, 'uuid': uuid},
                  '★ 设备登出：%s=%s 已从本设备解绑（验证码已消费）' % (send_type, key))


def _ep_logout_account_url(ctx, st):
    """`get_logoutAccount_url`（GET，NEED_ENCRYPT）—— 注释「获取账号注销网址」（:5468-5478）。

    `Account:gotoLogoutAccountWeb`（`Account.lua:537-564`）在 `errcode==0` 时
    **删掉本地角色 + 本地 userid**，然后 `SetupUIInMenuLayer.lua:818` 用
    `data.url` 开网页（"需要跳转到网页填写注销协议和注销内容"）。
    ⇒ 本接口只负责**给网址**（真正注销在网页上），这里不删任何存档。
    """
    url = _s(st.get('logout_account_url'))
    if not url:
        d = _shared(ctx, WEB_CONFIG) or {}
        fl = ((d.get('data') or {}).get('FenXiangList') or {}) if isinstance(d, dict) else {}
        url = _s(fl.get('default')) if isinstance(fl, dict) else ''
    if not url:
        url = 'http://fzjh.xiaohoutiaotiao.com/'
    return ctx.ok({'url': url},
                  '★ 账号注销网址（%s；取自 state.logout_account_url，缺省用她 getWebConfig 的'
                  'FenXiangList.default 官网地址 —— 我们自己的注销页还没做）' % url[:60])


# ================================================================ C. 本地数据清理 / 运维
def _rec_bucket(st, key):
    r = st.setdefault('records', {})
    b = r.get(key)
    if not isinstance(b, list):
        b = []
        r[key] = b
    return b


def _cnt(st, key, delta=0):
    c = st.setdefault('counters', {})
    v = _num(c.get(key), 0) + delta
    c[key] = v
    return v


def _ep_add_single_record(ctx, st):
    """`addSingleRecord`（POST，**正文就是记录本身**）—— 注释「调查问卷·添加单条记录」
    （`HttpManager.lua:2004-2011`：`retryPostWithHeader(DOMAIN.."addSingleRecord", type, ...)`，
    `type` 就是这个 table）。

    真实语义：把这条记录落进服务端的记录账本（她的埋点/问卷统计用的就是这一族：
    `count_single_record` / `count_multi_record` / `get_client_data` / `del_all_data`）。
    记录形状照 `HttpManager:addRecordCount` 上方的注释（`:1648-1657`）：
    `{"act": "keyao", "id": "tiaoxi", "t": UNIXTIME}`。
    """
    b = ctx.body_obj if isinstance(ctx.body_obj, dict) else {}
    rec = b.get('_value') if '_value' in b else b
    if isinstance(rec, list):
        items = [x for x in rec if isinstance(x, (dict, list, int, float, str))]
    elif isinstance(rec, dict):
        items = [rec]
    else:
        items = []
    if not items:
        return ctx.fail('参数不能为空',
                        '★ addSingleRecord 业务门：正文里没有记录（她上行正文本身就是记录 table）')
    added = []
    for it in items:
        act = 'single'
        if isinstance(it, dict):
            act = _s(it.get('act') or it.get('type') or it.get('key') or 'single') or 'single'
            it = dict(it)
            it.setdefault('t', _now())
        added.append((act, it))
    for act, it in added:
        _rec_bucket(st, act).append(it)
        _cnt(st, act, 1)
    acts = sorted({a for a, _ in added})
    _log(st, 'addSingleRecord %d 条 -> %s' % (len(added), ','.join(acts)))
    _save(ctx, st)
    return ctx.ok({'count': len(added), 'acts': acts,
                   'total': {a: len(_rec_bucket(st, a)) for a in acts}},
                  '★ 记录已落库（%d 条，账本 act=%s；她只判 errcode==0）'
                  % (len(added), ','.join(acts)))


def _ep_clear_api_data(ctx, st):
    """`clear_api_data`（POST `{act}`）—— 注释「清除江湖好友的投票次数」
    （`HttpManager.lua:1574-1578`）。`act` 就是那条记录/计数器的标识。"""
    act = _s(ctx.param('act') or (ctx.args[0] if ctx.args else ''))
    recs = st.setdefault('records', {})
    cnts = st.setdefault('counters', {})
    if act:
        n = len(recs.get(act) or []) if isinstance(recs.get(act), list) else 0
        c = _num(cnts.get(act), 0)
        recs[act] = []
        cnts[act] = 0
        _log(st, 'clear_api_data act=%s（清 %d 条 / 计数 %d）' % (act, n, c))
        _save(ctx, st)
        return ctx.ok({'act': act, 'cleared': n, 'counter': c},
                      '★ 清除 act=%s 的记录与计数（原 %d 条 / 计数 %d；'
                      '她 HttpManager:1574 的注释是「清除江湖好友的投票次数」）'
                      % (act, n, c))
    n = sum(len(v) for v in recs.values() if isinstance(v, list))
    recs.clear()
    cnts.clear()
    _log(st, 'clear_api_data 全清（%d 条）' % n)
    _save(ctx, st)
    return ctx.ok({'act': '', 'cleared': n, 'counter': 0},
                  '★ 未给 act ⇒ 清空整个记录账本（%d 条）' % n)


def _ep_del_all_data(ctx, st):
    """`del_all_data`（POST `{type}`）—— 注释「删除数据库对应标识的数据」
    （`HttpManager.lua:2046-2053`）：删掉该标识的**整桶**（记录 + 计数）。"""
    t = _s(ctx.param('type') or (ctx.args[0] if ctx.args else ''))
    recs = st.setdefault('records', {})
    cnts = st.setdefault('counters', {})
    n = len(recs.get(t) or []) if isinstance(recs.get(t), list) else 0
    recs.pop(t, None)
    c = _num(cnts.pop(t, 0), 0)
    _log(st, 'del_all_data type=%s（%d 条）' % (t, n))
    _save(ctx, st)
    return ctx.ok({'type': t, 'deleted': n, 'counter': c},
                  '★ 删除标识 %s 的全部数据（%d 条 / 计数 %d）' % (t or '(空)', n, c))


def _ep_del_data_by_type(ctx, st):
    """`del_data_by_type`（POST `{type}`）—— 注释「清除统计数据」
    （`HttpManager.lua:2148-2155`）。与 `del_all_data` 的区别：这个是**按类型清统计条目**
    —— 遍历所有 act 桶，把 `act/type/id` 命中该类型的条目摘掉。"""
    t = _s(ctx.param('type') or (ctx.args[0] if ctx.args else ''))
    recs = st.setdefault('records', {})
    cnts = st.setdefault('counters', {})
    removed = 0
    for act in list(recs.keys()):
        b = recs.get(act)
        if not isinstance(b, list):
            continue
        keep = []
        for it in b:
            hit = _s(act) == t
            if isinstance(it, dict):
                hit = hit or _s(it.get('act')) == t or _s(it.get('type')) == t or _s(it.get('id')) == t
            if hit:
                removed += 1
            else:
                keep.append(it)
        recs[act] = keep
    if t in cnts:
        cnts[t] = 0
    _log(st, 'del_data_by_type type=%s（摘掉 %d 条）' % (t, removed))
    _save(ctx, st)
    return ctx.ok({'type': t, 'deleted': removed, 'counter': _num(cnts.get(t), 0)},
                  '★ 按类型 %s 清除统计数据（摘掉 %d 条，桶保留）' % (t or '(空)', removed))


def _ep_clear_my_shop_record(ctx, st):
    """`clear_my_shop_record`（POST `{shop_id}`）—— `clearShopRecord`（:1630）注释
    「清除兑换次数,测试使用」；`clearPointRecord`（:1642）注释「重置活动积分」，
    两个函数打的是**同一个 URL**（都传 `{shop_id = ...}`）。"""
    shop = _s(ctx.param('shop_id') or (ctx.args[0] if ctx.args else ''))
    recs = st.setdefault('records', {})
    cnts = st.setdefault('counters', {})
    keys = [shop, 'shop:' + shop, 'shop_%s' % shop]
    n = 0
    for k in list(recs.keys()):
        b = recs.get(k)
        if not isinstance(b, list):
            continue
        keep = []
        for it in b:
            hit = k in keys
            if isinstance(it, dict):
                hit = hit or _s(it.get('shop_id')) == shop
            if hit:
                n += 1
            else:
                keep.append(it)
        recs[k] = keep
    for k in keys:
        if k in cnts:
            cnts[k] = 0
    _log(st, 'clear_my_shop_record shop_id=%s（清 %d 条）' % (shop, n))
    _save(ctx, st)
    return ctx.ok({'shop_id': shop, 'cleared': n},
                  '★ 清除商店/活动 %s 的兑换记录与次数（%d 条；她注释"清除兑换次数/重置活动积分"）'
                  % (shop or '(空)', n))


def _ep_del_activity_cache(ctx, st):
    """`del_activity_cache`（GET）—— 紧跟在「获取是否有未查看的活动」后面
    （`HttpManager.lua:1215-1223`）⇒ 清活动缓存。

    清两处：我们自己的缓存 + `action_festival_state.json` 里那两个**纯缓存字段**
    （`diy.list` / `lucky.goods`）：`action_festival.py:757`、`:1295` 都是
    `x or 重新生成`，置 None 只丢缓存不丢进度。
    """
    st['activity_cache'] = {}
    d = _shared(ctx, FESTIVAL_STATE)
    n = 0
    if isinstance(d, dict):
        for k, sub in (('diy', 'list'), ('lucky', 'goods')):
            v = d.get(k)
            if isinstance(v, dict) and v.get(sub):
                v[sub] = None
                n += 1
        if n:
            _shared_save(ctx, FESTIVAL_STATE, d)
    _log(st, 'del_activity_cache（清了 %d 个活动缓存字段）' % n)
    _save(ctx, st)
    return ctx.ok({'cache_cleared': n},
                  '★ 清活动缓存（我们的 activity_cache + 活动模块的 diy.list/lucky.goods 两个纯缓存字段，'
                  '共 %d 个；下次请求按她的表重新生成）' % n)


def _ep_clean_voucher_record(ctx, st):
    """`clean_voucher_record_2`（GET）—— 注释「测试接口不提交正式服」（:1391-1395）。

    兑换券的"已使用"账本在 `action_festival.py:_h_get_voucher_prize_2`：
    它用 `st['voucher']['got'][voucher]` 判「该兑换券已使用」⇒ 这里把那本账清掉，
    同一张兑换券就能**重新兑换**（这正是这个测试接口的作用）。
    """
    d = _shared(ctx, FESTIVAL_STATE)
    n = 0
    if isinstance(d, dict):
        v = d.get('voucher')
        if isinstance(v, dict):
            n = len(v.get('got') or {}) if isinstance(v.get('got'), dict) else 0
            v['got'] = {}
        else:
            d['voucher'] = {'got': {}}
        _shared_save(ctx, FESTIVAL_STATE, d)
    st['voucher_records'] = {}
    _log(st, 'clean_voucher_record_2（清掉 %d 张已用兑换券）' % n)
    _save(ctx, st)
    return ctx.ok({'cleared': n},
                  '★ 清除兑换券使用记录（%d 张已用券恢复到"未使用"，她 get_voucher_prize_2 的闸门就开了）'
                  % n)


def _intel(ctx):
    d = _shared(ctx, INTEL_STATE)
    if not isinstance(d, dict):
        d = {}
    d.setdefault('day', _today())
    d.setdefault('uploaded', False)
    d.setdefault('bought', False)
    d.setdefault('intelligence_list', [])
    d.setdefault('technique_list', [])
    d.setdefault('currency_type', 1)
    d.setdefault('price', 0)
    d.setdefault('read', [])
    return d


def _ep_delete_day_intelligence(ctx, st):
    """`delete_day_intelligence`（GET）—— 注释「删除今日已购买情报」（:3649-3653）。

    账本是 `intelligence.json`（`fz_boot_server.py:_intel_load/_intel_save`，
    `get_intelligence_data` 按 `bought` 决定回 errcode 0/1/2）。把 `bought` 打回 False
    ⇒ 她再进情报面板时回到 errcode 1「已上传待购买」，今天可以**重新购买**。
    """
    d = _intel(ctx)
    was = bool(d.get('bought'))
    d['bought'] = False
    d['bought_intelligence_list'] = []
    d['bought_technique_list'] = []
    _shared_save(ctx, INTEL_STATE, d)
    _log(st, 'delete_day_intelligence（bought %s -> False）' % was)
    _save(ctx, st)
    return ctx.ok({'bought': 0, 'was_bought': 1 if was else 0,
                   'intelligence': len(d.get('intelligence_list') or [])},
                  '★ 今日情报购买记录已删（bought %s→False，%d 条待购；'
                  '下次 get_intelligence_data 回 errcode 1）'
                  % (was, len(d.get('intelligence_list') or [])))


def _ep_delete_bought_intelligence(ctx, st):
    """`delete_bought_intelligence`（POST `{type}`）—— 注释「删除购买过的情报」（:3655-3659）。

    `type` 选哪一本：她 `qingbaoku` 里情报分普通（type 1/2）与"江湖秘辛"技巧类（type 3），
    对应 `intelligence.json` 的 `intelligence_list` / `technique_list`。
    """
    t = _num(ctx.param('type'), 0)
    d = _intel(ctx)
    if t == 3:
        n = len(d.get('technique_list') or [])
        d['technique_list'] = []
        d['bought_technique_list'] = []
        what = '技巧类（江湖秘辛）'
    else:
        n = len(d.get('intelligence_list') or [])
        d['intelligence_list'] = []
        d['bought_intelligence_list'] = []
        d['read'] = []
        d['uploaded'] = False        # 让她重新抽今天的（原版语义：这条购买记录被删了）
        d['bought'] = False
        what = '普通情报'
    _shared_save(ctx, INTEL_STATE, d)
    _log(st, 'delete_bought_intelligence type=%s（%s %d 条）' % (t, what, n))
    _save(ctx, st)
    return ctx.ok({'type': t, 'deleted': n, 'bought': _num(d.get('bought'), 0)},
                  '★ 删除已购%s（%d 条；type=3 清 technique_list，其余清 intelligence_list 并'
                  '置 uploaded=False ⇒ 她重新抽今天的）' % (what, n))


def _ep_delete_login_yuanbao_cache(ctx, st):
    """`delete_login_yuanbao_cache`（GET）—— 注释「清除今天领取次数」（:2200-2204）。

    闸门在 `misc_daily.py:_ep_get_login_yuanbao`：`st['login']` 的 `got/last/days[today]`。
    清掉它 ⇒ 今天能再领一次（这就是这个测试接口的语义）。
    """
    d = _shared(ctx, DAILY_STATE)
    n = 0
    if isinstance(d, dict):
        l = d.get('login')
        if not isinstance(l, dict):
            l = {}
            d['login'] = l
        n = _num(l.get('got'), 0)
        l['got'] = 0
        l['last'] = 0
        days = l.get('days')
        if isinstance(days, dict):
            days.pop(_today(), None)
        _shared_save(ctx, DAILY_STATE, d)
    _log(st, 'delete_login_yuanbao_cache（原 got=%d）' % n)
    _save(ctx, st)
    return ctx.ok({'got': 0, 'was_got': n, 'day': _today()},
                  '★ 登录元宝今日领取次数已清（原 got=%d ⇒ 0；她 get_login_yuanbao 的'
                  '防重复闸门就放行了）' % n)


def _ep_modify_qixi_ctime(ctx, st):
    """`modify_qixi_ctime/<daynum>`（GET）—— 注释「测试接口」，函数名 `testModifyQiXiCtime`
    （:2726-2733，`daynum` 缺省 0）。

    语义 = 把七夕活动的 **ctime（活动开始时间）** 挪 `daynum` 天：写进
    `action_festival_state.json` 的 `qixi.ctime`（`action_festival.py:400` 的 qixi 账本；
    那边目前没有按 ctime 做时间门，所以这里只记时间戳，**不动** day/finish/got 进度）。
    """
    daynum = _num(ctx.args[0] if ctx.args else 0, 0) or _num(ctx.param('daynum'), 0)
    ctime = _now() + daynum * 86400
    d = _shared(ctx, FESTIVAL_STATE)
    if isinstance(d, dict):
        q = d.get('qixi')
        if not isinstance(q, dict):
            q = {'day': 0, 'finish': 0, 'state': 0, 'got': {}}
            d['qixi'] = q
        q['ctime'] = ctime
        _shared_save(ctx, FESTIVAL_STATE, d)
    st['qixi_ctime'] = ctime
    _log(st, 'modify_qixi_ctime daynum=%s -> ctime=%d' % (daynum, ctime))
    _save(ctx, st)
    return ctx.ok({'ctime': ctime, 'daynum': daynum},
                  '★ 七夕活动 ctime 设为 %s（now%+d 天；写进活动模块的 qixi.ctime，'
                  '进度 day/finish/got 未动）' % (time.strftime('%Y-%m-%d %H:%M', time.localtime(ctime)), daynum))


def _ep_up_day_gametime(ctx, st):
    """`up_day_gametime`（POST `{time}`）—— 注释「上传当日游戏累计时间」（:874-884，非数字直接 return）。

    真实语义 = 服务端记这本"今日累计在线时长"的账（防沉迷/统计用）。我们按设备+日期存
    `gametime[uuid][YYYYMMDD] = {total, last, count}`，`total` 取她报上来的**最大值**
    （她传的是累计值，不是增量）。
    """
    t = _num(ctx.param('time'), -1)
    if t < 0:
        return ctx.fail('参数使用出错 upDayGameTime',
                        '★ up_day_gametime 业务门：time 非数字（她 HttpManager:876 直接 return）')
    key = _uuid(ctx)
    g = st.setdefault('gametime', {}).setdefault(key, {})
    if not isinstance(g, dict):
        g = {}
        st['gametime'][key] = g
    day = _today()
    rec = g.get(day)
    if not isinstance(rec, dict):
        rec = {'total': 0, 'last': 0, 'count': 0}
        g[day] = rec
    rec['total'] = max(_num(rec.get('total'), 0), t)
    rec['last'] = t
    rec['count'] = _num(rec.get('count'), 0) + 1
    g['day'] = day
    _save(ctx, st)
    return ctx.ok({'time': rec['total'], 'day': day, 'report': t, 'count': rec['count']},
                  '★ 当日游戏时长已记账（本次报 %d 秒，今日累计 %d 秒，第 %d 次上报）'
                  % (t, rec['total'], rec['count']))


def _ep_set_product_mark(ctx, st):
    """`set_product_mark`（POST `{activity_id,key}`）—— `HttpManager.lua:3601-3604`。

    没有 Lua 调用点、也没有注释；参数是"活动 id + 标记 key"。
    真实语义 = 给这个账号在服务端**打一个持久的活动标记**（幂等 upsert），
    这样重装/换设备后标记还在（客户端本地的 dayFlag 会没）。
    """
    aid = _s(ctx.param('activity_id') or (ctx.args[0] if ctx.args else ''))
    key = _s(ctx.param('key') or (ctx.args[1] if len(ctx.args) > 1 else ''))
    if not aid and not key:
        return ctx.fail('参数使用出错',
                        '★ set_product_mark 业务门：activity_id 与 key 都为空')
    marks = st.setdefault('product_marks', {})
    m = marks.get(aid or key)
    if not isinstance(m, dict):
        m = {}
    m.update({'activity_id': aid, 'key': key, 't': _now(), 'uuid': _uuid(ctx)})
    marks[aid or key] = m
    _save(ctx, st)
    return ctx.ok({'activity_id': aid, 'key': key, 'marked': 1},
                  '★ 活动标记已记（activity_id=%s key=%s；服务端持久化，重装也在）' % (aid, key))


# ================================================================ 分发
_HANDLERS = {
    'create_role': _ep_create_role,
    'get_archive_list': _ep_get_archive_list,
    'switch_archive': _ep_switch_archive,
    'get_login_reward_info': _ep_get_login_reward_info,
    'login': _ep_login,
    'get_partition_list': _ep_get_partition_list,
    'switch_partition': lambda ctx, st: _switch_partition(ctx, st, 'switch_partition'),
    'switch_partition2': lambda ctx, st: _switch_partition(ctx, st, 'switch_partition2'),
    'partition_clear': _ep_partition_clear,
    'migrate_to_new_package': lambda ctx, st: _migrate(ctx, st, 'migrate_to_new_package'),
    'migrate_to_new_package2': lambda ctx, st: _migrate(ctx, st, 'migrate_to_new_package2'),
    'login_device_2': _ep_login_device,
    'logout_device_2': _ep_logout_device,
    'get_logoutAccount_url': _ep_logout_account_url,
    'clear_api_data': _ep_clear_api_data,
    'del_all_data': _ep_del_all_data,
    'del_data_by_type': _ep_del_data_by_type,
    'clear_my_shop_record': _ep_clear_my_shop_record,
    'del_activity_cache': _ep_del_activity_cache,
    'clean_voucher_record_2': _ep_clean_voucher_record,
    'delete_bought_intelligence': _ep_delete_bought_intelligence,
    'delete_day_intelligence': _ep_delete_day_intelligence,
    'delete_login_yuanbao_cache': _ep_delete_login_yuanbao_cache,
    'modify_qixi_ctime': _ep_modify_qixi_ctime,
    'up_day_gametime': _ep_up_day_gametime,
    'set_product_mark': _ep_set_product_mark,
    'addSingleRecord': _ep_add_single_record,
}


def handle(ctx):
    fn = _HANDLERS.get(ctx.endpoint)
    if fn is None:
        return None
    st = _state(ctx)
    return fn(ctx, st)
