# -*- coding: utf-8 -*-
# ================= 离线包路径根（fz_make_offline_bundle.py 自动注入） =================
# 手机上整个服务端就是一个目录，表在哪、状态写哪，全部相对包根算。
# （有的模块原来把绝对路径写死，本身没 import os —— 这里一并补上）
import os
import os as _osp


def _off_find_bundle(_f):
    """从模块所在目录往上找包根（认 fz_boot_server.py）。
    ★ fz_api/*.py 的 __file__ 在 <根>/fz_api/ 下，直接 dirname 会算错一层。"""
    _d = _osp.path.dirname(_osp.path.abspath(_f))
    for _ in range(6):
        if _osp.path.exists(_osp.path.join(_d, 'fz_boot_server.py')):
            return _d
        _u = _osp.path.dirname(_d)
        if _u == _d:
            break
        _d = _u
    return _osp.path.dirname(_osp.path.abspath(_f))


_OFF_BUNDLE = _off_find_bundle(__file__)
_OFF_FZ_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_fz')
_OFF_INK_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_ink')
_OFF_WORK_ROOT = _OFF_BUNDLE
# =====================================================================================
# ★ 2026-10-04 商城空货架修复：客户端资源表解析——PC 开发树优先，设备上自动回退
#   到包内 client_fz 副本（jhserver/client_fz = fangzhi_lua_dec 的同步拷贝）。
def _fz_res(*parts):
    base = os.path.join(_OFF_FZ_ROOT, 'res', 'script')
    if not os.path.isdir(base):
        base = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            '..', 'client_fz', 'res', 'script')
    return os.path.join(base, *parts)

# -*- coding: utf-8 -*-
"""地图内买卖与杂项 —— NPC/冥币/美誉/声望/游字令商人、弃兵土堆、龙舟、科举、七夕、
七日应缘、活动积分、行动点、房间扩建、副本重置。

**契约出处（逐个读过她的客户端代码，不是猜的；行号是这一版解密的 lua）**

| 接口(URL 末段) | 上行 | 她读的 `data.字段`（类型） | 出处 |
|---|---|---|---|
| `get_history_weapon` | GET，无参 | **自身是数组**，元素 `{type(数0/1), index(数), data(对象，里面 .data)}`；`for i,v in pairs(data)` + `v.type` + `v.data.data` | `MapLayer.lua:523` |
| `throw_weapon/<type>/<index>` | POST `{data,type,index}` | —（只看 errcode） | `MapAddNpcAndItem.lua:256`(弃兵) `:393`(销毁) |
| `buy_npc_goods` | POST `{client_trans_id,itemId,npc_id,couponsId}` | `remove_point`（**数**，`"你花费了"..data.remove_point..unitName` + `currency[unit].num - tonumber(...)` ⇒ 缺了必崩） | `NpcMapBagLayer.lua:1270` |
| `del_buy_npc_time` | POST `{npc_id,itemId}` | —（只看 errcode） | `MapBagLayer.lua:1865` |
| `buy_mingbi_goods` | POST `{order_id,id}` | —（只看 errcode） | `MapBagLayer.lua:2050` |
| `buy_mask_piece_2` | POST `{order_id,id}` | —（只看 errcode） | `MapBagLayer.lua:1959` |
| `buy_trader_goods` | POST `{npc_id,itemId,client_trans_id,voucher_num}` | —（只看 errcode） | `MapBagLayer.lua:1763` |
| `buy_prestige_goods` | POST `{itemId,client_trans_id,npc_id}` | —（只看 errcode） | `MapBagLayer.lua:2149` |
| `get_prestige_goods` | POST `{npc_id,is_refresh}` | `list`(数组，元素 `{itemId(串),price(数),needSw(数),unit(串)}`；`for k,v in pairs(items)` 后 `v.itemId/v.price/v.needSw/v.unit` 全读) `shengwang`(数) `title`(任意，`self.isHaveTitle = title or false`) `remove`(数) `next_yuanbao`(数) `point`(数) `unit`(串) | `MapBagLayer.lua:1506` / `Chapman.lua:470` |
| `add_currency` | POST `{number,shop_id,type}` | `number`(数) `total_points`(数) | `BaseResults.lua:789` / `FestivalModule.lua:1431` |
| `add_land_gift` | POST `{gifTypt,objId}`（她拼错成 gifTypt） | —（只看 errcode） | `NewYearChuanMenModule.lua:48` |
| `add_npc_record/<npcId>` | GET | `npc_sum`(数) `add_points`(数) | `SpecialModule.lua:68` |
| `check_can_play_boat` | GET | —（只看 errcode） | `SpecialModule.lua:331` |
| `check_whether_exam/<id>` | GET | `id`(数；id=2 殿试时读，喂 `Exam:getPalaceQuestion(id)` ⇒ **必须是 dianshitimu 的键**) | `ExamModule.lua:96` |
| `get_dream_reward_skill` | GET | **自身是数组**，元素是武学 id（`for k,skillId in pairs(data)` → `role:addSkillExp(skillId,1)` ⇒ 每个 id 必须能在 `script.skill.skill["skills"]` 里查到，否则 `Skill:getSkill` 返回 nil ⇒ `skill.name` 抛错被吞 ⇒ 卡死） | `CommonResults.lua:3350` |
| `get_equinox_times` | POST `{type}` | `remove`(数，`if data.remove > 0` 且被 `..` 拼) `num`(数) | `SpecialModule.lua:391` |
| `remove_equinox_point` | POST `{type}` | —（只看 errcode） | `SpecialModule.lua:425` |
| `get_exam_point/<id>` | GET | 省试(id=1)：`flag`(数) `cheat`(数0/1) `rightCount`(数) `time`(数) `rank`(数)；殿试(id=2)：`flag`(数) `point`(数) `time`(数) `rank`(数1~3)。`flag ~= nil` 才开面板 | `ExamModule.lua:74/115` + `ExamScoreLayer.lua:130-220` |
| `check_whether_exam` 见上 | | | |
| `get_qixi_record` | GET | **自身是二维数组**：`for day,day_info in ipairs(data)` → `for _,result_info in ipairs(day_info)` → 读 `result_info.day`(数) `.info`(**串** `"1;左npcId;右npcId;level;textIndex"`) `.ratio`(数)；`info` 里的 npcId 必须能在 `others/xiqi.lua["People"]` 查到（`getNpcInfo(...).name`） | `qixi_2018.lua:159` + `QiXiUtil.lua:902` |
| `get_seventh_reward/1` | GET | `daoju`(对象，可缺 ⇒ 缺了走"背包必够"分支) | `FestivalModule.lua:1030` |
| `get_seventh_reward/2` | GET | `first`(布尔 true 才发奖) `daoju`(对象 `{物品键=数量}`) `shuxing`(对象) `currency`(对象) | `FestivalModule.lua:1045` |
| `get_spend_info/<actionId>` | GET | 自身是**对象**：`data[tostring(档位)]`(数；`== 2` 表示该档可领/已领，`== 0` 可继续充值) | `FestivalModule.lua:2579` |
| `remove_config_point` | POST `{com_config,quantity}` | `yuanbao`(数，LadderLantern 分支 `self.currYuanBao = data.yuanbao`)；`remove`(数，字牌兑换分支 `"花费"..tostring(data.remove).."元宝"`) | `LadderLanternLayer.lua:108` / `FestivalModule.lua:2715` |
| `update_daily_point/<id>` | POST `{point}` | —（只看 errcode） | `CommonResults.lua:1506` |
| `update_user_prestige` | POST `{}` | —（只看 errcode，开本门声望榜） | `EMapResults.lua:1353` |
| `extension_room` | POST `{mid,attr,upload,point}` | —（回调体不读 data；她本地已按 `upload` 建好房间） | `UserMap.lua:610` |
| `refresh_fuben_by_yuanbao` | POST `{map_list}` | `remove_yuanbao`(数，`> 0` 才提示"元宝: -N") | `SelectMapModel.lua:425` |

**内容全从她自己的表来**
  * `res/script/store/shoplist.lua["Sheet1"]`（2228 条，键就是 `GoodsHelper:getGoodsResClass(id)`
    查的那个 id，形如 `"100001"`）—— 所有 `itemId` / `name` / `icon` 的唯一来源；
    买回来的东西一律用 `fz_api/items_currency.py` 的 `IC.add_count` 真进包袱。
  * `res/script/others/storechap.lua["Sheet1"]`（176 条）—— 谁是特殊商人（`npcId` + `isnew`）。
  * `res/script/store/storeConfig.lua["Sheet1"]`（70 个新式商铺：`goodsshelf`/`displaycurrency`/
    `location`/`sell`/`start_time`/`end_time`）—— 新式商店 NPC 与开关时间。
  * `res/script/roleTitle/shengwangtouxian.lua["Sheet1"]`（声望头衔表，`shengwang` 门槛）
  * `res/script/others/xiqi.lua["People"]`（68 个七夕人物，`name`/`day`）—— `get_qixi_record` 的配对。
  * `res/script/dreamworld/dreamskill.lua["武学"]`（324 个）∩ `res/script/skill/skill.lua["skills"]`
    —— `get_dream_reward_skill` 只回**两边都有**的 id（少一边就会在她 `skill.name` 那里炸）。
  * `res/script/newmap/mapReset/mapReset.lua`（10 张可重置副本的 `price`）—— `refresh_fuben_by_yuanbao` 的元宝价。
  * `res/script/exam/exam.lua["dianshitimu"]` / `["shengshi"]` —— 殿试题目 id 与省试榜。
  * **钱和物品**：`fz_api/items_currency.py` 导出的 `IC.get_currency / IC.add_currency /
    IC.get_count / IC.add_count / IC.item_info / IC.goods / IC.canon`。
    本模块**不新造第二份钱**（`IC._purse` 读写的是 `work/homeland_state.json["currency"]`）。

**状态（真写盘 `work/map_shop_state.json`，本模块独占）**
`currency`(活动积分/礼券等按 shop_id 记)、`spent`(action → 已用次数，`remove_config_point`
与 `get_config_times`/`get_spend_info` 共用)、`tang`/`shi`(科举成绩)、`equinox`(龙舟次数)、
`weapons`(剑冢/土堆)、`dead_goods`/`mask_piece`/`trader`/`prestige`(各商人的已购次数与刷新次数)、
`spend_tier`(累充档位领没领)、`qixi`(七夕结果)、`seventh`(七日应缘)、`fuben_reset`(副本章节重置)、
`room_upload`(房间扩建上传表)、`daily_point`。

**已知的取舍 / 还没做到 1:1 的地方（诚实说明，不是拿假数据糊）**
  1. **商店货架不在客户端包里**。她的 `storeConfig.goodsshelf` 是 10000..10069 这种"货架号"，
     在一万多个脚本里都查不到对应的货架内容表（只有服务端数据库有），
     `storechap.lua` 也只给 `{id,isnew,npcId}` 不给货。
     ⇒ `get_prestige_goods` 的 `list` 用了一个**确定性**规则：把 `shoplist` 的键排序后，
     用 `npc_id` 的哈希取一段（同一商人每次拿到的货一样，不会每次刷新变脸）。
     `price`/`needSw` 在她包里也确实没有（客户端只显示服务端给的值），
     本模块把它们取成 `0`（`get_prestige_goods` 返回后她只做展示，`price` 是数字就不崩）。
  2. `buy_*` 系列（冥币/美誉/游字令/声望/元宝商人）的**价格由她服务端数据库掌握**，
     客户端上送时只带 `itemId` 不带价 ⇒ 本模块**只校验物品真实存在 + 记购买次数**，
     金额不走 `IC` 扣（`buy_npc_goods` 例外：她读 `data.remove_point`，回 0 表示"本次没花钱"）。
  3. `get_history_weapon` 回的是**状态里存的土堆/剑冢**（初始为空数组 ⇒ 她面板上是空的），
     不凭空造神兵。`throw_weapon` 真把她上送的 `data.data` 存进去。
  4. `get_spend_info` 的**档位键**取自她 `ConsumeWingLayer` 的累充档位口径
     （10/30/60/100/200/500/1000/2000/5000 元），状态里可改；不接真实充值。
"""
import os
import sys
import time

NAME = 'map_shop'
TITLE = '地图·买卖/冥币/声望/密探/杂项'
ENDPOINTS = [
    # 剑冢 / 弃兵
    'get_history_weapon',
    'throw_weapon',
    # NPC 商人 / 冥币 / 美誉 / 游字令 / 声望商人
    'buy_npc_goods',
    'del_buy_npc_time',
    'buy_mingbi_goods',
    'buy_mask_piece_2',
    'buy_trader_goods',
    'buy_prestige_goods',
    'get_prestige_goods',
    # 活动积分 / 家园礼品 / 制作组记录
    'add_currency',
    'add_land_gift',
    'add_npc_record',
    # 龙舟
    'check_can_play_boat',
    'get_equinox_times',
    'remove_equinox_point',
    # 科举
    'check_whether_exam',
    'get_exam_point',
    # 梦境武学 / 七夕 / 七日应缘 / 累充档位
    'get_dream_reward_skill',
    # ★ `get_qixi_record` **让给 `social_family`**：两边都声明过（`dispatch` 按模块名
    #   排序取第一个 ⇒ `map_shop` 生效、`social_family` 那份变死代码）。
    #   它的消费端是 `models/Action/ChineseValentine/` 的 `QiXiUtil:createResultDataList`，
    #   `social_family` 那份逐字段对过这个契约（按天分页 + `info` 用 `;` 分隔的
    #   `[2]/[3]/[4]/[5]`），比本模块的简版更贴原版 ⇒ 主动撤掉，只留一处实现。
    'get_seventh_reward',
    'get_spend_info',
    # 行动点 / 声望榜 / 房间扩建 / 副本重置
    'remove_config_point',
    'update_daily_point',
    'update_user_prestige',
    'extension_room',
    'refresh_fuben_by_yuanbao',
]

STATE = 'map_shop_state.json'

RES = _fz_res()
P_SHOPLIST = os.path.join(RES, 'store', 'shoplist.lua')
P_STORECHAP = os.path.join(RES, 'others', 'storechap.lua')
P_STORECONF = os.path.join(RES, 'store', 'storeConfig.lua')
P_TOUXIAN = os.path.join(RES, 'roleTitle', 'shengwangtouxian.lua')
P_XIQI = os.path.join(RES, 'others', 'xiqi.lua')
P_DREAMSKILL = os.path.join(RES, 'dreamworld', 'dreamskill.lua')
P_SKILL = os.path.join(RES, 'skill', 'skill.lua')
P_MAPRESET = os.path.join(RES, 'newmap', 'mapReset', 'mapReset.lua')
P_EXAM = os.path.join(RES, 'exam', 'exam.lua')

# ---------------------------------------------------------------------------
# 常量
# ---------------------------------------------------------------------------
# 行动点价的兜底（`get_config_times` 在 misc_systems.py 里用的也是这几个数；
# 真正扣钱在本模块的 `remove_config_point`，两边口径必须一致）
ACTION_COST = {
    'JingMaiChongZhu': 50,
    'refreshFuben': 30,
    'FishingGame': 20,
    'RiverLamp': 20,
    'LadderLantern': 20,
    'YinYangHuHuang': 100,
}
DEFAULT_ACTION_COST = 20

# 龙舟：她客户端写死"每天最多参加 2 次"（`SpecialModule.lua:345 maxTimes = 2`）
BOAT_MAX_TIMES = 2
BOAT_COST_YUANBAO = 20          # 第 2 次起的元宝价（她服务端配置，包里没有）
BOAT_TYPE = 'sailongzhou'

# 声望商人刷新：她包里没有价，按她"每刷新一次涨一档"的语义给个递增价
PRESTIGE_REFRESH_BASE = 20

# 累充档位（她 `ConsumeWingLayer` 的累充口径；`get_spend_info` 的键就是这些）
SPEND_TIERS = ['10', '30', '60', '100', '200', '500', '1000', '2000', '5000']

# 声望商人每次摆几件货（没有货架表，用确定性规则取 shoplist 的一段）
PRESTIGE_SHELF = 8

# 七日应缘：一次给几门"梦境丢失的武学"
SEVENTH_SKILLS = 1

# 科举：乡试答对多少题算过（`ExamScoreLayer.lua:110` 用的就是 60 分）
EXAM_PASS_SCORE = 60

# 副本重置：第 1 次免费，之后按 mapReset 表累计收费
FUBEN_FREE_PER_DAY = 1

_CACHE = {}


# ===========================================================================
# 她自己的表
# ===========================================================================


def _lua(path, *keys):
    """读 `res/script/<...>`；顺着 key 一层层走，失败回空 dict（绝不抛）。"""
    ck = (path, keys)
    if ck in _CACHE:
        return _CACHE[ck]
    val = {}
    try:
        if os.path.dirname(os.path.abspath(__file__)) not in sys.path:
            sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        work = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        if work not in sys.path:
            sys.path.insert(0, work)
        import fz_luatable
        val = fz_luatable.load_lua_table(path)
        for k in keys:
            val = val.get(k) if isinstance(val, dict) else None
            if val is None:
                break
    except Exception:                          # noqa: BLE001
        val = {}
    if not isinstance(val, dict):
        val = {}
    _CACHE[ck] = val
    return val


def _IC():
    """`fz_api/items_currency.py` —— 物品与货币的唯一账本（不在本模块另存一份钱）。"""
    ck = '_IC'
    if ck not in _CACHE:
        try:
            from fz_api import items_currency as IC
        except Exception:                       # noqa: BLE001
            try:
                import importlib
                IC = importlib.import_module('items_currency')
            except Exception:                   # noqa: BLE001
                IC = None
        _CACHE[ck] = IC
    return _CACHE[ck]


def _shop():
    """`store/shoplist.lua["Sheet1"]`（2228 条，键 = 她 `getGoodsResClass` 查的 id）。"""
    ic = _IC()
    if ic is not None:
        try:
            g = ic.goods()
            if g:
                return g
        except Exception:                       # noqa: BLE001
            pass
    return _lua(P_SHOPLIST, 'Sheet1')


def _goods(gid):
    return _shop().get(str(gid)) or {}


def _by_item_id():
    """`itemId` → 商品键（她买回来的东西 `role:addItemCount(itemData.id)` 用的是商品键）。"""
    ck = 'by_iid'
    if ck not in _CACHE:
        ic = _IC()
        if ic is not None:
            try:
                _CACHE[ck] = ic.by_item_id()
                return _CACHE[ck]
            except Exception:                   # noqa: BLE001
                pass
        m = {}
        for gid, g in _shop().items():
            if isinstance(g, dict) and g.get('itemId'):
                m.setdefault(str(g['itemId']), str(gid))
        _CACHE[ck] = m
    return _CACHE[ck]


def _canon(key):
    """任意物品标识 → 商品键（有商品号用商品键，否则原样）。"""
    s = _s(key)
    if not s:
        return ''
    if s in _shop():
        return s
    return _by_item_id().get(s, s)


def _sorted_keys():
    ck = 'shopkeys'
    if ck not in _CACHE:
        _CACHE[ck] = sorted(str(k) for k in _shop().keys())
    return _CACHE[ck]


def _storechap():
    return _lua(P_STORECHAP, 'Sheet1')


def _storeconf():
    return _lua(P_STORECONF, 'Sheet1')


def _is_chapman(npc_id):
    """她 `Chapman:checkIsChapman/ForNew` 用的是 storechap 的 `npcId`。"""
    n = _s(npc_id)
    if not n:
        return False
    for v in _storechap().values():
        if isinstance(v, dict) and _s(v.get('npcId')) == n:
            return True
    return n in _storeconf()


def _s(v):
    if v is None:
        return ''
    if isinstance(v, str):
        return v.strip()
    return str(v)


def _num(v, d=0):
    try:
        if v is None or v == '':
            return int(d)
        return int(float(v))
    except (TypeError, ValueError):
        return int(d)


def _bool(v):
    if isinstance(v, bool):
        return v
    if isinstance(v, str):
        return v.strip().lower() in ('1', 'true', 'yes', 'y', 't')
    return bool(v)


def _clip(v, maxlen):
    """她有些文本直接 `..` 拼进 C++ 字符串 —— 太长的中文串有崩的风险，截一刀。"""
    s = v if isinstance(v, str) else _s(v)
    return s[:maxlen] if len(s) > maxlen else s


# ===========================================================================
# 状态（`work/map_shop_state.json`）
# ===========================================================================
def _blank():
    return {
        'spent': {},            # action → 已用次数（与 misc_systems 的 get_config_times 同口径）
        'currency': {},         # shop_id(活动) → 已有积分/礼券
        'weapons': [],          # 剑冢/土堆：[{index,type,data}]
        'weapon_seq': 0,
        'thrown': {},           # weapon 序号 → 弃置方式
        'dead_goods': {},       # 冥币商人：itemId → 次数
        'mask_piece': {},       # 美誉商人：itemId → 次数
        'trader': {},           # 游字令商人：npc_id|itemId → 次数
        'npc_goods': {},        # 新式 NPC 商人：npc_id|itemId → 次数
        'npc_time': {},         # del_buy_npc_time 扣掉的购买次数
        'prestige': {},         # npc_id → {items:[...], refresh:次数}
        'land_gift': {},        # 新春摆放礼品：giftType → 次数
        'npc_record': {},       # npcId → 今日完成次数
        'equinox': {},          # 龙舟 type → {day,n}
        'exam': {},             # '1'/'2' → 成绩 dict
        'qixi': [],             # 七夕结果（二维数组）
        'seventh': {'done': 0, 'day': ''},
        'spend_tier': {},       # 累充档位 → 0/1/2
        'fuben_reset': {'day': '', 'n': 0},
        'room_upload': [],
        'daily_point': {},
        'log': [],
    }


def _st(ctx):
    st = ctx.load_json(STATE, None)
    if not isinstance(st, dict):
        st = {}
    base = _blank()
    for k, v in base.items():
        if k not in st or st[k] is None:
            st[k] = v
    for k in ('spent', 'currency', 'thrown', 'dead_goods', 'mask_piece', 'trader',
              'npc_goods', 'npc_time', 'prestige', 'land_gift', 'npc_record',
              'equinox', 'exam', 'spend_tier', 'daily_point'):
        if not isinstance(st.get(k), dict):
            st[k] = {}
    for k in ('weapons', 'qixi', 'room_upload'):
        if not isinstance(st.get(k), list):
            st[k] = []
    if not isinstance(st.get('seventh'), dict):
        st['seventh'] = {'done': 0, 'day': ''}
    if not isinstance(st.get('fuben_reset'), dict):
        st['fuben_reset'] = {'day': '', 'n': 0}
    if not isinstance(st.get('log'), list):
        st['log'] = []
    return st


def _save(ctx, st):
    st['log'] = (st.get('log') or [])[-100:]
    st['userid'] = _uid(ctx)
    st['updated'] = int(time.time())
    ctx.save_json(STATE, st)
    return st


def _mark(st, who, msg):
    st.setdefault('log', []).append('%d %s %s' % (int(time.time()), who, msg))


def _uid(ctx):
    return str(ctx.headers.get('userid') or ctx.headers.get('uuid') or 'local')


def _today():
    return time.strftime('%Y%m%d')


def _purse_get(ctx, kind):
    ic = _IC()
    if ic is None:
        return 0
    try:
        return _num(ic.get_currency(ctx, kind))
    except Exception:                           # noqa: BLE001
        return 0


def _purse_add(ctx, kind, n):
    """真扣/真加（`None` = 不够，且一点都不改）。"""
    ic = _IC()
    if ic is None:
        return None
    try:
        return ic.add_currency(ctx, kind, int(n))
    except Exception:                           # noqa: BLE001
        return None


def _grant(ctx, key, n=1):
    """把物品真放进她的包袱（键用商品键）。"""
    ic = _IC()
    if ic is None:
        return None
    try:
        return ic.add_count(ctx, _canon(key) or key, abs(_num(n, 1)) or 1)
    except Exception:                           # noqa: BLE001
        return None


def _have(ctx, key):
    ic = _IC()
    if ic is None:
        return 10 ** 9                            # 没有物品模块就一律放行
    try:
        return _num(ic.get_count(ctx, _canon(key) or key))
    except Exception:                             # noqa: BLE001
        return 0


def _yes(v):
    return _s(v).upper() in ('Y', 'YES', '1', 'TRUE')


def _as_list(v):
    """把"应该是数组"的上行参数拉成 list。

    真客户端发的是 JSON 数组；但 `/__probe/` 那种 `?a=1&b=2` 的查询串会把它变成**字符串**
    （`upload=[[...]]` / `map_list=["fb48"]`）⇒ 这里顺手把 JSON 串解开，
    否则模块在探针里永远走"空数组"分支、验不到真路径。
    """
    if isinstance(v, (list, tuple)):
        return list(v)
    if isinstance(v, str) and v.strip().startswith('['):
        try:
            import json
            got = json.loads(v)
            if isinstance(got, list):
                return got
        except Exception:                       # noqa: BLE001
            pass
    return []


# ===========================================================================
# 她包里的派生清单
# ===========================================================================
def _shengwang_titles():
    """`roleTitle/shengwangtouxian.lua["Sheet1"]` —— 声望门槛（`shengwang` 字段）。"""
    return _lua(P_TOUXIAN, 'Sheet1')


def _xiqi_people():
    """`others/xiqi.lua["People"]`（68 个七夕人物）。"""
    return _lua(P_XIQI, 'People')


def _xiqi_final():
    """`others/xiqi.lua["final"]` —— `QiXiUtil:getResultDesc(level,textIndex)` 取的就是它。"""
    return _lua(P_XIQI, 'final')


def _dream_skills():
    """`dreamskill["武学"]` ∩ `skill["skills"]` —— **两边都有**的才算合法武学 id。"""
    ck = 'dreamsk'
    if ck not in _CACHE:
        dream = _lua(P_DREAMSKILL, '武学')
        skill = _lua(P_SKILL, 'skills')
        both = [str(k) for k in dream.keys() if k in skill]
        both.sort()
        _CACHE[ck] = both
    return _CACHE[ck]


def _map_reset():
    """`newmap/mapReset/mapReset.lua` —— 可重置副本的元宝价（顶层表，没有 sheet）。"""
    return _lua(P_MAPRESET)


def _palace_questions():
    """`exam.lua["dianshitimu"]`（8 道殿试题，键 1..8）。"""
    return _lua(P_EXAM, 'dianshitimu')


def _exam_answers():
    """`exam.lua["shengshi"]`（42 题省试，用来给省试榜一个真名次基数）。"""
    return _lua(P_EXAM, 'shengshi')


def _prestige_shelf(npc_id):
    """声望商人的货：没有货架表 ⇒ 用 npc_id 哈希在 shoplist 里取一段（同商人固定不变）。"""
    ck = ('shelf', npc_id)
    if ck in _CACHE:
        return _CACHE[ck]
    keys = _sorted_keys()
    out = []
    if keys:
        seed = 0
        for ch in _s(npc_id) or 'shengwang':
            seed = (seed * 131 + ord(ch)) & 0x7FFFFFFF
        start = seed % len(keys)
        for i in range(PRESTIGE_SHELF):
            k = keys[(start + i) % len(keys)]
            g = _goods(k)
            if not isinstance(g, dict) or not g.get('itemId'):
                continue
            out.append({
                'id': k,                      # 商品键（她 GoodsHelper 查的就是它）
                'itemId': _s(g.get('itemId')),
                'name': _clip(_s(g.get('name')), 20),
                'price': 0,                   # 她包里没有价（服务端数据库才有）⇒ 只做展示
                'needSw': 0,
                'unit': 'gongxiandian',       # `getPrestigeChapmanStoreList` 里写死贡献点
            })
    _CACHE[ck] = out
    return out


def _npc_seller_list(npc_id):
    """NPC 商人（`buy_npc_goods` 那一套）的货：同样没有货架表 ⇒ 确定性取一段。"""
    ck = ('npcgoods', npc_id)
    if ck in _CACHE:
        return _CACHE[ck]
    keys = _sorted_keys()
    out = []
    if keys:
        seed = 7
        for ch in _s(npc_id) or 'npc':
            seed = (seed * 137 + ord(ch)) & 0x7FFFFFFF
        start = seed % len(keys)
        for i in range(PRESTIGE_SHELF):
            k = keys[(start + i) % len(keys)]
            g = _goods(k)
            if not isinstance(g, dict) or not g.get('itemId'):
                continue
            out.append({
                'id': k,
                'itemId': _s(g.get('itemId')),
                'name': _s(g.get('name')),
                'is_buy_time': 999,
                'is_buy': 'Y',
                'price': 0,
                'priceUnit': 'money',
                'unit': 'money',
            })
    _CACHE[ck] = out
    return out


# ===========================================================================
# 处理
# ===========================================================================
def handle(ctx):
    ep = ctx.endpoint
    st = _st(ctx)

    # ------------------------------------------------------------------ 剑冢 / 弃兵
    if ep == 'get_history_weapon':
        # ★ 她 `for i,v in pairs(data)` 直接读数组自身（不是 data.list）
        arr = []
        for it in st.get('weapons') or []:
            if not isinstance(it, dict):
                continue
            arr.append({
                'index': _num(it.get('index'), 1),
                'type': _num(it.get('type')),          # 0 土堆 / 1 剑冢
                'data': {'data': it.get('data') or {}},
            })
        return ctx.ok(arr, '★ 剑冢土堆（%d 座）' % len(arr))

    if ep == 'throw_weapon':
        wtype = _num(ctx.args[0] if ctx.args else 1, 1)      # 1 埋 2 弃 3 销毁
        index = _num(ctx.args[1] if len(ctx.args) > 1 else 1, 1)
        body = ctx.body_obj or {}
        payload = body.get('data') or ctx.param('data') or {}
        st['weapon_seq'] = _num(st.get('weapon_seq')) + 1
        st.setdefault('weapons', []).append({
            'index': index,
            'type': 0 if wtype == 1 else 1,               # 埋 → 土堆(0)，弃/销毁 → 剑冢(1)
            'data': {'data': payload},
        })
        st.setdefault('thrown', {})[str(st['weapon_seq'])] = wtype
        _mark(st, 'throw_weapon', 'type=%s index=%s' % (wtype, index))
        _save(ctx, st)
        ctx.log('[地图买卖] 弃兵 type=%s index=%s' % (wtype, index))
        return ctx.ok({'msg': ''}, '★ 弃兵/埋剑（第 %d 座）' % st['weapon_seq'])

    # ------------------------------------------------------------------ NPC 商人（新式）
    if ep == 'buy_npc_goods':
        item = _s(ctx.param('itemId'))
        npc = _s(ctx.param('npc_id'))
        coupons = _s(ctx.param('couponsId'))
        key = _canon(item)
        g = _goods(key)
        if not isinstance(g, dict) or not g.get('itemId'):
            return ctx.fail('商人没有这件货', '★ NPC 商人：shoplist 里没有 itemId=%s' % item)
        # 她读 `data.remove_point`（数字）拼进弹出文本并做减法 ⇒ 必须给数字
        cost = 0
        for row in _npc_seller_list(npc):
            if _s(row.get('itemId')) == _s(g.get('itemId')):
                cost = _num(row.get('price'))
                break
        mark = '%s|%s' % (npc, g.get('itemId'))
        st.setdefault('npc_goods', {})[mark] = _num(st['npc_goods'].get(mark)) + 1
        _grant(ctx, key, 1)
        if coupons:
            st.setdefault('npc_time', {})['coupon:' + coupons] = _num(
                st['npc_time'].get('coupon:' + coupons)) + 1
        _mark(st, 'buy_npc_goods', '%s ← %s(%s) cost=%s' % (npc, g.get('name'), key, cost))
        _save(ctx, st)
        ctx.log('[地图买卖] NPC 商人 %s 买 %s（%s）' % (npc, g.get('name'), key))
        return ctx.ok({'remove_point': cost, 'itemId': _s(g.get('itemId'))},
                      '★ NPC 商人购买《%s》' % _s(g.get('name')))

    if ep == 'del_buy_npc_time':
        # 她 `addChapmanItemCount(npcId,itemId)`：碎银购买走的就是这个（价格她本地算）
        item = _s(ctx.param('itemId'))
        npc = _s(ctx.param('npc_id'))
        key = _canon(item)
        g = _goods(key)
        if not isinstance(g, dict) or not g.get('itemId'):
            return ctx.fail('商人没有这件货', '★ 扣购买次数：shoplist 里没有 itemId=%s' % item)
        mark = '%s|%s' % (npc, g.get('itemId'))
        st.setdefault('npc_time', {})[mark] = _num(st['npc_time'].get(mark)) + 1
        _grant(ctx, key, 1)
        _mark(st, 'del_buy_npc_time', '%s %s' % (npc, key))
        _save(ctx, st)
        return ctx.ok({'left': 0, 'itemId': _s(g.get('itemId'))},
                      '★ 商人碎银购买《%s》' % _s(g.get('name')))

    # ------------------------------------------------------------------ 冥币商人
    if ep == 'buy_mingbi_goods':
        item = _s(ctx.param('id') or ctx.param('itemId'))
        key = _canon(item)
        g = _goods(key)
        if not isinstance(g, dict) or not g.get('itemId'):
            return ctx.fail('冥币商人的货架上没有这件东西',
                            '★ 冥币商人：shoplist 里没有 id=%s' % item)
        ic = _IC()
        have = _num(ic.get_currency(ctx, 'mingbi')) if ic is not None else 0
        need = 1
        if have < need:
            return ctx.fail('冥币不足', '★ 冥币商人：冥币 %d < %d' % (have, need))
        if ic is not None:
            try:
                left = ic.add_currency(ctx, 'mingbi', -need)
                if left is None:
                    return ctx.fail('冥币不足', '★ 冥币商人：冥币不够')
            except Exception:                     # noqa: BLE001
                pass
        _grant(ctx, key, 1)
        st.setdefault('dead_goods', {})[_s(g.get('itemId'))] = _num(
            st['dead_goods'].get(_s(g.get('itemId')))) + 1
        _mark(st, 'buy_mingbi_goods', '%s -%d 冥币' % (key, need))
        _save(ctx, st)
        ctx.log('[地图买卖] 冥币购买《%s》' % _s(g.get('name')))
        return ctx.ok({'left_mingbi': _purse_get(ctx, 'mingbi')},
                      '★ 冥币购买《%s》' % _s(g.get('name')))

    # ------------------------------------------------------------------ 美誉商人（面具碎片）
    if ep == 'buy_mask_piece_2':
        item = _s(ctx.param('id') or ctx.param('itemId'))
        key = _canon(item)
        g = _goods(key)
        if not isinstance(g, dict) or not g.get('itemId'):
            return ctx.fail('美誉商人的货架上没有这件东西',
                            '★ 美誉商人：shoplist 里没有 id=%s' % item)
        ic = _IC()
        have = _num(ic.get_currency(ctx, 'meiyu')) if ic is not None else 0
        need = 1
        if have < need:
            return ctx.fail('江湖美誉不足', '★ 美誉商人：美誉 %d < %d' % (have, need))
        if ic is not None:
            try:
                if ic.add_currency(ctx, 'meiyu', -need) is None:
                    return ctx.fail('江湖美誉不足', '★ 美誉商人：美誉不够')
            except Exception:                     # noqa: BLE001
                pass
        _grant(ctx, key, 1)
        st.setdefault('mask_piece', {})[_s(g.get('itemId'))] = _num(
            st['mask_piece'].get(_s(g.get('itemId')))) + 1
        _mark(st, 'buy_mask_piece_2', '%s -%d 美誉' % (key, need))
        _save(ctx, st)
        return ctx.ok({'meiyu': _purse_get(ctx, 'meiyu')},
                      '★ 美誉购买《%s》' % _s(g.get('name')))

    # ------------------------------------------------------------------ 游字令商人
    if ep == 'buy_trader_goods':
        item = _s(ctx.param('itemId') or ctx.param('id'))
        npc = _s(ctx.param('npc_id'))
        voucher = abs(_num(ctx.param('voucher_num'), 0))
        key = _canon(item)
        g = _goods(key)
        if not isinstance(g, dict) or not g.get('itemId'):
            return ctx.fail('杂货商没有这件货', '★ 游字令商人：shoplist 里没有 itemId=%s' % item)
        ic = _IC()
        have = _num(ic.get_currency(ctx, 'jiaozi')) if ic is not None else 0
        if voucher > 0 and have < voucher:
            return ctx.fail('游字令不足', '★ 游字令商人：游字令 %d < %d' % (have, voucher))
        if ic is not None and voucher > 0:
            try:
                if ic.add_currency(ctx, 'jiaozi', -voucher) is None:
                    return ctx.fail('游字令不足', '★ 游字令商人：游字令不够')
            except Exception:                     # noqa: BLE001
                pass
        _grant(ctx, key, 1)
        mark = '%s|%s' % (npc, g.get('itemId'))
        st.setdefault('trader', {})[mark] = _num(st['trader'].get(mark)) + 1
        _mark(st, 'buy_trader_goods', '%s ← %s 券 %d' % (npc, key, voucher))
        _save(ctx, st)
        return ctx.ok({'jiaozi': _purse_get(ctx, 'jiaozi'), 'voucher_num': voucher},
                      '★ 游字令购买《%s》' % _s(g.get('name')))

    # ------------------------------------------------------------------ 声望商人
    if ep == 'get_prestige_goods':
        npc = _s(ctx.param('npc_id'))
        is_refresh = _yes(ctx.param('is_refresh'))
        slot = st.setdefault('prestige', {}).get(npc)
        if not isinstance(slot, dict) or not slot.get('items') or is_refresh:
            items = _prestige_shelf(npc)
            slot = {'items': items, 'refresh': _num((slot or {}).get('refresh'))}
            if is_refresh:
                cost = PRESTIGE_REFRESH_BASE * (slot['refresh'] + 1)
                if _purse_get(ctx, 'yuanbao') < cost:
                    return ctx.fail('元宝不足', '★ 声望商人刷新：元宝 %d < %d'
                                    % (_purse_get(ctx, 'yuanbao'), cost))
                left = _purse_add(ctx, 'yuanbao', -cost)
                if left is None:
                    return ctx.fail('元宝不足', '★ 声望商人刷新：元宝不够')
                slot['refresh'] += 1
                _mark(st, 'prestige_refresh', '%s -%d 元宝' % (npc, cost))
            st['prestige'][npc] = slot
            _save(ctx, st)
        items = slot.get('items') or []
        next_yuanbao = PRESTIGE_REFRESH_BASE * (_num(slot.get('refresh')) + 1)
        # 声望：从她头衔表里按当前档位取一个真门槛（给面板显示"当前师门声望"）
        titles = _shengwang_titles()
        shengwang = 0
        for v in titles.values():
            if isinstance(v, dict):
                shengwang = max(shengwang, _num(v.get('shengwang')))
        data = {
            'list': items,                          # 数组，元素 {itemId,price,needSw,unit,...}
            'shengwang': shengwang,                 # 数字（她 setCurrPrestigeInfo 直接用）
            'title': '广结善缘',                     # 任意真值 ⇒ 走 7.5 折分支（她 `title or false`）
            'remove': PRESTIGE_REFRESH_BASE * _num(slot.get('refresh')),
            'next_yuanbao': next_yuanbao,
            'point': _purse_get(ctx, 'gongxiandian'),
            'unit': 'gongxiandian',
        }
        return ctx.ok(data, '★ 声望商人货架（%d 件，刷新 %d 次）' % (len(items), _num(slot.get('refresh'))))

    if ep == 'buy_prestige_goods':
        item = _s(ctx.param('itemId') or ctx.param('id'))
        npc = _s(ctx.param('npc_id'))
        key = _canon(item)
        g = _goods(key)
        if not isinstance(g, dict) or not g.get('itemId'):
            return ctx.fail('声望商人没有这件货',
                            '★ 声望购买：shoplist 里没有 itemId=%s' % item)
        slot = st.setdefault('prestige', {}).get(npc) or {}
        row = None
        for it in (slot.get('items') or []):
            if _s(it.get('itemId')) == _s(g.get('itemId')):
                row = it
                break
        if row is None and (slot.get('items')):
            return ctx.fail('声望商人今天没有摆这件货',
                            '★ 声望购买：%s 不在 %s 的货架上' % (g.get('itemId'), npc))
        need = _num((row or {}).get('price'))
        ic = _IC()
        have = _num(ic.get_currency(ctx, 'gongxiandian')) if ic is not None else 0
        if need > 0 and have < need:
            return ctx.fail('师门贡献点不足', '★ 声望购买：贡献点 %d < %d' % (have, need))
        if ic is not None and need > 0:
            try:
                if ic.add_currency(ctx, 'gongxiandian', -need) is None:
                    return ctx.fail('师门贡献点不足', '★ 声望购买：贡献点不够')
            except Exception:                     # noqa: BLE001
                pass
        _grant(ctx, key, 1)
        _mark(st, 'buy_prestige_goods', '%s ← %s' % (npc, key))
        _save(ctx, st)
        return ctx.ok({'point': _purse_get(ctx, 'gongxiandian')},
                      '★ 声望购买《%s》' % _s(g.get('name')))

    # ------------------------------------------------------------------ 活动积分 / 礼券
    if ep == 'add_currency':
        number = _num(ctx.param('number'), 0)
        shop_id = _s(ctx.param('shop_id')) or 'zhounianqin_jf'
        ck = st.setdefault('currency', {})
        total = _num(ck.get(shop_id)) + number
        ck[shop_id] = total
        _mark(st, 'add_currency', '%s %+d → %d' % (shop_id, number, total))
        _save(ctx, st)
        ctx.log('[地图买卖] 活动积分 %s %+d → %d' % (shop_id, number, total))
        # 她读 data.number（>0 才弹提示）与 data.total_points（`..` 拼串）
        return ctx.ok({'number': number, 'total_points': total, 'shop_id': shop_id},
                      '★ 活动积分 %s %+d（现有 %d）' % (shop_id, number, total))

    if ep == 'add_land_gift':
        gift = _num(ctx.param('gifTypt') or ctx.param('gift_type') or ctx.param('giftType'), 0)
        obj = _s(ctx.param('objId'))
        cost = {1: 280000, 2: 50}.get(gift)
        unit = {1: 'money', 2: 'yuanbao'}.get(gift)
        if cost and unit:
            left = _purse_add(ctx, unit, -cost)
            if left is None:
                return ctx.fail('碎银不足' if unit == 'money' else '元宝不足',
                                '★ 摆放礼品：%s 不够（要 %d）' % (unit, cost))
        st.setdefault('land_gift', {})[str(gift)] = _num(st['land_gift'].get(str(gift))) + 1
        _mark(st, 'add_land_gift', 'gift=%s obj=%s' % (gift, obj))
        _save(ctx, st)
        remaining = {1: 'money', 2: 'yuanbao'}.get(gift)
        return ctx.ok({'money': _purse_get(ctx, 'money'),
                       'yuanbao': _purse_get(ctx, 'yuanbao'),
                       'left': _purse_get(ctx, remaining) if remaining else 0},
                      '★ 摆放新春礼品（类型 %d）' % gift)

    if ep == 'add_npc_record':
        npc = _s(ctx.args[0] if ctx.args else ctx.param('npc_id'))
        day = st.setdefault('npc_record', {})
        rec = day.get(npc)
        if not isinstance(rec, dict) or rec.get('day') != _today():
            rec = {'day': _today(), 'sum': 0}
        rec['sum'] = _num(rec.get('sum')) + 1
        day[npc] = rec
        add_points = 0
        if rec['sum'] == 1:
            add_points = 10                     # 每日首次完成给江湖美誉（她 `data.add_points`）
            _purse_add(ctx, 'meiyu', add_points)
        _save(ctx, st)
        ctx.log('[地图买卖] 制作组副本 %s 今日第 %d 次' % (npc, rec['sum']))
        # 她读 data.npc_sum（==1 才发首胜奖励）与 data.add_points（>0 才弹提示）
        return ctx.ok({'npc_sum': rec['sum'], 'add_points': add_points, 'npc_id': npc},
                      '★ 制作组副本记录 %s 第 %d 次' % (npc, rec['sum']))

    # ------------------------------------------------------------------ 龙舟
    if ep == 'check_can_play_boat':
        rec = st.setdefault('equinox', {}).get(BOAT_TYPE) or {}
        n = _num(rec.get('n')) if rec.get('day') == _today() else 0
        ok = n < BOAT_MAX_TIMES
        return ctx.ok({'can_join': 1 if ok else 0,
                       'num': n,
                       'max': BOAT_MAX_TIMES,
                       'remove': 0 if n == 0 else BOAT_COST_YUANBAO},
                      '★ 赛龙舟资格（今日已 %d/%d 次，%s）'
                      % (n, BOAT_MAX_TIMES, '可参加' if ok else '次数已满'))

    if ep == 'get_equinox_times':
        typ = _s(ctx.param('type')) or BOAT_TYPE
        rec = st.setdefault('equinox', {}).get(typ) or {}
        n = _num(rec.get('n')) if rec.get('day') == _today() else 0
        # 她：`if data.remove > 0` 且 `..` 拼 ⇒ 必须是数字
        remove = 0 if n == 0 else BOAT_COST_YUANBAO
        return ctx.ok({'remove': remove, 'num': n, 'type': typ, 'max': BOAT_MAX_TIMES},
                      '★ 活动次数 %s（已 %d 次，本次 %d 元宝）' % (typ, n, remove))

    if ep == 'remove_equinox_point':
        typ = _s(ctx.param('type')) or BOAT_TYPE
        rec = st.setdefault('equinox', {}).get(typ)
        if not isinstance(rec, dict) or rec.get('day') != _today():
            rec = {'day': _today(), 'n': 0}
        if _num(rec.get('n')) >= BOAT_MAX_TIMES:
            return ctx.fail('今日次数已用完', '★ 消耗活动次数 %s：已 %d/%d'
                            % (typ, _num(rec.get('n')), BOAT_MAX_TIMES))
        cost = 0 if _num(rec.get('n')) == 0 else BOAT_COST_YUANBAO
        if cost:
            if _purse_add(ctx, 'yuanbao', -cost) is None:
                return ctx.fail('元宝不足', '★ 消耗活动次数 %s：元宝不够（要 %d）' % (typ, cost))
        rec['n'] = _num(rec.get('n')) + 1
        st['equinox'][typ] = rec
        _mark(st, 'remove_equinox_point', '%s 第 %d 次 -%d 元宝' % (typ, rec['n'], cost))
        _save(ctx, st)
        ctx.log('[地图买卖] %s 消耗一次机会（第 %d 次）' % (typ, rec['n']))
        return ctx.ok({'num': rec['n'], 'remove': cost, 'max': BOAT_MAX_TIMES,
                       'yuanbao': _purse_get(ctx, 'yuanbao')},
                      '★ 参加%s（今日第 %d 次）' % (typ, rec['n']))

    # ------------------------------------------------------------------ 科举
    if ep == 'check_whether_exam':
        eid = _num(ctx.args[0] if ctx.args else ctx.param('id'), 0)
        rec = (st.get('exam') or {}).get(str(eid)) or {}
        if not isinstance(rec, dict):
            rec = {}
        if eid == 2:
            qs = _palace_questions()
            qid = _num(rec.get('subject')) or (min(_num(k) for k in qs.keys()) if qs else 1)
            # 她 `data and data.id` → `PalaceExamEntranceLayer:showLayer(data.id)` →
            #   `Exam:getPalaceQuestion(id).question` ⇒ id 必须是 dianshitimu 的键
            return ctx.ok({'id': qid, 'can_exam': 1},
                          '★ 殿试资格（题目 id=%s）' % qid)
        # 乡试(0)/省试(1)：只判 errcode，她本地用 timeLimitFlag 判"本周考过没"
        left = 1
        return ctx.ok({'can_exam': left, 'id': eid},
                      '★ 科举资格（第 %d 级）' % eid)

    if ep == 'get_exam_point':
        eid = _num(ctx.args[0] if ctx.args else ctx.param('id'), 0)
        rec = (st.get('exam') or {}).get(str(eid)) or {}
        if not isinstance(rec, dict) or not rec:
            return ctx.ok({}, '★ 科举成绩（第 %d 级：还没有成绩）' % eid)
        data = {}
        if eid == 1:
            # 她 `self.examData.rightCount / time / rank / flag / cheat`
            data = {
                'flag': _num(rec.get('flag')),
                'cheat': _num(rec.get('cheat')),
                'rightCount': _num(rec.get('rightCount')),
                'time': _num(rec.get('time')),
                'rank': _num(rec.get('rank'), 1),
                'point': _num(rec.get('point')),
                'msg': _s(rec.get('msg')),
            }
        else:
            data = {
                'flag': _num(rec.get('flag')),
                'point': _num(rec.get('point')),
                'time': _num(rec.get('time')),
                'rank': _num(rec.get('rank'), 1),
                'cheat': _num(rec.get('cheat')),
                'msg': _s(rec.get('msg')),
            }
        return ctx.ok(data, '★ 科举成绩（第 %d 级，名次 %s）' % (eid, data.get('rank')))

    # ------------------------------------------------------------------ 梦境丢失武学
    if ep == 'get_dream_reward_skill':
        # ★ 自身是数组；元素必须是 `skill.lua["skills"]` 里有的武学 id，否则她 `skill.name` 抛错
        pool = _dream_skills()
        arr = pool[:SEVENTH_SKILLS]
        return ctx.ok(arr, '★ 梦境丢失武学（%d 门）' % len(arr))

    # ------------------------------------------------------------------ 七夕结果
    if ep == 'get_qixi_record':
        people = _xiqi_people()
        final = _xiqi_final()
        # 状态里有就回状态里的（她 `createResultDataList` 认二维数组）
        rec = st.get('qixi')
        if not isinstance(rec, list) or not rec:
            rec = _build_qixi(people, final)
            st['qixi'] = rec
            _save(ctx, st)
        if not rec:
            return ctx.ok({}, '★ 七夕结果（还没有可查看的配对）')
        return ctx.ok(rec, '★ 七夕结果（%d 天）' % len(rec))

    # ------------------------------------------------------------------ 七日应缘
    if ep == 'get_seventh_reward':
        sub = ctx.args[0] if ctx.args else ''
        if str(sub) == '1':
            # 只是"背包够不够"的预检：她 `if data.daoju then checkCanBuyTwoOrMoreThings(data.daoju)`。
            # 给空对象 ⇒ `MapIsEmpty` 为真 ⇒ 直接放行（给个她背包装不下的货会让整个应缘卡住）。
            return ctx.ok({}, '★ 七日应缘预检（背包必够）')
        # /2 真发奖
        done = _num(st.get('seventh', {}).get('done')) if isinstance(st.get('seventh'), dict) else 0
        if done > 0:
            return ctx.fail('你还没有祈福七次，没有奖励可以领取',
                            '★ 七日应缘：已领过（%d）' % done)
        pool = _dream_skills()
        daoju = {}
        for k in pool[:SEVENTH_SKILLS]:
            daoju[_canon(k)] = 1
            _grant(ctx, k, 1)
        st['seventh'] = {'done': 1, 'day': _today()}
        _mark(st, 'seventh', '发奖 %s' % daoju)
        _save(ctx, st)
        # 她读 data.first（布尔；true 才进发奖分支）、data.daoju / data.shuxing / data.currency（对象）
        return ctx.ok({'first': True, 'daoju': daoju, 'shuxing': {}, 'currency': {},
                       'msg': ''},
                      '★ 七日应缘（%d 件）' % len(daoju))

    # ------------------------------------------------------------------ 累充档位
    if ep == 'get_spend_info':
        action = _s(ctx.args[0] if ctx.args else ctx.param('actionId')) or 'totalPay1'
        if action != 'totalPay1':
            # 别的档位（yuanbaoxiaohao / dailyPay2 …）她只用自己的面板，这里给空对象即安全
            return ctx.ok({}, '★ 累充档位 %s（本模块只管 totalPay1）' % action)
        tiers = st.setdefault('spend_tier', {})
        out = {}
        for t in SPEND_TIERS:
            v = tiers.get(t)
            out[t] = _num(v) if v is not None else 0
        return ctx.ok(out, '★ 累充档位（%d 档）' % len(out))

    # ------------------------------------------------------------------ 行动点（买次数/字牌）
    if ep == 'remove_config_point':
        action = _s(ctx.param('com_config') or ctx.param('action'))
        qty = abs(_num(ctx.param('quantity'), 1)) or 1
        if not action:
            return ctx.fail('参数不全', '★ 扣除行动点：没带 com_config')
        used = _num((st.get('spent') or {}).get(action))
        # 她 `submitAction` 是"**再买一次**"（`LadderLanternLayer:88-101` 已经确认过元宝够、
        # `FestivalModule:2715` 已经弹过"花费N元宝兑换X"）⇒ 每一次都按单价真扣，
        # 不像 `get_config_times` 那样第一次免费。
        unit_price = ACTION_COST.get(action, DEFAULT_ACTION_COST)
        total = unit_price * qty
        if total:
            left = _purse_add(ctx, 'yuanbao', -total)
            if left is None:
                return ctx.fail('元宝不足，我这不能赊账呢。',
                                '★ 扣除行动点 %s：元宝不够（要 %d）' % (action, total))
        st.setdefault('spent', {})[action] = used + qty
        _mark(st, 'remove_config_point', '%s ×%d -%d 元宝' % (action, qty, total))
        _save(ctx, st)
        ctx.log('[地图买卖] 扣除行动点 %s ×%d（%d 元宝）' % (action, qty, total))
        # LadderLantern 读 data.yuanbao；字牌兑换读 data.remove（>0 才提示）
        return ctx.ok({'yuanbao': _purse_get(ctx, 'yuanbao'),
                       'remove': unit_price,
                       'num': st['spent'][action],
                       'money': _purse_get(ctx, 'money')},
                      '★ %s ×%d（扣 %d 元宝）' % (action, qty, total))

    if ep == 'update_daily_point':
        pid = _s(ctx.args[0] if ctx.args else ctx.param('id')) or '0'
        point = _num(ctx.param('point'))
        dp = st.setdefault('daily_point', {})
        dp[pid] = _num(dp.get(pid)) + point
        _save(ctx, st)
        ctx.log('[地图买卖] 每日积分 %s %+d → %d' % (pid, point, dp[pid]))
        return ctx.ok({'point': dp[pid], 'id': pid},
                      '★ 每日积分 %s %+d' % (pid, point))

    # ------------------------------------------------------------------ 声望榜
    if ep == 'update_user_prestige':
        # 她只看 errcode，然后开 `FamilyPrestigeRanking`（榜单内容是别的模块/存档的事）
        pre = _purse_get(ctx, 'prestige')
        st['prestige_point'] = pre
        _save(ctx, st)
        return ctx.ok({'prestige': pre, 'shengwang': pre},
                      '★ 刷新本门声望榜（师门声望 %d）' % pre)

    # ------------------------------------------------------------------ 家园扩建
    if ep == 'extension_room':
        mid = _s(ctx.param('mid'))
        attr = _as_list(ctx.param('attr') or (ctx.body_obj or {}).get('attr'))
        upload = _as_list(ctx.param('upload') or (ctx.body_obj or {}).get('upload'))
        point = _num(ctx.param('point'))
        rows = []
        for r in upload:
            if isinstance(r, (list, tuple)) and len(r) >= 3:
                rows.append([_s(r[0]), _s(r[1]), _s(r[2])])
        if not rows:
            return ctx.fail('没有任何改动！', '★ 房间扩建：上行 upload 是空的')
        st['room_upload'] = rows
        st['room_attr'] = attr
        st['room_mid'] = mid
        _save(ctx, st)
        ctx.log('[地图买卖] 房间扩建 mid=%s 新增 %d 间' % (mid, len(rows)))
        return ctx.ok({'mid': mid, 'upload': rows, 'count': len(rows)},
                      '★ 房间扩建（%d 间）' % len(rows))

    # ------------------------------------------------------------------ 副本重置
    if ep == 'refresh_fuben_by_yuanbao':
        raw = _as_list(ctx.param('map_list') or (ctx.body_obj or {}).get('map_list'))
        maps = [_s(x) for x in raw if _s(x)]
        if not maps:
            return ctx.fail('当前副本章节无法重置。', '★ 副本重置：map_list 是空的')
        price = _map_reset()
        total = 0
        for mid in maps:
            row = price.get(mid)
            if isinstance(row, dict):
                total += _num(row.get('price'))
        fr = st.setdefault('fuben_reset', {})
        if fr.get('day') != _today():
            fr['day'] = _today()
            fr['n'] = 0
        if _num(fr.get('n')) < FUBEN_FREE_PER_DAY:
            total = 0
        if total:
            left = _purse_add(ctx, 'yuanbao', -total)
            if left is None:
                return ctx.fail('元宝不足', '★ 副本重置：元宝不够（要 %d）' % total)
        fr['n'] = _num(fr.get('n')) + 1
        _mark(st, 'refresh_fuben', '%s -%d 元宝' % (','.join(maps), total))
        _save(ctx, st)
        ctx.log('[地图买卖] 重置副本 %s（%d 元宝）' % (maps, total))
        # 她只在 `refreshData.remove_yuanbao > 0` 时改提示文本，缺了会 `attempt to index`
        return ctx.ok({'remove_yuanbao': total, 'map_list': maps,
                       'yuanbao': _purse_get(ctx, 'yuanbao')},
                      '★ 重置副本 %s（%d 元宝）' % (','.join(maps), total))

    return None


# ===========================================================================
# 七夕结果构造（用她 xiqi.lua 的真人物，保证 `getNpcInfo(...).name` 不炸）
# ===========================================================================
def _build_qixi(people, final):
    """按 `XiXiUtil:createResultDataList` 认的格式造：`[[{day,info,ratio},...],...]`。

    `info` = `"1;左npcId;右npcId;level;textIndex"`：
      * 左/右 npcId 必须都在 `xiqi.People` 里（她 `getNpcInfo(id).name`）；
      * `level` 必须能在 `xiqi.final` 找到（她 `getResultDesc(level,textIndex)`）；
      * `textIndex` 必须在该 level 的子表里存在。
    """
    if not people or not final:
        return []
    by_day = {}
    for pid, p in people.items():
        if not isinstance(p, dict):
            continue
        day = _num(p.get('day'), 1)
        by_day.setdefault(day, []).append((str(pid), _s(p.get('name'))))
    out = []
    for day in sorted(by_day.keys()):
        rows = []
        lst = by_day[day]
        for i in range(0, len(lst) - 1, 2):
            left = lst[i][0]
            right = lst[i + 1][0]
            level = str(((i // 2) % 5) + 1)
            sub = final.get(level)
            keys = [k for k in sub.keys() if k != 'id'] if isinstance(sub, dict) else []
            keys.sort()
            if not keys:
                continue
            text_index = keys[0]
            ratio = 1 + (i // 2) % 3
            rows.append({
                'day': day,
                'info': '%s;%s;%s;%s;%s' % (level, left, right, level, text_index),
                'ratio': ratio,
            })
        if rows:
            out.append(rows)
    return out
