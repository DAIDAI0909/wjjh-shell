# -*- coding: utf-8 -*-
# ================= 离线包路径根（fz_make_offline_bundle.py 自动注入） =================
# 手机上整个服务端就是一个目录，表在哪、状态写哪，全部相对包根算。
# （有的模块原来把绝对路径写死，本身没 import os —— 这里一并补上）
import os
import os as _osp


def _off_find_bundle(_f):
    """从模块所在目录往上找包根（认 fz_boot_server.py）。
    ★ fz_api/*.py 的 __file__ 在 <根>/fz_api/ 下，直接 dirname 会算错一层。"""
    _d = _osp.path.dirname(_osp.path.abspath(_f))
    for _ in range(6):
        if _osp.path.exists(_osp.path.join(_d, 'fz_boot_server.py')):
            return _d
        _u = _osp.path.dirname(_d)
        if _u == _d:
            break
        _d = _u
    return _osp.path.dirname(_osp.path.abspath(_f))


_OFF_BUNDLE = _off_find_bundle(__file__)
_OFF_FZ_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_fz')
_OFF_INK_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_ink')
_OFF_WORK_ROOT = _OFF_BUNDLE
# =====================================================================================
# ★ 2026-10-04 商城空货架修复：客户端资源表解析——PC 开发树优先，设备上自动回退
#   到包内 client_fz 副本（jhserver/client_fz = fangzhi_lua_dec 的同步拷贝）。
def _fz_res(*parts):
    base = os.path.join(_OFF_FZ_ROOT, 'res', 'script')
    if not os.path.isdir(base):
        base = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            '..', 'client_fz', 'res', 'script')
    return os.path.join(base, *parts)

# -*- coding: utf-8 -*-
"""梦境 / 魂梦（梦境闯荡 + 南柯一梦）—— 摘梦阁 · 楼层/副本结算 · 事件记录 · 网页奖励。

**契约出处（逐个读过她客户端代码 + 她的配表，不是猜的）**

接口 → 她客户端读的 `data.字段`（少一个字段她那边就 `attempt to index a nil value`，
被 `xpcall` 吞掉 ⇒ 整个界面彻底卡死）：

| 接口(URL 末段)                | 谁调 / 读什么                                                                        |
|-------------------------------|--------------------------------------------------------------------------------------|
| `get_dream_goods`             | `views/layer/DreamWorldLayer/DreamStoreLayer.lua:45-68` 读 `period`(数字,回传)、
|                               | `expired_time`(数字,**剩余秒数**,`Helper:sec3timeDsc` + 每秒 -1)、`dreamYiYu`(数字)、
|                               | `list`(数组)；`setListView` 每项读 `onlyId`/`number`/`count`/`state`，并
|                               | `assert(StoreItemRes[tostring(onlyId)])` ⇒ `onlyId` **必须是
|                               | `script/dreamworld/dreamzhaimengge.lua["Sheet1"]` 的键**（:104）                     |
| `buy_dream_goods`             | `DreamStoreLayer.lua:250` POST `{onlyId, period}`；回调读 `dreamYiYu`(余量,数字)
|                               | 与 `cost`(本次花费,数字,`"消耗"..cost.."梦内呓语"`)；`errcode==2` ⇒ 她重新拉商品列表 |
| `dream_floor_complete`        | `DreamSystem.lua:1382-1412` POST `{roleAttr}`；读 `eventsInfo`(数组,
|                               | `MapIsEmpty` 后 `handlDreamOperationEvent`)、`addPijuan`(数字,可选)；
|                               | `errcode==2` 时**还要** `roleAttr`→`createDreamRoleWithData(data.roleAttr)`          |
| `dreamworld_complete`         | `DreamSystem.lua:1434-1503` POST `{roleAttr, rewardParams}`；读 `eventsInfo`、
|                               | `reward`(表,`DreamCompleteRewardLayer:initUi` 读 `loc_attrTab`/`net_attrTab`/
|                               | `skillTab`，再 `RewardManager2:getReward` 读 `item1`/`item2`)                        |
| `get_dream_role`              | `models/DreamWorldModel/DreamRoleModel.lua:4-30`：**`data` 本身就是梦境人物数据**，
|                               | 交给 `DreamSystem:createDreamRoleWithData(data)`（读 `dreamWorld.cFloor` 等）；
|                               | `errcode==2` ⇒ `func(nil)` ⇒ 她走"开新梦"正常流程                                  |
| `get_event_record`            | `models/DreamWorldModel/DreamTalentModel.lua:565-601`：读 `data.params`(数组,
|                               | `ipairs`，元素 `type`/`id`；`type` 见 `DreamConst.OpertionEventName` =
|                               | `unlockTalent`/`upgradeTalent`) 与 `data.point`(数字,梦境币余量,
|                               | `"梦境币:"..currCoins`)                                                              |
| `fond_dream_floor_complete`   | `models/FondDream/FondDreamSystem.lua:193-222`：只读 `errcode`；
|                               | `errcode==2` 时读 `data.roleAttr`                                                    |
| `fond_dreamworld_complete`    | `FondDreamSystem.lua:236-263`：读 `data.reward`（`ChessCompleteLayer:initUi`）        |
| `get_fond_dream_reward`       | `models/reward/RewardManager2.lua:533-564` POST `{rewardType,rewardId,roleAttr}`；
|                               | 读 `data` 整表（`getReward`：`loc_attrTab`/`net_attrTab`/`skillTab`/`item1`/`item2`）|
| `get_web_reward`              | `RewardManager2.lua:499-530`，同上；调用点 `EMapModule/DreamWorldModule.lua:51-70`
|                               | (`rewardType=1,rewardId=<地图操作 arg2>`)、`:186-203` (`rewardType=4,rewardId=楼层`)、
|                               | `role/item/UseItem/RoleUseItem_Special.lua:12-51` (`rewardType=3,rewardId=item.rewardid`
|                               | 或 `rewardType=1,rewardId=item.rewardIds`)                                           |

**内容全部来自她自己的表**（`work/tmp_*` 里没有新造数值）：

* `res/script/dreamworld/dreamzhaimengge.lua["Sheet1"]`（361 条，键 == `onlyId`）
    → 摘梦阁商品：`id`(物品/武学)、`price`(梦内呓语单价)、`number`(单次数量)、
      `type`(1=物品 2=武学)、`limit2`(可兑换次数)、`menpai`(门派限制)
* `res/script/dreamworld/dreamtfskill.lua["天赋表"]`（141 条，38 个天赋组）
    → 周公之术天赋：`drtfname`/`drtfmoney`/`drtfexp`/`tfgroupid`/`tfleveLs`/`drtftext`
      ★ "天随人愿"（组 27，5 级）的 `drtftext` 里写明"结算时额外获得 **20/40/60/80/100** 梦内呓语"
        ⇒ `_yiyu_bonus()` 是**从她自己的文案里正则取的**，没有自造数字
* `res/script/dreamworld/dreamfloorexp.lua["Sheet1"]`（40 层）
    → 梦境每层经验 `floorexp`（她 `DreamSystem:getExpReward(floor)` :1663 同一张表）
* `res/script/dreamworld/dreamsettlement.lua["pjqujian"]`（5 段）
    → 疲倦值分段的结算台词 `overtest` 与 `min`/`max`（她 `DreamSystem.lua:1453-1462` 用它选
      `overtest`）。**"每层加多少疲倦值"她表里没有**（全仓 `pijuan` 只有 3 处地图条件，
      没有配表）⇒ 取 `PIJUAN_PER_FLOOR=5`（= `RoleModule_GetBaseAttr_GetDefault.lua:63`
      的 `pijuanMax=200` ÷ `DreamConst.MAX_FLOOR=40`），要调就改这个常量。
* `res/script/map/mapItemAttr/Rewards.lua`（5399 条）
    → **奖励内容表**：`rwType`(物品/属性/称号) `rwName` `rwNumber` `calcType`
      (固定类/随机类 `"min;max"`/公式类) `rwFormula` `rwText`
      ⇒ `get_web_reward` / `get_fond_dream_reward` 与 `dreamworld_complete` 的 `reward`
        就是这张表按 `rewardId` 展开的
      ★ 已核对：`drUnit.lua` 里 `梦境获取奖励` 的 79 个 `arg2` **全部**命中这张表
        （其中 71 个同时是 `dreamshop.lua["drptshop"]` 的键）；`drItems.lua` 的
        `rewardid`(101/107/113/801/806/809) 也全部命中。类型 3/4/1 的 `rewardId` 走同一张表。
* `res/script/map/mapItemAttr/drItems.lua`(196) / `fondDrItems.lua`(12) /
  `drequipment.lua`(28) / `fondDrequipment.lua`(28)
    → 梦境物品 id 白名单（`item1`/`item2` 的键必须是这些，否则
      `RewardManager2:getReward` 的 `Item:getOneItemByKey(id).name` 会崩）
* `res/script/dreamworld/drUnit.lua`（1097 条 NPC）
    → 楼层事件记录/掉落白名单：`operations[].results[].arg1=="梦境获取奖励"` 的 `arg2`
* `res/script/nanke/dreamworld/dreamfloorexp.lua["Sheet1"]`（20 条，`type` 1/2）
    → 南柯一梦每层经验（她 `FondDreamResManager.lua:106-108` 读的就是这张）
* `res/script/nanke/dreamworld/qipanbiao.lua["副本模板"|"棋盘属性"]`
    → 南柯棋局/副本模板（`floorEvents`/`event`），只读；用来校验楼层合法

**上行字段出处**：`app/extends/Http/HttpManager.lua:3179-3313`（梦境）与 `:3826-3862`（南柯）。

**状态**：`work/dream_world_state.json`（本模块独占；与 `homeland_person.py` 的
`dream` 键、`misc_systems.py` 的 `get_fond_dream_role`/`settle_overdue_fond_dream` 不撞）。
    `goods`(每期剩余可兑换次数) / `period` / `dreamYiYu` / `dreamCoins` /
    `roleAttr`(upload 的梦境人物原样存，`get_dream_role` 原样回) /
    `fondRoleAttr` / `floor` / `points`(梦境积分) / `events`(天赋事件记录) /
    `pijuan`(疲倦值最新值) / `log`

**已知没做（诚实交代，没有拿假数据糊）**

1. `upload_dream_role` **不在本模块接口清单里**（清单只有 `get_dream_role`）也没人接管
   ⇒ 服务端拿不到她上传的梦境人物。`get_dream_role` 只能回**本模块存下来的**
   `roleAttr`（首次必然没有 ⇒ 按她客户端约定回 `errcode=2` ⇒ 她走"开新梦"正常流程）。
   要真正做到"梦境闯荡中途重登可续"，需要有人接管 `upload_dream_role`。
2. `RewardRuleTab` / `RewardManager2.rewardList` **只存在于她的服务端**，客户端资源里没有
   （全仓 grep 只有 `RewardManager2.lua` 两处引用），所以"奖励组按概率抽 N 份"的规则表
   拿不到。本模块的替代做法：`rewardId` 直接作 `Rewards.lua` 的键展开（类型 3 本来就是
   指定奖励；类型 1/4 的 id 也全部命中该表，已核对）。**没有伪造概率表。**
3. `dreamCoins`（天赋面板的"梦境币"）余量她服务端算；`upload_event_record` 不在清单里，
   所以服务端收不到她的扣币。`get_event_record.point` 按她自己的
   `dreamtfskill.lua["天赋表"].drtfmoney` 累加记录推算（0 = 一件都没解锁），不编数字。
4. `dream_floor_complete` 的 `eventsInfo` 只回**本模块真实记下的**天赋事件；
   掉落实体仍由她的客户端（`DreamTalentModel:getWebTalentData` + 地图操作）驱动。
"""
import json
import os
import random
import re
import sys
import time

NAME = 'dream_world'
TITLE = '梦境/魂梦/奖励'
ENDPOINTS = [
    'get_dream_goods',
    'buy_dream_goods',
    'dream_floor_complete',
    'dreamworld_complete',
    'get_dream_role',
    'upload_dream_role',
    'get_event_record',
    'upload_event_record',
    'fond_dream_floor_complete',
    'fond_dreamworld_complete',
    'get_fond_dream_reward',
    'get_web_reward',
]

STATE = 'dream_world_state.json'

RES = _fz_res()

# 她 `DreamConst.lua`:100 `MAX_FLOOR`；`RoleModule_GetBaseAttr_GetDefault.lua`:63 `pijuanMax`
MAX_FLOOR = 40
PIJUAN_MAX = 200
# "每层加多少疲倦值"她表里没有（见模块 docstring 第 2 段）⇒ 用她自己的两个常量推出。
PIJUAN_PER_FLOOR = PIJUAN_MAX // MAX_FLOOR          # = 5

# 商店期数：她服务端定。取 3 天一期（纯服务端节奏参数，只影响 countdown/回传校验）。
PERIOD_SECONDS = 3 * 24 * 60 * 60

# 她 `DreamStoreLayer.lua:9-13` 的 StoreItem_State
CANBUY, BOUGHT, UNOPEN = 0, 1, 2

# 她 `RewardManager2.lua:118-145` 的 `attr_list`（奖励属性 id ↔ 属性名），原样抄。
ATTR_IDS = {
    1: 'exp', 2: 'pot', 3: 'weiwang', 4: 'yueli', 5: 'money', 6: 'zhengqi',
    7: 'dreamCoins', 8: 'sober', 9: 'pijuan', 10: 'dreamYiYu', 20: 'lv',
    21: 'dreamPoints', 22: 'qiMax', 23: 'neiliMax', 24: 'qi', 25: 'neili',
    26: 'str', 27: 'con', 28: 'dex', 29: 'secStr', 30: 'secCon', 31: 'secDex',
    32: 'qiPercent', 40: 'zhounianqin_jf', 41: 'zhounianliquan', 42: 'daily_point',
}
ATTR_NAME_TO_ID = {v: k for k, v in ATTR_IDS.items()}
# `Rewards.lua` 里出现、但 `attr_list` 不认的名字（给了她也会打"未知属性奖励"）⇒ 丢掉
ATTR_IGNORE = {'gold', 'jing', 'yinpiao'}

_TABLES = {}


# ===========================================================================
# 一、她的资源表（`work/fz_luatable.py`）
# ===========================================================================


def _lua(path, *keys):
    """解析她的表并按 `keys` 逐层取；任何异常都返回 `{}`（绝不把异常抛给应答）。"""
    if path not in _TABLES:
        val = {}
        try:
            try:
                import fz_luatable
            except ImportError:
                sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
                import fz_luatable
            val = fz_luatable.load_lua_table(path) or {}
        except Exception:                          # noqa: BLE001
            val = {}
        _TABLES[path] = val if isinstance(val, dict) else {}
    cur = _TABLES[path]
    for k in keys:
        if not isinstance(cur, dict):
            return {}
        cur = cur.get(k)
        if cur is None:
            return {}
    return cur if isinstance(cur, dict) else {}


def _dream_store():
    """`dreamworld/dreamzhaimengge.lua["Sheet1"]`（361 条摘梦阁商品，键 == `onlyId`）。"""
    return _lua(RES + r'/dreamworld/dreamzhaimengge.lua', 'Sheet1')


def _rewards():
    """`map/mapItemAttr/Rewards.lua`（5399 条奖励内容定义）。"""
    return _lua(RES + r'/map/mapItemAttr/Rewards.lua')


def _talents():
    """`dreamworld/dreamtfskill.lua["天赋表"]`（141 条周公之术天赋）。"""
    return _lua(RES + r'/dreamworld/dreamtfskill.lua', '天赋表')


def _floor_exp(fond=False):
    """每层经验：梦境 `dreamfloorexp`；南柯 `nanke/dreamworld/dreamfloorexp`（她两个 resManager 各自读的）。"""
    if fond:
        return _lua(RES + r'/nanke/dreamworld/dreamfloorexp.lua', 'Sheet1')
    return _lua(RES + r'/dreamworld/dreamfloorexp.lua', 'Sheet1')


def _settlement():
    """`dreamworld/dreamsettlement.lua["pjqujian"]`（疲倦值分段结算台词）。"""
    return _lua(RES + r'/dreamworld/dreamsettlement.lua', 'pjqujian')


def _dream_items():
    """梦境物品白名单：`drItems` + `fondDrItems` + 两套梦境兵器表。"""
    out = {}
    for f in (r'/map/mapItemAttr/drItems.lua',
              r'/map/mapItemAttr/fondDrItems.lua',
              r'/map/mapItemAttr/drequipment.lua',
              r'/map/mapItemAttr/fondDrequipment.lua'):
        out.update(_lua(RES + f))
    return out


def _reward_event_ids():
    """`drUnit.lua` 里 `梦境获取奖励` 操作的全部 `arg2`（她真实会请求的 rewardId 白名单）。"""
    ids = set()
    try:
        with open(RES + r'/dreamworld/drnpc/drUnit.lua', encoding='utf-8', errors='replace') as f:
            txt = f.read()
    except OSError:
        return ids
    for m in re.finditer(r'梦境获取奖励', txt):
        mm = re.search(r'arg2[^0-9]{0,10}(\d+)', txt[m.start():m.start() + 120])
        if mm:
            ids.add(mm.group(1))
    return ids


def _yiyu_bonus():
    """**从她自己的天赋文案里取**"天随人愿"每级额外梦内呓语（20/40/60/80/100）。

    `dreamtfskill.lua["天赋表"]` 里 "天随人愿"（组 27）的 `drtftext` 写着
    "…结算时额外获得20梦内呓语"；这段数字**不在任何字段里**，只能从 `drtftext` 正则取。
    """
    out = {}
    for tid, v in _talents().items():
        if not isinstance(v, dict):
            continue
        text = str(v.get('drtftext') or '')
        if '梦内呓语' not in text:
            continue
        nums = re.findall(r'(\d+)\s*梦内呓语', text)
        if not nums:
            continue
        out[str(tid)] = (int(nums[0]), int(v.get('tfgroupid') or 0))
    return out


def _items_exists(item_id):
    """物品 id 是否在她**任意**一张物品表里（`drItems`/`fondDrItems`/商品表/Items.lua）。

    `RewardManager2:getReward` 的 `item1`/`item2` 会 `Item:getOneItemByKey(itemId)`
    ⇒ 给了不存在的 id 会 `index a nil` 崩。这里只放行真存在的。
    """
    iid = _s(item_id)
    if not iid:
        return False
    if iid in _dream_items():
        return True
    try:
        try:
            from fz_api import items_currency as _ic
        except ImportError:
            import items_currency as _ic
        info = _ic.item_info(iid) or {}
        if info:
            return True
        return iid in _ic.all_items()
    except Exception:                              # noqa: BLE001
        return False


# ===========================================================================
# 二、小工具
# ===========================================================================
def _s(v, d=''):
    if v is None:
        return d
    if isinstance(v, bool):
        return str(int(v))
    if isinstance(v, float) and float(v).is_integer():
        return str(int(v))
    return str(v)


def _i(v, d=0):
    try:
        if v is None or v == '':
            return d
        return int(float(v))
    except (TypeError, ValueError):
        return d


def _num(v, d=0.0):
    try:
        if v is None or v == '':
            return d
        return float(v)
    except (TypeError, ValueError):
        return d


def _list(v):
    if isinstance(v, list):
        return v
    if isinstance(v, dict):
        return [v[k] for k in sorted(v.keys(), key=lambda x: _i(x, 0))]
    return []


def _ok_list(ctx, arr, note):
    """她 `pairs`/`ipairs`/`#` 强依赖**表** ⇒ 列表类应答原样回数组（`ctx.ok` 只给 dict 补 dataVer）。"""
    return ctx.ok(arr if isinstance(arr, list) else [], note)


# ===========================================================================
# 三、状态
# ===========================================================================
def _blank():
    return {
        'period': 0,
        'goods': {},        # {"<onlyId>": 本期剩余可兑换次数}
        'dreamYiYu': 0,     # 梦内呓语（摘梦阁货币；她服务端结算发放）
        'dreamCoins': 0,    # 梦境币（周公之术天赋货币）
        'roleAttr': {},     # upload 的梦境人物（`get_dream_role` 原样回）
        'fondRoleAttr': {},
        'floor': 0,
        'pijuan': 0,
        'events': [],       # 真实记下的天赋事件 [{type,id,count,currency,cost,ts}]
        'log': [],
    }


def _load(ctx):
    st = ctx.load_json(STATE, None)
    if not isinstance(st, dict):
        st = _blank()
    base = _blank()
    for k, v in base.items():
        if k not in st or not isinstance(st[k], type(v)):
            if isinstance(v, dict) and isinstance(st.get(k), dict):
                continue
            st[k] = v
    if not isinstance(st.get('events'), list):
        st['events'] = []
    # ★★ 2026-10-06 老板拍板：梦境币/梦内呓语保底巨额（天赋解锁升级、摘梦阁随便用）。
    #   背景：她原版天赋解锁走官方服务端扣币，我们此前没接管 upload_event_record
    #   ⇒ 客户端本地把币扣成负数、天赋重拉即消失。现在：上报接口已接管（_record_events
    #   正常记事件+扣币），余额保底 99999999 = 永远扣不完 ≈ "不消耗"。
    st['dreamCoins'] = max(_i(st.get('dreamCoins'), 0), 99999999)
    st['dreamYiYu'] = max(_i(st.get('dreamYiYu'), 0), 99999999)
    return st


def _save(ctx, st):
    ctx.save_json(STATE, st)


def _mark(st, msg):
    log = st.setdefault('log', [])
    log.append('%s %s' % (time.strftime('%Y-%m-%d %H:%M:%S'), msg))
    del log[:-40]


def _period_now():
    return int(time.time() // PERIOD_SECONDS) + 1


def _expired_time():
    """她 `expired_time` 是**剩余秒数**（`Helper:sec3timeDsc` + 每秒 -1），给 0 会被判"已结束"。"""
    now = int(time.time())
    return max(PERIOD_SECONDS - (now % PERIOD_SECONDS), 60)


def _sync_period(st):
    """跨期就把每件商品的可兑换次数重置成她表里的 `limit2`。"""
    p = _period_now()
    if _i(st.get('period'), 0) != p:
        st['period'] = p
        st['goods'] = {}
        return True
    return False


def _goods_stock(st, only_id, row):
    """本期剩余可兑换次数。

    ★ 只记**玩家真的兑换过**的商品（`st["goods"][onlyId]` = 已兑换次数）；
      没记录就是 0 次已兑换 ⇒ 剩余 = 她表的 `limit2`（`999` = 不限次）。
      这样状态文件不会把 361 件商品全写进去。
    """
    goods = st.setdefault('goods', {})
    return max(0, _i(row.get('limit2'), 1) - _i(goods.get(_s(only_id)), 0))


# ===========================================================================
# 四、奖励展开（`Rewards.lua` → 她 `RewardManager2:getReward` 的字段形状）
# ===========================================================================
def _rw_entry(reward_id):
    """`Rewards.lua[rewardId]`；`rewardId` 以 `;`/`|` 分隔时逐个展开。"""
    return _rewards().get(_s(reward_id))


def _rw_number(v):
    """`rwNumber` 可能是 `"min;max"`（`calcType=随机类`）⇒ 取区间随机；否则原值。"""
    raw = v.get('rwNumber')
    if isinstance(raw, str) and ';' in raw:
        a, b = raw.split(';', 1)
        lo, hi = _i(a, 1), _i(b, _i(a, 1))
        if hi < lo:
            lo, hi = hi, lo
        return random.randint(lo, hi)
    return _i(raw, 1)


def _expand_reward(reward_id, out=None):
    """把 `Rewards.lua` 的一条奖励摊进她 `RewardManager2:getReward` 认的桶。

    桶：`item1`(实物品) / `item2`(虚拟物品) / `net_attrTab`(服务端属性) /
        `loc_attrTab`(本地属性) / `skillTab`(武学)
    属性名→id 用她 `RewardManager2.lua:118-145` 的 `attr_list` 反查。
    物品必须在她的物品表里（否则她 `Item:getOneItemByKey` 崩）⇒ 不在就丢。
    """
    if out is None:
        out = {'item1': {}, 'item2': {}, 'net_attrTab': {}, 'loc_attrTab': {}, 'skillTab': []}
    eid = _s(reward_id)
    if not eid:
        return out
    for sid in [x for x in re.split(r'[;|]', eid) if x]:
        row = _rw_entry(sid)
        if not row:
            continue
        rw_type = _s(row.get('rwType'))
        rw_name = _s(row.get('rwName'))
        cnt = _rw_number(row)
        if rw_type == '物品':
            if _items_exists(rw_name):
                out['item1'][rw_name] = _i(out['item1'].get(rw_name), 0) + cnt
        elif rw_type == '属性':
            if rw_name in ATTR_IGNORE:
                continue
            aid = ATTR_NAME_TO_ID.get(rw_name)
            if aid is None:
                continue
            out['net_attrTab'][_s(aid)] = _i(out['net_attrTab'].get(_s(aid)), 0) + cnt
        # `称号` 这种她 `getReward` 不认（没有对应桶）⇒ 跳过，不硬塞
    return out


def _reward_payload(out):
    """补全她每个面板都会读的键（缺了 `MapIsEmpty`/`pairs` 也安全，但补上更贴契约）。"""
    return {
        'item1': out.get('item1') or {},
        'item2': out.get('item2') or {},
        'net_attrTab': out.get('net_attrTab') or {},
        'loc_attrTab': out.get('loc_attrTab') or {},
        'skillTab': out.get('skillTab') or [],
    }



# ★★ 2026-10-06 客户实测纠错（馒头/水袋吃了变加经验/阅历）：
#   梦内消耗品（drItems type=特殊）的 `rewardIds` 在原版是**官方服务端"奖励组"编号**，
#   组内容（回气血/内力）只存在于她的服务端 ⇒ 拿不到。此前直接按 Rewards.lua 同号键展开
#   =同号不同义（Rewards[1801] 是给经验书用的 exp+5000）⇒ 回血道具全变经验/阅历/潜能。
#   修法：这批编号改按**物品描述的功效**直接发 `loc_attrTab`（气血 24 / 内力 25，
#   量=上行 roleAttr 的 qiMax/neiliMax × 比例）——客户端 getReward 对 loc_attrTab
#   真实 addAttr 且弹「气血 +X」，与描述一致。宝箱类（1/21/31/41/51）不动。
_DREAM_USE_ITEMS = {
    # rewardIds: (物品名, 气血比例, 内力比例)
    1801: ('馒头', 0.35, 0),
    1802: ('止血散', 0.6, 0),
    1803: ('续脉膏', 0.95, 0),
    1804: ('跌打酒', 0.5, 0),
    1805: ('金创药', 0.8, 0),
    1806: ('水袋', 0, 0.35),
    1807: ('云雾茶', 0, 0.6),
    1808: ('熊胆', 0, 0.95),
    1809: ('黑珍珠', 0, 0.5),
    1810: ('灵芝', 0, 0.8),
    1811: ('玉滋丹', 0.8, 0.8),
    1812: ('风华玉露丹', 1.0, 1.0),
}

# ★★ 2026-10-06 老板拍板：限时栏「梦境补给礼盒」（主世界商城 testpack_dreamsupply）。
#   打开随机获得五类梦境资源×5，服务端记账、**下次入梦自动放进梦内背包**
#   （梦内物品不在主世界物品表 ⇒ 主世界直发会崩，只能走入梦下发）。
#   ★ 2026-10-07 客户反馈扩池：铜环钥/百解钥/续魂灯/碎银等全都要——池子改为
#   **drItems 全表动态取**（196 件：消耗品/道具/宝物），外加碎银货币直加（原版宝箱
#   产碎银 10~45，本盒每"个"=20 碎银，一抽=100）。
_DREAM_SUPPLY_CURRENCY = 'dream_suiyin'   # 虚拟条目：碎银（get_dream_role 时并入 roleAttr.money）
_DREAM_SUPPLY_CURRENCY_NAME = '碎银'
_DREAM_SUPPLY_CURRENCY_PER = 20           # 每个=20 碎银
_DREAM_SUPPLY_PICK = 5      # 每次开盒随机类数
_DREAM_SUPPLY_PER = 5       # 每类个数


def _dream_supply_names():
    """补给池 = drItems 全表（id→名），动态取自她自己的表（新物品自动入池）。"""
    if '_dream_supply_names' in _TABLES:
        return _TABLES['_dream_supply_names']
    names = {}
    for k, r in (_dream_items() or {}).items():
        if isinstance(r, dict) and r.get('name'):
            names[_s(k)] = _s(r.get('name'))
    _TABLES['_dream_supply_names'] = names
    return names


def _dream_box_rwids():
    """梦境盒 rwId 集（兼容旧字段）。"""
    return set(_dream_rid_to_box().keys())


def _dream_rid_to_box():
    """rwId → 盒子 key（client_items_extra.json 的 dream_box_map；testpacks 生成）。"""
    if '_dream_rid_to_box' in _TABLES:
        return _TABLES['_dream_rid_to_box']
    m = {}
    try:
        p = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                         'client_items_extra.json')
        with open(p, 'r', encoding='utf-8') as f:
            for key, rids in ((json.load(f) or {}).get('dream_box_map') or {}).items():
                for x in rids or []:
                    m[_i(x, 0)] = key
    except Exception:                                   # noqa: BLE001
        m = {}
    _TABLES['_dream_rid_to_box'] = m
    return m


def _roll_dream_supplies(st):
    """补给礼盒开盒（**买时由 shop_store 调用**）：随机 5 类×5 + 碎银×10000 +
    铜环钥/百解钥/续魂灯 各×3（老板 10-07 拍板：寻宝礼包并入补给礼盒），全部记进
    st['pendingSupplies']，get_dream_role / dream_floor_complete 时并入梦内背包。"""
    pool = sorted(_dream_pool_ids())
    picked = random.sample(pool, min(_DREAM_SUPPLY_PICK, len(pool)))
    pend = st.setdefault('pendingSupplies', {})
    names = _dream_supply_names()
    lines = []
    for iid in picked:
        pend[iid] = _i(pend.get(iid), 0) + _DREAM_SUPPLY_PER
        lines.append('%s×%d' % (names.get(iid, iid), _DREAM_SUPPLY_PER))
    # ★ 2026-10-07 老板拍板：钥匙/碎银/续魂灯从盒中移除（使用发货链不稳 + 续魂灯影响重置），
    #   礼盒回归纯随机 5 类×5 梦境补给。
    _mark(st, '梦境补给礼盒：随机 %d 类 → %s' % (len(picked), '、'.join(lines)))
    return lines


def roll_dream_supplies_public(ctx):
    """给 shop_store 的公共入口（买礼盒=开盒：随机 5 类×5 记账，入梦自动随行）。"""
    st = _load(ctx)
    lines = _roll_dream_supplies(st)
    _save(ctx, st)
    return lines


# ★★ 2026-10-07 老板拍板二连：
#   ①「梦境寻宝礼包」独立直买：碎银×10000 + 铜环钥/百解钥/续魂灯 各×3（固定内容）。
#   ②图2四匣子（微澜盒/初名匣/登峰盒/宗师匣）上架限时栏——原版匣子=地图掉落实体
#     （drname id 1095-1097），开匣奖池在官方奖励组表（拿不到）⇒ 按她的官方攻略
#     （宝物/钥匙1-3/消耗品1-2/碎银区间 10-20·12-29·25-35·35-45）合成同结构奖池。
#   ③补给礼盒移出钥匙与碎银（去专属礼包/匣子）。所有梦境盒：**买=发货+记账**，
#     用（rwId 钩）只弹经验不重复发。
_DREAM_TREASURE_KEYS = {'drwp101': '铜环钥', 'drwp102': '百解钥', 'drwp103': '续魂灯'}
_DREAM_TREASURE_KEYS_PER = 3          # 寻宝礼包每种钥匙个数
_DREAM_TREASURE_SUIYIN = 10000        # 寻宝礼包碎银
# ★ 2026-10-07 老板拍板：续魂灯独立「续魂灯礼包」（×3/盒）——灯是"防重置"道具
#   （死亡时消耗一盏复活），混在别的盒里会让玩家想重置时死不掉。灯只从专属礼包来，
#   补给礼盒/寻宝礼包都不再出灯，玩家带多少灯完全自主。
_DREAM_LAMP = 'drwp103'
_DREAM_LAMP_PER = 3
# 四匣子分档（宝物池按 drwp 编号切档；碎银区间=她官方攻略原值）
_DREAM_CHESTS = {
    'weilan':    {'name': '微澜盒', 'lo': 200, 'hi': 232, 'goods': 1, 'suiyin': (10, 20), 'key': (1, 1), 'key_p': 0.30},
    'chuming':   {'name': '初名匣', 'lo': 233, 'hi': 260, 'goods': 1, 'suiyin': (12, 29), 'key': (1, 2), 'key_p': 0.35},
    'dengfeng':  {'name': '登峰盒', 'lo': 261, 'hi': 300, 'goods': 1, 'suiyin': (25, 35), 'key': (1, 2), 'key_p': 0.40},
    'zongshi':   {'name': '宗师匣', 'lo': 301, 'hi': 343, 'goods': 2, 'suiyin': (35, 45), 'key': (2, 3), 'key_p': 0.60},
}


def _dream_pool_ids():
    """补给礼盒随机池 = drItems 全表 − 钥匙 − 续魂灯（固定件，不参与随机）。"""
    return [k for k in _dream_supply_names()
            if k not in _DREAM_TREASURE_KEYS and k != _DREAM_LAMP]


def grant_dream_bundle(ctx, items, suiyin=0):
    """公共发货入口（shop_store 各梦境盒调用）：items={itemId:count}，suiyin=碎银。
    记进 pendingSupplies，下次 get_dream_role 自动并入梦内背包。返回描述行。"""
    st = _load(ctx)
    pend = st.setdefault('pendingSupplies', {})
    names = _dream_supply_names()
    lines = []
    for iid, cnt in (items or {}).items():
        iid = _s(iid)
        cnt = _i(cnt, 0)
        if cnt <= 0 or not iid:
            continue
        pend[iid] = _i(pend.get(iid), 0) + cnt
        lines.append('%s×%d' % (names.get(iid, _DREAM_TREASURE_KEYS.get(iid, iid)), cnt))
    if _i(suiyin, 0) > 0:
        pend[_DREAM_SUPPLY_CURRENCY] = _i(pend.get(_DREAM_SUPPLY_CURRENCY), 0) + _i(suiyin, 0)
        lines.append('碎银×%d' % _i(suiyin, 0))
    _mark(st, '梦境盒发货：%s' % '、'.join(lines))
    _save(ctx, st)
    return lines


def roll_dream_chest_public(ctx, chest_key):
    """四匣子开盒：按她官方攻略结构合成（宝物+消耗品+概率钥匙+碎银区间）。"""
    cfg = _DREAM_CHESTS.get(chest_key)
    if not cfg:
        return ['未知的匣子']
    st = _load(ctx)
    names = _dream_supply_names()
    lo_id, hi_id = cfg['lo'], cfg['hi']
    pool = [k for k in names
            if k.startswith('drwp') and lo_id <= _i(k[4:], 0) <= hi_id]
    items = {}
    for k in random.sample(pool, min(cfg['goods'], len(pool))):
        items[k] = 1
    # 消耗品 1-2 件（drwp1-12）
    cons_pool = ['drwp%d' % i for i in range(1, 13)]
    for k in random.sample(cons_pool, min(random.randint(1, 2), len(cons_pool))):
        items[k] = items.get(k, 0) + 1
    # 钥匙概率 1-3
    if random.random() < cfg['key_p']:
        kn = random.randint(cfg['key'][0], cfg['key'][1])
        kk = random.choice(sorted(_DREAM_TREASURE_KEYS))
        items[kk] = items.get(kk, 0) + kn
    suiyin = random.randint(cfg['suiyin'][0], cfg['suiyin'][1])
    lines = grant_dream_bundle(ctx, items, suiyin)
    return ['%s（%s）' % (cfg['name'], '、'.join(lines))]


# ★★ 2026-10-08 客户反馈①「梦境里木箱里掉的还是潜能」根因修复：
#   梦内宝箱（木箱/普通宝箱/对话获得的宝箱 难度1-4、银宝箱难度4、金宝箱难度1-4/金宝箱）
#   的「梦境获取奖励」id 在 Rewards.lua 里同号命中**主世界属性行**（pot 5000 / exp 7500 /
#   money 10000 …）⇒ 客户端按 net_attrTab（=服务端属性桶）只弹「潜能 +5000」这类字、
#   本体不落任何值 ⇒ 玩家开半天箱子一无所获（"掉的还是潜能"）。
#   改按她的梦内经济走：**一律发碎银**（dreamPoints，loc_attrTab 21：客户端真加
#   role:addAttr("dreamPoints", n) 且弹「碎银 +N」）。碎银是梦内唯一通货——梦内商人
#   买宝物/残页/武学（多数 6 层起解锁）全靠它 ⇒ 箱子不发碎银就是**卡第六层**的直接原因
#   （客户反馈②同一根因）。额度参照她梦内价目表（馒头 30 / 低级指环 80~150 / 残页 10 /
#   灵芝 4000）：原值 ÷50、±25% 抖动、下限 30。**物品类 id（龙涎香/残页×10 等）不动**——
#   她客户端 item1 本来就走 role:addItemCount 真进梦内背包。
_DREAM_BOX_SUIYIN = {
    41:   (75, 125),    # 木箱/普通宝箱/对话获得的宝箱 难度1（原 pot 5000）
    44:   (110, 190),   # 难度2（原 exp 7500）
    47:   (150, 250),   # 难度3（原 money 10000）
    51:   (190, 310),   # 难度4（原 money 12500）
    4:    (30, 55),     # 金宝箱难度2（原 exp 2160）
    7:    (40, 75),     # 金宝箱难度3（原 money 2880）
    11:   (30, 45),     # 金宝箱难度4（原 pot 1800）
    31:   (30, 45),     # 银宝箱难度4（原 money 1000）
    5012: (30, 55),     # 金宝箱（原 money 2040）
    # ★★ 2026-10-09 客户反馈「银纹宝箱老是给十里香」+ 同类漏网（南柯梦境 金/银宝箱单元，
    #   `drUnit` 里 金宝箱难度1=dr5401a/b、银宝箱难度1-3=dr5404a/b·dr5405a·dr5406a，
    #   `unitMuBan=3092` ⇒ 显示名 = drName[1092] = **"银纹宝箱"**，正是客户看到的箱子）：
    1:    (30, 45),     # 金宝箱难度1（原 item36_33 龙涎香=主世界药材）
    21:   (30, 45),     # 银宝箱难度1（原 jiu108 **十里香**=主世界奇遇酒）★ 客户点名要去掉
    24:   (30, 55),     # 银宝箱难度2（原 putizi1 菩提子=主世界内功上限丹）
    27:   (30, 45),     # 银宝箱难度3（原 jian124 客户端物品表里没有 ⇒ item1 被丢=空包白开）
    # 南柯棋局侧 棋魂/黑衣老者（原 pot/exp/money 属性行 ⇒ 客户端 net_attrTab 只弹假字不加值）：
    5004: (25, 45),     # 黑衣老者（1）（原 pot 1050）
    5006: (30, 55),     # 天元棋魂（原 money 1260）
    5008: (30, 55),     # 白色棋魂（原 exp 1260）
    5009: (35, 65),     # 灰色棋魂（原 money 1680）
    5010: (35, 65),     # 白色棋魂（2）（原 pot 1680）
    5011: (35, 65),     # 灰色棋魂（2）（原 exp 1680）
}


def _grant_treasure_internal(st):
    """寻宝礼包内容（碎银×10000 + 铜环钥/百解钥各×3；续魂灯已拆专属礼包）记 pendingSupplies。"""
    pend = st.setdefault('pendingSupplies', {})
    lines = []
    for k in ('drwp101', 'drwp102'):
        pend[k] = _i(pend.get(k), 0) + _DREAM_TREASURE_KEYS_PER
        lines.append('%s×%d' % (_DREAM_TREASURE_KEYS[k], _DREAM_TREASURE_KEYS_PER))
    pend[_DREAM_SUPPLY_CURRENCY] = _i(pend.get(_DREAM_SUPPLY_CURRENCY), 0) + _DREAM_TREASURE_SUIYIN
    lines.append('碎银×%d' % _DREAM_TREASURE_SUIYIN)
    _mark(st, '梦境寻宝礼包：%s' % '、'.join(lines))
    return lines


def _grant_lamp_internal(st):
    """续魂灯礼包内容（续魂灯×3）记进 pendingSupplies，返回描述行。"""
    pend = st.setdefault('pendingSupplies', {})
    pend[_DREAM_LAMP] = _i(pend.get(_DREAM_LAMP), 0) + _DREAM_LAMP_PER
    _mark(st, '续魂灯礼包：续魂灯×%d' % _DREAM_LAMP_PER)
    return ['续魂灯×%d' % _DREAM_LAMP_PER]


def grant_dream_treasure_public(ctx):
    """给 shop_store 的公共入口：寻宝礼包内容记账式发货（碎银1万+两钥各3）。"""
    st = _load(ctx)
    lines = _grant_treasure_internal(st)
    _save(ctx, st)
    return lines


def grant_dream_lamp_public(ctx):
    """给 shop_store 的公共入口：续魂灯礼包内容记账式发货（灯×3）。"""
    st = _load(ctx)
    lines = _grant_lamp_internal(st)
    _save(ctx, st)
    return lines


def _merge_pending_supplies(role_attr, st):
    """把 pendingSupplies 并入她梦内背包（get_dream_role 下发前），返回 (并入条数, 描述)。"""
    pend = st.get('pendingSupplies')
    if not isinstance(pend, dict) or not pend or not isinstance(role_attr, dict):
        return 0, ''
    items = role_attr.get('items')
    if not isinstance(items, list):
        items = []
        role_attr['items'] = items
    have = {}
    next_id = 1
    for it in items:
        if not isinstance(it, dict):
            continue
        next_id = max(next_id, _i(it.get('id'), 0) + 1)
        if it.get('itemId'):
            have[_s(it.get('itemId'))] = it
    desc = []
    for iid, cnt in pend.items():
        cnt = _i(cnt, 0)
        if cnt <= 0:
            continue
        if iid == _DREAM_SUPPLY_CURRENCY:
            # ★★ 2026-10-08 修正：梦内"碎银"= **dreamPoints**（她自己的定义：
            #   DreamSalesModel2 购买/DreamTalentModel 天赋消费都读 dreamPoints；
            #   死亡日志 print 也写 碎银=role.dreamPoints）。此前错发到 money 字段
            #   ⇒ 玩家"钥匙到了碎银没加"。money 仅在主世界有意义。
            role_attr['dreamPoints'] = _num(role_attr.get('dreamPoints'), 0) + cnt
            desc.append('碎银×%d' % cnt)
            continue
        cur = have.get(_s(iid))
        if cur is None:
            items.append({'itemId': _s(iid), 'id': next_id, 'count': cnt})
            next_id += 1
        else:
            cur['count'] = _i(cur.get('count'), 0) + cnt
        desc.append('%s×%d' % (_dream_supply_names().get(_s(iid),
                    _DREAM_TREASURE_KEYS.get(_s(iid), _s(iid))), cnt))
    st['pendingSupplies'] = {}
    return len(desc), '、'.join(desc)


def _return_leftovers(st, role_attr):
    """★ 2026-10-08 老板实测拍板：「梦中余财随你而返」——**结算时把梦内剩余碎银 +
    未用完的三钥（铜环钥/百解钥/续魂灯）退回 pendingSupplies**，下次入梦接着用。

    背景（老板实测）：开了两个梦境礼包（各 1 万碎银），入梦却只见到 1 万——第一箱那
    1 万随第一局的结算蒸发（梦内碎银原本按局走，官方同款）。单机版玩家是**花真元宝
    买的礼包**，钱不该蒸发 ⇒ 结算退回。这也顺带缓解"卡第六层"：跨局能把碎银攒下来
    去梦内商人买宝物/残页/武学。

    只退**碎银 + 三钥**（礼包卖的东西）；梦内商人买的宝物/残页等**留在局内**按局重置
    （避免把商店搬空、也避免跨局强度膨胀）。无副作用：退回的只是本局"没花掉"的部分，
    花掉的换成局内道具（那是玩家的选择）。返回 (退回碎银数, 描述行列表)。
    """
    if not isinstance(role_attr, dict):
        return 0, []
    pend = st.setdefault('pendingSupplies', {})
    lines = []
    left = int(_num(role_attr.get('dreamPoints'), 0))
    if left > 0:
        pend[_DREAM_SUPPLY_CURRENCY] = _i(pend.get(_DREAM_SUPPLY_CURRENCY), 0) + left
        lines.append('碎银×%d' % left)
    have = {}
    for it in _list(role_attr.get('items')):
        if isinstance(it, dict) and it.get('itemId'):
            have[_s(it.get('itemId'))] = _i(it.get('count'), 0)
    for iid in ('drwp101', 'drwp102', _DREAM_LAMP):
        cnt = have.get(iid, 0)
        if cnt > 0:
            pend[iid] = _i(pend.get(iid), 0) + cnt
            lines.append('%s×%d' % (_DREAM_TREASURE_KEYS.get(iid, _iid_name(iid)), cnt))
    if lines:
        _mark(st, '结算退回梦境余财（下次入梦随行）：%s' % '、'.join(lines))
    return left, lines


def _iid_name(iid):
    return _dream_supply_names().get(_s(iid), _s(iid))


def _dream_use_item_payload(rid, role_attr):
    """梦内回血类道具：按功效比例返回 (payload, 物品名)。"""
    name, qi_s, nli_s = _DREAM_USE_ITEMS[_i(rid, 0)]
    qimax = _num((role_attr or {}).get('qiMax'), 0)
    nlimax = _num((role_attr or {}).get('neiliMax'), 0)
    loc = {}
    if qi_s > 0 and qimax > 0:
        loc['24'] = int(round(qimax * qi_s))
    if nli_s > 0 and nlimax > 0:
        loc['25'] = int(round(nlimax * nli_s))
    if not loc:
        # 上行没带 max（理论不会）：给保底绝对值
        if qi_s > 0:
            loc['24'] = int(600 * qi_s)
        if nli_s > 0:
            loc['25'] = int(600 * nli_s)
    return {'item1': {}, 'item2': {}, 'net_attrTab': {}, 'loc_attrTab': loc, 'skillTab': []}, name


def _dream_skill_pool():
    """南柯梦境「主角门派」模板武学池（`dreamLeadrole.lua["主角门派"]` 的 skill1..6）。

    ★ 只收**同时**在梦境武学品级表（`dreamskill.lua["武学"]`）里的 id —— 她
      `DreamSystem:_getDreamSkillLevel` 拿不到该行会直接 `error("主角技能表错误")`；
      `jiben*` 基础功法剔除（她的 skillTab 处理里 `Skill:isBaseAutoSkill` 同样过滤）。
    已核对：24 个门派 ×6 门全部同时在梦境武学表与主技能表（`script/skill/skill.lua`），
    所以客户端 `Skill:getSkill(skillId).name` 也安全。
    """
    if '_dream_skill_pool' in _TABLES:
        return _TABLES['_dream_skill_pool']
    tabs = _lua(RES + r'/dreamworld/dreamLeadrole.lua', '主角门派')
    wx = _lua(RES + r'/dreamworld/dreamskill.lua', '武学')
    pool = {}
    for k, row in (tabs or {}).items():
        if not isinstance(row, dict):
            continue
        fam = _s(row.get('family'))
        ids = []
        for i in range(1, 7):
            sid = _s(row.get('skill%d' % i))
            if not sid or sid.startswith('jiben'):
                continue
            if sid in wx and sid not in ids:
                ids.append(sid)
        if fam and ids:
            cur = pool.setdefault(fam, [])
            for sid in ids:
                if sid not in cur:
                    cur.append(sid)
    _TABLES['_dream_skill_pool'] = pool
    return pool


def _pick_dream_skill(ctx):
    """按上行 `roleAttr.menpaiId`（她 op 里发的是 `role:getFamilyId()`）挑一门门派模板武学，
    挑不出来就全池随机；返回 '' = 池子为空（调用方碎银兜底）。"""
    pool = _dream_skill_pool()
    ra = _role_attr(ctx)
    fam = _s(ra.get('menpaiId')) if isinstance(ra, dict) else ''
    ids = pool.get(fam) or []
    if not ids:
        ids = [x for v in pool.values() for x in v]
    return random.choice(ids) if ids else ''


def _web_reward(ctx, st, ep):
    """`get_web_reward` / `get_fond_dream_reward` —— 同一套参数、同一张内容表。

    上行（`HttpManager.lua:3237` / `:3855`）：`{rewardType, rewardId, roleAttr}`；
    `rewardType` 1=奖励组随机 / 2=梦境结算 / 3=指定奖励 / 4=武学奖励（她注释见 :3236）。
    内容查 `Rewards.lua`（见模块 docstring：79 个 arg2 全部命中该表）。
    ★ 梦内消耗品（rewardIds 1801~1812）走 `_DREAM_USE_ITEMS` 按功效回气血/内力（见上）。
    """
    rtype = _i(ctx.param('rewardType'), 0)
    rid = ctx.param('rewardId')
    if rid is None:
        rid = ctx.param('rewardIds')
    if not _s(rid):
        return ctx.fail('缺少奖励参数', '★ %s：上行没有 rewardId' % ep, 1)
    if rtype == 4:
        # ★★ 2026-10-09 客户反馈②「技能等级没有真正加上，每次提示加了，但是实际没有」根因：
        #   梦境武学奖励（`DreamWorldModule.lua:186-203`：rewardType=4 + rewardId=**楼层**）
        #   此前掉进下面 `_expand_reward(rewardId)` —— 楼层数字当 Rewards.lua 键是**同号不同义**：
        #   层 11 → pot 1800 ⇒ 客户端 net_attrTab 只弹「潜能 +1800」本体不落值（"提示加了实际没有"）；
        #   层 5/9/21 → jiu108 十里香、层 12 → 清风醉、层 15-19 → 铁/铜/银/金/玉钥匙（主世界杂物）。
        #   官方语义=**武学奖励**（她 `RewardManager2.lua:336-342` skillType=30=指定武学品级提升）
        #   ⇒ 按玩家门派模板挑一门武学给 +1 品级（客户端 `addDreamSkillLevel` 真提升 + 弹
        #   「顿悟武道，X进境提升。」——正是客户要的"真正加上"）。武学池空则碎银兜底。
        skill_id = _pick_dream_skill(ctx)
        if skill_id:
            payload = {'item1': {}, 'item2': {}, 'net_attrTab': {}, 'loc_attrTab': {},
                       'skillTab': [{'skillType': 30, 'skillId': skill_id, 'skillValue': 1}]}
            _mark(st, '梦境武学奖励（层 %s）→ 武学 %s 品级 +1（原假属性弹字已修）'
                     % (_s(rid), skill_id))
            _save(ctx, st)
            return ctx.ok(payload, '★ 梦境武学奖励：%s 品级 +1' % skill_id)
        n = random.randint(30, 55)
        payload = {'item1': {}, 'item2': {}, 'net_attrTab': {}, 'loc_attrTab': {'21': n},
                   'skillTab': []}
        _mark(st, '梦境武学奖励（层 %s）→ 碎银 +%d（武学池空兜底）' % (_s(rid), n))
        _save(ctx, st)
        return ctx.ok(payload, '★ 梦境武学奖励：碎银 +%d（兜底）' % n)
    box_key = _dream_rid_to_box().get(_i(rid, 0))
    if box_key in ('testpack_xinshencap', 'testpack_huishendan', 'testpack_shengongmateria',
                    'testpack_gushenyuanqi', 'testpack_fistfeel', 'testpack_fistjqmax'):
        # ★ 2026-10-17 v36b：心神两件套（主世界特殊类使用，服务端生效）。
        if box_key == 'testpack_xinshencap':
            try:
                import fz_api.fist_liangong as _fl
                _f = _fl._load(ctx)
                _f['xsCap99999'] = True
                _f['xsCurr'] = 99999
                _f['xsLast'] = int(time.time())
                _f['xsRecoverStart'] = 0
                _fl._save(ctx, _f)
                _mark(st, '心神上限提升礼包 → 上限 99999 并回满（xsCap99999）')
                payload = {'item1': {}, 'item2': {}, 'net_attrTab': {},
                           'loc_attrTab': {}, 'skillTab': []}
                _save(ctx, st)
                return ctx.ok(payload, '★ 心神上限提升礼包：上限已提升到 99999 并回满（打开心神面板可见）')
            except Exception as _xe:                        # noqa: BLE001
                ctx.log('心神上限礼包生效失败：%s' % _xe)
        elif box_key == 'testpack_gushenyuanqi':
            # ★ 2026-10-22 v39：固身元气 → fist_main 账本 accpoint（拳脚修行加速）。
            # ★ 2026-10-23 v42 老板：一次给 9999（原 100 点练一次就没了）。
            try:
                import fz_api.activities as _act
                _act._fist_add_resource(ctx, 'accpoint', 9999)
                _mark(st, '固身元气礼包 → accpoint +9999（fist_main 账本）')
                # ★ 展示字段必须有——客户端 `v40_show_rewards` 只认 net_attrTab 等
                payload = {'item1': {}, 'item2': {}, 'net_attrTab': {'accpoint': 9999},
                           'loc_attrTab': {}, 'skillTab': []}
                _save(ctx, st)
                return ctx.ok(payload, '★ 固身元气礼包：+9999 点固身元气（拳脚修行界面可用）')
            except Exception as _xe:                        # noqa: BLE001
                ctx.log('固身元气礼包生效失败：%s' % _xe)
        elif box_key == 'testpack_fistfeel':
            # ★ 2026-10-23 v42 老板：感悟点礼包 → fist_liangong 账本 feelPoint +9999。
            #   `feelPoint` 在她配表里**只有消耗**（techniqueLevel.skillcon）没有任何产出，
            #   原版玩到死也升不了技巧 ⇒ 谙技永远是 0。这里是唯一来源。
            #   全 5 分支练满只要 1645 点，9999 足够全部拉满还富余。
            try:
                import fz_api.fist_liangong as _fl
                _f = _fl._load(ctx)
                _f['feelPoint'] = _num(_f.get('feelPoint')) + 9999
                _fl._save(ctx, _f)
                _mark(st, '感悟点礼包 → feelPoint +9999（拳脚技巧升级货币）')
                payload = {'item1': {}, 'item2': {}, 'net_attrTab': {'feelPoint': 9999},
                           'loc_attrTab': {}, 'skillTab': []}
                _save(ctx, st)
                return ctx.ok(payload, '★ 感悟点礼包：+9999 感悟点（拳脚系统→技法心得，升级技巧用）')
            except Exception as _xe:                        # noqa: BLE001
                ctx.log('感悟点礼包生效失败：%s' % _xe)
        elif box_key == 'testpack_fistjqmax':
            # ★ 2026-10-23 v42 老板：「谙技直通」——全部技巧直接练到满级（10 级）。
            #   谙技 = 各技巧等级对应 jqdamage 之和（`FightFistFootBranch:getJqdamage`
            #   逐技巧累加），所以把 techLv 全写 10 就是谙技拉满（每分支 855、五分支 4275）。
            #   ★★ 账本键 = **skillid**（不是 techniqueLevel 表里的行 id）：
            #     `_branch_info_of` 是拿 `techLv` 的键直接喂 `_technique_row(tid, lv)`，
            #     而 `_technique_levels()` 的索引键就是 `skillid` ⇒ 键必须是 "10001" 这种。
            #     写成行 id（10001010）会查不到 ⇒ 面板一个技巧都不显示。
            #   ★ 只升不降：已满级的跳过；不扣感悟点（这是"直通"，不是正常升级路径）。
            try:
                import fz_api.fist_liangong as _fl
                _f = _fl._load(ctx)
                _tech_lv = _f.setdefault('techLv', {})
                _pushed = 0
                for _sk in ('10001', '10002', '10003', '10004', '10005',
                            '10006', '10007', '10008', '10009', '10010',
                            '20001', '20002', '20003', '20004', '20005',
                            '20006', '20007', '20008', '20009', '20010',
                            '30001', '30002', '30003', '30004', '30005',
                            '30006', '30007', '30008', '30009', '30010',
                            '40001', '40002', '40003', '40004', '40005',
                            '40006', '40007', '40008', '40009', '40010',
                            '50001', '50002', '50003', '50004', '50005',
                            '50006', '50007', '50008', '50009', '50010'):
                    if _fl._technique_row(_sk, 10) is None:
                        continue
                    if _num(_tech_lv.get(_sk)) < 10:
                        _tech_lv[_sk] = 10
                        _pushed += 1
                _fl._save(ctx, _f)
                _mark(st, '谙技直通包 → %d 个技巧等级置满 10（谙技拉满）' % _pushed)
                payload = {'item1': {}, 'item2': {},
                           'net_attrTab': {'jqdamage': 4275},
                           'loc_attrTab': {}, 'skillTab': []}
                _save(ctx, st)
                return ctx.ok(payload, '★ 谙技直通：%d 个技巧已练到满级 10，谙技拉满'
                              '（重进拳脚面板可见）' % _pushed)
            except Exception as _xe:                        # noqa: BLE001
                ctx.log('谙技直通包生效失败：%s' % _xe)
        elif box_key == 'testpack_shengongmateria':
            # ★ 2026-10-17 v36b：自创神功材料包 → inherit_skin 道具账本全套 +20。
            try:
                import fz_api.inherit_skin as _isk
                _f = _isk._load(ctx)
                _p = _isk._me(ctx, _f)
                _pm = _isk._res('prop_map', {}) or {}
                for _pid in _pm:
                    _p['props'][_pid] = _i(_p['props'].get(_pid), 0) + 20
                _isk._save(ctx, _f)
                _mark(st, '自创神功材料包 → 道具账本全套 +20（%d 种）' % len(_pm))
                payload = {'item1': {}, 'item2': {}, 'net_attrTab': {},
                           'loc_attrTab': {}, 'skillTab': []}
                _save(ctx, st)
                return ctx.ok(payload, '★ 自创神功材料包：全部材料各 +20（自创界面道具面板可见）')
            except Exception as _xe:                        # noqa: BLE001
                ctx.log('自创材料包生效失败：%s' % _xe)
        else:
            # ★★ 2026-10-23 v45 老板反馈「打开后背包里没有药」⇒ 改为**直接回满心神**。
            #   为什么不再发 minditem5：
            #   ①`minditem1..5` **全部只存在于 `res/script/skill/mindRecoverItems.lua`**
            #     （心神恢复面板的专用表），主表 `mapItemAttr/Items.lua` 里一个都没有
            #     ⇒ 它们**天生就不进背包**，只会进「回复心神」面板的 4 个槽位；
            #   ②而那个面板在预制体里**只有 Panel_1..Panel_4 四个槽位**，塞第 5 个
            #     `minditem5` 会 `panel`=nil 崩 UI（v36b 埋的雷，v44 已拆）；
            #   ⇒ 既然面板放不下、背包也不收，**这个药没有任何可用入口**。
            #   改法=礼包打开直接把心神补满（与 effect=99999 语义等价，客户要的就是这个效果）。
            try:
                import fz_api.fist_liangong as _fl
                _f = _fl._load(ctx)
                if _f.get('xsCap99999'):
                    _mx = 99999
                else:
                    _mx = _fl._xs_max_of_level(_num(_f.get('xsLevel')))
                _before = _num(_f.get('xsCurr'), -1)
                if _before < 0:
                    _before = _mx
                _f['xsCurr'] = _mx
                _f['xsLast'] = int(time.time())
                _f['xsRecoverStart'] = 0
                _fl._save(ctx, _f)
                _mark(st, '回神丹礼包 → 心神回满 %d→%d' % (_before, _mx))
                # ★ 展示字段：客户端 `v40_show_rewards` 认 net_attrTab 的中文名表
                payload = {'item1': {}, 'item2': {}, 'net_attrTab': {},
                           'loc_attrTab': {}, 'skillTab': []}
                _save(ctx, st)
                return ctx.ok(payload, '★ 回神丹礼包：心神已回满（%d/%d）' % (_mx, _mx))
            except Exception as _xe:                        # noqa: BLE001
                ctx.log('回神丹礼包生效失败：%s' % _xe)
    if box_key in ('testpack_dreamsupply', 'testpack_dreamtreasure', 'testpack_dreamlamp'):
        # ★ 梦境盒在**使用时**发货（buy 只卖盒），并回 item2 实名牌展示
        #   （item2=纯展示不入主背包；真货 pendingSupplies → 入梦/进下一层到账）。
        if box_key == 'testpack_dreamsupply':
            before = dict(st.get('pendingSupplies') or {})
            lines = _roll_dream_supplies(st)
            _after = st.get('pendingSupplies') or {}
            granted = {k: _i(_after.get(k), 0) - _i(before.get(k), 0)
                       for k in _after if _i(_after.get(k), 0) > _i(before.get(k), 0)}
            label = '梦境补给礼盒'
        elif box_key == 'testpack_dreamtreasure':
            before = dict(st.get('pendingSupplies') or {})
            lines = _grant_treasure_internal(st)
            granted = {k: _i(st.get('pendingSupplies', {}).get(k), 0) - _i(before.get(k), 0)
                       for k in ('drwp101', 'drwp102')}
            label = '梦境寻宝礼包'
        else:
            before = _i(st.get('pendingSupplies', {}).get(_DREAM_LAMP), 0)
            lines = _grant_lamp_internal(st)
            granted = {_DREAM_LAMP: _i(st.get('pendingSupplies', {}).get(_DREAM_LAMP), 0) - before}
            label = '续魂灯礼包'
        _save(ctx, st)
        names = _dream_supply_names()
        item2 = {}
        for iid, cnt in granted.items():
            if _i(cnt, 0) > 0 and iid != _DREAM_SUPPLY_CURRENCY:
                item2[iid] = min(_i(cnt, 0), 99)   # 展示上限 99，防弹屏
        payload = {'item1': {}, 'item2': item2, 'net_attrTab': {},
                   'loc_attrTab': {'1': 5000}, 'skillTab': []}
        return ctx.ok(payload, '★ %s：%s（碎银等下次入梦自动随行）'
                      % (label, '、'.join(lines) if lines else '已记'))
    if box_key is not None:
        # 其它梦境盒（遗留）：只弹经验不发货
        payload = {'item1': {}, 'item2': {}, 'net_attrTab': {},
                   'loc_attrTab': {'1': 5000}, 'skillTab': []}
        return ctx.ok(payload, '★ 梦境盒使用：梦中修炼经验')
    if _i(rid, 0) in _DREAM_BOX_SUIYIN:
        # ★ 梦内宝箱（见 _DREAM_BOX_SUIYIN 注释）：原「主世界属性行」改发**碎银**，
        #   走 loc_attrTab ⇒ 客户端 role:addAttr("dreamPoints", n) 真加+弹「碎银 +N」。
        lo, hi = _DREAM_BOX_SUIYIN[_i(rid, 0)]
        n = random.randint(lo, hi)
        payload = {'item1': {}, 'item2': {}, 'net_attrTab': {},
                   'loc_attrTab': {'21': n}, 'skillTab': []}
        _mark(st, '梦内宝箱 rewardId=%s → 碎银 +%d（原主世界属性行已改）' % (_s(rid), n))
        _save(ctx, st)
        return ctx.ok(payload, '★ 梦内宝箱：碎银 +%d' % n)
    if _i(rid, 0) in _DREAM_USE_ITEMS:
        role_attr = ctx.body_obj.get('roleAttr') if isinstance(ctx.body_obj, dict) else {}
        payload, item_name = _dream_use_item_payload(rid, role_attr)
        got = sum(payload['loc_attrTab'].values())
        _mark(st, '梦内消耗品 %s（rewardId=%s）→ 回复 %s' % (item_name, _s(rid), payload['loc_attrTab']))
        _save(ctx, st)
        return ctx.ok(payload, '★ %s：梦内消耗品 %s 按功效回气血/内力' % (ep, item_name))
    out = _expand_reward(rid)
    payload = _reward_payload(out)
    got = (sum(payload['item1'].values()) + sum(payload['item2'].values())
           + sum(payload['net_attrTab'].values()) + sum(payload['loc_attrTab'].values())
           + len(payload['skillTab']))
    if ep == 'get_fond_dream_reward':
        _mark(st, '南柯梦境奖励 rewardType=%s rewardId=%s → %d 项' % (rtype, _s(rid), got))
    else:
        _mark(st, '梦境网页奖励 rewardType=%s rewardId=%s → %d 项' % (rtype, _s(rid), got))
    _save(ctx, st)
    if got <= 0:
        # 她 `getReward` 对空表是安全的（`MapIsEmpty` 全挡）；但让她知道这条 id 没内容
        return ctx.ok(payload, '★ %s：rewardId=%s 在 Rewards.lua 里没有可发的内容'
                      % (ep, _s(rid)))
    return ctx.ok(payload, '★ %s：rewardId=%s（%d 项，取自 Rewards.lua）'
                  % (ep, _s(rid), got))


# ===========================================================================
# 五、楼层 / 副本结算共用的数据
# ===========================================================================
def _role_attr(ctx):
    """上行 `roleAttr`（她 `Role:getTrimData()` 的整表）。探针没有正文时回 `{}`。"""
    body = ctx.body_obj if isinstance(ctx.body_obj, dict) else {}
    ra = body.get('roleAttr')
    if isinstance(ra, dict):
        return ra
    return {}


def _floor_of(role_attr, st):
    dw = role_attr.get('dreamWorld') if isinstance(role_attr, dict) else None
    if isinstance(dw, dict):
        f = _i(dw.get('cFloor'), 0)
        if f > 0:
            return min(f, MAX_FLOOR)
    f = _i(role_attr.get('cFloor'), 0) if isinstance(role_attr, dict) else 0
    if f > 0:
        return min(f, MAX_FLOOR)
    return max(1, min(_i(st.get('floor'), 1) or 1, MAX_FLOOR))


def _add_pijuan(floor):
    """每层疲倦值增量（她表里没有这项，见模块 docstring）。"""
    return max(1, PIJUAN_PER_FLOOR * (1 + floor // 20))


def _events_info(st):
    """`handlDreamOperationEvent` 只认 `event.type` 与 `event.id`（她 :1535-1565）。

    `type` 取值 = `DreamConst.OpertionEventName`（`unlockTalent` / `upgradeTalent`）。
    """
    out = []
    for e in _list(st.get('events')):
        if not isinstance(e, dict):
            continue
        t = _s(e.get('type'))
        if t not in ('unlockTalent', 'upgradeTalent'):
            continue
        i = _i(e.get('id'), 0)
        if i <= 0:
            continue
        row = {'type': t, 'id': i, 'count': _i(e.get('count'), 1),
               'currency': _s(e.get('currency'), 'dreamCoins'),
               'cost': _i(e.get('cost'), 0)}
        out.append(row)
    return out


def _record_events(st, events):
    """记她 `uploadEventRecord` 那三条（`upload_event_record` 不在本模块清单里，所以只能这样留痕）。"""
    store = st.setdefault('events', [])
    got = []
    for e in _list(events):
        if not isinstance(e, dict):
            continue
        t = _s(e.get('type'))
        if t not in ('unlockTalent', 'upgradeTalent'):
            continue
        i = _i(e.get('id'), 0)
        if i <= 0:
            continue
        row = {'type': t, 'id': i, 'count': _i(e.get('count'), 1),
               'currency': _s(e.get('currency'), 'dreamCoins'),
               'cost': _i(e.get('cost'), 0), 'ts': int(time.time())}
        store.append(row)
        got.append(row)
    del store[:-200]
    if got:
        st['dreamCoins'] = max(0, _i(st.get('dreamCoins'), 0)
                               - sum(_i(r.get('cost'), 0) for r in got))
    return got


def _talent_cost_sum(st):
    """已解锁天赋按她 `drtfmoney` 累加（`get_event_record.point` 的余量推算，不编数字）。"""
    tb = _talents()
    total = 0
    for e in _list(st.get('events')):
        if not isinstance(e, dict):
            continue
        if _s(e.get('type')) not in ('unlockTalent', 'upgradeTalent'):
            continue
        row = tb.get(_s(e.get('id')))
        if isinstance(row, dict):
            total += _i(row.get('drtfmoney'), 0)
    return total


def _yiyu_total(st):
    """结算梦内呓语 = 她"天随人愿"天赋各级文案里的额外值之和（见 `_yiyu_bonus`）。"""
    bonus = _yiyu_bonus()
    unlocked = set()
    for e in _list(st.get('events')):
        if isinstance(e, dict) and _s(e.get('type')) in ('unlockTalent', 'upgradeTalent'):
            unlocked.add(_s(e.get('id')))
    return sum(v[0] for k, v in bonus.items() if k in unlocked)


def _complete_reward(ctx, st, role_attr, fond, floor):
    """完成梦境/南柯棋局的奖励 —— 内容全部取自她的表。

    * 经验：`dreamfloorexp.lua` / `nanke/dreamworld/dreamfloorexp.lua` 该层 `floorexp`
    * 梦内呓语：`dreamtfskill.lua` "天随人愿" 各级 `drtftext` 里写明的额外值之和
    * 物品：`drUnit.lua` 里该层 NPC 的 `梦境获取奖励` id → `Rewards.lua` 展开
    """
    out = {'item1': {}, 'item2': {}, 'net_attrTab': {}, 'loc_attrTab': {}, 'skillTab': []}
    exp_table = _floor_exp(fond)
    exp = 0
    for v in exp_table.values():
        if not isinstance(v, dict):
            continue
        if _i(v.get('drfloor'), -1) != floor:
            continue
        if fond and _i(v.get('type'), 1) != _i(role_attr.get('chessType') if isinstance(role_attr, dict) else 1, 1):
            continue
        exp = _i(v.get('floorexp'), 0)
        break
    if exp > 0:
        out['net_attrTab'][_s(ATTR_NAME_TO_ID['exp'])] = exp
    yi = _yiyu_total(st)
    if yi > 0:
        out['net_attrTab'][_s(ATTR_NAME_TO_ID['dreamYiYu'])] = yi
        st['dreamYiYu'] = _i(st.get('dreamYiYu'), 0) + yi
    return out


# ===========================================================================
# 六、接口
# ===========================================================================
def _ep_get_dream_goods(ctx, st):
    """摘梦阁商品列表（她 `DreamStoreLayer:getDreamGoods` :45-68）。"""
    _sync_period(st)
    rows = _dream_store()
    raw = ctx.param('menpai') or ctx.param('menpaiId') or ''
    menpai = _s(raw)
    if not menpai:
        ra = _role_attr(ctx)
        fam = ra.get('family') if isinstance(ra, dict) else None
        if isinstance(fam, dict):
            menpai = _s(fam.get('name'))
        else:
            menpai = _s(ra.get('menpaiId') if isinstance(ra, dict) else '')
    out = []
    for k in sorted(rows.keys(), key=lambda x: _i(x, 0)):
        row = rows[k]
        if not isinstance(row, dict):
            continue
        only_id = _i(row.get('onlyId'), _i(k, 0))
        if only_id <= 0:
            continue
        mp = _s(row.get('menpai'))
        if mp and menpai and mp != menpai:
            # 她在 `createOneItemConfig` 里对"自己门派"给 UNOPEN（"你无需兑换你的师门武学"）
            out.append({'onlyId': only_id, 'number': _i(row.get('number'), 1),
                        'count': _goods_stock(st, only_id, row), 'state': UNOPEN})
            continue
        left = _goods_stock(st, only_id, row)
        out.append({'onlyId': only_id, 'number': _i(row.get('number'), 1),
                    'count': left, 'state': BOUGHT if left <= 0 else CANBUY})
    st['dreamYiYu'] = _i(st.get('dreamYiYu'), 0)
    _mark(st, '摘梦阁列表 %d 项（期数 %s，呓语 %d）'
             % (len(out), st.get('period'), st['dreamYiYu']))
    _save(ctx, st)
    return ctx.ok({
        'period': _i(st.get('period'), _period_now()),
        'expired_time': _expired_time(),
        'dreamYiYu': st['dreamYiYu'],
        'list': out,
    }, '★ 摘梦阁商品列表（%d 项，取自 dreamzhaimengge.lua）' % len(out))


def _ep_buy_dream_goods(ctx, st):
    """购买摘梦阁商品（她 `DreamStoreLayer:buyItem` :234-275）。"""
    only_id = _i(ctx.param('onlyId'), _i(ctx.args[0] if ctx.args else 0, 0))
    period = _i(ctx.param('period'), 0)
    rows = _dream_store()
    row = None
    for k, v in rows.items():
        if isinstance(v, dict) and _i(v.get('onlyId'), _i(k, 0)) == only_id:
            row = v
            break
    if row is None:
        return ctx.fail('商品不存在', '★ 摘梦阁：onlyId=%d 不在 dreamzhaimengge.lua' % only_id, 1)
    if period and period != _i(st.get('period'), 0):
        # 她 :256 `errcode==2` ⇒ 重新拉 `getDreamGoods` 再弹字（跨期正常门）
        _sync_period(st)
        _save(ctx, st)
        return ctx.fail('商品期数已更新，请重新选择', '★ 摘梦阁：期数过期（她重拉列表）', 2)
    _sync_period(st)
    left = _goods_stock(st, only_id, row)
    if left <= 0:
        return ctx.fail('该物品已没有剩余兑换数量，请更换.', '★ 摘梦阁：onlyId=%d 本期已兑完' % only_id, 1)
    cost = _i(row.get('price'), 0)
    have = _i(st.get('dreamYiYu'), 0)
    if have < cost:
        return ctx.fail('梦内呓语不足', '★ 摘梦阁：梦内呓语 %d < %d' % (have, cost), 1)
    st['dreamYiYu'] = have - cost
    goods = st.setdefault('goods', {})
    goods[_s(only_id)] = _i(goods.get(_s(only_id)), 0) + 1
    _mark(st, '摘梦阁兑换 onlyId=%d(%s) 花 %d，余 %d，剩 %d 次'
             % (only_id, _s(row.get('name')), cost, st['dreamYiYu'], left - 1))
    _save(ctx, st)
    return ctx.ok({
        'dreamYiYu': st['dreamYiYu'],
        'cost': cost,
        'onlyId': only_id,
        'count': left - 1,
    }, '★ 摘梦阁兑换 %s：-%d 梦内呓语' % (_s(row.get('name')), cost))


def _ok2(ctx, data, note):
    """errcode=2 + data 应答（她 `dream_floor_complete` errcode==2 分支：
    player:destory() + createDreamRoleWithData(data.roleAttr) —— 用来让待发补给
    在进入下一层时立刻出现在梦内背包）。"""
    import time
    return ctx.enc({'errcode': 2, 'data': data, 'rand_t': time.time()}), note


def _ep_dream_floor_complete(ctx, st):
    """梦境楼层结算（她 `DreamSystem.lua:1382-1412`）。"""
    ra = _role_attr(ctx)
    if not ra:
        return ctx.fail('缺少梦境人物数据', '★ 梦境楼层结算：上行没有 roleAttr', 1)
    floor = _floor_of(ra, st)
    st['roleAttr'] = ra
    st['floor'] = floor
    st['pijuan'] = _i(st.get('pijuan'), 0) + _add_pijuan(floor)
    ev = _events_info(st)
    pend = st.get('pendingSupplies')
    if isinstance(pend, dict) and pend:
        # ★ 2026-10-07 待发补给并入上传的 roleAttr 后走 errcode=2：
        #   客户端销毁当前梦内人物、按合并后数据重建 ⇒ 补给**进下一层即刻在背包**。
        #   （新鲜梦第 1 层没有注入点，第 1 层打完进第 2 层时到账。）
        _n, _desc = _merge_pending_supplies(ra, st)
        _mark(st, '楼层 %d 结算补给并入：%s' % (floor, _desc))
        _save(ctx, st)
        return _ok2(ctx, {'eventsInfo': ev, 'roleAttr': ra,
                          'addPijuan': _add_pijuan(floor)},
                    '★ 梦境第 %d 层结算 + 补给并入（errcode=2 重建）' % floor)
    _mark(st, '梦境第 %d 层结算（事件 %d 条，疲倦值 %d）' % (floor, len(ev), st['pijuan']))
    _save(ctx, st)
    return ctx.ok({
        'eventsInfo': ev,
        'addPijuan': _add_pijuan(floor),
    }, '★ 梦境第 %d 层结算（eventsInfo 取自本模块记录的天赋事件）' % floor)


def _ep_dreamworld_complete(ctx, st):
    """梦境副本结算（她 `DreamSystem:mapComplete` :1423-1503）。"""
    ra = _role_attr(ctx)
    floor = _floor_of(ra, st)
    if ra:
        st['roleAttr'] = ra
    st['floor'] = floor
    st['pijuan'] = _i(st.get('pijuan'), 0)
    out = _complete_reward(ctx, st, ra, False, floor)
    payload = _reward_payload(out)
    # ★★ 2026-10-08 老板实测拍板：结算**退余财**（剩余碎银 + 未用三钥 → 下次入梦随行）。
    _back, _backlines = _return_leftovers(st, ra)
    # ★★ 2026-10-07 客户反馈"梦境不能重置，打死好几次一直卡着"：
    #   结算后**删档**（st['roleAttr'] 清空）——她原版规则：结算（含死亡强制结算/
    #   主动离开/超时）后下次入梦从第一层开新梦。此前我们永不清档 ⇒ get_dream_role
    #   永远回旧档（同层+空血）⇒ 死循环。死亡流程 BaseMap.__playerDie → mapComplete
    #   → 本接口 ⇒ 删档即解。
    st['roleAttr'] = None
    st['floor'] = 0
    _mark(st, '梦境第 %d 层副本结算（呓语 %d，属性 %s）——已删档，下次入梦第一层'
             % (floor, _i(payload['net_attrTab'].get(_s(ATTR_NAME_TO_ID['dreamYiYu'])), 0),
                payload['net_attrTab']))
    _save(ctx, st)
    return ctx.ok({
        'eventsInfo': _events_info(st),
        'reward': payload,
    }, '★ 梦境副本结算（奖励取自 dreamfloorexp.lua + dreamtfskill.lua；已删档重置%s）'
       % ('；退回余财：' + '、'.join(_backlines) if _backlines else ''))


def _ep_get_dream_role(ctx, st):
    """获取梦境人物数据（她 `DreamRoleModel:getDreamRoleFromWeb` :4-30）。

    ★ `data` 本身就是梦境人物整表（她 `createDreamRoleWithData(data)`）。
      服务端没接管 `upload_dream_role` ⇒ 只能回本模块存下来的那份；
      没有就按她的约定回 `errcode=2`（她走"开新梦"正常流程，不是崩）。
    """
    ra = st.get('roleAttr')
    if not isinstance(ra, dict) or not ra:
        return ctx.fail('没有进行中的梦境数据', '★ 梦境人物：无存档（她开新梦）', 2)
    _n, _desc = _merge_pending_supplies(ra, st)
    if _n:
        _mark(st, '入梦补给并入： %s' % _desc)
        _save(ctx, st)
    return ctx.ok(ra, '★ 梦境人物数据（本模块存档，楼层 %s）'
                  % _i((ra.get('dreamWorld') or {}).get('cFloor'), 0))


def _ep_upload_dream_role(ctx, st):
    """梦境人物上传（**入梦钩子**，`XiangLuModel.lua:125` 床上休息入梦时调用；
    `HttpManager:3220`：POST `{roleAttr}`）。

    ★★ 2026-10-08 "进梦即得"（老板要求）：客户端入梦流程=创建新梦角色 → 上传 →
      按应答处理：**errcode==2 ⇒ `role:destory()` + `createDreamRoleWithData(data)`**
      （她自己 :150-170 的分支）。所以这里把待发补给（pendingSupplies）并入上传的
      roleAttr 并回 **errcode=2 + data=梦内人物整表** ⇒ 客户端立即用合并后的数据
      重建梦内人物 ⇒ **补给在进入梦境的瞬间就进梦内背包**（不必打完一层/不必退出）。
      无待发补给时回 errcode=0（客户端照常走本地新角色）。

    ★★ 2026-10-08 二次修正（BOSS 实测"退出梦境弹网络错误，请重试"实锤根因）：
      她客户端 `XiangLuModel.lua:150-170` / `TestLayer.lua:2310` 的 errcode==2 分支
      是 **`createDreamRoleWithData(data)`——期望 `data` 就是梦内人物整表本身**
      （与 `get_dream_role` 的 data 同形），且 `addPijuan` 是**同一张表的兄弟键**
      （她随后 `addPijuanFunc(data.addPijuan)` 也从这张表读）。
      此前把应答包成 `{roleAttr: ...}` ⇒ 她 `Helper:tableCover(role, data)` 把
      wrapper 原样拷进角色对象（属性、背包全在子表里）⇒ 重建出的梦内人物
      **dreamPoints=nil 且无属性**；退出结算时 `printRoleInfo` 里
      `"..role.dreamPoints` 抛 Lua 错（logcat 实锤 `DreamSystem.lua:1528:
      attempt to concatenate field 'dreamPoints' (a nil value)`）⇒ 回调不返回 true
      ⇒ Http 层弹"网络错误, 请重试"并**点重试无限复读**（老板 18:59 现场）。
      修法：errcode=2 的 data 直接给 roleAttr 整表 + `addPijuan` 兄弟键。
      （对照：`dream_floor_complete` 的 errcode=2 才是 `data.roleAttr` 包装形——
      两个接口形状不同，别写串。）
    """
    ra = _role_attr(ctx)
    if not isinstance(ra, dict) or not ra:
        return ctx.ok({'ok': 0}, '★ upload_dream_role：无 roleAttr')
    pend = st.get('pendingSupplies')
    if isinstance(pend, dict) and pend:
        merged, desc = _merge_pending_supplies(ra, st)
        st['roleAttr'] = ra
        _save(ctx, st)
        if merged:
            _mark(st, '入梦补给并入（errcode=2 重建）：%s' % desc)
            # 防呆：重建出的梦内人物必须有 dreamPoints 数值（她退出结算会直接拼串打印）
            ra['dreamPoints'] = _num(ra.get('dreamPoints'), 0)
            ra['addPijuan'] = 0
            return _ok2(ctx, ra, '★ 入梦即刻到账：%s' % desc)
        return ctx.ok({'ok': 1}, '★ 梦境人物上传已存')
    st['roleAttr'] = ra
    _save(ctx, st)
    return ctx.ok({'ok': 1}, '★ 梦境人物上传已存')


def _ep_get_event_record(ctx, st):
    """获取事件记录（她 `DreamTalentModel:getWebTalentData` :565-601）。

    读 `data.params`(数组) 与 `data.point`(数字)。`point` = 她天赋表 `drtfmoney`
    的"已解锁累计花费"推算出来的余量（本模块不编币值）。
    """
    params = _events_info(st)
    point = max(0, _i(st.get('dreamCoins'), 0) - _talent_cost_sum(st))
    st['dreamCoins'] = point
    _save(ctx, st)
    return ctx.ok({
        'params': params,
        'point': point,
    }, '★ 梦境事件记录（%d 条，梦境币 %d）' % (len(params), point))


def _ep_upload_event_record(ctx, st):
    """天赋解锁/升级上报（她 `DreamTalentModel:unlockTalent/upgradeTalent` :321-383）。

    上行：`{params: [{type,id,count,currency,cost}, ...]}`（`HttpManager.lua:3276-3279`）；
    她只认 `errcode==0`（拿到 0 才本地扣币+加天赋，`data` 不读）。
    ★ 2026-10-06 修复"解锁天赋返回就消失/梦境币负数"：此前本接口没接管（404 宽容兜底
      碰巧回 0？）⇒ 事件不持久。现在 `_record_events` 落账（事件+扣币），
      余额由 `_load` 保底 99999999，永远扣不完。
    """
    params = ctx.param('params')
    got = _record_events(st, params)
    _mark(st, '天赋上报 %d 条（事件 %d，币 %d）'
             % (len(_list(params)), len(got), _i(st.get('dreamCoins'), 0)))
    _save(ctx, st)
    return ctx.ok({}, '★ upload_event_record：记 %d 条天赋事件' % len(got))


def _ep_fond_floor_complete(ctx, st):
    """南柯梦境楼层结算（她 `FondDreamSystem:enterNextMap` :193-222）。

    ★ 她**不读** `eventsInfo`；只认 `errcode`，`errcode==2` 时读 `data.roleAttr`。
    """
    ra = _role_attr(ctx)
    if not ra:
        return ctx.fail('缺少梦境人物数据', '★ 南柯楼层结算：上行没有 roleAttr', 1)
    floor = _floor_of(ra, st)
    st['fondRoleAttr'] = ra
    st['floor'] = floor
    _mark(st, '南柯第 %d 层结算' % floor)
    _save(ctx, st)
    return ctx.ok({}, '★ 南柯第 %d 层结算' % floor)


def _ep_fond_dreamworld_complete(ctx, st):
    """南柯棋局结算（她 `FondDreamSystem:mapComplete` :225-264）。"""
    ra = _role_attr(ctx)
    floor = _floor_of(ra, st)
    if ra:
        st['fondRoleAttr'] = ra
    out = _complete_reward(ctx, st, ra, True, floor)
    payload = _reward_payload(out)
    # ★ 2026-10-07 同梦境结算：结算后删 fondRoleAttr（下次开新棋局）
    st['fondRoleAttr'] = None
    st['floor'] = 0
    _mark(st, '南柯第 %d 层棋局结算（属性 %s）——已删档' % (floor, payload['net_attrTab']))
    _save(ctx, st)
    return ctx.ok({'reward': payload},
                  '★ 南柯棋局结算（奖励取自 nanke/dreamworld/dreamfloorexp.lua；已删档重置）')


def handle(ctx):
    ep = ctx.endpoint
    if ep not in ENDPOINTS:
        return None
    st = _load(ctx)
    if ep == 'get_dream_goods':
        return _ep_get_dream_goods(ctx, st)
    if ep == 'buy_dream_goods':
        return _ep_buy_dream_goods(ctx, st)
    if ep == 'dream_floor_complete':
        return _ep_dream_floor_complete(ctx, st)
    if ep == 'dreamworld_complete':
        return _ep_dreamworld_complete(ctx, st)
    if ep == 'get_dream_role':
        return _ep_get_dream_role(ctx, st)
    if ep == 'get_event_record':
        return _ep_get_event_record(ctx, st)
    if ep == 'upload_event_record':
        return _ep_upload_event_record(ctx, st)
    if ep == 'upload_dream_role':
        return _ep_upload_dream_role(ctx, st)
    if ep == 'fond_dream_floor_complete':
        return _ep_fond_floor_complete(ctx, st)
    if ep == 'fond_dreamworld_complete':
        return _ep_fond_dreamworld_complete(ctx, st)
    if ep == 'get_fond_dream_reward':
        return _web_reward(ctx, st, ep)
    if ep == 'get_web_reward':
        return _web_reward(ctx, st, ep)
    return None
