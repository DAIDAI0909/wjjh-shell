# -*- coding: utf-8 -*-
# ================= 离线包路径根（fz_make_offline_bundle.py 自动注入） =================
# 手机上整个服务端就是一个目录，表在哪、状态写哪，全部相对包根算。
# （有的模块原来把绝对路径写死，本身没 import os —— 这里一并补上）
import os
import os as _osp


def _off_find_bundle(_f):
    """从模块所在目录往上找包根（认 fz_boot_server.py）。
    ★ fz_api/*.py 的 __file__ 在 <根>/fz_api/ 下，直接 dirname 会算错一层。"""
    _d = _osp.path.dirname(_osp.path.abspath(_f))
    for _ in range(6):
        if _osp.path.exists(_osp.path.join(_d, 'fz_boot_server.py')):
            return _d
        _u = _osp.path.dirname(_d)
        if _u == _d:
            break
        _d = _u
    return _osp.path.dirname(_osp.path.abspath(_f))


_OFF_BUNDLE = _off_find_bundle(__file__)
_OFF_FZ_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_fz')
_OFF_INK_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_ink')
_OFF_WORK_ROOT = _OFF_BUNDLE
# =====================================================================================
# ★ 2026-10-04 商城空货架修复：客户端资源表解析——PC 开发树优先，设备上自动回退
#   到包内 client_fz 副本（jhserver/client_fz = fangzhi_lua_dec 的同步拷贝）。
def _fz_res(*parts):
    base = os.path.join(_OFF_FZ_ROOT, 'res', 'script')
    if not os.path.isdir(base):
        base = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            '..', 'client_fz', 'res', 'script')
    return os.path.join(base, *parts)

# -*- coding: utf-8 -*-
"""家园「生活系统」—— 购地/地契/地税、银票兑换、车夫出行、日常事务。

契约全部从她 `assets/src` 里的 lua 逐行读出来（见下），内容一律取她自己的资源表。

== 接口 → 她读哪些 `data.字段` ==

| 接口 | 契约出处（行号） | 客户端读的字段（类型） |
|---|---|---|
| `get_manage_payment/<dpId>` | `DiQiModel:checkManagementCost` :160-184 | `data.day`(数字) `data.total_pay`(数字) |
| `recycle_land`                | `DiQiModel:recycleLand` :339-357 | 只读 errcode |
| `move_home_land`              | `DiQiModel:moveHomeland` :224-282 | 只读 errcode |
| `bidding_land`                | `BiddingLayer:initBiddingBtn` :86-135 | errcode0 → `data.remove_point`(数字) `data.surplusTime`(数字,可省)；errcode2 → `data.high_price`(数字) `data.high_name`(字符串) |
| `query_bidding_info`          | `BiddingQueryLayer:showLayer` :33-64 | `data.list`(数组，元素 `{dpId,bid_state,high_price,return_point,surplusTime,dsc}`) `data.point`(数字) |
| `get_bidding_land`            | `BiddingQueryLayer` :145-176 | 只读 errcode |
| `get_bidding_return_point`    | `BiddingQueryLayer` :198-220 | `data.return_point`(数字) |
| `get_land_store_list`         | `BuyLandLayer:showLayer` :52-86 | `data.list`(数组，喂 `BuyLandModel:initData`→`Helper:tableCover(v,dpInfo)`，故每条须带 `dpId` 与她地皮表的 `name/color/cost`) `data.hasLand`("Y"/"N") `data.point`(数字) |
| `exchange_yinpiao`            | `HomelandModule` 条件结果 `[银票票据兑换]` :237-270 / `[元宝兑换银票]` :272-354 | `data.get_yinpiao`(数字，两处都读) `data.next_yuanbao`(数字，仅元宝分支读) |
| `get_location_max`            | `HomelandModule` 条件结果 `[车夫出行]` :151-178 | `data.max`(**数组**，`#data.max == 4`，元素参与 `..` 拼串 ⇒ 必须是数字/字符串) |
| `add_currency_number`         | `TaskModule` :959-993 | `data.currency`(**对象**：`{币种 = {value = 数字}}`；`for c,v in pairs(data.currency)` 且读 `v.value`) |
| `update_currency_by_type`     | `TaskModule` :461 / `BaseTask` :1610 / `HomelandModule→ServantModule` :381 | 只读 errcode（`data` 不取字段） |
| `test_homeland/<type>`        | `HttpManager:testHomeland` :2624（type 7=地皮缴费状态 / 8=地皮回收状态） | 只读 errcode |

== 内容取自她哪张表 ==
* `res/script/others/familylist.lua` 的 `["房屋地皮"]`（1088 条）→ 购地列表 / 竞价 / 地税单价
  真键 `dpId`（形如 `yangzhou001`），字段 `name/place/color/cost/startprice/fbId/dsc/roomdsc`
* 同上 `["房契模板"]`（152 条）→ 搬入后的房契 `fqId`
* 同上 `["种植表"]`（27 条）→ 作物真键 `Plantid`(`zhongzhi001`…) / 种子 `lvfei001` /
  产物 `Getitem`(`tianchan001` `duyaoyc009`…) / `Growtime` `Growtype` `getvalue`
* `res/script/dreamworld/dreamcenser.lua` 的 `["炉"]` / `["香"]` → 香炉真键 `xlid`
  (`drxianglu01`…) / 香真键 `drxiangid`(`drxiang01`…) / `rxtime` `drgl`

== 状态（真写盘）==
`work/homeland_life_state.json` —— 地契 / 竞价 / 地税 / 已搬入地皮 / 账目流水
（`xianglu` 预留槽：她点燃香走的是 `uploadFurnitureExtra`，已由
`fz_api/homeland_furniture.py` 接管，本模块不抢）。
币种（银票/元宝）与 `fz_boot_server.py:_home_load()` 共用 `work/homeland_state.json`
（她的 `view_currency_by_type` 就是读那里，本模块读改写回，不新造第二份钱）。

== ⚠ 已知路由重叠（并行开发撞车，留给人合并）==
`fz_api/homeland_land.py`（NAME=`homeland_land`）也声明了本模块的
`get_land_store_list / bidding_land / get_bidding_land / query_bidding_info /
get_bidding_return_point / recycle_land / get_manage_payment / move_home_land /
get_location_max`。`fz_api.dispatch()` 按模块名排序取**第一个不返回 None** 的，
`homeland_land` < `homeland_life` ⇒ 这 9 个接口线上先走它。本模块的那 9 个
（另有 `exchange_yinpiao` / `add_currency_number` / `update_currency_by_type` /
`test_homeland` 四个不冲突）都逐条过了直接调用测试，作为可用备份保留。

== 已知没做（不在本模块，或她客户端本来就没接口）==
1. **种植/收获/施肥、做饭、赊盐宽贷**：她客户端**没有对应 HTTP 接口**——
   `SeedModel:seed/harvest/tendLand`（`HomelandModel/SeedModel.lua`）直接改
   `role:setHomelandAttr("plant")` 本地存档；`ServantModule.doResult["做饭"]` :180-255
   直接 `role:setHomelandAttr("dinner",…)`；`SheYankuanDaiLayer` 是通用物品选择框
   （`class("SheYanKuanDaiLayer", cc.Layer)`，`setList` 读条目的 `data.id/data.name`），
   药农/掌药弟子靠 `canSale`+`saleList`(`fb38r31_1` = `yao108;yao109`) 走通用买卖。
   这些随 `role:getHomelandAttr` 一起由 `uploadUserData` 存档，服务端只须别丢档。
2. `get_affair_list`（信差/日常事务）已由 `fz_api/homeland_furniture.py` 接管。
3. 派遣任务（`派遣表`/`派遣事件列表`）属管家系统，不在本模块。
"""
import os
import json
import time

NAME = 'homeland_life'
TITLE = '家园·种植/做饭/香炉/药农/赊盐'
ENDPOINTS = [
    # ★★ 归属说明（并行开发撞过一次车）：
    #   **地皮/竞价/地税/搬家**这 9 个接口由 `fz_api/homeland_land.py` 负责（它按地皮主题写的，
    #   实测 4 个关键接口都正常：`bidding_land`/`get_bidding_land`/`move_home_land`/`get_land_store_list`）。
    #   本模块**不再重复声明**它们 —— 重复声明只会让模块名靠前的那个生效、另一个变死代码，
    #   而且掩盖真正的问题（`fz_api.load_modules()` 现在会打印撞车警告）。
    #   原先写在这里的那 9 个实现仍保留在文件里（作为参考/备用），只是不注册。
    #
    # 本模块真正负责的：银票兑换 / 车夫出行上限 / 通用货币增减 / 家园区测试位
    'test_homeland',
]

STATE = 'homeland_life_state.json'      # 本模块独占（地契/竞价/地税/香炉账）
HOME_STATE = 'homeland_state.json'      # 与宿主服务端共用的钱袋子

RES = _fz_res()
FAMILYLIST = RES + r'/others/familylist.lua'
DREAMCENSER = RES + r'/dreamworld/dreamcenser.lua'

LAND_PAGE = 10                          # 一页货架 10 块地皮（BukLandLayer 一屏 10 行）
BID_SECONDS = 24 * 3600                 # 竞价挂 1 天（她只把 surplusTime 和 GetTime() 相减）
DEED_SECONDS = 3 * 24 * 3600            # 地契有效期（`DiQiModel:getDiQi` 里 timeend = 3600*24*3）
MOVE_OVERDUE = 7 * 24 * 3600            # 领取后 7 天未搬入 → 回收（`AskToBuyLayer` expired_time）

YINPIAO_PER_YUANBAO = 10                # 元宝兑换银票比例（按客户端下发的 costYb 反算）
CHEQUE = {                              # `HomelandModule[银票票据兑换]` 的 homemoney 面额
    'homemoney200': 200, 'homemoney1500': 1500,
    'homemoney2500': 2500, 'homemoney5000': 5000,
}

_CACHE = {}


# --------------------------------------------------------------------------
# 小工具
# --------------------------------------------------------------------------


def _num(v, d=0):
    try:
        return float(v)
    except (TypeError, ValueError):
        return d


def _int(v, d=0):
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return d


def _lua_table(path, sheet=None):
    key = (path, sheet)
    if key not in _CACHE:
        try:
            import fz_luatable
            t = fz_luatable.load_lua_table(path)
            if sheet:
                t = t.get(sheet) or {}
            t = t if isinstance(t, dict) else {}
        except Exception:                   # noqa: BLE001
            t = {}
        _CACHE[key] = t
    return _CACHE[key]


def _lands():
    """她 `familylist.lua["房屋地皮"]`：1088 条真地皮（键是按序号排的 1..1088）。"""
    t = _lua_table(FAMILYLIST, '房屋地皮')
    rows = [v for v in t.values() if isinstance(v, dict) and v.get('dpId')]
    rows.sort(key=lambda v: str(v.get('dpId')))
    return rows


def _land_by_dp(dp_id):
    for v in _lands():
        if str(v.get('dpId')) == str(dp_id):
            return v
    return None


def _plants():
    """她 `familylist.lua["种植表"]`：27 条真作物，键 = `zhongzhi001`…（= 种子 itemId）。"""
    t = _lua_table(FAMILYLIST, '种植表')
    return {str(v.get('Plantid')): v for v in t.values()
            if isinstance(v, dict) and v.get('Plantid')}


def _xiang_lu():
    """她 `dreamcenser.lua["炉"]`：4 个真香炉（`xlid` = drxianglu01…）。"""
    return _lua_table(DREAMCENSER, '炉')


def _xiang():
    """她 `dreamcenser.lua["香"]`：4 种真香（`drxiangid` = drxiang01…）。"""
    return _lua_table(DREAMCENSER, '香')


def _fq_by_dp(dp):
    """她 `familylist["房契模板"]`（152 条，键 = fqId 去掉城池前缀的数字，如 1→yangzhou001）。

    地皮 `changan184` 这种在房契模板里没有同名条目，就退化成房型名相近/第一条 —— 只要
    `fqId` 是她表里的真键（客户端 `FangQiModel` 会拿它去查房型）。
    """
    t = _lua_table(FAMILYLIST, '房契模板')
    dp_id = str(dp.get('dpId') or '')
    digits = ''.join(ch for ch in dp_id if ch.isdigit())
    for v in t.values():
        if isinstance(v, dict) and v.get('fqId') and str(v.get('fqId')) == dp_id:
            return v
    if digits:
        for k, v in t.items():
            if isinstance(v, dict) and str(k) == digits and v.get('fqId'):
                return v
        for v in t.values():
            if isinstance(v, dict) and v.get('fqId') and str(v.get('fqId')).endswith(digits):
                return v
    for v in t.values():
        if isinstance(v, dict) and v.get('fqId'):
            return v
    return {}


def _load_life(ctx):
    st = ctx.load_json(STATE, None)
    if not isinstance(st, dict):
        st = {}
    st.setdefault('lands', {})       # dpId -> {state, high_price, high_name, bidder, invest, deadline, taken}
    st.setdefault('deeds', [])       # 已领取未搬入的地契 {dpId, id, name, timeend}
    st.setdefault('moved', {})       # dpId -> {mid, fqId, last_pay}
    st.setdefault('tax', {})         # dpId -> {last_pay, paid, day}
    st.setdefault('currencyDelta', {})
    st.setdefault('xianglu', {})     # fid -> {xiangId, fireTime}
    st.setdefault('log', [])
    st.setdefault('counter', 0)
    return st


def _save_life(ctx, st):
    st['log'] = (st.get('log') or [])[-60:]
    ctx.save_json(STATE, st)
    return st


def _home(ctx):
    st = ctx.load_json(HOME_STATE, None)
    if not isinstance(st, dict):
        st = {}
    st.setdefault('currency', {'yinpiao': 200000, 'yuanbao': 99999, 'money': 200000})
    return st


def _home_save(ctx, st):
    ctx.save_json(HOME_STATE, st)
    return st


def _wallet(ctx, name):
    return int(_num((_home(ctx).get('currency') or {}).get(name), 0))


def _wallet_add(ctx, name, delta):
    """真扣/真加：写回 `work/homeland_state.json`（她的 view_currency_by_type 就读它）。"""
    st = _home(ctx)
    cur = st.setdefault('currency', {})
    cur[name] = int(_num(cur.get(name), 0)) + int(delta)
    _home_save(ctx, st)
    return int(cur[name])


def _note(st, text):
    st.setdefault('log', []).append({'t': int(time.time()), 'msg': text})


def _uid(ctx):
    return str(ctx.headers.get('userid') or ctx.param('userid') or 'me')


def _where(ctx):
    """`get_manage_payment/<dpId>` 是 GET（dpId 在 URL 尾段）；其余接口 dpId 在正文里。"""
    dp = str(ctx.param('dpId') or '')
    if dp:
        return dp
    for a in ctx.args:
        if a:
            return str(a)
    return ''


# --------------------------------------------------------------------------
# 地皮 / 竞价 / 地税
# --------------------------------------------------------------------------
def _bid(dp, st, now):
    """把一条地皮 + 运行时竞价状态拼成 `BuyLandLayer:bingRow` / `BiddingLayer` 认的行。

    她 `BuyLandModel:initData` 会 `Helper:tableCover(v, DiQiModel:getDpInfoById(v.dpId))`，
    所以行里只要带 `dpId` 和运行期字段，静态字段由 dpInfo 补。
    """
    dp_id = str(dp.get('dpId'))
    b = st['lands'].get(dp_id) or {}
    state = int(_num(b.get('state'), 1))            # 1 上架 / 2 竞拍中 / 3 已截止
    high = int(_num(b.get('high_price'), dp.get('startprice') or 0))
    if state == 2 and _num(b.get('deadline'), 0) and _num(b.get('deadline')) <= now:
        state = 3
    return {
        'dpId': dp_id,
        'state': state,
        'high_price': high,
        'high_name': b.get('high_name') or '',
        'surplusTime': int(_num(b.get('deadline'), now + BID_SECONDS)) if state == 2 else 0,
        'dsc': dp.get('dsc') or dp.get('roomdsc') or '',
        'index': 0,
        'type': '地契',
    }


def _store_page(rows, page):
    page = max(1, page)
    return rows[(page - 1) * LAND_PAGE: page * LAND_PAGE]


def _land_store(ctx, st):
    """`getLandStoreList(fbId, npcId)`：按 npc/地图分页发她真地皮。

    `BuyLandLayer:showLayer` 读 `data.list` / `data.hasLand` / `data.point`。
    """
    fb = str(ctx.param('fbId') or '')
    npc = str(ctx.param('npcId') or '')
    allrows = _lands()
    if fb:
        sub = [v for v in allrows if str(v.get('fbId') or '') == fb]
        allrows = sub or allrows
    if not allrows:
        return ctx.ok({'list': [], 'hasLand': 'N', 'point': _wallet(ctx, 'yinpiao')},
                      '★ 售地列表（她的房屋地皮表读不到）')
    # 按 npcId 稳定分片（同一个 NPC 每次看到同一页），按 URL/正文里的页码翻页
    pages = max(1, (len(allrows) + LAND_PAGE - 1) // LAND_PAGE)
    shard = (abs(hash(npc)) % pages) if npc else 0
    page = _int(ctx.param('page') or (ctx.args[1] if len(ctx.args) > 1 else 1), 1)
    page = max(1, min(pages, shard + max(0, page - 1) + 1))
    batch = _store_page(allrows, page)
    now = time.time()
    out = []
    for i, dp in enumerate(batch):
        row = _bid(dp, st, now)
        row['index'] = i + 1
        out.append(row)
    has_land = 'Y' if st.get('moved') else 'N'
    return ctx.ok({'list': out, 'hasLand': has_land, 'point': _wallet(ctx, 'yinpiao')},
                  '★ 售地列表（第 %d/%d 页，%d 块，她房屋地皮表）'
                  % (page, pages, len(out)))


def _query_bidding(ctx, st):
    """`querybiddingInfo`：她读 `data.list`（数组）和 `data.point`（数字）。"""
    now = time.time()
    rows = []
    for dp_id, b in list(st['lands'].items()):
        state = int(_num(b.get('state'), 1))
        if state not in (2, 3):
            continue
        if state == 2 and _num(b.get('deadline'), 0) and _num(b.get('deadline')) <= now:
            state = 3
            b['state'] = 3
        dp = _land_by_dp(dp_id) or {}
        row = {
            'dpId': dp_id,
            'bid_state': state,
            'high_price': int(_num(b.get('high_price'), dp.get('startprice') or 0)),
            'high_name': b.get('high_name') or '',
            'return_point': int(_num(b.get('invest'), 0)) if state == 3 else 0,
            'surplusTime': int(_num(b.get('deadline'), 0)) if state == 2 else 0,
            'dsc': (dp.get('dsc') or dp.get('roomdsc') or ''),
        }
        rows.append(row)
    _save_life(ctx, st)
    return ctx.ok({'list': rows, 'point': _wallet(ctx, 'yinpiao')},
                  '★ 竞价查询（%d 条在竞）' % len(rows))


def _bidding_land(ctx, st):
    """`biddingLand(dpId, npcId, price)` —— 真扣银票、真记最高价。

    errcode 0：出价成功，回 `data.remove_point`（这次扣了多少）+ `data.surplusTime`
    errcode 2：被别人抢先，回 `data.high_price` / `data.high_name` 让她刷新面板
    """
    dp_id = str(ctx.param('dpId') or '')
    price = int(_num(ctx.param('price'), 0))
    dp = _land_by_dp(dp_id)
    if dp is None:
        return ctx.fail('没有这块地皮。', '★ 竞价失败：dpId=%s 不在她的房屋地皮表' % dp_id)
    now = time.time()
    b = st['lands'].setdefault(dp_id, {'state': 1})
    cur = int(_num(b.get('high_price'), dp.get('startprice') or 0))
    mine = (not b.get('bidder')) or b.get('bidder') == _uid(ctx)
    if not mine and b.get('state') == 2:
        # 已被别人占着：她 errcode=2 → 用 data.high_price/high_name 刷新面板
        _save_life(ctx, st)
        return ctx.fail('当前最高价：%d（%s）' % (cur, b.get('high_name') or ''),
                        '★ 竞价被抢先 high=%d' % cur, errcode=2)
    if price <= cur:
        return ctx.fail('出价必须高于当前价%d银票。' % cur, '★ 竞价出价过低')
    wallet = _wallet(ctx, 'yinpiao')
    if wallet < price:
        return ctx.fail('银票不足，当前只有%d银票。' % wallet, '★ 竞价银票不足')
    _wallet_add(ctx, 'yinpiao', -price)
    b.update({
        'state': 2,
        'high_price': price,
        'high_name': str(ctx.headers.get('pkname') or ctx.param('name') or _uid(ctx)),
        'bidder': _uid(ctx),
        'invest': price,
        'deadline': int(now + BID_SECONDS),
        'taken': False,
    })
    st['counter'] = int(st.get('counter') or 0) + 1
    _note(st, '竞价 %s → %d 银票' % (dp_id, price))
    _save_life(ctx, st)
    return ctx.ok({'remove_point': price, 'surplusTime': b['deadline'],
                   'high_price': price, 'high_name': b['high_name']},
                  '★ 竞价成功（%s → %d 银票，剩 %d）' % (dp.get('name'), price, wallet - price))


def _get_bidding_land(ctx, st):
    """`getbiddingLand(dpId)` —— 竞拍成功领地契（同 `DiQiModel:getDiQi` 的 3 天有效期）。"""
    dp_id = str(_where(ctx) or ctx.param('dpId') or '')
    dp = _land_by_dp(dp_id)
    if dp is None:
        return ctx.fail('没有这块地皮。', '★ 领地契失败：dpId=%s' % dp_id)
    b = st['lands'].setdefault(dp_id, {})
    b['taken'] = True
    b['state'] = 0
    deed_id = 'dq_' + dp_id
    if not any(str(d.get('dpId')) == dp_id for d in st['deeds']):
        st['deeds'].append({
            'id': deed_id,
            'dpId': dp_id,
            'name': dp.get('name') or '',
            'color': dp.get('color') or 'HIW',
            'timeend': int(time.time() + DEED_SECONDS),
        })
    _note(st, '领取地契 %s' % dp_id)
    _save_life(ctx, st)
    return ctx.ok({'deed_id': deed_id, 'dpId': dp_id,
                   'name': dp.get('name') or '', 'timeend': int(time.time() + DEED_SECONDS)},
                  '★ 领取地契（%s）' % (dp.get('name') or dp_id))


def _get_bidding_return_point(ctx, st):
    """`getBiddingReturnPoint(dpId)` —— 她读 `data.return_point`（数字）并加到银票显示上。"""
    dp_id = str(_where(ctx) or ctx.param('dpId') or '')
    b = st['lands'].setdefault(dp_id, {})
    back = int(_num(b.get('invest'), 0))
    if back:
        _wallet_add(ctx, 'yinpiao', back)
    b.update({'state': 0, 'high_price': 0, 'high_name': '', 'invest': 0, 'deadline': 0})
    _note(st, '竞价返还 %s → %d 银票' % (dp_id, back))
    _save_life(ctx, st)
    return ctx.ok({'return_point': back}, '★ 领取返还银票（%d）' % back)


def _move_home_land(ctx, st):
    """`moveHomeland(dpId, mid)` —— 搬入地皮：记 mid/fqId 并起算地税。"""
    dp_id = str(ctx.param('dpId') or _where(ctx) or '')
    mid = str(ctx.param('mid') or '')
    dp = _land_by_dp(dp_id)
    if dp is None:
        return ctx.fail('没有这块地皮。', '★ 搬入失败：dpId=%s' % dp_id)
    fq = _fq_by_dp(dp)
    if not mid:
        mid = str(100 + (abs(hash(dp_id)) % 900))
    now = int(time.time())
    st['moved'][dp_id] = {'mid': mid, 'fqId': fq.get('fqId') or '',
                          'name': dp.get('name') or '', 'location': (dp.get('place') or '') + (dp.get('name') or ''),
                          'last_pay': now}
    st['tax'][dp_id] = {'last_pay': now, 'paid': 0, 'day': 0}
    st['deeds'] = [d for d in st.get('deeds') or [] if str(d.get('dpId')) != dp_id]
    _note(st, '搬入 %s（mid=%s fqId=%s）' % (dp_id, mid, fq.get('fqId')))
    _save_life(ctx, st)
    return ctx.ok({'mid': mid, 'fqId': fq.get('fqId') or '', 'dpId': dp_id,
                   'location': st['moved'][dp_id]['location'],
                   'remove_point': 0},
                  '★ 搬入新居（%s / fqId=%s）' % (dp.get('name') or dp_id, fq.get('fqId') or '?'))


def _recycle_land(ctx, st):
    """`recycleLand(dpId)` —— 逾期未搬入的地皮收回库存。"""
    dp_id = str(_where(ctx) or ctx.param('dpId') or '')
    st['deeds'] = [d for d in st.get('deeds') or [] if str(d.get('dpId')) != dp_id]
    b = st['lands'].get(dp_id)
    if b:
        b.update({'state': 1, 'high_price': 0, 'high_name': '', 'invest': 0,
                  'deadline': 0, 'taken': False, 'bidder': ''})
    _note(st, '地皮回收 %s' % dp_id)
    _save_life(ctx, st)
    return ctx.ok({'dpId': dp_id}, '★ 地皮回收（%s）' % dp_id)


def _manage_payment(ctx, st):
    """`getManagePayment/<dpId>` —— 她只读 `data.day`（欠费天数）和 `data.total_pay`（欠费总数）。

    单日地税 = 她地皮表的 `cost`（元宝/天）。超过 15 天没缴，`DiQiModel` 侧会提示将被收回。
    """
    dp_id = str(_where(ctx) or ctx.param('dpId') or '')
    dp = _land_by_dp(dp_id)
    cost = int(_num((dp or {}).get('cost'), 0))
    now = int(time.time())
    tax = st['tax'].setdefault(dp_id, {'last_pay': now, 'paid': 0, 'day': 0})
    last = int(_num(tax.get('last_pay'), now))
    day = int(max(0, (now - last) // (24 * 3600)))
    total = cost * day
    tax['day'] = day
    if total > 0:
        wallet = _wallet(ctx, 'yuanbao')
        if wallet >= total:
            _wallet_add(ctx, 'yuanbao', -total)
            tax.update({'last_pay': now, 'paid': int(_num(tax.get('paid'), 0)) + total, 'day': 0})
            _note(st, '缴清地税 %s（%d 元宝 / %d 天）' % (dp_id, total, day))
            day, total = 0, 0
        else:
            _note(st, '地税欠 %d 天 / %d 元宝（%s）' % (day, total, dp_id))
    _save_life(ctx, st)
    return ctx.ok({'day': day, 'total_pay': total, 'dpId': dp_id,
                   'unit': 'yuanbao', 'cost': cost},
                  '★ 地税欠费（%s：欠 %d 天 / %d 元宝）' % (dp_id or '?', day, total))


# --------------------------------------------------------------------------
# 日常：银票 / 车夫 / 通用货币 / 测试位
# --------------------------------------------------------------------------
def _exchange_yinpiao(ctx, st):
    """`exchangeYinPiao(number, type)` —— type `yuanbao` 走元宝兑换（回 next_yuanbao），
    type `cheque` 走银票票据兑换（`HomelandModule[银票票据兑换]`，只需 `get_yinpiao`）。"""
    number = int(_num(ctx.param('number'), 0))
    kind = str(ctx.param('type') or '').strip()
    low = kind.lower()
    if low in ('yuanbao', '2', '3', 'gold'):
        wallet = _wallet(ctx, 'yuanbao')
        cost = number if number > 0 else min(wallet, 50)
        if wallet < cost:
            return ctx.fail('元宝不足，当前只有%d元宝。' % wallet, '★ 兑换银票：元宝不足')
        add = max(1, cost) * YINPIAO_PER_YUANBAO
        left = _wallet_add(ctx, 'yuanbao', -cost)
        _wallet_add(ctx, 'yinpiao', add)
        _note(st, '元宝兑换银票：-%d 元宝 / +%d 银票' % (cost, add))
        _save_life(ctx, st)
        return ctx.ok({'get_yinpiao': add, 'next_yuanbao': left, 'costYb': cost},
                      '★ 元宝兑换银票（+%d 银票 / 余 %d 元宝）' % (add, left))
    # 票据兑换：客户端传的是 `result.arg2 - 1`（0..3），对应 homemoney200/1500/2500/5000
    order = ['homemoney200', 'homemoney1500', 'homemoney2500', 'homemoney5000']
    idx = number if 0 <= number < len(order) else 0
    key = kind if kind in CHEQUE else order[idx]
    add = CHEQUE.get(key, 200)
    _wallet_add(ctx, 'yinpiao', add)
    _note(st, '票据兑换银票：%s → +%d' % (key, add))
    _save_life(ctx, st)
    return ctx.ok({'get_yinpiao': add, 'next_yuanbao': _wallet(ctx, 'yuanbao'),
                   'homemoney': key},
                  '★ 银票票据兑换（%s → +%d 银票）' % (key, add))


def _location_max(ctx, st):
    """`getLocationMax(mapIndex)` —— 她读 `data.max` 后：

        limitCache = data.max
        if #limitCache ~= 4 then PopText("数据获取失败！") end
        CheFuQianWangLayer:setTotalList(startIndex, limitCache)
          → for i = startIndex, self._limitArray[n] do ... _totalList[n][i] ...

    ⇒ `max` 必须是**长度 4 的数组**，且每个数不能超过她
    `UserMapRelation` 里对应层级列表的长度（超了 `_totalList[n][i]` 是 nil ⇒ 崩）。
    她的四层真长度：cityAreaRelation=16 / cityDirRelation=20 / villageRelation=26 /
    villageAreaRelation=20。`startIndex` 默认 1，所以第 1 层必须先有空档。
    """
    idx = _int(ctx.args[0] if ctx.args else ctx.param('mapIndex') or 0, 0)
    caps = [16, 20, 26, 20]              # UserMapRelation 四层列表的真长度
    m = list(caps)
    m[0] = max(1, m[0])
    return ctx.ok({'max': m}, '★ 车夫可达村落上限（mapIndex=%d → %s）' % (idx, m))


def _add_currency_number(ctx, st):
    """`addCurrencyNumber(net_rewards, addType, type)` —— 她 `pairs(data.currency)` 并读 `v.value`。

    ⇒ `data.currency` 必须是**对象**：`{币种 = {value = 数字}}`（给数组/缺 value 都会崩）。
    """
    obj = ctx.body_obj or {}
    net = obj.get('net_rewards')
    if not isinstance(net, dict):
        net = {}
        for k in ('jiaozi', 'yinpiao', 'yuanbao', 'mingbi', 'money'):
            v = ctx.int_param(k, 0)
            if v:
                net[k] = v
    if not net:
        net = {'jiaozi': 50}
    add_type = str(obj.get('addType') or ctx.param('addType') or '')
    out = {}
    for name, val in net.items():
        amount = int(_num(val, 0))
        if not amount:
            continue
        total = _wallet_add(ctx, str(name), amount)
        out[str(name)] = {'value': amount, 'total': total, 'name': str(name)}
        _note(st, '发放 %s +%d（%s）' % (name, amount, add_type))
    _save_life(ctx, st)
    return ctx.ok({'currency': out, 'addType': add_type},
                  '★ 发放货币（%s：%s）' % (add_type or '-', ', '.join(out) or '无'))


def _update_currency_by_type(ctx, st):
    """货币变更。她客户端有**两种**真实上行格式，都得认（2026-10-02 修）。

    ★ 本函数目前是**未注册的备用代码**（ENDPOINTS 只挂了 test_homeland；
      线上 `update_currency_by_type` 由 `items_currency._ep_update_currency` 生效，
      它本来就认 A 格式）。要是哪天把本函数重新注册回 ENDPOINTS，
      必须保留这里的 A 格式分支，否则会踩下面的雷。

    A) `HttpManager:updateCurrencyByType / updateCurrencyByTable` 发的是
       `{action, currency={币种=count}, addType}` —— TaskModule / BaseTask /
       DispatchTaskUtils / ServantModule / HeroFeast / GM 面板等十几处活流程都在用。
       ★ 只认 B 格式的话，A 格式会掉进下面的"其它按设定覆盖"分支，把默认的
         `yinpiao` **清零**（派任务结算银票 → 钱袋银票归 0）。
    B) 旧文档格式 `{doType, name, count}`（个别系统调用）。
    """
    obj = ctx.body_obj or {}
    cur = obj.get('currency')
    if isinstance(cur, dict) and cur:
        action = str(ctx.param('action') or obj.get('action') or 'add').lower()
        sign = -1 if action in ('remove', 'sub', 'cost', 'reduce', '2') else 1
        results = {}
        for kind, cnt in cur.items():
            if isinstance(cnt, dict):
                cnt = cnt.get('value') if cnt.get('value') is not None else cnt.get('count')
            results[str(kind)] = int(_wallet_add(ctx, str(kind), sign * _num(cnt)))
        _note(st, '货币变更 %s %s' % (action or 'add', results))
        _save_life(ctx, st)
        first = next(iter(results))
        return ctx.ok({'number': results[first], 'currency_type': first,
                       'count': results[first], 'currency': results},
                      '★ 货币变更（%s %s）' % (action or 'add', results))
    do = str(ctx.param('doType') or obj.get('doType') or '')
    name = str(ctx.param('name') or obj.get('name') or 'yinpiao')
    count = int(_num(ctx.param('count') if ctx.param('count') is not None else obj.get('count'), 0))
    low = do.lower()
    if low in ('add', '1', 'income'):
        total = _wallet_add(ctx, name, count)
    elif low in ('remove', 'sub', '2', 'cost'):
        total = _wallet_add(ctx, name, -count)
    else:
        home = _home(ctx)
        home.setdefault('currency', {})[name] = count
        _home_save(ctx, home)
        total = count
    _note(st, '货币变更 %s %s %s → %d' % (do or 'set', name, count, total))
    _save_life(ctx, st)
    return ctx.ok({'number': total, 'currency_type': name, 'count': count},
                  '★ 货币变更（%s %s %+d → %d）' % (do or 'set', name, count, total))


def _test_homeland(ctx, st):
    """`testHomeland/<type>` —— 她的家园区测试位。

    type 7 = 地皮缴费状态（设 `datime`），8 = 地皮回收状态（设 `datime`），
    其余（1 一键忠诚 / 2 删人 / 3 解锁特性 / 4 清空家园数据）只回 errcode。
    """
    kind = str(ctx.args[0] if ctx.args else ctx.param('type') or '')
    obj = ctx.body_obj or {}
    dp_id = str(obj.get('dpId') or ctx.param('dpId') or '')
    datime = obj.get('datime', ctx.param('datime'))
    if kind == '7' and dp_id:
        st['tax'].setdefault(dp_id, {})['last_pay'] = int(_num(datime, time.time()))
        _note(st, 'test_homeland 设缴费状态 %s' % dp_id)
    elif kind == '8' and dp_id:
        st['lands'].setdefault(dp_id, {})['deadline'] = int(_num(datime, time.time()))
        _note(st, 'test_homeland 设回收状态 %s' % dp_id)
    else:
        _note(st, 'test_homeland type=%s' % (kind or '?'))
    _save_life(ctx, st)
    return ctx.ok({'type': kind, 'dpId': dp_id}, '★ 家园测试位（type=%s）' % (kind or '?'))


# --------------------------------------------------------------------------
# 入口
# --------------------------------------------------------------------------
def handle(ctx):
    ep = ctx.endpoint
    if ep not in ENDPOINTS:
        return None
    st = _load_life(ctx)

    if ep == 'get_manage_payment':
        return _manage_payment(ctx, st)
    if ep == 'get_land_store_list':
        return _land_store(ctx, st)
    if ep == 'query_bidding_info':
        return _query_bidding(ctx, st)
    if ep == 'bidding_land':
        return _bidding_land(ctx, st)
    if ep == 'get_bidding_land':
        return _get_bidding_land(ctx, st)
    if ep == 'get_bidding_return_point':
        return _get_bidding_return_point(ctx, st)
    if ep == 'move_home_land':
        return _move_home_land(ctx, st)
    if ep == 'recycle_land':
        return _recycle_land(ctx, st)
    if ep == 'exchange_yinpiao':
        return _exchange_yinpiao(ctx, st)
    if ep == 'get_location_max':
        return _location_max(ctx, st)
    if ep == 'add_currency_number':
        return _add_currency_number(ctx, st)
    if ep == 'update_currency_by_type':
        return _update_currency_by_type(ctx, st)
    if ep == 'test_homeland':
        return _test_homeland(ctx, st)
    return None


# --------------------------------------------------------------------------
# 只读体检（给人在 python 里核对她的表读得对不对，不参与路由）
# --------------------------------------------------------------------------
def _selftest():
    out = {'lands': len(_lands()), 'plants': len(_plants()),
           'xianglu': len(_xiang_lu()), 'xiang': len(_xiang())}
    dp = _lands()[0] if _lands() else {}
    out['land0'] = {k: dp.get(k) for k in ('dpId', 'name', 'cost', 'startprice', 'fbId')}
    pl = _plants()
    key = sorted(pl)[0] if pl else ''
    out['plant0'] = {k: (pl.get(key) or {}).get(k)
                     for k in ('Plantid', 'Plantname', 'Plantitem', 'Getitem', 'Growtime', 'Growtype')}
    out['xiang0'] = list(_xiang().values())[:1]
    return json.dumps(out, ensure_ascii=False)


if __name__ == '__main__':
    print(_selftest())
