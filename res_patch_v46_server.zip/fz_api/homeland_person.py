# -*- coding: utf-8 -*-
# ================= 离线包路径根（fz_make_offline_bundle.py 自动注入） =================
# 手机上整个服务端就是一个目录，表在哪、状态写哪，全部相对包根算。
# （有的模块原来把绝对路径写死，本身没 import os —— 这里一并补上）
import os
import os as _osp


def _off_find_bundle(_f):
    """从模块所在目录往上找包根（认 fz_boot_server.py）。
    ★ fz_api/*.py 的 __file__ 在 <根>/fz_api/ 下，直接 dirname 会算错一层。"""
    _d = _osp.path.dirname(_osp.path.abspath(_f))
    for _ in range(6):
        if _osp.path.exists(_osp.path.join(_d, 'fz_boot_server.py')):
            return _d
        _u = _osp.path.dirname(_d)
        if _u == _d:
            break
        _d = _u
    return _osp.path.dirname(_osp.path.abspath(_f))


_OFF_BUNDLE = _off_find_bundle(__file__)
_OFF_FZ_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_fz')
_OFF_INK_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_ink')
_OFF_WORK_ROOT = _OFF_BUNDLE
# =====================================================================================
# ★ 2026-10-04 商城空货架修复：客户端资源表解析——PC 开发树优先，设备上自动回退
#   到包内 client_fz 副本（jhserver/client_fz = fangzhi_lua_dec 的同步拷贝）。
def _fz_res(*parts):
    base = os.path.join(_OFF_FZ_ROOT, 'res', 'script')
    if not os.path.isdir(base):
        base = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            '..', 'client_fz', 'res', 'script')
    return os.path.join(base, *parts)

# -*- coding: utf-8 -*-
"""家园里的「人」—— 管家 / 仆人 / 门客 / 招募候选 / 派遣 / 赏赐打点。

契约全部从她 `assets/src` 里的 Lua 逐行读出来（行号见下），内容一律取她自己的资源表。

== 接口 → 她读哪些 `data.字段`（类型必须对，否则回调里被 xpcall 吞掉 ⇒ 客户端整体卡死）==

| 接口 | 契约出处 | 客户端读的字段 |
|---|---|---|
| `get_employee_list/{npcId}/{mid}` | `GuanJiaModel:initEmployList` :196 / `PuRenModel:initEmployList` :524 / `MenKeModel:initEmployList` :284 | `data.list`（**数组**，每条 `state`(数字，0=可雇) 与 `hid`(条目 id)，另有 `jobType/name/price/price_unit/modal/…`）；`data.shenshi`（**数组**，已用过的身世 id，门客/仆人靠它去重） |
| `save_employee_list` | `GuanJiaModel:refresh` :232 / `PuRenModel:refresh` :494 / `MenKeModel:refresh` :256 | 上行 `{type, npcId, list}`；应答 `data` **本身就是数组**（`for i = 1, #data` → `data[i].state`） |
| `add_employee` | `GuanJiaModel:employeeNpc` :332 / `PuRenModel:employeeNpc` :648 / `MenKeModel:employeeNpc` :422 / `HomelandRoleUtil:employeNpc` :937 / `GuanJiaModule["初始管家雇佣"]` :22 | 上行 `{hid, objId, mid, npcId, push_data}`；应答 `data.fjId`(字符串) `data.rwId`(字符串) `data.jobType` `data.name` `data.defaultZhongCheng`(数字)；**整条 `data` 直接喂** `HomelandRoleUtil:initHomelandMapRole` ⇒ 必须与 `roomperson` 里那条同形 |
| `delete_employee` | `HomelandRoleUtil:firedRole` :1171 | 只读 errcode |
| `get_employee_data` | `MapMeetUtil`（欧遇/串门）:450-483 | 整个 `data` 当一个人物对象：`data.modal`(mobanid，给错 `getMobanRoleAttr` 得 nil) `data.job`(=职业 id) `data.name` `data.defaultZhongCheng`(数字) |
| `update_employee_data` | `ChatModel:chat` :43 / `GuanJiaModule["管家交谈"]` :225 / `ServantRewardLayer:rewardFunc` :200 / `HomelandRoleUtil:addFidelityFree` :1276 | `data.defaultZhongCheng`(数字) `data.level_up`(**布尔**) `data.trait`(**表**，键 `trait1..3`) `data.day_limit`(数字，==1 表示本日闲聊到顶) `data.activity`(表) |
| `update_employee_extra` | `DispatchTaskManager:dispatchTask` :340（派遣）/ `ShenShiTask:unlockTask` :62 | `data` 不取字段（只看 errcode）；上行 `{mid, up_data = {{rwId, extra = {stay_room_time / shenshi_status}}}}` |
| `get_guaike_reward` | `JiangHuGuaiKeModel:getWinRewards` :204-268 | `data.yinpiao`/`data.yueli`/`data.weiwang`(数字) `data.activityItems`(**数组**，元素 `{itemId, num}`) `data.defaultZhongCheng`(数字) `data.level_up`(**布尔**) `data.trait`(表) |
| `get_shenshi_reward` | `ShenShiTask:rewardPayHalf` :363 / `rewardFreeDay` :393 / `MapOuYuModule` :139 | 只读 errcode（`type` 1=薪资减半 2=n 天免薪 3=武功等级增加） |
| `get_manage_payment/{dpId}` | `DiQiModel:checkManagementCost` :160-184 | `data.day`(**数字**) `data.total_pay`(**数字**) |
| `get_location_max/{mapIndex}` | `HomelandModule["车夫出行"]` :151-178 → `CheFuQianWangLayer:setTotalList` :100 | `data.max`（**数组，长度必须==4**，元素当数字/字符串用；`_totalList[n][i]` 靠它限界） |
| `settle_overdue_dream` | `XiangLuModel:297-319`（香炉/梦境入口） | errcode：0=结算过期梦境（读 `data.eventsInfo`/`data.reward`）、2=没有过期梦境、-2=作弊 |
| `check_goods_valid` | `BaseItem.lua:630` / `JiangHuGuaiKeModel:77` / `FestivalModule:680,2429,2826` / `ChongGuangDuiHuanLayer:153` | `data` **是表**，`for k,v in pairs(data)` 读 `v.itemId`(字符串) `v.number`(数字)⇒**绝不能只回 `{dataVer}`**（那样 `v` 是数字，`v.itemId` 直接崩） |

== `map_persons(ctx, mid)`（额外导出，给宿主 `get_user_map` 用）==
返回 `get_user_map` 应答里的 `roomperson` 数组。她 `UserMap:initUserMap` :182-207：
`for k,roleInfo in pairs(mapInfo.roomperson)` → `HomelandRoleUtil:initHomelandMapRole(roleInfo, map)`
（:266）→ 读 `rwId`(角色 id) / `fjId`(所在房间) / `job`(→ jobType) / `jobType` / `modal`(必须是
`familylist["人物模板设计"]` 里真有的 `mobanid`) / `name` / `sex` / `age` / `looks` / `character`
/ `defaultZhongCheng`(**数字，缺了 `getFidelityLv` 比较会崩**) / `shenShi`(**非管家必须有，
`addNormalCR` :293 会 `RoleLife:getLifeTitle` 断言**) / `trait1..3` / `mobanSkill`(表) / `extra`(表)
—— 然后按 `roleInfo.fjId` 塞进 `map.room[fjId].roleList`（**人真的站在屋里**）。
`fjId` 必须真的在那张 `maproom` 里（否则 `UserMap.lua:194` 报"房间ID不在副本内"）。
管家固定站**大门**那间（`roomType == "tsfangjian004"`，就是 `HomelandRoomUtil:getDaMenRoomId` :1041
认的那间）；其它职业按 `familylist["人物类型"].roomtyPe` 找对应房间（护院→大门、书童→书房、
绣女→饰品房、老农→田圃、厨子→厨房、铁匠→炼器房、陪练→练功房、门客→客房、仆人→下房），
家里没这种房间就退到大门之后第一间室内房。

== 内容取自她哪张表 ==
* `res/script/others/familylist.lua`
  * `["人物模板设计"]`（124 条）→ 真 `mobanid`(`moban001`…`moban158`)、`loyallv`、`menpai`(门派)、
    `lv/exp/qi/neili/str/con/dex/int/jiali/weapon/skill1..20/skillLv1..20/activeZhao*`
  * `["人物类型"]`（10 条）→ `peopletYpe`(职业 id)、`ages/sexs/looks/randlife(身世)/specialrand(特点)/
    roomtyPe(该职业该站哪间房)/hirevlaue(雇佣价系数)/talk1..8(她说的话)`
  * `["高级门客招募需求"]`（49 条，`moban067`…`moban115`）→ 门客只在这 49 个模板里出，
    否则她 `MenKeModel:checkCanEmployeeNpc` :553 的 `getConditionAttr` 返回 nil ⇒ 崩
  * `["派遣表"]`（41 条 `task1`…）/ `["派遣事件列表"]` → 派遣面板（客户端自己读，本模块只管把
    `extra.stay_room_time` 真写盘）
  * `["房屋地皮"]`（1088 条）→ `get_manage_payment` 的日单价 `cost`
* `res/script/others/familyspecial.lua`
  * `["trait"]`（327 条 `texing001`…）→ `trait1..3` 只用真 id，阈值取 `CharacteristicNeed`
    （她 `HomelandRoleUtil:getTexingList` :192 拼错了字段名 `Characteristicneed`，所以原版
    这句永远返回空 —— 这里按**设计意图**用正确的字段名，取 `attributeValue > 0` 的正向特点）
  * `["character"]`（`xingge001`…`xingge010` → 沉默寡言…活泼诙谐）、`["career"]`（10 种职业的
    忠诚成长/闲聊/赏赐/离走系数）、`["Life"]`（54 条身世 `shenshi001`…`shenshi054`）
* `assets/src/app/Helper.lua` 的 `Helper:getRandomName`（姓/男名/女名三张字库）+
  `PuRenModel:getNamebySex` 的 A/B/C/D 四张字库 → **原版取名用的就是这些**，运行时解析出来用
* `assets/src/app/models/map/UserMapRelation.lua` 的 `cityAreaRelation/cityDirRelation/
  villageRelation/villageAreaRelation` → `get_location_max` 四层上限

== 状态（真写盘）==
`work/homeland_person_state.json`（本模块独占，**不碰** `homeland_furniture.py` 的
`homeland_home_state.json`）：
`lists`（按招募 NPC 存的候选名单，含 `hid/state`）、`employees`（已雇的人，含 `rwId/fjId/extra`）、
`daily`（每人每天的闲聊/赏赐次数）、`tax`（地皮缴费）、`log`。
另外**只同步一个键**到 `work/homeland_state.json["employees"]`（宿主服务端 `get_home_info` 的
`pnum` 读它，`_home_load` :404 也是它）—— 读改写回，不动别的键。

== 已知还没做 / 需要上层收口的地方 ==
1. **`use_homebw`（珍宝赏赐）不在本模块**：它由 `fz_api/homeland_furniture.py` 接管并只回
   `{'msg': ''}`，而 `ServantRewardLayer:236-282` 会读 `data.defaultZhongCheng` 再算
   `data.defaultZhongCheng>=4000` ⇒ **珍宝赏赐那条路现在会崩**（本模块不抢别人的接口，
   要么那个模块补 `defaultZhongCheng/trait/activity`，要么把该接口让给本模块）。
2. **`get_guaike_reward` / `get_shenshi_reward` / `get_manage_payment` / `get_location_max` /
   `settle_overdue_dream` / `check_goods_valid` 有多个模块同时声明**（本模块 + `homeland_land.py`
   + `homeland_life.py` + `items_currency.py`）。`fz_api.dispatch` 按**模块名字母序**取第一个非
   None ⇒ `homeland_land` < `homeland_life` < `homeland_person` < `items_currency`。
   本模块这 6 条照样声明（她要求的接口名一个不少，别的模块没到位时这里能兜住），但运行时由
   顶部 `_YIELD` + `_yield_to_owner()` **主动让位**给更专业的模块（例如 `check_goods_valid`
   让给 `items_currency`，因为真背包数量在它的 `items_state.json` 里；硬抢会让数量从真值降级成 0）。
   ※ 并行开发期间有人用 `work/tmp_unclaim.py` 把这些接口名从本文件的 `ENDPOINTS` 里删过一轮
   （"划清归属"），已按本条方案恢复 —— 要收口请**只留一份声明**，别再直接删别人的声明。
3. **框架坑（`fz_api/__init__.py` 的 `Ctx.ok`）**：`data` 是**非空数组**时 `ctx.ok(arr)` 会
   `dict(arr)` 直接 `ValueError`。本模块内部用 `_ok_list()` 绕开（`save_employee_list` /
   `check_goods_valid` 的 `data` 本身就是数组）。别的模块回数组也会踩这个坑。
4. `check_goods_valid`：背包真值不在本模块，所以**让位给 `items_currency`**；真轮到自己应答时
   只回本模块 `homeland_person_state.json["items"]` 里记的数量（默认 0），形状保证是
   `[{itemId, number}]` 的**数组**（绝不能只回 `{dataVer}`——那样她 `v.itemId` 直接崩）。
5. `settle_overdue_dream` 只回 errcode=2（没有过期梦境）：梦境闯荡的存档在
   `DreamWorldModel`（`get_dream_role_data` 那条链），本模块不掌管梦境层数。
6. `get_manage_payment` 只算「欠费天数 / 欠费总额」（她 `DiQiModel` 也正是只读这两个数字）：
   自动从元宝里扣缴地税那套在 `homeland_life.py` / `homeland_land.py` 里。
7. `get_guaike_reward` 的银票/阅历/威望原版无配表（只有客户端自算的交子/经验/潜能），
   本模块回 0，只做**门客忠诚度推进**；`use_homebw` 那条路见第 1 条。
"""
import os
import random
import re
import sys
import time

NAME = 'homeland_person'
TITLE = '家园·仆人/门客/管家/派遣'
ENDPOINTS = [
    'get_employee_data', 'update_employee_data', 'update_employee_extra',
    'get_employee_list', 'add_employee', 'delete_employee', 'save_employee_list',
    # ★ 2026-10-13：师门挂机任务「邀请同行」（门客页签）/ 读书「书童陪读」都要它。
    #   原来 fz_boot_server 里的空壳形状还错（{list:[]} 当数组用）——由本模块接管。
    'get_all_persons',
    # ★ 从 `homeland_furniture` 迁过来的：珍宝赏赐也是"给仆人加忠诚度"，
    #   账本（`defaultZhongCheng` / 每日次数 / 特性解锁）本来就在本模块，
    #   放在家具模块只能自己再存一份假账（旧实现回的是"累计增量"，没有上限、
    #   没有日限、没有 errcode 1/2/3 ⇒ 客户端那三条提示分支永远走不到）。
    'use_homebw',
]

# ★ 并行开发撞车：下面这几个接口另有**更专业的模块**（自带状态账本）。
#   本模块照样声明（万一那个模块没到位，这里还能兜住），但运行时**让位**——
#   `_yield_to_owner()` 发现对方在位就 `return None`，让 `fz_api.dispatch` 继续往下走。
#   之所以要让位而不是硬抢：`fz_api.dispatch` 按**模块名字母序**取第一个非 None，
#   而 `homeland_person` 排在 `items_currency` 前面 ⇒ 硬抢会把 `check_goods_valid`
#   从"真背包数量"（`items_state.json`）降级成本模块的 0。
_YIELD = {
    'check_goods_valid': ('items_currency',),               # 真背包在那边的 items_state.json
    'get_guaike_reward': ('homeland_land',),
    'get_shenshi_reward': ('homeland_land',),
    'settle_overdue_dream': ('homeland_land',),
    'get_manage_payment': ('homeland_land', 'homeland_life'),
    'get_location_max': ('homeland_land', 'homeland_life'),
}

STATE = 'homeland_person_state.json'    # 本模块独占
HOME_STATE = 'homeland_state.json'      # 只借用 "employees" 一个键（宿主 pnum 读它）

RES = _fz_res()
FAMILYLIST = RES + r'/others/familylist.lua'
FAMILYSPECIAL = RES + r'/others/familyspecial.lua'

SRC = os.path.join(_OFF_FZ_ROOT, 'src', 'app')
if not os.path.isdir(SRC):   # 设备上用包内 client_fz 副本（2026-10-04）
    SRC = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'client_fz', 'src', 'app')
HELPER_LUA = SRC + r'/Helper.lua'
PUREN_LUA = SRC + r'/models/HomelandModel/HomelandRoleModel/PuRenModel.lua'
USERMAPREL_LUA = SRC + r'/models/map/UserMapRelation.lua'

# 她 `HomelandRoleUtil:getCHAJobTypeName` :309 那张职业名表（顺序也是招募面板的顺序）
JOB_CN = {
    'huyuan001': '护院', 'shutong001': '书童', 'xiunv001': '绣女', 'laonong001': '老农',
    'chuzi001': '厨子', 'tiejiang001': '铁匠', 'puren001': '仆人', 'peilian001': '陪练',
    'guanjia001': '管家', 'menke001': '门客',
}
# 她 `HomelandRoleUtil:getCHAXingGeName` :333
XINGGE_CN = {
    'xingge001': '沉默寡言', 'xingge002': '内向害羞', 'xingge003': '细心谨慎',
    'xingge004': '老实巴交', 'xingge005': '老成练达', 'xingge006': '热心耿直',
    'xingge007': '稳重踏实', 'xingge008': '多愁善感', 'xingge009': '开朗健谈',
    'xingge010': '活泼诙谐',
}
# 她 `HomelandRoleUtil:getFidelityLv` :50 的忠诚度等级阈值
LEVELS = ((0, 1), (200, 2), (500, 3), (800, 4), (1200, 5), (1800, 6), (2700, 7))
ZC_MAX = 4000                            # `getFidelityByLv(8)` 的上限
DA_MEN = 'tsfangjian004'                 # `HomelandRoomUtil:getDaMenRoomId` 认的大门
OUT_ROOM = ('tsfangjian001', 'tsfangjian002', 'tsfangjian003')   # 空房/屋外/门前
XIU_SHU_TIE = {                          # `PuRenModel:getRandomWuMobanidAndLoyallv` :310
    'xiunv001': ('moban150', 'moban151', 'moban152'),
    'shutong001': ('moban153', 'moban154', 'moban155'),
    'tiejiang001': ('moban156', 'moban157', 'moban158'),
}
MOBAN_EXCLUDE = set(XIU_SHU_TIE['xiunv001'] + XIU_SHU_TIE['shutong001'] + XIU_SHU_TIE['tiejiang001'])
MENKE_WEIGHT = ((1, 75), (2, 20), (3, 5))          # `MenKeModel:getMenkeMobanId` :150
TRAITVAL_WEIGHT = ((1, 25), (2, 35), (3, 28), (4, 11), (5, 1))   # `MenKeModel:getTraitVal` :177

_CACHE = {}


# ===========================================================================
# 一、小工具
# ===========================================================================


def _s(v, d=''):
    if v is None:
        return d
    if isinstance(v, bool):
        return str(int(v))
    if isinstance(v, float) and float(v).is_integer():
        return str(int(v))
    return str(v)


def _i(v, d=0):
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return d


def _num(v, d=0.0):
    try:
        return float(v)
    except (TypeError, ValueError):
        return d


def _read(path):
    """读她客户端源码原文（取名字库用），带缓存。"""
    key = ('txt', path)
    if key not in _CACHE:
        try:
            with open(path, encoding='utf-8', errors='replace') as f:
                _CACHE[key] = f.read()
        except OSError:
            _CACHE[key] = ''
    return _CACHE[key]


def _lua(path, sheet=None):
    """解析她的数据表；缓存挂在 `fz_luatable` 上，热加载时不用重解析大表。"""
    key = (path, sheet)
    try:
        import fz_luatable
    except Exception:                        # noqa: BLE001
        # 直接 `python fz_api\homeland_person.py` 时 work 不在 sys.path 上，补一下
        try:
            here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            if here not in sys.path:
                sys.path.insert(0, here)
            import fz_luatable
        except Exception:                    # noqa: BLE001
            return {}
    cache = getattr(fz_luatable, '_fz_person_cache', None)
    if cache is None:
        cache = {}
        fz_luatable._fz_person_cache = cache
    if key not in cache:
        try:
            t = fz_luatable.load_lua_table(path)
        except Exception:                    # noqa: BLE001
            t = {}
        if sheet and isinstance(t, dict):
            t = t.get(sheet) or {}
        cache[key] = t if isinstance(t, dict) else {}
    return cache[key]


def _lua_strs(seg):
    return [m for m in re.findall(r'"([^"]*)"', seg or '') if m]


# ---------------- 她的表 ----------------
def _fam():
    return _lua(FAMILYLIST)


def _spe():
    return _lua(FAMILYSPECIAL)


def _mobans():
    """`familylist["人物模板设计"]` → {mobanid: 行}。"""
    if 'mobans' not in _CACHE:
        out = {}
        for v in (_fam().get('人物模板设计') or {}).values():
            if isinstance(v, dict) and v.get('mobanid'):
                out[_s(v.get('mobanid'))] = v
        _CACHE['mobans'] = out
    return _CACHE['mobans']


def _roletypes():
    """`familylist["人物类型"]` → {职业 id: 行}。"""
    if 'roletypes' not in _CACHE:
        out = {}
        for v in (_fam().get('人物类型') or {}).values():
            if isinstance(v, dict) and v.get('peopletYpe'):
                out[_s(v.get('peopletYpe'))] = v
        _CACHE['roletypes'] = out
    return _CACHE['roletypes']


def _jobtypes():
    """她这 10 个职业（表里有几个就是几个，不另造）。"""
    return [j for j in JOB_CN if j in _roletypes()] or list(JOB_CN)


def _traits():
    if 'traits' not in _CACHE:
        out = {}
        for k, v in (_spe().get('trait') or {}).items():
            if isinstance(v, dict):
                out[_s(v.get('id') or k)] = v
        _CACHE['traits'] = out
    return _CACHE['traits']


def _lives():
    return _spe().get('Life') or {}


def _characters():
    if 'chars' not in _CACHE:
        out = {}
        for k, v in (_spe().get('character') or {}).items():
            if isinstance(v, dict):
                out[_s(v.get('id') or k)] = v
        _CACHE['chars'] = out
    return _CACHE['chars']


def _career():
    if 'career' not in _CACHE:
        out = {}
        for v in (_spe().get('career') or {}).values():
            if isinstance(v, dict) and v.get('charactertype'):
                out[_s(v.get('charactertype'))] = v
        _CACHE['career'] = out
    return _CACHE['career']


def _char_factor(job):
    """`HomelandRoleUtil:getCharacterFactor` :237 —— 职业系数行。"""
    return _career().get(_s(job)) or {}


def _char_attr(xingge):
    """`HomelandRoleUtil:getCharacterAttr` :222 —— 性格行。"""
    return _characters().get(_s(xingge)) or {}


def _fid_lv(zc):
    lv = 1
    for val, l in LEVELS:
        if _num(zc) >= val:
            lv = l
    return lv


def _traits_for(value):
    """她 `getTexingList` 的设计意图：`CharacteristicNeed <= value` 的正向特点真 id。"""
    out = [k for k, v in _traits().items()
           if _num(v.get('attributeValue'), 0) > 0 and _num(v.get('CharacteristicNeed'), 0) <= value]
    return sorted(out)


def _roll_traits(value):
    """`HomelandRoleUtil:getTexingCount` :209 的概率：5% 一个 / 0.25% 两个 / 0.0125% 三个。"""
    pool = _traits_for(value)
    if not pool:
        return []
    cnt = 0
    if random.randint(1, 1000000) <= 125:
        cnt = 3
    elif random.randint(1, 10000) <= 25:
        cnt = 2
    elif random.randint(1, 100) <= 5:
        cnt = 1
    out = []
    for _ in range(cnt):
        if not pool:
            break
        tid = random.choice(pool)
        pool = [t for t in pool if t != tid]
        out.append(tid)
    return out


def _moban_skill(row):
    """`HomelandRoleUtil:getUploadWebRoleSkillArray` :766 —— skill1..20 → {武功: 等级}。"""
    out = {}
    for i in range(1, 21):
        name = _s(row.get('skill%d' % i))
        if name:
            out[name] = _i(row.get('skillLv%d' % i), 1)
    return out


# ---------------- 她的取名字库 ----------------
def _names_guanjia():
    """`Helper:getRandomName` :1019 的姓/男名/女名（管家与门客都用这套）。"""
    if 'name_gj' not in _CACHE:
        txt = _read(HELPER_LUA)
        out = []
        for var in ('xing', 'nanMing', 'nvMing'):
            m = re.search(r'\b' + var + r'\s*=\s*\{(.*?)\}', txt, re.S)
            out.append(_lua_strs(m.group(1)) if m else [])
        _CACHE['name_gj'] = out
    return _CACHE['name_gj']


def _names_puren():
    """`PuRenModel:getNamebySex` :346 的 A(男姓) B(男名) C(女姓) D(女名)。"""
    if 'name_pr' not in _CACHE:
        txt = _read(PUREN_LUA)
        best = {}
        for letter in 'ABCD':
            cur = []
            for m in re.finditer(r'\b' + letter + r'\s*=\s*\{(.*?)\}', txt, re.S):
                items = _lua_strs(m.group(1))
                if len(items) > len(cur) and any('\u4e00' <= c <= '\u9fff' for c in ''.join(items)):
                    cur = items
            best[letter] = cur
        _CACHE['name_pr'] = (best['A'], best['B'], best['C'], best['D'])
    return _CACHE['name_pr']


def _rand_name(job, sex):
    """按她自己的字库拼名字（原版怎么拼就怎么拼）。"""
    if job in ('guanjia001', 'menke001'):
        xing, nan, nv = _names_guanjia()
        given = nan if sex == '男' else nv
        if xing and given:
            return random.choice(xing) + random.choice(given)
    else:
        a, b, c, d = _names_puren()
        if sex == '男':
            if a and b:
                return random.choice(a) + random.choice(b)
        elif c and d:
            return random.choice(c) + random.choice(d)
        if a and b:
            return random.choice(a) + random.choice(b)
    # 兜底（她字库没解析出来时）：用职业名，绝不编造百家姓
    return JOB_CN.get(job, '仆人')


# ===========================================================================
# 二、候选人 / 人物生成（照她 GuanJiaModel / MenKeModel / PuRenModel 的算法）
# ===========================================================================
def _rng(a, b):
    a, b = _i(a, 1), _i(b, 1)
    if a > b:
        a, b = b, a
    return random.randint(a, b)


def _range2(text, dflt):
    parts = [_i(x, 0) for x in _s(text).split(';') if _s(x).strip()]
    if len(parts) >= 2:
        return parts[0], parts[1]
    if len(parts) == 1:
        return parts[0], parts[0]
    return dflt


def _weighted(pairs):
    total = sum(w for _, w in pairs if w > 0)
    if total <= 0:
        return pairs[0][0]
    r = random.uniform(0, total)
    acc = 0.0
    for k, w in pairs:
        acc += w
        if r <= acc:
            return k
    return pairs[-1][0]


def _pick_moban(job, zc, sex):
    """她三个 model 的模板挑选规则（:132 / :148 / :310）。"""
    pool = list(_mobans().values())
    if not pool:
        return {}
    if job in XIU_SHU_TIE:
        want = XIU_SHU_TIE[job]
        cand = [m for m in pool if _s(m.get('mobanid')) in want]
        return random.choice(cand) if cand else random.choice(pool)
    if job == 'menke001':
        line = _weighted(MENKE_WEIGHT)
        if line == 1:
            lo, hi = 67, 75
        elif line == 2:
            lo, hi = 76, 85
        else:
            lo, hi = 86, 115
        ids = ['moban0%d' % n if n < 100 else 'moban%d' % n for n in range(lo, hi + 1)]
        cand = [m for m in pool if _s(m.get('mobanid')) in ids]
        return random.choice(cand) if cand else random.choice(pool)
    if job == 'guanjia001':
        # `GuanJiaModel:getWugongInfo` :132 —— 男 1..53，女 10..40
        n = _rng(10, 40) if sex == '女' else _rng(1, 53)
        mid = ('moban00%d' % n) if n < 10 else ('moban0%d' % n)
        if mid in _mobans():
            return _mobans()[mid]
    # `PuRenModel:getRandomWuMobanidAndLoyallv` :329 —— 按忠诚度随机 loyallv，再找同 loyallv 的模板
    lv = _rng(1, max(1, min(int(_num(zc)) // 9, 111)))
    left = [m for m in pool if _s(m.get('mobanid')) not in MOBAN_EXCLUDE]
    cand = [m for m in left if _i(m.get('loyallv'), 0) == lv]
    if not cand:
        left.sort(key=lambda m: abs(_i(m.get('loyallv'), 0) - lv))
        cand = left[:1]
    return random.choice(cand) if cand else random.choice(pool)


def _price_puren(zc, loyallv, job, trait_sum):
    """`PuRenModel:getPriceEmploy` :369 —— 仆人/护院…的雇佣价（元宝 20% / 银票 80%）。"""
    unit = 'yinpiao' if random.randint(1, 100) > 20 else 'yuanbao'
    k3 = _i((_roletypes().get(job) or {}).get('hirevlaue'), 60)
    base = min(_num(loyallv) * 0.5 + k3 * 0.4 + min(trait_sum, 300) * 0.5, 200)
    if unit == 'yuanbao':
        return int(max(0, min(min(base * 0.35, 50), 200))) * 14, unit
    return int(max(0, base)) * 14, unit


def _make_candidate(job, zc=None, shenshi=None, sex=None, name=None, trait_val=None):
    """照她客户端生成一条候选人（字段与她 `EmployDataModel` 喂给 UI 的完全一致）。"""
    rt = _roletypes().get(job) or {}
    sexs = [x for x in _s(rt.get('sexs'), '男').split(';') if x]
    if sex not in ('男', '女'):
        sex = random.choice(sexs) if sexs else '男'
    ages = _range2(rt.get('ages'), (20, 40))
    looks = _range2(rt.get('looks'), (15, 25))
    lives = [x for x in _s(rt.get('randlife')).split(';') if x] or sorted(_lives())
    xg = random.choice(sorted(_characters()) or ['xingge004'])

    unit = 'yinpiao'
    if job == 'guanjia001':
        zc0 = _rng(1, 200) if sex == '男' else _rng(50, 230)
        price = _rng(1500, 2000) if sex == '男' else _rng(1800, 2400)
        shenshi = ''
        tval = _i(trait_val, _rng(1, 500))
    elif job == 'menke001':
        zc0 = _rng(1, 100)
        price = _rng(90, 180) * 14
        tval = {1: _rng(1, 99), 2: _rng(100, 199), 3: _rng(200, 299),
                4: _rng(300, 499), 5: 500}[_weighted(TRAITVAL_WEIGHT)]
        shenshi = shenshi or random.choice(lives) if lives else ''
    else:
        z0 = _num(zc, 100.0)
        zc0 = _rng(50 + int(z0 // 20), 100 + int(z0 // 4))
        tval = int(z0 // 7)
        price = 0
        shenshi = shenshi or (random.choice(lives) if lives else '')

    moban = _pick_moban(job, zc0, sex)
    tids = _roll_traits(tval)
    cf, ca = _char_factor(job), _char_attr(xg)
    speed = _num(cf.get('Dailyup1'), 1) * _num(ca.get('Dailyup'), 1)
    leave = _num(cf.get('leave1'), 1) * _num(ca.get('leave'), 1)
    if job not in ('guanjia001', 'menke001'):
        tsum = sum(_num((_traits().get(t) or {}).get('attributeValue'), 0) for t in tids)
        price, unit = _price_puren(zc0, _i(moban.get('loyallv'), 1), job, tsum)

    out = {
        'name': name or _rand_name(job, sex),
        'sex': sex, 'age': _rng(*ages), 'looks': _rng(*looks),
        'shenShi': _s(shenshi), 'jobType': job, 'character': xg,
        'defaultZhongCheng': int(zc0), 'speedZhongCheng': int(speed),
        'price': int(price), 'price_unit': unit, 'traitVal': int(tval),
        'modal': _s(moban.get('mobanid')), 'leave_day': int(leave),
        'mobanSkill': _moban_skill(moban),
        'trait1': tids[0] if len(tids) > 0 else '',
        'trait2': tids[1] if len(tids) > 1 else '',
        'trait3': tids[2] if len(tids) > 2 else '',
    }
    return out


def _moban_ok(mobanid):
    return _s(mobanid) in _mobans()


def _fix_person(src, job=None):
    """把一条人物数据补全成她 `initHomelandMapRole` 敢吃的形状（缺项会崩，类型也要对）。"""
    out = dict(src) if isinstance(src, dict) else {}
    jt = _s(out.get('jobType') or out.get('job') or job)
    if jt not in _roletypes():
        jt = jt if jt in JOB_CN else 'puren001'
    out['jobType'] = jt
    out['job'] = jt
    if _s(out.get('sex')) not in ('男', '女'):
        out['sex'] = '男'
    out['name'] = _s(out.get('name')) or JOB_CN.get(jt, '仆人')
    out['age'] = _i(out.get('age'), 30)
    out['looks'] = _i(out.get('looks'), 20)
    if not _moban_ok(out.get('modal')):
        out['modal'] = _s((_pick_moban(jt, _num(out.get('defaultZhongCheng'), 100),
                                       out['sex']) or {}).get('mobanid'))
    if _s(out.get('character')) not in _characters():
        out['character'] = random.choice(sorted(_characters()) or ['xingge004'])
    # ★★ 2026-10-01：**管家的忠诚度抬到 lv4 起步**。
    #   管家那排按钮的开关在 `HomelandRoleTemplate.lua:458-464`：
    #       local lv = HomelandRoleUtil:getFidelityLv(role.defaultZhongCheng)
    #       if lv >= 3 then 「招募仆人」open
    #       if lv >= 4 then 「房屋改造」open
    #   而 `getFidelityLv`（`HomelandRoleUtil.lua:44-67`）的门槛是
    #       0→1 / 200→2 / **500→3** / **800→4** / 1200→5 / 1800→6 / 2700→7
    #   老板存档里的李管家只有 **84**（种子数据给的）⇒ lv **1**
    #   ⇒ 截图里管家只有 交谈/房屋事务/赏赐/仆人管理，缺「招募仆人 / 房屋改造」。
    #   私服里把管家**抬到至少 900**（= lv 4）；「赏赐」照样能继续往上加。
    #   （注意是"抬高"不是"缺省"——他这条记录里已经有值 84，用缺省补不到。）
    if jt == 'guanjia001':
        _zc = max(900, int(_num(out.get('defaultZhongCheng'), 900)))
        out['defaultZhongCheng'] = int(max(0, min(ZC_MAX, _zc)))
    else:
        out['defaultZhongCheng'] = int(max(0, min(ZC_MAX, _num(out.get('defaultZhongCheng'), 100))))
    out['speedZhongCheng'] = int(_num(out.get('speedZhongCheng'), 1))
    out['price'] = _i(out.get('price'), 140)
    if _s(out.get('price_unit')) not in ('yinpiao', 'yuanbao'):
        out['price_unit'] = 'yinpiao'
    out['traitVal'] = _i(out.get('traitVal'), 0)
    # ★ 非管家必须有**真身世**：`HomelandRoleTemplate:addNormalCR` :293 会
    #   `RoleLife:getLifeTitle(role.shenShi)` → `assert(Life_res[lifeId])`，给假 id 直接崩。
    if jt == 'guanjia001':
        out['shenShi'] = ''
    else:
        lives = _lives()
        if _s(out.get('shenShi')) not in lives:
            cand = [x for x in _s((_roletypes().get(jt) or {}).get('randlife')).split(';') if x in lives]
            out['shenShi'] = random.choice(cand) if cand else (random.choice(sorted(lives)) if lives else '')
    # ★ trait1..3 只能是真 texing id，空串她那边会跳过（'' 不等于 nil，但会走 MapIsEmpty 分支）
    for i in (1, 2, 3):
        k = 'trait%d' % i
        out[k] = _s(out.get(k)) if _s(out.get(k)) in _traits() else ''
    if not isinstance(out.get('mobanSkill'), dict):
        out['mobanSkill'] = _moban_skill(_mobans().get(_s(out.get('modal'))) or {})
    if not isinstance(out.get('extra'), dict):
        out['extra'] = {}
    # ★★ 2026-10-01：**管家的 id 必须正好是 `guanjia1001`**（老板："呼唤管家"文字说来了、
    #   实际人没来）。客户端 `HomelandRoleUtil:createObjId`（:1253-1260）对 `guanjia001`
    #   直接 `return "guanjia1001"`，而且 `initHomelandMapRole` 里 `role.id = role.rwId`
    #   ⇒ 房间角色的 id 就是 rwId。客户端有**十几处**按这个常量找管家：
    #     · `MapLayer.lua:620`  呼唤管家：`if value == "guanjia1001" then gjCurrRoom = k`
    #       ⇒ 找不到 ⇒ `gjCurrRoom` 为 nil ⇒ 只打印"管家一路小跑了过来"但**不搬人**
    #     · `FurnitureModule.lua:494/596/912/1000` 家具摆放/收回要的也是它
    #     · `HomeDesc.lua:580`、`TitleUI.lua:720`、`HeroFeastModule.lua:49` …
    #   我们以前发的是存档里的 `pr_1001`（甚至空串）⇒ 一律找不到人。
    if jt == 'guanjia001':
        out['objId'] = 'guanjia1001'
        out['rwId'] = 'guanjia1001'
    else:
        # 仆人/门客走官方规则：`pr_<prIdIndex+1>`；存档里有就沿用，没有就补一个稳定的
        if not _s(out.get('objId')):
            out['objId'] = _s(out.get('rwId'))
        if not _s(out.get('rwId')):
            out['rwId'] = _s(out['objId'])
    out.pop('hid', None)
    out.pop('state', None)
    return out


def _payload(emp):
    """`roomperson` 里的一条 / `add_employee` / `get_employee_data` 的应答体。"""
    p = _fix_person(emp)
    return {
        # ★ 取 `_fix_person` 补好的值（管家会被强制成 guanjia1001），不要直接读原始记录
        'rwId': _s(p.get('rwId')), 'objId': _s(p.get('objId') or p.get('rwId')),
        'fjId': _s(emp.get('fjId')), 'job': p['jobType'], 'jobType': p['jobType'],
        'name': p['name'], 'sex': p['sex'], 'age': p['age'], 'looks': p['looks'],
        'modal': p['modal'], 'character': p['character'],
        'defaultZhongCheng': p['defaultZhongCheng'],
        'speedZhongCheng': p['speedZhongCheng'],
        'price': p['price'], 'price_unit': p['price_unit'], 'traitVal': p['traitVal'],
        'trait1': p['trait1'], 'trait2': p['trait2'], 'trait3': p['trait3'],
        'shenShi': p['shenShi'], 'leave_day': _i(p.get('leave_day'), 0),
        'mobanSkill': p['mobanSkill'], 'extra': p['extra'],
    }


# ===========================================================================
# 三、状态（真写盘）
# ===========================================================================
def _today():
    return time.strftime('%Y-%m-%d')


def _load(ctx):
    st = ctx.load_json(STATE, None)
    if not isinstance(st, dict):
        st = {}
    st.setdefault('lists', {})
    st.setdefault('employees', [])
    st.setdefault('daily', {})
    st.setdefault('tax', {})
    st.setdefault('items', {})
    st.setdefault('dream', {})
    st.setdefault('log', [])
    for k in list(st['daily']):
        if k < time.strftime('%Y-%m-%d', time.localtime(time.time() - 3 * 86400)):
            st['daily'].pop(k, None)
    return st


def _save(ctx, st):
    st['log'] = (st.get('log') or [])[-200:]
    ctx.save_json(STATE, st)
    return st


def _note(st, text):
    st.setdefault('log', []).append({'t': int(time.time()), 'msg': text})


def _mid_of(ctx, *args):
    for a in list(args) + [ctx.param('mid'), (ctx.args[1] if len(ctx.args) > 1 else None)]:
        if a not in (None, ''):
            return _s(a)
    return '0'


def _emps(st):
    out = st.get('employees')
    return out if isinstance(out, list) else []


def _emps_for_mid(ctx, st, mid):
    """按 mid 取已雇的人；一条都没有就退到全部（单机开发期房号可能飘）。"""
    want = _s(mid)
    hit = [e for e in _emps(st) if isinstance(e, dict) and _s(e.get('mid')) == want]
    if hit:
        return hit
    return [e for e in _emps(st) if isinstance(e, dict)]


def _find_emp(st, rw):
    """按 `rwId`（或 `objId`）找府上的人。"""
    rw = _s(rw)
    if not rw:
        return None
    for e in _emps(st):
        if isinstance(e, dict) and _s(e.get('rwId')) == rw:
            return e
    for e in _emps(st):
        if isinstance(e, dict) and _s(e.get('objId')) == rw:
            return e
    return None


def _next_index(st):
    mx = 1000
    for e in _emps(st):
        if isinstance(e, dict):
            tail = _s(e.get('rwId')).split('_')
            if len(tail) > 1 and tail[1].isdigit():
                mx = max(mx, int(tail[1]))
    return mx + 1


# ---------------- 钱袋子（宿主服务端/home land_life 共用同一份） ----------------
def _home(ctx):
    st = ctx.load_json(HOME_STATE, None)
    if not isinstance(st, dict):
        st = {}
    st.setdefault('currency', {'yinpiao': 200000, 'yuanbao': 99999, 'money': 200000})
    return st


def _wallet(ctx, name):
    return _i((_home(ctx).get('currency') or {}).get(name), 0)


def _wallet_add(ctx, name, delta):
    st = _home(ctx)
    cur = st.setdefault('currency', {})
    cur[name] = _i(cur.get(name), 0) + _i(delta)
    ctx.save_json(HOME_STATE, st)
    return cur[name]


def _mirror_home(ctx, st):
    """只同步 `homeland_state.json["employees"]`（宿主 `get_home_info` 的 `pnum` 读它）。"""
    home = _home(ctx)
    home['employees'] = [{'objId': _s(e.get('objId') or e.get('rwId')),
                          'jobType': _s(e.get('jobType')), 'name': _s(e.get('name')),
                          'mid': _s(e.get('mid')), 'fjId': _s(e.get('fjId'))}
                         for e in _emps(st) if isinstance(e, dict)]
    ctx.save_json(HOME_STATE, home)
    return home['employees']


def _adopt_mirror(ctx, st):
    """把宿主旧版 `add_employee` 记下的 `employees` 收编成真人物（老板之前雇的管家别丢）。"""
    home = _home(ctx)
    known = {_s(e.get('objId') or e.get('rwId')) for e in _emps(st)}
    added = 0
    for m in (home.get('employees') or []):
        if not isinstance(m, dict):
            continue
        oid = _s(m.get('objId') or m.get('rwId'))
        if not oid or oid in known:
            continue
        job = _s(m.get('jobType')) or 'puren001'
        nm = _s(m.get('name'))
        if nm in JOB_CN.values() or not nm:
            nm = ''
        emp = _fix_person(_make_candidate(job, name=nm or None))
        emp.update({'rwId': oid, 'objId': oid, 'mid': _s(m.get('mid')) or '0',
                    'fjId': _s(m.get('fjId')), 'extra': {}})
        _emps(st).append(emp)
        known.add(oid)
        added += 1
    if added:
        _note(st, '从 homeland_state.employees 收编 %d 人' % added)
        _save(ctx, st)
    return added


# ===========================================================================
# 四、房间（必须与 get_user_map 下发的 maproom 完全一致）
# ===========================================================================
def _rooms(ctx, mid):
    try:
        here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        if here not in sys.path:
            sys.path.insert(0, here)
        import fz_homeland_map as H
        data = H.build_user_map(mid)
        rooms = [r for r in (data.get('maproom') or [])
                 if isinstance(r, dict) and r.get('fjId')]
        if rooms:
            return [{'fjId': _s(r.get('fjId')), 'name': _s(r.get('name')),
                     'roomType': _s(r.get('roomType'))} for r in rooms]
    except Exception as e:                   # noqa: BLE001
        try:
            ctx.log('家园人事：取房间失败 %s' % e)
        except Exception:                    # noqa: BLE001
            pass
    return []


def _pick_room(rooms, job, used):
    """按她 `人物类型.roomtyPe` 挑房间：管家固定大门；没这种房间就退到第一间室内房。"""
    if not rooms:
        return ''
    want = DA_MEN if job == 'guanjia001' else _s((_roletypes().get(job) or {}).get('roomtyPe'))
    load = lambda r: used.get(r['fjId'], 0)          # noqa: E731
    indoor = [r for r in rooms if r.get('roomType') not in OUT_ROOM]
    cand = [r for r in rooms if r.get('roomType') == want] if want else []
    if not cand and job != 'guanjia001':
        cand = [r for r in indoor if r.get('roomType') == want]
    if not cand:
        cand = [r for r in indoor if r.get('roomType') != DA_MEN] or indoor or rooms
    free = [r for r in cand if load(r) == 0]
    return (free or cand)[0]['fjId']


def _assign_rooms(ctx, st, mid, emps):
    """给每个人定 `fjId`（已定的、且房间还在的就不动）。"""
    rooms = _rooms(ctx, mid)
    ids = {r['fjId'] for r in rooms}
    used, changed = {}, False
    for e in emps:
        fj = _s(e.get('fjId'))
        if fj and (not ids or fj in ids):
            used[fj] = used.get(fj, 0) + 1
            continue
        fj = _pick_room(rooms, _s(e.get('jobType')), used)
        if fj:
            e['fjId'] = fj
            used[fj] = used.get(fj, 0) + 1
            changed = True
    return changed


# ===========================================================================
# 五、`roomperson`（宿主 `get_user_map` 会调）
# ===========================================================================
def _ensure_guanjia(ctx, st, mid):
    """★ 2026-10-17 v34：员工账里一个管家都没有 → 自动补录一名真管家。

    救的是 v28 时代的老客户：初始管家已被关闭（isDispose=true）又从未雇佣成功
    （员工账无记录）⇒ 家里永远没管家、招募入口（在管家对话里）也进不去的死锁。
    补的人和正常雇佣完全同形（_make_candidate + _fix_person ⇒ 忠诚 900 起、
    rwId=guanjia1001），fjId 交给 `_assign_rooms` 分。已有管家的存档零影响。
    """
    for e in _emps(st):
        if isinstance(e, dict) and _s(e.get('jobType')) == 'guanjia001':
            return None
    emp = _fix_person(_make_candidate('guanjia001'))
    emp['mid'] = _s(mid) or '0'
    emp['fjId'] = _s(emp.get('fjId')) or ''
    emp['extra'] = emp.get('extra') if isinstance(emp.get('extra'), dict) else {}
    _emps(st).append(emp)
    _note(st, '员工账无管家 → 自动补录一名（老档保底）')
    _save(ctx, st)
    try:
        ctx.log('家园人事：员工账无管家 → 自动补录 %s（mid=%s）'
                % (_s(emp.get('name')), emp['mid']))
    except Exception:                        # noqa: BLE001
        pass
    return emp


def map_persons(ctx, mid):
    """返回 `get_user_map` 应答里的 `roomperson` 数组 —— 雇过的人真的站在对应房间。

    见模块 docstring：她 `UserMap:initUserMap` :182-207 逐条喂
    `HomelandRoleUtil:initHomelandMapRole(roleInfo, map)`，再按 `fjId` 塞进 `room.roleList`。
    """
    try:
        st = _load(ctx)
        _adopt_mirror(ctx, st)
        _ensure_guanjia(ctx, st, mid)   # ★ 2026-10-17 v34：无管家自动补录（老档死锁兜底）
        emps = _emps_for_mid(ctx, st, mid)
        if not emps:
            return []
        changed = _assign_rooms(ctx, st, mid, emps)
        out = []
        for e in emps:
            p = _payload(e)
            if not p['rwId'] or not p['fjId']:
                continue
            out.append(p)
        if changed:
            _save(ctx, st)
        return out
    except Exception as e:                   # noqa: BLE001
        try:
            ctx.log('家园人事：map_persons 失败 %s' % e)
        except Exception:                    # noqa: BLE001
            pass
        return []


# ===========================================================================
# 六、招募名单
# ===========================================================================
def _list_key(npc_id, mid):
    return '%s|%s' % (_s(npc_id) or '-', _s(mid) or '-')


def _used_shenshi(st):
    out = []
    for v in (st.get('lists') or {}).values():
        for c in (v.get('cands') or []):
            ss = _s((c or {}).get('shenShi'))
            if ss and ss not in out:
                out.append(ss)
    for e in _emps(st):
        ss = _s((e or {}).get('shenShi'))
        if ss and ss not in out:
            out.append(ss)
    return out


def _gen_batch(st, job, mid, count):
    """服务端自己造一批候选（真 moban/真名字/真门派/真属性）。"""
    used = set(_used_shenshi(st))
    zc = 100.0
    for e in _emps(st):
        if _s((e or {}).get('jobType')) == 'guanjia001':
            zc = _num(e.get('defaultZhongCheng'), 100)
            break
    out = []
    for _ in range(max(1, count)):
        c = _make_candidate(job, zc=zc)
        if job != 'guanjia001':
            lives = [x for x in _s((_roletypes().get(job) or {}).get('randlife')).split(';')
                     if x and x in _lives() and x not in used]
            if not lives:
                lives = [x for x in sorted(_lives()) if x not in used] or sorted(_lives())
            if lives:
                c['shenShi'] = random.choice(lives)
                used.add(c['shenShi'])
        if job == 'menke001':
            # ★ 2026-10-01 老板要「顶级门客/伙伴」礼包 ⇒ 干脆让服务端出的门客就是顶级：
            #   忠诚拉满（ZC_MAX）、属性/特性拉高，价格也就贵一些（银票）。
            #   这样他在「招募门客」面板里看到的候选本身就是好货，重复刷新也不会掉档次。
            try:
                c['defaultZhongCheng'] = ZC_MAX
                c['speedZhongCheng'] = 5
                c['looks'] = max(_i(c.get('looks'), 20), 95)
                c['traitVal'] = max(_i(c.get('traitVal'), 0), 3)
                c['price'] = max(_i(c.get('price'), 140), 4000)
                c['price_unit'] = 'yinpiao'
            except Exception:                                          # noqa: BLE001
                pass
        out.append(c)
    return out


def _store_batch(ctx, st, key, job, mid, cands, paid=0):
    for i, c in enumerate(cands):
        c['hid'] = 'h%d_%s_%d' % (int(time.time()) % 100000, key.replace('|', '_'), i + 1)
        c['state'] = 0
        c['npcId'] = key.split('|')[0]
    st['lists'][key] = {'jobType': job, 'mid': _s(mid), 'at': int(time.time()),
                        'paid': _i(paid, 0), 'cands': cands}
    return st['lists'][key]


def _serve_list(ctx, st, key, job, mid):
    """把名单伺候好：有可雇的就给，全雇完了非门客就再开一批（门客一天只招一个）。"""
    rec = (st.get('lists') or {}).get(key)
    if isinstance(rec, dict) and isinstance(rec.get('cands'), list) and rec['cands']:
        job = _s(rec.get('jobType')) or job
        if any(_i((c or {}).get('state'), 0) == 0 for c in rec['cands']):
            return rec
        if job == 'menke001':
            return rec                      # 她要看 state==1 才能说"今日已招过门客"
    n = 3
    if job == 'menke001':
        n = 3
    elif job not in ('guanjia001',):
        # 她 `PuRenModel:getZhaomuListNum` :132：跟管家忠诚度等级挂钩（下限 1，保证面板有内容）
        zc = 100.0
        for e in _emps(st):
            if _s((e or {}).get('jobType')) == 'guanjia001':
                zc = _num(e.get('defaultZhongCheng'), 100)
                break
        lv = _fid_lv(zc)
        k = 0 if lv > 4 else min(1000.0 / ((lv + 3) ** 2), 20)
        n = min(int(zc // 1000) + 1, 5) if k < random.randint(1, 100) else 1
        n = max(1, n)
    return _store_batch(ctx, st, key, job, mid, _gen_batch(st, job, mid, n))


# ===========================================================================
# 七、接口
# ===========================================================================
def _npc_job_hint(npc_id):
    """按 npcId 猜这次雇佣是招哪种人。

    「招募门客」的 NPC：`map/mapRole/fb301.lua` 里 `fb301zm1`（别林，baseId=fb301zm，
    caozuoName=招募门客，results1=fb301mk1）——家园外景 fb301 里随机投放到若干房间。
    客户端只把 npcId 发上来，认不出来就回空表（原版分工：客户端自己生成后上传）。
    """
    s = _s(npc_id).lower()
    for pre, job in (('fb301zm', 'menke001'),):
        if s.startswith(pre):
            return job
    return ''


def _get_employee_list(ctx, st):
    npc_id = _s(ctx.args[0] if ctx.args else ctx.param('npcId'))
    mid = _mid_of(ctx, ctx.args[1] if len(ctx.args) > 1 else None)
    key = _list_key(npc_id, mid)
    rec = (st.get('lists') or {}).get(key)
    if not npc_id:
        # 探针/无参调用：服务端自己出一批（真模板真名字），让人看得见"有内容"
        rec = _serve_list(ctx, st, key, 'puren001', mid)
        _save(ctx, st)
    elif isinstance(rec, dict) and rec.get('cands'):
        # 已知职业：有可雇的就给老的；全雇完了，非门客再开一批（门客一天只招一个）
        rec = _serve_list(ctx, st, key, _s(rec.get('jobType')), mid)
        _save(ctx, st)
    if (not isinstance(rec, dict) or not rec.get('cands')):
        _hint = _npc_job_hint(npc_id)
        if _hint:
            # ★ 门客：回空表的话客户端会走 `MenKeModel:initEmployList` :305-318
            #   那条路 —— 先查背包有没有 `menkecard1`（沧浪帖），没有就
            #   `PopText("需要拥有沧浪帖！")` 直接 return ⇒ **面板永远打不开**。
            #   所以这里服务端直接把候选摆出来（原版是客户端自己生成后上传）。
            rec = _serve_list(ctx, st, key, _hint, mid)
            _save(ctx, st)
    if not isinstance(rec, dict) or not rec.get('cands'):
        # ★ 她自己的流程：`data.list` 为空 ⇒ 客户端用**她自己的生成器**造一批再
        #   `save_employee_list` 上传，服务端存下来。原版就是这么分工的，
        #   所以这里必须回空表（否则会替她决定职业，把"招募管家"变成招仆人）。
        return ctx.ok({'list': [], 'shenshi': _used_shenshi(st)},
                      '★ 雇佣候选（空 ⇒ 客户端自己生成后上传）')
    return ctx.ok({'list': rec['cands'], 'shenshi': _used_shenshi(st)},
                  '★ 雇佣候选 %d 人（%s）' % (len(rec['cands']), JOB_CN.get(_s(rec.get('jobType')), '?')))


def _save_employee_list(ctx, st):
    obj = ctx.body_obj if isinstance(ctx.body_obj, dict) else {}
    typ = _i(ctx.param('type'), 1)
    npc_id = _s(obj.get('npcId') or ctx.param('npcId'))
    mid = _mid_of(ctx)
    key = _list_key(npc_id, mid)
    raw = obj.get('list')
    if not isinstance(raw, list):
        raw = []
    old = (st.get('lists') or {}).get(key) or {}
    job = _s((raw[0] or {}).get('jobType') if raw and isinstance(raw[0], dict) else old.get('jobType'))
    if job not in _roletypes():
        job = _s(old.get('jobType')) or 'puren001'
    cands = [_fix_person(c, job) for c in raw if isinstance(c, dict)]
    paid = 0
    if typ == 2:
        # `HomelandRoleEmployLayer:setReplaceButton` :117 —— 换一批花 50 元宝，真扣
        if _wallet(ctx, 'yuanbao') >= 50:
            _wallet_add(ctx, 'yuanbao', -50)
            paid = 50
        else:
            return ctx.fail('元宝不足，换一批需要50元宝。', '★ 换一批：元宝不足')
    if not cands:
        cands = _gen_batch(st, job, mid, 1)
    rec = _store_batch(ctx, st, key, job, mid, cands, paid)
    _note(st, '招募名单刷新：%s %d 人（type=%d%s）'
          % (JOB_CN.get(job, job), len(rec['cands']), typ, '，扣50元宝' if paid else ''))
    _save(ctx, st)
    return _ok_list(ctx, rec['cands'], '★ 存雇佣名单 %d 人（%s）' % (len(rec['cands']), JOB_CN.get(job, job)))


def _find_cand(st, hid):
    for key, rec in (st.get('lists') or {}).items():
        if not isinstance(rec, dict):
            continue
        for c in (rec.get('cands') or []):
            if isinstance(c, dict) and _s(c.get('hid')) == _s(hid):
                return key, rec, c
    return None, None, None


def _hire(ctx, st):
    """`add_employee` —— 真雇佣：写盘 + 定房间 + 回一条与 `roomperson` 同形的人物数据。"""
    obj = ctx.body_obj if isinstance(ctx.body_obj, dict) else {}
    hid = _s(ctx.param('hid') or obj.get('hid'))
    obj_id = _s(ctx.param('objId') or obj.get('objId'))
    mid = _mid_of(ctx)
    npc_id = _s(ctx.param('npcId') or obj.get('npcId'))
    push = obj.get('push_data')
    if not isinstance(push, dict) or not push:
        push = None

    key = rec = cand = None
    src = None
    if push:
        src = push                      # 初始管家 / 副本仆人 / 门客：客户端把整条数据推上来
    elif hid:
        key, rec, cand = _find_cand(st, hid)
        if cand is None:
            return ctx.fail('雇佣信息已过期，请重新招募。', '★ 雇佣：候选条目不存在（hid=%s）' % hid)
        src = cand
    if src is None:
        # 既没 hid 也没 push_data（探针/残包）：先用名单里还没被雇的那条，再没有就现造一条。
        # 正常客户端永远会给 hid 或 push_data，这里只是别让请求变成死路。
        k2 = _list_key(npc_id, mid)
        r2 = (st.get('lists') or {}).get(k2)
        if isinstance(r2, dict):
            for c in (r2.get('cands') or []):
                if isinstance(c, dict) and _i(c.get('state'), 0) == 0:
                    key, rec, cand = k2, r2, c
                    src = c
                    break
        if src is None:
            job0 = _s(ctx.param('jobType') or obj.get('jobType')) or 'puren001'
            if job0 not in JOB_CN:
                job0 = 'puren001'
            src = _gen_batch(st, job0, mid, 1)[0]
            _note(st, 'add_employee 缺 hid/push_data ⇒ 服务端自造一条（%s）' % JOB_CN.get(job0, job0))

    job = _s(src.get('jobType') or src.get('job') or 'puren001')
    if job not in JOB_CN:
        job = 'puren001'
    emp = _fix_person(src, job)
    rw = obj_id or _s(emp.get('objId')) or 'pr_%d' % _next_index(st)
    if job == 'guanjia001' and not rw:
        rw = 'guanjia1001'
    # ★ 她 `MenKeModel:employeeNpc` :457 / `PuRenModel:employeeNpc` :681 会
    #   `string.split(rwId,"_")[2]` → `tonumber(...)` 存 `prIdIndex`；没有 "_" 会写出 nil
    #   ⇒ 下次 `createObjId` 直接 `attempt to perform arithmetic on nil`。这里兜住。
    if '_' not in rw:
        rw = 'pr_%d' % _next_index(st)

    # 管家唯一：她 UI 明说"雇佣后会将其自动辞退"
    if job == 'guanjia001':
        st['employees'] = [e for e in _emps(st)
                           if _s((e or {}).get('jobType')) != 'guanjia001']
    if _find_emp(st, rw):
        st['employees'] = [e for e in _emps(st) if _s((e or {}).get('rwId')) != rw]

    emp.update({'rwId': rw, 'objId': rw, 'mid': mid, 'fjId': ''})
    emp['extra'] = dict(emp.get('extra') or {})
    if key and rec is not None and cand is not None:
        cand['state'] = 1               # 用过就作废（门客靠它判断"今日已招"）
        if job == 'menke001':
            for c in (rec.get('cands') or []):
                c['state'] = 1          # 她 `MenKeModel:initEmployList` :298 的"今天已经招募了一名门客"
        emp['extra']['hid'] = _s(cand.get('hid'))
    if npc_id:
        emp['extra']['npcId'] = npc_id
    st['employees'] = _emps(st) + [emp]
    # ★ 必须把**已经在府上的人**一起算进房间占位，否则新来的人会跟老人挤同一间
    _assign_rooms(ctx, st, mid, _emps(st))
    _save(ctx, st)
    _mirror_home(ctx, st)
    _note(st, '雇佣 %s（%s / %s）→ 房间 %s'
          % (emp['name'], JOB_CN.get(job, job), rw, emp.get('fjId')))
    return ctx.ok(_payload(emp), '★ 雇佣 %s（%s）' % (emp['name'], JOB_CN.get(job, job)))


def _fire(ctx, st):
    rw = _s(ctx.param('objId') or (ctx.body_obj or {}).get('objId'))
    emp = _find_emp(st, rw)
    if emp is None:
        return ctx.fail('府上没有这个人。', '★ 辞退：查无此人（%s）' % rw)
    st['employees'] = [e for e in _emps(st) if _s((e or {}).get('rwId')) != _s(emp.get('rwId'))]
    _save(ctx, st)
    _mirror_home(ctx, st)
    _note(st, '辞退 %s（%s）' % (_s(emp.get('name')), rw))
    return ctx.ok({}, '★ 辞退 %s' % _s(emp.get('name'), rw))


def _employee_data(ctx, st):
    rw = _s(ctx.param('objId') or (ctx.body_obj or {}).get('objId'))
    emp = None
    if rw:
        emp = _find_emp(st, rw)
    else:
        # 没给 objId（探针/残包）：府上第一个人的数据，纯粹方便自检；
        # 真客户端 `MapMeetUtil` 永远会给 `npcWebId`。
        emps = _emps_for_mid(ctx, st, _mid_of(ctx))
        if emps:
            emp = emps[0]
            rw = _s(emp.get('rwId'))
    if emp is None:
        # ★ 不能回半条：`MapMeetUtil` :464-470 会把 data 合并进人物再 `getFidelityLv`，
        #   缺 `defaultZhongCheng` 会在她回调里崩。查不到就老实报错（她会 clearTask + print）。
        return ctx.fail('没有这个人的信息。', '★ 查人物：查无此人（%s）' % rw)
    return ctx.ok(_payload(emp), '★ 人物数据 %s（%s）' % (_s(emp.get('name')), rw))


def _update_employee_data(ctx, st):
    """`update_employee_data` —— 闲聊/赏赐/花钱/任何条件加忠诚度，真写盘、真扣钱。"""
    rw = _s(ctx.param('objId'))
    kind = _s(ctx.param('zc_type'), 'free') or 'free'
    val = _num(ctx.param('zc_val'), 0)
    cur = _num(ctx.param('currency'), 0)
    emp = _find_emp(st, rw)
    if emp is None:
        return ctx.fail('没有这个人的信息。', '★ 加忠诚：查无此人（%s）' % rw)
    job = _s(emp.get('jobType'))
    name = _s(emp.get('name'))
    zc_old = _num(emp.get('defaultZhongCheng'), 0)
    lv_old = _fid_lv(zc_old)
    cf, ca = _char_factor(job), _char_attr(_s(emp.get('character')))
    today = _today()
    day = st['daily'].setdefault(today, {}).setdefault(rw, {'chat': 0.0, 'give': 0})
    day_limit = 0

    if zc_old >= ZC_MAX:
        return ctx.fail('%s如今已同你生死与共，忠诚度无法再提升了。' % name,
                        '★ 加忠诚：已达上限', 3)
    if kind == 'chat':
        # 她 `ChatModel:getAddValueAndRandom` :114 的日上限 = career.Gossiplimit1 * character.Gossiplimit
        limit = _num(cf.get('Gossiplimit1'), 1) * _num(ca.get('Gossiplimit'), 1)
        if limit > 0 and _num(day.get('chat'), 0) >= limit:
            return ctx.fail('今日%s已经与你聊得够多了，还是明日再来吧。' % name,
                            '★ 闲聊：已达本日上限', 2)
        val = max(0.0, val)
        day['chat'] = _num(day.get('chat'), 0) + val
        if limit > 0 and day['chat'] >= limit:
            day_limit = 1
    elif kind in ('give', 'spent'):
        # 她 `ServantRewardLayer:getRewardInfo` :290 的日上限 = career.rewardtimes1 * character.rewardtimes
        limit = _num(cf.get('rewardtimes1'), 1) * _num(ca.get('rewardtimes'), 1)
        if limit > 0 and _num(day.get('give'), 0) >= limit:
            return ctx.fail('你今日已经赏赐够多了，还是明日再说吧。',
                            '★ 赏赐：已达本日上限', 2)
        if cur > 0:
            have = _wallet(ctx, 'yinpiao')
            if have < cur:
                return ctx.fail('银票不足，当前只有%d银票。' % have, '★ 赏赐：银票不足')
            _wallet_add(ctx, 'yinpiao', -int(cur))
        day['give'] = _num(day.get('give'), 0) + 1
        if val <= 0:
            val = 1.0
    else:
        val = max(0.0, val)

    zc_new = max(0.0, min(float(ZC_MAX), zc_old + val))
    emp['defaultZhongCheng'] = int(zc_new)
    lv_new = _fid_lv(zc_new)
    level_up = lv_new > lv_old
    traits = {}
    if level_up:
        for tid in _roll_traits(_num(emp.get('traitVal'), 0)):
            for i in (1, 2, 3):
                k = 'trait%d' % i
                if not _s(emp.get(k)):
                    emp[k] = tid
                    traits[k] = tid
                    break
            if len(traits) >= 3:
                break
    _save(ctx, st)
    return ctx.ok({
        'defaultZhongCheng': int(zc_new), 'level_up': bool(level_up), 'trait': traits,
        'day_limit': _i(day_limit, 0), 'activity': {}, 'rwId': rw, 'jobType': job,
        'level': lv_new,
    }, '★ 忠诚度 %d→%d（%s%s）' % (int(zc_old), int(zc_new), kind, '，升级' if level_up else ''))


# 她 `ServantRewardLayer:getBaoWuItems` :165-178 只认 `mapItemAttr/Items.lua` 里
# `type == "珍宝"` 的物品；忠诚度增量是她客户端 :131-136 **写死**的四档。
# 服务端按**同一张物品表**校验种类，按**同一个数**推进忠诚度 —— 不另造数值。
BAOWU_ZC = {'homebw1': 50, 'homebw2': 35, 'homebw3': 25, 'homebw4': 15}
ITEMS_LUA = RES + r'/map/mapItemAttr/Items.lua'


def _item_type(item_id):
    """物品 `type`（`mapItemAttr/Items.lua`，7805 条）。读不到就回空串。"""
    if 'items' not in _CACHE:
        try:
            from fz_luatable import load_lua_table
            _CACHE['items'] = load_lua_table(ITEMS_LUA)
        except Exception as e:                 # noqa: BLE001
            print('[homeland_person] Items.lua 读不了：%s' % e)
            _CACHE['items'] = {}
    it = (_CACHE['items'] or {}).get(_s(item_id))
    return _s(it.get('type')) if isinstance(it, dict) else ''


def _use_homebw(ctx, st):
    """`use_homebw` —— 珍宝赏赐（`ServantRewardLayer:236-285`）。

    她回调里读的字段（**一个都不能少**）：
      `data.defaultZhongCheng`(数字，直接盖到人物身上)
      `data.trait`(表，`DeblockRoleTrait` 里 `for k,v in pairs(traits)`——**空表也要给**)
      `data.activity`(表，`MapIsEmpty` 判空；新春活动时给 `ssyjf`/`znqjf` 券)

    她的三条 errcode 分支（旧实现永远走不到）：
      1 = 需拥有珍宝才能赏赐
      2 = 当前忠诚度已达到上限
      3 = 你今日已经赏赐够多了，还是明日再说吧
    """
    pr = _s(ctx.param('prId'))
    bw = _s(ctx.param('bwid'))
    emp = _find_emp(st, pr)
    if emp is None:
        return ctx.fail('没有这个人的信息。', '★ 珍宝赏赐：查无此人（%s）' % (pr or '?'))
    # ---- errcode 1：不是真「珍宝」就拒绝（她客户端也会先过一遍，服务端再兜一次）
    if bw not in BAOWU_ZC or _item_type(bw) != '珍宝':
        return ctx.fail('需拥有珍宝才能赏赐',
                        '★ 珍宝赏赐：%s 不是珍宝（物品表 type=%r）' % (bw or '?', _item_type(bw)),
                        1)
    zc_old = _num(emp.get('defaultZhongCheng'), 0)
    # ---- errcode 2：已到上限
    if zc_old >= ZC_MAX:
        return ctx.fail('当前忠诚度已达到上限', '★ 珍宝赏赐：已达上限（%d）' % int(zc_old), 2)
    job = _s(emp.get('jobType'))
    name = _s(emp.get('name'))
    cf, ca = _char_factor(job), _char_attr(_s(emp.get('character')))
    rw = _s(emp.get('rwId')) or pr
    day = st['daily'].setdefault(_today(), {}).setdefault(rw, {'chat': 0.0, 'give': 0})
    # 日上限 = `career.rewardtimes1 * character.rewardtimes`（她自己 `getRewardInfo` 用的也是这两个数）
    limit = _num(cf.get('rewardtimes1'), 1) * _num(ca.get('rewardtimes'), 1)
    if limit > 0 and _num(day.get('give'), 0) >= limit:
        return ctx.fail('你今日已经赏赐够多了，还是明日再说吧',
                        '★ 珍宝赏赐：已达本日上限（%d/%d）' % (_num(day.get('give'), 0), limit), 3)

    add = _num(ctx.param('zc_val'), 0)
    if add <= 0:
        add = BAOWU_ZC[bw]                     # 她没传就按同一张表兜
    zc_new = max(0.0, min(float(ZC_MAX), zc_old + add))
    emp['defaultZhongCheng'] = int(zc_new)
    lv_old, lv_new = _fid_lv(zc_old), _fid_lv(zc_new)
    level_up = lv_new > lv_old
    traits = {}
    if level_up:
        for tid in _roll_traits(_num(emp.get('traitVal'), 0)):
            for i in (1, 2, 3):
                k = 'trait%d' % i
                if not _s(emp.get(k)):
                    emp[k] = tid
                    traits[k] = tid
                    break
            if len(traits) >= 3:
                break
    day['give'] = _num(day.get('give'), 0) + 1
    _save(ctx, st)
    ctx.log('珍宝赏赐：%s（%s）忠诚 %d→%d，今日第 %d/%d 次%s'
            % (name, bw, int(zc_old), int(zc_new), int(day['give']), limit,
               '，解锁特性 %s' % traits if traits else ''))
    return ctx.ok({
        'defaultZhongCheng': int(zc_new), 'trait': traits, 'activity': {},
        'level_up': bool(level_up), 'level': lv_new, 'rwId': rw, 'jobType': job,
    }, '★ 珍宝赏赐 %s：忠诚 %d→%d' % (bw, int(zc_old), int(zc_new)))


def _update_employee_extra(ctx, st):
    """`update_employee_extra` —— 派遣写 `stay_room_time`、身世任务写 `shenshi_status`，真写盘。"""
    obj = ctx.body_obj if isinstance(ctx.body_obj, dict) else {}
    up = obj.get('up_data')
    if not isinstance(up, list):
        up = []
    if not up:
        # 探针/缺参：至少别炸
        return ctx.ok({}, '★ 更新人物附加数据（无 up_data）')
    touched = []
    for item in up:
        if not isinstance(item, dict):
            continue
        rw = _s(item.get('rwId'))
        emp = _find_emp(st, rw)
        if emp is None:
            continue
        extra = item.get('extra')
        if isinstance(extra, dict):
            dst = emp.setdefault('extra', {})
            if not isinstance(dst, dict):
                dst = {}
                emp['extra'] = dst
            dst.update(extra)
            touched.append('%s:%s' % (rw, ','.join(sorted(extra.keys()))))
        for k in ('fjId', 'jobType', 'defaultZhongCheng'):
            if item.get(k) not in (None, ''):
                emp[k] = item[k]
    _save(ctx, st)
    return ctx.ok({}, '★ 更新人物附加数据（%s）' % ('; '.join(touched) or '无匹配'))


def _guaike_reward(ctx, st):
    """`get_guaike_reward` —— 江湖怪客/门客代打的胜负奖励。

    `data.yinpiao/yueli/weiwang`：原版这些数值在她客户端**没有配表**
    （只有客户端自算的交子/经验/潜能，走 `add_currency_number`），所以这里老实回 0，
    但**真做门客代打的忠诚度推进**（`data.defaultZhongCheng` / `level_up` / `trait`）：
    一次代打 +`10 * 怪客等级`，10/20/30 都是她 `familylist["派遣表"].zhongcheng`
    里真实存在的档位（全表 41 条的取值 = 10/20/30/40/50/60）。
    """
    obj = ctx.body_obj if isinstance(ctx.body_obj, dict) else {}
    is_menke = _i(ctx.param('isMenKe'), 0)
    mk = _s(ctx.param('menKeId') or obj.get('menKeId'))
    out = {'yinpiao': 0, 'yueli': 0, 'weiwang': 0, 'activityItems': [],
           'defaultZhongCheng': 0, 'level_up': False, 'trait': {}}
    if is_menke == 1 and mk:
        emp = _find_emp(st, mk)
        if emp is None:
            return ctx.fail('没有这个门客的信息。', '★ 怪客奖励：查无门客（%s）' % mk)
        zc_old = _num(emp.get('defaultZhongCheng'), 0)
        lv_old = _fid_lv(zc_old)
        # 代打涨忠诚：档位取她 `派遣表.zhongcheng` 里真有的 10/20/30
        gain = 10 * max(1, min(3, _i(ctx.param('guaikeLv'), 1)))
        zc_new = max(0.0, min(float(ZC_MAX), zc_old + gain))
        emp['defaultZhongCheng'] = int(zc_new)
        level_up = _fid_lv(zc_new) > lv_old
        traits = {}
        if level_up:
            for tid in _roll_traits(_num(emp.get('traitVal'), 0)):
                for i in (1, 2, 3):
                    k = 'trait%d' % i
                    if not _s(emp.get(k)):
                        emp[k] = tid
                        traits[k] = tid
                        break
                if len(traits) >= 3:
                    break
        _save(ctx, st)
        out.update({'defaultZhongCheng': int(zc_new), 'level_up': bool(level_up), 'trait': traits})
    gain = 10 * max(1, min(3, _i(ctx.param('guaikeLv'), 1))) if is_menke else 0
    return ctx.ok(out, '★ 怪客奖励（银票/阅历/威望原版无配表 ⇒ 0；门客忠诚 +%d）' % gain)


def _shenshi_reward(ctx, st):
    """`get_shenshi_reward` —— 身世任务奖励：type 1 薪资减半 / 2 n 天免薪 / 3 武功等级增加。

    客户端只看 errcode，但**真实推进**是这里的：把 `extra.shenshi_status` 置 3（已完成）,
    `HomelandRoleTemplate:unlockRoleFunc` :550 会据此关掉"身世概况"、放开"闲聊"。
    """
    typ = _i(ctx.param('type'), 0)
    rw = _s(ctx.param('objId'))
    up = ctx.param('up_data')
    emp = _find_emp(st, rw)
    if emp is None:
        return ctx.fail('没有这个人的信息。', '★ 身世奖励：查无此人（%s）' % rw)
    extra = emp.setdefault('extra', {})
    if not isinstance(extra, dict):
        extra = {}
        emp['extra'] = extra
    extra['shenshi_status'] = 3
    done = 'shenshi_status=3'
    if typ == 1:
        extra['pay_half'] = 1
        done += ' 薪资减半'
    elif typ == 2:
        days = _i(up, 0) or _i(ctx.param('day'), 0)
        extra['free_pay_days'] = days
        done += ' %d 天免薪' % days
    elif typ == 3:
        skills = emp.get('mobanSkill')
        if not isinstance(skills, dict):
            skills = {}
            emp['mobanSkill'] = skills
        add = up if isinstance(up, dict) else {}
        for k, v in (add or {}).items():
            skills[_s(k)] = _i(v, 0)
        done += ' 武功等级 %s' % (','.join(sorted(_s(k) for k in (add or {}))) or '无')
    _save(ctx, st)
    return ctx.ok({'type': typ, 'objId': rw, 'shenshi_status': 3},
                  '★ 身世奖励（%s）' % done)


def _manage_payment(ctx, st):
    """`get_manage_payment/<dpId>` —— 她只读 `data.day`/`data.total_pay`（都是数字）。

    日单价取她 `familylist["房屋地皮"][dpId].cost`。★ 同契约的实现也在
    `fz_api/homeland_life.py`，路由按模块名排序 ⇒ 实际走它那份；这里是兜底。
    """
    dp = _s(ctx.args[0] if ctx.args else ctx.param('dpId'))
    cost = 0
    for v in (_fam().get('房屋地皮') or {}).values():
        if isinstance(v, dict) and _s(v.get('dpId')) == dp:
            cost = _i(v.get('cost'), 0)
            break
    now = int(time.time())
    rec = st['tax'].setdefault(dp or '-', {'last_pay': now, 'paid': 0})
    day = int(max(0, (now - _i(rec.get('last_pay'), now)) // 86400))
    rec['day'] = day
    _save(ctx, st)
    return ctx.ok({'day': day, 'total_pay': cost * day, 'dpId': dp,
                   'unit': 'yuanbao', 'cost': cost},
                  '★ 地税欠费（%s：欠 %d 天 / %d 元宝）' % (dp or '?', day, cost * day))


def _relation_caps():
    """她 `UserMapRelation` 四层真长度（车夫出行的 `data.max` 不能超过它）。"""
    if 'caps' not in _CACHE:
        txt = _read(USERMAPREL_LUA)
        caps = []
        for var in ('cityAreaRelation', 'cityDirRelation', 'villageRelation', 'villageAreaRelation'):
            m = re.search(r'\b' + var + r'\s*=\s*\{(.*?)\n\}', txt, re.S)
            caps.append(len(re.findall(r'\[\d+\]\s*=\s*"', m.group(1))) if m else 0)
        _CACHE['caps'] = caps if all(c > 0 for c in caps) else [16, 20, 26, 20]
    return _CACHE['caps']


def _location_max(ctx, st):
    """`get_location_max/<mapIndex>` —— `data.max` 必须是**长度 4 的数组**。

    `CheFuQianWangLayer:setTotalList` :100 `assert(startIndex > limitArray[1])` 会崩，
    且 `_totalList[n][i]` 取到 nil 也会崩 ⇒ 第 1 层给 startIndex+3（本城 4 个郊外），
    其余给表的真长度。★ 同契约实现在 `fz_api/homeland_life.py`（路由优先它）。
    """
    idx = _i(ctx.args[0] if ctx.args else ctx.param('mapIndex'), 1)
    start = {1: 1, 2: 5, 3: 9, 4: 13}.get(idx, 1)
    caps = _relation_caps()
    m = [min(start + 3, caps[0]), caps[1], caps[2], caps[3]]
    m[0] = max(1, m[0])
    return ctx.ok({'max': m}, '★ 车夫可达（mapIndex=%d → %s）' % (idx, m))


def _settle_dream(ctx, st):
    """`settle_overdue_dream` —— errcode 2 = 没有需要结算的过期梦境（她接着拉上次梦境数据）。"""
    run = st.get('dream')
    if isinstance(run, dict) and run:
        st['dream'] = {}
        _save(ctx, st)
        return ctx.ok({'eventsInfo': [], 'reward': []}, '★ 过期梦境结算')
    return ctx.fail('没有需要结算的过期梦境', '★ 过期梦境结算（无）', 2)


def _check_goods(ctx, st):
    """`check_goods_valid` —— 应答 `data` 必须是**表**，元素读 `v.itemId` / `v.number`。

    ★ 原来没人接管时回的是 `{dataVer}`，她 `for k,v in pairs(data)` 拿到的是**数字**，
    `v.itemId` 直接崩（被 xpcall 吞掉 ⇒ 界面整体卡死）。这里至少保证形状正确。
    背包真值在客户端存档里，服务端没有 ⇒ 默认 0（预留 `state["items"]` 供以后填）。
    """
    obj = ctx.body_obj if isinstance(ctx.body_obj, dict) else {}
    ids = obj.get('itemIds')
    if not isinstance(ids, list):
        ids = [ids] if ids not in (None, '') else []
    if not ids:
        ids = [a for a in ctx.args if a] or ['yuhuiling']
    items = st.get('items') if isinstance(st.get('items'), dict) else {}
    out = []
    for i in ids:
        key = _s(i)
        if key:
            out.append({'itemId': key, 'number': _i(items.get(key), 0), 'expired': 0})
    return _ok_list(ctx, out, '★ 检查物品有效（%d 项）' % len(out))


def _get_all_persons(ctx, st):
    """`get_all_persons`（POST `{mid, job}`）——「府上这个人有没有」的通用查询。

    ★★ 2026-10-13 补（客户反馈：师门任务「邀请同行」选不出门客）：
      原来只在 `fz_boot_server` 里有个空壳（回 `{list: []}`——形状还是错的，
      客户端把 `data` 当**数组**用：`titleTable[2].list = data` / `data[1].name`）。

    两个客户端消费方（源码实锤）：
      · `HuPengYinBanLayer.lua:369` 师门挂机任务「呼朋引伴」窗·**门客页签**
        —— 逐条读 `id`/`name`/`job`(=='menke001')/`modal`/`defaultZhongCheng`；
      · `ReadBook.lua:400` 读书的「书童陪读」—— 读 `data[1].name` /
        `data[1].defaultZhongCheng`（`job="shutong001"`）。

    数据源 = **本模块自己的员工账**（`st['employees']`，add_employee 存的同一条记录，
    单一数据源），补齐 `id`（她拿 rwId 当条目 id）后整条下发。
    同门（真人）在私服里没有 ⇒ 那边空着是正确行为；门客/书童都是自家人，必须给到。
    """
    mid = _mid_of(ctx)
    job = _s(ctx.param('job') or ctx.param('jobType'))
    out = []
    for e in _emps_for_mid(ctx, st, mid):
        if not isinstance(e, dict):
            continue
        if job and _s(e.get('jobType')) != job:
            continue
        d = _fix_person(e, job or None)
        d['id'] = _s(e.get('rwId') or e.get('objId'))
        out.append(d)
    return _ok_list(ctx, out, '★ 全部人物（%s ×%d）' % (job or 'all', len(out)))


def _ok_list(ctx, arr, note):
    """`data` **本身就是数组** 的应答（`save_employee_list` / `check_goods_valid`）。

    ★ 不能用 `ctx.ok(arr)`：`Ctx.ok` 会给字典补 `dataVer`，而 `dict(非空数组)` 直接
    `ValueError: dictionary update sequence element #0 has length N; 2 is required`
    （框架 `__init__.py` 里那个 `dict(data)` 只对 dict 成立）。她这边
    `BaseHttp:createGetResponseFunction` :364 把 `data` 原样透传，不需要 `dataVer`。
    """
    return ctx.enc({'errcode': 0, 'data': arr, 'rand_t': time.time()}), note


def _yield_to_owner(ep):
    """`_YIELD` 里那几个接口：对方模块在位就让位（返回 True）。"""
    names = _YIELD.get(ep)
    if not names:
        return False
    try:
        import importlib
    except Exception:                        # noqa: BLE001
        return False
    for name in names:
        try:
            m = importlib.import_module('fz_api.' + name)
        except Exception:                    # noqa: BLE001
            continue
        if ep in (getattr(m, 'ENDPOINTS', None) or ()) and callable(getattr(m, 'handle', None)):
            return True
    return False


def handle(ctx):
    ep = ctx.endpoint
    if ep not in ENDPOINTS:
        return None
    if _yield_to_owner(ep):
        return None                          # 让更专业的模块应答（见模块顶部 `_YIELD`）
    st = _load(ctx)
    if ep == 'get_employee_list':
        return _get_employee_list(ctx, st)
    if ep == 'save_employee_list':
        return _save_employee_list(ctx, st)
    if ep == 'add_employee':
        return _hire(ctx, st)
    if ep == 'delete_employee':
        return _fire(ctx, st)
    if ep == 'get_employee_data':
        return _employee_data(ctx, st)
    if ep == 'update_employee_data':
        return _update_employee_data(ctx, st)
    if ep == 'update_employee_extra':
        return _update_employee_extra(ctx, st)
    if ep == 'use_homebw':
        return _use_homebw(ctx, st)
    if ep == 'get_guaike_reward':
        return _guaike_reward(ctx, st)
    if ep == 'get_shenshi_reward':
        return _shenshi_reward(ctx, st)
    if ep == 'get_manage_payment':
        return _manage_payment(ctx, st)
    if ep == 'get_location_max':
        return _location_max(ctx, st)
    if ep == 'settle_overdue_dream':
        return _settle_dream(ctx, st)
    if ep == 'check_goods_valid':
        return _check_goods(ctx, st)
    if ep == 'get_all_persons':
        return _get_all_persons(ctx, st)
    return None


# ===========================================================================
# 八、只读体检（在 python 里核对她的表读得对不对，不参与路由）
# ===========================================================================
def _selftest():
    jobs = _jobtypes()
    c = _make_candidate('puren001', zc=300)
    return {
        'mobans': len(_mobans()), 'roletypes': len(_roletypes()),
        'traits': len(_traits()), 'lives': len(_lives()),
        'jobs': jobs, 'job_cn': [JOB_CN[j] for j in jobs],
        'names_gj': [len(x) for x in _names_guanjia()],
        'names_puren': [len(x) for x in _names_puren()],
        'caps': _relation_caps(),
        'sample_puren': {k: c[k] for k in ('name', 'sex', 'modal', 'defaultZhongCheng',
                                           'price', 'price_unit', 'shenShi', 'character')},
        'sample_menke_modal': _s((_pick_moban('menke001', 100, '男') or {}).get('mobanid')),
        'sample_guanjia_modal': _s((_pick_moban('guanjia001', 100, '男') or {}).get('mobanid')),
    }


if __name__ == '__main__':
    import json
    print(json.dumps(_selftest(), ensure_ascii=False, indent=1))
