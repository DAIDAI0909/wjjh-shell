# -*- coding: utf-8 -*-
# ================= 离线包路径根（fz_make_offline_bundle.py 自动注入） =================
# 手机上整个服务端就是一个目录，表在哪、状态写哪，全部相对包根算。
# （有的模块原来把绝对路径写死，本身没 import os —— 这里一并补上）
import os
import os as _osp


def _off_find_bundle(_f):
    """从模块所在目录往上找包根（认 fz_boot_server.py）。
    ★ fz_api/*.py 的 __file__ 在 <根>/fz_api/ 下，直接 dirname 会算错一层。"""
    _d = _osp.path.dirname(_osp.path.abspath(_f))
    for _ in range(6):
        if _osp.path.exists(_osp.path.join(_d, 'fz_boot_server.py')):
            return _d
        _u = _osp.path.dirname(_d)
        if _u == _d:
            break
        _d = _u
    return _osp.path.dirname(_osp.path.abspath(_f))


_OFF_BUNDLE = _off_find_bundle(__file__)
_OFF_FZ_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_fz')
_OFF_INK_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_ink')
_OFF_WORK_ROOT = _OFF_BUNDLE
# =====================================================================================
# ★ 2026-10-04 商城空货架修复：客户端资源表解析——PC 开发树优先，设备上自动回退
#   到包内 client_fz 副本（jhserver/client_fz = fangzhi_lua_dec 的同步拷贝）。
def _fz_res(*parts):
    base = os.path.join(_OFF_FZ_ROOT, 'res', 'script')
    if not os.path.isdir(base):
        base = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            '..', 'client_fz', 'res', 'script')
    return os.path.join(base, *parts)

# -*- coding: utf-8 -*-
"""各种商店 —— 黑市 / 功勋(功绩) / 门派兑换 / 游商(商人) / 声望 / NPC 买卖 /
储物箱 / 面具材料 / 藏衣阁-悬兵洞 / 订单支付 / 制作组(面具商人) / 充值商店。

===========================================================================
一、契约（逐个读她客户端源码读出来的，不是猜的）
===========================================================================
URL 定义全在 `assets/src/app/extends/Http/HttpManager.lua`（`HttpManagerEx` 就是它，
`models/loader/Loader.lua:272`），调用点与回调体逐个读过：

| 接口(URL 末段) | 上行 | 她读的 `data.字段`（类型） | 出处 |
|---|---|---|---|
| `black_market_store` | GET | `status`(串 "OPEN") `list`(数组 `{id,itemId,count,name,price,priceUnit,discount}`) `currencyList`(数组 `{unit,name,num}`) | `models/Store/BlackStore.lua:190-227`(:200/:211) `models/Chapman/Chapman.lua:152-202` |
| `buy_black_goods` | POST `{goodsInfo=[{itemId,number,price,priceUnit}],client_trans_id,mark}` | `goodsList`(数组 `{itemId,number,price,priceUnit}`)；errcode 1=非法 2=列表刷新 | `BlackStore.lua:446-501`(:455/:461) |
| `get_mingbi_list` | POST | `status`(串 "OPEN") `list`(数组 `{itemId,price}`) `count`(数，冥币) | `Chapman.lua:48-89`(:63/:69/:79) |
| `buy_mingbi_goods` | POST `{order_id,id}` | —（只看 errcode） | `views/layer/MapLayer/MapBagLayer.lua:2050` |
| `get_merit_goods` | POST `{familyId,id,dataVer,isSent}` | `goods`(**对象** `{type(数1物品/2属性),id,number,name,icon}`) `dataVer`(数) `msg`(串) | `models/Store/ReputationStore.lua:110-142`(:115-133) |
| `get_sect_merit_store` | POST `{familyId,isRefresh}` | `buyTimes`(数) `buyLimit`(数) `refreshCost`(数) `list`(数组 `{id,goods={type,id,number,name,icon},state(0买/1领/2售罄),stock,price,thresholdText,origPrice?}`) | `ReputationStore.lua:31-58`(:41-49) + `:164-207` |
| `buy_merit_goods` | POST `{familyId,id}` | `reputation`(数，可空) | `ReputationStore.lua:92-108`(:97) |
| `get_sect_exchangeStore` | POST `{familyId}` | `currencies`(数组 `{id,count}`) `list`(数组 `{id,state,stock,price,goods={id,number},cost={id,number},unlockConditionText,origPrice?}`) | `models/Store/FamilyExchangeStore.lua:30-45` + `:105-164` |
| `buy_sect_exchangeGoods` | POST `{familyId,id}` | `goods`(对象 `{id,number}`) `donate`/`renown`/`gbpoint`/`sgbpoint`/`reputation`(数，都可空) `msg`(串) | `FamilyExchangeStore.lua:63-103` |
| `trader_store` | GET `/trader_store/<npcId>` | `list`(数组 `{id,itemId,count,name,price,priceUnit,is_buy,is_buy_time,price2?,priceUnit2?,time}`) `yuanbao`(数) | `models/Chapman/Chapman.lua:92-150`(:109/:116/:127/:140) |
| `buy_trader_goods` | POST `{npc_id,itemId,client_trans_id,voucher_num}` | —（只看 errcode；本地扣减在 `MapBagLayer.lua:1776-1796`） | `MapBagLayer.lua:1763-1805` |
| `del_buy_npc_time` | POST `{npc_id,itemId}` | —（只看 errcode） | `MapBagLayer.lua:1865-1874` |
| `get_prestige_goods` | POST `{npc_id,is_refresh}` | `list`(数组 `{itemId,price,unit,needSw}`) `point`(数) `unit`(串) `shengwang`(数) `title`(数/布尔) `next_yuanbao`(数) `remove`(数，仅刷新分支读) | `models/Chapman/Chapman.lua:456-522`(:481-517) `MapBagLayer.lua:1506-1548`(:1520-1547) |
| `buy_prestige_goods` | POST `{itemId,client_trans_id,npc_id}` | —（只看 errcode） | `MapBagLayer.lua:2149-2157` |
| `get_storage_box` | GET `/get_storage_box/<baseId>` | `storage`(数组 `{id,extra={itemId}}`) `point`(数) `list`(数组 `{unit,price,itemId,countNum}`) `unit`(串) | `Chapman.lua:416-446`(:433-436) + `models/Chapman/CkChapman.lua:25-100` |
| `buy_storage_box` | POST `{client_trans_id,itemId,npc_id,fid}` | `remove_point`(数) `total_point`(数) `storage_box`(对象 `{id,extra={itemId}}`) | `CkChapman.lua:176-220`(:187-210) |
| `buy_mask_piece_2` | POST `{order_id,id}` | —（只看 errcode） | `MapBagLayer.lua:1959-1968` |
| `get_ckitems_list` | POST `{ckname,ver}` | `ver`(数) `list`(数组 `{itemId,total,update_time}`) | `models/ShenBing/CangYiGeModel.lua:37-50` + `:80-99`；`BlackStore.lua:520-552` |
| `get_buy_order_id` | GET | `order_id`(串) | `models/transCheck/TransCheck.lua:27-33` |
| `get_order_id/<type>` | POST `{...}` | `order_id`(串) | `models/order/Order.lua:16-31`（type=1 首充 `{key=1}` / type=2 累计充值 `{key=金额}`） |
| `rollback_order_status/<type>` | POST `{...,order_id}` | —（只看 errcode；非 0 她删本地订单） | `Order.lua:142-172` |
| `get_reward_2/<rType>` | POST `{trans_id,is_homeland}` | —（只看 errcode：0/7 成功，其余失败） | `TransCheck.lua:211-231` `views/layer/StoreLayer/YueKaLayer.lua:443-503` |
| `get_jhms_desc` | GET | `eleven`(真值) `status`(串 "CLOSE" 关) `errmsg`(串) `title_status`(**对象** `{expired_time,refresh_time,price_desc,not_received_days,notjia_received_days,today_not_received_days}`) `title_name`(对象 `{title,desc}`) `title_receive_per_day`(对象 `{yuanbao,money,exp,pot,yinpiao}`) `title_receive_once_prize`(对象 `{fuyuandan,desc}`) `title_extra_rights`(**数组**串) `canBuy`(布尔) `message`(串) `product_id`(串) | `YueKaLayer.lua:52-136` + `:246-339` |
| `get_jhms_reward` | POST `{trans_id,is_homeland,days}` | —（只看 errcode） | `YueKaLayer.lua:562-607` |
| `get_goods/<itemId>` | GET | `id`(由上行覆盖) `itemId` `name` `price`(数) `dsc1` `dsc2` `icon` `share` `discount`(数，1=无折) | `views/layer/PayLayer/YuanBaoPayLayer.lua:76-130`(:90-100) |
| `get_goods_2/<itemId>` | POST `{others}` | 同上（`NewYuanBaoPayUI` 再读 `itemData.dsc`） | `YuanBaoPayLayer.lua:200-236` + `:132-167` |
| `buy_goods_3/<itemId>` | POST `{id,itemId,quantity,client_trans_id,discount,...}` | `special_reward`(可空) `total_yuanbao`(数) `remove_yuanbao`(数) `activity`(对象，可空) | `TransCheck.lua:302-362`(:328-347) |
| `check_fail_transaction_2/<transType>` | POST `{trans_id}` | —（只看 errcode，语义见 `TransCheck.lua:246-268` 注释） | `TransCheck.lua:236-272` |
| `check_pay_sign` | POST `{key,activity_id?}` | —（只看 errcode） | `views/layer/StoreLayer/PayLayer.lua:142-261` `YaShiLayer.lua:169` `YueKaLayer.lua:146` |
| `get_applestore_list` | GET | `store_status`(串 "OPEN") `list`(数组 `{id,name,dsc,yuanbao,price,real_price,key}`) `discount`(对象 `{tostring(id):倍率}`) `title`(串) `time`(串) | `views/layer/StoreLayer/PayLayer.lua:38-83` + `:99-134` |
| `get_npc_list` | GET | `data1`(对象: npcId→房间/茅房 id) `data2`(对象: npcId→累计次数) | `models/ZhiZuoZu/ZhiZuoZu.lua:240-252` + `:254-288` |
| `add_npc_record/<npcId>` | GET | `npc_sum`(数，今日完成次数) | `models/map/MapHandle/Modules/SpecialModule/SpecialModule.lua:68-71` |
| `get_mask_list` | GET | `status`(串 "OPEN") `points`(数，美誉) `yuanbao`(数，刷新价) | `ZhiZuoZu.lua:355-429`(:367/:378/:381) |
| `refresh_mask_list` | POST `{order_id}` | —（只看 errcode） | `ZhiZuoZu.lua:407-419` |
| `matters_shop_info` | POST `{type,currencyVersion}` | `yuanbao_num`(数) `currency_number`(数) `currency_name`(串) `isRefreshLimit`(真值) `matters_list`(数组 `{id,num}`) `goods_list`(数组 `{key,num,price,id}`) `currencyVersion`(数) | `models/Store/XuJuanStore.lua:83-141`(:86-99/:115-137) |
| `buy_matters` | POST `{goodsKey,currencyVersion}` | `reward`(对象 `{id,num}`) `currencyVersion`(数) `msg`(串)；errcode 2 也算成功但弹 errmsg | `XuJuanStore.lua:53-81`(:57-73) |
| `get_devote_list` | POST `{type,menpai}` | `list`(数组 `{id,itemId,buyPrice,salePrice,priceUnit,unit,name,dsc,status(0=未买)}`) `yuanbao`(数) | `TransCheck`/`RoleObserveModel.lua:768-790`、`views/layer/SalesLayer/SalesLayer.lua:603-651`、`SalesLayer.lua:344-442` |
| `get_devote_list_by_yuanbao` | POST `{order_id,type,menpai}` | 同上 | `SalesLayer.lua:657-690` |

===========================================================================
二、内容全从她自己的表来（`work/fz_luatable.py` 解析 `res/script/**`）
===========================================================================
* `store/shoplist.lua` → `["Sheet1"]`（**2228 件**，键就是 `GoodsHelper:getGoodsResClass(id)`
  查的那个字符串键，如 `"400039"`）。每件的 `id/itemId/itype/name/dsc/icon/viewtype/extra`。
  ★ 所有面板给客户端的 `id` / `goodsId` **一律是这张表的键**，不是 `itemId` ——
    `models/Store/GoodsHelper.lua:34-44` 明写 `index = tostring(id)` 查不到就 `error()`。
  ★ `itype` 就是 `models/Store/Goods.lua` 的 `Goods.Const.TYPE`
    （1道具 2客户端特殊道具 3客户端属性 4服务器物品 5服务器缓存 6可回溯 7解锁功能 8江湖雅士
     9称号 10货币管理货币）。
* `store/storeItem.lua` → `["shangchengwupin"]`（**194 件**，按 `itemId` 索引）——
  游商/黑市/商城价的**唯一真实来源**（`buyPrice` / `salePrice` / `priceUnit` / `unit`）。
* `others/familylist.lua` → `["储物箱"]`（13 个箱子：`id/name/dsc/addCapacity/grade`）——
  储物箱面板与 `ckLimit` 的真正来源（她客户端 `models/HomelandModel/FurnitureModel/StorageBox.lua:3`）。
* `others/monetarymanagement.lua` → `["Sheet1"]`（货币表）与 `models/role/Role.lua` 的
  `getCHAttrName` 表 —— 币种中文名（`reputation`=个人功绩、`donate`=佳绩、`gbpoint`=师门昌盛度…）。
* 制作组面具材料：`models/ZhiZuoZu/ZhiZuoZu.lua:177-207` 里写死的 28 个 `cailiao200_01..28`
  （**客户端就是这张表**，服务端只是决定当天上哪几件）。

===========================================================================
三、钱与物品：**不另造第二份账**
===========================================================================
货币与背包一律走 `fz_api/items_currency.py` 导出的接口（`_purse` 落在 `homeland_state.json`，
与宿主服务端共用一份钱袋子）：
  `get_count(ctx,item_id)` / `add_count` / `spend` / `grant` / `get_currency(ctx,kind)` /
  `add_currency` / `set_currency` / `canon` / `item_info` / `currencies` / `currency_name` /
  `goods()` / `by_item_id()` / `sell_price()`
本模块**只**在 `work/shop_store_state.json` 里存"商店状态"（刷新时间、当天货架、限购计数）。

★ 已知没做 / 做不了（诚实标注，不用假数据糊）：
  1. `get_applestore_list` —— 充值商品表（`real_price`/`product.key`）**她客户端里没有这张表**，     它由原官方服务端 + 应用商店 SDK 下发；我全量搜过 `ink_dec`（`real_price` 只在
     `PayLayer.lua:213` 被读、没有任何配置表）。所以这里**不编造商品**，按"充值商店已关闭"
     返回（`store_status="CLOSED"` + `list=[]`），她客户端 `PayLayer.lua:64-69` 本来就有
     "充值商店已关闭" 分支，不会崩。
  2. `check_pay_sign` 同理：原版是服务端拿应用商店的签名订单去校验，这里没有 SDK 订单来源，
     只做"参数结构校验"（`key` 缺失回 errcode 1），**不伪造已支付**。
  3. 原版这些商店的库存/限购/随机货架都在官方 DB 里（客户端只发 `npcId`/`familyId`），
     本模块按她表里的真实商品 + 确定性抽签生成当天货架（同样输入永远同一批，不闪），
     限购/库存/刷新时间落盘在 `shop_store_state.json`。
  4. **有 9 个接口的处理函数写好了但没声明路由**（`ENDPOINTS_DELEGATED`，详见常量上方注释）：
     `add_npc_record` / `buy_mask_piece_2` / `buy_mingbi_goods` / `buy_npc_goods` /
     `buy_prestige_goods` / `buy_trader_goods` / `del_buy_npc_time` / `get_prestige_goods`
     已由 `map_shop` 实现且生效，`check_pay_sign` 由 `action_festival` 实现且生效
     （`dispatch` 按模块名字母序取第一个 ⇒ 我声明了也是死代码，还会误报"接口撞车"）。
"""
import json
import os
import time

NAME = 'shop_store'
TITLE = '商店（黑市/功勋/门派兑换/游商/声望/NPC/储物箱/制作组/订单）'

ENDPOINTS = [
    # 黑市 / 冥币
    'black_market_store', 'buy_black_goods', 'get_mingbi_list',
    # 功勋（功绩）商店
    'get_merit_goods', 'buy_merit_goods',
    # 门派兑换商店
    'get_sect_exchangeStore', 'buy_sect_exchangeGoods', 'get_sect_merit_store',
    # 商人 / 游商
    'trader_store', 'buy_matters', 'matters_shop_info',
    # 储物箱
    'get_storage_box', 'buy_storage_box',
    # 藏衣阁 / 悬兵洞
    'get_ckitems_list',
    # 订单 / 支付
    'get_order_id', 'rollback_order_status', 'get_reward_2', 'get_applestore_list',
    'get_jhms_desc', 'get_jhms_reward', 'get_goods', 'get_goods_2',
    'buy_goods_3', 'check_fail_transaction_2', 'get_buy_order_id',
    # 制作组（面具商人）
    'get_mask_list', 'refresh_mask_list', 'get_npc_list',
    # 贡献商人（师门/游侠 NPC 交易，SalesLayer 用）
    'get_devote_list', 'get_devote_list_by_yuanbao',
]

# ===========================================================================
# ★ 下面是**不在 `ENDPOINTS` 里**的 9 个接口 —— 处理函数留在文件里，但不声明路由。
#
# 原因：这 9 个名字 `map_shop` / `action_festival` 也声明了，而 `fz_api.dispatch()` 按
# **模块名字母序**取第一个非 None（`__init__.py:206/240-250`）：
#     'map_shop' < 'shop_store'，'action_festival' < 'shop_store' ⇒ 我永远是后者。
# 也就是说我自己那份是**死代码**，声明了只会让 `load_modules()` 报"接口撞车"，
# 还会让人误以为这个接口是 shop_store 在负责。所以摘掉名字、保留实现：
#   * 它们已由 `map_shop`（8 个）/ `action_festival`（1 个）完整实现（逐个核对过契约，
#     字段与类型都对，`buy_npc_goods` 的 `data.remove_point` 也给了数字）；
#   * 处理函数 `_ep_xxx` 仍留在本文件（`_HANDLERS` 里也还挂着），想收回只需把名字加回
#     上面的 `ENDPOINTS` —— 立刻生效，不用再写一遍。
#
#   add_npc_record         → map_shop（调用点 models/ZhiZuoZu + models/map/.../SpecialModule）
#   buy_mask_piece_2       → map_shop（调用点唯一：views/layer/MapLayer）
#   buy_mingbi_goods       → map_shop（同上）
#   buy_npc_goods          → map_shop（同上）
#   buy_prestige_goods     → map_shop（同上）
#   buy_trader_goods       → map_shop（同上）
#   del_buy_npc_time       → map_shop（同上）
#   get_prestige_goods     → map_shop（调用点 models/Chapman + views/layer/MapLayer）
#   check_pay_sign         → action_festival（调用点主要在 models/Action、
#                            views/layer/ActionLayer/SpringFestival_2021）
#
# 想把它收回来：把名字加进上面的 `ENDPOINTS`，并让对家从它自己的 `ENDPOINTS` 摘掉。
# ===========================================================================
ENDPOINTS_DELEGATED = [
    'add_npc_record', 'buy_mask_piece_2', 'buy_mingbi_goods', 'buy_npc_goods',
    'buy_prestige_goods', 'buy_trader_goods', 'del_buy_npc_time', 'get_prestige_goods',
    'check_pay_sign',
]


STATE = 'shop_store_state.json'
RES_ROOT = _fz_res()
SHOPLIST = os.path.join(RES_ROOT, 'store', 'shoplist.lua')
STOREITEM = os.path.join(RES_ROOT, 'store', 'storeItem.lua')
FAMILYLIST = os.path.join(RES_ROOT, 'others', 'familylist.lua')

# `models/Store/Goods.lua` Goods.Const.TYPE
T_ITEM = 1            # 道具（进背包）
T_SPECIAL = 2         # 客户端特殊道具
T_ATTR = 3            # 客户端属性
T_SERVER_ITEM = 4     # 服务器物品
T_UNCEL = 7           # 解锁功能道具
T_TITLE = 9           # 称号
T_CURRENCY = 10       # 货币管理货币

# 能够真发给玩家的商品类型（其余交给物品模块已有的接口）
GRANTABLE = (T_ITEM, T_SPECIAL, T_SERVER_ITEM, T_UNCEL, T_CURRENCY)

# 冥币：她的显示单位是"亿"（`MapBagLayer.lua:1654` 拼 "亿"）
MINGBI = 'mingbi'
MONEY = 'money'
YUANBAO = 'yuanbao'
GONGXIANDIAN = 'gongxiandian'
MEIYU = 'meiyu'
REPUTATION = 'reputation'   # 个人功绩（Role.lua getCHAttrName）
DONATE = 'donate'           # 佳绩
RENOWN = 'renown'           # 资历
GBPOINT = 'gbpoint'         # 师门昌盛度
SGBPOINT = 'sgbpoint'       # 贡献昌盛度

WEEK = 7 * 86400
DAY = 86400

# 制作组商人材料（`models/ZhiZuoZu/ZhiZuoZu.lua:177-207` 原样搬过来）
CAILIAO = ['cailiao200_%02d' % i for i in range(1, 29)]
# 能替换的箱子最多 6 个（`StorageBox.lua:6` HAS_MAX_STORAGE_BOX）
HAS_MAX_STORAGE_BOX = 6


# ===========================================================================
# 她自己的表（缓存挂在函数属性上，热加载不重复解析 622KB）
# ===========================================================================


def _lua(path, key=None):
    cache = getattr(_lua, '_cache', None)
    if cache is None:
        cache = {}
        _lua._cache = cache
    if path not in cache:
        val = {}
        try:
            import fz_luatable
            t = fz_luatable.load_lua_table(path) or {}
            val = (t.get(key) if key else t) or {}
            if not isinstance(val, dict):
                val = {}
        except Exception:                       # noqa: BLE001
            val = {}
        cache[path] = val
    return cache[path]


def goods():
    """`store/shoplist.lua["Sheet1"]` —— 2228 件，键就是客户端查商品用的 id。"""
    return _lua(SHOPLIST, 'Sheet1')


def store_items():
    """`store/storeItem.lua["shangchengwupin"]` —— 按 itemId 索引的真实商城价。"""
    return _lua(STOREITEM, 'shangchengwupin')


def storage_boxes():
    """`others/familylist.lua["储物箱"]` —— 13 个真箱子。"""
    return _lua(FAMILYLIST, '储物箱')


def _by_item_id():
    """{itemId: 商品表键} —— 反查用（她有几个接口上行给的是 itemId）。"""
    m = getattr(_by_item_id, '_cache', None)
    if m is None:
        m = {}
        for gid, g in goods().items():
            if isinstance(g, dict) and g.get('itemId'):
                m.setdefault(str(g['itemId']), str(gid))
        _by_item_id._cache = m
    return m


def _int(v, d=0):
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return d


def _s(v):
    return '' if v is None else str(v)


def _key_of(gid):
    """把上行给的 id 归一成商品表键。

    她有三套 id：商品表键（"400039"）、`itemId`（"ygpill"）、`Items.lua` 的键
    （"shimenwupin29"）。客户端 `GoodsHelper` 只认第一种，所以这里尽量换过去；
    实在换不过去就原样返回（至少不会崩在她手上）。
    """
    g = goods()
    k = _s(gid)
    if k in g:
        return k
    hit = _by_item_id().get(k)
    if hit:
        return hit
    try:
        import fz_api.items_currency as ic
        c = ic.canon(k)
        if c and c in g:
            return c
    except Exception:                           # noqa: BLE001
        pass
    return k


def _info(gid):
    """一件商品的真信息（从她表里取，绝不编）。"""
    key = _key_of(gid)
    g = goods().get(key) or {}
    if not isinstance(g, dict):
        g = {}
    iid = _s(g.get('itemId')) or key
    it = store_items().get(iid) or {}
    if not isinstance(it, dict):
        it = {}
    return {
        'key': key,
        'itemId': iid,
        'name': _s(g.get('name')) or _s(it.get('name')) or key,
        'dsc': _s(g.get('dsc')) or _s(it.get('dsc')),
        'icon': _s(g.get('icon')),
        'itype': _int(g.get('itype'), 1),
        'viewtype': _int(g.get('viewtype'), 0),
        'extra': g.get('extra') if isinstance(g.get('extra'), (dict, list)) else {},
        'buyPrice': _int(it.get('buyPrice'), 0),
        'salePrice': _int(it.get('salePrice'), 0),
        'priceUnit': _s(it.get('priceUnit')) or YUANBAO,
        'unit': _s(it.get('unit')),
        'raw': g,
    }


def _cat(*itypes, **kw):
    """按 `itype` 挑商品表键（有序：数字键升序）。

    kw:
      need_price  只收 `storeItem` 里有真价（`buyPrice>0`）的
      view        只要这些 `viewtype`
    """
    need_price = kw.get('need_price')
    views = kw.get('view')
    out = []
    for gid in sorted(goods().keys(), key=lambda x: _int(x, 10 ** 9)):
        g = goods().get(gid)
        if not isinstance(g, dict):
            continue
        if itypes and _int(g.get('itype'), 0) not in itypes:
            continue
        if views is not None and _int(g.get('viewtype'), 0) not in views:
            continue
        if need_price:
            iid = _s(g.get('itemId'))
            it = store_items().get(iid) or {}
            if _int(it.get('buyPrice'), 0) <= 0:
                continue
        out.append(str(gid))
    return out


def _stable_hash(s):
    """稳定散列。

    ★ 不能用内建 `hash()`：Python 对 str 的 hash **每个进程都加随机盐**
      （PYTHONHASHSEED），服务端一重启货架就整个换一批 —— 玩家会看到商店"随机跳"。
      这里用 crc32 自己混，跨进程/跨重启完全可复现。
    """
    import zlib
    h = 2166136261
    for ch in str(s).encode('utf-8'):
        h = ((h ^ ch) * 16777619) & 0xFFFFFFFF
    return (h ^ zlib.crc32(str(s).encode('utf-8'))) & 0x7FFFFFFF


def _pick(seed, pool, n, rotate=0):
    """确定性抽签（同一 seed 永远同一批，面板不会每次刷新都变脸，重启也不变）。

    用稳定散列定位起点，然后按步长取，不引 random（要可复现）。
    """
    if not pool:
        return []
    if n >= len(pool):
        return list(pool)
    k = len(pool)
    idx = (seed if isinstance(seed, int) else _stable_hash(seed)) % k
    out, seen = [], set()
    step = max(1, k // max(1, n))
    i = (idx + rotate * step) % k
    guard = 0
    while len(out) < n and guard < k * 4:
        cand = pool[i % k]
        if cand not in seen:
            seen.add(cand)
            out.append(cand)
        i += step
        guard += 1
    # 兜底补齐（step 与 k 不互质时会提前停）
    for cand in pool:
        if len(out) >= n:
            break
        if cand not in seen:
            seen.add(cand)
            out.append(cand)
    return out


# ===========================================================================
# 价格（全部由她表里的真价推出，不凭空造）
# ===========================================================================
# 各面板的"档位系数"：黑市/游商翻倍批发价、功勋/声望/门派兑换按商品档位
SHOP_MULT = {
    'black': 2.0,
    'trader': 2.0,
    'prestige': 2.0,
}
BASE_PRICE = {
    'merit': 100,       # 功勋（个人功绩）
    'sect': 60,         # 门派兑换（佳绩）
    'matters': 120,     # 续卷
}


def _tier(v):
    """商品档位 1..3（按 viewtype：面具/挂饰/武学/宝箱 比普通道具贵）。"""
    return {0: 1, 1: 2, 2: 2, 3: 3, 4: 2}.get(_int(v, 0), 1)


def price_of(gid, shop, unit=None):
    """一件商品在这个商店里的真价格。

    优先 `storeItem.buyPrice`（她表里写的真价）× 商店系数；没有价就按档位基数推，
    并在 note 里标明是推算的，绝不当成"官方定价"。
    """
    info = _info(gid)
    base = info['buyPrice']
    if base > 0:
        mult = SHOP_MULT.get(shop)
        if mult:
            return max(1, int(round(base * mult)))
        b = BASE_PRICE.get(shop, 100)
        return max(1, b * _tier(info['viewtype']))
    b = BASE_PRICE.get(shop, 100)
    return max(1, b * _tier(info['viewtype']))


def discount_of(gid):
    """折扣：她表里没写折扣字段，只有 `storeItem` 有价的才给"黑市九折"。

    返回 1（无折）或 0.9 —— `YuanBaoPayLayer:setImageShow` 只认 "0.9"/"0.8"/"0.6"。
    """
    info = _info(gid)
    if info['buyPrice'] <= 0:
        return 1
    return 0.9 if (_int(gid, 0) % 3 == 0) else 1


# ===========================================================================
# 状态（只存"商店状态"，钱和物品一律走 items_currency）
# ===========================================================================
def _st(ctx):
    st = ctx.load_json(STATE, {})
    if not isinstance(st, dict):
        st = {}
    for k, v in (('order_seq', 0), ('orders', {}), ('merit', {}), ('sect', {}),
                 ('mask', {}), ('npc_records', {}), ('purchased', {})):
        st.setdefault(k, v)
    if not isinstance(st['orders'], dict):
        st['orders'] = {}
    return st


def _save(ctx, st):
    ctx.save_json(STATE, st)
    return st


def _uid(ctx):
    return _s(ctx.headers.get('userid') or ctx.headers.get('uuid') or 'local')


def _cur(ctx, kind):
    """读货币 —— 走 `items_currency`，不在这里另存一份钱。"""
    try:
        import fz_api.items_currency as ic
        v = ic.get_currency(ctx, kind)
        if v:
            return v
    except Exception:                           # noqa: BLE001
        pass
    try:
        import fz_api.items_currency as ic
        return ic.get_currency(ctx, kind)
    except Exception:                           # noqa: BLE001
        return 0




def _free_mode():
    """★ 2026-10-18 v37 零元购：包内 free_purchase.flag ⇒ 元宝价格显示 0。"""
    try:
        import fz_api.items_currency as _ic
        return _ic._free_purchase()
    except Exception:                           # noqa: BLE001
        return False


def _disp_price(p):
    """零花费模式（v37b）下我方礼包价格显示 0（原商场价格原样）。"""
    return 0 if (_free_mode() and p and _s(p) != '0') else p


def _spend_cur(ctx, kind, n):
    """扣货币；不够返回 False（一点都不扣）。"""
    try:
        import fz_api.items_currency as ic
        return ic.add_currency(ctx, kind, -abs(int(n))) is not None
    except Exception:                           # noqa: BLE001
        return False


def _add_cur(ctx, kind, n):
    try:
        import fz_api.items_currency as ic
        return ic.add_currency(ctx, kind, int(n))
    except Exception:                           # noqa: BLE001
        return None


def _grant(ctx, gid, n=1):
    """真发货：按 `itemId` 进背包（走 `items_currency`）。

    ★ 不能只靠 `_info(gid)`：那是在 `shoplist["Sheet1"]` 里找键，
      而**商城 11 件与礼包都不在 shoplist 里**（遁地符/艾香/渡元丹…）。
      传给 `_info` 的 `dundifu` 会查不到 ⇒ `key` 为空 ⇒ `add_count('', n)`
      ⇒ 静默不发货（本轮实测踩到：元宝扣了、`items_state.json` 里没有 dundifu）。
      所以先按传入的 `itemId` 直接发，再退回 `_info` 的键。
    """
    try:
        import fz_api.items_currency as ic
        n = abs(int(n))
        # ① 传入的就是她表里的 itemId（商城/礼包都属这类）⇒ 直接发
        r = ic.add_count(ctx, gid, n)
        if r:
            return r
        # ② 退回 shoplist 的键（老路径）
        info = _info(gid)
        for _k in (info.get('key'), info.get('itemId')):
            if _k:
                r = ic.add_count(ctx, _k, n)
                if r:
                    return r
        return None
    except Exception as e:                      # noqa: BLE001
        try:
            ctx.log('[商城] 发货失败 %s x%d：%s' % (gid, n, e))
        except Exception:                       # noqa: BLE001
            pass
        return None


def _sell(ctx, gid, n=1):
    try:
        import fz_api.items_currency as ic
        info = _info(gid)
        return ic.spend(ctx, info['key'], abs(int(n))) or \
            ic.spend(ctx, info['itemId'], abs(int(n)))
    except Exception:                           # noqa: BLE001
        return False


def _order_id(ctx, st, prefix='shop'):
    st['order_seq'] = _int(st.get('order_seq'), 0) + 1
    oid = 'FZ%s%s%d' % (prefix, _uid(ctx)[:8], st['order_seq'])
    st['orders'][oid] = {'t': int(time.time()), 'user': _uid(ctx), 'prefix': prefix}
    # 只留最近 200 条，别把状态文件撑爆
    if len(st['orders']) > 200:
        for k in sorted(st['orders'], key=lambda x: _int(st['orders'][x].get('t'), 0))[:100]:
            st['orders'].pop(k, None)
    return oid


def _new_order(ctx, st, prefix='shop'):
    oid = _order_id(ctx, st, prefix)
    _save(ctx, st)
    return oid


def _currency_body(unit, name, num):
    """`currencyList` 元素 —— 她读 `v.unit` / `v.name` / `v.num`（`BlackStore.lua:706-715`）。"""
    return {'unit': unit, 'name': name, 'num': int(num)}


def _cname(kind):
    try:
        import fz_api.items_currency as ic
        n = ic.currency_name(kind)
        if n:
            return n
    except Exception:                           # noqa: BLE001
        pass
    return kind


# ===========================================================================
# 黑市
# ===========================================================================
# 黑市货架：能进背包的真道具 + 能卖的（`storeItem` 有价），确定性抽 12 件
def _black_pool():
    return _cat(T_ITEM, T_SPECIAL, T_ATTR, T_SERVER_ITEM, need_price=True)


def _mingbi_pool():
    # 冥币商人卖"贵东西"：面具/挂饰/武学这一档
    return _cat(T_ITEM, view=(1, 2, 3))


def _ep_black_market_store(ctx, st):
    pool = _black_pool()
    keys = _pick('black-%s' % _uid(ctx), pool, 12)
    lst = []
    for k in keys:
        info = _info(k)
        lst.append({
            'id': _int(k, 0),
            'itemId': info['itemId'],
            'count': 1,
            'name': info['name'],
            'price': price_of(k, 'black'),
            'priceUnit': YUANBAO,
            'discount': discount_of(k),
        })
    cl = [
        _currency_body(MONEY, _cname(MONEY), _cur(ctx, MONEY)),
        _currency_body(YUANBAO, _cname(YUANBAO), _cur(ctx, YUANBAO)),
        _currency_body(MINGBI, _cname(MINGBI), _cur(ctx, MINGBI)),
    ]
    return ctx.ok({
        'status': 'OPEN',
        'list': lst,
        'currencyList': cl,
    }, '★ 黑市货架 %d 件（%s 表真道具，价取 storeItem.buyPrice×2）' % (len(lst), 'shoplist'))


def _ep_buy_black_goods(ctx, st):
    # ★ 先吃 `body_obj`（真客户端是 JSON），`ctx.param` 的 key=value 兜底只对明文探针有用
    raw = ctx.body_obj.get('goodsInfo')
    if raw is None:
        raw = ctx.param('goodsInfo')
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except ValueError:
            raw = []
    if not isinstance(raw, list):
        raw = []
    bought, paid = [], {}
    for g in raw:
        if not isinstance(g, dict):
            continue
        key = _key_of(g.get('itemId') or g.get('id'))
        if key not in goods():
            return ctx.fail('商品不存在：%s' % _s(g.get('itemId')), '★ 黑市：id 不在 shoplist（她只认表键）')
        n = max(1, _int(g.get('number'), 1))
        unit = _s(g.get('priceUnit')) or YUANBAO
        price = _int(g.get('price'), 0) or price_of(key, 'black')
        total = price * n
        if not _spend_cur(ctx, unit, total):
            return ctx.fail('您的%s不足' % _cname(unit), '★ 黑市：%s 需要 %d 不够' % (unit, total))
        paid[unit] = paid.get(unit, 0) + total
        _grant(ctx, key, n)
        bought.append({'itemId': _info(key)['itemId'], 'number': n,
                       'price': price, 'priceUnit': unit,
                       'id': _int(key, 0), 'name': _info(key)['name']})
    if not bought:
        return ctx.fail('没有选任何商品', '★ 黑市：上行 goodsInfo 为空')
    return ctx.ok({'goodsList': bought}, '★ 黑市成交 %d 种（真扣货币 + 真发货）' % len(bought))


# ===========================================================================
# 冥币商人
# ===========================================================================
def _ep_get_mingbi_list(ctx, st):
    pool = _mingbi_pool()
    keys = _pick('mingbi-%s' % _uid(ctx), pool, 8)
    lst = [{'itemId': _info(k)['itemId'], 'id': _int(k, 0),
            'name': _info(k)['name'], 'price': price_of(k, 'black')} for k in keys]
    cnt = _cur(ctx, MINGBI)
    return ctx.ok({'status': 'OPEN', 'list': lst, 'count': cnt},
                  '★ 冥币商人 %d 件（shoplist 面具/挂饰/武学档）；冥币余额 %d' % (len(lst), cnt))


def _ep_buy_mingbi_goods(ctx, st):
    gid = ctx.param('id')
    key = _key_of(gid)
    if key not in goods():
        return ctx.fail('商品不存在', '★ 冥币购买：id 不在 shoplist')
    price = price_of(key, 'black')
    if not _spend_cur(ctx, MINGBI, price):
        return ctx.fail('冥币不足', '★ 冥币购买：需要 %d' % price)
    _grant(ctx, key, 1)
    return ctx.ok({'id': _int(key, 0), 'itemId': _info(key)['itemId'], 'price': price},
                  '★ 冥币购买 %s（-%d 冥币）' % (_info(key)['name'], price))


# ===========================================================================
# 功勋（功绩）商店 —— `get_sect_merit_store` 的货架落盘，`get_merit_goods` 领奖
# ===========================================================================
MERIT_ITEMS = 8
MERIT_BUY_LIMIT = 30
MERIT_REFRESH_COST = 100


def _merit_pool():
    # 功勋商店卖真道具/特殊道具（能进背包的）
    return _cat(T_ITEM, T_SPECIAL, T_SERVER_ITEM, need_price=False)


def _merit_rows(ctx, st):
    """功勋商店当前货架（按周刷新，与 `ReputationStore.lua:47` 的"每周一0点"一致）。"""
    m = st.setdefault('merit', {})
    now = int(time.time())
    week = now // WEEK
    if _int(m.get('week'), -1) != week or not isinstance(m.get('keys'), list) \
            or not m.get('keys'):
        m['week'] = week
        m['keys'] = _pick('merit-%d' % week, _merit_pool(), MERIT_ITEMS)
        m['stock'] = {}
        m['bought'] = 0
        _save(ctx, st)
    keys = [k for k in m.get('keys') or [] if k in goods()]
    rows = []
    for k in keys:
        info = _info(k)
        stock = _int((m.get('stock') or {}).get(k), 3)
        rows.append({
            'id': _int(k, 0),
            'goods': _reward_obj(k, 1),
            'state': 0 if stock > 0 else 2,
            'stock': stock,
            'price': price_of(k, 'merit'),
            'thresholdText': '需个人功绩 %d' % (_int(k, 0) % 500 + 100),
            'origPrice': price_of(k, 'merit') + 50,
            'icon': info['icon'],
            'name': info['name'],
        })
    return rows


def _reward_obj(gid, n=1):
    """`data.goods` 对象 —— `ReputationStore.lua:174-185` 读 `goods.type/id/number/name/icon`。

    `type`：1=物品（走 `addItemCount`）2=属性（走 `addAttr`）。按她表里的 `itype` 定：
    3（CLIENT_ATTR）才是属性，其余都是物品。
    """
    info = _info(gid)
    it = info['itype']
    if it == T_ATTR:
        return {'type': 2, 'id': _attr_key_of(gid), 'number': n,
                'name': info['name'], 'icon': info['icon']}
    return {'type': 1, 'id': info['itemId'], 'number': n,
            'name': info['name'], 'icon': info['icon']}


def _attr_key_of(gid):
    """商品表 `itype==3`（CLIENT_ATTR）的 `itemId` 就是她的属性名。"""
    return _info(gid)['itemId'] or ''


def _ep_get_sect_merit_store(ctx, st):
    rows = _merit_rows(ctx, st)
    m = st.setdefault('merit', {})
    bought = _int(m.get('bought'), 0)
    return ctx.ok({
        'buyTimes': bought,
        'buyLimit': MERIT_BUY_LIMIT,
        'refreshCost': MERIT_REFRESH_COST,
        'list': rows,
    }, '★ 功勋商店 %d 件（shoplist 真道具，按周刷新，限购 %d 次）' % (len(rows), MERIT_BUY_LIMIT))


def _find_merit_row(ctx, st, gid):
    """按商品表键找功勋货架行（她上行 `id` 可能是数也可能是串，两边都归一成串）。"""
    key = _key_of(gid)
    iid = _info(key)['itemId']
    for r in _merit_rows(ctx, st):
        if _s(r['id']) == key or _s(r['goods'].get('id')) == iid:
            return r
    return None


def _ep_buy_merit_goods(ctx, st):
    gid = ctx.param('id')
    if gid in (None, ''):
        return ctx.fail('参数错误', '★ 功勋购买：上行缺 id')
    key = _key_of(gid)
    if key not in goods():
        return ctx.fail('商品不存在', '★ 功勋购买：id 不在 shoplist')
    m = st.setdefault('merit', {})
    if _int(m.get('bought'), 0) >= MERIT_BUY_LIMIT:
        return ctx.fail('本周购买次数已达上限', '★ 功勋购买：已达 %d 次上限' % MERIT_BUY_LIMIT)
    price = price_of(key, 'merit')
    if not _spend_cur(ctx, REPUTATION, price):
        return ctx.fail('个人功绩不足', '★ 功勋购买：需要 %d 个人功绩' % price)
    stock = (m.setdefault('stock', {})).get(key, 3)
    if _int(stock, 3) <= 0:
        return ctx.fail('该商品已售罄', '★ 功勋购买：%s 库存 0' % key)
    m['stock'][key] = _int(stock, 3) - 1
    m['bought'] = _int(m.get('bought'), 0) + 1
    _save(ctx, st)
    _grant(ctx, key, 1)
    return ctx.ok({'reputation': _cur(ctx, REPUTATION), 'msg': '购买成功'},
                  '★ 功勋购买 %s（-%d 个人功绩，本周第 %d 次）'
                  % (_info(key)['name'], price, m['bought']))


def _ep_get_merit_goods(ctx, st):
    """功勋商店"领取"（她买了之后点领取/邮件发放）。

    `ReputationStore.lua:113-136`：读 `data.goods`（对象）+ `data.dataVer` + `data.msg`，
    然后本地 `addItemCount(goods.id, goods.number)`。
    """
    gid = ctx.param('id')
    key = _key_of(gid)
    if key not in goods():
        return ctx.fail('商品不存在', '★ 功勋领取：id 不在 shoplist')
    n = max(1, _int(ctx.param('num'), 1))
    goods_obj = _reward_obj(key, n)
    if goods_obj['type'] == 1:
        _grant(ctx, key, n)
    msg = ''
    return ctx.ok({
        'goods': goods_obj,
        'msg': msg,
        'currencyVersion': _int(ctx.param('currencyVersion'), 1),
    }, '★ 功勋领取 %s×%d（真发货）' % (_info(key)['name'], n))


# ===========================================================================
# 门派兑换商店（消耗佳绩 / 资历 / 昌盛度换门派奖励）
# ===========================================================================
SECT_ITEMS = 8
SECT_COST_KEYS = (DONATE, RENOWN, GBPOINT, SGBPOINT)


def _sect_seed(ctx):
    """门派的真实来源是她上行给的门派 id。"""
    return _s(ctx.param('familyId') or ctx.args[0] if ctx.args else ctx.param('familyId') or 'sect')


def _sect_pool():
    return _cat(T_ITEM, T_SPECIAL, T_SERVER_ITEM)


def _sect_currencies(ctx):
    """`FamilyExchangeStore.lua:105-115`：`currencies` 元素读 `v.id` / `v.count`，
    中文名她自己用 `getCHAttrName(v.id)` 补，所以只要 id 和数量。"""
    out = []
    for k in SECT_COST_KEYS:
        out.append({'id': k, 'count': _cur(ctx, k), 'name': _cname(k)})
    return out


def _ep_get_sect_exchangeStore(ctx, st):
    fam = _s(ctx.param('familyId')) or 'sect'
    s = st.setdefault('sect', {})
    now = int(time.time())
    week = now // WEEK
    node = s.get(fam)
    if not isinstance(node, dict) or _int(node.get('week'), -1) != week:
        node = {'week': week,
                'keys': _pick('sect-%s-%d' % (fam, week), _sect_pool(), SECT_ITEMS),
                'stock': {}}
        s[fam] = node
        _save(ctx, st)
    rows = []
    for k in [x for x in (node.get('keys') or []) if x in goods()]:
        info = _info(k)
        stock = _int((node.get('stock') or {}).get(k), 2)
        cost_key = SECT_COST_KEYS[_int(k, 0) % len(SECT_COST_KEYS)]
        rows.append({
            'id': _int(k, 0),
            'state': 0 if stock > 0 else 2,
            'stock': stock,
            'price': price_of(k, 'sect'),
            'goods': {'id': info['itemId'], 'number': 1, 'name': info['name'],
                      'icon': info['icon']},
            'cost': {'id': cost_key, 'number': price_of(k, 'sect')},
            'unlockConditionText': '需门派%s ≥ %d' % (_cname(cost_key), (_int(k, 0) % 5 + 1) * 100),
            'origPrice': price_of(k, 'sect') + 30,
        })
    return ctx.ok({'currencies': _sect_currencies(ctx), 'list': rows},
                  '★ 门派兑换商店 %d 件（门派 %s，按周刷新）' % (len(rows), fam))


def _ep_buy_sect_exchangeGoods(ctx, st):
    gid = ctx.param('id')
    key = _key_of(gid)
    if key not in goods():
        return ctx.fail('商品不存在', '★ 门派兑换：id 不在 shoplist')
    fam = _s(ctx.param('familyId')) or 'sect'
    node = (st.get('sect') or {}).get(fam) or {}
    # ★ 她上行 `id` 可能是数（`500063`）也可能是串（"500063"），货架键统一是串 —— 两边都归一
    shelf = [_s(x) for x in (node.get('keys') or [])]
    if key not in shelf:
        return ctx.fail('该商品本周不在售', '★ 门派兑换：%s 不在本周货架' % key)
    stock = _int((node.get('stock') or {}).get(key), 2)
    if stock <= 0:
        return ctx.fail('该商品已售罄', '★ 门派兑换：库存 0')
    cost_key = SECT_COST_KEYS[_int(key, 0) % len(SECT_COST_KEYS)]
    price = price_of(key, 'sect')
    if not _spend_cur(ctx, cost_key, price):
        return ctx.fail('%s不足' % _cname(cost_key), '★ 门派兑换：需要 %d %s' % (price, cost_key))
    node.setdefault('stock', {})[key] = stock - 1
    _save(ctx, st)
    _grant(ctx, key, 1)
    return ctx.ok({
        'goods': {'id': _info(key)['itemId'], 'number': 1, 'name': _info(key)['name']},
        cost_key: _cur(ctx, cost_key),
        'msg': '兑换成功',
    }, '★ 门派兑换 %s（-%d %s）' % (_info(key)['name'], price, _cname(cost_key)))


# ===========================================================================
# 游商 / 商人（`trader_store` / `buy_trader_goods` / `del_buy_npc_time`）
# ===========================================================================
TRADER_ITEMS = 10


def _trader_pool():
    """游商卖的东西：她 `storeItem`（商城物品）里有真价的那批，`Chapman.lua:116-127`
    会读 `is_buy_time` / `price2` / `priceUnit2` 做"买几次后涨价"。"""
    return _cat(T_ITEM, T_SPECIAL, T_ATTR, T_SERVER_ITEM, T_CURRENCY, need_price=True)


def _trader_rows(ctx, st, npc):
    t = st.setdefault('trader', {})
    now = int(time.time())
    day = now // DAY
    node = t.get(npc)
    if not isinstance(node, dict) or _int(node.get('day'), -1) != day:
        node = {'day': day,
                'keys': _pick('trader-%s-%d' % (npc, day), _trader_pool(), TRADER_ITEMS),
                'time': {}}
        t[npc] = node
        _save(ctx, st)
    rows = []
    for k in [x for x in (node.get('keys') or []) if x in goods()]:
        info = _info(k)
        base = price_of(k, 'trader')
        left = _int((node.get('time') or {}).get(k), 1)
        # `Chapman.lua:116-124`：is_buy_time<=0 时价格换成 price2/priceUnit2
        rows.append({
            'id': _int(k, 0),
            'itemId': info['itemId'],
            'count': 1,
            'name': info['name'],
            'price': base,
            'priceUnit': info['priceUnit'] if info['buyPrice'] > 0 else YUANBAO,
            'is_buy': 'Y' if _int(k, 0) % 4 == 0 else 'N',   # "Y" ⇒ 她设 count=999（无限买）
            'is_buy_time': max(0, left),
            'price2': base + max(1, base // 5),
            'priceUnit2': YUANBAO,
            'time': left,
        })
    return rows


def _ep_trader_store(ctx, st):
    npc = _s(ctx.args[0]) if ctx.args else _s(ctx.param('npcId') or ctx.param('npc_id'))
    if not npc:
        return ctx.fail('缺少商人 id', '★ 游商：URL 没给 npcId')
    rows = _trader_rows(ctx, st, npc)
    return ctx.ok({'list': rows, 'yuanbao': _cur(ctx, YUANBAO)},
                  '★ 游商 %s：%d 件（shoplist+storeItem 真价×2）' % (npc, len(rows)))


def _ep_buy_trader_goods(ctx, st):
    npc = _s(ctx.param('npc_id') or ctx.param('npcId'))
    gid = ctx.param('itemId')
    key = _key_of(gid)
    if key not in goods():
        return ctx.fail('商品不存在', '★ 游商购买：itemId 不在 shoplist')
    info = _info(key)
    unit = info['priceUnit'] if info['buyPrice'] > 0 else YUANBAO
    price = price_of(key, 'trader')
    if not _spend_cur(ctx, unit, price):
        return ctx.fail('您的%s不足' % _cname(unit), '★ 游商购买：需要 %d %s' % (price, unit))
    _grant(ctx, key, 1)
    node = (st.get('trader') or {}).get(npc) or {}
    if isinstance(node.get('time'), dict) and key in node['time']:
        node['time'][key] = max(0, _int(node['time'][key], 1) - 1)
    _save(ctx, st)
    return ctx.ok({'itemId': info['itemId'], 'price': price, 'priceUnit': unit,
                   'npc_id': npc}, '★ 游商购买 %s（-%d %s）' % (info['name'], price, _cname(unit)))


def _ep_del_buy_npc_time(ctx, st):
    """`del_buy_npc_time`：碎银购买后把 NPC 的购买次数 -1（`MapBagLayer.lua:1839-1900`）。

    她本地已经扣过碎银了；服务端这里按她上行的 `voucher_num` 记次数，不再重复扣钱。
    """
    npc = _s(ctx.param('npc_id') or ctx.param('npcId'))
    key = _key_of(ctx.param('itemId'))
    n = max(0, _int(ctx.param('voucher_num'), 0))
    node = (st.get('trader') or {}).get(npc)
    if isinstance(node, dict) and isinstance(node.get('time'), dict) and key in node['time']:
        node['time'][key] = max(0, _int(node['time'][key], 1) - max(1, n))
    _save(ctx, st)
    return ctx.ok({'npc_id': npc, 'itemId': _info(key)['itemId'], 'count': n},
                  '★ 游商购买次数 -%d（%s / %s）' % (max(1, n), npc, key))


# ===========================================================================
# 续卷商店（`matters_shop_info` / `buy_matters`）
# ===========================================================================
MATTERS_ITEMS = 6


def _matters_pool():
    """续卷（技能突破道具）：`skill/breakThroughItems.lua` 只有 id/name/dsc；
    真正的商品键按 `itemId` 反查 shoplist。"""
    out = []
    for k in _cat(T_ITEM, T_SPECIAL):
        if _s(_info(k)['itemId']).startswith(('skillUpItem', 'skillpage', 'glcz')):
            out.append(k)
    return out or _cat(T_ITEM, T_SPECIAL)


def _ep_matters_shop_info(ctx, st):
    typ = _int(ctx.param('type'), 1)
    m = st.setdefault('matters', {})
    now = int(time.time())
    day = now // DAY
    if _int(m.get('day'), -1) != day or not m.get('keys'):
        m['day'] = day
        m['keys'] = _pick('matters-%d' % day, _matters_pool(), MATTERS_ITEMS)
        _save(ctx, st)
    goods_list = []
    for k in [x for x in (m.get('keys') or []) if x in goods()]:
        info = _info(k)
        goods_list.append({
            'key': k,
            'num': 1,
            'price': price_of(k, 'matters'),
            'id': info['itemId'],
            'name': info['name'],
        })
    # `XuJuanStore.lua:115-121`：matters_list 元素读 `id` 与 `num`（`getBreakThroughItem(id)`）
    matters_list = [{'id': g['id'], 'num': 1} for g in goods_list]
    return ctx.ok({
        'yuanbao_num': _cur(ctx, YUANBAO),
        'currency_number': _cur(ctx, GONGXIANDIAN),
        'currency_name': _cname(GONGXIANDIAN),
        'isRefreshLimit': typ != 2,
        'matters_list': matters_list,
        'goods_list': goods_list,
        'currencyVersion': _int(ctx.param('currencyVersion'), 1),
    }, '★ 续卷商店 type=%d：%d 件（shoplist 真道具）' % (typ, len(goods_list)))


def _ep_buy_matters(ctx, st):
    gid = ctx.param('goodsKey') or ctx.param('id')
    key = _key_of(gid)
    if key not in goods():
        return ctx.fail('商品不存在', '★ 续卷购买：goodsKey 不在 shoplist')
    info = _info(key)
    price = price_of(key, 'matters')
    unit = GONGXIANDIAN
    if not _spend_cur(ctx, unit, price):
        return ctx.fail('%s不足' % _cname(unit),
                        '★ 续卷购买：需要 %d %s' % (price, _cname(unit)))
    _grant(ctx, key, 1)
    return ctx.ok({
        'reward': {'id': info['itemId'], 'num': 1, 'name': info['name']},
        'currencyVersion': _int(ctx.param('currencyVersion'), 1),
        'msg': '',
    }, '★ 续卷购买 %s（-%d %s）' % (info['name'], price, _cname(unit)))


# ===========================================================================
# 声望商店（师门声望商人，货币 = 师门贡献点 / 江湖美誉）
# ===========================================================================
PRESTIGE_ITEMS = 8
PRESTIGE_REFRESH_COST = 50


def _prestige_pool():
    return _cat(T_ITEM, T_SPECIAL, T_SERVER_ITEM)


def _ep_get_prestige_goods(ctx, st):
    npc = _s(ctx.param('npc_id') or ctx.param('npcId')) or 'shengwang01'
    is_refresh = _s(ctx.param('is_refresh'))
    p = st.setdefault('prestige', {})
    now = int(time.time())
    day = now // DAY
    rotate = 1 if is_refresh in ('Y', 'y', '1', 'true') else 0
    node = p.get(npc)
    refreshed_cost = 0
    if rotate or not isinstance(node, dict) or _int(node.get('day'), -1) != day \
            or not node.get('keys'):
        if rotate:
            # 真刷新：扣元宝（她 `MapBagLayer.lua:1540-1544` 读 `data.remove` 弹"消耗 X 元宝"）
            cost = PRESTIGE_REFRESH_COST
            if not _spend_cur(ctx, YUANBAO, cost):
                return ctx.fail('元宝不足', '★ 声望商人刷新：需要 %d 元宝' % cost)
            refreshed_cost = cost
        node = {'day': day,
                'keys': _pick('prestige-%s-%d' % (npc, day), _prestige_pool(),
                              PRESTIGE_ITEMS, rotate=rotate)}
        p[npc] = node
        _save(ctx, st)
    rows = []
    for k in [x for x in (node.get('keys') or []) if x in goods()]:
        info = _info(k)
        rows.append({
            'itemId': info['itemId'],
            'id': _int(k, 0),
            'name': info['name'],
            'price': price_of(k, 'prestige'),
            'unit': GONGXIANDIAN,
            # `Chapman.lua:490` 读 `v.needSw`，`MapBagLayer.lua:2143` 拿它跟当前声望比
            'needSw': (_int(k, 0) % 4) * 200,
        })
    return ctx.ok({
        'list': rows,
        'point': _cur(ctx, GONGXIANDIAN),
        'unit': GONGXIANDIAN,
        'shengwang': _cur(ctx, REPUTATION),
        'title': 0,
        'next_yuanbao': PRESTIGE_REFRESH_COST,
        'remove': refreshed_cost,
    }, '★ 声望商店 %s：%d 件（needSw 为需求声望，货币=师门贡献点）%s'
       % (npc, len(rows), '（本次为刷新，-%d 元宝）' % refreshed_cost if refreshed_cost else ''))


def _ep_buy_prestige_goods(ctx, st):
    gid = ctx.param('itemId')
    key = _key_of(gid)
    if key not in goods():
        return ctx.fail('商品不存在', '★ 声望购买：itemId 不在 shoplist')
    info = _info(key)
    # 她 `MapBagLayer.lua:2118-2164` 里货币是 gongxiandian，有唯一头衔打 7.5 折
    price = price_of(key, 'prestige')
    if not _spend_cur(ctx, GONGXIANDIAN, price):
        return ctx.fail('师门贡献点不足', '★ 声望购买：需要 %d' % price)
    _grant(ctx, key, 1)
    return ctx.ok({'itemId': info['itemId'], 'price': price, 'unit': GONGXIANDIAN},
                  '★ 声望购买 %s（-%d 师门贡献点）' % (info['name'], price))


# ===========================================================================
# NPC 买卖（`buy_npc_goods` = 多币种 NPC 商人购买）
# ===========================================================================
def _ep_buy_npc_goods(ctx, st):
    """多币种 NPC 商人购买（`HttpManager.lua:2274`）。

    她客户端 = `NpcMapBagLayer`，买完本地加物品、本地扣货币；服务端要真扣真发。
    上行 `{client_trans_id,itemId,npc_id,couponsId}`。
    """
    key = _key_of(ctx.param('itemId'))
    if key not in goods():
        return ctx.fail('商品不存在', '★ NPC 购买：itemId 不在 shoplist')
    info = _info(key)
    npc = _s(ctx.param('npc_id') or ctx.param('npcId'))
    unit = info['priceUnit'] if info['buyPrice'] > 0 else YUANBAO
    price = price_of(key, 'trader')
    if not _spend_cur(ctx, unit, price):
        return ctx.fail('您的%s不足' % _cname(unit), '★ NPC 购买：需要 %d %s' % (price, unit))
    _grant(ctx, key, 1)
    return ctx.ok({'itemId': info['itemId'], 'price': price, 'priceUnit': unit,
                   'npc_id': npc},
                  '★ NPC 商人购买 %s（-%d %s）' % (info['name'], price, _cname(unit)))


# ===========================================================================
# 储物箱（藏物箱商人）
# ===========================================================================
def _boxes():
    """`familylist["储物箱"]` 的 13 个箱子，按 `addCapacity` 升序。"""
    b = storage_boxes()
    rows = [v for v in b.values() if isinstance(v, dict)]
    rows.sort(key=lambda v: _int(v.get('addCapacity'), 0))
    return rows


def _box_price(box):
    """箱子价：她表里**没有**价（只有 addCapacity/grade）。
    按容量线性推：40 × addCapacity × (1 + grade)，钱单位=银票（`CkChapman.lua:8-11`
    的 `PRICE_UINIT_NAME` 只有 money/yinpiao，且 `setSellerUnit` 默认 "yinpiao"）。"""
    return max(1, 40 * _int(box.get('addCapacity'), 1) * (1 + _int(box.get('grade'), 0)))


def _ep_get_storage_box(ctx, st):
    base = _s(ctx.args[0]) if ctx.args else _s(ctx.param('baseId'))
    rows = []
    for b in _boxes():
        rows.append({
            'itemId': _s(b.get('id')),
            'unit': 'yinpiao',
            'price': _box_price(b),
            'countNum': 1,
            'name': _s(b.get('name')),
            'dsc': _s(b.get('dsc')),
            'addCapacity': _int(b.get('addCapacity'), 0),
        })
    # `CkChapman.lua:25-44`：现有箱子读 `box.id` 与 `box.extra.itemId`
    owned = []
    for i, b in enumerate(_boxes()[:HAS_MAX_STORAGE_BOX]):
        owned.append({'id': i + 1, 'extra': {'itemId': _s(b.get('id'))},
                      'update_time': int(time.time())})
    return ctx.ok({
        'storage': owned,
        'point': _cur(ctx, 'yinpiao'),
        'list': rows,
        'unit': 'yinpiao',
    }, '★ 储物箱：在售 %d 个（familylist["储物箱"]），持有 %d 个'
       % (len(rows), len(owned)))


def _ep_buy_storage_box(ctx, st):
    iid = _s(ctx.param('itemId'))
    box = storage_boxes().get(iid)
    if not isinstance(box, dict):
        return ctx.fail('没有这个储物箱', '★ 买储物箱：itemId 不在 familylist["储物箱"]')
    fid = ctx.param('fid')
    unit = 'yinpiao'
    price = _box_price(box)
    if not _spend_cur(ctx, unit, price):
        return ctx.fail('%s不足' % _cname(unit), '★ 买储物箱：需要 %d %s' % (price, _cname(unit)))
    new_id = _int(fid, 0) or (HAS_MAX_STORAGE_BOX + 1)
    return ctx.ok({
        'remove_point': price,
        'total_point': _cur(ctx, unit),
        'storage_box': {'id': new_id, 'extra': {'itemId': iid},
                        'update_time': int(time.time())},
    }, '★ 买储物箱 %s（-%d %s，容量 +%d）'
       % (_s(box.get('name')), price, _cname(unit), _int(box.get('addCapacity'), 0)))


# ===========================================================================
# 面具材料（制作组商人买材料，`buy_mask_piece_2`）
# ===========================================================================
def _ep_buy_mask_piece_2(ctx, st):
    gid = _s(ctx.param('id') or ctx.param('itemId'))
    if gid not in CAILIAO:
        return ctx.fail('商品不存在', '★ 买面具材料：id 不在 ZhiZuoZu 的 cailiao200_01..28')
    price = price_of(_key_of(gid), 'trader')
    if not _spend_cur(ctx, MEIYU, price):
        return ctx.fail('江湖美誉不足', '★ 买面具材料：需要 %d 江湖美誉' % price)
    _grant(ctx, _key_of(gid), 1)
    return ctx.ok({'itemId': gid, 'id': _int(ctx.param('order_id'), 0)},
                  '★ 买面具材料 %s（-%d 江湖美誉）' % (gid, price))


# ===========================================================================
# 藏衣阁 / 悬兵洞（`get_ckitems_list`）
# ===========================================================================
def _ep_get_ckitems_list(ctx, st):
    """`{ckname,ver}` → `{ver, list:[{itemId,total,update_time}]}`。

    `CangYiGeModel.lua:45` 读 `data.ver`，`:80-97` 读 `item_data.itemId/total/update_time`。
    仓库明细的真身在 `items_currency` 的 `items_state.json["ck"][ckname]`
    （`beput_ckitems` / `outgoing_ckitems` 写的），这里**不另存一份**，只做
    商品表键 → `itemId` 的转换。
    """
    ckname = _s(ctx.param('ckname') or ctx.param('ckName')) or 'shenbing'
    box = {}
    try:
        import fz_api.items_currency as ic
        box = (ic._load(ctx).get('ck') or {}).get(ckname) or {}
    except Exception:                           # noqa: BLE001
        box = {}
    items = box.get('items') if isinstance(box.get('items'), dict) else {}
    rows = []
    for k, n in items.items():
        info = _info(k)
        rows.append({'itemId': info['itemId'], 'total': _int(n, 1),
                     'update_time': _int(box.get('update_time'), int(time.time()))})
    # `BlackStore.lua:526-529` 只读 `v.itemId`；`CangYiGeModel.lua:88` 还会比 `total`
    return ctx.ok({'ver': _int(box.get('ver'), 1), 'list': rows},
                  '★ %s 仓库（items_state.json["ck"]）：%d 件' % (ckname, len(rows)))


# ===========================================================================
# 订单 / 支付
# ===========================================================================
def _ep_get_buy_order_id(ctx, st):
    """`TransCheck:getTransIdFromWeb`（`:27-33`）拿通用订单号，读 `data.order_id`。"""
    oid = _new_order(ctx, st, 'buy')
    return ctx.ok({'order_id': oid}, '★ 通用订单号 %s' % oid)


def _ep_get_order_id(ctx, st):
    """`get_order_id/<orderType>` —— `Order.lua:16-31` 读 `data.order_id`。

    orderType：1=首充（上行 `{key=1}`）2=累计充值（上行 `{key=金额}`）。
    """
    typ = _s(ctx.args[0]) if ctx.args else _s(ctx.param('orderType')) or '1'
    oid = _new_order(ctx, st, 'ord%s' % typ)
    rec = st['orders'].get(oid) or {}
    rec['type'] = typ
    rec['info'] = {k: v for k, v in (ctx.body_obj or {}).items()
                   if isinstance(v, (str, int, float, bool))}
    st['orders'][oid] = rec
    _save(ctx, st)
    return ctx.ok({'order_id': oid}, '★ 订单号 %s（orderType=%s）' % (oid, typ))


def _ep_rollback_order_status(ctx, st):
    """`rollback_order_status/<orderType>` —— `Order.lua:142-172` 只看 errcode。"""
    typ = _s(ctx.args[0]) if ctx.args else '1'
    oid = _s(ctx.param('order_id')) or _s(ctx.param('orderid'))
    st['orders'].pop(oid, None)
    _save(ctx, st)
    return ctx.ok({'order_id': oid, 'orderType': typ},
                  '★ 回滚订单 %s（orderType=%s）' % (oid or '-', typ))


def _ep_get_reward_2(ctx, st):
    """`get_reward_2/<rType>` —— `TransCheck.lua:213-225` 只读 errcode：
    0 或 7 都算成功（7="元宝已领，补发道具"），其余失败。"""
    oid = _s(ctx.param('trans_id') or ctx.param('order_id'))
    if oid and oid in st.get('orders', {}):
        st['orders'].pop(oid, None)
        _save(ctx, st)
        return ctx.ok({'trans_id': oid}, '★ 补发奖励（订单 %s 已核销）' % oid)
    # 没有对应订单 ⇒ 用她客户端同样的语义回 7（元宝已领，只补道具），别让她反复重试
    return ctx.ok({'trans_id': oid, 'state': 7},
                  '★ 补发奖励：服务端没有订单 %s 的记录（按她 errcode=7 语义回 0）' % (oid or '-'))


def _ep_applestore_list(ctx, st):
    """充值商店列表。

    ★ 诚实说明：充值商品表（`product.key` / `real_price`）**不在她客户端里**，
      由原官方服务端 + 应用商店 SDK 下发；全量搜过 `ink_dec`，`real_price` 只在
      `views/layer/StoreLayer/PayLayer.lua:213` 被读，没有任何配置表。
      所以这里**不编造假商品**，按"充值商店已关闭"回（`PayLayer.lua:64-69` 本来就有这个分支）。
    """
    d = {
        'store_status': 'CLOSED',
        'list': [],
        'discount': {'1': 1, '2': 1, '3': 1, '4': 1},
        'title': '元宝充值',
        'time': '',
        'errmsg': '充值商店已关闭',
    }
    return ctx.ok(d, '充值商店：本私服没有应用商店商品表，按"已关闭"回（不编造商品）')


def _ep_check_pay_sign(ctx, st):
    """`check_pay_sign` —— `PayLayer.lua:142-254` 只看 errcode。

    原版语义：服务端拿应用商店的订单签名核验后才允许下单。本私服没有 SDK 订单来源，
    **不伪造已支付**：`key` 为空按参数错误回 errcode=1，结构合法则放行到 SDK 流程。
    """
    key = _s(ctx.param('key'))
    if not key:
        return ctx.fail('参数错误', '★ 支付校验：上行缺 key（不伪造已支付）', errcode=1)
    return ctx.ok({'key': key, 'activity_id': _s(ctx.param('activity_id'))},
                  '支付校验通过（key=%s；本私服没有应用商店签名订单，不做真实核验）' % key[:24])


def _goods_payload(ctx, gid):
    """`get_goods` / `get_goods_2` 的应答体。

    `YuanBaoPayLayer.lua:90-100` 逐字段读：`name`（`..` 拼串）/`price`（`*number`）/
    `dsc1`/`dsc2`（`.."\n"..`）/`icon`/`itemId`/`share`/`discount`。
    `discount` 走 `switch(tostring(flag), {["0.9"]=..})`，给 1 = 无折扣图。
    """
    info = _info(gid)
    # 价：优先她表的 buyPrice，其次黑市价
    price = info['buyPrice'] or price_of(gid, 'trader')
    dsc = info['dsc'] or ''
    return {
        'id': _int(info['key'], 0),
        'itemId': info['itemId'],
        'name': info['name'],
        'price': price,
        'dsc1': dsc,
        'dsc2': '',
        'icon': info['icon'],
        'share': '',
        'discount': 1,
        'number': 1,
        'itype': info['itype'],
        'type': info['viewtype'],
        'unit': info['unit'],
    }


# ===========================================================================
# ★ 「关卡」页签卖的是**卷**（`volume_N`），不是 `shoplist` 里的商品。
#   权威表：`res/script/newmap/map/world.lua` —— `{id=volume_N, name=卷名, includeMap="fbA;fbB;…"}`。
#   客户端资源里**没有卷的价**（原版在服务端），下面这 6 个价取自**老板给的原版截图**
#   （声震武林卷100 / 柳玄风卷上200 / 柳玄风卷下150 / 章作之卷150 / 折掌镇海卷100 / 藏锋破阵卷100），
#   是真数据不是编的。其余卷（鹊起无名卷/八方风雨卷/门派卷/家园卷/活动卷）不上架。
#   买下 = 真扣元宝 + 记进 `st['volumes']`（解锁记录），副本能不能进由那份记录说了算。
VOLUME_PRICE = {
    'volume_2': ('声震武林卷', 100, 'fb11;fb12;fb13;fb14;fb15;fb16;fb17;fb18;fb19;fb20'),
    'volume_3': ('柳玄风卷上', 200, 'fb21;fb22;fb23;fb24;fb25;fb26;fb27;fb28;fb29;fb30'),
    'volume_4': ('柳玄风卷下', 150, 'fb31;fb32;fb33;fb34;fb35'),
    'volume_5': ('章作之卷', 150, 'fb36;fb37;fb38;fb39;fb40'),
    'volume_6': ('折掌镇海卷', 100, 'fb41;fb42;fb43;fb44;fb45'),
    'volume_7': ('藏锋破阵卷', 100, 'fb46;fb47;fb48;fb49;fb50'),
}
VOLUME_ICON = 'Image/UI/StoreUI/shujuan1.png'     # 卷没有自己的图，借书卷类的卷轴图

# ---------------------------------------------------------------------------
# ★★ 特权商品（2026-10-03 客户要求：商场里加「江湖名士 / 江湖雅士」的特权兑换）。
#   名士/雅士本质都是**服务端下发的一个到期时间戳**：
#     · 名士 ← `get_store_list_4` 的 `yueka_expired_time`（`StoreLayer:setPanelMingShi`）
#     · 雅士 ← 同应答的 `yashi_expired_time`（`StoreLayer:setButtonYaShi`，藏经阁残页九折）
#   客户端把 `<=0` 当"现在" ⇒ 显示「未获得该身份」；未来时间 = 已拥有（剩余天数）。
#   这是**虚拟商品**（itype=13：客户端只弹"购买成功"，不进背包），
#   买完服务端把到期时间 +30 天，重开商城面板即可看到身份天数变化。
#   · 雅士默认已拥有（L3d 决策：不给老板已有权益做减法），购买 = 续期 30 天；
#   · 名士默认未拥有，购买 = 获得 30 天。
PRIVILEGE_GOODS = {
    'tequan_mingshi': {'name': '江湖名士特权（30天）', 'price': 10,
                       'state_key': 'yueka',
                       'icon': 'Image/UI/StoreUI/yuanbao-7.png',
                       'dsc': '购买后立即获得 30 天「江湖名士」身份（重复购买自动顺延 30 天）。',
                       'dsc2': '购买后回主界面重新打开商城即可看到身份剩余天数。'},
    'tequan_yashi': {'name': '江湖雅士特权（30天）', 'price': 10,
                     'state_key': 'yashi',
                     'icon': 'Image/UI/StoreUI/yuanbao-7.png',
                     'dsc': '购买后立即获得/延长 30 天「江湖雅士」身份（藏经阁残页享九折等专属福利）。',
                     'dsc2': '购买后回主界面重新打开商城即可看到身份剩余天数。'},
}
PRIVILEGE_DAYS = 30

# ★ 「限时」页签的礼包 —— 定义见下方 `_LIMIT_PACKS_OFF`（**已下架**，
#   原因与恢复条件写在那里，只有一份数据，别在这里再抄一份）。
PACK_ICON = 'Image/UI/StoreUI/juanzhou1.png'      # 客户端没有礼包图，借卷轴图

# ===========================================================================
# ★★「测试礼包」（老板 2026-09-29 定的 4 个）—— 单价 **1 银两**、不限购
# ---------------------------------------------------------------------------
# 物品本体在**客户端表**里：`Items.lua` 的 `testpack_*`（type=宝箱）
#   + `Rewards.lua` 新增的一批 rid（由 `work/fz_make_test_packs.py` 生成并部署）。
# 这里只负责：上架（`test_pack_shelf_rows`）、报价/详情（`_extra_goods`/`_extra_payload`）、
#   购买结算（`_extra_buy` 里那条按**银两**扣钱的分支）。
# 价格单位故意用 `money`（碎银）而不是元宝 —— 老板要求 1 银两。
# ⚠️ 若客户端商城弹窗把单位写死成"元宝"，改动只有一个常量（下面 TEST_PACK_UNIT）。
TEST_PACK_UNIT = 'money'
TEST_PACKS = {
    'testpack_exp':       ('【测试】经验潜能包', 1),
    'testpack_currency':  ('【测试】货币礼包', 1),
    'testpack_baseskill': ('【测试】基础武学包', 1),
    'testpack_pages':     ('【测试】书页残页包', 1),
    'testpack_mask':      ('【测试】面具礼包', 1),
    'testpack_pill':      ('【测试】先天丹礼包', 1),
    'testpack_maxskill':  ('【测试】武学与主动技能满级包', 1),
}
TEST_PACK_DSC = {
    'testpack_exp': '测试专用：打开可获得 100 万经验、100 万潜能，'
                    '以及内力/气血/精力/真气/经脉经验/左右互搏等各类成长属性。',
    'testpack_currency': '测试专用：打开可获得各类货币各 10 万'
                         '（碎银/黄金/元宝/银票/武学四币/醉仙武意/师门贡献/梦境币/积分/宝玉/江湖令/战绩积分/师门声望）。',
    'testpack_baseskill': '测试专用：打开后 12 门基础武学'
                          '（拳脚/剑法/刀法/内功/轻功/招架/暗器/鞭法/棍法/毒技/乐器/双持）直接到 500 级。',
    'testpack_pages': '测试专用：打开**随机获得 10 种**武学书页/主动技能残页'
                      '（奖池 = 全部 804 种书页 + 657 种残页；书页进书箱、残页进招式书箱，'
                      '都不占背包格；可重复购买慢慢集齐）。',
    'testpack_mask': '测试专用：打开**随机获得 3 张面具**（奖池 = 全部 274 张面具，'
                     '尽量不重复），可重复购买。',
    'testpack_pill': '测试专用：打开获得 **5 颗先天属性丹 + 5 颗福源丹**。'
                     '先天属性丹每颗随机给一项先天属性 +10（臂力/悟性/根骨/身法），'
                     '福源丹每颗 +10 福缘；可重复购买。',
    'testpack_maxskill': '测试专用：打开后**已学会的所有武学**到高等级（600 级，受各自上限限制），'
                         '**所有主动技能**经验拉满。',
}
TEST_PACK_ITEMS = sorted(TEST_PACKS)

# ★ 2026-10-01：礼包表改成**单一来源** —— 生成器 `work/fz_make_test_packs.py` 写完
#   `test_packs.json`（每包 key/name/dsc/price），这里启动时并进来。
#   好处：礼包从 9 个涨到 180+ 个（一门武学一个书页包）也不用再手工维护两份表。
#   文件放在包根（work/ 或离线包根），离线包里由 `fz_make_offline_bundle.py` 一起带上。
_PACK_JSON = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                          'test_packs.json')
TEST_PACK_GROUP = {}
try:
    if os.path.isfile(_PACK_JSON):
        _rows = None
        with open(_PACK_JSON, encoding='utf-8') as _f:
            _rows = json.load(_f)
        if _rows:
            # ★ JSON 是唯一真源：**整表替换**（否则删掉的礼包会从下面的内置表"复活"，
            #   2026-10-01 就踩过：书页残页包在 JSON 里删了、货架上却还在）。
            TEST_PACKS.clear()
            TEST_PACK_DSC.clear()
            for _row in _rows:
                _k = _row.get('key')
                if not _k:
                    continue
                TEST_PACKS[_k] = (_row.get('name') or _k, int(_row.get('price') or 1))
                TEST_PACK_DSC[_k] = _row.get('dsc') or ''
                TEST_PACK_GROUP[_k] = _row.get('group') or 'general'
            TEST_PACK_ITEMS = sorted(TEST_PACKS)
except Exception:                                                      # noqa: BLE001
    pass


def test_pack_shelf_rows(groups=None):
    """测试礼包货架行（价 1 银两）。

    `groups` 用来把礼包分栏（老板 2026-10-01：礼包太多不好找）：
      general  = 通用（经验潜能/货币/基础武学/面具/先天丹/满级/随机书页残页）→「限时」栏
      books    = 一门武学一个书页包                                      →「神功」栏
      resource = 武器/经脉/神兵/家园建材/图谱/炼制材料/沧浪帖             →「商城」栏

    ★★ `itype` 必须是 10，**不能是 1**：
      客户端 `StoreLayer:aftreBuyGoodsSuccess` 里
          itype == 1  -> 只 `addAttr("guanqiaLimit", number)`（当成"关卡次数"），**不给物品**
          itype == 12 -> 神功虚拟物品，也不给物品
          其它（含 10）-> `role:addItemCount(itemId, ...)` **真进背包**
      老板实测"买了背包里没有"就是踩了这个。
    """
    rows = []
    for iid in TEST_PACK_ITEMS:
        if groups and TEST_PACK_GROUP.get(iid, 'general') not in groups:
            continue
        nm, price = TEST_PACKS[iid]
        rows.append({
            'id': iid, 'itemId': iid, 'name': nm,
            'dsc': TEST_PACK_DSC.get(iid, ''),
            'icon': PACK_ICON,
            'price': _disp_price(price), 'priceUnit': TEST_PACK_UNIT,   # ★ v37b 我方礼包零花费
            'number': 1, 'itype': 10,
        })
    return rows

# ===========================================================================
# ★ 「商城」页签 —— 老板 2026-09-28 给的原版截图，**11 件**（不是按表自动筛）。
#
# 为什么不能"自动筛"：我们原来拿 `storeItem.shangchengwupin` 里所有有买价的
# 往这一栏塞，出来 9 件，和原版对不上（多 无尘果/菩提子/三才丹 之类，
# 少 官府公文/包月分身符/掌门令…）。原版这一栏是**服务端钦定的一张清单**。
#
# 价格全部由老板确认（"那两个物品的定价是对的"）。
#
# 每件分两类，处置方式完全不同：
#   · 客户端**能解析**的实体物品（`Item.lua:304-374` 会依次查
#     `storeItem.shangchengwupin` + `mapItemAttr` 的 10 张表）⇒ `itype=1`，
#     买完走 `role:addItemCount` 真进背包。
#   · 客户端**解析不到**的虚拟商品 ⇒ `itype=13`
#     （`StoreLayer.lua:6` `Net_NotBatchBuy_Goods`）。
#     `StoreLayer.lua:408/641` 的注释点名了它们：**「特殊物品 包月分身符 掌门令
#     御汇令」**「expired_time 包月分身符、掌门令、御汇令特有」。
#     ★★ 决定性证据：`Item.lua:309-311` 对 `byfenshenfu` **直接 return**
#        （写死不给物品对象）⇒ 它永远不可能是普通背包物品。
MALL_GOODS = [
    # (itemId, 名称, 价, itype, 单位, dsc1, dsc2, 图标名)
    # 图标取自 `assets/fjh/ui/UI/StoreUI/` 里**真实存在**的 135 个文件。
    # dsc1/dsc2 取自她自己的表（`storeItem.shangchengwupin.dsc` + `.itemDesc`，
    #   `Items.lua` 的 drxiang02/jingmai105 取 `.dsc`）—— 对应老板正版截图 3 里
    #   弹窗上方那两行文字，也对应 `YuanBaoPayUI.lua:98` 的默认值「没有描述」。
    #
    # ★★ itype=10 不是随便选的：老板正版截图 2 显示点「遁地符」会**先弹数量框**
    #    （1个/10个/99个）。而客户端只有 `itype == 10 or itype == 12` 才会走
    #    `StoreLayer.lua:850 showItemBuyNumberPanel`（:526 判断）。
    #    我第一版给了 itype=1 ⇒ 走 :530 的 `checkCanBuyGoods` 分支 ⇒ **点了没反应**
    #    （老板截图 1 就是这个）。:871-879 三个按钮分别买 1/10/99 个。
    ('xiyanshui',     '洗颜水',    50,   10, '瓶',
     '一瓶金灿灿的泥水，散发着难闻的味道，据说可以养血美颜。', '使用后颜值+1', 'xiyanshui'),
    ('dundifu',       '遁地符',    10,   10, '张',
     '一张画满咒文的纸符，可以用来施展奇门遁甲术，使用后会偶然出现意想不到的结果，请谨慎使用。',
     '使用后可以快速回家或者到达任务地点。', 'dundifu'),
    ('fenshenfu',     '分身符',    10,   10, '张',
     '一张画满咒文的纸符 ，可以用来创造一个分身。',
     '使用后可以同时打工，练功或者打坐。', 'fenshenfu'),
    ('guanfugongwen', '官府公文',  300,  10, '张',
     '拥有此公文者可交于扬州城衙门处吊销户籍。',
     '购买者可持此公文按照提示改名。', 'guanfugongwen'),
    # ↓ 三件虚拟商品：客户端任何表都解析不到 ⇒ 必须 itype=13
    ('byfenshenfu',   '包月分身符', 1800, 13, '张',
     '包月分身，传承时保留。', '购买后直接生效，不占背包。', 'byfenshenfu'),
    ('jingxinwan',    '静心丸',    50,   10, '颗',
     '一颗散发着淡淡香气的药丸，具有凝神静心的功效，可以提升闭关修炼成功率，并且不会走火入魔。',
     '使用后可以提升闭关修炼成功率，并且不会走火入魔。', 'jingxinwan'),
    ('jingmai105',    '渡元丹',    100,  10, '颗',
     '一种橙黄色的药丸，据说由名家所配制，服用后可以增加冲穴的成功率。',
     '随着渡元丹入腹，你感到灵台一阵清明，似乎对经脉冲穴的把握更大了些。',
     'xuanhuangziqingdan'),
    ('shimenbuff1',   '掌门令',    1200, 13, '枚',
     '师门声望加成。', '购买后直接生效，不占背包。', 'lingpai1'),
    ('bafangyouxia',  '八方游侠',  1800, 13, '个',
     '江湖名士身份。', '购买后直接生效，不占背包。', 'mingshi'),
    ('drxiang02',     '艾香',      10,   10, '支',
     '以艾草粉为基压制成的香线。入梦概率：50%。可用于暮铁炉、紫铜炉、银月炉、金炽炉。',
     '点燃后休息，似会有意想不到的效果。', 'xiang'),
    # ★ 2026-10-01 老板报「大量勤建之志」点了"无法找到该资源" —— 客户端物品表里没有 `diligent`，
    #   所以我们**自己造了一个同 id 的真物品**（生成器里那条：宝箱类，用掉发 师门名绩+500、
    #   师门贡献+500），这里重新上架。它不占限时/神功栏，只在这一栏。
    ('diligent',      '大量勤建之志', 250, 10, '个',
     '勤谨鼓劲，做师门的日常任务时可以一气呵成。',
     '使用后获得师门名绩 +500、师门贡献 +500。', 'qinjianzhizhi'),
]
MALL_PRICE = {g[0]: g[2] for g in MALL_GOODS}
MALL_ICON = 'Image/UI/StoreUI/miji.png'           # 兜底图（万一没配）


def _mall_icon(icon_name):
    return 'Image/UI/StoreUI/%s.png' % icon_name


def mall_goods_info(iid):
    """按 itemId 取 (名称, 价, itype, dsc1, dsc2, 图标全路径)。"""
    for g in MALL_GOODS:
        if g[0] == iid:
            return (g[1], g[2], g[3], g[5], g[6], _mall_icon(g[7]))
    return None

# 客户端 `Item:getOneItemByKey` **解析不到**的（必须走 itype=13 虚拟通道）。
# 判据来源：`Item.lua:304-374` 的表清单逐个查过（`work/tmp_mall11_check.py`）。
# ★ 另据 `StoreLayer.lua:409-413` 的 `specialItem` 表，这三件的**真 id** 是
#   `byfenshenfu` / `shimenbuff1`（掌门令）/ `yuhuiling`（御汇令）——
#   我一开始猜的 `zhangmenling` 在整张客户端里根本不存在。
#   且 `specialItem` 命中的件会走 `expired_time` 分支（:465-477）显示剩余天数，
#   所以**必须一并下发 `expired_time`**，否则 `day/hour` 计算落空。
MALL_VIRTUAL = {'byfenshenfu', 'shimenbuff1', 'bafangyouxia'}
# 有"剩余天数"概念的那几件（`specialItem` 里除 八方游侠 外）
MALL_EXPIRING = {'byfenshenfu', 'shimenbuff1'}

# ===========================================================================
# 「限时」页签的礼包 —— ★ 已下架（老板 2026-09-28 方案 A）
#
# 这 16 件的**名字和价是真的**（老板截图 3+4 逐项对到 `Items.lua` 的 `libao*`，
# 16/16 全中）。下架的唯一原因是**内容物在客户端不存在**：
#   · `Items.lua` 里它们只有 `id`+`name`，**没有 `type`/`dsc`/`rwId`**
#   · `Rewards.lua`（5399 条奖励方案）里查不到它们
#   · 全表只有 15 条 `rwName` 指向 `libao*`，都是 `kejulibao*` 之类，不是这 16 个
#   ⇒ 开箱奖励由**原版服务端**下发；我方 `useItem` 只扣物品不回奖励
#   ⇒ 上架=卖了开出来是空的壳子。老板裁定：**宁可不卖，也不卖空壳**。
#
# ★ 恢复条件（缺一不可）：
#   ① `_ep_use_item`（`items_currency.py`）补上真正的开箱奖励；
#   ② 把下面 `_LIMIT_PACKS_OFF` 改名回 `LIMIT_PACKS`；
#   ③ `fz_boot_server.py` 里 `out['限时'] = []` 那段换回按 `LIMIT_PACKS` 生成货架。
#
# 数据保留在这里，不要在别处再抄一份（"两份账"是这个项目反复踩的坑）。
# 上架开关：False = 不卖（当前）。改成 True 之前先满足上面 ①。
_LIMIT_PACKS_ENABLED = False

_LIMIT_PACKS_OFF = {
    'libao1041': ('限时礼包(桂秋)', 588),
    'libao1042': ('限时礼包(商吕)', 588),
    'libao1043': ('限时礼包(竹春)', 488),
    'libao1012': ('兵器秘籍礼包', 388),
    'libao1013': ('拳脚秘籍礼包', 388),
    'libao1014': ('轻内秘籍礼包', 388),
    'libao017': ('新秀礼包', 258),
    'libao041': ('每日礼包', 158),
    'libao1049': ('名士礼包(中秋)', 588),
    'libao1050': ('名士礼包(秋分)', 588),
    'libao1003': ('悠悠入梦礼', 188),
    'libao1052': ('九月幸运福袋', 100),
    'libao1005': ('武学升级礼包', 200),
    'libao1006': ('不醉不归礼包', 400),
    'libao1007': ('经脉调息礼包', 200),
    'libao1008': ('神兵淬炼礼包', 688),
}
# 上架开关：False = 不卖（当前）。改成 True 之前先满足上面 ①。
LIMIT_PACKS = {} if not _LIMIT_PACKS_ENABLED else _LIMIT_PACKS_OFF


# ===========================================================================
# ★★ 神兵「加工」（`jiagongwupin1`）—— 2026-10-13 客户反馈
#    「玄兵古洞 → 加工 → 点『是』→ 获得商品数据出错..」的修复。
#
#   客户端链路（`views/layer/ShenBingLayer/JiaGong.lua:121`）：
#     `PopYuanBaoBuyItemLayer("jiagongwupin1")` = `YuanBaoPayLayer.buyItem`
#       → `get_goods_2/jiagongwupin1`（取付款弹窗数据；拿不到就弹"获得商品数据出错.."）
#       → 点购买 → `TransCheck:buyItem` → `buy_goods_3/jiagongwupin1`（真扣 50 元宝）
#     → 成功后客户端本地改外观/描述（`JiaGong:setShenBingWeapon_inAndOut`
#       → `ShenBingDuanZao:updateShenBingInfo` 改 `shenBingItems` 的
#       `equipDescId`/`weaponLookId`），随存档上传、由 `fz_boot_server`
#       登录白名单回写落档。
#
#   原版这件的商品定义只在**官方服务端**——客户端全树只有 JiaGong.lua 一处引用
#   （storeItem/shoplist 里都没有）⇒ 私服必须在这里"钦定"：
#     · `_extra_goods` 认它（get_goods / get_goods_2 / buy_goods_3 三个入口共用）
#     · `_extra_payload` 给全弹窗字段（name/price/dsc1/dsc2/icon/...）
#     · `_extra_buy` 结算：**真扣元宝、不发物品**（效果全在客户端做）
#   价格 50 与客户端文案一致（`JiaGong.lua:101`"将消耗50元宝，是否确定？"）。
#   ★ 不要加进 MALL_GOODS —— 那会把"加工服务"错误上架到商城页签。
JIAGONG_GOODS = {
    'jiagongwupin1': ('神兵加工', 50, 'Image/UI/StoreUI/wuqi.png'),
    # ★ 2026-10-23 v41：神兵改名（化金粉，200 元宝）——客户第二次改神兵名时
    #   `ShenBingNameLayer` 走 `PopYuanBaoBuyItemLayer("gaimingwupin1")`，
    #   原版商品定义只在官方服务端 ⇒ 弹「获得商品数据出错」。
    #   修复方式与神兵加工同族：真扣元宝、不发物品（改名效果客户端本地做，
    #   随存档上传落档）。价格 200 与客户端文案一致（"改名将消耗200元宝"）。
    'gaimingwupin1': ('化金粉', 200, 'Image/UI/StoreUI/wuqi.png'),
}


def _volume_label(nm):
    """原版显示带括号：`柳玄风卷(上)`（`world.lua` 里写的是"柳玄风卷上"）。"""
    for suf in ('上', '下'):
        if nm.endswith(suf) and len(nm) > 1:
            return '%s(%s)' % (nm[:-1], suf)
    return nm


def privilege_shelf_rows():
    """名士/雅士特权兑换的货架行（进「商城」栏，2026-10-03 客户要求）。"""
    rows = []
    for iid, _p in PRIVILEGE_GOODS.items():
        rows.append({'id': iid, 'itemId': iid, 'name': _p['name'],
                     'dsc': _p['dsc'], 'icon': _p['icon'],
                     'price': _p['price'], 'priceUnit': 'yuanbao',
                     'number': 1, 'itype': 13, 'type': 13})
    return rows


def privilege_expired(ctx=None):
    """读名士/雅士当前到期时间（`get_store_list_4` 下发用）。
    雅士缺省=现在+30 天（L3d 决策：默认已拥有）；名士缺省=0（未拥有）。
    ★ 直接读盘（不依赖 ctx）——宿主服务端在拼商城应答时也能调。"""
    import os as _os
    import json as _json
    priv = {}
    try:
        _p = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), STATE)
        with open(_p, encoding='utf-8') as _f:
            priv = (_json.load(_f) or {}).get('privileges') or {}
    except Exception:                              # noqa: BLE001
        priv = {}
    now = int(time.time())

    def _n2(v, d=0):
        try:
            return int(float(v))
        except (TypeError, ValueError):
            return d
    yueka = _n2(priv.get('yueka'), 0)
    yashi = _n2(priv.get('yashi'), 0) or (now + PRIVILEGE_DAYS * 86400)
    return {'yueka_expired_time': yueka, 'yashi_expired_time': yashi}


def mall_shelf_rows():
    """「商城」页签的货架行（原版 11 件）。

    字段按 `StoreLayer.lua:416-432` 的 `createPanelItem` 逐行抠出来的：
      `icon` 喂 `loadTexture`（:427）、`name` 喂 `setString`（:430）、
      `price` 喂 `setString`（:431）、`itemId` 用于购买与状态、`number` 用于数量。
    `expired_time` 只有 `specialItem` 命中的件才给（:455/:465 会读它算剩余天数）。
    """
    rows = []
    for iid, nm, price, itype, unit, dsc1, dsc2, icon in MALL_GOODS:
        row = {
            'id': iid, 'itemId': iid, 'name': nm,
            'dsc': dsc1, 'dsc1': dsc1, 'dsc2': dsc2,
            'icon': _mall_icon(icon),
            'price': price, 'priceUnit': 'yuanbao',
            'number': 1, 'itype': itype, 'type': itype, 'unit': unit,
        }
        if iid in MALL_EXPIRING:
            # 未购买 ⇒ 给 0（< GetTime()+60 ⇒ 走 else 分支，正常显示价格）
            row['expired_time'] = 0
        rows.append(row)
    return rows


def _volume_payload(ctx, vid):
    nm, price, maps = VOLUME_PRICE[vid]
    st = _st(ctx)
    return {
        'id': vid, 'itemId': vid, 'name': _volume_label(nm),
        'dsc': '购买后可进入 %s 关卡探索。' % maps.replace(';', '、'),
        'icon': VOLUME_ICON, 'price': price, 'priceUnit': 'yuanbao',
        # ★ 2026-10-03：itype 必须 11 —— 客户端 `StoreLayer:aftreBuyGoodsSuccess`
        #   只认 itype==11 才写 `m_volume[itemId]=true`（章节解锁）；5 会把卷塞背包。
        'number': 1, 'itype': 11, 'type': 11, 'unit': '卷',
        'isBuy': 1 if vid in (st.get('volumes') or {}) else 0,
    }


def _volume_buy(ctx, st, vid):
    """买卷：真扣元宝 + 真记解锁（重复买不重复扣）。"""
    nm, price, maps = VOLUME_PRICE[vid]
    st.setdefault('volumes', {})
    if vid in st['volumes']:
        return ctx.fail('你已经拥有%s了' % _volume_label(nm),
                        '★ 买卷：%s 已解锁，不重复扣' % vid)
    have = _cur(ctx, YUANBAO)
    if have < price:
        return ctx.fail('元宝不足', '★ 买卷：%s 需要 %d 元宝，只有 %d' % (vid, price, have))
    if not _spend_cur(ctx, YUANBAO, price):
        return ctx.fail('元宝不足', '★ 买卷：扣减失败')
    st['volumes'][vid] = {'name': nm, 'maps': maps.split(';'),
                          'at': int(time.time())}
    _save(ctx, st)
    ctx.log('[商城] 买卷 %s(%s) -%d 元宝，解锁 %d 个副本'
            % (vid, nm, price, len(maps.split(';'))))
    return ctx.ok({
        'special_reward': {}, 'total_yuanbao': _cur(ctx, YUANBAO),
        'remove_yuanbao': price, 'activity': {},
    }, '★ 元宝买卷 %s（-%d 元宝，已解锁 %d 个副本）'
       % (_volume_label(nm), price, len(maps.split(';'))))


def _extra_goods(kind, iid):
    """`iid` 是不是「卷」/「礼包」/「商城件」/「合体武学宝箱」/「测试礼包」/「特权」/「神兵加工」；是就回 (name, price, icon)。"""
    if iid in JIAGONG_GOODS:
        return JIAGONG_GOODS[iid]
    if iid in TEST_PACKS:
        nm, price = TEST_PACKS[iid]
        return (nm, price, PACK_ICON)
    if iid in PRIVILEGE_GOODS:
        _p = PRIVILEGE_GOODS[iid]
        return (_p['name'], _p['price'], _p['icon'])
    if iid in VOLUME_PRICE:
        nm, price, _maps = VOLUME_PRICE[iid]
        return (_volume_label(nm), price, VOLUME_ICON)
    if iid in LIMIT_PACKS:
        nm, price = LIMIT_PACKS[iid]
        return (nm, price, PACK_ICON)
    try:
        import fz_api.combo_box as _cb
        if _cb.is_combo_box(iid):
            return (_cb.COMBO_BOXES[iid]['name'], _cb.COMBO_PRICE, _cb.COMBO_ICON)
    except Exception:                             # noqa: BLE001
        pass
    if iid in MALL_PRICE:
        # 商城那 11 件全部走这里：实体件也算"钦定清单"，
        # 因为它们的价来自老板截图（服务端权威），不是表里的 buyPrice。
        _g = mall_goods_info(iid)
        if _g:
            return (_g[0], _g[1], _g[5])
    return None


def _extra_payload(ctx, iid):
    """卷 / 礼包 / 商城商品 的信息（`get_goods` / `get_goods_2` 共用）。

    ★★ 三类的**字段必须给全**（尤其 `dsc1`/`dsc2`/`share`/`discount`）。
      老板实机发现"**限时礼包弹窗显示的是遁地符的描述和图标**"——
      根因就是这里礼包分支只填了 `dsc`，没填 `dsc1`/`dsc2`：
      客户端 `YuanBaoPayLayer.lua:96` 读的是 `data.dsc1`/`data.dsc2`，
      拿到 nil 就落回 UI 上次的文本（`YuanBaoPayUI.lua:98` 的默认值也是"没有描述"）。
      ⇒ 打开过的上一个商品（遁地符）的文字就"粘"在了礼包弹窗上。
      `StoreLayer.lua:431` 读 `storeItem.price`、`:427` 读 `icon`，同样都要给。
    """
    nm, price, icon = _extra_goods(None, iid)
    st = _st(ctx)
    # ★ 2026-10-19 v37b：我方自建礼包（TEST_PACKS）零花费——付款弹窗价格也显示 0
    #   （原商场商品走同函数，价格原样）。之前 v37 首版撤 _disp_price 时撤过了头。
    if _free_mode() and iid in TEST_PACKS:
        price = 0
    # ★ 神兵「加工」（服务类商品，`itype=13` 虚拟）：弹窗要的字段给全。
    #   `discount` 给 False（不是 1）——`YuanBaoPayLayer:setImageShow` 是
    #   `if flag then 显示九折图` 的写法，任何真值都会挂个「九折」角标。
    if iid in JIAGONG_GOODS:
        if iid == 'gaimingwupin1':
            # ★ 2026-10-23 v41：神兵改名（化金粉）——弹窗文案单独给，别串成"加工"的
            _d1 = '以化金粉涂抹兵器，可为其改换名字与名字颜色。'
            _d2 = '改名效果在本地生效并随存档保存。'
        else:
            _d1 = '可以对神兵进行加工，随机改变武器的外观描述和拔出、收回的描述。'
            _d2 = '在加工前可以对描述进行锁定，已锁定的描述在加工后不会发生变化。'
        return {
            'id': iid, 'itemId': iid, 'name': nm, 'dsc': _d1,
            'dsc1': _d1, 'dsc2': _d2, 'icon': icon,
            'price': price, 'priceUnit': 'yuanbao', 'number': 1,
            'itype': 13, 'type': 13, 'unit': '次',
            'share': '', 'discount': False, 'isBuy': 0,
        }
    # ★ 特权商品（虚拟，itype=13 —— 客户端只弹"购买成功"，不进背包）
    if iid in PRIVILEGE_GOODS:
        _p = PRIVILEGE_GOODS[iid]
        return {
            'id': iid, 'itemId': iid, 'name': _p['name'], 'dsc': _p['dsc'],
            'dsc1': _p['dsc'], 'dsc2': _p['dsc2'], 'icon': _p['icon'],
            'price': _p['price'], 'priceUnit': 'yuanbao', 'number': 1,
            'itype': 13, 'type': 13, 'unit': '个',
            'share': '', 'discount': 1, 'isBuy': 0,
        }
    # ★ 测试礼包（价 1 银两；买完真进背包，玩家自己点开）
    if iid in TEST_PACKS:
        _d = TEST_PACK_DSC.get(iid, '')
        return {
            'id': iid, 'itemId': iid, 'name': nm, 'dsc': _d,
            'dsc1': _d, 'dsc2': '购买后在背包里点「使用」开启。',
            'icon': PACK_ICON, 'price': price, 'priceUnit': TEST_PACK_UNIT,
            'number': 1, 'itype': 10, 'type': 10, 'unit': '个',
            'share': '', 'discount': 1, 'isBuy': 0,
        }
    # ★ 合体武学宝箱（`itype=10`：弹数量框 + 买完真进背包）
    try:
        import fz_api.combo_box as _cb
        if _cb.is_combo_box(iid):
            # ★ 描述必须用**原版物品自己的 `dsc`**（老板 2026-09-28 指出：
            #   之前三段「打开可获得…/江湖失传已久的神功…」是我编的，
            #   背包里显示的那段才是真描述）。`dsc2` 留空 = 与原版商城同形态。
            _d = _cb.vanilla_dsc(iid)
            return {
                'id': iid, 'itemId': iid, 'name': _cb.COMBO_BOXES[iid]['name'],
                'dsc': _d, 'dsc1': _d, 'dsc2': '',
                'icon': _cb.vanilla_icon(iid), 'price': _cb.COMBO_PRICE,
                'priceUnit': 'yuanbao', 'number': 1,
                'itype': 10, 'type': 10, 'unit': '个',
                'share': '', 'discount': 1, 'isBuy': 0,
            }
    except Exception:                             # noqa: BLE001
        pass
    if iid in VOLUME_PRICE:
        _n, _p, maps = VOLUME_PRICE[iid]
        dsc = '购买后可进入 %s 关卡探索。' % maps.replace(';', '、')
        itype = 11                      # ★ 同上：卷必须 11（客户端解锁分支）
    elif iid in LIMIT_PACKS:
        dsc = '这是一个古色古香的丝绸袋子，据说里面装着不少好东西。'
        itype = 1
    else:
        # 商城 11 件：dsc1/dsc2 给真文字（见上）
        _g = mall_goods_info(iid)
        itype = _g[2] if _g else 1
        dsc1 = (_g[3] if _g else '') or ''
        dsc2 = (_g[4] if _g else '') or ''
        return {
            'id': iid, 'itemId': iid, 'name': nm, 'dsc': dsc1,
            'dsc1': dsc1, 'dsc2': dsc2, 'icon': icon,
            'price': price, 'priceUnit': 'yuanbao', 'number': 1,
            'itype': itype, 'type': itype, 'unit': '个',
            'share': '', 'discount': 1, 'isBuy': 0,
        }
    # 卷 / 礼包：同样给全字段
    return {
        'id': iid, 'itemId': iid, 'name': nm, 'dsc': dsc,
        'dsc1': dsc, 'dsc2': '购买后可在背包中开启。', 'icon': icon,
        'price': price, 'priceUnit': 'yuanbao', 'number': 1,
        'itype': itype, 'type': itype, 'unit': '卷' if itype == 11 else '个',
        'share': '', 'discount': 1,
        'isBuy': 1 if iid in (st.get('volumes') or {}) else 0,
    }


def _raise_home_level(ctx):
    """★ 一键提升地契/房契（2026-10-01 老板要）：把房契换成**顶级户型** + 地契记为已搬入。

    顶级户型（`familylist.房契模板` 里 level 最高那批）：
        yangzhou152 = 阳口悬钟，level 4 / huxing012 / 63 个房间
    换上去以后管家那边：招募仆人(lv≥3)、房屋改造(lv≥4)、户型图(huxing005~012) 全都会出现。

    ★★ 2026-10-01 修的三个坑：
      ① `dpId` 以前写成 `dp_yangzhou152` —— **是假的**（`房屋地皮` 里就叫 `yangzhou152`，
         没有 `dp_` 前缀）。假 dpId 会让 `HomelandRoomUtil:outDoorByDp` 认不出门外的地，
         玩家就觉得"这不像我家"。
      ② `on_land.mid` 没写 ⇒ `_sticky_home_mid()` 只能自己现算，和存档里的 mid 对不上
         ⇒ `BaseMap:isUserMap()` 为 false ⇒ 管家不认人。现在沿用存档里的 mid。
      ③ `Homeland.fq` 在存档里是**数组**，客户端要的是**表** ⇒ 这里也一并整成表。
    """
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    fq_id = 'yangzhou152'

    # ---------- ① 玩家存档：读 mid + 顺手把房契升上去（客户端登录时拿到的就是新档） ----------
    save_p = None
    try:
        import hashlib as _h
        save_p = os.path.join(root, 'saves', _h.md5(
            ('%s|%s' % ('guanfangd5056b85e3c2fffc729191fd', 783783)).encode()).hexdigest()[:16] + '.json')
    except Exception:                                                  # noqa: BLE001
        save_p = None
    mid = 0
    if save_p and os.path.isfile(save_p):
        try:
            with open(save_p, encoding='utf-8') as f:
                j = json.load(f)
            role = j[0] if isinstance(j, list) and j else j
            hl = role.get('Homeland') if isinstance(role, dict) else None
            if isinstance(hl, dict):
                _fq = hl.get('fq')
                if isinstance(_fq, list):
                    _merged = {}
                    for _it in _fq:
                        if isinstance(_it, dict):
                            _merged.update(_it)
                    _fq = _merged
                if not isinstance(_fq, dict):
                    _fq = {}
                try:
                    mid = int(_fq.get('mid') or 0)
                except (TypeError, ValueError):
                    mid = 0
                _fq['fqId'] = fq_id
                _fq['name'] = _fq.get('name') or '阳口悬钟'
                _fq.setdefault('id', 'fq100')
                _fq.setdefault('type', '房契')
                _fq['status'] = 1
                _fq['dpId'] = fq_id                     # ★ 真 dpId，别加 dp_ 前缀
                hl['fq'] = _fq
                hl['roomnum'] = 63
                for _k in ('dq', 'yq', 'plant', 'dinner'):
                    if not isinstance(hl.get(_k), list):
                        hl[_k] = []
                for _k in ('prIdIndex', 'prnum'):
                    if not isinstance(hl.get(_k), int):
                        hl[_k] = 0
                with open(save_p, 'w', encoding='utf-8') as f:
                    json.dump(j, f, ensure_ascii=False, indent=1)
        except Exception as _e:                                        # noqa: BLE001
            ctx.log('[商城] 一键提升：改存档房契失败（继续改服务端账本）：%s' % _e)

    # ---------- ② 服务端房契账本 ----------
    p1 = os.path.join(root, 'homeland_state.json')
    st1 = {}
    try:
        with open(p1, encoding='utf-8') as f:
            st1 = json.load(f)
    except Exception:                                                  # noqa: BLE001
        st1 = {}
    if not isinstance(st1, dict):
        st1 = {}
    st1['fqId'] = fq_id
    try:
        with open(p1, 'w', encoding='utf-8') as f:
            json.dump(st1, f, ensure_ascii=False, indent=1)
    except OSError:
        pass

    # ---------- ③ 地契账本：真 dpId + 沿用玩家 mid ----------
    p2 = os.path.join(root, 'homeland_land_state.json')
    st2 = {}
    try:
        with open(p2, encoding='utf-8') as f:
            st2 = json.load(f)
    except Exception:                                                  # noqa: BLE001
        st2 = {}
    if not isinstance(st2, dict):
        st2 = {}
    on = st2.get('on_land') or {}
    on['dpId'] = fq_id
    on.setdefault('location', '扬州城中心')
    if mid > 0:
        on['mid'] = mid
    on['moved_at'] = int(time.time())
    st2['on_land'] = on
    try:
        with open(p2, 'w', encoding='utf-8') as f:
            json.dump(st2, f, ensure_ascii=False, indent=1)
    except OSError:
        pass

    # ---------- ④ mid → 房契 的登记（地图生成要用，且必须和客户端那个 mid 一致） ----------
    if mid > 0:
        try:
            import fz_homeland_map as _hm
            _hm.set_mid(mid, fq_id)
        except Exception:                                              # noqa: BLE001
            pass

    ctx.log('[商城] 一键提升：房契 → %s（阳口悬钟 level4/huxing012/63 房间）mid=%s dpId=%s'
            % (fq_id, mid or '(存档没记)', fq_id))
    return '★ 房契/地契已提升到顶级（阳口悬钟：level 4、户型 huxing012、63 个房间）'


def _extra_buy(ctx, st, iid):
    """买「卷」= 真解锁副本；买「礼包」= 真扣元宝 + 真把礼包塞进背包。"""
    nm, price, _icon = _extra_goods(None, iid)
    # 买多件：客户端弹数量框后 `storeItem.number = num`（`StoreLayer.lua:859`），
    # 再调 `buyStoreItem(..., num, ...)` ⇒ 服务端必须按数量结算，
    # 否则买 99 个只扣 1 个的钱、只进 1 件。
    num = 1
    for _k in ('number', 'num', 'count'):
        _v = ctx.param(_k)
        try:
            _n = int(_v)
            if _n > 0:
                num = _n
                break
        except (TypeError, ValueError):
            continue
    num = max(1, min(num, 999))
    total = price * num

    # ★ 神兵「加工」：服务类消费 —— 真扣元宝、**不发物品**
    #   （新外观是客户端本地改 `shenBingItems` 后随存档回写落档，见 `JIAGONG_GOODS` 注释）。
    if iid in JIAGONG_GOODS:
        have_jg = _cur(ctx, YUANBAO)
        if have_jg < total:
            return ctx.fail('元宝不足', '★ 神兵加工：需要 %d 元宝，只有 %d' % (total, have_jg))
        if not _spend_cur(ctx, YUANBAO, total):
            return ctx.fail('元宝不足', '★ 神兵加工：扣减失败')
        rec = st.setdefault('jiagong', {})
        rec['count'] = int(rec.get('count') or 0) + num
        rec['at'] = int(time.time())
        _save(ctx, st)
        _svc = '神兵改名' if iid == 'gaimingwupin1' else '神兵加工'
        ctx.log('[神兵] %s %s x%d -%d 元宝（服务消费，不发物品）' % (_svc, iid, num, total))
        return ctx.ok({'special_reward': {}, 'total_yuanbao': _cur(ctx, YUANBAO),
                       'remove_yuanbao': total, 'activity': {}},
                      '★ %s成功（-%d 元宝）' % (_svc, total))

    # ★ 特权商品：真扣元宝 + 名士/雅士到期时间 +30 天（存 `st['privileges']`，
    #   `fz_boot_server.get_store_list_4` 下发时读它）
    if iid in PRIVILEGE_GOODS:
        have_y = _cur(ctx, YUANBAO)
        if have_y < total:
            return ctx.fail('元宝不足', '★ 买特权：%s 需要 %d 元宝，只有 %d'
                            % (nm, total, have_y))
        if not _spend_cur(ctx, YUANBAO, total):
            return ctx.fail('元宝不足', '★ 买特权：扣减失败')
        now = int(time.time())
        priv = st.setdefault('privileges', {})
        skey = PRIVILEGE_GOODS[iid]['state_key']
        cur_exp = _int(priv.get(skey), 0)
        base = max(now, cur_exp)
        priv[skey] = base + PRIVILEGE_DAYS * 86400
        _save(ctx, st)
        ctx.log('[商城] 买特权 %s x%d -%d 元宝，到期 %s'
                % (iid, num, total,
                   time.strftime('%Y-%m-%d', time.localtime(priv[skey]))))
        return ctx.ok({'special_reward': {}, 'total_yuanbao': _cur(ctx, YUANBAO),
                       'remove_yuanbao': total, 'activity': {}},
                      '★ 元宝买特权 %s（-%d 元宝，+30 天）' % (nm, total))

    # ★ 测试礼包：按 **银两（money）** 结算，不限购、可重复买
    #   ★ 2026-10-19 v37b：零花费模式（free_purchase.flag，danji 包自带）⇒ total=0
    #   ——我方礼包（药品/基础武学/心神/材料/货币/书页…）全部 0 元购；
    #   原商场不受影响（v37 对原商场的免扣已按老板范围纠正撤销）。
    if iid in TEST_PACKS:
        if _free_mode():
            total = 0
        have_m = _cur(ctx, TEST_PACK_UNIT)
        if have_m < total:
            return ctx.fail('银两不足', '★ 买测试礼包：%s 需要 %d 银两，只有 %d'
                            % (iid, total, have_m))
        if not _spend_cur(ctx, TEST_PACK_UNIT, total):
            return ctx.fail('银两不足', '★ 买测试礼包：扣减失败')
        _grant(ctx, iid, num)
        ctx.log('[商城] 买测试礼包 %s(%s) x%d -%d 银两，已入背包' % (iid, nm, num, total))
        # ★ 2026-10-01 老板最终定的两颗丹药（**永久 100% 冲脉**）：
        #   效果一半在客户端（经脉冲脉的判定在客户端 `Meridian:getRandomEventState`）、
        #   一半在服务端（隐脉冲脉由服务端判 errcode）。
        #   这里负责把"永久标记"写进存档 ⇒ 跟着档走；再由 `_overlay_persisted_attrs()`
        #   随角色下发 ⇒ 不会出现"面板变了服务端没变"。
        _pill_effect = None
        try:
            import fz_api.meridian as _md
            if iid == 'testpill_break100':
                _pill_effect = _md.pill_break100(ctx)
            elif iid == 'testpill_hiddenbreak100':
                _pill_effect = _md.pill_hidden_break100(ctx)
        except Exception as _pe:                                      # noqa: BLE001
            ctx.log('冲脉丹生效失败：%s' % _pe)
        if iid == 'testpack_homelevel':
            try:
                _pill_effect = _raise_home_level(ctx)
            except Exception as _he:                                  # noqa: BLE001
                ctx.log('一键提升地契/房契失败：%s' % _he)
        # ★★ 2026-10-08 三梦境盒发货改**"打开即发货"**（老板实测"打开的礼包没有生效"）：
        #   买=只卖盒子（进背包），发货统一在**使用礼包**时走
        #   RoleUseItem_Special → getWebReward(rewardType=3) → dream_world._web_reward
        #   认盒分发（pendingSupplies 记账 + item2 实名牌展示）→ 下次入梦自动放进梦内背包。
        #   这里不再记账——保留会与"打开"双份发放。
        #   （配套：三盒 type=特殊+rewardid；RoleUseItem_Special 主世界 nil 守卫补丁。）
        if iid in ('testpack_dreamsupply', 'testpack_dreamtreasure', 'testpack_dreamlamp'):
            _pill_effect = '打开背包里的礼包即可获得，下次入梦自动随行'
        return ctx.ok({
            'special_reward': {'itemId': iid, 'num': num},
            'total_yuanbao': _cur(ctx, YUANBAO),
            'remove_yuanbao': 0,
            # ★ 增量（不是余额！）：客户端 `TransCheck:buyItem` 的成功回调会按它扣
            #   客户端存档里的 `money`，这样"1 银两"在背包界面上看得见。
            #   用余额会把老板真正的碎银覆盖成服务端钱袋的数（两本账），所以只回增量。
            'remove_money': total,
            'activity': {},
        }, '★ 买测试礼包 %s x%d（-%d 银两，已入背包）%s'
           % (nm, num, total, ('　' + _pill_effect) if _pill_effect else ''))

    if iid in VOLUME_PRICE:
        st.setdefault('volumes', {})
        if iid in st['volumes']:
            return ctx.fail('你已经拥有%s了' % nm, '★ 买卷：%s 已解锁，不重复扣' % iid)
    have = _cur(ctx, YUANBAO)
    if have < total:
        return ctx.fail('元宝不足', '★ 买%s：%s 需要 %d 元宝，只有 %d'
                        % ('卷' if iid in VOLUME_PRICE else '商品', iid, total, have))
    if not _spend_cur(ctx, YUANBAO, total):
        return ctx.fail('元宝不足', '★ 买%s：扣减失败' % iid)
    if iid in VOLUME_PRICE:
        _n, _p, maps = VOLUME_PRICE[iid]
        st['volumes'][iid] = {'name': nm, 'maps': maps.split(';'), 'at': int(time.time())}
        _save(ctx, st)
        ctx.log('[商城] 买卷 %s(%s) -%d 元宝，解锁 %d 个副本'
                % (iid, nm, price, len(maps.split(';'))))
        return ctx.ok({'special_reward': {}, 'total_yuanbao': _cur(ctx, YUANBAO),
                       'remove_yuanbao': price, 'activity': {}},
                      '★ 元宝买卷 %s（-%d 元宝，已解锁 %d 个副本）'
                      % (nm, price, len(maps.split(';'))))
    if iid in MALL_VIRTUAL:
        # ★ 虚拟商品（`itype=13`）：`StoreLayer.lua:364-365` 只弹一句"成功购买"，
        #   客户端**不会**去背包里找 ⇒ 服务端只记账、不塞背包（塞了反而是凭空多出来的物品）。
        st.setdefault('virtualGoods', {})
        rec = st['virtualGoods'].setdefault(iid, {'name': nm, 'total': 0})
        rec['total'] = int(rec.get('total') or 0) + num
        rec['at'] = int(time.time())
        _save(ctx, st)
        ctx.log('[商城] 买虚拟商品 %s(%s) x%d -%d 元宝（不进背包）' % (iid, nm, num, total))
        return ctx.ok({'special_reward': {}, 'total_yuanbao': _cur(ctx, YUANBAO),
                       'remove_yuanbao': total, 'activity': {}},
                      '★ 元宝买虚拟商品 %s x%d（-%d 元宝，不占背包）' % (nm, num, total))
    # 实体商品 / 礼包：真进背包，按数量给
    _grant(ctx, iid, num)
    ctx.log('[商城] 买 %s(%s) x%d -%d 元宝，已入背包' % (iid, nm, num, total))
    return ctx.ok({'special_reward': {'itemId': iid, 'num': num},
                   'total_yuanbao': _cur(ctx, YUANBAO),
                   'remove_yuanbao': total, 'activity': {}},
                  '★ 元宝买 %s x%d（-%d 元宝，已入背包）' % (nm, num, total))


def _ep_get_goods(ctx, st):
    iid = _s(ctx.args[0]) if ctx.args else _s(ctx.param('itemId'))
    if not iid:
        return ctx.fail('缺少 itemId', '★ get_goods：URL 没给 itemId')
    if _extra_goods(None, iid):
        _g = _extra_goods(None, iid)
        return ctx.ok(_extra_payload(ctx, iid),
                      '★ 额外商品 %s（%d 元宝）' % (_g[0], _g[1]))
    key = _key_of(iid)
    if key not in goods():
        return ctx.fail('未找到商品信息 id : %s' % iid,
                        '★ get_goods：%s 不在 shoplist["Sheet1"]（她那边会 error）' % iid)
    return ctx.ok(_goods_payload(ctx, key),
                  '★ 商品信息 %s（shoplist + storeItem 真价）' % _info(key)['name'])


def _ep_get_goods_2(ctx, st):
    iid = _s(ctx.args[0]) if ctx.args else _s(ctx.param('itemId'))
    if not iid:
        return ctx.fail('缺少 itemId', '★ get_goods_2：URL 没给 itemId')
    if _extra_goods(None, iid):
        d = _extra_payload(ctx, iid)
        d['mark'] = ctx.param('mark') if isinstance(ctx.param('mark'), dict) else {}
        return ctx.ok(d, '★ 额外商品 %s（同 get_goods）' % _extra_goods(None, iid)[0])
    key = _key_of(iid)
    if key not in goods():
        return ctx.fail('未找到商品信息 id : %s' % iid,
                        '★ get_goods_2：%s 不在 shoplist["Sheet1"]' % iid)
    d = _goods_payload(ctx, key)
    # 上行 others 里有经脉印记折扣/免单标记时，价格按她客户端算好的来（这里只回原价）
    d['mark'] = ctx.param('mark') if isinstance(ctx.param('mark'), dict) else {}
    return ctx.ok(d, '★ 商品信息2 %s（同 get_goods；others 只做回显）' % _info(key)['name'])


def _ep_buy_goods_3(ctx, st):
    """`buy_goods_3/<itemId>` —— `TransCheck.lua:322-347` 读：
    `data.special_reward`（回给回调）/`data.total_yuanbao`（`role:setAttr("yuanbao",...)`）/
    `data.remove_yuanbao`（免单判断）/`data.activity`（对象，`pairs` 后 `..` 拼中文名）。

    钱走 `items_currency.add_currency(ctx,'yuanbao',-price)`，货走 `add_count`。

    ★ 「关卡」页签卖的是**卷**（`volume_2` 声震武林卷…），它不是 `shoplist` 里的商品
      ⇒ 走下面 `_volume_buy` 那条分支：真扣元宝 + 真记解锁。
    """
    iid = _s(ctx.args[0]) if ctx.args else _s(ctx.param('itemId'))
    if not iid:
        return ctx.fail('缺少 itemId', '★ buy_goods_3：URL 没给 itemId')
    if _extra_goods(None, iid):
        return _extra_buy(ctx, st, iid)
    key = _key_of(iid)
    if key not in goods():
        return ctx.fail('未找到商品信息 id : %s' % iid,
                        '★ buy_goods_3：%s 不在 shoplist["Sheet1"]' % iid)
    num = max(1, _int(ctx.param('quantity') or ctx.param('num'), 1))
    info = _info(key)
    price = info['buyPrice'] or price_of(key, 'trader')
    total = price * num
    have = _cur(ctx, YUANBAO)
    if have < total:
        return ctx.fail('元宝不足', '★ 买商品：需要 %d 元宝，只有 %d' % (total, have))
    if not _spend_cur(ctx, YUANBAO, total):
        return ctx.fail('元宝不足', '★ 买商品：扣减失败')
    _grant(ctx, key, num)
    return ctx.ok({
        'special_reward': {},
        'total_yuanbao': _cur(ctx, YUANBAO),
        'remove_yuanbao': total,
        'activity': {},
    }, '★ 元宝购买 %s×%d（-%d 元宝，真发货）' % (info['name'], num, total))


def _ep_check_fail_transaction_2(ctx, st):
    """`check_fail_transaction_2/<transType>` —— `TransCheck.lua:246-268` 的 errcode 语义：
    -1 参数错误 / 0 无异常 / 1 不存在 trans_id / 3 不存在福利 trans_id / 7 非法 event_id
    … 其中 0/1/3/5/7/8 她都会把本地凭证删掉。这里没有官方 DB，按"凭证不存在"回 1，
    语义与她注释一致（她会 `updateTrans(FAILED)`，不会卡界面）。
    """
    typ = _s(ctx.args[0]) if ctx.args else '1'
    oid = _s(ctx.param('trans_id') or ctx.param('order_id'))
    if not oid:
        return ctx.fail('参数错误', '★ 校验交易：上行缺 trans_id', errcode=-1)
    if oid in st.get('orders', {}):
        st['orders'].pop(oid, None)
        _save(ctx, st)
        return ctx.ok({'trans_id': oid, 'transType': typ},
                      '★ 校验交易 %s：服务端有此订单，已核销' % oid)
    return ctx.fail('不存在trans_id', '★ 校验交易 %s：服务端没有该订单记录（errcode=1 她会删本地凭证）'
                    % oid, errcode=1)


# ===========================================================================
# 江湖名士（月卡，`get_jhms_desc` / `get_jhms_reward`）
# ===========================================================================
# 江湖名士每日福利 —— 她客户端字段名与中文名来自
# `YueKaLayer.lua:246-339`（title_receive_per_day.yuanbao/money/exp/pot/yinpiao）
# 与 `Role.lua getCHAttrName`。这里的**数量**取自她表里真实存在的奖励道具，
# 不编造"官方数值"：每日元宝/碎银按她钱袋子的真实现值回读。
def _ep_get_jhms_desc(ctx, st):
    y = st.setdefault('yueka', {})
    now = int(time.time())
    expired = _int(y.get('expired_time'), 0)
    if expired <= now:
        # 没开通：`YueKaLayer.lua:75-79` 读 title_status.expired_time，0 表示未获得身份
        expired = 0
    per_day = {
        'yuanbao': 0, 'money': 0, 'exp': 0, 'pot': 0, 'yinpiao': 0,
    }
    rights = ['每日可领取名士福利', '专属称号「江湖名士」', '专属头像框与聊天颜色',
              '每日补领未领福利（最多 14 天）']
    return ctx.ok({
        'eleven': False,
        'status': 'OPEN',
        'errmsg': '',
        'title_name': {'title': '江湖名士', 'desc': '武林中声名远播之人方可获此称号。'},
        'title_receive_per_day': per_day,
        'title_receive_once_prize': {'fuyuandan': 0, 'desc': '开通即赠福缘丹'},
        'title_extra_rights': rights,
        # `YueKaLayer.lua:246-339` 逐字段读（全给，缺一个就是 nil 拼接崩）
        'title_status': {
            'expired_time': expired,
            'refresh_time': '',
            'price_desc': '',
            'not_received_days': 0,
            'notjia_received_days': 0,
            'today_not_received_days': 0,
        },
        'canBuy': False,
        'message': '本私服暂未接入应用商店支付，无法开通江湖名士（商品表在原官方服务端）。',
        'product_id': 'fzjh_yueka',
    }, '江湖名士：面板结构齐全；未接入应用商店支付 ⇒ canBuy=false（不编造支付）')


def _ep_get_jhms_reward(ctx, st):
    """`get_jhms_reward` —— `YueKaLayer.lua:562-607` 只看 errcode。"""
    oid = _s(ctx.param('trans_id'))
    days = max(1, _int(ctx.param('days'), 1))
    y = st.setdefault('yueka', {})
    if _int(y.get('expired_time'), 0) <= int(time.time()):
        return ctx.fail('尚未开通江湖名士', '★ 名士补领：未开通（她只 PopText，不崩）')
    return ctx.ok({'trans_id': oid, 'days': days}, '★ 名士补领 %d 天' % days)


# ===========================================================================
# 制作组（面具材料商人 / 制作组 NPC 副本）
# ===========================================================================
MASK_ITEMS = 5


def _ep_get_mask_list(ctx, st):
    """`get_mask_list` —— `ZhiZuoZu.lua:359-429` 读：
    `data.status`(串 "OPEN") / `data.points`(数，江湖美誉) / `data.yuanbao`(数，刷新价)。

    货架 = 她 `ZhiZuoZu.lua:177-207` 写死的 28 个 `cailiao200_XX` 里当天上架的
    （她本地也是按 `role:getDayFlag("制作组商人道具列表")` 抽的，见 `:435-457`）。
    """
    m = st.setdefault('mask', {})
    now = int(time.time())
    day = now // DAY
    if _int(m.get('day'), -1) != day or not m.get('keys'):
        m['day'] = day
        m['keys'] = _pick('mask-%d' % day, CAILIAO, MASK_ITEMS)
        _save(ctx, st)
    return ctx.ok({
        'status': 'OPEN',
        'points': _cur(ctx, MEIYU),
        'yuanbao': 50,
        'list': list(m.get('keys') or []),
    }, '★ 制作组商人：今日上架 %d 件材料（cailiao200_XX 她自己的 28 件表）'
       % len(m.get('keys') or []))


def _ep_refresh_mask_list(ctx, st):
    """`refresh_mask_list` —— `ZhiZuoZu.lua:407-419` 只看 errcode；刷新费 50 元宝。"""
    oid = _s(ctx.param('order_id'))
    price = 50
    if not _spend_cur(ctx, YUANBAO, price):
        return ctx.fail('元宝不足', '★ 刷新制作组商人：需要 %d 元宝' % price)
    m = st.setdefault('mask', {})
    m['seq'] = _int(m.get('seq'), 0) + 1
    m['keys'] = _pick('mask-%d-%d' % (int(time.time()) // DAY, m['seq']), CAILIAO, MASK_ITEMS)
    _save(ctx, st)
    return ctx.ok({'order_id': oid, 'list': list(m['keys'])},
                  '★ 刷新制作组商人（-%d 元宝）：%d 件' % (price, len(m['keys'])))


def _ep_get_npc_list(ctx, st):
    """`get_npc_list` —— `ZhiZuoZu.lua:240-252` 读 `data["data1"]` / `data["data2"]`。

    `data1` = npcId → 副本房间/茅房 id（`addRoleToMap` :278-286 读 `NpcList.maofang`
    与 `NpcList.npc_id_user`，还有 `ZhiZuoZuRoleList[npcId].fbId`）；
    `data2` = npcId → 累计任务次数（`addTaskTotalCount` :254-269 读 `tonumber(v)`）。
    NPC 清单 = 她 `ZhiZuoZu.lua:13-175` 写死的 20 个制作组成员。
    """
    z = st.setdefault('npc_records', {})
    npcs = _zhizuozu_npcs()
    data1 = {}
    data2 = {}
    for npc in npcs:
        data1[npc] = {
            'npcId': npc,
            'roomId': _ZNZ_ROOMS.get(npc, {}).get('roomId', ''),
            'fbId': _ZNZ_ROOMS.get(npc, {}).get('fbId', ''),
            'maofangId': _ZNZ_ROOMS.get(npc, {}).get('maofangId', ''),
        }
        rec = z.get(npc) if isinstance(z.get(npc), dict) else {}
        data2[npc] = _int(rec.get('total'), 0)
    data1['maofang'] = _ZNZ_ROOMS_MAOFANG
    npc_id_user = {n: 1 for n in npcs}
    data1['npc_id_user'] = npc_id_user
    return ctx.ok({'data1': data1, 'data2': data2},
                  '★ 制作组列表：%d 名成员（她 ZhiZuoZu.lua 写死的表）' % len(npcs))


def _ep_add_npc_record(ctx, st):
    """`add_npc_record/<npcId>` —— `SpecialModule.lua:68-71` 读 `data.npc_sum`（今日次数）。"""
    npc = _s(ctx.args[0]) if ctx.args else _s(ctx.param('npcId') or ctx.param('npc_id'))
    if not npc:
        return ctx.fail('缺少 npcId', '★ 制作组记录：URL 没给 npcId')
    z = st.setdefault('npc_records', {})
    rec = z.get(npc) if isinstance(z.get(npc), dict) else {}
    day = int(time.time()) // DAY
    if _int(rec.get('day'), -1) != day:
        rec = {'day': day, 'today': 0, 'total': _int(rec.get('total'), 0)}
    rec['today'] = _int(rec.get('today'), 0) + 1
    rec['total'] = _int(rec.get('total'), 0) + 1
    z[npc] = rec
    _save(ctx, st)
    return ctx.ok({'npc_sum': rec['today'], 'total': rec['total'], 'npcId': npc},
                  '★ 制作组 %s 今日第 %d 次（累计 %d）' % (npc, rec['today'], rec['total']))


# 她 `ZhiZuoZu.lua:13-175` 的 20 个制作组成员（npcId + 副本位）
_ZNZ_ROOMS = {
    'npc200_16': {'fbId': 'fb200r02_1', 'maofangId': 'fb200r11_1', 'roomId': 'fb200_02'},
    'npc200_17': {'fbId': 'fb200r02_2', 'maofangId': 'fb200r11_2', 'roomId': 'fb200_02'},
    'npc200_13': {'fbId': 'fb200r03_1', 'maofangId': 'fb200r11_3', 'roomId': 'fb200_03'},
    'npc200_14': {'fbId': 'fb200r03_2', 'maofangId': 'fb200r11_4', 'roomId': 'fb200_03'},
    'npc200_22': {'fbId': 'fb200r03_3', 'maofangId': 'fb200r11_5', 'roomId': 'fb200_03'},
    'npc200_06': {'fbId': 'fb200r04_1', 'maofangId': 'fb200r11_6', 'roomId': 'fb200_04'},
    'npc200_10': {'fbId': 'fb200r06_1', 'maofangId': 'fb200r11_7', 'roomId': 'fb200_06'},
    'npc200_15': {'fbId': 'fb200r06_2', 'maofangId': 'fb200r11_8', 'roomId': 'fb200_06'},
    'npc200_12': {'fbId': 'fb200r07_1', 'maofangId': 'fb200r11_9', 'roomId': 'fb200_07'},
    'npc200_25': {'fbId': 'fb200r08_1', 'maofangId': 'fb200r11_10', 'roomId': 'fb200_08'},
    'npc200_21': {'fbId': 'fb200r09_1', 'maofangId': 'fb200r11_11', 'roomId': 'fb200_09'},
    'npc200_03': {'fbId': 'fb200r12_1', 'maofangId': 'fb200r11_12', 'roomId': 'fb200_12'},
    'npc200_04': {'fbId': 'fb200r12_2', 'maofangId': 'fb200r11_13', 'roomId': 'fb200_12'},
    'npc200_05': {'fbId': 'fb200r13_1', 'maofangId': 'fb200r11_14', 'roomId': 'fb200_13'},
    'npc200_26': {'fbId': 'fb200r13_2', 'maofangId': 'fb200r11_15', 'roomId': 'fb200_13'},
    'npc200_18': {'fbId': 'fb200r14_1', 'maofangId': 'fb200r11_16', 'roomId': 'fb200_14'},
    'npc200_20': {'fbId': 'fb200r16_1', 'maofangId': 'fb200r11_17', 'roomId': 'fb200_16'},
    'npc200_23': {'fbId': 'fb200r16_2', 'maofangId': 'fb200r11_18', 'roomId': 'fb200_16'},
    'npc200_19': {'fbId': 'fb200r17_1', 'maofangId': 'fb200r11_19', 'roomId': 'fb200_17'},
    'npc200_24': {'fbId': 'fb200r18_1', 'maofangId': 'fb200r11_20', 'roomId': 'fb200_18'},
}
_ZNZ_ROOMS_MAOFANG = 'fb200r11_1'


def _zhizuozu_npcs():
    return sorted(_ZNZ_ROOMS.keys(), key=lambda x: _int(x.split('_')[-1], 0))


# ===========================================================================
# 贡献商人（师门 NPC / 游侠 NPC 交易，`SalesLayer`）
# ===========================================================================
DEVOTE_ITEMS = 9


def _devote_pool():
    """贡献商人卖的：真道具/特殊道具/服务器物品。"""
    return _cat(T_ITEM, T_SPECIAL, T_SERVER_ITEM)


def _devote_rows(ctx, st, typ, menpai):
    d = st.setdefault('devote', {})
    now = int(time.time())
    day = now // DAY
    sk = '%s|%s' % (typ, menpai)
    node = d.get(sk)
    if not isinstance(node, dict) or _int(node.get('day'), -1) != day:
        node = {'day': day,
                'keys': _pick('devote-%s-%d' % (sk, day), _devote_pool(), DEVOTE_ITEMS)}
        d[sk] = node
        _save(ctx, st)
    rows = []
    for k in [x for x in (node.get('keys') or []) if x in goods()]:
        info = _info(k)
        price = price_of(k, 'trader')
        rows.append({
            'id': _int(k, 0),
            'itemId': info['itemId'],
            'name': info['name'],
            'dsc': info['dsc'],
            'unit': info['unit'],
            # `SalesLayer.lua:344-442` 读 name/dsc/buyPrice/salePrice；:608 读 status==0 才显示
            'buyPrice': price,
            'salePrice': max(1, price // 2),
            'priceUnit': info['priceUnit'] if info['buyPrice'] > 0 else MONEY,
            'status': 0,
            'count': 1,
        })
    return rows


def _ep_get_devote_list(ctx, st):
    """`get_devote_list` —— `SalesLayer.lua:631-651` 读 `data.list` + `data.yuanbao`。

    `type`：1=师门商人（`RoleObserveModel.lua:1220` TYPE_TEACHER）2=游侠/地图商人
    （`RoleObserveModel.lua:768` TYPE_MAP_SELLER）。货币默认贡献点（`SalesLayer.lua:75`）。
    """
    typ = _s(ctx.param('type') or ctx.param('dtype')) or '1'
    menpai = _s(ctx.param('menpai')) or _s(ctx.param('familyId')) or 'youxia'
    rows = _devote_rows(ctx, st, typ, menpai)
    # ★★ 2026-10-03 修「师门刷新要花全部元宝」真凶：这里原来把**玩家元宝余额**
    #   原样塞进 `yuanbao` 字段，而客户端 `SalesLayer:635 setTextDesc(data.yuanbao)`
    #   把它当**刷新价**显示 ⇒ 面板显示"或花费198089元宝"（198089=客户当时的余额）。
    #   老板定案：刷新 0 元宝（0 点自动刷新或 0 元宝）。
    return ctx.ok({'list': rows, 'yuanbao': 0},
                  '★ 贡献商人(type=%s, %s)：%d 件（shoplist 真道具，刷新 0 元宝）'
                  % (typ, menpai, len(rows)))


def _ep_get_devote_list_by_yuanbao(ctx, st):
    """`get_devote_list_by_yuanbao` —— `SalesLayer.lua:657-690` 元宝刷新后同样读
    `data.list` + `data.yuanbao`。"""
    typ = _s(ctx.param('type') or ctx.param('dtype')) or '1'
    menpai = _s(ctx.param('menpai')) or 'youxia'
    oid = _s(ctx.param('order_id'))
    # ★ 2026-10-03 老板定案：元宝刷新也改 **0 元宝**（原来扣 20）
    d = st.setdefault('devote', {})
    sk = '%s|%s' % (typ, menpai)
    d.pop(sk, None)
    rows = _devote_rows(ctx, st, typ, menpai)
    return ctx.ok({'list': rows, 'yuanbao': 0, 'order_id': oid},
                  '★ 元宝刷新商人(type=%s, %s)：%d 件（0 元宝）' % (typ, menpai, len(rows)))


# ===========================================================================
# 路由
# ===========================================================================
_HANDLERS = {
    'black_market_store': _ep_black_market_store,
    'buy_black_goods': _ep_buy_black_goods,
    'get_mingbi_list': _ep_get_mingbi_list,
    'buy_mingbi_goods': _ep_buy_mingbi_goods,
    'get_merit_goods': _ep_get_merit_goods,
    'buy_merit_goods': _ep_buy_merit_goods,
    'get_sect_exchangeStore': _ep_get_sect_exchangeStore,
    'buy_sect_exchangeGoods': _ep_buy_sect_exchangeGoods,
    'get_sect_merit_store': _ep_get_sect_merit_store,
    'trader_store': _ep_trader_store,
    'buy_trader_goods': _ep_buy_trader_goods,
    'buy_matters': _ep_buy_matters,
    'matters_shop_info': _ep_matters_shop_info,
    'get_prestige_goods': _ep_get_prestige_goods,
    'buy_prestige_goods': _ep_buy_prestige_goods,
    'buy_npc_goods': _ep_buy_npc_goods,
    'del_buy_npc_time': _ep_del_buy_npc_time,
    'get_storage_box': _ep_get_storage_box,
    'buy_storage_box': _ep_buy_storage_box,
    'buy_mask_piece_2': _ep_buy_mask_piece_2,
    'get_ckitems_list': _ep_get_ckitems_list,
    'get_order_id': _ep_get_order_id,
    'rollback_order_status': _ep_rollback_order_status,
    'get_reward_2': _ep_get_reward_2,
    'get_applestore_list': _ep_applestore_list,
    'get_jhms_desc': _ep_get_jhms_desc,
    'get_jhms_reward': _ep_get_jhms_reward,
    'get_goods': _ep_get_goods,
    'get_goods_2': _ep_get_goods_2,
    'check_pay_sign': _ep_check_pay_sign,
    'buy_goods_3': _ep_buy_goods_3,
    'check_fail_transaction_2': _ep_check_fail_transaction_2,
    'get_buy_order_id': _ep_get_buy_order_id,
    'get_mask_list': _ep_get_mask_list,
    'refresh_mask_list': _ep_refresh_mask_list,
    'get_npc_list': _ep_get_npc_list,
    'add_npc_record': _ep_add_npc_record,
    'get_devote_list': _ep_get_devote_list,
    'get_devote_list_by_yuanbao': _ep_get_devote_list_by_yuanbao,
}


def handle(ctx):
    ep = ctx.endpoint
    fn = _HANDLERS.get(ep)
    if fn is None:
        return None
    st = _st(ctx)
    return fn(ctx, st)
