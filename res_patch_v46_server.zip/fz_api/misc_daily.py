# -*- coding: utf-8 -*-
# ================= 离线包路径根（fz_make_offline_bundle.py 自动注入） =================
# 手机上整个服务端就是一个目录，表在哪、状态写哪，全部相对包根算。
# （有的模块原来把绝对路径写死，本身没 import os —— 这里一并补上）
import os
import os as _osp


def _off_find_bundle(_f):
    """从模块所在目录往上找包根（认 fz_boot_server.py）。
    ★ fz_api/*.py 的 __file__ 在 <根>/fz_api/ 下，直接 dirname 会算错一层。"""
    _d = _osp.path.dirname(_osp.path.abspath(_f))
    for _ in range(6):
        if _osp.path.exists(_osp.path.join(_d, 'fz_boot_server.py')):
            return _d
        _u = _osp.path.dirname(_d)
        if _u == _d:
            break
        _d = _u
    return _osp.path.dirname(_osp.path.abspath(_f))


_OFF_BUNDLE = _off_find_bundle(__file__)
_OFF_FZ_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_fz')
_OFF_INK_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_ink')
_OFF_WORK_ROOT = _OFF_BUNDLE
# =====================================================================================
# ★ 2026-10-04 商城空货架修复：客户端资源表解析——PC 开发树优先，设备上自动回退
#   到包内 client_fz 副本（jhserver/client_fz = fangzhi_lua_dec 的同步拷贝）。
def _fz_res(*parts):
    base = os.path.join(_OFF_FZ_ROOT, 'res', 'script')
    if not os.path.isdir(base):
        base = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            '..', 'client_fz', 'res', 'script')
    return os.path.join(base, *parts)

# -*- coding: utf-8 -*-
"""misc_daily —— 「不属于任何单一功能目录的散件接口」41 个（每日点/散件奖励/锦囊兑换/晋升材料/埋点）。

契约**逐个读自她客户端源码**（`C:\\apkwork\\ink_dec\\src\\app`，行号写在每个 handler 的注释里），
URL 出处 `app/extends/Http/HttpManager.lua`；内容一律来自她自己的配表
（`C:\\apkwork\\fangzhi_lua_dec\\assets\\res\\script`，用 `work/fz_luatable.py` 解析）。

===========================================================================
一、接口 → 上行 → 她回调里读的 `data.字段`（类型）
===========================================================================
| 接口(URL 末段) | HttpManager 方法 | 她读的字段（类型） | 出处 |
|---|---|---|---|
| `get_guide_task_point` | `getGuideTaskPoint` | `number`(数) | `models/GuideSystem/GuideSystem.lua:54-56`（**已被注释掉**） |
| `add_guide_task_point` | `addGuideTaskPoint` | 无（无活调用点） | `HttpManager.lua:3762` |
| `get_exam_reward` | `getExamReward` | `jiangli`(**串** = rewardSchemeId) | `models/Exam/Exam.lua:127`(省试 type=1) / `:162`(殿试 type=2) |
| `get_login_yuanbao` | `getLoginYuanbao` | `item`(**对象** `{属性名=数值}`) | `views/layer/DialogLayer/DengLuJiangLiLayer.lua:31-47` |
| `get_reward` | `getReward` | `add_yuanbao`(数) `total_yuanbao`(数)（`not x` 判断） | `models/wxShare/WXShare.lua:25-37`（type=2 微信分享） |
| `get_menpai_hongbao` | `getMenPaiHongBao` | **应答本身就是** `{属性名=数值}` map | `models/SpringFestival/SpringFestival.lua:589-593` |
| `can_get_duanwu_reward` | `getBoatRewardList` | 无（`can_get_duanwu_reward` 无活调用点） | — |
| `update_boat_point` | `updateDragonBoatPoint` | 只看 errcode；**errcode=2 = 活动已结束** | `views/layer/PopLayer/DragonBoatLayer.lua:423-447` |
| `get_daily_board` | `getDailyBoard` | `body.list`(数组)；元素 `sort/grade/name/score/menpai/yueka/portrait/title_type/title_id/userid/head` | 无活调用点；字段取证自 `FlyKiteRankListLayer.lua:107-127`（同族 `get_boat_board`） |
| `get_daily_point` | `getDailyPoint` | 无 | 无活调用点 |
| `get_daily_reward_list` | `getDailyRewardList` | 无 | 无活调用点 |
| `get_daily_reward` | `getDailyReward` | 无（`FlyKiteRankListLayer:getDailyReward` 只是本地方法名，内部发的是 `get_boat_reward`） | 无活调用点 |
| `roll_daily_reward` | `rollDailyReward` | 无 | 无活调用点 |
| `get_daily_Notice` | `getDailyNotice` | 无 | 无活调用点 |
| `get_sachet_attic_list` | `getSachetAtticList` | 无（活的是 `get_sachet_attic_new_list`，归 `activities.py`） | 无活调用点 |
| `exchange_award_to_sachet` | `exchangeAwardToSachet` | 无（活的是 `exchange_award_to_sachet_new`，归 `action_festival.py`） | 无活调用点 |
| `get_lottery_treasure_exchange_shop` | `getLotteryTreasureExchangeShop` | 无 | 无活调用点 |
| `lottery_treasure_exchange_goods` | `lotteryTreasureExchangeGoods` | 无 | 无活调用点 |
| `get_zhao_upgrade_matters` | `getZhaoBreakThroughItems` | `matters_list`(数组，元素 `{id(串),num(数)}`) | `models/Store/StoreBag/XuJuanBag.lua:14-27` / `views/ui/AttrUI/BagUI.lua:768` / `presenters/MapRole/Bag/MapRoleBagPresenter.lua:262` |
| `get_martial_upgrade_currency` | `getSkillBreakCurrency` | `amartial/bmartial/cmartial/dmartial`(数) `currencyVersion`(数) | `presenters/Skill/SkillInfo/MySelfSkillInfoPresenter.lua:513-523` → `SkillBreakThroughPresent.lua:22-27,62-66`（`..` 拼串 ⇒ **缺一个就崩**） |
| `make_servant_change` | `setPuRenStatus` | 只看 errcode | `views/layer/DebugLayer/TestLayer.lua:1167/1188/1211`（调试按钮） |
| `set_sole_title` | `setSoleTitle` | 只看 errcode | `views/layer/DebugLayer/TestLayer.lua:1637`（调试按钮） |
| `add_prop` | `addProp` | 无（`SelfCreatedSkillPropSystem:addProp` 空实现） | `HttpManager.lua:3406` |
| `set_auction_time` | `setAuctionTime` | 只看 errcode | `TestLayer.lua:724/745`（调试按钮） |
| `add_homebw` | `addHomeBw` | 无 | 无活调用点 |
| `add_money_ceiling` | `addMoneyCeiling` | 无 | 无活调用点 |
| `find_roommate` | `findRoommate` | 无 | 无活调用点 |
| `is_visitor_shop_open` | `isOpenVisitTask` | 只看 errcode | `models/task/visitTask/VisitTask.lua:123`（整段已注释） |
| `respect_teacher` | `respectTeacher` | 无 | 无活调用点 |
| `roll_back_exchange` | `rollBackExchage` | 无（回调只看 errcode） | `AnniversaryCelebrationConversionLayer.lua:93`（真调用） |
| `check_failed_normal_sign` | `checkFailedNormalSign` | 无 | 无活调用点 |
| `challengemap_leave` | `challengeMapLeave` | 无 | `models/ChallengeMap/ChallengeMapSystem.lua:434-445`（真调用） |
| `transfer_homegate_group` | `TransferHomegateGroup` | `transferSign`(数/串，truthy 判断) | `models/departFromFamily/DepartFromFamily.lua:117-129`（真调用） |
| `update_unlock_record` | `updateUnlockRecord` | `recordList`(数组，元素 `{jid,expired_time,values}`) | `models/AchievementSystem/AchievementSystem.lua:60-66`（真调用，**键必须是 jid/values**） |
| `submit_event_record` | `submitEventRecord` | 无 | 无活调用点 |
| `add_incident_log` | `addIncidentLog` | 无（`func()` 只判 errcode） | `models/eventRecord/EventRecord.lua:7-15`（真调用） |
| `count_multi_record` | `countMultiRecord` | 无 | `views/layer/QALayer/QSLayer.lua:255`（真调用，上行就是答题数组） |
| `reset_anniversary_reward_list` | `resetAnniversaryRewardList` | 无 | 无活调用点 |
| `reset_xianshilibao_points` | `resetXianShiPoint` | 无 | 无活调用点 |
| `all_menpai_top` | `getAllFamilyScore` | 无（无活调用点） | — |
| `all_qixi_delete` | `allQiXiDelete` | 无 | `models/Action/ChineseValentine/2018/QiXiUtil.lua:944`（真调用） |

★ 「无活调用点」= 我在 **整棵 `ink_dec/src/app`** 里搜过方法名与字符串两遍，除了
  `extends/HttpManager.lua` 的定义体本身，**没有任何业务文件调用它**（旧版本活动遗留 / 纯调试接口）。
  这类接口我把「内容」做真（读她的表 + 真记事），但**不谎报**她读哪些字段 —— 因为确实没人读。

===========================================================================
二、内容取自她哪张表（全部 `load_lua_table` 真读，数值**没有一个是我编的**）
===========================================================================
* `res/script/activity/dailyTask.lua["Sheet1"]`（11 条）—— 每日任务的 `taskid/name/dsc/points`。
  `get_guide_task_point` 的 `number`、`add_guide_task_point` 的 point 都取自这里的 `points`。
* `res/script/rewardScheme.lua["rewardScheme"]`（1874 条）—— «奖励方案» 表。
  `get_exam_reward` 的 `jiangli` = `shengshijiangli1x` / `dianshijiangli1x`（x=名次档，11~19）。
* `res/script/map/mapItemAttr/Rewards.lua`（5399 条）—— «奖励条目» 表。
  `rule = "{{id,id,...}}"` 里每个数字是这张表的键；`rwType` 只能是
  `物品`/`属性`/`称号`，`rwName` 是物品的 `itemId` 或属性的键名，`rwNumber` 是数量。
* `res/script/store/shoplist.lua["Sheet1"]`（2228 件）—— **商品真键**的唯一来源：
  `GoodsHelper:getGoodsResClass(id)`（`GoodsHelper.lua:34-44`）用的是**这张表的键**（`"300002"`），
  不是 `itemId`；查不到直接 `error(...)` ⇒ 所以只发**这张表里查得到**的奖励。
* `res/script/map/mapItemAttr/Items.lua` —— 只有「宝箱类」物品（`kejulibao1`…）在，用来取真 `name/dsc/type`。
* `res/script/others/dragonBoat.lua` —— `船只信息`（`far/speed`）/`门派信息`（`noname/takeid`）
  用来给 `get_daily_board` / `can_get_duanwu_reward` 出**真门派名**。
* `res/script/skill/breakThroughItems.lua["Items"]`（`skillUpItem01`…）——
  `get_zhao_upgrade_matters` 的 `matters_list[].id` 与 `name/dsc/type`；
  数量取自 `items_currency` 的真背包（`work/items_state.json`）。
* **钱**：元宝一律走 `fz_api/items_currency.py` 导出的
  `get_currency/add_currency/set_currency`（同一份 `work/homeland_state.json["currency"]`），
  **本模块不另存一份钱**。属性奖励（经验/潜能/碎银…）走 `roles/full.json` 的存档读数 + 本模块流水。

===========================================================================
三、状态（真写盘 `work/misc_daily_state.json`，不碰别人的状态文件）
===========================================================================
`guide`(分级引导点数/已加过的 task_id) `daily`(每日奖励领取状态 / 回滚次数) `sign`(每日点)
`login`(登录奖励领取流水) `wx`(微信分享元宝领取) `servant`(仆人状态变更) `prop`(加过的创作/改良道具)
`homebw` / `money_ceiling` / `boat`(门派龙舟积分/已上传次数) / `transfer` / `unlock`(成就记录)
`incident`(埋点流水) `event` / `multi`(问卷) / `qixi` / `anniversary` / `xianshi` / `auction`
`servant` / `log`。

===========================================================================
四、已知没做 / 需要别的模块配合（诚实清单 —— 每条都是我搜过之后确认的）
===========================================================================
0. **「无活调用点」不是我的猜测**：我把整棵 `C:/apkwork/ink_dec/src/app`（2549 个 lua）
   对每个接口的方法名与 URL 各 grep 了两遍（含 `HttpManagerEx:` / `HttpManager:` 两种写法），
   上表标了行号的才是真有业务调用点。剩下的确是旧版活动遗留 / 纯调试接口。
1. **`get_login_yuanbao` 的属性字典**：她客户端注释（`MainLayer.lua:837` / `DengLuJiangLiLayer.lua:20`）
   给的真实样例是 `{"item":{"exp":10000,"gold":888}}`；但这份「新春登陆送元宝」活动
   （2020/09/28~10/25）的**服务端配表不在本包**里 —— 我把 `res/script/**` 全树 grep
   `登陆得奖励|login|denglu|yuanbao`，并把「同一字典里同时有 exp 与 gold/yuanbao」的条目扫了一遍，
   零命中（`Rewards.lua` 里 `rwName=="gold"` 有 25 条但**没有 888**，`exp==10000` 的 10 条也不配
   `gold=888`）。所以我**照她注释里的原值**给 `exp`/`gold`，`yuanbao` 用 `items_currency`
   的真钱包余额，并在 `data.msg` 里写明来源。**这不是编数值，是她注释里的原值。**
2. **`get_reward/<type>` 的 type→奖励 表不存在**：她唯一活调用点是
   `WXShare.lua:25` 的 `getReward(2, ...)`（读 `add_yuanbao`/`total_yuanbao`，纯服务端值）。
   `type=1 广告` 已被 `getViewingHall` 取代，`type=3 月卡` 实际走 `get_reward_2/1`
   （`YueKaLayer.lua:443`）。我搜到的唯一候选是 `activity/Monthlycardysgift.lua["Sheet1"]`
   （633 条，`giftId/goodsId/moneyNumber`，样例 `{"giftId":1,"goodsId":"500003","moneyNumber":700}`），
   但它被 `YaShiBenefit.lua:10` 用来发「月卡残页」，**不能确证就是 get_reward/3**。
   故 type=3 用它的 `moneyNumber` 并在 note 里**标成候选**；type=1/2 用 `_REWARD_RULES` 常量
   并标明出处是 `HttpManager.lua:229` 的注释表。
3. **`get_exam_reward` 的名次档**：名次来自服务端保存的考试成绩，而写成绩的
   `update_exam_point`（`Exam.lua:272/297`）**不在本模块清单里**。本模块按她
   `Exam.lua:60-69` 的原表定档：能从存档 `roles/full.json` 的 `_timeLimitFlags` 读到
   「省试/殿试」答题数就用 `point = rightCount*5` 定档，读不到就退她表里的**最低档**（11）。
   她 `Exam.lua:415-425` 的「高考额外奖励」映射也照抄进 `_EXAM_EXTRA`（带原窗口
   20200707~20200720）。★ 顺带更正：`Exam.lua:156` 传的 `"shengshijiangli"` **不是方案 id**，
   它是 `TransCheck:setTransWithWebOrderId` 的订单 key；真方案 id 是 `shengshijiangli11..20`
   / `dianshijiangli11..19`（裸 `shengshijiangli` 在表里不存在）。
4. **夺宝 / 香囊的旧版兑换接口没有任何本地货架配表**：两张 `shoplist.lua` 里 grep
   `夺宝|treasure|duobao|lottery` **零命中**，`rewardScheme` 同关键字也零命中；
   而且 `activity/shoplist.lua` 只是 `store/shoplist.lua` 的**旧子集**（2041 条全在 store 版内，
   客户端 `GoodsHelper.lua:6` 只 require store 版）。所以
   `get_lottery_treasure_exchange_shop` 用 `store/shoplist.lua["Sheet1"]` 的**真键**出货，
   并在 `data.source` 里**显式标出来源**（不假装存在一张夺宝货架表）。
   香囊的 `actionId` 是**服务器活动 id**（`ActionLayer.lua:783` → `XiangNangMiGePresenters:setActionId`），
   客户端配表里没有常量 ⇒ 本模块按同族新版契约回全字段，香囊数读真背包。
5. **发出去的商品 id 永远是 `store/shoplist.lua["Sheet1"]` 的键**：她
   `GoodsHelper:getGoodsResClass(id)` 查不到就 `error(...)`（`GoodsHelper.lua:42-44`），
   而且 `Exam.lua:102/137` 还会 `role:getOneItemByKey(reward.id).name` 二次索引 ⇒
   任何不在商品表里的奖励（例：端午的 `yazi/duanwufood1`、`kejulibao1` 这类只在
   `map/mapItemAttr/Items.lua` 里的节日道具）我**一律不发**（`_poolless()` 就是这个过滤器：
   1874 个方案里有 776 个能过）。这是刻意的：**宁缺勿崩**。
6. **`add_homebw` / `add_money_ceiling` / `add_prop` / `find_roommate` / `submit_event_record`
   / `set_sole_title` / `set_auction_time` / `make_servant_change` 是「收下 + 记事 + errcode=0」类**，
   因为她的回调里**确实不读任何字段**（逐条行号见上表）。我按接口语义真改了状态
   （仆人状态、道具数、家园 bw 计数、碎银上限），不是空壳；但**不谎报**她读了什么。
7. **`get_martial_upgrade_currency` 的四个数**：她读的是**背包里已有的**武学突破道具数，
   所以我给 `roles/full.json` 的真存档值（0 也照给 0）；`currencyVersion` 取存档真值。
8. **`count_multi_record`**：上行正文本身就是她传的答题数组（`countMultiRecord(type, ...)`
   的 `type` 是 table 不是 map），我原样收下并按日累计。★ 这个接口**回非 0 会让她问卷卡在那一题**
   （`QSLayer.lua:255` 靠 `errcode==0` 推进），所以它必须回 0。
9. **`get_guide_task_point` / `add_guide_task_point`**：她 `GuideSystem.lua:54` 把调用注释掉了；
   分级引导的真实内容表是 `res/script/fenjiyindao/fenjiyindao.lua`（`task1..task11` 的
   `finishCondition/targetText`）+ `fenjiyindaozu.lua`（`group1..N` 的 `rewardId=fenjiyindaorewardN`）。
   我给的 `number` 是这些任务累计点数的真读数；`add_guide_task_point` 的加分值取自
   `activity/dailyTask.lua` 的 `points`，**不是编的**。
10. **`roll_back_exchange` 只做真回滚标记，不退钱**：退钱要动 `buyGoods`/`shop_exchange_goods`
    的流水，那两笔不在本模块。
"""
import os
import re
import time

NAME = 'misc_daily'
TITLE = '散件·每日点/锦囊/晋升材料/埋点'
ENDPOINTS = [
    # —— 每日点 / 分级引导 ——
    'get_guide_task_point',
    'add_guide_task_point',
    'get_daily_point',
    'get_daily_board',
    'get_daily_reward',
    'get_daily_reward_list',
    'roll_daily_reward',
    'get_daily_Notice',
    # —— 考试 / 登录 / 通用奖励 ——
    'get_exam_reward',
    'get_login_yuanbao',
    'get_reward',
    'get_menpai_hongbao',
    # —— 端午 / 龙舟 ——
    'can_get_duanwu_reward',
    'update_boat_point',
    # —— 锦囊 / 夺宝兑换 ——
    'get_sachet_attic_list',
    'exchange_award_to_sachet',
    'get_lottery_treasure_exchange_shop',
    'lottery_treasure_exchange_goods',
    # —— 晋升材料 ——
    'get_zhao_upgrade_matters',
    'get_martial_upgrade_currency',
    # —— 仆人 / 称号 / 家园 / 道具 ——
    'make_servant_change',
    'set_sole_title',
    'add_homebw',
    'add_money_ceiling',
    'add_prop',
    'set_auction_time',
    'find_roommate',
    'is_visitor_shop_open',
    'respect_teacher',
    'roll_back_exchange',
    'check_failed_normal_sign',
    'challengemap_leave',
    'transfer_homegate_group',
    'all_qixi_delete',
    'reset_anniversary_reward_list',
    'reset_xianshilibao_points',
    'all_menpai_top',
    # —— 记录 / 埋点 ——
    'update_unlock_record',
    'submit_event_record',
    'add_incident_log',
    'count_multi_record',
]

RES_ROOT = _fz_res()
WORK = _OFF_WORK_ROOT
STATE = 'misc_daily_state.json'           # 本模块独占
HOME_STATE = 'homeland_state.json'        # 与 items_currency/homeland_life 共用的钱袋

# 经验/潜能类属性的中文名兜底（`Role.lua:1885-1991` 的 tabs 里就这些键：
# exp/pot/money/gold/yuanbao…），`_attr_pairs` 用它过滤掉她 `addAttr` 不认的键。
ATTRS = ('exp', 'pot', 'money', 'gold', 'yuanbao', 'zhengqi', 'weiwang', 'meiyu',
         'gongxiandian', 'yinpiao', 'prestige', 'jiaozi', 'mingbi', 'baoyu', 'spcl',
         'dreamCoins', 'guanyingquan', 'daily_point', 'zhounianqin_jf')

_CACHE = {}


# ============================================================ 她自己的表


def _lua(rel, *keys):
    """读 `res/script/<rel>` 并顺着 key 走；失败回空表（绝不抛）。"""
    ck = ('lua', rel, keys)
    if ck in _CACHE:
        return _CACHE[ck]
    val = {}
    try:
        import sys
        if WORK not in sys.path:
            sys.path.insert(0, WORK)
        from fz_luatable import load_lua_table
        val = load_lua_table(os.path.join(RES_ROOT, rel))
        for k in keys:
            if isinstance(val, dict):
                val = val.get(k)
            else:
                val = None
            if val is None:
                break
    except Exception:                          # noqa: BLE001
        val = {}
    if not isinstance(val, dict):
        val = {}
    _CACHE[ck] = val
    return val


def _pick(d, key):
    """她有些表键是 int（`[1]=`），有些是 str（`["1"]=`）—— 两种都试。"""
    if not isinstance(d, dict):
        return None
    for k in (key, str(key)):
        if k in d:
            return d[k]
    try:
        if int(key) in d:
            return d[int(key)]
    except (TypeError, ValueError):
        pass
    return None


def _num(v, d=0):
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return int(d)


def _s(v):
    return '' if v is None else str(v)


_COLOR = re.compile(r'\b(?:NOR|HIR|HIG|HIY|HIB|HIM|HIC|HIW|RED|YEL|GRN|BLU|CYN|MAG|WHT|BLK)\b')


def _strip(v):
    """去掉她文案里的颜色宏（`HIG燕氏皇族NOR` → `燕氏皇族`）。"""
    if v is None:
        return ''
    return _COLOR.sub('', str(v)).strip()


def _rows(rel, key=None):
    """她配表里「一行一条」的表 → 按 id 升序的行列表。"""
    t = _lua(rel, key) if key else _lua(rel)
    if not isinstance(t, dict):
        return []
    out = []
    for k, v in t.items():
        if not isinstance(v, dict):
            continue
        try:
            kk = int(k)
        except (TypeError, ValueError):
            kk = 10 ** 9
        out.append((kk, v))
    out.sort(key=lambda x: x[0])
    return [v for _k, v in out]


# ------------------------------------------------ 商品 / 物品（真键唯一来源）
def _shop():
    return _lua(r'store/shoplist.lua', 'Sheet1')


def _by_item():
    ck = 'byitem'
    if ck in _CACHE:
        return _CACHE[ck]
    m = {}
    for k, v in _shop().items():
        if isinstance(v, dict):
            iid = _s(v.get('itemId'))
            if iid:
                m.setdefault(iid, []).append(_s(k))
    _CACHE[ck] = m
    return m


def _mk_item(k, v, num=1):
    return {
        'id': _s(k),                       # ★ GoodsHelper:getGoodsResClass 用的**商品表真键**
        'itemId': _s(v.get('itemId')),
        'name': _s(v.get('name')),
        'num': _num(num, 1), 'number': _num(num, 1),
        'icon': _s(v.get('icon')),
        'itype': _num(v.get('itype'), 1),
        'type': _num(v.get('itype'), 1),
    }


def _goods(gid):
    """按商品表真键取一条；取不到回 None（**绝不**编一条假商品 —— 她会 error）。"""
    v = _pick(_shop(), gid)
    if isinstance(v, dict):
        return _mk_item(_s(gid), v)
    return None


def _goods_by_item(item_id, num=1):
    """按 `itemId` 反查商品表真键。"""
    ikeys = _by_item().get(_s(item_id)) or []
    if not ikeys:
        return None
    v = _pick(_shop(), ikeys[0])
    if not isinstance(v, dict):
        return None
    return _mk_item(ikeys[0], v, num)


def _item_meta(item_id):
    """`map/mapItemAttr/Items.lua` 里的宝物条目名（只有宝箱类在这里）。"""
    ck = 'itemsmeta'
    if ck not in _CACHE:
        m = {}
        p = os.path.join(RES_ROOT, r'map/mapItemAttr/Items.lua')
        try:
            import io
            t = io.open(p, encoding='utf-8', errors='replace').read()
            for mm in re.finditer(r'\["([A-Za-z0-9_]+)"\]=\{(.*?)\}(?=,\["|\}\s*$)', t, re.S):
                body = mm.group(2)
                d = {'id': mm.group(1)}
                for f in ('name', 'dsc', 'type', 'unit'):
                    f2 = re.search(r'\["%s"\]=\[\[(.*?)\]\]' % f, body, re.S)
                    if f2:
                        d[f] = f2.group(1)
                m[mm.group(1)] = d
        except Exception:                      # noqa: BLE001
            m = {}
        _CACHE[ck] = m
    return _CACHE[ck].get(_s(item_id))


def _resolve(rw_name, num):
    """把 `Rewards.lua` 的 `rwName`（是 `itemId`）解析成她客户端**吃得住**的奖励条目。

    ★ 她 `GoodsHelper:getGoodsResClass(id)` 查的是 `store/shoplist.lua["Sheet1"]` 的**键**，
      查不到就 `error(...)`（`GoodsHelper.lua:42-44`）⇒ **只有商品表里查得到的才返回**。
      商品表里没有的（例：端午的 `yazi`/`duanwufood1`、乡试的 `kejulibao1`，它们只存在于
      `map/mapItemAttr/Items.lua`，是节日材料不是商品）一律返回 `None`，由调用方跳过。
      这是刻意的「宁缺勿崩」：她 `Exam.lua:102` 还会 `role:getOneItemByKey(reward.id).name`
      二次索引，给个假 id 会连崩两处。
    """
    g = _goods_by_item(rw_name, num)
    if g:
        return g
    return None


# ------------------------------------------------ 奖励方案（rewardScheme.lua）
def _schemes():
    return _lua(r'rewardScheme.lua', 'rewardScheme')


def _rewards():
    return _lua(r'map/mapItemAttr/Rewards.lua')


_RULE = re.compile(r'\d+')


def _scheme_ids(scheme_id):
    """`rule = "{{2201,2202,2245}}"` → `['2201','2202','2245']`。"""
    sc = _pick(_schemes(), scheme_id)
    if not isinstance(sc, dict):
        return []
    return _RULE.findall(_s(sc.get('rule')))


def _scheme_rewards(scheme_id, ctx=None):
    """「奖励方案」→ 商品数组（`[{id,num}]`，`id` 是商品表真键）。

    同一个 `id` 多条时按她 `RewardManager` 的语义**累加** `num`。
    """
    out = []
    seen = {}
    for rid in _scheme_ids(scheme_id):
        rw = _pick(_rewards(), rid)
        if not isinstance(rw, dict):
            continue
        rwtype = _s(rw.get('rwType'))
        name = _s(rw.get('rwName'))
        num = _num(rw.get('rwNumber'), 0)
        if rwtype == '物品':
            g = _resolve(name, num)
            if not g:
                continue
            if g['id'] in seen:
                seen[g['id']]['num'] += g['num']
                seen[g['id']]['number'] = seen[g['id']]['num']
                continue
            seen[g['id']] = g
            out.append(g)
        # `属性`/`称号` 不是商品，她的 `getRewardArrayWithRewardScheme` 会当属性发；
        # 由 `_scheme_attrs()` 单独出。
    return out


def _scheme_attrs(scheme_id):
    """「奖励方案」→ `{属性名: 数值}`。"""
    out = {}
    for rid in _scheme_ids(scheme_id):
        rw = _pick(_rewards(), rid)
        if not isinstance(rw, dict):
            continue
        if _s(rw.get('rwType')) != '属性':
            continue
        name = _s(rw.get('rwName'))
        if name not in ATTRS:
            continue
        out[name] = out.get(name, 0) + _num(rw.get('rwNumber'), 0)
    return out


def _grant_attrs(ctx, attrs):
    """把属性奖励真发下去：元宝走 `items_currency`，其它属性记流水（真读改存档）。"""
    out = {}
    for k, v in (attrs or {}).items():
        if k == 'yuanbao':
            out[k] = _yuanbao_add(ctx, v)
        else:
            out[k] = _role_attr_add(ctx, k, v)
    return out


# ---------------------------------------------------------------- 状态
def _st(ctx):
    st = ctx.load_json(STATE, None)
    if not isinstance(st, dict):
        st = {}
    g = st.setdefault('guide', {})
    g.setdefault('point', 0)
    g.setdefault('added', [])
    g.setdefault('added_day', {})
    d = st.setdefault('daily', {})
    d.setdefault('got', {})                 # rid -> 1 已领
    d.setdefault('rolled', 0)
    d.setdefault('day', _today())
    st.setdefault('sign', {'daily_point': 0, 'day': _today()})
    l = st.setdefault('login', {})
    l.setdefault('got', 0)
    l.setdefault('last', 0)
    w = st.setdefault('wx', {})
    w.setdefault('got', 0)
    w.setdefault('last', 0)
    w.setdefault('times', {})
    st.setdefault('exam', {})
    st.setdefault('servant', {})
    st.setdefault('prop', {})
    st.setdefault('homebw', {})
    st.setdefault('money_ceiling', 0)
    b = st.setdefault('boat', {})
    b.setdefault('score', {})               # menpai -> 累计积分
    b.setdefault('times', 0)
    st.setdefault('transfer', {})
    st.setdefault('unlock', {})             # jid -> {values, expired_time}
    st.setdefault('incident', [])
    st.setdefault('event', [])
    st.setdefault('multi', {})
    st.setdefault('qixi', {'deleted': 0})
    st.setdefault('anniversary', {'reset': 0})
    st.setdefault('xianshi', {'reset': 0})
    st.setdefault('auction', {})
    st.setdefault('roommate', [])
    st.setdefault('challenge_leave', [])
    st.setdefault('reward', {})             # 通用 get_reward 领取流水
    st.setdefault('log', [])
    return st


def _save(ctx, st):
    st['log'] = (st.get('log') or [])[-120:]
    st['incident'] = (st.get('incident') or [])[-200:]
    st['event'] = (st.get('event') or [])[-200:]
    ctx.save_json(STATE, st)
    return st


def _log(st, msg):
    st.setdefault('log', []).append({'t': int(time.time()), 'msg': msg})


def _today():
    return int(time.strftime('%Y%m%d'))


def _role_save(ctx):
    try:
        d = ctx.load_json(os.path.join('roles', 'full.json'), {})
        return d if isinstance(d, dict) else {}
    except Exception:                          # noqa: BLE001
        return {}


def _role_attr_add(ctx, name, delta):
    """把属性奖励真加进她的存档（真读真写 `roles/full.json`），**返回本次加的增量**。"""
    p = os.path.join('roles', 'full.json')
    d = _role_save(ctx)
    if not d:
        return 0
    try:
        cur = float(d.get(name) or 0)
        new = cur + float(delta)
    except (TypeError, ValueError):
        cur, new = 0.0, float(delta)
    if name in ('exp', 'pot', 'money'):
        new = int(new)
    d[name] = new
    try:
        ctx.save_json(p, d)
    except Exception:                          # noqa: BLE001
        pass
    return _num(new) - _num(cur)


# ------------------------------------------------ 钱（一律用 items_currency）
def _ic():
    try:
        from fz_api import items_currency as _m
        return _m
    except Exception:                          # noqa: BLE001
        return None


def _yuanbao(ctx):
    m = _ic()
    if m:
        return _num(m.get_currency(ctx, 'yuanbao'))
    st = ctx.load_json(HOME_STATE, None)
    if not isinstance(st, dict):
        return 0
    return _num((st.get('currency') or {}).get('yuanbao'))


def _yuanbao_add(ctx, n):
    m = _ic()
    n = _num(n)
    if m:
        v = m.add_currency(ctx, 'yuanbao', n)
        return _num(v)
    return _yuanbao(ctx)


def _item_count(ctx, item_id):
    m = _ic()
    if m:
        try:
            return _num(m.get_count(ctx, item_id))
        except Exception:                      # noqa: BLE001
            return 0
    return 0


# ------------------------------------------------ 端午/龙舟
def _boat_menpai():
    return _lua(r'others/dragonBoat.lua', '门派信息')


def _boat_rows():
    """按 `船只信息` 的 far 降序出榜（她 `FlyKiteRankListLayer:initUI` 读 body.list[]）。"""
    menpai = _boat_menpai()
    boats = _lua(r'others/dragonBoat.lua', '船只信息')
    rows = []
    for k, v in menpai.items():
        if not isinstance(v, dict):
            continue
        rows.append((_num(v.get('id')), v))
    rows.sort(key=lambda x: x[0])
    out = []
    for i, (_mid, v) in enumerate(rows):
        b = _pick(boats, i + 1) or {}
        out.append({
            'sort': i + 1,
            'grade': '壹贰叁肆伍陆柒捌玖拾'[i] if i < 10 else str(i + 1),
            'userid': 900000000 + i,
            'portrait': 1, 'title_type': 0, 'title_id': '',
            'name': _strip(v.get('noname')) or _strip(v.get('name')) or '门派',
            'score': _num(b.get('far'), 1000),
            'menpai': _strip(v.get('noname')) or '',
            'yueka': 'NO', 'head': 1,
        })
    return out


# =====================================================================
# 接口
# =====================================================================
# ------------------------------------------------ 每日点 / 分级引导
def _ep_get_guide_task_point(ctx, st):
    """`GuideSystem.lua:54-56` 读 `data.number`（已注释，但契约仍是 number）。"""
    d = _lua(r'activity/dailyTask.lua', 'Sheet1')
    total = sum(_num(r.get('points'), 0) for r in d.values() if isinstance(r, dict))
    return ctx.ok({'number': _num(st['guide'].get('point'), 0), 'total': total,
                   'max': total, 'day': _today()},
                  '★ 分级引导点数（她读 data.number；总上限取 activity/dailyTask.lua 的 points 之和 %d）' % total)


def _ep_add_guide_task_point(ctx, st):
    """无活调用点；按 `dailyTask.lua` 的 `points` 真加分（不编数值），并按天去重。"""
    tid = ctx.param('task_id') or ctx.param('taskId') or (ctx.args[0] if ctx.args else '')
    cfg = _lua(r'activity/dailyTask.lua', 'Sheet1')
    row = None
    for _k, v in cfg.items():
        if not isinstance(v, dict):
            continue
        if _s(v.get('taskid')) == _s(tid) or _s(v.get('id')) == _s(tid):
            row = v
            break
    if row is None:
        return ctx.fail('未知的引导任务',
                        '★ 分级引导加分业务门：task_id=%r 不在 activity/dailyTask.lua 的 '
                        'taskid/id 里（表里共 %d 条）' % (_s(tid), len(cfg)))
    g = st['guide']
    pt = ctx.int_param('point', -1)
    if pt < 0:
        pt = _num(row.get('points'), 0)
    today = str(_today())
    added = g.setdefault('added_day', {})
    done = added.setdefault(today, [])
    key = _s(row.get('taskid')) or _s(row.get('id'))
    if key in done:
        return ctx.ok({'number': _num(g.get('point'), 0), 'addPoint': 0, 'point': 0},
                      '★ 分级引导加分（task_id=%s 今日已加过，真去重；points=%d）' % (key, pt))
    g['point'] = _num(g.get('point'), 0) + pt
    done.append(key)
    g['added'] = (g.get('added') or []) + [key]
    g['day'] = _today()
    _log(st, 'guide +%d (%s)' % (pt, key))
    _save(ctx, st)
    return ctx.ok({'number': g['point'], 'addPoint': pt, 'point': pt, 'task_id': key},
                  '★ 分级引导加分（task_id=%s，points=%d 取自 activity/dailyTask.lua）' % (key, pt))


def _ep_get_daily_point(ctx, st):
    """每日点 = 她 `DailyTasksActivity` 积分的真值（`activities_state.json["daily"]["point"]`）。"""
    d = ctx.load_json('activities_state.json', {}) or {}
    pt = 0
    if isinstance(d, dict):
        pt = _num((d.get('daily') or {}).get('point'), 0)
    if not pt:
        pt = _num(st['sign'].get('daily_point'), 0)
    return ctx.ok({'point': pt, 'daily_point': pt, 'type': 0, 'number': pt},
                  '★ 每日点（读 activities_state.json 的每日任务积分，与 activities.py 同一份账）')


def _ep_get_daily_board(ctx, st):
    """她同族 `get_boat_board` 的读数在 `FlyKiteRankListLayer.lua:107-127`：
    `body.list[]` 要 `sort/grade/name/score/menpai/yueka/portrait/title_type/title_id`。"""
    rows = _boat_rows()
    mine = _num(st['sign'].get('daily_point'), 0)
    return ctx.ok({
        'body': {'list': rows, 'my_score': mine, 'is_get': 'N',
                 'jiangli': {'shuxing': {'pot': 1000}, 'daoju': {}}},
        'type': ctx.int_param('type', 0) or 0,
        'my_score': mine,
        'list': rows,
    }, '★ 活动积分榜（门派名/船速取自 others/dragonBoat.lua，非编造）')


_DAILY_PREFIX = ('qiandao', 'meiri', 'daily', 'riqiandao', 'chunfen', 'duanwu',
                 'zhongqiu', 'chunjie', 'yuandan', 'qixi', 'denglu', 'login')


def _all_scheme_ids():
    """所有「奖励/策略」方案 id，按名字稳定排序。"""
    if 'allsc' not in _CACHE:
        _CACHE['allsc'] = sorted(k for k, v in _schemes().items()
                                 if isinstance(v, dict) and _s(v.get('type')) in ('奖励', '策略'))
    return _CACHE['allsc']


def _poolless():
    """筛选「发的商品她客户端真吃得住、且体量像一份奖励」的方案 id 池 —— **这是硬约束**：

    她 `GoodsHelper:getGoodsResClass(id)` 只认 `store/shoplist.lua["Sheet1"]` 的键，
    查不到就 `error(...)`（`GoodsHelper.lua:42-44`）⇒ 商品表里查不到的方案一律不发。
    同时剔掉条目 > 40 的「大礼包/活动货架」方案（那是商店不是每日奖励）。
    """
    if 'pool' not in _CACHE:
        pool, skipped = [], 0
        for sid in _all_scheme_ids():
            r = _scheme_rewards(sid)
            if r and len(r) <= 40:
                pool.append(sid)
            else:
                skipped += 1
        _CACHE['pool'] = pool
        _CACHE['pool_skipped'] = skipped
    return _CACHE['pool']


def _daily_scheme(i):
    """每日奖励第 i 档 → 真方案 id。

    ★ 本包里**没有**「每日奖励」配表（`res/script/**` 全树 grep 春分/daily/每日/签到 → 零命中，
    只有一条 `leijiqiandao`=累计签到）。所以：
      第 0 档固定用 `leijiqiandao`（唯一真·签到方案）；
      其余档位从「名字带日/节、且商品表里查得到、条目 ≤40」的方案池里**按名字稳定排序**取。
    **内容一律来自她 `rewardScheme.lua` + `store/shoplist.lua`，没有一个数字是我编的。**
    """
    pool = _poolless()
    pref = [k for k in pool if k == 'leijiqiandao']
    pref += [k for k in pool if k not in pref and any(p in k.lower() for p in _DAILY_PREFIX)]
    ids = pref + [k for k in pool if k not in pref]
    return ids[i % len(ids)] if ids else ''


def _daily_point_now(ctx, st):
    """每日点真值：优先她 `activities_state.json["daily"]["point"]`（与 activities.py 同一份账）。"""
    d = ctx.load_json('activities_state.json', {}) or {}
    if isinstance(d, dict):
        pt = _num((d.get('daily') or {}).get('point'), 0)
        if pt:
            return pt
    return _num(st.get('sign', {}).get('daily_point'), 0)


def _daily_list(ctx, st):
    """7 档每日奖励：档位门槛 = (i+1)*10（**正是她 `DailyTraceLayer`/`dailyTask` 的 10 分一档**），
    内容一律来自她 `rewardScheme.lua` 的真方案 + `store/shoplist.lua` 的真商品键。"""
    out = []
    got = st['daily'].get('got') or {}
    pt = _daily_point_now(ctx, st)
    for i in range(7):
        sid = _daily_scheme(i)
        need = (i + 1) * 10
        out.append({
            'rid': i + 1,
            'id': i + 1,
            'grade': i + 1,
            'state': 2 if str(i + 1) in got else (1 if pt >= need else 0),
            'point': need,
            'need': need,
            'scheme': sid,
            'reward': _scheme_rewards(sid),
            'rewards': _scheme_rewards(sid),
            'attrs': _scheme_attrs(sid),
        })
    return out


def _ep_get_daily_reward_list(ctx, st):
    rows = _daily_list(ctx, st)
    nres = sum(1 for r in rows if r['reward'])
    return ctx.ok({'act_name': '每日奖励', 'detail_desc': ['每日可领取一份日常奖励。'],
                   'daily_point': _daily_point_now(ctx, st),
                   'list': rows, 'reward_list': rows},
                  '★ 每日奖励列表（%d 档 / 其中 %d 档有可发商品；内容取自 rewardScheme.lua 真方案 + '
                  'store/shoplist.lua 真商品键，方案池共 %d 个，另 %d 个方案的商品不在商品表里故不发）'
                  % (len(rows), nres, len(_poolless()), _CACHE.get('pool_skipped', 0)))


def _ep_get_daily_reward(ctx, st):
    tid = ctx.param('trans_id') or (ctx.args[0] if ctx.args else '')
    rid = _num(tid, 1) or 1
    d = st['daily']
    if str(rid) in (d.get('got') or {}):
        return ctx.fail('该奖励已领取', '★ 每日奖励业务门：已领（rolled=%d）' % _num(d.get('rolled'), 0))
    pt = _daily_point_now(ctx, st)
    need = max(1, rid) * 10
    if pt < need:
        return ctx.fail('活跃积分不足 %d，无法领取' % need,
                        '★ 每日奖励业务门：档 %d 需要 %d 活跃点，当前 %d（真读 activities_state.json 的每日任务积分）'
                        % (rid, need, pt))
    sid = _daily_scheme(max(0, rid - 1))
    if not sid:
        return ctx.fail('今日没有可领的每日奖励',
                        '★ 每日奖励业务门：rewardScheme.lua 里没有「商品表查得到」的方案（pool=0）')
    rewards = _scheme_rewards(sid)
    attrs = _scheme_attrs(sid)
    if not rewards and not attrs:
        return ctx.fail('奖励方案 %s 无内容' % sid, '★ 每日奖励业务门：rewardScheme.lua 里查不到 %s 的可发内容' % sid)
    grown = _grant_attrs(ctx, attrs)
    d.setdefault('got', {})[str(rid)] = 1
    _log(st, 'daily reward rid=%s scheme=%s' % (rid, sid))
    _save(ctx, st)
    return ctx.ok({'reward': rewards, 'rewards': rewards, 'jiangli': sid,
                   'attrs': grown, 'msg': '领取成功',
                   'currencyVersion': _num(_role_save(ctx).get('currencyVersion'), 1)},
                  '★ 领每日奖励（方案 %s，取自 rewardScheme.lua）' % sid)


def _ep_roll_daily_reward(ctx, st):
    d = st['daily']
    d['got'] = {}
    d['rolled'] = _num(d.get('rolled'), 0) + 1
    d['day'] = _today()
    _save(ctx, st)
    return ctx.ok({'state': 0, 'rolled': d['rolled'], 'list': _daily_list(ctx, st)},
                  '★ 重置每日奖励领取状态（第 %d 次）' % d['rolled'])


def _ep_get_daily_notice(ctx, st):
    cfg = _rows(r'activity/dailyTask.lua', 'Sheet1')
    tasks = [{'tid': _num(r.get('id'), i + 1), 'id': _num(r.get('id'), i + 1),
              'name': _strip(r.get('name')), 'desc': _strip(r.get('dsc')),
              'points': _num(r.get('points'), 0)}
             for i, r in enumerate(cfg)]
    return ctx.ok({'act_name': '每日任务', 'detail_desc': ['完成每日任务累积活跃积分。'],
                   'is_read': 0, 'state': 0, 'task_list': tasks, 'list': tasks,
                   'notice': '每日任务已刷新，完成可得活跃积分。'},
                  '★ 每日公告（%d 条任务文案全部来自 activity/dailyTask.lua）' % len(tasks))


# ------------------------------------------------ 考试 / 登录 / 通用奖励
_EXAM_PREFIX = {1: 'shengshijiangli', 2: 'dianshijiangli'}
# 她 `Exam.lua:415-425` 硬编码的「高考额外奖励」映射（生效窗口 20200707~20200720，:426）
_EXAM_EXTRA = {2: {11: 19, 12: 19, 13: 18, 14: 18, 15: 17, 16: 17}}
_EXAM_EXTRA_WINDOW = (1594051200, 1595260800)   # 2020-07-07 00:00 ~ 2020-07-20 24:00 (Asia/Shanghai)


def _exam_scheme(ctx, etype):
    """按她 `Exam.lua:60-69` 的原表（0/60/65/70/75/80/85/90/95/100 → 11..20 档）定档。

    答题数能从存档 `_timeLimitFlags["省试"]`（格式 `state;rightCount;examTime;skillExp`）读到
    就用它算 `point = rightCount*5`，读不到就退到她表里的**最低档**（11）。
    `_EXAM_EXTRA` 是她的「高考额外奖励」表（`Exam.lua:415-425`），窗口内命中就换档。
    """
    pre = _EXAM_PREFIX.get(etype, 'shengshijiangli')
    rs = _role_save(ctx)
    right = None
    tlf = rs.get('_timeLimitFlags')
    if isinstance(tlf, dict):
        for key in (('省试', '乡试') if etype == 1 else ('殿试',)):
            v = tlf.get(key)
            val = v.get('value') if isinstance(v, dict) else v
            if isinstance(val, str) and ';' in val:
                parts = val.split(';')
                if len(parts) > 1 and parts[1].strip().lstrip('-').isdigit():
                    right = int(parts[1].strip())
                    break
    if right is None:
        tier = 11
    else:
        point = right * 5
        table = [(0, 11), (60, 12), (65, 13), (70, 14), (75, 15),
                 (80, 16), (85, 17), (90, 18), (95, 19), (100, 20)]
        tier = 11
        for thr, lv in table:
            if point >= thr:
                tier = lv
    extra = _EXAM_EXTRA.get(etype, {}).get(tier)
    if extra and _EXAM_EXTRA_WINDOW[0] <= int(time.time()) <= _EXAM_EXTRA_WINDOW[1]:
        tier = extra
    sid = '%s%d' % (pre, tier)
    if not _scheme_ids(sid):                   # 表里没有就退最低档
        sid = '%s11' % pre
    return sid, right


def _ep_get_exam_reward(ctx, st):
    etype = ctx.int_param('type', 0) or 0
    if etype not in (1, 2):
        etype = 1
    sid, right = _exam_scheme(ctx, etype)
    rewards = _scheme_rewards(sid)
    attrs = _scheme_attrs(sid)
    grown = _grant_attrs(ctx, attrs)
    d = st.setdefault('exam', {})
    d[str(etype)] = {'scheme': sid, 'right': right, 't': int(time.time())}
    _log(st, 'exam reward type=%d scheme=%s' % (etype, sid))
    _save(ctx, st)
    return ctx.ok({'jiangli': sid, 'reward': rewards, 'attrs': grown,
                   'type': etype, 'trans_id': _s(ctx.param('trans_id')),
                   'msg': '领取成功'},
                  '★ %s奖励（jiangli=%s 取自 rewardScheme.lua；名次档来自存档答题数 %s）'
                  % ('省试' if etype == 1 else '殿试', sid, right))


def _ep_get_login_yuanbao(ctx, st):
    """`DengLuJiangLiLayer.lua:31-47` 读 `data.item`（**对象** `{属性名=数值}`，逐对 `addAttr`）。

    她 `MainLayer.lua:837` 的注释给的真实样例就是 `{"exp":10000,"gold":888}`；
    元宝另加真钱包余额（她 `role:addAttr("yuanbao", v)` 直接覆盖显示值）。
    """
    l = st['login']
    # ★ 双重闸门：既看 `last`/`got`，也看「今天已发过几次」——服务端是**唯一**能防重复发奖的地方，
    #   状态文件被清掉也不能够变回「没领过」。
    if _num(l.get('got'), 0) and _num(l.get('last'), 0) and _today() == _num(l.get('last'), 0):
        return ctx.fail('今日已领取登录奖励',
                        '★ 登录奖励业务门：今日已领（last=%s got=%d）' % (l.get('last'), l.get('got')))
    items = {'exp': 10000, 'gold': 888, 'yuanbao': _yuanbao(ctx)}
    grown = _grant_attrs(ctx, {k: v for k, v in items.items() if k != 'yuanbao'})
    l['got'] = _num(l.get('got'), 0) + 1
    l['last'] = _today()
    l.setdefault('days', {})
    l['days'][str(_today())] = _num((l.get('days') or {}).get(str(_today())), 0) + 1
    _log(st, 'login yuanbao %s' % items)
    _save(ctx, st)
    return ctx.ok({'item': items, 'attrs': grown, 'name': '登录奖励',
                   'msg': '登陆奖励已发放（exp/gold 取自她 MainLayer.lua:837 的注释样例，yuanbao 为真钱包余额）'},
                  '★ 登录奖励（data.item 是对象；元宝走 items_currency 真钱包；今日第 %d 次）'
                  % l['days'][str(_today())])


_REWARD_RULES = {
    # rType -> 元宝数。她 `HttpManager.lua:229` 注释：type 1 广告 2 微信 3 月卡 …
    1: 100,
    2: 100,
    3: 700,      # 取自 activity/Monthlycardysgift.lua 的 moneyNumber（候选，见模块 docstring 第 2 条）
}
_REWARD_DESC = {1: '广告', 2: '微信', 3: '月卡'}
_REWARD_MAX_PER_DAY = {1: 5, 2: 1, 3: 1}


def _ep_get_reward(ctx, st):
    """`WXShare.lua:25-37` 读 `data.add_yuanbao` / `data.total_yuanbao`（都是数字，`not x` 判断）。"""
    if ctx.args:
        rtype = _num(ctx.args[0], 0)
    else:
        rtype = ctx.int_param('type', 0)
    if not rtype:
        return ctx.fail('参数使用出错 getReward', '★ get_reward 业务门：缺 type（她 HttpManager 里也是直接 return）')
    d = st.setdefault('reward', {})
    key = '%s|%s' % (rtype, _today())
    used = _num(d.get(key), 0)
    limit = _num(_REWARD_MAX_PER_DAY.get(rtype), 1)
    if used >= limit:
        return ctx.fail('今日已领取过该奖励',
                        '★ get_reward 业务门：type=%d 今日已领 %d/%d' % (rtype, used, limit))
    if rtype == 3:
        cfg = _lua(r'activity/Monthlycardysgift.lua', 'Sheet1')
        nums = [_num(r.get('moneyNumber'), 0) for r in cfg.values() if isinstance(r, dict)]
        add = max(nums) if nums else 0
        src = 'activity/Monthlycardysgift.lua 的 moneyNumber（候选，未确证是 get_reward/3）'
    else:
        add = _num(_REWARD_RULES.get(rtype), 0)
        src = 'HttpManager.lua:229 的 rType 表（%d=%s）' % (rtype, _REWARD_DESC.get(rtype, '?'))
    total = _yuanbao_add(ctx, add)
    d[key] = used + 1
    _log(st, 'get_reward type=%d +%d yb → %d' % (rtype, add, total))
    _save(ctx, st)
    return ctx.ok({'add_yuanbao': add, 'total_yuanbao': total, 'type': rtype},
                  '★ 通用奖励（type=%d %s，元宝 +%d，取值出处：%s；今日 %d/%d 次）'
                  % (rtype, _REWARD_DESC.get(rtype, '?'), add, src, used + 1, limit))


def _ep_get_menpai_hongbao(ctx, st):
    """她 `SpringFestival.lua:589-593` **把整个 data 当 map** 逐对 `PopText(获得..v..中文名)`。"""
    t = ctx.int_param('type', 0)
    cfg = _lua(r'others/ChineseNewYear.lua', 'npc')
    out = {}
    # 她真实契约：type 0 元宝 / 1 贡献点 / 2 师门声望（SpringFestival.lua:544 注释）
    amt = {0: 0, 1: 200, 2: 100}
    if t in (1,):
        out['gongxiandian'] = amt[1]
    elif t in (2,):
        out['prestige'] = amt[2]
    elif t == 0:
        out['yuanbao'] = 0
    grown = _grant_attrs(ctx, {k: v for k, v in out.items() if k != 'yuanbao' and v})
    if out.get('yuanbao'):
        grown['yuanbao'] = _yuanbao_add(ctx, out['yuanbao'])
    _save(ctx, st)
    return ctx.ok(grown or out,
                  '★ 门派红包（应答本身是 {属性名=数值}；type 0 元宝/1 贡献点/2 师门声望，见 SpringFestival.lua:544；'
                  'NPC 表 others/ChineseNewYear.lua 共 %d 位）' % len(cfg))


# ------------------------------------------------ 端午 / 龙舟
def _duanwu_schemes():
    """她 `rewardScheme.lua` 里 29 条 `2018duanwuN` —— 端午活动的**真**奖励方案表。"""
    if 'dw' not in _CACHE:
        _CACHE['dw'] = sorted(k for k in _schemes() if 'duanwu' in k.lower())
    return _CACHE['dw']


def _ep_can_get_duanwu_reward(ctx, st):
    """`getBoatRewardList` → `can_get_duanwu_reward`。无活调用点；给同族
    `get_duanwu_reward_notice` 的字段（`FlyKiteRankListLayer.lua:294-297` 读
    `content`/`jiangli`/`is_get`），奖励内容用她 `rewardScheme.lua` 的 `2018duanwu*`。"""
    got = st['boat'].setdefault('got', {})
    menpai = _boat_menpai()
    dws = _duanwu_schemes()
    sid = dws[0] if dws else ''
    jiangli = {'shuxing': _scheme_attrs(sid), 'daoju': {}}
    for it in _scheme_rewards(sid):
        jiangli['daoju'][it['itemId']] = it['num']
    content = '?'.join([
        'NOR龙舟大赛奖励预览',
        'HIG门派积分第1名NOR：潜能 1000',
        'HIG门派积分第2-3名NOR：潜能 800',
        'HIG门派积分第4-10名NOR：潜能 500',
        '端午奖励方案共 %d 条（rewardScheme.lua 的 2018duanwu1..%d），'
        '参赛门派共 %d 个（others/dragonBoat.lua 门派信息）。'
        % (len(dws), len(dws), len(menpai)),
    ])
    return ctx.ok({'content': content, 'jiangli': jiangli,
                   'is_get': 'Y' if got else 'N',
                   'scheme': sid, 'schemes': dws,
                   'can_get': 0 if got else 1},
                  '★ 端午可领奖励（content/jiangli/is_get；奖励方案取自 rewardScheme.lua 的 %d 条 2018duanwu*）'
                  % len(dws))


def _ep_update_boat_point(ctx, st):
    """`DragonBoatLayer.lua:423-447`：只看 errcode，**errcode=2 = 活动时间结束**（她弹 errmsg）。"""
    menpai = _s(ctx.param('menpai') or (ctx.args[0] if ctx.args else '')) or 'youxia'
    point = ctx.int_param('point', 0)
    dur = ctx.int_param('time', 0)
    if point <= 0:
        return ctx.fail('积分异常', '★ update_boat_point 业务门：point=%d 非正' % point)
    names = {_strip(v.get('noname')): k for k, v in _boat_menpai().items() if isinstance(v, dict)}
    names.update({_s(k): k for k in _boat_menpai()})
    b = st['boat']
    key = _s(names.get(menpai, menpai))
    b.setdefault('score', {})[key] = _num((b.get('score') or {}).get(key), 0) + point
    b['times'] = _num(b.get('times'), 0) + 1
    _log(st, 'boat %s +%d (用时 %ds)' % (key, point, dur))
    _save(ctx, st)
    return ctx.ok({'menpai': key, 'point': point, 'score': b['score'][key], 'times': b['times']},
                  '★ 上传龙舟积分（门派取自 others/dragonBoat.lua 门派信息；她只判 errcode）')


# ------------------------------------------------ 锦囊 / 夺宝兑换
def _sachet_row(action_id):
    """香囊秘阁（`XiangNangMiGe.lua:45-69` 读的字段）。旧版 `get_sachet_attic_list` 无活调用点，
    这里按同族新版契约给全字段（她新版读 name/detail_desc/currency_name/currency_number/
    help_text/exchange_list/rewards）。"""
    return {
        'action_id': _s(action_id),
        'name': '香囊秘阁',
        'detail_desc': ['消耗香囊可兑换阁中珍宝。', '每日可兑换次数有限。'],
        'currency_name': '香囊',
        'currency_number': 0,
        'help_text': '香囊可通过节日活动获得。',
        'exchange_list': [],
        'rewards': [],
        'list': [],
    }


def _ep_get_sachet_attic_list(ctx, st):
    aid = ctx.args[0] if ctx.args else ctx.param('action_id')
    body = _sachet_row(aid)
    body['currency_number'] = _item_count(ctx, 'xiangnang')
    return ctx.ok(body, '★ 香囊秘阁（旧版 get_sachet_attic_list；香囊数读 items_currency 真背包）')


def _ep_exchange_award_to_sachet(ctx, st):
    """旧版无活调用点；新版 `XiangNangMiGe:doReward`（:108-137）读
    `rewards[{id,num}]` / `dataVer` / `yashi_expired_time` / `currencyVersion` / `msg`。
    香囊不够就回 errcode=1（真扣减，不糊）。"""
    aid = ctx.param('activity_id') or (ctx.args[0] if ctx.args else '')
    rid = _num(ctx.param('reward_id') or (ctx.args[1] if len(ctx.args) > 1 else 0), 0)
    row = _sachet_row(aid)
    if _item_count(ctx, 'xiangnang') <= 0:
        return ctx.fail('你没有香囊，无法兑换',
                        '★ 香囊兑换业务门：items_currency 真背包里香囊为 0（activity_id=%s rid=%s）' % (aid, rid))
    sid = _daily_scheme(max(0, rid - 1))
    rewards = _scheme_rewards(sid)
    if not rewards:
        return ctx.fail('兑换奖励不存在',
                        '★ 香囊兑换业务门：rewardScheme.lua 的 %s 无可发商品（rid=%s）' % (sid, rid))
    return ctx.ok({'rewards': rewards, 'reward': rewards, 'msg': '兑换成功',
                   'yashi_expired_time': 0,
                   'currencyVersion': _num(_role_save(ctx).get('currencyVersion'), 1)},
                  '★ 香囊兑换（方案 %s，商品取自 shoplist.lua 真键）' % sid)


def _ep_get_lottery_treasure_exchange_shop(ctx, st):
    """江湖夺宝兑换商店（旧版；新版 `get_lottery_treasure_list` 归 activities.py）。

    ★ 我核实过：**没有任何「夺宝兑换货架」配表** —— 两张 `shoplist.lua` 里 grep
      `夺宝|treasure|duobao|lottery` 零命中，`rewardScheme` 里同关键字也零命中；
      而 `activity/shoplist.lua` 只是 `store/shoplist.lua` 的**旧子集**
      （2041 条全在 store 版内，且客户端 `require("res.script.store.shoplist")` 只认 store 版：
      `GoodsHelper.lua:6`）。所以这里按「兑换商店」的语义，用她**活动商品表里
      客户端真在用的那份** `store/shoplist.lua["Sheet1"]` 出货，并显式标出来源。
    """
    aid = ctx.param('activity_id') or (ctx.args[0] if ctx.args else '')
    rows = []
    for k, v in _shop().items():
        if not isinstance(v, dict):
            continue
        it = _mk_item(k, v, 1)
        if not it['itemId']:
            continue
        rows.append({'id': it['id'], 'goodsId': it['id'], 'itemId': it['itemId'],
                     'name': it['name'], 'icon': it['icon'], 'itype': it['itype'],
                     'number': 1, 'price': _num(v.get('salePrice'), 0)
                     or _num(v.get('buyPrice'), 0)})
    rows = rows[:120]
    return ctx.ok({'activity_id': _s(aid), 'currency_name': '夺宝令',
                   'currency_number': _item_count(ctx, 'duobaoling'),
                   'list': rows, 'goods_list': rows, 'shop_list': rows,
                   'source': 'store/shoplist.lua["Sheet1"]',
                   'help_text': '夺宝令可在商城用元宝购买；兑换货架取自她客户端真在用的商品表。'},
                  '★ 夺宝兑换商店（%d 条，全部是 store/shoplist.lua["Sheet1"] 的**真键**；'
                  '本包内没有独立的夺宝货架配表，已在 data.source 标出）' % len(rows))


def _ep_lottery_treasure_exchange_goods(ctx, st):
    """兑换一件：真查商品表 → 真扣夺宝令 → 回商品（`GrantGoodRequest` 只吃商品表真键）。"""
    aid = ctx.param('activity_id') or (ctx.args[0] if ctx.args else '')
    gid = ctx.param('goods_id') or (ctx.args[1] if len(ctx.args) > 1 else '')
    g = _goods(gid) or _goods_by_item(gid, 1)
    if not g:
        return ctx.fail('兑换物品不存在',
                        '★ 夺宝兑换业务门：store/shoplist.lua["Sheet1"]["%s"] 查不到（她 GoodsHelper 会 error）'
                        % _s(gid))
    price = ctx.int_param('price', 0)
    if price <= 0:
        v = _pick(_shop(), g['id']) or {}
        price = _num(v.get('salePrice'), 0) or _num(v.get('buyPrice'), 0)
    m = _ic()
    have = _item_count(ctx, 'duobaoling')
    if price and have < price:
        return ctx.fail('夺宝令不足', '★ 夺宝兑换业务门：需要 %d，真背包只有 %d（activity_id=%s）'
                        % (price, have, _s(aid)))
    if price and m:
        m.add_count(ctx, 'duobaoling', -price)
    return ctx.ok({'reward': g, 'rewards': [g], 'goods': g, 'msg': '兑换成功',
                   'duobaoling': _item_count(ctx, 'duobaoling'),
                   'currencyVersion': _num(_role_save(ctx).get('currencyVersion'), 1)},
                  '★ 夺宝兑换（真扣 %d 夺宝令；商品 id=%s 是 store/shoplist.lua 真键）' % (price, g['id']))


# ------------------------------------------------ 晋升材料
def _ep_get_zhao_upgrade_matters(ctx, st):
    """`XuJuanBag.lua:14-27` / `BagUI.lua:768-773` / `MapRoleBagPresenter.lua:262` 读
    `data.matters_list[].id` 与 `.num`（`ipairs` + `count = v.num` 算术 ⇒ 两者都必须是数/串）。"""
    rows = _rows(r'skill/breakThroughItems.lua', 'Items')
    out = []
    for r in rows:
        iid = _s(r.get('id'))
        if not iid:
            continue
        out.append({'id': iid, 'name': _strip(r.get('name')) or iid,
                    'dsc': _strip(r.get('dsc')), 'type': _strip(r.get('type')),
                    'num': _item_count(ctx, iid)})
    return ctx.ok({'matters_list': out, 'currencyVersion': _num(_role_save(ctx).get('currencyVersion'), 1)},
                  '★ 招式突破材料（id/name 取 skill/breakThroughItems.lua，num 取 items_currency 真背包，共 %d 种）'
                  % len(out))


def _ep_get_martial_upgrade_currency(ctx, st):
    """`SkillBreakThroughPresent.lua:22-27` 读 `amartial/bmartial/cmartial/dmartial`；
    `:62-66` 用 `..` 拼串 ⇒ **四个都不能缺**（缺一个 attempt to concatenate → UI 卡死）。"""
    rs = _role_save(ctx)
    out = {}
    for k in ('amartial', 'bmartial', 'cmartial', 'dmartial'):
        out[k] = _num(rs.get(k), 0)
    out['currencyVersion'] = _num(rs.get('currencyVersion'), 1)
    return ctx.ok(out, '★ 武学突破货币（四个数读 roles/full.json 真存档；currencyVersion 也是真值）')


# ------------------------------------------------ 仆人 / 称号 / 家园 / 道具
_SERVANT_STATUS = {'naoshi': 1, 'leave': 0, 'wild': 2}


def _ep_make_servant_change(ctx, st):
    """`setPuRenStatus`（`TestLayer.lua:1167/1188/1211` 传 "naoshi"/"leave"/"wild"）；只看 errcode。"""
    mid = _s(ctx.param('mid') or (ctx.args[0] if ctx.args else ''))
    rw = _s(ctx.param('rwId') or ctx.param('rwid') or (ctx.args[1] if len(ctx.args) > 1 else ''))
    typ = _s(ctx.param('type') or (ctx.args[2] if len(ctx.args) > 2 else ''))
    if not mid or typ not in _SERVANT_STATUS:
        return ctx.fail('仆人状态参数有误',
                        '★ make_servant_change 业务门：mid=%s type=%s（她只传 naoshi/leave/wild）' % (mid, typ))
    s = st.setdefault('servant', {})
    s.setdefault(mid, {})['status'] = _SERVANT_STATUS[typ]
    s[mid]['rwId'] = rw
    s[mid]['time'] = ctx.int_param('time', 0)
    s[mid]['t'] = int(time.time())
    _save(ctx, st)
    return ctx.ok({'mid': mid, 'rwId': rw, 'type': typ, 'status': _SERVANT_STATUS[typ]},
                  '★ 改变仆人状态（%s → %d，真记事；她只判 errcode）' % (typ, _SERVANT_STATUS[typ]))


def _ep_set_sole_title(ctx, st):
    """`TestLayer.lua:1637` 的调试按钮；只看 errcode。真去写存档的唯一头衔标记。"""
    rs = _role_save(ctx)
    cur = rs.get('soleTitle')
    st.setdefault('title', {})['sole'] = 1
    _log(st, 'unlock sole title')
    _save(ctx, st)
    return ctx.ok({'sole_title': 1, 'before': _s(cur)},
                  '★ 解锁门派唯一头衔（调试接口；已记 misc_daily_state.json 的 title.sole）')


def _ep_add_homebw(ctx, st):
    """无活调用点。她存档里有 `homebw` 键（`roles/full.json`），这里真加数量。"""
    bwid = _s(ctx.param('bwid') or ctx.param('bwId') or (ctx.args[0] if ctx.args else ''))
    n = ctx.int_param('number', 0)
    if not bwid or n == 0:
        return ctx.fail('参数有误', '★ add_homebw 业务门：bwid=%s number=%d' % (bwid, n))
    h = st.setdefault('homebw', {})
    h[bwid] = _num(h.get(bwid), 0) + n
    _save(ctx, st)
    return ctx.ok({'bwid': bwid, 'number': h[bwid]}, '★ 加家园宝物（bwid=%s ⇒ %d，真写 misc_daily_state.json）' % (bwid, h[bwid]))


def _ep_add_money_ceiling(ctx, st):
    """无活调用点。她存档的 `money` 有上限语义（`Role.lua:1891` money=碎银），这里真加"上限"计数。"""
    n = ctx.int_param('number', 0)
    st['money_ceiling'] = _num(st.get('money_ceiling'), 0) + n
    _save(ctx, st)
    return ctx.ok({'number': st['money_ceiling'], 'money_ceiling': st['money_ceiling']},
                  '★ 提高碎银上限（累计 %d；无活调用点，她回调不读字段）' % st['money_ceiling'])


def _ep_add_prop(ctx, st):
    """`HttpManager.lua:3406` 的 `addProp(propId,count)`；她 `SelfCreatedSkillPropSystem:addProp`
    是**空实现**（`SelfCreatedSkillPropSystem.lua:70-71`），回调不读任何字段 ⇒ 真记流水即可。"""
    pid = _s(ctx.param('prop') or ctx.param('propId') or (ctx.args[0] if ctx.args else ''))
    n = ctx.int_param('count', 0)
    if not pid or n == 0:
        return ctx.fail('参数有误', '★ add_prop 业务门：prop=%s count=%d' % (pid, n))
    p = st.setdefault('prop', {})
    p[pid] = _num(p.get(pid), 0) + n
    _save(ctx, st)
    return ctx.ok({'prop': pid, 'count': p[pid]}, '★ 加创作/改良道具（prop=%s ⇒ %d，真写状态）' % (pid, p[pid]))


def _ep_set_auction_time(ctx, st):
    """`TestLayer.lua:724/745` 的调试按钮；只看 errcode。真存拍卖时间。"""
    t = ctx.int_param('time', 0)
    st.setdefault('auction', {})['time'] = t
    _save(ctx, st)
    return ctx.ok({'time': t}, '★ 设置拍卖时间（调试接口；已存 misc_daily_state.json 的 auction.time）')


def _ep_find_roommate(ctx, st):
    """无活调用点；收下 `roommate_id` + `room_id` 并记流水（她回调只看 errcode）。"""
    rid = _s(ctx.param('roommate_id') or (ctx.args[0] if ctx.args else ''))
    room = _s(ctx.param('room_id') or (ctx.args[1] if len(ctx.args) > 1 else ''))
    if not rid:
        return ctx.fail('参数有误', '★ find_roommate 业务门：缺 roommate_id')
    st.setdefault('roommate', []).append({'roommate_id': rid, 'room_id': room, 't': int(time.time())})
    _save(ctx, st)
    return ctx.ok({'roommate_id': rid, 'room_id': room},
                  '★ 寻找室友（已记流水 %d 条；无活调用点）' % len(st['roommate']))


def _ep_is_visitor_shop_open(ctx, st):
    """`VisitTask.lua:123`（整段已注释）只看 `errcode==0` 就放行。她读 `is_open` 的地方在别的模块，
    这里给真字段 + 不糊。"""
    return ctx.ok({'is_open': 1, 'state': 1, 'status': 1,
                   'visit_task': 1, 'open': 1},
                  '★ 拜访任务开关（她 VisitTask.lua:123 只判 errcode==0 才放行）')


def _ep_respect_teacher(ctx, st):
    """无活调用点；她 `dailyTask.lua` 里 `qingan`(每日首次进行师门请安, 10 点) 就是它对应的行为，
    所以这里真按那条 +points 记一笔（数值来自她的表）。"""
    cfg = _lua(r'activity/dailyTask.lua', 'Sheet1')
    pt = 0
    for _k, v in cfg.items():
        if isinstance(v, dict) and _s(v.get('taskid')) == 'qingan':
            pt = _num(v.get('points'), 0)
            break
    s = st.setdefault('respect', {'times': 0, 'point': 0})
    s['times'] = _num(s.get('times'), 0) + 1
    s['point'] = _num(s.get('point'), 0) + pt
    _save(ctx, st)
    return ctx.ok({'times': s['times'], 'point': pt, 'total': s['point']},
                  '★ 师门请安（+%d 点，取自 activity/dailyTask.lua 的 qingan；无活调用点）' % pt)


def _ep_roll_back_exchange(ctx, st):
    """`AnniversaryCelebrationConversionLayer.lua:93` 真调用；回调只看 errcode（`:117-186`）。"""
    tid = _s(ctx.param('client_trans_id') or (ctx.args[0] if ctx.args else ''))
    if not tid:
        return ctx.fail('缺少流水号', '★ roll_back_exchange 业务门：缺 client_trans_id')
    r = st.setdefault('rollback', {})
    r[tid] = {'state': 'failed', 't': int(time.time())}
    _log(st, 'roll back %s' % tid)
    _save(ctx, st)
    return ctx.ok({'state': 'failed', 'client_trans_id': tid},
                  '★ 回滚失败订单 %s（她只看 errcode；退钱归 buyGoods 的模块，本模块不退钱）' % tid)


def _ep_check_failed_normal_sign(ctx, st):
    """无活调用点（真实流量里出现过 1 次）。她只判 errcode。"""
    tid = _s(ctx.param('trans_id') or (ctx.args[0] if ctx.args else ''))
    st.setdefault('sign_check', {})[tid or '-'] = int(time.time())
    _save(ctx, st)
    return ctx.ok({'trans_id': tid, 'state': 0},
                  '★ 检查累计签到结果（trans_id=%s；无活调用点，她只判 errcode）' % tid)


def _ep_challengemap_leave(ctx, st):
    """`ChallengeMapSystem.lua:434-445` 真调用：`errcode==0` 才 `callback(true)`（真结束副本记录）。"""
    t = ctx.int_param('type', 0)
    if t not in (1, 2, 3):
        return ctx.fail('参数有误', '★ challengemap_leave 业务门：type=%d（她只传 1主动/2失败/3重连）' % t)
    st.setdefault('challenge_leave', []).append({'type': t, 't': int(time.time())})
    _save(ctx, st)
    return ctx.ok({'type': t, 'state': 0},
                  '★ 离开挑战副本（type=%d，与 challenge_map 模块共用 challengemap_state.json 的副本账）' % t)


def _ep_transfer_homegate_group(ctx, st):
    """`DepartFromFamily.lua:117-129` 读 `data.transferSign`（truthy 才 `setAttr("departFromFamilySign")`）。"""
    fid = _s(ctx.param('familyId') or (ctx.args[0] if ctx.args else ''))
    nfid = _s(ctx.param('newFamilyId') or (ctx.args[1] if len(ctx.args) > 1 else ''))
    if not fid or not nfid:
        return ctx.fail('参数有误', '★ transfer_homegate_group 业务门：familyId=%s newFamilyId=%s' % (fid, nfid))
    sign = int(time.time())
    st.setdefault('transfer', {})[fid] = {'new': nfid, 'sign': sign}
    _log(st, 'transfer %s → %s' % (fid, nfid))
    _save(ctx, st)
    return ctx.ok({'transferSign': sign, 'familyId': fid, 'newFamilyId': nfid},
                  '★ 转投师门组（transferSign=%d，她 truthy 判断后写 departFromFamilySign）' % sign)


def _ep_all_qixi_delete(ctx, st):
    """`QiXiUtil.lua:944-975` 真调用：`errcode==0` 才清她客户端 7 天七夕数据。她读 `data` 的字段：无。"""
    q = st.setdefault('qixi', {'deleted': 0})
    q['deleted'] = _num(q.get('deleted'), 0) + 1
    q['t'] = int(time.time())
    _save(ctx, st)
    return ctx.ok({'deleted': q['deleted'], 'state': 0},
                  '★ 清除七夕所有数据（第 %d 次；她 QiXiUtil.lua:944 只判 errcode==0）' % q['deleted'])


def _ep_reset_anniversary_reward_list(ctx, st):
    """无活调用点；对应 `action_festival.py` 的 `get_anniversary_reward_list`，
    这里真把它那份 `activities_state.json["anniv"]["got"]` 清掉（**不动别人的状态文件结构**，只清 got）。"""
    d = ctx.load_json('activities_state.json', {}) or {}
    n = 0
    if isinstance(d, dict):
        a = d.get('anniv')
        if isinstance(a, dict) and isinstance(a.get('got'), dict):
            n = len(a['got'])
            a['got'] = {}
            ctx.save_json('activities_state.json', d)
    st.setdefault('anniversary', {})['reset'] = _num(st['anniversary'].get('reset'), 0) + 1
    _save(ctx, st)
    return ctx.ok({'reset': st['anniversary']['reset'], 'cleared': n},
                  '★ 重置周年庆领取状态（清了 activities_state.json 的 anniv.got %d 条，与 action_festival.py 同一份账）' % n)


def _ep_reset_xianshilibao_points(ctx, st):
    """无活调用点；真把限时礼包积分归零（`activity/shoplist.lua` 里 xianshi 段是它的货架）。"""
    st.setdefault('xianshi', {})['reset'] = _num(st['xianshi'].get('reset'), 0) + 1
    st['xianshi']['point'] = 0
    _save(ctx, st)
    return ctx.ok({'point': 0, 'reset': st['xianshi']['reset']},
                  '★ 重置限时礼包积分（第 %d 次）' % st['xianshi']['reset'])


def _familys():
    """她 `family/family.lua["familys"]`（30 个门派，`id/name/camp/familytype/...`）。"""
    return _lua(r'family/family.lua', 'familys')


def _ep_all_menpai_top(ctx, st):
    """`getAllFamilyScore` → `all_menpai_top`。无活调用点；
    门派名与类型取她 `family/family.lua`（`familys` + `门派类型`），**不是**龙舟表。"""
    fams = _familys()
    types = _lua(r'family/family.lua', '门派类型')
    ftype = {}
    for _k, v in types.items():
        if isinstance(v, dict):
            for fid in _s(v.get('familys')).split(';'):
                if fid:
                    ftype[fid] = _s(v.get('name'))
    rows = []
    for i, k in enumerate(sorted(fams)):
        v = fams[k]
        if not isinstance(v, dict):
            continue
        rows.append({
            'id': _s(v.get('id')) or _s(k),
            'menpai': _strip(v.get('name')) or _s(k),
            'name': _strip(v.get('name')) or _s(k),
            'familytype': _num(v.get('familytype'), 0),
            'camp': _num(v.get('camp'), 0),
            'typeName': ftype.get(_s(v.get('id')) or _s(k), ''),
            'score': _num(v.get('atkFamily'), 0) + _num(v.get('defFamily'), 0)
                     + _num(v.get('apFamily'), 0) + _num(v.get('dodgeFamily'), 0)
                     + _num(v.get('damageFamily'), 0),
            'grade': i + 1,
        })
    rows.sort(key=lambda r: (-r['score'], r['grade']))
    for i, r in enumerate(rows):
        r['sort'] = i + 1
    return ctx.ok({'list': rows, 'menpai_list': rows, 'top': rows[:10],
                   'family_list': rows},
                  '★ 全门派积分榜（%d 个门派，名字/类型/系数全取 family/family.lua 的 familys+门派类型）'
                  % len(rows))


# ------------------------------------------------ 记录 / 埋点
def _ep_update_unlock_record(ctx, st):
    """`AchievementSystem.lua:60-66`：**必须**回 `recordList`，每条 `{jid, expired_time, values}`；
    她 `:80-82` 做 `unlockRecords[v.jid] = v.values` 然后 `+1` 算术 ⇒ 三者都不能缺、values 必须是数。"""
    ev = ctx.param('events')
    if ev is None and ctx.body_obj:
        ev = ctx.body_obj.get('events')
    added = 0
    if isinstance(ev, list):
        for it in ev:
            if not isinstance(it, dict):
                continue
            jid = _s(it.get('jid') or it.get('id'))
            if not jid:
                continue
            st.setdefault('unlock', {})[jid] = {
                'jid': jid,
                'expired_time': _num(it.get('expired_time'), 0),
                'values': _num(it.get('values'), _num(it.get('value'), 0)),
            }
            added += 1
    recs = list((st.get('unlock') or {}).values())
    _save(ctx, st)
    return ctx.ok({'recordList': recs, 'record_list': recs, 'add': added},
                  '★ 上传/取回成就解锁记录（recordList[].jid/expired_time/values；上传 %d 条，现存 %d 条）'
                  % (added, len(recs)))


def _ep_submit_event_record(ctx, st):
    """无活调用点；收下并记事（她回调不读字段）。"""
    st.setdefault('event', []).append({'body': (ctx.body_text or '')[:400], 't': int(time.time())})
    _save(ctx, st)
    return ctx.ok({'state': 0, 'count': len(st['event'])},
                  '★ 提交事件记录（已收下 %d 条；她只判 errcode）' % len(st['event']))


def _ep_add_incident_log(ctx, st):
    """`EventRecord.lua:7-15` 真调用：`errcode==0` 才 `func()`。她读 `data` 的字段：无。"""
    et = _s(ctx.param('event_type') or (ctx.args[0] if ctx.args else ''))
    prm = ctx.param('envet_param')
    ua = ctx.param('user_attr')
    st.setdefault('incident', []).append({
        'event_type': et, 'param': prm if isinstance(prm, (str, int, float, list, dict)) else _s(prm),
        'has_user_attr': bool(ua), 't': int(time.time()),
    })
    _save(ctx, st)
    return ctx.ok({'state': 0, 'count': len(st['incident'])},
                  '★ 事件上报（event_type=%s，已存 %d 条；她只判 errcode==0 就回调）' % (et, len(st['incident'])))


def _ep_count_multi_record(ctx, st):
    """`QSLayer.lua:255` 真调用：`errcode==0` 才继续下一题（**这里回非 0 会让她问卷卡住**）。
    她的上行正文**就是答题数组本身**（`retryPostWithHeader(..., type, ...)`，type 是 table）。"""
    body = ctx.body_obj if isinstance(ctx.body_obj, dict) else {}
    answers = ctx.body_obj if isinstance(ctx.body_obj, list) else body.get('answers')
    if answers is None:
        answers = ctx.param('answer_list')
    n = len(answers) if isinstance(answers, (list, dict)) else 0
    m = st.setdefault('multi', {})
    key = str(_today())
    m[key] = _num(m.get(key), 0) + 1
    m['last_answers'] = n
    _save(ctx, st)
    return ctx.ok({'state': 0, 'count': m[key], 'answers': n},
                  '★ 问卷答题记录（本次 %d 题，今日第 %d 次；她 QSLayer.lua:255 靠 errcode==0 推进下一题）'
                  % (n, m[key]))


# =====================================================================
_HANDLERS = {
    'get_guide_task_point': _ep_get_guide_task_point,
    'add_guide_task_point': _ep_add_guide_task_point,
    'get_daily_point': _ep_get_daily_point,
    'get_daily_board': _ep_get_daily_board,
    'get_daily_reward': _ep_get_daily_reward,
    'get_daily_reward_list': _ep_get_daily_reward_list,
    'roll_daily_reward': _ep_roll_daily_reward,
    'get_daily_Notice': _ep_get_daily_notice,
    'get_exam_reward': _ep_get_exam_reward,
    'get_login_yuanbao': _ep_get_login_yuanbao,
    'get_reward': _ep_get_reward,
    'get_menpai_hongbao': _ep_get_menpai_hongbao,
    'can_get_duanwu_reward': _ep_can_get_duanwu_reward,
    'update_boat_point': _ep_update_boat_point,
    'get_sachet_attic_list': _ep_get_sachet_attic_list,
    'exchange_award_to_sachet': _ep_exchange_award_to_sachet,
    'get_lottery_treasure_exchange_shop': _ep_get_lottery_treasure_exchange_shop,
    'lottery_treasure_exchange_goods': _ep_lottery_treasure_exchange_goods,
    'get_zhao_upgrade_matters': _ep_get_zhao_upgrade_matters,
    'get_martial_upgrade_currency': _ep_get_martial_upgrade_currency,
    'make_servant_change': _ep_make_servant_change,
    'set_sole_title': _ep_set_sole_title,
    'add_homebw': _ep_add_homebw,
    'add_money_ceiling': _ep_add_money_ceiling,
    'add_prop': _ep_add_prop,
    'set_auction_time': _ep_set_auction_time,
    'find_roommate': _ep_find_roommate,
    'is_visitor_shop_open': _ep_is_visitor_shop_open,
    'respect_teacher': _ep_respect_teacher,
    'roll_back_exchange': _ep_roll_back_exchange,
    'check_failed_normal_sign': _ep_check_failed_normal_sign,
    'challengemap_leave': _ep_challengemap_leave,
    'transfer_homegate_group': _ep_transfer_homegate_group,
    'all_qixi_delete': _ep_all_qixi_delete,
    'reset_anniversary_reward_list': _ep_reset_anniversary_reward_list,
    'reset_xianshilibao_points': _ep_reset_xianshilibao_points,
    'all_menpai_top': _ep_all_menpai_top,
    'update_unlock_record': _ep_update_unlock_record,
    'submit_event_record': _ep_submit_event_record,
    'add_incident_log': _ep_add_incident_log,
    'count_multi_record': _ep_count_multi_record,
}


def handle(ctx):
    ep = ctx.endpoint
    fn = _HANDLERS.get(ep)
    if fn is None:
        return None
    st = _st(ctx)
    return fn(ctx, st)
