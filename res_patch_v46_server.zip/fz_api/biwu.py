# -*- coding: utf-8 -*-
# ================= 离线包路径根（fz_make_offline_bundle.py 自动注入） =================
# 手机上整个服务端就是一个目录，表在哪、状态写哪，全部相对包根算。
# （有的模块原来把绝对路径写死，本身没 import os —— 这里一并补上）
import os
import os as _osp


def _off_find_bundle(_f):
    """从模块所在目录往上找包根（认 fz_boot_server.py）。
    ★ fz_api/*.py 的 __file__ 在 <根>/fz_api/ 下，直接 dirname 会算错一层。"""
    _d = _osp.path.dirname(_osp.path.abspath(_f))
    for _ in range(6):
        if _osp.path.exists(_osp.path.join(_d, 'fz_boot_server.py')):
            return _d
        _u = _osp.path.dirname(_d)
        if _u == _d:
            break
        _d = _u
    return _osp.path.dirname(_osp.path.abspath(_f))


_OFF_BUNDLE = _off_find_bundle(__file__)
_OFF_FZ_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_fz')
_OFF_INK_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_ink')
_OFF_WORK_ROOT = _OFF_BUNDLE
# =====================================================================================
# ★ 2026-10-04 商城空货架修复：客户端资源表解析——PC 开发树优先，设备上自动回退
#   到包内 client_fz 副本（jhserver/client_fz = fangzhi_lua_dec 的同步拷贝）。
def _fz_res(*parts):
    base = os.path.join(_OFF_FZ_ROOT, 'res', 'script')
    if not os.path.isdir(base):
        base = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            '..', 'client_fz', 'res', 'script')
    return os.path.join(base, *parts)

# -*- coding: utf-8 -*-
"""论剑 / 比武（BiWu）面板 —— 1:1 复刻她客户端的接口契约。

契约来源（**逐个回调体**读过，不是猜的）：
  * `app/models/BiWu/BiWu.lua`              —— 所有 `data.*` 的读取点
       987-1055  watch_fight / 1071-1097 unwatch_fight / 1100-1133 get_fight_msg2
       1136-1190 join_fight2 / 1192-1319 fight2/{1,2,3,4}
       1321-1392 report_fight_result2 / 1394-1410 use_fight_card
       1412-1435 get_fight_times2 / 1437-1451 get_fight_yuanbao
       1453-1470 get_chanllenge_msg / 1473-1508 can_watch_fight
       1511-1549 get_fight_board/{1,2,3} / 1552-1570 get_out_fight_stage
       1928-2012 get_fight_reward_list / get_fight_reward / get_fight_reward_notice
  * `app/views/ui/BiWuUI/BiWuRankingUI.lua`  —— 榜单每行/我的名次怎么用 `body.list`、`body.mine`
       152-214 createListView（`data.list` 用 ipairs/#、`data.mine.sort`）
       217-344 createPanel（每行 `name/menpai/dsc/looks/sex` + Role:create→HeadViewPresenter）
  * `app/views/layer/BiWuLayer/BiWuRankingLayer.lua` 197-234 —— 奖励列表 / 奖励预览
  * `app/views/layer/BiWuLayer/BiWuMainLayer.lua` 256-340 / 620-665 —— 入场/上场/在线人数
  * `app/views/layer/BiWuLayer/BiWuWatchLayer.lua` 76-198 —— 观战倒计时（expired_time 用未来秒）
  * `app/extends/Http/HttpManager.lua` 552-691、2055-2060 —— URL 与 HTTP 方法

接口 → 她读的字段（类型按她的**用法**判定：pairs/ipairs/# ⇒ 表；`..` ⇒ 串；`+ - <` ⇒ 数；`a.b` ⇒ 对象）

  get_fight_board/{type}   type 1 历史人气榜 2 本周人气榜 3 本周对战记录
      data.body.list  表（ipairs/#）      每行 {name(串), userid(数), menpai(串), dsc(串),
                                             looks(数), sex("男"/"女"), renqi(数), family(对象)}
      data.body.mine  对象（同每行 + sort(数)）
      data.body.renqi 数 / data.body.sort 数   —— 面板左上「人气」、右上「排名」
      ★ type==2 时她做 `tonumber(string.sub(data.body.mine.dsc,4,-1))` 当作**玩家本周人气**
        ⇒ `mine.dsc` 必须是「3 字节前缀 + 纯数字」⇒ 本模块用 "人" + renqi（正好 3 字节）
      ★ type==3 时她只把 `data` 的**值**当数组用：`list[1]`=名次、`list[2]`=人数
        （记录本身取本地 fightWeekAllData）⇒ 回 {"sort":名次, "renqi":人数}
  get_fight_msg2           {watch_msg: [{msg(串)}], watch_cnt(数), week_renqi(数), history_renqi(数)}
                           watch_msg 是**数组**，元素是**对象**（她读 `[1].msg` 并逐条 remove）
  get_fight_times2         {fight_times(数=剩余上台次数), current_cnt(数=回合)}
  get_fight_yuanbao/{type} {yuanbao(数)}                type 1 上台 2 挑战
  get_fight_reward_list    {is_get("Y"/"N"), last_renqi, last_sort, reward(串),
                            current_renqi, current_sort, danyao(表{itemId:个数}), money(数)}
  get_fight_reward         {reward_list: [串], renqi(数), danyao(表{itemId:个数})}
  get_fight_reward_notice  {notice(串)}                 她 `gsub(notice,"?","\\n")` 后打印
  join_fight2              {renqi, fid, current_cnt, today_max_point, stage_renqi} 全 number
  fight2/{1挑衅 2邀战 3告辞 4挑战}
                           {id(数), user(对象=对手整档), win_points(数), today_max_point(数),
                            current_cnt(数), week_renqi(数)}   —— 告辞(3)时读 week_renqi
  report_fight_result2     {current_time, expired_time(未来秒), lose_points, current_cnt, renqi,
                            win_points, win_times, stage_renqi, today_max_point} 全 number
  can_watch_fight          只看 errcode（0 可 / 1 不可 / 2 服务器正在观战，带 errmsg）
  watch_fight              {current_time(数), expired_time(数=未来秒), fid(数)}
  unwatch_fight            （不读 data；上行 fid / unwatch_time）
  use_fight_card           （不读 data；上行 fid / id / card_id）
  add_record/lunjian_x_y   （只看 errcode/errmsg；上行就是 URL）
  get_out_fight_stage      {today_max_point(数)}  ★不在交办清单里，但**必须做**：
       `BiWu.lua:1559` 是 `fightAllData.day_renqi = data.today_max_point` 然后
       `PopText("...成功返回"..fightAllData.day_renqi)`；宽容兜底不给这个字段 ⇒ 拼 nil
       ⇒ 崩在应答回调里被 xpcall 吞掉 ⇒ **整个 UI 卡死**。所以顺带实现。
  get_chanllenge_msg       她 `fightAllData.watchFightResultMsg = data` 后 `for i=1,#data`
       ⇒ data 顶层必须是**数组**（数组元素是要打印的战报串）。ctx.ok 只能回 dict，
       所以这里直接用 ctx.enc 自己拼。不做的话落到宽容兜底回 dict ⇒ `#data`==0 ⇒ 观战空屏。

数据出处（全部来自**她自己的资源表**，`work/fz_luatable.py` 解析 `assets/res/script/**`）：
  * 门派 / 门派技能 / 阵营：`family/family.lua` 的 `["familys"]`（华山/武当派/丐帮/… 的 name）
  * 对手名单·等级·气血·内力·looks·sex·介绍：`map/mapRoleBase/fb*.lua`（取前几个文件，
    只收有名字、lv>=80、sex 为「男/女」的条目 —— sex 必须是这两个字，
    否则 `HeadViewBasePresent:getLookMaskId` 会 `error("sex is error")`）
  * 战报文案：`app/models/BiWu/BiWu.lua` 里她自己的比武文本表
    （`_BattleReplyText` / `_ProvokeReplyText` / `_BattleWinText` / `_ProvokeWinText` /
      `defaultText[4]`），把 `$A/$B/$C/$K/$L/$M/$N/$T` 用上面两张表填出来
  * 称号（$C）：`roleTitle/newRoleTitleConf.lua` 的 `["1"]`（text + color）
  * 技能名（$K）：`skill/skill.lua` 的 `["skills"][门派心法id]["name"]`（养蛇术/华山剑法…）
  * 奖励物品 id：`store/shoplist.lua` 里 300004=潜能丹(qiannengdan)、300144=天香玉露(tianxiangyulu1)
    （该表 622KB、解析要 2.6s，所以按作者期解析结果写成常量，注释里留了出处）
  * 榜单每行 / 对手的**角色整档**：`work/role_store/dev1.json`（6.7KB，字段齐全）与
    `work/roles/full.json`（27KB，真实存档）。用真档当模板是为了避开
    `Role_Task:loadHangUpVersion`（读 `hangUpTasks.__ver`）、`MaskSystem:getPortraitId`
    （读 `portrait.id`）、`Role_Item:getEquipByName`（读 `equips[x]`）、
    `RoleViewBorderSys:load`（读 `borderShowList[1]`）这些**缺字段就 index nil** 的地方。

状态：`work/biwu_state.json`（报名/上台、今日次数、人气/历史人气/周人气、今日最高分、
      观战记录、领奖记录、战报轮转计数、资源缓存）。
"""
import copy
import hashlib
import json
import os
import time

NAME = 'biwu'
TITLE = '论剑/比武'
ENDPOINTS = [
    # ★ 交办清单里的 15 个
    'get_fight_board', 'get_fight_msg2', 'get_fight_times2', 'get_fight_yuanbao',
    'get_fight_reward', 'get_fight_reward_list', 'get_fight_reward_notice',
    'join_fight2', 'fight2', 'report_fight_result2',
    'can_watch_fight', 'watch_fight', 'unwatch_fight', 'use_fight_card',
    'add_record',
    # ★ 同功能附带（不做的话上面 docstring 写了原因：一个卡死、一个观战空屏）
    'get_out_fight_stage', 'get_chanllenge_msg',
]

STATE = 'biwu_state.json'
RES_ROOT = _fz_res()

DAY_TIMES = 5              # 每日上台次数（她资源里没这张表：服务端配置）
COST_UP = 20               # 上台需消耗元宝（同上）
COST_CHALLENGE = 10        # 挑战需消耗元宝（同上）
WATCH_SECONDS = 2 * 3600   # 观战最大收益时长（她 `isOverTime` 拿 expired_time 比）
FIGHT_WINDOW = 600         # 挑战有效期（`resolveUnnormalFightResult`/挑战按钮用）
BOARD_ROWS = 10            # 她 `#data.list < 10` 就不追加"我的名次"了 ⇒ 至少给 10 行
ROSTER_LIMIT = 160         # 名单条数
ROSTER_FILES = 8           # 扫前 N 个 mapRoleBase 文件（够用且快）

# 她 `store/shoplist.lua` 里的 id（作者期解析出来的，见模块 docstring）
GOOD_QIANNENGDAN = '300004'   # 潜能丹   itemId=qiannengdan
GOOD_TIANXIANGYULU = '300144'  # 天香玉露 itemId=tianxiangyulu1

_ROLE_CACHE = {}
_RES_CACHE = {}
_ROLE_FALLBACK = {
    'name': '无名侠客', 'userid': 900000001, 'sex': '男', 'looks': 20, 'lv': 100,
    'id': 'wanjia', 'family': {'name': 'youxia', 'level': 3},
    'portrait': {'id': '', 'lv': 1}, 'equips': {}, 'items': [],
    'borderVer': 1, 'borderShowList': [], 'basicTitleData': {'titleList': [], 'titleId': ''},
    'titles': {'extraTitle': []}, 'hangUpTasks': {'__ver': 0, '__currHangUpTaskId': '', '__tasks': {}},
    'skills': {}, 'activeZhaos': {}, 'polymorph': {}, 'dsc': '',
}

# 她 `BiWu.lua` 自己的比武文本（$A 门派 $B 名字 $C 称号 $K 技能 $L 门派 $M 门派 $N 名字 $T 门派）
REPORT_TPL = [
    'WHT少侠客气了，我乃$AWHT$BWHT，愿以$KWHT与少侠一战。',
    'WHT在下$AWHT$BWHT，今日就以$KWHT与少侠切磋一二。',
    'WHT哼，今日我 $BWHT就以$KWHT来会会你这狂妄之徒！',
    'WHT休要放肆！就让我$BWHT来收拾你这狂徒！',
    'WHT哪来的狂徒！不知天高地厚，今日我$BWHT定要你让你尝尝我这$KWHT的厉害！',
    'GLD你打败了$MWHT$BGLD,一脚把他踢下台去，对台下众人抱拳道：',
    'GLD刚教训了一个不知天高地厚的WHT$LGLD。',
    'GLD吾乃$TWHT$NGLD，江湖人称$C',
    'GLD哼，就这点实力也敢来挑战我，真是讨打！',
    'GLD真是不禁打，我还没出力就倒下了。',
    'GLD唉，无敌真是寂寞啊。',
    'GLD今日天色已晚，不便再战，就此告辞。',
    'GLD不知哪位朋友愿上台来与我切磋一二？',
    'GLD还望各位武林同道不吝赐教！',
]

# 奖励预览（她客户端 `BiWuRankingLayer:printRewardPreview` 的兜底文案就是这套规则，
# 服务端那张配置表她资源里没有 ⇒ 按同一套分组/奖励写成 notice，"?" 她那边换成换行）
NOTICE = (
    'YEL人气值达到15000以及以上的为宗师组?人气在6000~14999内的为高手组?人气在1200~5999内的为新秀组?'
    '?NOR宗师组且排行榜第1名：?HIW碎银DWT：1000000  HIG潜能丹DWT：3  HIY元宝DWT：500'
    '?NOR宗师组且第2名：?HIW碎银DWT：400000  HIG潜能丹DWT：3  HIY元宝DWT：450'
    '?NOR宗师组且第3名：?HIW碎银DWT：300000  HIG潜能丹DWT：3  HIY元宝DWT：430'
    '?NOR宗师组且第4-10名：?HIW碎银DWT：200000  HIG潜能丹DWT：2  HIY元宝DWT：360'
    '?NOR宗师组且第11-100名：?HIW碎银DWT：170000  HIG潜能丹DWT：1  HIY元宝DWT：350'
    '?NOR宗师组且第101-500名：?HIW碎银DWT：140000  HIG潜能丹DWT：1  HIY元宝DWT：300'
    '?NOR宗师组且第501-1000名：?HIW碎银DWT：110000  HIG潜能丹DWT：1  HIY元宝DWT：250'
    '?NOR宗师组且1000名以外：?HIW碎银DWT：80000  HIG潜能丹DWT：1  HIY元宝DWT：200'
    '?NOR高手组：?HIW碎银DWT：50000  HIY元宝DWT：100'
    '?NOR新秀组：?HIW碎银DWT：30000  HIY元宝DWT：50'
)

GRADE = ['壹', '贰', '叁', '肆', '伍', '陆', '柒', '捌', '玖', '拾']


# --------------------------------------------------------------------------- #
# 小工具
# --------------------------------------------------------------------------- #


def _now():
    return int(time.time())


def _today():
    return int(time.strftime('%Y%m%d'))


def _week():
    """她周三清周人气（`clearFightRenQiInWednesday`），这里用 ISO 周做同一件事。"""
    t = time.localtime()
    return int(time.strftime('%Y%W', t))


def _num(v, d=0):
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return d


def _grade(i):
    return GRADE[i - 1] if 1 <= i <= len(GRADE) else str(i)


def _seed(*parts):
    return int(hashlib.md5(('|'.join(str(p) for p in parts)).encode('utf-8')).hexdigest()[:8], 16)


def _load_lua(path):
    """解析她的 Lua 数据表；任何失败都返回 {}（绝不抛到应答路上）。"""
    try:
        import fz_luatable
        return fz_luatable.load_lua_table(path)
    except Exception:                             # noqa: BLE001
        return {}


def _read_role(ctx, rel):
    """从 work/ 下读一份**真的角色档**当模板（进程内缓存）。"""
    if rel in _ROLE_CACHE:
        return _ROLE_CACHE[rel]
    doc = None
    try:
        with open(ctx.data_file(rel), encoding='utf-8') as f:
            v = json.load(f)
        if isinstance(v, dict):
            doc = v
    except Exception:                             # noqa: BLE001
        doc = None
    _ROLE_CACHE[rel] = doc
    return doc


def _role_doc(ctx, want):
    """want='row' 用轻档（榜单每行 10 份）；want='opponent' 用真档（要能打）。"""
    order = {
        'row': [os.path.join('role_store', 'dev1.json'), os.path.join('roles', 'full.json')],
        'opponent': [os.path.join('roles', 'full.json'), os.path.join('role_store', 'dev1.json')],
    }[want]
    for rel in order:
        doc = _read_role(ctx, rel)
        if doc:
            return doc
    return _ROLE_FALLBACK


# --------------------------------------------------------------------------- #
# 资源缓存（存在 biwu_state.json 里，重启不用再解析）
# --------------------------------------------------------------------------- #
def _resources():
    """她自己的表 → {sects, roster, titles, skillnames}。

    只在**第一台**付费解析一次（`skill/skill.lua` 651KB 要 ~1.2s、mapRoleBase 前 8 个
    文件 ~0.3s），之后从 `biwu_state.json` 读缓存 ⇒ 后续请求 0.07s 级。
    """
    if _RES_CACHE:
        return _RES_CACHE

    # 1) 门派：family/family.lua 的 ["familys"]
    sects = []
    fam = _load_lua(os.path.join(RES_ROOT, 'family', 'family.lua'))
    for sid, v in sorted((fam.get('familys') or {}).items(), key=lambda kv: str(kv[0])):
        if not isinstance(v, dict):
            continue
        nm = v.get('name')
        if not isinstance(nm, str) or not nm.strip():
            continue
        sects.append({'id': str(sid), 'name': nm,
                      'skill': str(v.get('familySkill') or ''), 'camp': v.get('camp') or 0})

    # 2) 称号：roleTitle/newRoleTitleConf.lua 的 ["1"]
    titles = []
    tt = _load_lua(os.path.join(RES_ROOT, 'roleTitle', 'newRoleTitleConf.lua'))
    node = tt.get('1') if isinstance(tt.get('1'), dict) else tt
    if isinstance(node, dict):
        for _k, v in sorted(node.items(), key=lambda kv: str(kv[0])):
            if isinstance(v, dict) and isinstance(v.get('text'), str) and v['text'].strip():
                titles.append({'text': v['text'], 'color': str(v.get('color') or 'WHT')})

    # 3) 技能名：skill/skill.lua 的 ["skills"][技能id]["name"]
    #    （只留门派心法那几个 id —— `$K` 在战报里要的是中文技能名，不是 yangsheshu 这种 id）
    want = set(s['skill'] for s in sects if s.get('skill'))
    skillnames = {}
    sk = _load_lua(os.path.join(RES_ROOT, 'skill', 'skill.lua'))
    table = sk.get('skills') if isinstance(sk.get('skills'), dict) else {}
    for k, v in table.items():
        if str(k) in want and isinstance(v, dict) and isinstance(v.get('name'), str):
            skillnames[str(k)] = v['name']

    # 4) 名单：map/mapRoleBase/fb*.lua
    roster = []
    root = os.path.join(RES_ROOT, 'map', 'mapRoleBase')
    try:
        files = sorted(f for f in os.listdir(root) if f.endswith('.lua'))[:ROSTER_FILES]
    except OSError:
        files = []
    for fn in files:
        tab = _load_lua(os.path.join(root, fn))
        if not isinstance(tab, dict):
            continue
        for _k, v in sorted(tab.items(), key=lambda kv: str(kv[0])):
            if not isinstance(v, dict):
                continue
            nm, lv, sx = v.get('name'), v.get('lv'), v.get('sex')
            if not isinstance(nm, str) or not nm.strip():
                continue
            if sx not in ('男', '女'):          # `getLookMaskId` 只认这两个字
                continue
            if not isinstance(lv, (int, float)) or lv < 80:
                continue
            looks = _num(v.get('looks'), 20)
            if looks < 0:
                looks = 20
            roster.append({
                'name': nm.strip(), 'lv': int(lv), 'sex': sx, 'looks': looks,
                'qi': _num(v.get('qi'), 3000), 'neili': _num(v.get('neili'), 3000),
                'dsc': str(v.get('dsc') or ''),
            })
            if len(roster) >= ROSTER_LIMIT:
                break
        if len(roster) >= ROSTER_LIMIT:
            break

    # 门派按顺序发下去（她表里就是这些门派，不另造）
    for i, r in enumerate(roster):
        if sects:
            s = sects[i % len(sects)]
            r['menpai'] = s['name']
            r['family_id'] = s['id']
            r['skill'] = skillnames.get(s.get('skill') or '') or '基本内功'
        else:
            r['menpai'], r['family_id'], r['skill'] = '江湖散人', 'youxia', '基本内功'
        if titles:
            r['title'] = titles[i % len(titles)]

    _RES_CACHE.update({'sects': sects, 'roster': roster, 'titles': titles, 'skillnames': skillnames})
    return _RES_CACHE


def _ensure_res(ctx, st):
    """名单/门派等缓存进 biwu_state.json（第一次付费解析，之后读档）。"""
    if st.get('roster') and st.get('sects'):
        _RES_CACHE.setdefault('roster', st['roster'])
        _RES_CACHE.setdefault('sects', st['sects'])
        _RES_CACHE.setdefault('titles', st.get('titles') or [])
        _RES_CACHE.setdefault('skillnames', st.get('skillnames') or {})
        return st
    res = _resources()
    st['roster'] = res['roster']
    st['sects'] = res['sects']
    st['titles'] = res['titles']
    st['skillnames'] = res['skillnames']
    st['res_ver'] = 1
    return st


# --------------------------------------------------------------------------- #
# 状态
# --------------------------------------------------------------------------- #
def _default_state():
    return {
        'day': 0, 'week': 0,
        'times_used': 0,          # 今日已上台次数
        'join_seq': 0, 'fid': 0,  # 上台编号（她 join 后到处带着 fid）
        'on_stage': False,
        'fight_id': 0,            # fight2 给的战斗 id（report 要带回）
        'current_cnt': 0,         # 第几回合
        'win_times': 0,           # 本场连胜
        'renqi': 0,               # 本周（当前）人气
        'week_renqi': 0,          # 本周人气
        'history_renqi': 0,       # 历史人气
        'last_week_renqi': 0,     # 上周人气（发奖用）
        'last_week_sort': 1,
        'today_max_point': 0,     # 今日最高人气
        'stage_renqi': 0,         # 本场人气（可负）
        'win_points': 0, 'lose_points': 0,
        'cur_win_points': 30, 'cur_lose_points': 10,
        'watch': {'fid': 0, 'start': 0, 'expired': 0},
        'watch_cnt': 0, 'msg_seq': 0,
        'card_id': 0, 'card_used': 0,
        'reward': {'is_get': 'N', 'get_time': 0},
        'lunjian_records': {},     # add_record/lunjian_级别_是否传承
        'roster': [], 'sects': [], 'titles': [], 'skillnames': {},
    }


def _roll(st):
    """跨天/跨周结算 —— 她在 `clearFightRenQiInWednesday` 干的事。"""
    d, w = _today(), _week()
    if _num(st.get('day')) != d:
        st['day'] = d
        st['times_used'] = 0
        st['today_max_point'] = 0
        st['stage_renqi'] = 0
        st['current_cnt'] = 0
        st['win_times'] = 0
        st['on_stage'] = False
    if _num(st.get('week')) != w:
        st['week'] = w
        st['last_week_renqi'] = st.get('week_renqi') or 0
        st['last_week_sort'] = st.get('last_sort') or 1
        st['week_renqi'] = 0
        st['renqi'] = 0
        st['stage_renqi'] = 0
        st['reward'] = {'is_get': 'N', 'get_time': 0}
    return st


def _save(ctx, st):
    st.pop('_cache', None)
    ctx.save_json(STATE, st)


def _left_times(st):
    return max(0, DAY_TIMES - _num(st.get('times_used')))


def _online(st):
    """在线人数（主界面左上「人数」）—— 按她观战面板的语义给个随时段起伏的真数。"""
    base = 5 + len(st.get('roster') or []) // 12
    h = time.localtime().tm_hour
    return base + (h % 7)


def _set_renqi(st, val):
    val = max(0, _num(val))
    st['week_renqi'] = val
    st['renqi'] = val
    if val > _num(st.get('history_renqi')):
        st['history_renqi'] = val
    if val > _num(st.get('today_max_point')):
        st['today_max_point'] = val
    return val


# --------------------------------------------------------------------------- #
# 榜单 / 每行 / 战报
# --------------------------------------------------------------------------- #
def _sect_of(st, r):
    return r.get('menpai') or '江湖散人'


def _row_of(ctx, st, r, renqi, rank, is_mine=False, my=None):
    """榜单每一行 —— 用她自己的**真角色档**当模板铺开，再盖上榜单字段。"""
    doc = _role_doc(ctx, 'row')
    row = copy.deepcopy(doc) if isinstance(doc, dict) else dict(_ROLE_FALLBACK)
    for k, v in _ROLE_FALLBACK.items():
        row.setdefault(k, v)
    row['name'] = str((my or {}).get('name') or r.get('name') or '无名侠客')
    row['userid'] = _num((my or {}).get('userid'), 0) or (900000000 + _seed(r.get('name'), renqi) % 99999999)
    row['sex'] = (my or {}).get('sex') if (my or {}).get('sex') in ('男', '女') else r.get('sex', '男')
    row['looks'] = _num((my or {}).get('looks'), _num(r.get('looks'), 20))
    row['lv'] = _num((my or {}).get('lv'), _num(r.get('lv'), 100))
    row['menpai'] = _sect_of(st, r) if not is_mine else ((my or {}).get('menpai') or '江湖散人')
    row['family'] = {'name': (my or {}).get('family_id') or r.get('family_id') or 'youxia', 'level': 3}
    # ★ type==2 她 `tonumber(string.sub(mine.dsc,4,-1))` 当本周人气 ⇒ "人"+数字（3 字节前缀）
    row['dsc'] = '人' + str(_num(renqi))
    row['renqi'] = _num(renqi)
    row['sort'] = _num(rank, 1)
    row['grade'] = _grade(_num(rank, 1))
    row['head'] = ''
    row['is_mine'] = 1 if is_mine else 0
    return row


def _entries(st, kind):
    """名单 × 稳定伪随机人气 ⇒ 名次（同一个 kind 每次结果一样，榜单不会乱跳）。"""
    out = []
    for i, r in enumerate(st.get('roster') or []):
        h = _seed(i, r.get('name'), kind, 'renqi')
        val = (8000 + h % 120000) if kind == 1 else (1200 + h % 14800)
        out.append((val, r))
    out.sort(key=lambda e: -e[0])
    return out


def _my_row_data(st, ctx):
    """玩家自己那一行：人气用我们状态里的真值。"""
    return {
        'name': st.get('player_name') or _player_from_disk(ctx).get('name') or '无名侠客',
        'userid': _num(st.get('player_userid'), 0) or _player_from_disk(ctx).get('userid'),
        'sex': _player_from_disk(ctx).get('sex') or '男',
        'looks': _num(_player_from_disk(ctx).get('looks'), 20),
        'menpai': _player_from_disk(ctx).get('menpai') or '江湖散人',
        'lv': _num(_player_from_disk(ctx).get('lv'), 100),
    }


def _player_from_disk(ctx):
    """玩家自己的名字/门派 —— 服务端下发的就是 roles/full.json（`--role ours`）。"""
    key = '_player'
    if key in _ROLE_CACHE:
        return _ROLE_CACHE[key]
    info = {}
    for rel in (os.path.join('roles', 'full.json'), os.path.join('role_store', 'dev1.json')):
        doc = _read_role(ctx, rel)
        if not doc:
            continue
        fam = (doc.get('family') or {}).get('name')
        fam_tab = (_resources().get('sects') or [])
        menpai = None
        for s in fam_tab:
            if s['id'] == fam:
                menpai = s['name']
                break
        info = {'name': doc.get('name') or '无名侠客',
                'userid': _num(doc.get('userid'), 0),
                'sex': doc.get('sex') if doc.get('sex') in ('男', '女') else '男',
                'looks': _num(doc.get('looks'), 20),
                'lv': _num(doc.get('lv'), 100),
                'family_id': fam or 'youxia',
                'menpai': menpai or '江湖散人'}
        break
    if not info:
        info = {'name': '无名侠客', 'userid': 900000001, 'sex': '男', 'looks': 20,
                'lv': 100, 'family_id': 'youxia', 'menpai': '江湖散人'}
    _ROLE_CACHE[key] = info
    return info


def _board(st, ctx, kind):
    entries = _entries(st, kind)
    my_renqi = _num(st.get('week_renqi')) if kind in (2, 3) else _num(st.get('history_renqi'))
    rank = 1 + sum(1 for v, _r in entries if v > my_renqi)
    rows = [_row_of(ctx, st, r, v, i + 1) for i, (v, r) in enumerate(entries[:BOARD_ROWS])]
    mine = _row_of(ctx, st, {}, my_renqi, rank, is_mine=True, my=_my_row_data(st, ctx))
    return rows, mine, rank, max(1, len(entries) + 1)


def _reports(st, ctx):
    """战报 —— 用她自己 BiWu.lua 里的比武文本，拿名单里的名字/门派/称号/技能填。"""
    roster = st.get('roster') or []
    if not roster:
        return []
    seq = _num(st.get('msg_seq'))
    out = []
    for j in range(6):
        a = roster[(seq * 3 + j * 5) % len(roster)]
        b = roster[(seq * 7 + j * 11 + 3) % len(roster)]
        tpl = REPORT_TPL[(seq + j) % len(REPORT_TPL)]
        if a['name'] == b['name']:
            b = roster[(roster.index(b) + 1) % len(roster)]
        title = a.get('title') or {'text': '江湖新秀', 'color': 'WHT'}
        msg = (tpl
               .replace('$A', a['menpai']).replace('$M', a['menpai'])
               .replace('$L', b['menpai']).replace('$T', a['menpai'])
               .replace('$N', a['name']).replace('$B', b['name'])
               .replace('$K', a.get('skill') or '基本内功')
               .replace('$C', str(title.get('color')) + str(title.get('text')) + 'NOR'))
        out.append({'msg': msg})
    return out


def _opponent(st, ctx, fid):
    """对手整档：真档模板 + 名单里的名字/门派/looks/sex。"""
    doc = _role_doc(ctx, 'opponent')
    role = copy.deepcopy(doc) if isinstance(doc, dict) else dict(_ROLE_FALLBACK)
    for k, v in _ROLE_FALLBACK.items():
        role.setdefault(k, v)
    roster = st.get('roster') or []
    if not roster:
        return role
    r = roster[_seed(fid, len(roster), 'opp') % len(roster)]
    role['name'] = r['name']
    role['sex'] = r['sex']
    role['looks'] = r['looks']
    role['userid'] = 900000000 + _seed(r['name'], fid) % 99999999
    role['family'] = {'name': r.get('family_id') or 'youxia', 'level': 3}
    role['menpai'] = r.get('menpai') or ''
    role['dsc'] = r.get('dsc') or ''
    return role


# --------------------------------------------------------------------------- #
# 奖励
# --------------------------------------------------------------------------- #
def _last_pair(st):
    """面板上的「上周总人气 / 上周排名」。

    ★ 上周没有记录时（新号 / 上周没上台）按**本周当前**人气与名次预估 ——
      服务端那张奖励配置表她资源里没有，若不给这个回退，奖励面板会一直显示「碎银：0」。
    """
    renqi = _num(st.get('last_week_renqi'))
    rank = max(1, _num(st.get('last_week_sort'), 1))
    if renqi <= 0:
        renqi = _num(st.get('week_renqi'))
        rank = max(1, _num(st.get('last_sort'), 1))
    return renqi, rank


def _reward_rule(st):
    """按上周人气分组（她面板上写的门槛：15000+ 宗师 / 6000~14999 高手 / 1200~5999 新秀）。"""
    renqi, rank = _last_pair(st)
    if renqi >= 15000:
        money, dan, yuanbao = 1000000, 3, 500
        if rank > 10:
            money, dan, yuanbao = 200000, 2, 360
        if rank > 100:
            money, dan, yuanbao = 170000, 1, 350
        if rank > 500:
            money, dan, yuanbao = 140000, 1, 300
        if rank > 1000:
            money, dan, yuanbao = 80000, 1, 200
        return {'group': '宗师组', 'money': money, 'dan': dan, 'yuanbao': yuanbao,
                'dan_id': 'qiannengdan', 'dan_name': '潜能丹'}
    if renqi >= 6000:
        return {'group': '高手组', 'money': 50000, 'dan': 0, 'yuanbao': 100,
                'dan_id': 'qiannengdan', 'dan_name': '潜能丹'}
    if renqi >= 1200:
        return {'group': '新秀组', 'money': 30000, 'dan': 0, 'yuanbao': 50,
                'dan_id': 'qiannengdan', 'dan_name': '潜能丹'}
    return {'group': '未上榜', 'money': 0, 'dan': 0, 'yuanbao': 0,
            'dan_id': 'qiannengdan', 'dan_name': '潜能丹'}


def _reward_str(rule):
    if rule['group'] == '未上榜':
        return '未上榜（人气需满1200才有排名奖励）'
    parts = ['碎银：%d' % rule['money']]
    if rule['dan']:
        parts.append('%s：%d' % (rule['dan_name'], rule['dan']))
    if rule['yuanbao']:
        parts.append('元宝：%d' % rule['yuanbao'])
    return '  '.join(parts)


# --------------------------------------------------------------------------- #
# 主入口
# --------------------------------------------------------------------------- #
def handle(ctx):
    ep = ctx.endpoint
    if ep not in ENDPOINTS:
        return None

    st = ctx.load_json(STATE, {})
    if not isinstance(st, dict):
        st = {}
    for k, v in _default_state().items():
        st.setdefault(k, copy.deepcopy(v))
    _roll(st)
    _ensure_res(ctx, st)

    # ---------------------------------------------------------------- 榜单 --
    if ep == 'get_fight_board':
        kind = _num(ctx.args[0] if ctx.args else 1, 1)
        if kind not in (1, 2, 3):
            kind = 1
        rows, mine, rank, people = _board(st, ctx, kind)
        name = {1: '历史人气最高榜', 2: '本周人气榜', 3: '本周对战记录'}[kind]
        _save(ctx, st)
        if kind == 3:
            # 她 `createListViews(3,list)`：list[1]=名次 list[2]=人数（记录本身取本地）
            return ctx.ok({'sort': rank, 'renqi': people},
                          '★ %s：我第 %d 名 / 共 %d 人' % (name, rank, people))
        return ctx.ok({'body': {'list': rows, 'mine': mine,
                               'renqi': _num(st.get('week_renqi') if kind == 2 else st.get('history_renqi')),
                               'sort': rank}},
                      '★ %s（%d 行真名单，我第 %d 名，人气 %d）'
                      % (name, len(rows), rank, _num(st.get('week_renqi') if kind == 2 else st.get('history_renqi'))))

    # ------------------------------------------------------------ 战报/人数 --
    if ep == 'get_fight_msg2':
        msgs = _reports(st, ctx)
        st['msg_seq'] = _num(st.get('msg_seq')) + 1
        st['watch_cnt'] = _online(st)
        _save(ctx, st)
        return ctx.ok({'watch_msg': msgs, 'watch_cnt': st['watch_cnt'],
                       'week_renqi': _num(st.get('week_renqi')),
                       'history_renqi': _num(st.get('history_renqi')),
                       'today_max_point': _num(st.get('today_max_point'))},
                      '★ 论剑战报 %d 条 / 在线 %d / 本周人气 %d'
                      % (len(msgs), st['watch_cnt'], _num(st.get('week_renqi'))))

    if ep == 'get_chanllenge_msg':
        # 她 `for i=1,#data` ⇒ data 顶层要是数组；ctx.ok 只吃 dict，所以自己拼
        msgs = [m['msg'] for m in _reports(st, ctx)]
        payload = ctx.enc({'errcode': 0, 'data': msgs, 'rand_t': time.time()})
        return payload, '★ 观战中收到的战报 %d 条' % len(msgs)

    # ------------------------------------------------------------ 次数/元宝 --
    if ep == 'get_fight_times2':
        return ctx.ok({'fight_times': _left_times(st), 'current_cnt': _num(st.get('current_cnt'))},
                      '★ 今日还可上台 %d 次（第 %d 回合）'
                      % (_left_times(st), _num(st.get('current_cnt'))))

    if ep == 'get_fight_yuanbao':
        kind = _num(ctx.args[0] if ctx.args else 1, 1)
        cost = COST_UP if kind == 1 else COST_CHALLENGE
        return ctx.ok({'yuanbao': cost}, '★ %s需元宝 %d' % ('上台' if kind == 1 else '挑战', cost))

    # ---------------------------------------------------------------- 上台 --
    if ep == 'join_fight2':
        if not st.get('on_stage') and _left_times(st) <= 0:
            # 她 errcode==1 走 PopText；errmsg 一定是串（她 `tostring(errmsg)`）
            _save(ctx, st)
            return ctx.fail('今日上台次数已用尽，明日再来（剩 %d 次）' % _left_times(st),
                            '★ 上台被拒（今日 %d 次已用完）' % DAY_TIMES)
        if not st.get('on_stage'):
            st['times_used'] = _num(st.get('times_used')) + 1
            st['join_seq'] = _num(st.get('join_seq')) + 1
            st['fid'] = 500000 + _num(st.get('join_seq'))
            st['on_stage'] = True
            st['current_cnt'] = 0
            st['win_times'] = 0
            st['stage_renqi'] = 0
            st['fight_id'] = 0
        if _num(st.get('today_max_point')) < _num(st.get('week_renqi')):
            st['today_max_point'] = _num(st.get('week_renqi'))
        _save(ctx, st)
        ctx.log('论剑上台：fid=%s 第 %d 次 本周人气 %d'
                % (st['fid'], _num(st.get('times_used')), _num(st.get('week_renqi'))))
        return ctx.ok({'renqi': _num(st.get('week_renqi')), 'fid': _num(st.get('fid')),
                       'current_cnt': _num(st.get('current_cnt')),
                       'today_max_point': _num(st.get('today_max_point')),
                       'stage_renqi': _num(st.get('stage_renqi'))},
                      '★ 上台成功（fid=%d，剩 %d 次）' % (_num(st.get('fid')), _left_times(st)))

    # ------------------------------------------------------------ 匹配对手 --
    if ep == 'fight2':
        ftype = _num(ctx.args[0] if ctx.args else 2, 2)
        fid = _num(ctx.param('fid'), _num(st.get('fid')))
        if ftype == 3:                                   # 告辞：结算本周人气
            st['stage_renqi'] = 0
            st['on_stage'] = False
            st['fight_id'] = 0
            st['current_cnt'] = 0
        else:
            st['fight_id'] = 900000 + _seed(fid, ftype, _num(st.get('times_used'))) % 99999
            st['cur_win_points'] = 20 + _seed(fid, 'wp') % 31
            st['cur_lose_points'] = 5 + _seed(fid, 'lp') % 16
        opp = _opponent(st, ctx, fid)
        _save(ctx, st)
        ctx.log('论剑匹配：type=%d fid=%s 对手=%s（%s）'
                % (ftype, fid, opp.get('name'), (opp.get('family') or {}).get('name')))
        return ctx.ok({'id': _num(st.get('fight_id')), 'user': opp,
                       'win_points': _num(st.get('cur_win_points')),
                       'today_max_point': _num(st.get('today_max_point')),
                       'current_cnt': _num(st.get('current_cnt')),
                       'week_renqi': _num(st.get('week_renqi'))},
                      '★ %s：对手 %s（%s）' % ({1: '挑衅', 2: '邀战', 3: '告辞', 4: '挑战'}.get(ftype, '比武'),
                                              opp.get('name'), opp.get('menpai') or ''))

    # ------------------------------------------------------------ 汇报结果 --
    if ep == 'report_fight_result2':
        res = str(ctx.param('result') or '')
        win = _num(st.get('cur_win_points'), 30)
        lose = _num(st.get('cur_lose_points'), 10)
        if res == 'win':
            st['current_cnt'] = _num(st.get('current_cnt')) + 1
            st['win_times'] = _num(st.get('win_times')) + 1
            st['stage_renqi'] = _num(st.get('stage_renqi')) + win
            st['win_points'], st['lose_points'] = win, 0
            _set_renqi(st, _num(st.get('week_renqi')) + win)
        elif res == 'lose':
            st['current_cnt'] = _num(st.get('current_cnt')) + 1
            st['win_times'] = 0
            st['stage_renqi'] = _num(st.get('stage_renqi')) - lose
            st['win_points'], st['lose_points'] = 0, lose
            _set_renqi(st, _num(st.get('week_renqi')) - lose)
        else:                                            # cancel / run
            st['win_points'], st['lose_points'] = 0, 0
            st['on_stage'] = False
            st['fight_id'] = 0
            st['stage_renqi'] = 0
        now = _now()
        _save(ctx, st)
        ctx.log('论剑汇报：%s → 本周人气 %d（本场 %d，回合 %d，连胜 %d）'
                % (res or '?', _num(st.get('week_renqi')), _num(st.get('stage_renqi')),
                   _num(st.get('current_cnt')), _num(st.get('win_times'))))
        return ctx.ok({'current_time': now, 'expired_time': now + FIGHT_WINDOW,
                       'lose_points': _num(st.get('lose_points')),
                       'current_cnt': _num(st.get('current_cnt')),
                       'renqi': _num(st.get('week_renqi')),
                       'win_points': _num(st.get('win_points')),
                       'win_times': _num(st.get('win_times')),
                       'stage_renqi': _num(st.get('stage_renqi')),
                       'today_max_point': _num(st.get('today_max_point'))},
                      '★ 汇报「%s」：本场人气 %+d，本周人气 %d，今日最高 %d'
                      % (res or '?', _num(st.get('stage_renqi')),
                         _num(st.get('week_renqi')), _num(st.get('today_max_point'))))

    # ---------------------------------------------------------------- 下台 --
    if ep == 'get_out_fight_stage':
        st['on_stage'] = False
        st['fight_id'] = 0
        st['stage_renqi'] = 0
        st['today_max_point'] = max(_num(st.get('today_max_point')), _num(st.get('week_renqi')))
        _save(ctx, st)
        return ctx.ok({'today_max_point': _num(st.get('today_max_point'))},
                      '★ 下台结算：今日最高人气 %d' % _num(st.get('today_max_point')))

    # ---------------------------------------------------------------- 观战 --
    if ep == 'can_watch_fight':
        w = st.get('watch') or {}
        if _num(w.get('fid')) and _num(w.get('expired')) > _now():
            return ctx.fail('你正在观战中，请先取消观战', '★ 已在观战中（fid=%s）' % w.get('fid'))
        if time.localtime().tm_hour == 23:
            return ctx.fail('比武擂台暂时关闭，开放时间为0点-23点', '★ 23 点后不可观战')
        return ctx.ok({}, '★ 可以观战')

    if ep == 'watch_fight':
        now = _now()
        st['join_seq'] = _num(st.get('join_seq')) + 1
        fid = 600000 + _num(st.get('join_seq'))
        st['watch'] = {'fid': fid, 'start': now, 'expired': now + WATCH_SECONDS}
        st['watch_cnt'] = _online(st)
        _save(ctx, st)
        ctx.log('论剑观战：fid=%s 到 %d' % (fid, now + WATCH_SECONDS))
        return ctx.ok({'current_time': now, 'expired_time': now + WATCH_SECONDS, 'fid': fid},
                      '★ 开始观战（fid=%s，%d 分钟后收益打满）' % (fid, WATCH_SECONDS // 60))

    if ep == 'unwatch_fight':
        fid = _num(ctx.param('fid'))
        st['watch'] = {'fid': 0, 'start': 0, 'expired': 0}
        _save(ctx, st)
        return ctx.ok({}, '★ 结束观战（fid=%s）' % fid)

    # ---------------------------------------------------------------- 卡牌 --
    if ep == 'use_fight_card':
        st['card_id'] = _num(ctx.param('card_id'))
        st['card_used'] = _num(st.get('card_used')) + 1
        _save(ctx, st)
        return ctx.ok({}, '★ 使用比武卡牌 id=%d' % _num(st.get('card_id')))

    # ---------------------------------------------------------------- 奖励 --
    if ep == 'get_fight_reward_list':
        rows, _mine, rank, _people = _board(st, ctx, 2)
        st['last_sort'] = rank
        rule = _reward_rule(st)
        lrenqi, lrank = _last_pair(st)
        got = str((st.get('reward') or {}).get('is_get') or 'N')
        _save(ctx, st)
        if got == 'Y':
            # 她 `BiWu.lua:1937` 写着：errcode==1 ⇒ 没有奖励/已经领取，只 PopText
            return ctx.fail('本周奖励已经领取过了', '★ 奖励已领取（本周 %s）' % _reward_str(rule))
        return ctx.ok({
            'is_get': got,
            'last_renqi': lrenqi,
            'last_sort': lrank,
            'reward': _reward_str(rule),
            'current_renqi': _num(st.get('week_renqi')),
            'current_sort': rank,
            'danyao': {rule['dan_id']: rule['dan']} if rule['dan'] else {},
            'money': rule['money'],
        }, '★ 我的论剑奖励（%s）：%s，本周人气 %d 第 %d 名，未领取'
           % (rule['group'], _reward_str(rule), _num(st.get('week_renqi')), rank))

    if ep == 'get_fight_reward':
        if str((st.get('reward') or {}).get('is_get')) == 'Y':
            return ctx.fail('本周奖励已经领取过了', '★ 重复领奖被拒')
        rule = _reward_rule(st)
        lrenqi, lrank = _last_pair(st)
        st['reward'] = {'is_get': 'Y', 'get_time': _now()}
        _save(ctx, st)
        lines = ['碎银 %d' % rule['money']]
        if rule['dan']:
            lines.append('%s %d' % (rule['dan_name'], rule['dan']))
        if rule['yuanbao']:
            lines.append('元宝 %d' % rule['yuanbao'])
        lines.append('%s · 上周人气 %d 第 %d 名' % (rule['group'], lrenqi, lrank))
        ctx.log('论剑领奖：%s' % ' / '.join(lines))
        return ctx.ok({
            'reward_list': lines,
            'renqi': lrenqi,
            'danyao': {rule['dan_id']: rule['dan']} if rule['dan'] else {},
        }, '★ 领取论剑奖励：%s' % ' / '.join(lines))

    if ep == 'get_fight_reward_notice':
        return ctx.ok({'notice': NOTICE}, '★ 论剑奖励预览（宗师/高手/新秀三组）')

    # ------------------------------------------------------- add_record/lunjian --
    if ep == 'add_record':
        key = ctx.args[0] if ctx.args else ''
        recs = st.get('lunjian_records') or {}
        recs[str(key)] = _num(recs.get(str(key))) + 1
        st['lunjian_records'] = recs
        st['player_name'] = st.get('player_name') or _player_from_disk(ctx).get('name')
        st['player_userid'] = st.get('player_userid') or _player_from_disk(ctx).get('userid')
        _save(ctx, st)
        lv = str(key).split('_')
        ctx.log('每日论剑统计：%s（累计 %d 次）' % (key, recs[str(key)]))
        return ctx.ok({}, '★ 每日论剑统计 %s（%s 级 / %s）'
                      % (key, lv[1] if len(lv) > 1 else '?', lv[2] if len(lv) > 2 else '?'))

    return None
