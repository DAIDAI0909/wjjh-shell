# -*- coding: utf-8 -*-
# ================= 离线包路径根（fz_make_offline_bundle.py 自动注入） =================
# 手机上整个服务端就是一个目录，表在哪、状态写哪，全部相对包根算。
# （有的模块原来把绝对路径写死，本身没 import os —— 这里一并补上）
import os
import os as _osp


def _off_find_bundle(_f):
    """从模块所在目录往上找包根（认 fz_boot_server.py）。
    ★ fz_api/*.py 的 __file__ 在 <根>/fz_api/ 下，直接 dirname 会算错一层。"""
    _d = _osp.path.dirname(_osp.path.abspath(_f))
    for _ in range(6):
        if _osp.path.exists(_osp.path.join(_d, 'fz_boot_server.py')):
            return _d
        _u = _osp.path.dirname(_d)
        if _u == _d:
            break
        _d = _u
    return _osp.path.dirname(_osp.path.abspath(_f))


_OFF_BUNDLE = _off_find_bundle(__file__)
_OFF_FZ_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_fz')
_OFF_INK_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_ink')
_OFF_WORK_ROOT = _OFF_BUNDLE
# =====================================================================================
# ★ 2026-10-04 商城空货架修复：客户端资源表解析——PC 开发树优先，设备上自动回退
#   到包内 client_fz 副本（jhserver/client_fz = fangzhi_lua_dec 的同步拷贝）。
def _fz_res(*parts):
    base = os.path.join(_OFF_FZ_ROOT, 'res', 'script')
    if not os.path.isdir(base):
        base = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            '..', 'client_fz', 'res', 'script')
    return os.path.join(base, *parts)

# -*- coding: utf-8 -*-
"""拳脚 / 练功 / 心身 / 天赋（技巧心得）/ 挂机 —— 20 个接口的 1:1 还原。

**契约出处（逐个读过她客户端代码，不是猜的）**

===========================================================================
一、心身（心神）——`app/models/role/xinShen/XinShenSystem.lua` +
    `app/views/ui/AttrUI/JiangHuAttrUI.lua:250-315` +
    `app/presenters/LianGong/XinShenPresenter.lua` /
    `XinShenRecoveryPresenter.lua`
===========================================================================
| 接口(URL 末段)                 | 她读的 `data.字段`                 | 出处 |
|---|---|---|
| `getXinShenValue`              | `curr` `max`（**都参与 `<` 比较与 `..`**，缺一个就崩） | `JiangHuAttrUI.lua:260/:271/:272`、`TeacherLayer.lua:379-380`、`SkillXiuLianLayer.lua:884-885`、`MySelfSkillInfoPresenter.lua:448-449`、`NormalSkillInfoPresenter.lua:171-172` |
| `getXinShenLevel`              | `level`（数字）                     | `JiangHuAttrUI.lua:273` |
| `getXinShenRecoverStartTime`   | `time`（unix 秒，参与 `GetTime()-t` 取模） | `JiangHuAttrUI.lua:274` → `XinShenPresenter.lua:24` |
| `upgradeXinShenLevel`          | `curr` `max`（`setXinShen(data.curr)` / `setXinShenMax(data.max)`） | `XinShenPresenter.lua:228-229` |
| `recoverXinShenValue`          | `curr` `max`                        | `XinShenSystem.lua:106` → 调用方同 `upgradeXinShenLevel` |
`upgradeXinShenLevel` / `recoverXinShenValue` 在
`ServerActionSystem.lua:280-297` / `:333-350` 里都走 **`self:__saveAction(data.dataVer, ...)`**
⇒ 应答**必须带数字 `dataVer`**（`:44 setDataVersion` 拿不到数字直接 `error()`，协程被打断
⇒ 界面卡死、连弹窗都没有）。本模块所有回复都由 `ctx.ok()` 自动补 `dataVer`。

数值来源（她的表，不是我编的）：
  * `res/script/skill/liangongParamsConf.lua["通用参数"]`
      - `17` = 400 → **心神基础上限**（`XinShenSystem:getBaseXinShenMax`）
      - `24` = 300 → **心神恢复间隔(秒)**（`getXinShenRecoverInterval`）
      - `25` = 10  → **每次恢复值**（`getXinShenRecoverValue`）
  * `res/script/skill/maxMindUpgrade.lua["心神上限升级"]` → 每级 `{stage,maxMind,level,deplete}`
      - 心神上限 = 基础 400 + 当前 stage 的 `maxMind`
      - 升级消耗 `deplete` 点**精力**(`jing`)、并要求「任意心法等级 ≥ `level`」（客户端自己会拦）
      - `stage` 条数 = 等级上限（`XinShenResManager:getMaxLevel`）
  * `res/script/skill/mindRecoverItems.lua["心神回复道具"]` → `minditem1..4` 的 `effect`
      （清心散 50 / 谧心丸 100 / 凝心露 200 / 聚心丹 500），`recoverXinShenValue` 的
      `value` 就是她那边算好的 `effect`（DebugLayer 才直接手输数字）。

===========================================================================
二、练功体力（笃志）——`ServerActionSystem:getLianGongTiLi`(:352) +
    `TeacherLayer.lua:376` / `LianGongPresenter.lua:116-120` /
    `NormalSkillInfoPresenter.lua:168`
===========================================================================
* `get_liangong_tili` 的 URL（`app/extends/Http/HttpManager.lua:4636`）就是 `get_liangong_tili`，
  函数名是 `getLianGongTiLi`。
* 她只读 **`currTiLi` `maxTiLi`** 两个字段：
  `layer:setTiLi(tiliData.currTiLi)` / `layer:setTiLiMax(tiliData.maxTiLi)`
  （`TeacherLayer.lua:381-382`、`MySelfSkillInfoPresenter.lua:450-451`、
   `NormalSkillInfoPresenter.lua:173-174`、`SkillXiuLianLayer.lua:886-887`），
  两个都会进 `tili.."/"..tiliMax` 的字符串拼接 ⇒ **必须是数字**。
* 上限/消耗倍率也来自 `liangongParamsConf.lua["通用参数"]` 的 `29`(=0.2224，笃志换算)、
  `28`(=0.128，笃志加成)，客户端自己算「可投入上限 = costXinShen * 29」。

===========================================================================
三、天赋（技巧心得）——`app/models/FistFootSystem/FistFootSystem.lua` +
    `app/models/FistFootSystem/TalentPage/BasicTalentPage.lua` +
    `app/presenters/FistFoot/TalentPagePresenter.lua`
===========================================================================
| 接口 | 她读的字段 | 出处 |
|---|---|---|
| `get_talent_info`     | `resetCount`(数字) `currPageIndex`(数字) `list`(**数组**)；每页 `{feelPoint, branchInfo}` | `FistFootMenuPresenter.lua:139-141` → `BasicTalentPage:__init` |
| `switch_talent_page`  | 同上：`feelPoint` + `branchInfo`（**缺一个她就 `error("返回数据错误，请联系服务器")`**） | `ServerActionSystem.lua:810-826` → `FistFootSystem:changeTelentPage:1274-1282` |
| `get_characterPool_info` | `characterList`（**数组**，元素 `{id, state}`）；`CharacterInfoPresenter:setCharacterList` 会 `table.sort` 并读 `.state`/`.id` | `ComprehendCharacterPresenter.lua:214` → `CharacterInfoPresenter.lua:33-49` |
| `grasp_technique_feature` | `characterInfo[techniqueId].characterId`（**table，按技巧id取**）+ `characterPoint`(数字) | `FistFootSystem:extractCharacter:803-811` |
| `replace_technique_feature` | 无（只看 errcode） | `FistFootSystem:replaceCharacter:848-866` |
| `upgrade_technique`   | `lv`(数字，`tech:upgradeLevel(data.lv)`) `feelPoint`(数字) `cost`(数字) | `FistFootSystem:upgradeTechnique:770-777` |
* `branchInfo` 结构（`FistFootSystem.lua:19-86` 的默认表 + `:164-231` 的读法）：
  `{ [branchType] = {exp, costTechnique, techniqueList=[{id,lv,branchId}],
                      characterInUse=[{techniqueId,characterId}],
                      characterUnused=[{techniqueId,characterId}] } }`
  branchType 取自 `res/script/fistFoot/branchLevel.lua["1"]` 的 `type`：
  **10010 拳法 / 10020 掌法 / 10030 爪法 / 10040 指法 / 10050 腿法**。
* 页数上限 = `res/script/fistFoot/fistFootConst.lua["data"].skillpageUL.content` = **10**
  （`TalentPagePresenter:__init:19-21` 用它算列表格子）。
* 回溯消耗 = `res/script/fistFoot/techniqueReset.lua["1"]`
  `{recall=N, type=1(元宝), count=1500..5000}`，`recall` 就是该页已回溯次数
  （`FistFootResManager:getResetData/getMaxResetCount`）。
* 技巧等级/谙技/升级消耗 = `res/script/fistFoot/techniqueLevel.lua["1"]`
  `{skillid, skilllv, type(分支), jqdamage(谙技), skillcon(升级消耗感悟点), papool(特性池), resource}`
* 特性 = `res/script/fistFoot/character.lua["1"]` `{peculiarityid, level, ...}`；
  特性池 = `res/script/fistFoot/characterPool.lua["1"]` `{papool, weight, peculiarityid}`。
  ★ 关键：`FistFootSystem:extractCharacter:803` 拿到 `characterId` 后立刻
    `getFistFootEffect(characterId, 技巧当前等级)` → `getCharacterData(id, lv)`，
    **查不到就 assert 抛错**⇒ 必须选一个「该 `peculiarityid` 在该等级真有记录」的特性。

===========================================================================
四、挂机 ——`app/models/Task2/HangUpTaskSystem.lua`
===========================================================================
| 接口 | 她读的字段 | 出处 |
|---|---|---|
| `start_hang_up_task` | `start_time`（参与 `SetTime` 与 `currTime + TaskConst.MaxHangUpTime`）`version` | `HangUpTaskSystem.lua:316` `:339` |
| `stop_hang_up_task`  | 无（奖励由**客户端** `CalHangUpTaskRewards` 算好回传；`rewardInfos` 是她本地对象） | `HangUpTaskSystem.lua:500-581` |
| `get_hangUp_yashi_time` | `data` **本身是数组**，元素 `{start_time, end_time}`（`ipairs`） | `HangUpTaskSystem.lua:787-797` |
| `record_click_task`  | 无（只看 errcode） | `HangUpTaskSystem.lua:230-275` |
* `MaxHangUpTime = 72*3600`（`TaskConst.lua:31`）。
* 雅士加成倍率 `yaShiAwardExpAdd = 0.15`（`res/script/HangUpTask/hangUpTaskConst.lua`）。
* 挂机任务表 = `res/script/HangUpTask/hangUpTaskConfig.lua["挂机任务"]`（12 条，`taskType=1` 才是挂机）。
* 雅士是否生效：角色存档 `yaShi`（0/1）+ `yashi`(到期时间戳)，见 `Role.lua:3602-3625`。

===========================================================================
五、招式对练 / 残页 ——`app/models/ActiveSkillPractice/ActiveSkillPracticeModel.lua`
    + `app/presenters/ActiveZhaoPractice/*.lua`
===========================================================================
| 接口 | 她读的字段 | 出处 |
|---|---|---|
| `get_zhao_practiceInfo` | `practice_day_num` `practice_max_num` `curr_num` `max_num`（4 个都进 `..` 拼接 ⇒ 必须数字） | `ActiveZhaoPracticePresenter:initData:68-76`，显示在 `:102` `:106` |
| `zhao_practice`         | `practice_day_num` `curr_num`（+ 可选 `currencyVersion`） | `ActiveZhaoPracticePresenter.lua:352-354` `:423-425`；`ActiveSkillPracticeModel.lua:102-104` 读 `data.currencyVersion` |
| `gift_zhao_page`        | 无（本地把 zhaoId 塞进 `npc.extra.zhaoIdList`、`zhaoLearnNum+1`、残页 -1） | `ActiveSkillPracticeModel.lua:128-145` |
| `forget_zhao_page`      | **`yuanbao_num`**（`User:setRoleAttr("yuanbao", data.yuanbao_num)`） | `ActiveSkillPracticeModel.lua:182` |
* `practice_max_num` = 陪练当前忠诚度等级的 `maxTimes`，来自
  `res/script/others/trainServant.lua["Sheet1"]`（`{levelId, maxTimes, jingSave, baseproficiencyAdd, proficiencyAdd}`），
  忠诚度等级 = `HomelandRoleUtil:getFidelityLv(defaultZhongCheng)`（0/200/500/800/1200/1800/2700 → 1..7）。
* `curr_num`/`max_num` = **凝神丹**数量（`Role:getCHAttrName("ningshendan")`，
  `res/script/others/monetarymanagement.lua["Sheet1"].ningshendan`）。
* 遗忘消耗 = `res/script/others/homeServant.lua["Sheet1"].deleteCostYuanbao.content` = **2300 元宝**
  （`ForgetPagePresenter.lua:315` 显示的就是它）。

**状态**：`work/fist_liangong_state.json`（本模块独占，不与 `meridian_state.json` 混）。
    心神（当前/上限/等级/恢复起点）、笃志、技巧等级/特性/天赋页回溯次数、招式页与
    对练次数、挂机版本与进行中的挂机任务，全部读真值、动作真改。
    钱（凝神丹/元宝/银票）**不另造第二份** —— 与 `items_currency.py` /
    `fz_boot_server.py` 共用 `work/homeland_state.json["currency"]`。

**已知还没做 / 做不到的（诚实记录，见文件末尾 `KNOWN_GAPS`）**
"""
import json
import math
import os
import random
import sys
import time

NAME = 'fist_liangong'
TITLE = '拳脚/练功/心身/天赋/挂机'
ENDPOINTS = [
    'getXinShenLevel',
    'getXinShenRecoverStartTime',
    'getXinShenValue',
    'recoverXinShenValue',
    'upgradeXinShenLevel',
    'get_characterPool_info',
    'get_liangong_tili',
    'get_talent_info',
    'switch_talent_page',
    'grasp_technique_feature',
    'replace_technique_feature',
    'upgrade_technique',
    'forget_zhao_page',
    'get_zhao_practiceInfo',
    'gift_zhao_page',
    'zhao_practice',
    'get_hangUp_yashi_time',
    'record_click_task',
    'start_hang_up_task',
    'stop_hang_up_task',
]

STATE = 'fist_liangong_state.json'

KNOWN_GAPS = """\
1) `get_talent_info` / `switch_talent_page` 的 `branchInfo.techniqueList` 一律给 **空表**：
   她的配表里没有「玩家初始该会哪些技巧」的初始值（`get_fist_info` 的旧实现也给空），
   所以「共有谙技」显示 0、「已领悟特性」空。要让面板有内容得有技巧产出玩法
   （修行任务 `fistFoot/tasks.lua` 的 `AwardType.Exp/1` 给分支阅历），不在本模块 20 个接口里。
2) `feelPoint`（感悟点数）的**产出**在她表里查不到（只有消耗：`techniqueLevel.skillcon`），
   按 `get_fist_info` 的旧实现从 0 起；不够时 `upgrade_technique` 回 errcode=1 弹提示，
   不假装成功。`characterPoint`（特性见解）来自 `fistFoot/tasks.lua` 里
   `awards={{4,"characterPoint",N}}` 的修行任务，本模块只做与 `get_fist_info` 一致的记账。
3) `upgrade_technique` 的前提「拳法锻境等级」由 `get_fist_tasks`/`finish_fist_task`
   （**别人的接口，不在本模块清单里**）推进，本模块不校验锻境等级（没有该数据源）。
4) `get_characterPool_info` 的 `state`（是否已解锁）一律给 1（已解锁）：
   解锁条件 `condition`（如「拳法锻境等级 130」）要锻境数据，本模块拿不到 ⇒ 不假装"未解锁"
   （给 0 只是列表里画成灰字，但会让玩家以为功能坏了）。
5) `record_click_task` 的**收益**是她客户端根据 `hangUpTaskRewardConfig.lua` 自己算的，
   服务端只记录；本模块记账不发放。
6) 挂机停止奖励同样由客户端计算后回传（`stop_hang_up_task` 的 `reward` 上行），
   服务端不重复发放、不校验（她那边 `rewardInfos` 本来就是本地对象）。
7) `get_hangUp_yashi_time`：她表里没有「一天中哪几段算雅士时段」的配置，
   只能按角色存档的雅士到期时间与挂机起点求交集（`Role.lua:3602-3625`）。
   无雅士 → 回空数组（她 `MapIsEmpty` 判断，正确行为）。
8) **精力(`jing`) 不做"第二份账"**：现值 = `roles/full.json.jing` 减去本模块记的
   `jingSpent`（`work/fist_liangong_state.json`）。她客户端本地也会 `addAttr("jing",-costJing)`，
   所以真实扣减是"客户端本地 + 本模块记账"两处同时发生，服务端只保证
   `get_zhao_practiceInfo` / `zhao_practice` 回的 `curr_num` 与 `max_num` 是真数字。
   角色存档 `roles/full.json` **只读、绝不改写**。
9) 角色属性读取带 **30 秒缓存**（`_role_cache`）：刚买雅士后最迟 30 秒才会在
   `get_hangUp_yashi_time` 里体现（客户端自己会 `updateYaShiStatus` 立刻刷新画面）。
"""

# ---------------------------------------------------------------------------
# 她的资源表
# ---------------------------------------------------------------------------
RES_ROOT = _fz_res()
RES_LIANGGONG_CONF = os.path.join(RES_ROOT, 'skill', 'liangongParamsConf.lua')
RES_MAX_MIND = os.path.join(RES_ROOT, 'skill', 'maxMindUpgrade.lua')
RES_MIND_ITEMS = os.path.join(RES_ROOT, 'skill', 'mindRecoverItems.lua')
RES_FIST_CONST = os.path.join(RES_ROOT, 'fistFoot', 'fistFootConst.lua')
RES_BRANCH_LEVEL = os.path.join(RES_ROOT, 'fistFoot', 'branchLevel.lua')
RES_TECHNIQUE_LEVEL = os.path.join(RES_ROOT, 'fistFoot', 'techniqueLevel.lua')
RES_TECHNIQUE_RESET = os.path.join(RES_ROOT, 'fistFoot', 'techniqueReset.lua')
RES_CHARACTER = os.path.join(RES_ROOT, 'fistFoot', 'character.lua')
RES_CHARACTER_POOL = os.path.join(RES_ROOT, 'fistFoot', 'characterPool.lua')
RES_TRAIN_SERVANT = os.path.join(RES_ROOT, 'others', 'trainServant.lua')
RES_HOME_SERVANT = os.path.join(RES_ROOT, 'others', 'homeServant.lua')
RES_HANGUP_TASK = os.path.join(RES_ROOT, 'HangUpTask', 'hangUpTaskConfig.lua')

# 角色存档（fz_boot_server.py 里 `--role ours` 下发的就是 roles/full.json；
# 上传的存档落在 saves/<key>.json）。只读，绝不改写她的存档。
ROLE_FULL = 'roles/full.json'

_TABLES = {}

# 心神恢复参数兜底（`liangongParamsConf` 读不到时才用；值就是表里的 17/24/25）
FALLBACK_BASE_XINSHEN_MAX = 400
FALLBACK_RECOVER_INTERVAL = 300
FALLBACK_RECOVER_VALUE = 10
# 笃志兜底（角色存档里没有 `lianGongTiLi` 时给一份能让面板真的有用的初始值）
FALLBACK_TILI = 100




def _here():
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _lua_table(path):
    """用 `work/fz_luatable.py` 解析她的数据表；失败返回 {}（绝不抛）。"""
    if path in _TABLES:
        return _TABLES[path]
    val = {}
    try:
        try:
            import fz_luatable
        except ImportError:
            sys.path.insert(0, _here())
            import fz_luatable
        val = fz_luatable.load_lua_table(path) or {}
        if not isinstance(val, dict):
            val = {}
    except Exception:                          # noqa: BLE001
        val = {}
    _TABLES[path] = val
    return val


def _num(v, d=0):
    try:
        if v is None or v == '' or isinstance(v, bool):
            return d
        return int(float(v))
    except (TypeError, ValueError):
        return d


def _fnum(v, d=0.0):
    try:
        if v is None or v == '' or isinstance(v, bool):
            return d
        return float(v)
    except (TypeError, ValueError):
        return d


def _s(v):
    return '' if v is None else str(v)


def _now():
    return int(time.time())


def _uid(ctx):
    return str(ctx.headers.get('userid') or ctx.headers.get('uuid') or 'local')


# ---------------------------------------------------------------------------
# 读她的表
# ---------------------------------------------------------------------------
def _lg_conf():
    """`liangongParamsConf.lua["通用参数"]` → {id(str): float}。"""
    t = _lua_table(RES_LIANGGONG_CONF)
    conf = t.get('通用参数') or {}
    out = {}
    for k, v in (conf or {}).items():
        if isinstance(v, dict):
            out[str(k)] = _fnum(v.get('content'))
    return out


def _conf(key, default):
    v = _lg_conf().get(str(key))
    return default if v is None else v


def _mind_upgrades():
    """`maxMindUpgrade.lua["心神上限升级"]` → {stage(int): row}（按 stage 排序）。"""
    t = _lua_table(RES_MAX_MIND)
    raw = t.get('心神上限升级') or {}
    out = {}
    for v in (raw or {}).values():
        if isinstance(v, dict):
            st = _num(v.get('stage'))
            if st > 0:
                out[st] = v
    return out


def _mind_item_effect(item_id):
    t = _lua_table(RES_MIND_ITEMS)
    it = (t.get('心神回复道具') or {}).get(_s(item_id))
    return _num((it or {}).get('effect')) if isinstance(it, dict) else 0


def _fist_conf(key, default=None):
    t = _lua_table(RES_FIST_CONST)
    row = (t.get('data') or {}).get(_s(key))
    if isinstance(row, dict) and 'content' in row:
        return row.get('content')
    return default


def _branch_types():
    """所有拳脚分支 type（`branchLevel.lua`）—— 10010 拳法 … 10050 腿法。"""
    t = _lua_table(RES_BRANCH_LEVEL)
    seen = []
    for v in (t.get('1') or {}).values():
        if isinstance(v, dict):
            ty = _s(v.get('type'))
            if ty and ty not in seen:
                seen.append(ty)
    if not seen:                                # 表读不到 → 用她 `FistFootSystem.lua:19-83` 的默认分支
        seen = ['10010', '10020', '10030', '10040', '10050']
    return sorted(seen)


def _technique_levels():
    """`techniqueLevel.lua["1"]` → {skillid(str): {skilllv(int): row}}（惰性建索引，缓存）。"""
    key = '__tech_idx__'
    if key in _TABLES:
        return _TABLES[key]
    t = _lua_table(RES_TECHNIQUE_LEVEL)
    idx = {}
    for v in (t.get('1') or {}).values():
        if not isinstance(v, dict):
            continue
        sid = _s(v.get('skillid'))
        lv = _num(v.get('skilllv'))
        if sid and lv:
            idx.setdefault(sid, {})[lv] = v
    _TABLES[key] = idx
    return idx


def _technique_row(skill_id, lv):
    return (_technique_levels().get(_s(skill_id)) or {}).get(_num(lv))


def _technique_max_lv(skill_id):
    grp = _technique_levels().get(_s(skill_id)) or {}
    return max(grp) if grp else 0


def _technique_resets():
    """`techniqueReset.lua["1"]` → {recall(int): {type,count}}。"""
    t = _lua_table(RES_TECHNIQUE_RESET)
    out = {}
    for v in (t.get('1') or {}).values():
        if isinstance(v, dict):
            out[_num(v.get('recall'))] = v
    return out


def _characters():
    """`character.lua["1"]` → {peculiarityid(str): {level(int): row}}。"""
    key = '__char_idx__'
    if key in _TABLES:
        return _TABLES[key]
    t = _lua_table(RES_CHARACTER)
    idx = {}
    for v in (t.get('1') or {}).values():
        if not isinstance(v, dict):
            continue
        pid = _s(v.get('peculiarityid'))
        lv = _num(v.get('level'))
        if pid and lv:
            idx.setdefault(pid, {})[lv] = v
    _TABLES[key] = idx
    return idx


def _character_pools():
    """`characterPool.lua["1"]` → {papool(str): [pool entry, ...]}。"""
    key = '__pool_idx__'
    if key in _TABLES:
        return _TABLES[key]
    t = _lua_table(RES_CHARACTER_POOL)
    idx = {}
    for v in (t.get('1') or {}).values():
        if not isinstance(v, dict):
            continue
        idx.setdefault(_s(v.get('papool')), []).append(v)
    for k in idx:
        idx[k].sort(key=lambda r: _num(r.get('id')))
    _TABLES[key] = idx
    return idx


def _train_servants():
    """`trainServant.lua["Sheet1"]` → {fidelityLv(int): row}。"""
    t = _lua_table(RES_TRAIN_SERVANT)
    out = {}
    for v in (t.get('Sheet1') or {}).values():
        if isinstance(v, dict):
            out[_num(v.get('levelId'))] = v
    return out


def _fidelity_lv(fidelity):
    """`HomelandRoleUtil:getFidelityLv`（0/200/500/800/1200/1800/2700 → 1..7）。"""
    lv = 0
    for v, l in ((0, 1), (200, 2), (500, 3), (800, 4), (1200, 5), (1800, 6), (2700, 7)):
        if _num(fidelity) >= v:
            lv = l
        else:
            break
    return lv or 1


def _hangup_tasks():
    """`hangUpTaskConfig.lua["挂机任务"]` → {taskId(str): row}。"""
    t = _lua_table(RES_HANGUP_TASK)
    raw = t.get('挂机任务') or {}
    out = {}
    for k, v in (raw or {}).items():
        if isinstance(v, dict):
            out[_s(k)] = v
    return out


# ---------------------------------------------------------------------------
# 读角色存档（只读，用来拿精力/陪练忠诚度/雅士到期这类"她自己的账"）
# ---------------------------------------------------------------------------
def _read_save(filename):
    try:
        p = os.path.join(_here(), filename)
        with open(p, encoding='utf-8') as f:
            d = json.load(f)
        if isinstance(d, list):
            d = d[0] if d else {}
        return d if isinstance(d, dict) else {}
    except Exception:                          # noqa: BLE001
        return {}


def _role_attr(ctx, *keys, **kw):
    """从 `roles/full.json`（或最近上传的存档）里取角色属性；取不到回 None。

    `kw['fresh']` 回填「这一份 role 是不是**刚**从磁盘读出来的」——
    只有刚读到的 `jing` 才能用来判断"她那边是不是已经把精力补回来了"
    （见 `_jing_now` 的 `jingHash` 逻辑）。
    """
    fresh_out = kw.get('fresh')
    st = ctx.load_json(STATE, {}) or {}
    uid = _uid(ctx)
    ck = st.get('_role_cache')
    fresh = False
    if isinstance(ck, dict) and ck.get('uid') == uid and ck.get('at', 0) > _now() - 30:
        role = ck.get('role') or {}
    else:
        role = _read_save(ROLE_FULL)
        if not role:
            if fresh_out is not None:
                fresh_out[0] = True
            return None
        st['_role_cache'] = {'uid': uid, 'at': _now(), 'role': role}
        fresh = True
        try:
            ctx.save_json(STATE, st)
        except Exception:                       # noqa: BLE001
            pass
    if fresh_out is not None:
        fresh_out[0] = fresh
    for k in keys:
        if k in role and role[k] is not None:
            return role[k]
    return None


def _jing_now(ctx, st):
    """当前精力。

    ★ 不做"第二份 jing"：现值 = 她角色存档里的 `jing` 减去**本模块本次对账周期内**
      记下的消耗 `jingSpent`。
    ★ 对账周期怎么结束：客户端每次行动后都会把存档（含它自己扣过的 jing）传上来。
      所以只要**刚**读到的那份存档和我们上次记 `jingSpent` 时那份**不是同一份**
      （`jingHash` 变了）⇒ 说明她那边已经自己扣过/补过了，我们**清零** `jingSpent`，
      改以存档现值 + 之后的记账为准。否则（同一份存档的缓存期内）继续累加。
      这样"升级心神上限消耗精力""对练消耗精力"在多次操作间都不会漂。
    """
    fresh = [False]
    v = _role_attr(ctx, 'jing', fresh=fresh)
    if v is None:
        v = st.get('jingBase', 0)
    cur = _num(v)
    h = '%d|%d' % (cur, _jing_max(ctx))
    if fresh[0] and _s(st.get('jingHash')) != h:
        # 新观察到的一份存档：它的 jing 已经包含她之前的扣减 ⇒ 旧账清零
        if _num(st.get('jingSpent')):
            _mark(st, 'jing', '存档 jing=%d 变了（旧账 %d 清零）' % (cur, _num(st.get('jingSpent'))))
        st['jingSpent'] = 0
        st['jingHash'] = h
    elif not _s(st.get('jingHash')):
        st['jingHash'] = h
    return max(0, cur - _num(st.get('jingSpent', 0)))


def _spend_jing(ctx, st, n):
    """扣 `n` 点精力（记账）；不够回 False。"""
    n = abs(_num(n))
    if n <= 0:
        return True
    have = _jing_now(ctx, st)
    if have < n:
        return False
    st['jingSpent'] = _num(st.get('jingSpent')) + n
    return True


def _jing_max(ctx):
    v = _role_attr(ctx, 'jingMax')
    return _num(v, 0)


def _fidelity_lv_of(ctx):
    """陪练忠诚度等级 —— 存档里 `homeLandRoleData.peilian001.defaultZhongCheng`。"""
    d = _role_attr(ctx, 'homeLandRoleData')
    if isinstance(d, dict):
        pei = d.get('peilian001')
        if isinstance(pei, dict) and pei.get('defaultZhongCheng') is not None:
            return _fidelity_lv(pei.get('defaultZhongCheng'))
    return 1


# ---------------------------------------------------------------------------
# 钱袋子（与 items_currency.py / fz_boot_server.py 共用 homeland_state.json["currency"]）
# ---------------------------------------------------------------------------
def _items():
    try:
        try:
            from fz_api import items_currency
        except ImportError:
            sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
            import items_currency                       # type: ignore
        return items_currency
    except Exception:                          # noqa: BLE001
        return None


def _get_currency(ctx, kind):
    m = _items()
    if m is None:
        home = ctx.load_json('homeland_state.json', {}) or {}
        cur = home.get('currency') if isinstance(home.get('currency'), dict) else {}
        return _num((cur or {}).get(_s(kind)))
    try:
        return _num(m.get_currency(ctx, kind))
    except Exception:                          # noqa: BLE001
        return 0


def _add_currency(ctx, kind, n):
    """真写盘；`n<0` 且不够回 None。"""
    m = _items()
    if m is None:
        return None
    try:
        return m.add_currency(ctx, kind, n)
    except Exception:                          # noqa: BLE001
        return None


def _item_count(ctx, item_id):
    m = _items()
    if m is None:
        return 0
    try:
        return _num(m.get_count(ctx, item_id))
    except Exception:                          # noqa: BLE001
        return 0


def _take_item(ctx, item_id, n=1):
    m = _items()
    if m is None:
        return False
    try:
        return bool(m.spend(ctx, item_id, n))
    except Exception:                          # noqa: BLE001
        return False


# ---------------------------------------------------------------------------
# 状态
# ---------------------------------------------------------------------------
def _blank():
    return {
        'version': 0,
        # ---- 心身 ----
        'xsLevel': 0,            # 已提升次数（0 = 基础 400 上限）
        'xsCurr': -1,            # -1 = 还没初始化（第一次读时按上限填满）
        'xsRecoverStart': 0,     # 恢复计时起点（unix 秒）
        'xsLast': 0,             # xsCurr 的最后结算时间（心跳恢复用）
        # ---- 练功笃志 ----
        'tili': -1,
        'tiliMax': -1,
        # ---- 天赋（技巧心得）----
        'feelPoint': 0,
        'characterPoint': 0,
        'currPageIndex': 1,
        'techLv': {},            # {"技巧id": 等级}
        'charInUse': {},         # {"技巧id": [characterId,...]}（已装备特性）
        'charUnused': {},        # {"技巧id": [characterId,...]}（已抽取未装备）
        'pageReset': {},         # {"页码": 已回溯次数}
        # ---- 招式对练（陪练）----
        'npcZhao': {},           # {"npcId": [zhaoId,...]}
        'practiceDay': '',       # YYYYMMDD
        'practiceNum': {},       # {"npcId": 今日已对练次数}
        # ---- 挂机 ----
        'hangupVersion': 0,
        'hangupTaskId': '',
        'hangupStart': 0,
        'clickDaily': {},        # {"taskId": [YYYYMMDD, 次数]}（打工点击记账）
        # ---- 记账 ----
        'jingSpent': 0,          # 本对账周期内已消耗的精力（见 `_jing_now`）
        'jingHash': '',          # 上次记 `jingSpent` 时那份存档的 (jing|jingMax)
        'log': [],
    }


def _load(ctx):
    st = ctx.load_json(STATE, None)
    if not isinstance(st, dict):
        st = {}
    for k, v in _blank().items():
        if k not in st or st[k] is None:
            st[k] = v
    for k in ('techLv', 'charInUse', 'charUnused', 'pageReset', 'npcZhao',
              'practiceNum', 'clickDaily'):
        if not isinstance(st.get(k), dict):
            st[k] = {}
    for k in ('charInUse', 'charUnused', 'npcZhao'):
        for kk, vv in list(st[k].items()):
            if not isinstance(vv, list):
                st[k][kk] = []
    if not isinstance(st.get('log'), list):
        st['log'] = []
    today = time.strftime('%Y%m%d')
    if st.get('practiceDay') != today:          # 每日对练次数刷新
        st['practiceDay'] = today
        st['practiceNum'] = {}
    return st


def _save(ctx, st):
    st['log'] = st.get('log', [])[-120:]
    st['userid'] = _uid(ctx)
    st['updated'] = _now()
    ctx.save_json(STATE, st)
    return st


def _mark(st, who, msg):
    st.setdefault('log', []).append('%d %s %s' % (_now(), who, msg))


def _bump(st):
    st['version'] = _num(st.get('version')) + 1
    return st['version']


# ---------------------------------------------------------------------------
# 心身
# ---------------------------------------------------------------------------
def _xs_max_of_level(lv):
    """心神上限 = 基础(400) + maxMindUpgrade[stage=lv+1].maxMind。"""
    base = int(_conf('17', FALLBACK_BASE_XINSHEN_MAX))
    ups = _mind_upgrades()
    stage = _num(lv) + 1
    row = ups.get(stage)
    if row is None and ups:                     # 超出表范围 → 用最后一级
        row = ups[max(ups)]
    return base + _num((row or {}).get('maxMind'))


def _xs_sync(ctx, st):
    """按 `liangongParamsConf` 的恢复规则把心神结算到"现在"。返回 (curr, max)。"""
    interval = int(_conf('24', FALLBACK_RECOVER_INTERVAL)) or FALLBACK_RECOVER_INTERVAL
    per = int(_conf('25', FALLBACK_RECOVER_VALUE)) or FALLBACK_RECOVER_VALUE
    # ★ 2026-10-17 v36b：心神上限提升礼包（xsCap99999）⇒ 上限固定 99999（客户要求）。
    if st.get('xsCap99999'):
        mx = 99999
    else:
        mx = _xs_max_of_level(st.get('xsLevel'))
    if _num(st.get('xsCurr'), -1) < 0:
        # 第一次：给满（她面板的"当前/上限"才不是 0/0）
        st['xsCurr'] = mx
        st['xsLast'] = _now()
        st['xsRecoverStart'] = 0
        return st['xsCurr'], mx
    curr = max(0, min(_num(st.get('xsCurr')), mx))
    last = _num(st.get('xsLast')) or _now()
    now = _now()
    if curr < mx and now > last:
        ticks = (now - last) // interval
        if ticks > 0:
            curr = min(mx, curr + ticks * per)
            last += ticks * interval
            st['xsLast'] = last
    if curr >= mx:
        st['xsRecoverStart'] = 0
    elif not _num(st.get('xsRecoverStart')):
        # 不满且没有恢复起点 → 从现在开始计时（她 `(GetTime()-time) % interval`）
        st['xsRecoverStart'] = now
        st['xsLast'] = now
    st['xsCurr'] = curr
    return curr, mx


# ---------------------------------------------------------------------------
# 天赋（技巧心得）页
# ---------------------------------------------------------------------------
def _page_count():
    n = _num(_fist_conf('skillpageUL', 10), 10)
    return n if n > 0 else 10


def _branch_info_of(page_index, st):
    """构造一页的 `branchInfo`（结构照 `FistFootSystem.lua:19-86` + `:164-231`）。"""
    idx = _num(page_index)
    out = {}
    for bt in _branch_types():
        tech_list = {}
        for tid, lv in (st.get('techLv') or {}).items():
            row = _technique_row(tid, lv)
            if row is None:
                continue
            if _s(row.get('type')) != _s(bt):
                continue
            tech_list[_s(tid)] = {'id': _s(tid), 'lv': _num(lv), 'branchId': _s(bt)}
        in_use = []
        unused = []
        if idx == _num(st.get('currPageIndex'), 1):
            for tid, ids in (st.get('charInUse') or {}).items():
                for cid in (ids or []):
                    in_use.append({'techniqueId': _s(tid), 'characterId': _s(cid)})
            for tid, ids in (st.get('charUnused') or {}).items():
                for cid in (ids or []):
                    unused.append({'techniqueId': _s(tid), 'characterId': _s(cid)})
        out[_s(bt)] = {
            'exp': 0,
            'costTechnique': 0,
            'techniqueList': tech_list,
            'characterInUse': in_use,
            'characterUnused': unused,
        }
    return out


def _page_data(page_index, st):
    return {
        'feelPoint': _num(st.get('feelPoint')),
        'branchInfo': _branch_info_of(page_index, st),
    }


def _reset_count(st):
    return len([1 for v in (st.get('pageReset') or {}).values() if _num(v) > 0])


def _reset_cost(recall):
    """第 `recall+1` 次回溯的消耗（`techniqueReset.lua`）。"""
    rows = _technique_resets()
    if not rows:
        return None, 0
    nxt = _num(recall) + 1
    row = rows.get(nxt) or rows[max(rows)]
    return row, _num((row or {}).get('count'))


# ---------------------------------------------------------------------------
# 特性
# ---------------------------------------------------------------------------
def _pick_character(papool, level):
    """按 `weight` 从特性池里挑一个「在该等级真有记录」的特性，返回 peculiarityid(str)。"""
    pool = _character_pools().get(_s(papool)) or []
    chars = _characters()
    cand = [e for e in pool if _num(level) in (chars.get(_s(e.get('peculiarityid'))) or {})]
    if not cand:
        return ''
    total = sum(max(0, _num(e.get('weight'))) for e in cand)
    if total <= 0:
        return _s(random.choice(cand).get('peculiarityid'))
    r = random.uniform(0, total)
    acc = 0.0
    for e in cand:
        acc += max(0, _num(e.get('weight')))
        if r <= acc:
            return _s(e.get('peculiarityid'))
    return _s(cand[-1].get('peculiarityid'))


def _technique_of_id(ctx):
    return _s(ctx.param('techniqueId') or ctx.param('techniqueid') or '')


# ---------------------------------------------------------------------------
# 招式对练
# ---------------------------------------------------------------------------
def _zhao_list_of(st, npc_id):
    v = (st.get('npcZhao') or {}).get(_s(npc_id))
    return list(v) if isinstance(v, list) else []


def _practice_max(ctx):
    """今日对练次数上限 = 陪练忠诚度等级的 `trainServant.maxTimes`。"""
    lv = _fidelity_lv_of(ctx)
    row = _train_servants().get(lv) or _train_servants().get(1) or {}
    n = _num((row or {}).get('maxTimes'))
    return n if n > 0 else 2                      # 表读不到时她 Lv1 就是 2


def _npc_id(ctx):
    return _s(ctx.param('npcId') or ctx.param('npcid') or '')


# ---------------------------------------------------------------------------
# 残页物品（`gift_zhao_page` / `forget_zhao_page` 用）
#
# 契约：`ActiveSkillPracticeModel.lua:122-145` 上行只给 `npcId`/`mid`/`zhaoId`，
# 成功回调里 `self.__role:addZhaoShuXiang(itemId, -1)`（`:141`）说明 **itemId 就是 zhaoId**。
# 她 `res/script/store/shoplist.lua` 里的残页道具形如
#   id="500001", itemId="xiaoyaoyiguncanye", name="一棍逍遥残页"
# 而 `Role_Item:getZhaoShuXiangItems()`（`:95`）挑的是 `itemId` 里含 "canye" 的道具
#   （`CommonResults.lua:3385` 用的键就是 "biluohuangquancanye"）。
# ⇒ 这里按 ①zhaoId 原样 ②shoplist 里 itemId==zhaoId 的商品键 ③zhaoId 去重后与
#   残页 itemId 互查 的顺序找一件真残页；一件都找不到时**不假装成功**（errcode=1）。
# ---------------------------------------------------------------------------
RES_SHOPLIST = os.path.join(RES_ROOT, 'store', 'shoplist.lua')


def _shoplist():
    t = _lua_table(RES_SHOPLIST)
    return t.get('Sheet1') or {}


def _shop_index():
    """{itemId(str小写): [商品键, ...]} —— 只建一次，避免每次扫 764 条商品。"""
    key = '__shop_idx__'
    if key in _TABLES:
        return _TABLES[key]
    idx = {}
    for gid, v in (_shoplist() or {}).items():
        if not isinstance(v, dict):
            continue
        iid = _s(v.get('itemId')).lower()
        if iid:
            idx.setdefault(iid, []).append(_s(gid))
    _TABLES[key] = idx
    return idx


def _page_item_ids(zhao_id):
    """返回候选残页物品键（按优先级）。"""
    z = _s(zhao_id).lower()
    if not z:
        return []
    out = [z]
    if not z.endswith('canye'):
        out.append(z + 'canye')
    idx = _shop_index()
    for cand in (z, z + 'canye' if not z.endswith('canye') else ''):
        if not cand:
            continue
        for gid in (idx.get(cand) or []):
            out.append(gid)
            out.append(cand)
    seen = []
    for x in out:
        if x and x not in seen:
            seen.append(x)
    return seen


def _page_item_count(ctx, zhao_id):
    """最优先一件候选残页的持有数（持有最多的那件）。"""
    best = 0
    for iid in _page_item_ids(zhao_id):
        n = _item_count(ctx, iid)
        if n > best:
            best = n
    return best


def _take_page_item(ctx, zhao_id):
    """真扣一张残页，返回扣到的物品键；扣不到返回 ''。"""
    for iid in _page_item_ids(zhao_id):
        if _item_count(ctx, iid) >= 1 and _take_item(ctx, iid, 1):
            return iid
    return ''


# ---------------------------------------------------------------------------
# 挂机
# ---------------------------------------------------------------------------
def _yashi_expired(ctx):
    v = _role_attr(ctx, 'yashi', 'yaShiExpiredTime')
    return _num(v)


def _yashi_active(ctx):
    v = _role_attr(ctx, 'yaShi')
    if v is None:
        return _yashi_expired(ctx) > _now()
    return _num(v) == 1


MAX_HANGUP_TIME = 72 * 3600                       # `TaskConst.lua:31`


# ===========================================================================
# 接口实现
# ===========================================================================
def _ep_get_xinshen_value(ctx, st):
    curr, mx = _xs_sync(ctx, st)
    _save(ctx, st)
    return ctx.ok({'curr': curr, 'max': mx},
                  '★ 心神 %d/%d（上限=基础400+maxMindUpgrade[stage=%d]）'
                  % (curr, mx, _num(st.get('xsLevel')) + 1))


def _ep_get_xinshen_level(ctx, st):
    # `XinShenSystem.lua:69` → `JiangHuAttrUI.lua:273 layer:setXinShenMaxLevel(levelData.level)`
    # ★ 这个 level 是**表里的 stage 号**，`script/skill/maxMindUpgrade.lua` 只有 stage≥1（没有 0）。
    #   回 0 的话 `XinShenPresenter:setXinShenMaxUi`(:128 `getXinShenMaxUpgradeDataByLevel(level)`)
    #   拿到 nil，:161 `currXinShenData.maxMind` 直接抛错（被 xpcall 吞）⇒ 面板卡死 +
    #   客户端一直重试 getXinShenLevel ⇒ 界面上就是「网络错误，请重试」。
    #   我们内部 xsLevel = 已升级次数 ⇒ 对外 level = xsLevel + 1。
    ups = _mind_upgrades()
    lv = _num(st.get('xsLevel')) + 1
    if ups:
        lv = max(1, min(lv, len(ups)))
    return ctx.ok({'level': lv},
                  '★ 心神上限等级 = %d（表里共 %d 级）'
                  % (lv, max(1, len(ups))))


def _ep_get_xinshen_recover_time(ctx, st):
    _xs_sync(ctx, st)
    _save(ctx, st)
    # `JiangHuAttrUI.lua:274 setRecoverTime(recoverData.time)`；满了给 0（她满值分支自己给 0）
    t = _num(st.get('xsRecoverStart'))
    return ctx.ok({'time': t},
                  '★ 心神恢复计时起点 = %d' % t)


def _ep_recover_xinshen(ctx, st):
    value = _num(ctx.param('value'))
    curr, mx = _xs_sync(ctx, st)
    new = max(0, min(mx, curr + max(0, value)))
    st['xsCurr'] = new
    st['xsLast'] = _now()
    if new < mx and not _num(st.get('xsRecoverStart')):
        st['xsRecoverStart'] = _now()
    if new >= mx:
        st['xsRecoverStart'] = 0
    _mark(st, 'recoverXinShenValue', '+%d → %d/%d' % (value, new, mx))
    _save(ctx, st)
    # `ServerActionSystem.lua:342 __saveAction(data.dataVer, ...)` ⇒ dataVer 由 ctx.ok 补
    return ctx.ok({'curr': new, 'max': mx}, '★ 恢复心神 +%d → %d/%d' % (value, new, mx))


def _ep_upgrade_xinshen_level(ctx, st):
    ups = _mind_upgrades()
    lv = _num(st.get('xsLevel'))
    stage = lv + 2                       # ★ 要**升到**的 stage（内部 xsLevel=已升级次数）
    nxt = ups.get(stage)                 #   升到 stage 的消耗/加成都在这一行
    if nxt is None:
        return ctx.fail('心神上限已达最高等级',
                        '★ 提升心神上限：已满级（当前 stage=%d / 共 %d）' % (lv + 1, len(ups)))
    deplete = _num(nxt.get('deplete'))
    if deplete > 0 and not _spend_jing(ctx, st, deplete):
        return ctx.fail('心神上限升级消耗的资源不足',
                        '★ 提升心神上限需要 %d 精力，当前 %d' % (deplete, _jing_now(ctx, st)))
    st['xsLevel'] = lv + 1
    mx = _xs_max_of_level(st['xsLevel'])
    curr = max(0, min(_num(st.get('xsCurr')), mx))
    if curr < mx and not _num(st.get('xsRecoverStart')):
        st['xsRecoverStart'] = _now()
        st['xsLast'] = _now()
    st['xsCurr'] = curr
    _mark(st, 'upgradeXinShenLevel', 'stage %d → 上限 %d（消耗 %d 精力）' % (stage, mx, deplete))
    _save(ctx, st)
    # `XinShenPresenter.lua:228-229` setXinShen(data.curr) / setXinShenMax(data.max)
    return ctx.ok({'curr': curr, 'max': mx},
                  '★ 提升心神上限 → stage %d（上限 %d，耗 %d 精力）' % (stage, mx, deplete))


def _ep_get_liangong_tili(ctx, st):
    if _num(st.get('tiliMax'), -1) < 0:
        # 第一次：上限取存档里的 `lianGongTiLi`（有就用她的真值），否则给一份可用初值
        mx = _num(_role_attr(ctx, 'lianGongTiLi'), FALLBACK_TILI)
        st['tiliMax'] = mx if mx > 0 else FALLBACK_TILI
        st['tili'] = st['tiliMax']
    mx = _num(st.get('tiliMax'))
    curr = max(0, min(_num(st.get('tili')), mx))
    st['tili'] = curr
    _save(ctx, st)
    # `TeacherLayer.lua:381-382` 读 currTiLi / maxTiLi，两个都会进字符串拼接
    return ctx.ok({'currTiLi': curr, 'maxTiLi': mx},
                  '★ 笃志 %d/%d（练功/修炼加速用）' % (curr, mx))


def _ep_get_talent_info(ctx, st):
    pages = _page_count()
    lst = [_page_data(i + 1, st) for i in range(pages)]
    _save(ctx, st)
    # `FistFootMenuPresenter.lua:139-141` 读 resetCount / currPageIndex / list
    return ctx.ok({'resetCount': _reset_count(st),
                   'currPageIndex': _num(st.get('currPageIndex'), 1),
                   'list': lst},
                  '★ 技法心得 %d 页（当前第 %d 页，已回溯 %d 页）'
                  % (pages, _num(st.get('currPageIndex'), 1), _reset_count(st)))


def _ep_switch_talent_page(ctx, st):
    page = _num(ctx.param('pageIndex') or ctx.param('pageNum'))
    pages = _page_count()
    if page <= 0 or page > pages:
        return ctx.fail('页码错误', '★ 切换技法心得：pageIndex=%s 越界（1..%d）' % (page, pages))
    st['currPageIndex'] = page
    _mark(st, 'switchTalentPage', '当前页 → %d' % page)
    _save(ctx, st)
    data = _page_data(page, st)
    # ★ `FistFootSystem.lua:1274` 缺 branchInfo 或 feelPoint 会直接 error ⇒ 两个都必须给
    return ctx.ok(data, '★ 切换技法心得 → 第 %d 页（feelPoint=%d）'
                  % (page, _num(st.get('feelPoint'))))


def _ep_get_character_pool_info(ctx, st):
    pool_id = _s(ctx.param('papool') or (ctx.args[0] if ctx.args else ''))
    pool = _character_pools().get(pool_id) or []
    if not pool:
        # 特性池 id 不在表里（或探针没带 papool）→ 回空数组（她 `ipairs` 空表安全），并说明
        if not pool_id:
            return ctx.ok({'characterList': []},
                          '★ 特性池：本请求没带 papool（上行 `{papool=dataVer...}`，'
                          '`HttpManager.lua:4973`）⇒ 空列表')
        return ctx.ok({'characterList': []},
                      '★ 特性池 %s：`characterPool.lua` 里没有这个 papool' % pool_id)
    chars = _characters()
    lst = []
    for e in pool:
        cid = _s(e.get('peculiarityid'))
        if not cid or cid not in chars:
            continue
        # `CharacterInfoPresenter.lua:33-49` 读 .id / .state（state==0 画灰字）
        lst.append({'id': cid, 'state': 1})
    if not lst:
        return ctx.ok({'characterList': []},
                      '★ 特性池 %s：池里的特性在 `character.lua` 里都没有定义' % pool_id)
    return ctx.ok({'characterList': lst},
                  '★ 特性池 %s → %d 个特性（characterPool+character 真表）'
                  % (pool_id, len(lst)))


def _ep_upgrade_technique(ctx, st):
    tid = _technique_of_id(ctx)
    if not tid:
        return ctx.fail('技巧参数错误', '★ upgrade_technique：上行没有 techniqueId')
    lv = _num((st.get('techLv') or {}).get(tid), 1)     # 她 `PlayerFistFootTechnique:create(id, 1)` 从 1 起
    nxt = _technique_row(tid, lv + 1)
    if nxt is None and _technique_row(tid, lv) is None:
        return ctx.fail('技巧不存在', '★ upgrade_technique：技巧 %s 不在 techniqueLevel.lua' % tid)
    if nxt is None:
        return ctx.fail('技巧已达最高等级', '★ upgrade_technique：技巧 %s 已满级 %d' % (tid, lv))
    cost = _num(nxt.get('skillcon'))
    feel = _num(st.get('feelPoint'))
    if cost > 0 and feel < cost:
        return ctx.fail('感悟点数不足',
                        '★ upgrade_technique：技巧 %s 升到 %d 级需 %d 感悟点，当前 %d'
                        % (tid, lv + 1, cost, feel))
    st.setdefault('techLv', {})[tid] = lv + 1
    st['feelPoint'] = max(0, feel - cost)
    _mark(st, 'upgradeTechnique', '%s %d→%d（-%d 感悟点）' % (tid, lv, lv + 1, cost))
    _save(ctx, st)
    # `FistFootSystem.lua:770-777` 读 data.lv / data.feelPoint / data.cost
    return ctx.ok({'lv': lv + 1, 'feelPoint': _num(st.get('feelPoint')), 'cost': cost},
                  '★ 提升技巧 %s → Lv%d（耗 %d 感悟点，余 %d）'
                  % (tid, lv + 1, cost, _num(st.get('feelPoint'))))


def _ep_grasp_technique_feature(ctx, st):
    tid = _technique_of_id(ctx)
    if not tid:
        return ctx.fail('技巧参数错误', '★ grasp_technique_feature：上行没有 techniqueId')
    lv = _num((st.get('techLv') or {}).get(tid), 1)
    row = _technique_row(tid, lv)
    if row is None:
        return ctx.fail('技巧不存在',
                        '★ grasp_technique_feature：技巧 %s 等级 %d 不在 techniqueLevel.lua' % (tid, lv))
    pool_id = _s(row.get('papool'))
    if not pool_id or pool_id == '0':
        return ctx.fail('该技巧没有可领悟的特性',
                        '★ grasp_technique_feature：技巧 %s 的 papool=0（不可领悟特性）' % tid)
    cid = _pick_character(pool_id, lv)
    if not cid:
        return ctx.fail('特性池配置缺失',
                        '★ grasp_technique_feature：特性池 %s 在 %d 级没有可用特性' % (pool_id, lv))
    st.setdefault('charUnused', {}).setdefault(tid, [])
    st['charUnused'][tid].append(cid)
    _mark(st, 'extractCharacter', '技巧 %s 领悟特性 %s（池 %s）' % (tid, cid, pool_id))
    _save(ctx, st)
    # ★ `FistFootSystem.lua:803`：`data.characterInfo[tostring(techniqueId)].characterId`
    #   拿不到就 `attempt to index a nil value`；而且这个 characterId 必须能让
    #   `getCharacterData(id, 技巧等级)` 查到（否则 assert 抛错）—— `_pick_character` 已保证。
    return ctx.ok({'characterInfo': {tid: {'characterId': cid}},
                   'characterPoint': _num(st.get('characterPoint'))},
                  '★ 领悟特性：技巧 %s → 特性 %s（池 %s 按 weight 抽）' % (tid, cid, pool_id))


def _ep_replace_technique_feature(ctx, st):
    tid = _technique_of_id(ctx)
    if not tid:
        return ctx.fail('技巧参数错误', '★ replace_technique_feature：上行没有 techniqueId')
    unused = list((st.get('charUnused') or {}).get(tid) or [])
    if not unused:
        return ctx.fail('没有可替换的特性',
                        '★ replace_technique_feature：技巧 %s 没有已抽取未装备的特性' % tid)
    new_cid = unused.pop(0)
    in_use = list((st.get('charInUse') or {}).get(tid) or [])
    old = in_use[0] if in_use else ''
    # `FistFootSystem.lua:855-856`：`removeEffect(1)` 然后把未装备的第 1 个 `insertEffect`
    #   ⇒ 装备位永远只有 1 个；被换下来的**直接丢弃**（她本地也把它从 unUseEffects 里 pop 掉了，
    #     不会再塞回未装备列表，所以服务端跟着丢弃，否则会出现两边列表不一致）。
    st.setdefault('charInUse', {})[tid] = [new_cid]
    st.setdefault('charUnused', {})[tid] = unused
    _mark(st, 'replaceCharacter', '技巧 %s 特性 %s → %s' % (tid, old or '空', new_cid))
    _save(ctx, st)
    # `FistFootSystem.lua:848-866` 只看 ok，不读 data 字段
    return ctx.ok({'techniqueId': tid, 'characterId': new_cid},
                  '★ 替换特性：技巧 %s %s → %s（未装备余 %d）'
                  % (tid, old or '空', new_cid, len(unused)))


def _ep_get_zhao_practice_info(ctx, st):
    npc = _npc_id(ctx)
    mx_prac = _practice_max(ctx)
    day = _num((st.get('practiceNum') or {}).get(npc))
    curr = _get_currency(ctx, 'ningshendan')
    limit = _currency_limit('ningshendan')
    cv = _num((ctx.load_json('items_state.json', {}) or {}).get('currencyVersion'), 1)
    _save(ctx, st)
    # ★ `ActiveZhaoPracticePresenter.lua:68-76` 四个字段全部进字符串拼接 ⇒ 必须数字
    return ctx.ok({'practice_day_num': day, 'practice_max_num': mx_prac,
                   'curr_num': curr, 'max_num': limit,
                   'currencyVersion': cv},
                  '★ 对练详情：今日 %d/%d 次，凝神丹 %d/%d（陪练%s）'
                  % (day, mx_prac, curr, limit, npc or '?'))


def _currency_limit(kind):
    try:
        from fz_api import items_currency
        return _num(items_currency.currency_limit(kind))
    except Exception:                          # noqa: BLE001
        try:
            import items_currency                      # type: ignore
            return _num(items_currency.currency_limit(kind))
        except Exception:                      # noqa: BLE001
            return 9999


def _ep_zhao_practice(ctx, st):
    npc = _npc_id(ctx)
    zhao_id = _s(ctx.param('zhaoId') or ctx.param('zhaoid'))
    ptype = _num(ctx.param('type'), 1)
    price = _num(ctx.param('price'))
    add_exp = _num(ctx.param('addExp'), 0)
    cost_jing = _num(ctx.param('costJing'), 0)
    if not zhao_id:
        return ctx.fail('招式参数错误', '★ zhao_practice：上行没有 zhaoId')
    known = _zhao_list_of(st, npc)
    if zhao_id not in known:
        return ctx.fail('你的陪练没有学习该招式',
                        '★ zhao_practice：陪练 %s 未学招式 %s（已学 %s）'
                        % (npc, zhao_id, ','.join(known) or '无'))
    mx_prac = _practice_max(ctx)
    day = _num((st.get('practiceNum') or {}).get(npc))
    if day >= mx_prac:
        return ctx.fail('今日对练次数已达上限',
                        '★ zhao_practice：陪练 %s 今日已对练 %d/%d 次' % (npc, day, mx_prac))
    if ptype == 2 and price > 0:                 # 潜心（加速）对练：扣凝神丹
        left = _add_currency(ctx, 'ningshendan', -price)
        if left is None:
            return ctx.fail('凝神丹数量不足，无法练习',
                            '★ zhao_practice：潜心对练需 %d 凝神丹，只有 %d'
                            % (price, _get_currency(ctx, 'ningshendan')))
    elif cost_jing > 0:                          # 普通对练：扣精力（记在本模块账上）
        if not _spend_jing(ctx, st, cost_jing):
            return ctx.fail('精力不足，无法对练',
                            '★ zhao_practice：需 %d 精力，当前 %d'
                            % (cost_jing, _jing_now(ctx, st)))
    st.setdefault('practiceNum', {})[npc] = day + 1
    _mark(st, 'zhaoPractice', '陪练 %s 招式 %s +%d 熟练度（type=%d, price=%d, jing=%d）'
          % (npc, zhao_id, add_exp, ptype, price, cost_jing))
    cv = _num((ctx.load_json('items_state.json', {}) or {}).get('currencyVersion'), 1)
    _save(ctx, st)
    # `ActiveZhaoPracticePresenter.lua:352-354` 读 practice_day_num / curr_num
    return ctx.ok({'practice_day_num': day + 1, 'curr_num': _jing_now(ctx, st),
                   'practice_max_num': mx_prac,
                   'max_num': _jing_max(ctx),
                   'currencyVersion': cv},
                  '★ 对练 %s：今日 %d/%d 次，精力 %d/%d'
                  % (zhao_id, day + 1, mx_prac, _jing_now(ctx, st), _jing_max(ctx)))


def _ep_gift_zhao_page(ctx, st):
    npc = _npc_id(ctx)
    zhao_id = _s(ctx.param('zhaoId') or ctx.param('zhaoid'))
    if not zhao_id:
        return ctx.fail('招式参数错误', '★ gift_zhao_page：上行没有 zhaoId')
    known = _zhao_list_of(st, npc)
    if zhao_id in known:
        return ctx.fail('该招式陪练已经学过了',
                        '★ gift_zhao_page：陪练 %s 已学 %s' % (npc, zhao_id))
    # 残页物品：`zhaoId` 就是残页 `itemId`（`ActiveSkillPracticeModel.lua:141` 的
    # `addZhaoShuXiang(itemId,-1)`）；`shoplist.lua` 里残页 itemId 形如 xxxcanye。
    have = _page_item_count(ctx, zhao_id)
    if have < 1:
        return ctx.fail('残页不足，无法赠与',
                        '★ gift_zhao_page：残页 %s 只有 %d 张（候选键 %s）'
                        % (zhao_id, have, ','.join(_page_item_ids(zhao_id)[:3])))
    used = _take_page_item(ctx, zhao_id)
    if not used:
        return ctx.fail('残页不足，无法赠与',
                        '★ gift_zhao_page：扣残页 %s 失败' % zhao_id)
    known.append(zhao_id)
    st.setdefault('npcZhao', {})[npc] = known
    _mark(st, 'giftZhaoPage', '陪练 %s 学会招式 %s（残页 %s -1）' % (npc, zhao_id, used))
    _save(ctx, st)
    return ctx.ok({'zhaoId': zhao_id, 'itemId': used, 'learn_num': len(known)},
                  '★ 赠与残页：陪练 %s 学会 %s（残页 %s -1，现共 %d 招）'
                  % (npc, zhao_id, used, len(known)))


def _ep_forget_zhao_page(ctx, st):
    npc = _npc_id(ctx)
    zhao_id = _s(ctx.param('zhaoId') or ctx.param('zhaoid'))
    if not zhao_id:
        return ctx.fail('招式参数错误', '★ forget_zhao_page：上行没有 zhaoId')
    known = _zhao_list_of(st, npc)
    if zhao_id not in known:
        return ctx.fail('你的陪练没有学习该招式',
                        '★ forget_zhao_page：陪练 %s 未学 %s' % (npc, zhao_id))
    # 遗忘消耗 = `homeServant.lua["Sheet1"].deleteCostYuanbao.content`（表里是 2300 元宝）
    _hs = (_lua_table(RES_HOME_SERVANT).get('Sheet1') or {}).get('deleteCostYuanbao') or {}
    cost = _num(_hs.get('content'), 2300)
    left = _add_currency(ctx, 'yuanbao', -cost)
    if left is None:
        return ctx.fail('元宝不足，无法遗忘',
                        '★ forget_zhao_page：需 %d 元宝，只有 %d'
                        % (cost, _get_currency(ctx, 'yuanbao')))
    known.remove(zhao_id)
    st.setdefault('npcZhao', {})[npc] = known
    _mark(st, 'forgetZhaoPage', '陪练 %s 遗忘招式 %s（-%d 元宝）' % (npc, zhao_id, cost))
    _save(ctx, st)
    # ★ `ActiveSkillPracticeModel.lua:182` `User:setRoleAttr("yuanbao", data.yuanbao_num)`
    return ctx.ok({'yuanbao_num': _num(left), 'learn_num': len(known)},
                  '★ 遗忘残页：陪练 %s 忘掉 %s（-%d 元宝，余 %d）'
                  % (npc, zhao_id, cost, _num(left)))


def _ep_get_hangup_yashi_time(ctx, st):
    ver = _num(ctx.param('version'))
    task_id = _s(st.get('hangupTaskId'))
    start = _num(st.get('hangupStart'))
    out = []
    if task_id and start and _yashi_active(ctx):
        end = min(_now(), start + MAX_HANGUP_TIME)
        if end > start:
            out.append({'start_time': start, 'end_time': end})
    # ★ `HangUpTaskSystem.lua:787-797`：`if MapIsEmpty(data)==false then for i,time_info in ipairs(data)`
    #   ⇒ 应答 `data` **本身**就是数组（`{}` 也是 table，MapIsEmpty 判空安全）。
    note = ('★ 挂机雅士时段：%d 段（雅士生效中，挂机任务 %s）'
            % (len(out), task_id) if out else
            '★ 挂机雅士时段：空（角色存档 yaShi=%s，yashi=%d）'
            % (_role_attr(ctx, 'yaShi'), _yashi_expired(ctx)))
    if ver and ver > _num(st.get('hangupVersion')):
        st['hangupVersion'] = ver
        _save(ctx, st)
    return ctx.ok(out, note)


def _ep_record_click_task(ctx, st):
    task_id = _s(ctx.param('task_id') or ctx.param('taskId'))
    conf = _hangup_tasks().get(task_id)
    if conf is None:
        # 2026-09-30 改宽松：以前未知 id 直接回 errcode!=0。但客户端的按钮回调
        # **只看 errcode**（`HangUpTaskSystem.lua:234-267`），回失败会把界面留在
        # "处理中"状态（老板点「停止任务」卡死就是这么来的）。所以照常认账。
        conf = {}
        _mark(st, 'recordClickTask', '未知任务 id=%r，照常认账（避免客户端界面锁死）' % task_id)
    today = time.strftime('%Y%m%d')
    rec = st.setdefault('clickDaily', {}).get(task_id)
    if not isinstance(rec, list) or len(rec) != 2 or _s(rec[0]) != today:
        rec = [today, 0]
    rec[1] = _num(rec[1]) + 1
    st['clickDaily'][task_id] = rec
    limit = _num(conf.get('clickLimit'))
    _mark(st, 'recordClickTask', '%s(%s) 打工第 %d 次%s'
          % (task_id, _s(conf.get('taskName')), rec[1],
             '（今日上限 %d）' % limit if limit else ''))
    _save(ctx, st)
    # `HangUpTaskSystem.lua:234-267` 只看 errcode；收益是她按 `hangUpTaskRewardConfig.lua` 自己算的
    return ctx.ok({}, '★ 打工点击记账：%s(%s) 今日第 %d 次'
                  % (task_id, _s(conf.get('taskName')), rec[1]))


def _ep_start_hangup_task(ctx, st):
    """同样**不要 fail**：客户端 `HangUpTaskSystem.lua:316-339` 也是在 errcode==0 里推进状态，
    失败会留下"开始中"的锁。认账、记账、回 ok 就行（收益本来就在客户端算）。"""
    task_id = _s(ctx.param('task_id') or ctx.param('taskId'))
    conf = _hangup_tasks().get(task_id)
    warn = ''
    if task_id and conf is None:
        warn = '（配置表里没有 %s，仍照常认账）' % task_id
    elif conf is not None and _num(conf.get('taskType')) != 1:
        warn = '（%s 不是挂机类型 taskType=%s，仍照常认账）' % (task_id, conf.get('taskType'))
    if _s(st.get('hangupTaskId')):
        warn += '（原先在挂 %s，直接覆盖）' % _s(st.get('hangupTaskId'))
    now = _now()
    ver = _num(ctx.param('version'))
    st['hangupVersion'] = max(ver, _num(st.get('hangupVersion'))) + 1
    st['hangupTaskId'] = task_id
    st['hangupStart'] = now
    _mark(st, 'startHangUpTask', '%s(%s) 开始挂机' % (task_id, _s((conf or {}).get('taskName'))))
    _save(ctx, st)
    # ★ `HangUpTaskSystem.lua:316-339`：SetTime(data.start_time) / self.__hangUpVersion = data.version
    #   `start_time` 马上参与 `currTime + TaskConst.MaxHangUpTime`（数字）⇒ 必须数字
    return ctx.ok({'start_time': now, 'version': st['hangupVersion']},
                  '★ 开始挂机 %s(%s)（start_time=%d version=%d）%s'
                  % (task_id, _s((conf or {}).get('taskName')), now, st['hangupVersion'], warn))


def _ep_stop_hangup_task(ctx, st):
    """★ 2026-09-30 修：**这个接口绝不能回 errcode != 0**。

    老板实测：点「停止任务」卡死（点一次没反应，连点 8 次）。
    日志里我们回的是「没有进行中的挂机任务」(errcode!=0)。
    看客户端 `HangUpTaskSystem.lua:500-581`：
        if status == 200 then
            if errcode == 0 then
                ... 把任务置 Idle、发奖励、self.__isStoppingHangUp = false
    也就是说 errcode != 0 时那个 `__isStoppingHangUp` 永远是 true ⇒ 整个挂机界面锁死。
    而奖励本来就是**客户端** `CalHangUpTaskRewards` 算好随请求带上来的，
    服务端根本不需要校验，直接认账就好。
    """
    task_id = _s(ctx.param('task_id') or ctx.param('taskId'))
    cur = _s(st.get('hangupTaskId'))
    elapsed = max(0, _now() - _num(st.get('hangupStart'))) if cur else 0
    if cur:
        st['hangupTaskId'] = ''
        st['hangupStart'] = 0
        _mark(st, 'stopHangUpTask', '%s 停止挂机（挂了 %d 秒）' % (cur, elapsed))
        _save(ctx, st)
        return ctx.ok({}, '★ 停止挂机 %s（本次挂机 %d 秒；奖励由客户端 CalHangUpTaskRewards 算）'
                      % (cur, elapsed))
    # 我们这边没有记录（挂机是在旧存档/早前开始的）也照样认，让它把界面解锁
    st['hangupTaskId'] = ''
    st['hangupStart'] = 0
    _mark(st, 'stopHangUpTask', '停止挂机（服务端无记录，请求 task_id=%s）' % (task_id or '?'))
    _save(ctx, st)
    return ctx.ok({}, '★ 停止挂机（服务端本来没记录，请求 %s；照常回 ok 以免客户端界面锁死）'
                  % (task_id or '?'))


# ---------------------------------------------------------------------------
# 路由
# ---------------------------------------------------------------------------
_HANDLERS = {
    'getXinShenValue': _ep_get_xinshen_value,
    'getXinShenLevel': _ep_get_xinshen_level,
    'getXinShenRecoverStartTime': _ep_get_xinshen_recover_time,
    'recoverXinShenValue': _ep_recover_xinshen,
    'upgradeXinShenLevel': _ep_upgrade_xinshen_level,
    # 她 `HttpManager:getLianGongTiLi` 发的 URL（`HttpManager.lua:4636`）
    'get_liangong_tili': _ep_get_liangong_tili,
    # `HttpManager:getTalentPageInfo`（`:4968`）
    'get_talent_info': _ep_get_talent_info,
    # `HttpManager:switchTalentPage`（`:5031`）
    'switch_talent_page': _ep_switch_talent_page,
    # `HttpManager:getCharacterPoolInfo`（`:4973`）
    'get_characterPool_info': _ep_get_character_pool_info,
    # `HttpManager:upgradeTechnique`（`:4948`）
    'upgrade_technique': _ep_upgrade_technique,
    # `HttpManager:extractCharacter`（`:4953`）
    'grasp_technique_feature': _ep_grasp_technique_feature,
    # `HttpManager:replaceCharacter`（`:4958`）
    'replace_technique_feature': _ep_replace_technique_feature,
    'get_zhao_practiceInfo': _ep_get_zhao_practice_info,
    'zhao_practice': _ep_zhao_practice,
    'gift_zhao_page': _ep_gift_zhao_page,
    'forget_zhao_page': _ep_forget_zhao_page,
    'get_hangUp_yashi_time': _ep_get_hangup_yashi_time,
    'record_click_task': _ep_record_click_task,
    'start_hang_up_task': _ep_start_hangup_task,
    'stop_hang_up_task': _ep_stop_hangup_task,
}


def handle(ctx):
    ep = ctx.endpoint
    fn = _HANDLERS.get(ep)
    if fn is None:
        return None                     # 不是我的接口
    st = _load(ctx)
    return fn(ctx, st)
