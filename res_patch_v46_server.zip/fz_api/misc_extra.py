# -*- coding: utf-8 -*-
# ================= 离线包路径根（fz_make_offline_bundle.py 自动注入） =================
# 手机上整个服务端就是一个目录，表在哪、状态写哪，全部相对包根算。
# （有的模块原来把绝对路径写死，本身没 import os —— 这里一并补上）
import os
import os as _osp


def _off_find_bundle(_f):
    """从模块所在目录往上找包根（认 fz_boot_server.py）。
    ★ fz_api/*.py 的 __file__ 在 <根>/fz_api/ 下，直接 dirname 会算错一层。"""
    _d = _osp.path.dirname(_osp.path.abspath(_f))
    for _ in range(6):
        if _osp.path.exists(_osp.path.join(_d, 'fz_boot_server.py')):
            return _d
        _u = _osp.path.dirname(_d)
        if _u == _d:
            break
        _d = _u
    return _osp.path.dirname(_osp.path.abspath(_f))


_OFF_BUNDLE = _off_find_bundle(__file__)
_OFF_FZ_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_fz')
_OFF_INK_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_ink')
_OFF_WORK_ROOT = _OFF_BUNDLE
# =====================================================================================
# ★ 2026-10-04 商城空货架修复：客户端资源表解析——PC 开发树优先，设备上自动回退
#   到包内 client_fz 副本（jhserver/client_fz = fangzhi_lua_dec 的同步拷贝）。
def _fz_res(*parts):
    base = os.path.join(_OFF_FZ_ROOT, 'res', 'script')
    if not os.path.isdir(base):
        base = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            '..', 'client_fz', 'res', 'script')
    return os.path.join(base, *parts)

# -*- coding: utf-8 -*-
"""misc_extra —— 散落在各面板、没人认领的那批接口（1:1 还原）。

**契约一律逐个读过她解密的客户端源码**（`C:\\apkwork\\ink_dec\\src\\app\\**`），
URL 取 `extends/Http/HttpManager.lua`（**不是** 同名的旧副本 `extends/HttpManager.lua`；
`Loader.lua:272` 载入的是 `extends/Http/` 那份）。

===========================================================================
一、接口契约表（上行 / 她回调里真正读的 `data.字段`）
===========================================================================
| 接口(URL 末段) | 上行 | 她读的字段（类型） | 出处 |
|---|---|---|---|
| `get_board/<ptype>`      | POST `{page}` | 单榜**对象**：`title`(串) `type`(串) `header`(数组) `body.list`(数组) `body.mine`(对象) `total_nums` `board_type` `total_page` `nums`(数) | `RankingUI.lua:864` + `:986-1017` |
| `get_board/<id>`（同一个 URL！） | POST 无参 | 同上（`getRankingListByOne`） | `BookRankLayer.lua:288`(id=5) `WzRankLayer.lua:292`(id=8) `ShenBingRankLayer.lua:301`(id=8/9) |
| `canInherit`             | GET | —（只看 errcode；errcode=0 才会去调 `inherit`） | `models/inherit/Inherit.lua:624` |
| `check_email_white`      | POST `{email}` | `auth`(**必须能被 tonumber**：`DebugConfig:setRoleType` 里 `tonumber(type)`) | `EmailLayer/BindingTestMailLayer.lua:75` + `DebugLayer/DebugConfig.lua:141` |
| `exchange_yashi_welfare_reward` | POST `{id,number,type,currencyVersion}` | `yashiWelfarePoint`(数) `yashiExpiredTime`(数) `currencyVersion`(数，可选) `msg`(串，可选) | `models/YaShiBenefit/YaShiBenefit.lua:224` |
| `join_family`            | POST `{familyId,currencyVersion}` | `currencyVersion`(数，可选) | `models/role/Role_Family.lua:272` |
| `pvp_roleData_verify`    | POST `{roleDatas}` | errcode 0=通过 / 2=判定作弊（`PopText("请公平公正的参与游戏")`） | `views/layer/MapPVPLayer/WaitingLayer.lua:288` + `models/FuBenClient/FubenClient.lua:205` |
| `report_gain_log`        | POST `{log_data=[...]}` | —（只看 errcode；errcode=0 才把本地日志删掉） | `models/Record/Record.lua:174` |
| `check_user_gain_log`    | GET | —（**只看 errcode**：1=`confirmBtnFunc()`（无继承期数就中断），0=`doNoRoleResults(arg8)`（走继承奖励）） | `MapHandle/Modules/CommonModule/CommonResults.lua:4344`（方法名 `getwxtranstwxplushasGainAfter202509291500`） |
| `count_single_record/<type>` | GET | —（只看 errcode） | `countSingleRecordWithType` `FestivalModule.lua:610`("zhongyuanjie") `TaskModule.lua:458`("YeGuiRenWu") `:571`("HaoLiXing")；`joinGhostTimes`→`join_ghost` `TaskModule.lua:828`；`finishGhostTimes`→`finish_ghost` `TaskModule.lua:974` |
| `get_recharge_benefits_info` | GET | `giftList`(数组，元素 `giftId/giftName/giftIcon/giftType/ridList`) `goodsList`(**对象** `{rid={goodsId,num}}`) `rewardList`(数组 `{id,needMoney,state,giftList=[{giftId,giftNum}]}`) `totalRecharge`(数) | `models/Action/SpringEquinox.lua:102` + `presenters/Activity/SpringEquinoxPresenters.lua:81/126` |
| `get_recharge_benefits_reward` | POST `{id,isEmail,dataVer,currencyVersion}` | `reward`(数组 `{id,num}`) `dataVer`(数) `currencyVersion`(数) `msg`(串，可选) | `models/Action/SpringEquinox.lua:220` |
| `get_challengemap_task_info` | GET | `act_name`(串) `detail_desc`(**数组**，她 `ipairs` 逐行拼) `task_list`(数组 `{id,state,reward=[{id,num}]}`) `map_list`(数组 `{map_id,times}`) | `models/Action/ChallengeClearTimes.lua:36` |
| `get_challengemap_task_reward` | POST `{isEmail,dataVer,currencyVersion}` | `reward`(数组 `{id,num}`) `dataVer`(数) `currencyVersion`(数) `msg`(串，可选) | `models/Action/ChallengeClearTimes.lua:89` |
| `get_merchant_event_info` | POST `{activityId,currencyVersion}` | `location`(**数组** `{mapId,roomId}`) `hongDianState`(布尔/任意) | `models/Action/SkillResExchange.lua:23` |
| `get_merchant_store_list` | POST `{merchantId,isRefresh,currencyVersion,dataVer}` | `goodsList`(数组，元素 `storeId/goodsId/price/priceUnit/unitCount/discount/limitType/limitCount/limitBoughtCount/count`) `currencyList`(数组 `{unit,name,num,limit,cycleLimit,cycleNum}`) `currencyShowList`(任意) `refreshTime`(数) `refreshCost`(数) `refreshState`(数) `refreshCurrencyName`(串) `currencyVersion`(数，可选) | `models/Store/Store.lua:344-383` + `StoreBag/StoreSellBag.lua:28-54` + `StoreItem/StoreGoods.lua` |
| `buy_merchant_goods`     | POST `{merchantId,goodsList,recordList,dataVer,currencyVersion}` | `goodsList`(数组 `{id,num}`) `dataVer`(数) `currencyVersion`(数) `yashi_expired_time`(数，可空) | `models/Store/Store.lua:792` + `:830` |
| `buy_sect_supportGoods`  | POST `{familyId,id}` | `gainList`(数组 `{id,number}`) `costList`(数组 `{id,number}`) `currencies`(数组 `{id,number}`，`id` ∈ donate/renown/sgbpoint/gbpoint/reputation) `msg`(串，可选) | `models/Store/TeacherBuildResExchangeStore.lua:63` |
| `get_sect_supportShop`   | POST `{familyId}` | `exchangeLimit`(数) `exchangeTimes`(数) `list`(**数组**，元素 `id`(数) `state`(数 0/1) `titleText` `contentText` `unlockText`) | `models/Store/TeacherBuildResExchangeStore.lua:28` + `:120-137` + `presenters/Store/TeacherBuildResExchangeStorePresenter.lua:84-98` |

**关于 `get_board` 的三个面板（同一接口、同一个 URL 前缀，靠 URL 那段数字区分）**：
* `views/ui/RankingUI/RankingUI.lua:864` 用 `boardType`（服务端列表下发的 `board_type`）翻页 ⇒ **ptype=1..4**，
  面板读 `title/type/header/body.list[]/body.mine/total_nums/board_type/total_page/nums`；
  行元素她读 `sort`(算名次) `userid` `name` `dsc` `menpai` `inheritCount` `title_id/title_type` `head` `looks` `sex`（`Role:create(userData)` → `HeadViewPresenter`）。
* `views/layer/GongFuPageLayer/{BookRankLayer,WzRankLayer,ShenBingRankLayer}.lua` 走 `getRankingListByOne(id)` ⇒
  **5=藏书榜 / 8=武藏榜 / 9=神兵榜**（8/9 的对应关系取自 `ControllLayer.lua:886-943` 的 `setSetUpButtonName`）。
  这三个面板读 `header[3]`(表头第三列) `title` `body.list` `body.mine` `userid` `name` `dsc` `head` `real_menpai`，
  名次是它们自己按 `i+(page-1)*10` 算的（**不读 `sort`**），所以本模块照样把 `sort/grade` 一起给上（`BookRankLayer:122` 读 `grade`）。
* `views/layer/TeacherLayer/FamilyPrestigeRanking.lua:454` 走 `getRankingListByOne(self.flag)`，
  `self.flag = 13`（:24 "13 类别"）⇒ 门派威望榜，结构同上（她读 `self.rankData.body.is_get`）。

===========================================================================
二、内容从她自己的表/存档来（**不编数值**）
===========================================================================
* `res/script/family/family.lua["familys"]`（30 个门派：`id`/`name`）→ `join_family` 校验与 `menpai` 真名。
* `res/script/activity/Monthlycardysgift.lua["Sheet1"]`（633 条 `{giftId,goodsId,moneyNumber}`）→ 雅士福利兑换的花费
  （`YaShiBenefit.lua:9` 就是 `require("script.activity.Monthlycardysgift")["Sheet1"]`）。
* `res/script/activity/challengetaskPZ.lua["Sheet1"]`（9 个任务 `{id,tasktitle,taskdesc,rewards,condition}`）
  + `challengetaskTJ.lua["Sheet1"]`（32 条条件 `{id,fbid,times}`）→ 挑战地图任务列表与领奖；
  **通关次数**读 `fz_api/challenge_map.py` 已经落盘的 `work/challengemap_state.json`（同一份数据，不另记）。
* `res/script/store/storeConfig.lua["Sheet1"]`（70 个商人：`location`/`displaycurrency`/`shownums`/`Refreshtype`/`Refreshtime`）→ 商人信息。
* `res/script/store/shoplist.lua["Sheet1"]`（2228 件**真商品**，键就是 `GoodsHelper:getGoodsResClass(id)` 查的那个）
  → 商人货架 / 师门易物堂的商品 id。
* `res/script/family/sectBuildDonate.lua`（68 条 `{donateid,donatecondition,upresources,renown,donate,unlockcondition}`）
  + `sectBuildInfo.lua`（`donateid` 列表）→ 师门易物堂（`get_sect_supportShop` 的 `list` 与
  `buy_sect_supportGoods` 的**同一份**条目）；
  门槛 `unlockcondition` 的建筑等级读 `fz_api/teacher_build.py` 已落盘的 `work/teacherbuild_state.json`（不另记）。
* `res/script/others/monetarymanagement.lua` + `Role.lua#getCHAttrName` → 货币/属性中文名（走 `items_currency`）。
* **她自己的样例榜数据**：`RankingUI.lua:1078` 的 `getTestData()` 里内嵌的
  `[[{"errcode":0,"data":[…4 个榜…]}]]` —— 她拿这份数据做自测，**结构就是权威**。
  本模块把它整份抠出来当**种子**（`res/script` 里没有"全服排行榜"这种表，原版榜在服务端 DB）。
* **钱和物品**：`fz_api/items_currency.py` 的
  `get_count/add_count/spend/grant` + `get_currency/add_currency`（**不新造第二份钱**）。
* 玩家自己的名字/门派/等级：`work/roles/full.json`（服务端下发的角色档），与 `biwu.py` 同口径。

===========================================================================
三、状态（`work/misc_extra_state.json`，本模块独占）
===========================================================================
    board     —— 榜数据（首次从她内嵌样例建种子，`seed_from_client` 记出处）
    merchant  —— 每个商人：`goods`(货架) / `bought`(storeId→已买) / `refreshed`(刷新次数)
    sold      —— 商人处玩家已卖出的东西（`buy_merchant_goods` 的 recordList 记账）
    sect      —— 师门易物堂：`familyId`(加入的门派) / `exchangeTimes` / `limit`
    yashi     —— 雅士福利：`point`(可用额度，`YaShiBenefit:getMaxCurrencyNum()`=1000 是客户端常量) / `expiredTime`
    recharge  —— 累充返利：`totalRecharge`(元) / `claimed`(已领档位)
    challenge —— 挑战地图任务：`claimed`(已领任务 id)
    inherit   —— `canInherit` 过没过、`check_user_gain_log` 的答案
    records   —— `count_single_record/<type>` 的计数、`gain_logs`（`report_gain_log` 落盘）
    email_auth—— `check_email_white` 的白名单邮箱 → 权限等级
    pvp       —— `pvp_roleData_verify` 收到的最近一份属性快照

===========================================================================
四、诚实说明：哪些是"确定性推算"、哪些还没做到 1:1
===========================================================================
1. **商人货架排布不是原版配置**。`storeConfig` 只给 `goodsshelf=[[10053]]` 这种**货架号**
   （10000–10069），而这个号在她 1 万多个 `res/script/**` 里**根本查不到**对应的货架内容表
   （只在原版服务端 DB）。本模块的做法：用 `store/shoplist.lua` 的 2228 件真商品，按
   `merchantId` 做**确定性**抽签（`seed = md5(merchantId)` 排序后取一段）⇒ 同一商人永远同一批货，
   不重启就换。**`price` 同理**：货架表里没有价格，用商品键的确定性散列给一个稳定的正整数
   （客户端 `Store:buyGoods` 会拿它做 `price*count`，`nil` 会直接崩）。
   ⇒ 这两项是"确定性推算"，**不是原版数值**。
2. **雅士福利额度的发放**：客户端只在 `ControllLayer.lua:2591` 读 `yashiWelfarePoint`、
   `StoreLayer.lua:133` 读 `yashi_welfare_point`，**没有任何接口发放它**（原版是买月卡/雅士后服务端加）。
   本模块把可用额度初值取**客户端常量 1000**（`YaShiBenefit:getMaxCurrencyNum()` 就是 `return 1000`），
   之后按 `Monthlycardysgift` 的 `moneyNumber` 真扣。**没有真实充值通道**，不假装充值成功。
3. **累充返利（`get_recharge_benefits_*`）的礼包/档位表在客户端里不存在**
   （`SpringEquinox.lua` 里那两段 `giftList`/`goodsList`/`rewardList` 全是**注释掉的样例**，
   真数据由服务端下发）。本模块：
   * `rewardList` 的档位 `needMoney`、`giftList` 的 `giftId/giftNum` 结构**照她注释里的样例形状**建，
     礼包内容（`ridList`/`goodsList`）用 `shoplist` 里**真商品键**填；
   * 领取时按 `GoodsHelper:fromNetworkGrantGoods` 的契约回 `reward=[{id,num}]`，真进她的包袱（`IC.add_count`）。
   ⇒ 档位金额与礼包内容是**确定性推算**，docstring 里明说，不谎称原版配置。
4. **挑战地图任务的"通关次数"**读 `challenge_map.py` 的 `challengemap_state.json["finished"]`
   （服务端已有的那份记录）；读不到就是 0（她面板会显示"未完成"，这是真状态，不是假数据）。
5. **`pvp_roleData_verify` 只做"结构性校验"**：校验上行 `roleDatas` 的形状、把快照落盘、
   拿服务端自己知道的属性做区间比对；**不判定作弊**（原版的作弊阈值在服务端配置里，
   客户端与公开资料都没有）⇒ 一律放行 errcode=0。判错会把正常玩家挡在切磋之外，
   比"不判"更糟。**这是明确的取舍，不是没做**。
6. **`check_user_gain_log`** 她只分 `errcode==1`（`confirmBtnFunc`，无继承期数就中断）
   与 `errcode==0`（`doNoRoleResults(arg8)`，走继承奖励）两支。本模块按状态里的
   `inherit.has_gain_log` 作答（默认 **1** ⇒ 与"没到继承期"一致，不会白送奖励）。
7. **`count_single_record/<type>`** 的 `join_ghost`/`finish_ghost`/`YeGuiRenWu`/`HaoLiXing`/`zhongyuanjie`
   在她客户端**全是"计数上报"**（回调只看 errcode，`DEBUG_MODE` 才打印"参与次数加 1"）⇒
   本模块对这几个类型**真 +1 落盘**并回 errcode 0，其余类型只当**查询**（读计数，不写）。
8. **师门易物堂（`get_sect_supportShop`）的门槛判定是保守的**：`sectBuildDonate.lua` 68 条里
   只有 6 条没有 `unlockcondition`，其余要求 `buildinglevel`(492 次)/`unionleave`(47)/
   `condilevel`(13)/`factionstate`(12)。建筑等级能从 `teacherbuild_state.json` 读到，
   **但 `unionleave`(师门等级)/`factionstate`(门派状态) 我这边没有可信来源**
   ⇒ 带这两类门槛的条目一律按 `state=0`（未解锁，面板上灰着 + 显示 `text` 解锁说明）。
   **绝不谎报"已解锁"** 让她点进来再被拒。要放开就得先把师门等级/门派状态接进来。
"""
import hashlib
import json
import os
import re
import sys
import time

NAME = 'misc_extra'
TITLE = '杂项·排行榜/传承/雅士/加入门派/充值返利/挑战地图任务/商人/日志'
ENDPOINTS = [
    # —— 排行榜（三个面板共用一个 URL）——
    'get_board',
    # —— 传承 / 邮箱 ——
    'canInherit',
    'check_email_white',
    # —— 雅士福利 ——
    'exchange_yashi_welfare_reward',
    # —— 门派 ——
    'join_family',
    'get_sect_supportShop',
    'buy_sect_supportGoods',
    # —— 切磋校验 ——
    'pvp_roleData_verify',
    # —— 日志 ——
    'report_gain_log',
    'check_user_gain_log',
    'count_single_record',
    # —— 充值返利 ——
    'get_recharge_benefits_info',
    'get_recharge_benefits_reward',
    # —— 挑战地图任务（"江湖轶闻"清理任务）——
    'get_challengemap_task_info',
    'get_challengemap_task_reward',
    # —— 商人 ——
    'get_merchant_event_info',
    'get_merchant_store_list',
    'buy_merchant_goods',
]

STATE = 'misc_extra_state.json'

RES = _fz_res()
APP = os.path.join(_OFF_INK_ROOT, 'src', 'app')
P_FAMILY = os.path.join(RES, 'family', 'family.lua')
P_MONTHLY = os.path.join(RES, 'activity', 'Monthlycardysgift.lua')
P_TASKPZ = os.path.join(RES, 'activity', 'challengetaskPZ.lua')
P_TASKTJ = os.path.join(RES, 'activity', 'challengetaskTJ.lua')
P_STORECONF = os.path.join(RES, 'store', 'storeConfig.lua')
P_DONATE = os.path.join(RES, 'family', 'sectBuildDonate.lua')
P_RANKINGUI = os.path.join(APP, 'views', 'ui', 'RankingUI', 'RankingUI.lua')

# 客户端常量（**不是**我编的，逐条给出处）
YASHI_MAX_POINT = 1000            # `YaShiBenefit:getMaxCurrencyNum()` -> `return 1000`（她的**上限**）
YASHI_SEED_POINT = 10000          # ★ 服务端摆的"可用额度"初值：客户端**没有**发放接口
                                  #   （`ControllLayer.lua:2591` 只读 `yashiWelfarePoint`、
                                  #    `StoreLayer.lua:133` 只读 `yashi_welfare_point`），
                                  #   而 `Monthlycardysgift` 里 633 条残页的价全是 700（`moneyNumber`）
                                  #   ⇒ 给 1000（=她自己的上限）**一件都兑不了**。这是"服务端下发值"，
                                  #   按一次雅士（30 元）给够兑若干件。要调改这个常量。
YASHI_NINGSHENDAN_GOODS = '400002'  # `YaShiBenefit:getNingShenDanInfo()` -> goodsId = "400002"（凝神丹）
YASHI_NINGSHENDAN_PRICE = 5       # 同上 -> `price = 5`
MAX_PER_PAGE = 10                 # `RankingUI:initAndSaveData`（:998）按 10 条一页算名次

# 师门易物堂的"钱"分两类（`Role.lua:getCHAttrName` 的 tabs / `others/monetarymanagement.lua`）：
#   * `SECT_CURRENCIES` 是真货币（在货币管理表里）⇒ 走 `items_currency`；
#   * `SECT_ATTRS` 是角色属性（建材 + 各种贡献/资历）⇒ 记在本模块 state 的 `sect.materials`。
SECT_CURRENCIES = ('amartial', 'bmartial', 'cmartial', 'dmartial', 'money', 'yinpiao', 'yuanbao')
SECT_ATTRS = ('donate', 'renown', 'sgbpoint', 'gbpoint', 'reputation',
              'bmaterials1', 'bmaterials2', 'bmaterials3', 'bmaterials4', 'bmaterials5', 'bmaterials6')

# 榜类型 → (标题, 类型串, 表头)
BOARD_META = {
    1: ('高手榜', 'total_board', ['名次', '昵称', '武学造诣']),
    2: ('财富榜', 'total_board', ['名次', '昵称', '财富描述']),
    3: ('名人堂', 'total_board', ['名次', '昵称', '江湖阅历']),
    4: ('少林寺', 'menpai_board', ['名次', '昵称', '武学造 诣']),
    5: ('藏书榜', 'total_board', ['名次', '昵称', '藏书数量']),
    6: ('门派榜', 'menpai_board', ['名次', '昵称', '门派威望']),
    7: ('师徒榜', 'total_board', ['名次', '昵称', '师门贡献']),
    8: ('武藏榜', 'total_board', ['名次', '昵称', '武学收藏']),
    9: ('神兵榜', 'total_board', ['名次', '昵称', '神兵造诣']),
    # `TeacherLayer/FamilyPrestigeRanking.lua:24` → `self.flag = 13`（:454 调 `getRankingListByOne`）
    13: ('门派威望榜', 'menpai_board', ['名次', '昵称', '门派威望']),
}

# ★ 这几个类型的 `count_single_record` 在她客户端是**写**（计数上报），其余只当查询。
COUNT_WRITE_TYPES = {
    'join_ghost',       # `HttpManager:joinGhostTimes`（TaskModule.lua:828，鬼差任务参加次数）
    'finish_ghost',     # `HttpManager:finishGhostTimes`（TaskModule.lua:974，鬼差任务完成次数）
    'YeGuiRenWu',       # 押鬼奖励（TaskModule.lua:458）——"玩法数据统计"
    'HaoLiXing',        # 蒿里行奖励发放（TaskModule.lua:571）——"玩法数据统计"
    'zhongyuanjie',     # 中元节（FestivalModule.lua:610）——"玩法数据统计"
}

_RES_CACHE = {}
_ROLE_CACHE = {}


# ===========================================================================
# 基础工具
# ===========================================================================


def _s(v, d=''):
    if v is None:
        return d
    if isinstance(v, bool):
        return 'true' if v else 'false'
    if isinstance(v, (int, float)):
        return str(v)
    if isinstance(v, str):
        return v
    return str(v)


def _num(v, d=0):
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return d


def _fnum(v, d=0.0):
    try:
        return float(v)
    except (TypeError, ValueError):
        return d


def _bool(v, d=False):
    if isinstance(v, bool):
        return v
    if v is None:
        return d
    if isinstance(v, (int, float)):
        return v != 0
    return str(v).lower() in ('1', 'true', 'yes', 'y')


def _seed(*parts):
    raw = '|'.join(str(p) for p in parts).encode('utf-8')
    return int(hashlib.md5(raw).hexdigest()[:8], 16)


def _lua_table(path):
    """用 `work/fz_luatable.py` 读她的配表（进程内缓存；失败返回 {}）。"""
    if path in _RES_CACHE:
        return _RES_CACHE[path]
    out = {}
    try:
        if os.path.dirname(os.path.abspath(__file__)) not in sys.path:
            sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        from fz_luatable import load_lua_table
        v = load_lua_table(path)
        if isinstance(v, dict):
            out = v
    except Exception:                             # noqa: BLE001
        out = {}
    _RES_CACHE[path] = out
    return out


def _sheet(path):
    t = _lua_table(path)
    return t.get('Sheet1') or t.get('1') or t


def _families():
    """`family/family.lua["familys"]` → {id: name}（30 个门派）。"""
    t = _lua_table(P_FAMILY)
    fam = t.get('familys')
    return fam if isinstance(fam, dict) else {}


def _family_names():
    """30 个门派的**中文名**集合（判断"这个榜是不是某个门派榜"用）。"""
    if 'family_names' in _RES_CACHE:
        return _RES_CACHE['family_names']
    out = set(_s(v.get('name')) for v in _families().values() if isinstance(v, dict) and v.get('name'))
    _RES_CACHE['family_names'] = out
    return out


def _monthly_gift():
    """`activity/Monthlycardysgift.lua["Sheet1"]` → {giftId: {goodsId, moneyNumber}}（633 条）。"""
    return _sheet(P_MONTHLY)


def _store_config():
    """`store/storeConfig.lua["Sheet1"]` → {merchantId: {...}}（70 个商人）。"""
    return _sheet(P_STORECONF)


def _denote():
    """`family/sectBuildDonate.lua` → {donateid: {...}}（68 条）。"""
    return _sheet(P_DONATE)


def _taskpz():
    """`activity/challengetaskPZ.lua["Sheet1"]`（9 个任务）。"""
    return _sheet(P_TASKPZ)


def _tasktj():
    """`activity/challengetaskTJ.lua["Sheet1"]`（32 条条件）。"""
    return _sheet(P_TASKTJ)


def _ic():
    """`items_currency` —— 钱与物品的唯一记账处。"""
    from fz_api import items_currency
    return items_currency


def _uid(ctx):
    return _s(ctx.headers.get('userid') or ctx.headers.get('uuid') or 'local', 'local')


def _dataver(ctx):
    """宿主服务端注入的 dataVer 自增器（`fz_boot_server.py:606 next_dataver`）。

    她多处 `__saveAction(data.dataVer)` → `setDataVersion`，**给 nil 或 0 会把她的存档版本号打回去**，
    所以这里优先问宿主要一个新号；实在没有就退回 1（不是 0）。
    """
    try:
        v = ctx.deps['next_dataver']()
        return _num(v, 1) or 1
    except Exception:                             # noqa: BLE001
        return 1


def _currency_version(ctx):
    """货币版本 —— **读 `items_currency` 那份 state**（她 `data.currencyVersion` 只用来比对），不另存一份。"""
    try:
        st = _ic()._load(ctx)
        return _num(st.get('currencyVersion'), 1) or 1
    except Exception:                             # noqa: BLE001
        return 1


# ===========================================================================
# 状态
# ===========================================================================
def _sect_seed_materials():
    """师门建材/贡献的**服务端下发初值**（客户端没有"给玩家发建材"的接口）。

    `bmaterials1..6` = 三合土/青石砖/楠木/汉白玉/琉璃瓦/生漆；
    `donate`=佳绩 / `renown`=资历 / `sgbpoint`=贡献昌盛度 / `gbpoint`=师门昌盛度 / `reputation`=个人功绩
    —— 名字全部取自 `Role.lua:getCHAttrName` 那张 `tabs`。
    原版靠师门任务（`family/tasks.lua` 的 `awards={{"bmaterials1","5"}}`）发放，
    那些任务跑在服务端。这里给一个能兑几件的小额初值，**不是原版数值**，要调改这里 / state。
    """
    return {'bmaterials1': 200, 'bmaterials2': 120, 'bmaterials3': 80,
            'bmaterials4': 40, 'bmaterials5': 20, 'bmaterials6': 10,
            'donate': 0, 'renown': 0, 'sgbpoint': 0, 'gbpoint': 0, 'reputation': 0}


def _blank():
    return {
        'board': {},
        'merchant': {},
        'sold': {},
        'sect': {'familyId': '', 'exchangeTimes': 0, 'limit': 10, 'materials': _sect_seed_materials()},
        'yashi': {'point': YASHI_SEED_POINT, 'expiredTime': 0},
        'recharge': {'totalRecharge': 0, 'claimed': []},
        'challenge': {'claimed': []},
        'inherit': {'has_gain_log': 1, 'can': 1},
        'records': {},
        'gain_logs': [],
        'email_auth': {},
        'pvp': {},
        'log': [],
    }


def _st(ctx):
    st = ctx.load_json(STATE, None)
    if not isinstance(st, dict):
        st = {}
    for k, v in _blank().items():
        if k not in st or st[k] is None:
            st[k] = v
    for k in ('board', 'merchant', 'sold', 'records', 'email_auth', 'pvp'):
        if not isinstance(st.get(k), dict):
            st[k] = {}
    for k in ('gain_logs',):
        if not isinstance(st.get(k), list):
            st[k] = []
    for k in ('sect', 'yashi', 'recharge', 'challenge', 'inherit'):
        if not isinstance(st.get(k), dict):
            st[k] = _blank()[k]
    st['sect'].setdefault('materials', _sect_seed_materials())
    if not isinstance(st['sect'].get('materials'), dict):
        st['sect']['materials'] = _sect_seed_materials()
    return st


def _save(ctx, st):
    try:
        ctx.save_json(STATE, st)
    except Exception:                             # noqa: BLE001
        pass


def _log(ctx, st, msg):
    st.setdefault('log', [])
    st['log'].append('[%d] %s' % (int(time.time()), msg))
    del st['log'][:-200]
    ctx.log('[misc_extra] ' + msg)


# ===========================================================================
# 她自己的样例榜数据（`RankingUI.lua:1078 getTestData()` 内嵌的那段 JSON）
# ===========================================================================
def _client_seed_boards():
    """把 `RankingUI:getTestData()` 里的样例 JSON 抠出来。**结构权威**（她自测用的）。"""
    if 'seed' in _RES_CACHE:
        return _RES_CACHE['seed']
    out = []
    try:
        with open(P_RANKINGUI, encoding='utf-8', errors='replace') as f:
            t = f.read()
        m = re.search(r'getTestData\s*\([^)]*\)\s*local\s+jsonData\s*=\s*\[\[(.*?)\]\]', t, re.S)
        if m:
            doc = json.loads(m.group(1))
            for b in (doc.get('data') or []):
                if isinstance(b, dict) and b.get('title'):
                    out.append(b)
    except Exception:                             # noqa: BLE001
        out = []
    _RES_CACHE['seed'] = out
    return out


def _clone(v):
    return json.loads(json.dumps(v))


def _rank_score(row, ptype):
    """榜单排序键 —— 全部用她样例行里**真实存在**的字段。"""
    if ptype == 2:
        return _fnum(row.get('money'))
    if ptype == 3:
        return _fnum(row.get('yueli'))
    return _fnum(row.get('kongfu'))


def _head_item(row):
    """`data.head`：她 `RoleInfoLayer` 用 `data.equips.head = userData.head`；
    样例里是**对象** `{itemId,id}`，也有 `""` 的（`misc_daily.py` 同口径）。"""
    h = row.get('head')
    if isinstance(h, dict) and h.get('itemId'):
        return h
    return ''


def _row_of(result_row, sort=None):
    """把样例行整成一份**字段齐全**的榜行。

    ★ 少字段就会在她回调里抛异常、被 xpcall 吞掉 ⇒ 界面卡死，所以这里把
      `RankingUI:updateOnePanelItem`（:582-636）和
      `BookRankLayer:createPanel`（:109-204）读的字段全部补齐。
    """
    r = dict(result_row)
    r['userid'] = _num(r.get('userid'))
    r['lv'] = _num(r.get('lv'), 1)
    r['sex'] = r.get('sex') if r.get('sex') in ('男', '女') else '男'
    r['looks'] = _num(r.get('looks'), 20)
    r['name'] = _s(r.get('name'), '无名侠客')
    r['menpai'] = _s(r.get('menpai'), '江湖散人')
    r['real_menpai'] = _s(r.get('real_menpai'), r['menpai'])
    r['dsc'] = _s(r.get('dsc'), '深不可测')
    r['kongfu'] = _fnum(r.get('kongfu'))
    r['money'] = _num(r.get('money'))
    r['yueli'] = _num(r.get('yueli'))
    r['inheritCount'] = _num(r.get('inheritCount'), 0)
    r['head'] = _head_item(r)
    # `RankingUI:updateOnePanelItem`（:605-611）读这两个；给了就不会走她那个默认分支
    r['title_id'] = _num(r.get('title_id'), 160)
    r['title_type'] = _num(r.get('title_type'), 2)
    if sort is not None:
        r['sort'] = _num(sort)
    r.setdefault('sort', 0)
    r['grade'] = _grade(_num(r.get('sort')))
    return r


_GRADE = ['壹', '贰', '叁', '肆', '伍', '陆', '柒', '捌', '玖', '拾']


def _grade(i):
    """`RankingUI:createListView` 的 `gradeCast`（:479-484）—— 完全照抄她的规则。"""
    if 1 <= i <= len(_GRADE):
        return _GRADE[i - 1]
    if i > 9999:
        return '9999+'
    return str(i)


def _my_row(ctx):
    """玩家自己那一行：名字/门派/等级取服务端下发的角色档（与 `biwu.py` 同口径）。"""
    key = 'me'
    if key in _ROLE_CACHE:
        base = _ROLE_CACHE[key]
    else:
        base = {}
        for rel in (os.path.join('roles', 'full.json'), os.path.join('role_store', 'dev1.json')):
            try:
                with open(ctx.data_file(rel), encoding='utf-8') as f:
                    doc = json.load(f)
            except Exception:                     # noqa: BLE001
                doc = None
            if isinstance(doc, dict) and doc:
                fam_id = _s((doc.get('family') or {}).get('name') if isinstance(doc.get('family'), dict) else '')
                fam = _families().get(fam_id) or {}
                base = {
                    'userid': _num(doc.get('userid'), 0),
                    'name': _s(doc.get('name'), '无名侠客'),
                    'sex': doc.get('sex') if doc.get('sex') in ('男', '女') else '男',
                    'looks': _num(doc.get('looks'), 20),
                    'lv': _num(doc.get('lv'), 1),
                    'menpai': _s((fam or {}).get('name'), '江湖散人') if fam_id else '江湖散人',
                    'kongfu': _fnum(doc.get('kongfu')),
                    'money': _num(doc.get('money')),
                    'yueli': _num(doc.get('yueli')),
                }
                break
        if not base:
            base = {'userid': 900000001, 'name': '无名侠客', 'sex': '男', 'looks': 20,
                    'lv': 1, 'menpai': '江湖散人', 'kongfu': 0.0, 'money': 0, 'yueli': 0}
        _ROLE_CACHE[key] = base
    row = dict(base)
    # 自己的门派以 `join_family` 真加过的为准（state 里那份）
    st_fam = _s(_st(ctx).get('sect', {}).get('familyId'))
    if st_fam:
        fam = _families().get(st_fam) or {}
        if fam.get('name'):
            row['menpai'] = _s(fam.get('name'))
    return row


def _board_seed(st, ptype, title):
    """榜的**内容**：优先用她内嵌样例里同名那块（`RankingUI:getTestData`），
    没有就退到样例里的第一块（结构一致）——**不凭空造玩家**。"""
    seed = _client_seed_boards()
    pick = None
    for b in seed:
        if _s(b.get('title')) == title:
            pick = b
            break
    if pick is None:
        for b in seed:
            if _s(b.get('type')) == 'total_board':
                pick = b
                break
    if pick is None:
        return []
    lst = ((pick.get('body') or {}).get('list')) or []
    rows = []
    for i, r in enumerate(lst):
        if not isinstance(r, dict):
            continue
        rows.append(_row_of(r, sort=i + 1))
    # 按该榜的排序键重排（她样例本身就没排好：`武学造诣` 那块 `shenfa=1900` 排第一）
    rows.sort(key=lambda r: (-_rank_score(r, ptype), _num(r.get('userid'))))
    for i, r in enumerate(rows):
        r['sort'] = i + 1
        r['grade'] = _grade(i + 1)
    return rows


def _board_obj(ctx, st, ptype, page):
    """`get_board/<ptype>` 的应答体（**对象**，不是数组）。"""
    title, btype, header = BOARD_META.get(ptype, ('排行榜', 'total_board', ['名次', '昵称', '武学造诣']))
    cache = st['board'].get(str(ptype))
    if not isinstance(cache, dict) or not isinstance(cache.get('rows'), list) or not cache['rows']:
        rows = _board_seed(st, ptype, title)
        cache = {'rows': rows, 'seed_from_client': True}
        st['board'][str(ptype)] = cache
    rows = cache.get('rows') or []

    # 门派榜（她样例里 `type=menpai_board` 那一块就是"少林寺"榜）：
    # ★ 只有当**榜名本身是个门派名**时才按门派过滤 —— 否则（`门派威望榜` 这种聚合榜）
    #   过滤条件永远不成立，榜会恒空（我第一版就踩了：type=13 回 0 条）。
    if btype == 'menpai_board' and title in _family_names():
        rows = [r for r in rows if _s(r.get('menpai')) == title or _s(r.get('real_menpai')) == title]

    total = len(rows)
    total_page = max(1, (total + MAX_PER_PAGE - 1) // MAX_PER_PAGE)
    page = max(1, min(page, total_page))
    chunk = rows[(page - 1) * MAX_PER_PAGE: page * MAX_PER_PAGE]

    # `mine`：自己的名次（按排序键算真名次；没上榜就给"未入榜"——她 :519-537 认字符串）
    me = _my_row(ctx)
    me = _row_of(me)
    score = _rank_score(me, ptype)
    better = sum(1 for r in rows if _rank_score(r, ptype) > score)
    if rows and better < total:
        me['sort'] = better + 1
        me['grade'] = _grade(me['sort'])
    else:
        me['sort'] = '未入榜'
        me['grade'] = '未入榜'
    return {
        'title': title,
        'type': btype,
        'header': list(header),
        'total_nums': total,
        'board_type': ptype,
        'total_page': total_page,
        'nums': len(chunk),
        'body': {'list': chunk, 'mine': me},
    }


# ===========================================================================
# 接口实现
# ===========================================================================
def _ep_get_board(ctx, st):
    """`get_board/<ptype>`：RankingUI 翻页（ptype=board_type）、
    Book/Wz/ShenBing/RoleRank 那几块面板（ptype=5/8/9...）。**同一个 URL**。"""
    raw = ctx.args[0] if ctx.args else ''
    digits = re.findall(r'\d+', _s(raw))
    ptype = _num(digits[0]) if digits else 0
    page = _num(ctx.param('page'), 1) or 1
    if ptype <= 0:
        # 探针/异常请求不带 type：回**当前榜单**（高手榜）而不是报错——她那边 ptype 为 nil 时压根不会发请求
        ptype = 1
    data = _board_obj(ctx, st, ptype, page)
    _save(ctx, st)
    return ctx.ok(data, '★ 排行榜 %s（type=%d 第 %d 页，%d 条/共 %d 条）'
                  % (data['title'], ptype, page, data['nums'], data['total_nums']))


def _ep_can_inherit(ctx, st):
    """`canInherit`：她只看 `errcode==0` 才会去调 `Inherit:inherit`。
    errcode=0 ⇒ 放行传承。"""
    st['inherit']['can'] = 1
    _save(ctx, st)
    return ctx.ok({'canInherit': 1}, '★ 可传承（Inherit.lua:624 只看 errcode）')


def _ep_check_email_white(ctx, st):
    """`check_email_white`：`BindingTestMailLayer:__bindingMail` 读 `data.auth`
    丢给 `DebugConfig:setRoleType` → `tonumber(type)` ⇒ **auth 必须能被 tonumber**。
    白名单从 state 读（`email_auth`），没登记的邮箱 auth=0（非测试号）。"""
    email = _s(ctx.param('email'))
    auth = _num(st['email_auth'].get(email.lower()), 0)
    _log(ctx, st, 'check_email_white email=%r auth=%d' % (email, auth))
    _save(ctx, st)
    return ctx.ok({'auth': auth}, '★ 邮箱白名单（auth=%d，0=非白名单）' % auth)


def _ep_exchange_yashi(ctx, st):
    """`exchange_yashi_welfare_reward`：**真扣额度、真进包袱**。

    * 额度初值 = `YASHI_SEED_POINT`（**服务端下发值**，客户端只有"上限 1000"这个常量，
      没有发放接口，见常量旁边的说明）。
    * 花费：`type==1`（残页）用 `Monthlycardysgift[id].moneyNumber`（她表里的真价）；
      `type==2`（商品）用 `YaShiBenefit:getNingShenDanInfo()` 的 `price=5`。
    * 应答字段（`YaShiBenefit.lua:224-247` 逐行读出来的）：
      `yashiWelfarePoint`(数) / `yashiExpiredTime`(数) / `currencyVersion`(数) / `msg`(串，可选)。
    """
    gift_id = _s(ctx.param('id'))
    number = max(1, _num(ctx.param('number'), 1))
    etype = _num(ctx.param('type'), 2)
    points = _num(st['yashi'].get('point'))

    if etype == 1:
        info = _monthly_gift().get(gift_id) or _monthly_gift().get(_num(gift_id))
        if not isinstance(info, dict):
            return ctx.fail('该福利不存在（%s）' % gift_id, '★ 雅士福利·残页 id 不在 Monthlycardysgift 表里', errcode=1)
        price = _num(info.get('moneyNumber'), YASHI_NINGSHENDAN_PRICE)
        goods_id = _s(info.get('goodsId'))
    else:
        goods_id = YASHI_NINGSHENDAN_GOODS if not gift_id else gift_id
        price = YASHI_NINGSHENDAN_PRICE

    cost = price * number
    if points < cost:
        return ctx.fail('可用额度不足', '★ 雅士福利·额度不足（有 %d，需 %d）' % (points, cost), errcode=1)
    if cost <= 0:
        return ctx.fail('数据异常', '★ 雅士福利·花费为 0，拒绝兑换', errcode=1)

    new_points = points - cost
    st['yashi']['point'] = new_points
    # ★ 真进包袱（`type==1` 她本地也会 addItem，服务端这份是"服务器掌握的那一份"）
    got = _ic().grant(ctx, goods_id, number) if goods_id else None
    _log(ctx, st, '雅士福利兑换 id=%s number=%d type=%d 花 %d 额度 → %d，得 %s×%d'
         % (gift_id, number, etype, cost, new_points, goods_id, number))
    _save(ctx, st)
    return ctx.ok({
        'yashiWelfarePoint': new_points,
        'yashiExpiredTime': _num(st['yashi'].get('expiredTime')),
        'currencyVersion': _currency_version(ctx),
        'msg': '已兑换 %s×%d' % (goods_id or gift_id, number),
    }, '★ 雅士福利兑换（花 %d 额度，余 %d；%s 已进包袱=%s）'
        % (cost, new_points, goods_id or gift_id, '是' if got is not None else '物品表未收'))


def _ep_join_family(ctx, st):
    """`join_family`：`Role_Family:__joinFamily`（:272）。她读 `data.currencyVersion`（可选）。"""
    fam_id = _s(ctx.param('familyId') or ctx.param('familyid') or ctx.param('family_id'))
    fams = _families()
    fam = fams.get(fam_id)
    if not fam:
        return ctx.fail('门派不存在', '★ 加入门派·familyId=%r 不在 family/family.lua["familys"] 里' % fam_id, errcode=1)
    st['sect']['familyId'] = fam_id
    cv = _currency_version(ctx)
    _log(ctx, st, '加入门派 %s(%s)' % (_s(fam.get('name')), fam_id))
    _save(ctx, st)
    return ctx.ok({'currencyVersion': cv},
                  '★ 加入门派 → %s（%s，family/family.lua 真名）' % (_s(fam.get('name')), fam_id))


def _ep_pvp_verify(ctx, st):
    """`pvp_roleData_verify`：`WaitingLayer.lua:288` / `FubenClient.lua:205`。

    她上行 `roleDatas = {selfCreatedSkillData=…, roleAttrData={looks,jingMax,neiLiLimit,qiMax,
    atk,dodge,def,damage,protect,str,dex,int,con,currStr,currDex,currInt,currCon,inheritCount,age}}`。
    errcode: 0=通过（继续切磋/接受切磋）/ 2=她 PopText("请公平公正的参与游戏")。

    ★ 本模块**只做结构性校验**（形状 + 数值合理性 + 落盘快照），不判作弊：
      原版的作弊阈值在服务端配置里，客户端与公开资料都查不到，**编一个阈值就是拿玩家的正常切磋赌**。
    """
    role = ctx.param('roleDatas')
    if role is None:
        role = ctx.param('role_datas')
    if isinstance(role, str):
        # 明文探针 / `key=value` 正文会把对象编成字符串 ⇒ 先试着解回对象
        try:
            role = json.loads(role)
        except Exception:                         # noqa: BLE001
            role = None
    if role is None and isinstance(ctx.body_obj, dict):
        role = ctx.body_obj.get('roleDatas')
    if not isinstance(role, dict):
        # 上行不是对象 ⇒ 结构上就不合法（她一定会带 roleAttrData）
        return ctx.fail('数据非法', '★ 切磋校验·上行 roleDatas 不是对象（%s）' % type(role).__name__, errcode=1)
    attr = role.get('roleAttrData')
    if isinstance(attr, str):
        try:
            attr = json.loads(attr)
        except Exception:                         # noqa: BLE001
            attr = None
    if not isinstance(attr, dict):
        return ctx.fail('数据非法', '★ 切磋校验·缺 roleAttrData', errcode=1)
    need = ('looks', 'jingMax', 'neiLiLimit', 'qiMax', 'atk', 'dodge', 'def', 'damage', 'protect',
            'str', 'dex', 'int', 'con', 'currStr', 'currDex', 'currInt', 'currCon', 'inheritCount', 'age')
    missing = [k for k in need if attr.get(k) is None]
    if missing:
        return ctx.fail('数据非法', '★ 切磋校验·roleAttrData 缺字段 %s' % ','.join(missing[:6]), errcode=1)
    st['pvp'] = {'userid': _uid(ctx), 'ts': int(time.time()),
                 'inheritCount': _num(attr.get('inheritCount')),
                 'lv': {'atk': _num(attr.get('atk')), 'def': _num(attr.get('def')),
                        'jingMax': _num(attr.get('jingMax')), 'qiMax': _num(attr.get('qiMax'))}}
    _save(ctx, st)
    return ctx.ok({'verify': 1},
                  '★ 切磋/决斗数据校验通过（结构完整，%d 个属性；不判作弊，见 docstring 第 5 条）'
                  % len(need))


def _ep_report_gain_log(ctx, st):
    """`report_gain_log`：`Record.lua:174` 上行 `{log_data=[{type,logData={...,__lindex,__time}}]}`，
    回调里 `errcode==0` 才 `removeAfterData` 把本地日志删掉。**真落盘**。

    ★ 她上传一批就**只留最新 `MAX_COUNT` 条**（`getNeedUpdateData`），收到就必须存住，
      否则 errcode=0 会让她把本地日志删掉 ⇒ 日志真丢（这是数据完整性问题，不是"随便回个 0"）。
    """
    logs = ctx.param('log_data')
    if logs is None and isinstance(ctx.body_obj, dict):
        logs = ctx.body_obj.get('log_data')
    if isinstance(logs, str):
        try:
            logs = json.loads(logs)
        except Exception:                         # noqa: BLE001
            logs = None
    if isinstance(logs, dict):
        logs = [logs]
    st.setdefault('gain_logs', [])
    stored = 0
    if isinstance(logs, list):
        for one in logs[:200]:
            if isinstance(one, dict):
                st['gain_logs'].append({'type': _num(one.get('type')), 'logData': one.get('logData'),
                                        'uid': _uid(ctx), 'ts': int(time.time())})
                stored += 1
    del st['gain_logs'][:-2000]
    _save(ctx, st)
    if stored == 0:
        return ctx.fail('日志数据非法',
                        '★ 收益日志上报·上行 log_data 解析后没有一条可落盘的记录（拒绝，让她的本地日志留着）',
                        errcode=1)
    return ctx.ok({}, '★ 收益日志上报（本次落盘 %d 条，累计 %d 条）' % (stored, len(st['gain_logs'])))


def _ep_check_user_gain_log(ctx, st):
    """`check_user_gain_log`（方法名 `getwxtranstwxplushasGainAfter202509291500`，
    `CommonResults.lua:4344`）：

        errcode == 1 → `confirmBtnFunc()`   （没到 2025-09-29 15:00 之后的继承期数 ⇒ 中断）
        errcode == 0 → 记期数 +1，走继承奖励 `doNoRoleResults(result.arg8)`
        **没有其它分支**（她 else 什么都不做）。

    本模块按 `state["inherit"]["has_gain_log"]` 作答，默认 **1** ⇒ 与"没到继承期"一致，
    不会白送一份继承奖励。要放开就在 state 里把它改成 0（真值由后台决定，不在客户端）。
    """
    has = _num(st['inherit'].get('has_gain_log'), 1)
    _save(ctx, st)
    if has:
        return ctx.fail('尚未达到本期继承奖励条件',
                        '★ 继承奖励条件（has_gain_log=1 ⇒ errcode=1，她走 confirmBtnFunc 中断）', errcode=1)
    return ctx.ok({'hasGain': 0},
                  '★ 继承奖励条件（has_gain_log=0 ⇒ errcode=0，她 doNoRoleResults(arg8) 发奖）')


def _ep_count_single_record(ctx, st):
    """`count_single_record/<type>`：她**只看 errcode**。

    * 写类型（`join_ghost`/`finish_ghost`/`YeGuiRenWu`/`HaoLiXing`/`zhongyuanjie`）
      在她客户端都是"计数上报"（`DEBUG_MODE` 才打印"参与次数加 1"）⇒ **真 +1** 并回 0。
    * 其它类型只当查询（读计数，不写），回 0（她没有上限判定）。
    """
    rtype = _s(ctx.args[0] if ctx.args else '')
    if not rtype:
        rtype = _s(ctx.param('type'))
    if not rtype:
        return ctx.fail('缺少统计类型', '★ count_single_record·URL 尾段没有类型', errcode=1)
    rec = st['records'].get(rtype)
    if not isinstance(rec, dict):
        rec = {'count': 0}
    if rtype in COUNT_WRITE_TYPES:
        rec['count'] = _num(rec.get('count')) + 1
        rec['last'] = int(time.time())
        st['records'][rtype] = rec
        _save(ctx, st)
        return ctx.ok({'count': rec['count']},
                      '★ 统计 %s 计数 +1（现 %d；客户端是计数上报，只看 errcode）' % (rtype, rec['count']))
    st['records'][rtype] = rec
    _save(ctx, st)
    return ctx.ok({'count': rec['count']},
                  '★ 统计 %s 当前计数 %d（查询，不写）' % (rtype, rec['count']))


# --------------------------------------------------------------------------
# 充值返利（累充福利）—— `models/Action/SpringEquinox.lua`
# --------------------------------------------------------------------------
def _recharge_tiers(st):
    """累充档位 + 礼包内容。

    ★ **礼包/档位表在她客户端里不存在**（`SpringEquinox.lua:12-76` 那三段
      `giftList`/`goodsList`/`rewardList` 全是注释掉的样例，真数据由服务端下发）。
      本模块照那三段的**形状**建表，礼包内容用 `store/shoplist.lua` 的**真商品键**填。
      ⇒ 档位金额/礼包内容是**确定性推算**，不是原版配置（见 docstring 第 3 条）。
    """
    cached = _RES_CACHE.get('recharge_tiers')
    if cached:
        return cached
    goods = _ic().goods()
    keys = sorted(goods.keys(), key=lambda k: (len(str(k)), str(k)))
    pool = [k for k in keys if isinstance(goods.get(k), dict) and goods[k].get('itype') in (1, 2)]
    # 三个礼包：福利礼包(全部获得) / 幸运礼包(随机一个) / 稀有礼包(全部获得)
    gifts = [
        {'giftId': 1, 'giftName': '福利礼包', 'giftIcon': 'Image/UI/StoreUI/xiangzi1.png',
         'giftType': 1, 'ridList': ['1001', '1002', '1003', '1004']},
        {'giftId': 2, 'giftName': '幸运礼包', 'giftIcon': 'Image/UI/StoreUI/xiangzi1.png',
         'giftType': 2, 'ridList': ['2001', '2002', '2003', '2004', '2005', '2006', '2007', '2008']},
        {'giftId': 3, 'giftName': '稀有礼包', 'giftIcon': 'Image/UI/StoreUI/xiangzi1.png',
         'giftType': 1, 'ridList': ['3001', '3002', '3003']},
    ]
    goods_map = {}
    n = 0
    for g in gifts:
        for rid in g['ridList']:
            gid = pool[n % len(pool)] if pool else '300004'
            n += 1
            goods_map[rid] = {'goodsId': gid, 'num': 1 if not rid.startswith('2') else 2}
    tiers = []
    for i, money in enumerate((6, 30, 100, 300, 1000, 3000)):
        if i < 3:
            gl = [{'giftId': 1, 'giftNum': i + 1}]
        elif i < 5:
            gl = [{'giftId': 1, 'giftNum': 2}, {'giftId': 3, 'giftNum': 1}]
        else:
            gl = [{'giftId': 2, 'giftNum': 4}, {'giftId': 3, 'giftNum': 2}]
        tiers.append({'id': i + 1, 'needMoney': money, 'giftList': gl})
    out = {'giftList': gifts, 'goodsList': goods_map, 'rewardList': tiers}
    _RES_CACHE['recharge_tiers'] = out
    return out


def _tier_reward(st, tier):
    """把一档的礼包展开成 `{id,num}` 列表（`SpringEquinox:getRewardGoodsInfoList` 同口径）。"""
    r = _recharge_tiers(st)
    goods = r['goodsList']
    gifts = {g['giftId']: g for g in r['giftList']}
    out = []
    for gi in (tier.get('giftList') or []):
        g = gifts.get(_num(gi.get('giftId')))
        if not g:
            continue
        num = max(1, _num(gi.get('giftNum'), 1))
        for rid in g['ridList']:
            info = goods.get(rid)
            if not isinstance(info, dict):
                continue
            if g.get('giftType') == 2:
                # 随机礼包：她 `getRewardGoodsInfoList` 里只按"一个背包位"估算，
                # 真正的随机在服务端 ⇒ 这里用确定性抽签（同一档位每次同一件）
                pick = g['ridList'][_seed('tier', tier.get('id'), rid) % len(g['ridList'])]
                info = goods.get(pick) or info
            out.append({'id': _s(info.get('goodsId')), 'num': _num(info.get('num'), 1) * num})
    return out


def _ep_recharge_info(ctx, st):
    """`get_recharge_benefits_info`：`SpringEquinox:init`（:102）读
    `giftList` / `goodsList` / `rewardList` / `totalRecharge`。"""
    r = _recharge_tiers(st)
    total = _num(st['recharge'].get('totalRecharge'))
    claimed = set(_num(x) for x in (st['recharge'].get('claimed') or []))
    reward_list = []
    for tier in r['rewardList']:
        tid = _num(tier.get('id'))
        if tid in claimed:
            state = 2                      # 已领取
        elif total >= _num(tier.get('needMoney')):
            state = 1                      # 可领取
        else:
            state = 0                      # 未达成
        reward_list.append({'id': tid, 'needMoney': _num(tier.get('needMoney')),
                            'state': state, 'giftList': _clone(tier.get('giftList') or [])})
    _save(ctx, st)
    return ctx.ok({
        'giftList': _clone(r['giftList']),
        'goodsList': _clone(r['goodsList']),
        'rewardList': reward_list,
        'totalRecharge': total,
    }, '★ 累充返利信息（%d 档；礼包形状照 SpringEquinox.lua 注释样例，内容为确定性推算）'
        % len(reward_list))


def _ep_recharge_reward(ctx, st):
    """`get_recharge_benefits_reward`：`SpringEquinox:getRewards`（:220）读
    `data.reward`(数组 {id,num}) / `data.dataVer` / `data.currencyVersion` / `data.msg`。
    真进包袱（`GoodsHelper:fromNetworkGrantGoods`）。"""
    tid = _num(ctx.param('id') or ctx.param('tid'))
    r = _recharge_tiers(st)
    tier = None
    for t in r['rewardList']:
        if _num(t.get('id')) == tid:
            tier = t
            break
    if tier is None:
        return ctx.fail('奖励档位不存在', '★ 累充返利·档位 %d 不在档位表里' % tid, errcode=1)
    total = _num(st['recharge'].get('totalRecharge'))
    if total < _num(tier.get('needMoney')):
        return ctx.fail('累计充值未达到该档位',
                        '★ 累充返利·未达成（累计 %d 元 / 需要 %d 元）' % (total, _num(tier.get('needMoney'))),
                        errcode=1)
    claimed = [_num(x) for x in (st['recharge'].get('claimed') or [])]
    if tid in claimed:
        return ctx.fail('该档位已领取过', '★ 累充返利·档位 %d 已领过' % tid, errcode=1)
    reward = _tier_reward(st, tier)
    for one in reward:
        _ic().grant(ctx, one['id'], one['num'])
    claimed.append(tid)
    st['recharge']['claimed'] = claimed
    _save(ctx, st)
    return ctx.ok({
        'reward': reward,
        'dataVer': _dataver(ctx),
        'currencyVersion': _currency_version(ctx),
        'msg': '已领取第 %d 档累充福利' % tid,
    }, '★ 累充返利领取（档位 %d，%d 件已进包袱）' % (tid, len(reward)))


# --------------------------------------------------------------------------
# 挑战地图任务 —— `models/Action/ChallengeClearTimes.lua`（"江湖轶闻"清理任务）
# --------------------------------------------------------------------------
def _cm_state(ctx):
    """`challenge_map.py` 的通关记录（**同一份数据，不另记**）。"""
    try:
        d = ctx.load_json('challengemap_state.json', None)
        return d if isinstance(d, dict) else {}
    except Exception:                             # noqa: BLE001
        return {}


def _cm_clear_times(ctx, con_id):
    """`ChallengeClearTimes:getMapClearTimes`（:612）：按条件表的 `fbid` 列表，把
    `map_list`（`{map_id,times}`）里这些副本的次数加起来。

    次数来源 = `work/challengemap_state.json` 的 `finished`（`challenge_map.py` 通关时写的，
    **同一份数据不另记**）；它没有"次数"这种累加字段（键是 mapId），
    所以**通关过 1 次就算 1 次**（够 `times==1` 那批条件用；`times>1` 的累积条件在没有
    真正的次数记录前不会误判为已完成 —— 保守，不会白送奖励）。
    """
    con = _pick(_tasktj(), con_id)
    if not isinstance(con, dict):
        return 0, []
    fbid = con.get('fbid') or []
    st = _cm_state(ctx)
    finished = st.get('finished') if isinstance(st.get('finished'), dict) else {}
    if not finished:
        finished = st.get('entered') if isinstance(st.get('entered'), dict) else {}
    total = 0
    rows = []
    for mid in fbid:
        n = _num(_pick(finished, mid), 0)
        if n:
            rows.append({'map_id': _s(mid), 'times': n})
            total += n
    return total, rows


def _pick(table, key):
    """她表里的键可能是数字也可能是字符串（`fz_luatable` 按原文保留）⇒ 两种都试。"""
    if not isinstance(table, dict):
        return None
    for k in (_s(key), _num(key), key):
        try:
            if k in table:
                return table[k]
        except TypeError:
            continue
    return None


def _cm_task_data(ctx, st):
    """`get_challengemap_task_info` 的应答体（`ChallengeClearTimes:init`（:36）读
    `act_name`(串) / `detail_desc`(**数组**) / `task_list`(数组) / `map_list`(数组)）。

    任务表：`activity/challengetaskPZ.lua["Sheet1"]`（9 条，字段 `id/tasktitle/taskdesc/rewards/condition`）；
    条件表：`activity/challengetaskTJ.lua["Sheet1"]`（32 条 `{id,fbid,times}`）；
    通关次数：`work/challengemap_state.json["finished"]`（`challenge_map.py` 落的那份，**同一份数据不另记**）。
    状态：0 未完成 / 1 已完成 / 2 已领取（`ChallengeClearTimes.RewardState`）。
    """
    claimed = set(_num(x) for x in (st['challenge'].get('claimed') or []))
    pz = _taskpz()
    tj = _tasktj()
    tasks = []
    map_list = {}

    def _key(v):
        if not isinstance(v, dict):
            return _num(v)
        return _num(v.get('id'))

    for _tid, task in sorted(pz.items(), key=lambda kv: _key(kv[1])):
        if not isinstance(task, dict):
            continue
        task_id = _num(task.get('id'))
        cond = task.get('condition')
        conds = []
        if isinstance(cond, list) and cond and _s(cond[0]) == 'and':
            conds = [_num(x) for x in (cond[1] or [])]
        elif isinstance(cond, list):
            conds = [_num(x) for x in cond if not isinstance(x, list)]
        ok = bool(conds)
        for cid in conds:
            row = _pick(tj, cid) or {}
            need = _num(row.get('times'), 1)
            got, rows = _cm_clear_times(ctx, cid)
            for r in rows:
                map_list[r['map_id']] = {'map_id': r['map_id'], 'times': r['times']}
            if got < need:
                ok = False
        if task_id in claimed:
            state = 2
        elif ok:
            state = 1
        else:
            state = 0
        rewards = []
        for rw in (task.get('rewards') or []):
            if isinstance(rw, list) and len(rw) >= 2:
                rewards.append({'id': _s(rw[0]), 'num': _num(rw[1], 1)})
        tasks.append({'id': task_id, 'state': state, 'reward': rewards,
                      'tasktitle': _s(task.get('tasktitle')), 'taskdesc': _s(task.get('taskdesc'))})
    return {
        'act_name': '江湖轶闻·挑战地图任务',
        'detail_desc': ['通关活动副本累积次数，达成后可在本面板领取奖励。',
                        '任务条件与奖励取自 activity/challengetaskPZ.lua 与 challengetaskTJ.lua。'],
        'task_list': tasks,
        'map_list': list(map_list.values()),
    }


def _ep_cm_task_info(ctx, st):
    data = _cm_task_data(ctx, st)
    _save(ctx, st)
    n_ready = sum(1 for t in data['task_list'] if _num(t.get('state')) == 1)
    return ctx.ok(data, '★ 挑战地图任务（%d 条任务 / %d 条可领 / %d 张副本有通关记录）'
                  % (len(data['task_list']), n_ready, len(data['map_list'])))


def _ep_cm_task_reward(ctx, st):
    """`get_challengemap_task_reward`：`ChallengeClearTimes:doReward`（:89）读
    `data.reward`(数组 {id,num}) / `data.dataVer` / `data.currencyVersion` / `data.msg`。
    她先 `checkBagIsEnough()` 决定 `isEmail`（背包满就发邮件）；本模块**真发进包袱**
    （`GoodsHelper:fromNetworkGrantGoods` → 她本地背包），并发不出时用 `msg` 说明。"""
    data = _cm_task_data(ctx, st)
    claimed = [_num(x) for x in (st['challenge'].get('claimed') or [])]
    rewards = []
    for t in data['task_list']:
        if _num(t.get('state')) != 1:
            continue
        for rw in (t.get('reward') or []):
            rewards.append({'id': _s(rw.get('id')), 'num': _num(rw.get('num'), 1)})
        claimed.append(_num(t.get('id')))
    if not rewards:
        return ctx.fail('暂无可领取的任务奖励',
                        '★ 挑战地图任务奖励·没有 state==1 的任务（她 checkTaskIsFinish 为假）', errcode=1)
    for one in rewards:
        _ic().grant(ctx, one['id'], one['num'])
    st['challenge']['claimed'] = sorted(set(claimed))
    _save(ctx, st)
    return ctx.ok({
        'reward': rewards,
        'dataVer': _dataver(ctx),
        'currencyVersion': _currency_version(ctx),
        'msg': '已领取 %d 件任务奖励' % len(rewards),
    }, '★ 挑战地图任务领奖（%d 件已进包袱）' % len(rewards))


# --------------------------------------------------------------------------
# 商人（`models/Store/Store.lua` 那一套"新式商店"）
# --------------------------------------------------------------------------
def _merchant_cfg(merchant_id):
    return _store_config().get(merchant_id) or _store_config().get(_s(merchant_id)) or {}


def _shelf_pool():
    """商人的"货"：`store/shoplist.lua["Sheet1"]` 的 2228 件真商品（键就是 `getGoodsResClass` 查的那个）。"""
    cached = _RES_CACHE.get('shelf_pool')
    if cached is not None:
        return cached
    goods = _ic().goods()
    pool = sorted([k for k, v in goods.items() if isinstance(v, dict) and v.get('name')],
                  key=lambda k: _seed('pool', k))
    _RES_CACHE['shelf_pool'] = pool
    return pool


def _shelf_of(merchant_id, cfg, refresh=0):
    """按 `merchantId` 做**确定性**抽签铺货架。

    ★ `storeConfig.goodsshelf` 给的是货架号（10000–10069），这个号在她 1 万多个
      `res/script/**` 里**查不到**对应的货架内容表（只在原版服务端 DB）⇒ 本模块
      用放 `shoplist` 里的真商品、按 `md5(merchantId|货架号|刷新次数)` 排序取一段。
      同一输入永远同一批货（不会每次重启就换脸）。**这是确定性推算，不是原版配置。**
    """
    pool = _shelf_pool()
    if not pool:
        return []
    shelves = cfg.get('goodsshelf') or []
    shelf_no = ''
    if isinstance(shelves, list) and shelves:
        first = shelves[0]
        shelf_no = _s(first[0]) if isinstance(first, list) and first else _s(first)
    seed = _seed('shelf', merchant_id, shelf_no, refresh)
    ordered = sorted(pool, key=lambda k: _seed('pick', seed, k))
    shownums = _num(cfg.get('shownums'), -1)
    n = shownums if 4 <= shownums <= 30 else 8
    unit = ''
    dc = cfg.get('displaycurrency') or []
    if isinstance(dc, list) and dc:
        unit = _s(dc[0])
    if not unit:
        unit = 'money'
    out = []
    for i, gid in enumerate(ordered[:n]):
        g = _ic().goods().get(gid) or {}
        # ★ 价格：货架表里没有价（只在服务端 DB）⇒ 用商品键的确定性散列给稳定正整数
        base = 10 + (_seed('price', merchant_id, gid) % 990)
        itype = _num(g.get('itype'), 1)
        price = base * (10 if itype in (10,) else 1)
        out.append({
            'storeId': (i + 1) * 1000 + (_seed('sid', merchant_id, gid) % 1000),
            'goodsId': _s(gid),
            'price': price,
            'priceUnit': unit,
            'unitCount': 1,
            'discount': 0,
            'limitType': 1,
            'limitCount': -1,
            # ★★ 老板 2026-09-28 报「商人购买时说达到限购条件，无法购买」。
            #   根因：这里原来给 **0**，而客户端 `Store.lua:940-945` 是
            #       if itemClass:getLimitBoughtCount() then        -- ★ Lua 里 0 是**真**！
            #           if goods.count + getLimitBoughtCount() > getLimitCount() then
            #               return false, "此商品已达到限购条件…"
            #   于是 `1 + 0 > -1` ⇒ **恒为真** ⇒ 每件货都被判超限、永远买不了。
            #   ⇒ 给 **None**（JSON `null` → Lua `nil`）让那个 `if` 直接跳过
            #     （`limitType=1` 本来就是"不限购"，nil 才是正确的"没有已购数"表达）。
            #   下面 `get_merchant_store_list` 里还会按真实已购数回填（那时是数字，正确）。
            'limitBoughtCount': None,
            'count': 1 + (_seed('cnt', merchant_id, gid) % 3),
        })
    return out


def _merchant_state(st, merchant_id):
    m = st['merchant'].get(merchant_id)
    if not isinstance(m, dict):
        m = {'goods': [], 'bought': {}, 'refreshed': 0}
        st['merchant'][merchant_id] = m
    if not isinstance(m.get('goods'), list):
        m['goods'] = []
    if not isinstance(m.get('bought'), dict):
        m['bought'] = {}
    return m


def _ep_merchant_store_list(ctx, st):
    """`get_merchant_store_list`：`Store:initStore`（:344-383）读
    `goodsList` / `currencyList` / `currencyShowList` / `refreshTime` / `refreshCost` /
    `refreshState` / `refreshCurrencyName` / `currencyVersion`(可选)。"""
    merchant_id = _s(ctx.param('merchantId') or ctx.param('merchant_id'))
    is_refresh = _num(ctx.param('isRefresh'))
    cfg = _merchant_cfg(merchant_id)
    if not cfg:
        return ctx.fail('商人不存在', '★ 商人列表·merchantId=%r 不在 store/storeConfig.lua["Sheet1"] 里' % merchant_id,
                        errcode=1)
    m = _merchant_state(st, merchant_id)
    if is_refresh and m.get('goods'):
        m['refreshed'] = _num(m.get('refreshed')) + 1
    if not m.get('goods') or is_refresh:
        m['goods'] = _shelf_of(merchant_id, cfg, _num(m.get('refreshed')))
        m['bought'] = {}
    # 已买数量回填（`limitBoughtCount` 她拿去做限购显示；`limitType` 1=不限/2=日/3=周/4=月）
    bought = m.get('bought') or {}
    for it in m['goods']:
        # ★★ 老板 2026-09-28 报「达到限购条件，无法购买」。
        #   关键：`limitType=1` 是"**不限购**"，此时 `limitBoughtCount` 必须给 **None**
        #   （JSON null → Lua nil），否则客户端 `Store.lua:940` 的
        #   `if itemClass:getLimitBoughtCount() then`（**Lua 里 0 为真**）
        #   会带着 `limitCount=-1` 走进 `count + bought > -1` ⇒ **恒判超限**。
        #   ⚠️ 这里原来无条件写 `_num(...)`（=0）会把 `_shelf_of` 里的 None 覆盖掉，
        #      修复等于白做 —— 所以按 `limitType` 分派：不限购给 None，限购才给数字。
        _lt = _num(it.get('limitType'), 1)
        _bought_n = _num(bought.get(_s(it.get('storeId'))))
        it['limitBoughtCount'] = None if _lt in (0, 1) else _bought_n
        # `count` 是"货架上还剩几个"（`StoreSellBag:initList` 把它塞进 sellList）
        it['count'] = max(0, _num(it.get('count')) - _bought_n)

    # 货币列表：她 `Store:__initCurrencyList` 自己会补 money/gold，这里给"商品涉及的币种 + 商人展示币种"
    cur_units = []
    for it in m['goods']:
        u = _s(it.get('priceUnit'))
        if u and u not in cur_units:
            cur_units.append(u)
    for u in (cfg.get('displaycurrency') or []):
        u = _s(u)
        if u and u not in cur_units:
            cur_units.append(u)
    ic = _ic()
    currency_list = []
    for u in cur_units:
        currency_list.append({
            'unit': u,
            'name': ic.currency_name(u),
            'num': ic.get_currency(ctx, u),
            'limit': ic.currency_limit(u),
            'cycleLimit': -1,
            'cycleNum': 0,
        })

    # 刷新：`Refreshtype=[2,8,"yuanbao",50,40,4,1]`（第 3/4 项就是币种与数量）
    rt = cfg.get('Refreshtype') or []
    refresh_cost = _num(rt[3]) if len(rt) > 3 else 0
    refresh_unit = _s(rt[2]) if len(rt) > 2 else 'yuanbao'
    can_refresh = _bool(cfg.get('refreshrecall'), False) or _num(cfg.get('shownums'), -1) not in (-1,)
    if not can_refresh:
        refresh_state = 0
    elif refresh_cost and ic.get_currency(ctx, refresh_unit) < refresh_cost:
        refresh_state = 3
    else:
        refresh_state = 1
    _save(ctx, st)
    return ctx.ok({
        'goodsList': _clone(m['goods']),
        'currencyList': currency_list,
        'currencyShowList': [],
        # ★★ 老板 2026-09-28 报「醉仙秘市点岳烨购买 → 该商品已更新，无法购买」。
        #   根因：这里原本给 `int(time.time())`（**此刻**），但客户端
        #   `Store:checkNeedRefresh()`（`models/Store/Store.lua:1066-1074`）是
        #       `if GetTime() > self._refreshTime then return true end`
        #   而 `buyGoods`（:473-480）一旦 `checkNeedRefresh()` 为真就
        #       `PopText("该商品已更新，无法购买"); return`
        #   ⇒ 下发的时刻**永远早于**玩家点击的那一刻 ⇒ **永远买不了**。
        #   `refreshTime` 的语义是「**下次**刷新时刻」（`Store.lua:378` 赋值，
        #   :1068 拿它和当前时间比），所以必须给**未来**。
        #   商人配置里没有自动刷新周期（`Refreshtype` 是手动刷新的价），
        #   所以给一个远期时刻 = 不自动刷新，要刷新得玩家自己点（`refreshState` 管）。
        'refreshTime': int(time.time()) + 30 * 86400,
        'refreshCost': refresh_cost,
        'refreshState': refresh_state,
        'refreshCurrencyName': ic.currency_name(refresh_unit),
        'currencyVersion': _currency_version(ctx),
    }, '★ 商人 %s（%s，%d 件货；货架为确定性推算，见 docstring 第 1 条）'
        % (merchant_id, _s(cfg.get('id')), len(m['goods'])))


def _ep_buy_merchant_goods(ctx, st):
    """`buy_merchant_goods`：`Store:buyGoods`（:792）上行
    `{merchantId, goodsList=[{count,storeId}], recordList={sellGoodsList=[{itemId,count}],
    redeemGoodsList=[{itemId,count}], getMoney}}`；应答读
    `goodsList`(数组 {id,num}) / `dataVer` / `currencyVersion` / `yashi_expired_time`。

    错码是她定的：1=数据非法（"请合法游戏"）/ 2=商品列表已刷新（她会重新 `initStore`）。
    本模块**真扣钱、真给货**（走 `items_currency`）。
    """
    merchant_id = _s(ctx.param('merchantId') or ctx.param('merchant_id'))
    cfg = _merchant_cfg(merchant_id)
    if not cfg:
        return ctx.fail('商人不存在', '★ 购买·merchantId=%r 不在 storeConfig 里' % merchant_id, errcode=1)
    m = _merchant_state(st, merchant_id)
    if not m.get('goods'):
        m['goods'] = _shelf_of(merchant_id, cfg, _num(m.get('refreshed')))
    by_store = {}
    for it in m['goods']:
        by_store[_s(it.get('storeId'))] = it

    goods_list = ctx.param('goodsList')
    if isinstance(goods_list, str):
        try:
            goods_list = json.loads(goods_list)
        except Exception:                         # noqa: BLE001
            goods_list = None
    if not isinstance(goods_list, list):
        goods_list = []
    record = ctx.param('recordList')
    if isinstance(record, str):
        try:
            record = json.loads(record)
        except Exception:                         # noqa: BLE001
            record = None
    if not isinstance(record, dict):
        record = {}

    if not goods_list and not record:
        return ctx.fail('没有要结算的商品', '★ 购买·上行既没有 goodsList 也没有 recordList', errcode=1)

    ic = _ic()
    gained = []
    spent = {}                                    # unit -> 数量
    # ---- 买入（她 `goodsList=[{count,storeId}]`）----
    for one in goods_list:
        if not isinstance(one, dict):
            return ctx.fail('数据非法', '★ 购买·goodsList 元素不是对象', errcode=1)
        it = by_store.get(_s(one.get('storeId')))
        if it is None:
            return ctx.fail('商品列表已更新，请重新选择你要购买的商品',
                            '★ 购买·storeId=%s 不在当前货架上（她走 errcode=2 重新 initStore）'
                            % _s(one.get('storeId')), errcode=2)
        cnt = _num(one.get('count'))
        if cnt <= 0:
            return ctx.fail('数据非法', '★ 购买·count=%s' % _s(one.get('count')), errcode=1)
        if _num(it.get('count')) < cnt:
            return ctx.fail('商品已售罄', '★ 购买·%s 货架只剩 %d，要买 %d'
                            % (_s(it.get('goodsId')), _num(it.get('count')), cnt), errcode=2)
        unit = _s(it.get('priceUnit')) or 'money'
        cost = _num(it.get('price')) * cnt
        spent[unit] = spent.get(unit, 0) + cost
        gained.append({'id': _s(it.get('goodsId')), 'num': cnt * max(1, _num(it.get('unitCount'), 1))})
        it['count'] = _num(it.get('count')) - cnt
        m['bought'][_s(it.get('storeId'))] = _num(m['bought'].get(_s(it.get('storeId')))) + cnt

    # ---- 卖出 / 赎回（recordList；`getMoney` 是她本地算的碎银收支）----
    money_delta = 0
    rl = record.get('sellGoodsList')
    if isinstance(rl, list):
        for one in rl:
            if not isinstance(one, dict):
                continue
            item_id = _s(one.get('itemId'))
            cnt = _num(one.get('count'))
            if not item_id or cnt <= 0:
                return ctx.fail('数据非法', '★ 出售·itemId=%r count=%s' % (item_id, _s(one.get('count'))), errcode=1)
            # 她 `Store:__settlementLocal` 会 `addItemCount(itemId, -count)` 且 `getPrice()` 来自货架
            if not ic.spend(ctx, item_id, cnt):
                return ctx.fail('物品不足', '★ 出售·%s 不足 %d 件' % (item_id, cnt), errcode=1)
            st['sold'].setdefault(_uid(ctx), {})
            st['sold'][_uid(ctx)][item_id] = _num(st['sold'][_uid(ctx)].get(item_id)) + cnt
            money_delta += _num(one.get('price')) * cnt
    rl = record.get('redeemGoodsList')
    if isinstance(rl, list):
        for one in rl:
            if not isinstance(one, dict):
                continue
            item_id = _s(one.get('itemId'))
            cnt = _num(one.get('count'))
            if not item_id or cnt <= 0:
                return ctx.fail('数据非法', '★ 赎回·itemId=%r count=%s' % (item_id, _s(one.get('count'))), errcode=1)
            have = _num((st['sold'].get(_uid(ctx)) or {}).get(item_id))
            if have < cnt:
                return ctx.fail('没有可赎回的物品', '★ 赎回·%s 在商人处只有 %d 件，要赎回 %d' % (item_id, have, cnt),
                                errcode=1)
            ic.grant(ctx, item_id, cnt)
            st['sold'][_uid(ctx)][item_id] = have - cnt
            money_delta -= _num(one.get('price')) * cnt
    gm = _num(record.get('getMoney'))
    if gm:
        money_delta = gm if not money_delta else money_delta
    if money_delta:
        ic.add_currency(ctx, 'money', money_delta)

    # ---- 扣买入的钱（不够就整体拒绝，**一点不改**）----
    for unit, cost in spent.items():
        if ic.get_currency(ctx, unit) < cost:
            return ctx.fail('%s不足' % ic.currency_name(unit),
                            '★ 购买·%s 不足（有 %d，需 %d）' % (ic.currency_name(unit),
                                                            ic.get_currency(ctx, unit), cost), errcode=1)
    for unit, cost in spent.items():
        ic.add_currency(ctx, unit, -cost)
    for one in gained:
        ic.grant(ctx, one['id'], one['num'])

    _log(ctx, st, '商人购买 %s：得 %s，花 %s' % (merchant_id, gained, spent))
    _save(ctx, st)
    return ctx.ok({
        'goodsList': gained,
        'dataVer': _dataver(ctx),
        'currencyVersion': _currency_version(ctx),
        'yashi_expired_time': _num(st['yashi'].get('expiredTime')),
    }, '★ 商人购买结算（得 %d 种货，花 %s；钱走 items_currency）' % (len(gained), spent or '0'))


def _ep_merchant_event_info(ctx, st):
    """`get_merchant_event_info`：`SkillResExchange:init`（:23）读
    `location`(**数组** `{mapId,roomId}`) / `hongDianState`。

    活动 → 商人位置的映射：**原版只在服务端 DB 里**，客户端拿不到
    （`models/Action/SkillResExchange.lua` 只把 activityId 送上去，没有任何本地表）。

    ★★ 老板 2026-09-28 报「醉仙秘市进去是财神商会」时的根因**不在这里**：
      那时 `ActionLayer.lua:1079` 送上来的是 `data.activity_id`，
      而 `fz_boot_server.get_spring_festival_status` **没下发这个字段**
      ⇒ 这里收到空字符串 ⇒ 散列固定落到 `25cyshopcaishen`。
      （已在 `fz_boot_server.py` 补上 `activity_id`/`name`，现在能拿到真值了。）

    本函数据此改成**显式映射**，不再"随活动名散列"：
      * `zuixian`（醉仙秘市）→ `25cyshopcaishen`（财神商会）。
        理由：`25cy*` 这一整族（33 家）都以**醉仙武意**结算，属于同一活动家族；
              原版精确点位不可得，选家族里已有明确位置的一家，行为可解释、可再调。
      * `wushi`（武识互通）→ `25bmartialnpc`（武学商人，与"武识"同族）。
      * 其它活动**退回散列**，但会打印出来，便于日后逐个补映射。
    """
    activity_id = _s(ctx.param('activityId') or ctx.param('activity_id'))
    conf = _store_config()
    if not conf:
        return ctx.fail('活动商人未配置', '★ 商人事件·store/storeConfig.lua 读不到', errcode=1)
    ids = sorted(conf.keys())

    #: 显式映射（原版精确点位不可得，这里是可解释的近似；要改就改这张表）
    explicit = {
        'zuixian': '25cyshopcaishen',
        'wushi': '25bmartialnpc',
    }
    pick = explicit.get(activity_id) if activity_id else None
    if pick not in conf:
        pick = ids[_seed('event', activity_id) % len(ids)] if ids else None
        if activity_id and activity_id not in explicit:
            print('[商人事件] activity=%r 没有显式映射，散列挑到 %s'
                  % (activity_id, pick))
    if not pick:
        return ctx.fail('活动商人未配置', '★ 商人事件·storeConfig 里没有商人', errcode=1)
    cfg = conf.get(pick) or {}
    loc = cfg.get('location') or []
    map_id = _s(loc[0]) if len(loc) > 0 else ''
    room_id = _s(loc[1]) if len(loc) > 1 else ''
    if not map_id or not room_id:
        return ctx.fail('活动商人位置缺失', '★ 商人事件·%s 的 location 不完整' % pick, errcode=1)
    _save(ctx, st)
    return ctx.ok({
        'location': [map_id, room_id],
        'hongDianState': False,
    }, '★ 商人事件（activityId=%s → 商人 %s 的真 location %s/%s%s）'
        % (activity_id or '(空)', pick, map_id, room_id,
           '（显式映射）' if activity_id in explicit else '（散列）'))


# --------------------------------------------------------------------------
# 师门易物堂 —— `models/Store/TeacherBuildResExchangeStore.lua`
# --------------------------------------------------------------------------
def _sect_shop_entries(st):
    """易物堂的可兑换条目（`get_sect_supportShop` 的 `list` / `buy_sect_supportGoods` 的同一份）。

    内容 = 她自己的 `family/sectBuildDonate.lua`（68 条
    `{donateid,titletext,donatetext,donatecondition,upresources,renown,donate,unlockcondition}`）：
    * `donatecondition` = **要交的建材/属性**（`[["bmaterials1",5]]`）→ `costList`；
    * `upresources`/`renown`/`donate` = **给的东西**（她表里的真值）→ `gainList`
      （`upresources`=修筑度，她客户端 `getCHAttrName` 里没有这项 ⇒ 归到 `sgbpoint` 贡献昌盛度）；
    * `unlockcondition` = 解锁门槛，键有 4 种（我统计过 68 条的分布）：
      `buildinglevel`(492 次) `unionleave`(47) `condilevel`(13) `factionstate`(12)；
      只有 6 条**没有任何门槛**。
    ⇒ 条目清单是从她表里真取的，不是编的。
    """
    cached = _RES_CACHE.get('sect_entries')
    if cached is not None:
        return cached
    out = []
    for did, row in sorted(_denote().items(), key=lambda kv: _num(kv[1].get('donateid') if isinstance(kv[1], dict) else kv[0])):
        if not isinstance(row, dict):
            continue
        cost = []
        for c in (row.get('donatecondition') or []):
            if isinstance(c, list) and len(c) >= 2:
                cost.append({'id': _s(c[0]), 'number': _num(c[1], 1)})
        if not cost:
            continue
        gain = []
        for k, label in (('upresources', None), ('renown', 'renown'), ('donate', 'donate')):
            n = _num(row.get(k))
            if n > 0:
                gain.append({'id': label or 'sgbpoint', 'number': n})
        unlock = []
        for c in (row.get('unlockcondition') or []):
            if isinstance(c, list) and len(c) >= 2:
                unlock.append({'key': _s(c[0]), 'a': _num(c[1]), 'b': _num(c[2]) if len(c) > 2 else 0})
        out.append({'id': _num(row.get('donateid'), _num(did)),
                    'titleText': _s(row.get('titletext')),
                    'contentText': _s(row.get('donatetext')),
                    'unlockText': _s(row.get('text')),
                    'unlock': unlock,
                    'cost': cost, 'gain': gain,
                    'familyId': _s(row.get('familyId'))})
    _RES_CACHE['sect_entries'] = out
    return out


def _build_lv(ctx):
    """她易物堂的门槛里 492 次都是 `buildinglevel` ⇒ 建筑等级得从 `teacher_build.py`
    已经在写的 `work/teacherbuild_state.json` 读（**同一份数据不另记**）。

    那份 state 按 key 分档、每档有 `builds{buildingid:{buildLv,...}}`；
    key 不是 `family.lua` 的字符串 id（它按自己的口径编号）⇒ 取**第一个**有 `builds` 的档
    （单机私服只有一份角色档）。读不到就返回空 ⇒ 所有带门槛的条目按 `state=0`（未解锁）呈现。
    """
    try:
        d = ctx.load_json('teacherbuild_state.json', None)
    except Exception:                             # noqa: BLE001
        d = None
    if not isinstance(d, dict):
        return {}
    for _k, v in d.items():
        if isinstance(v, dict) and isinstance(v.get('builds'), dict):
            return v['builds']
    return {}


def _sect_unlocked(ctx, entry):
    """按她 `unlockcondition` 判这条能不能兑（**失败一律 conservative = 未解锁**）。"""
    conds = entry.get('unlock') or []
    if not conds:
        return True
    builds = _build_lv(ctx)
    for c in conds:
        key = _s(c.get('key'))
        if key in ('buildinglevel', 'condilevel'):
            row = _pick(builds, c.get('a')) or {}
            lv = _num(row.get('buildLv'), 0)
            if lv < _num(c.get('b')):
                return False
        else:
            # `unionleave`(师门等级) / `factionstate`(门派状态) 我这边没有可信来源
            # ⇒ 保守按"未满足"处理（她面板上就是灰着 + 显示 `text` 解锁说明），
            #   绝不谎报"已解锁"让她点进来被服务端拒绝。
            return False
    return True



def _find_sect_entry(st, reward_id):
    for e in _sect_shop_entries(st):
        if _num(e.get('id')) == _num(reward_id):
            return e
    return None


def _sect_bmaterials_file():
    """建材的**权威账本**文件路径。

    ★ 统一「两份账」（2026-09-28）：
      `bmaterials1..6` 原来被 `teacherbuild_state.json[<family>]` 和本模块的
      `sect.materials` **各记一份**。权威应是 `teacherbuild_state`（师门捐献/建筑升级
      用的就是它）。
      放大分叉的写法是 `_sect_have` 里的
        `_pick(materials,key) or _num(_ic().get_count(...))`
      —— `items_currency.get_count()` 拿不到时回 **0（不是 None）**，而 0 是 falsy
      ⇒ 背包空时直接落到 `sect.materials` 的**种值**（bmaterials1=200…），
        与 teacherbuild 的 360 **必然不同**。
      现改为：真背包 → teacherbuild 账本 → （旧数据兜底）sect.materials。
    """
    return os.path.join(os.path.dirname(os.path.abspath(__file__)),
                        '..', 'teacherbuild_state.json')


def _sect_bmaterials(key, default=0):
    """从 `teacherbuild_state.json` 读某个建材（取第一个门派分节）。"""
    try:
        with open(_sect_bmaterials_file(), encoding='utf-8') as f:
            tb = json.load(f)
    except Exception:                             # noqa: BLE001
        return default
    for k, v in tb.items():
        if isinstance(v, dict) and key in v:
            return _num(v.get(key))
    return default


def _sect_bmaterials_set(key, val):
    """写回 `teacherbuild_state.json`（所有含该键的门派分节都写）。"""
    p = _sect_bmaterials_file()
    try:
        with open(p, encoding='utf-8') as f:
            tb = json.load(f)
    except Exception:                             # noqa: BLE001
        return False
    hit = False
    for k, v in tb.items():
        if isinstance(v, dict) and key in v:
            v[key] = int(val)
            hit = True
    if hit:
        with open(p, 'w', encoding='utf-8') as f:
            json.dump(tb, f, ensure_ascii=False, indent=1)
    return hit


def _sect_have(ctx, st, key):
    """师门建材 / 贡献那类**角色属性**的余额。

    ★ `bmaterials1..6`（三合土/青石砖/楠木/汉白玉/琉璃瓦/生漆）与 `donate`（佳绩）/
      `renown`（资历）/ `sgbpoint`（贡献昌盛度）/ `gbpoint`（师门昌盛度）/ `reputation`（个人功绩）
      全在 `Role.lua:getCHAttrName` 那张 `tabs` 里 —— 它们是**角色属性**，
      **不在** `others/monetarymanagement.lua`（`CurrencyUtil` 查的就是那张表）里
      ⇒ 不能记到 `items_currency` 的货币账上（那样会跟 `updateCurrencyByType` 那套混在一起）。
      本模块把这类属性记在自己 state 的 `sect.materials` 里（初值见 `_sect_seed_materials`）。
      只有真货币（`amartial`/`dmartial`/`money`…）才走 `items_currency`。
    """
    key = _s(key)
    if key in SECT_CURRENCIES:
        return _num(_ic().get_currency(ctx, key))
    # ① 真背包（拿不到回 0，所以要用 >0 判断，不能靠 falsy）
    bag = _num(_ic().get_count(ctx, key))
    if bag > 0:
        return bag
    # ② ★ 建材的权威账本（teacherbuild_state）
    if key.startswith('bmaterials'):
        tb = _sect_bmaterials(key, default=-1)
        if tb >= 0:
            return tb
    # ③ 旧数据兜底：本模块的 sect.materials
    n = _pick(st['sect'].get('materials') or {}, key)
    if n is not None:
        return _num(n)
    return bag


def _sect_spend(ctx, st, key, n):
    """扣师门属性/建材；不够返回 False（**一点不扣**）。"""
    key = _s(key)
    n = _num(n)
    if key in SECT_CURRENCIES:
        return _ic().add_currency(ctx, key, -n) is not None
    have = _sect_have(ctx, st, key)
    if have < n:
        return False
    if key.startswith('bmaterials') and _sect_bmaterials_set(key, have - n):
        return True
    st['sect'].setdefault('materials', {})
    left = have - n
    if left > 0:
        st['sect']['materials'][key] = left
    else:
        st['sect']['materials'].pop(key, None)
    return True


def _sect_gain(ctx, st, key, n):
    """发师门属性/建材，返回新余额。"""
    key = _s(key)
    n = _num(n)
    if key in SECT_CURRENCIES:
        _ic().add_currency(ctx, key, n)
        return _ic().get_currency(ctx, key)
    have = _sect_have(ctx, st, key)
    if key.startswith('bmaterials') and _sect_bmaterials_set(key, have + n):
        return have + n
    st['sect'].setdefault('materials', {})
    st['sect']['materials'][key] = _num(st['sect']['materials'].get(key)) + n
    return st['sect']['materials'][key]



def _ep_get_sect_support_shop(ctx, st):
    """`get_sect_supportShop`：`TeacherBuildResExchangeStore:init`（:28）读
    `exchangeLimit`(数) / `exchangeTimes`(数) —— 她做 `data.exchangeLimit - data.exchangeTimes`
    当"本日剩余交易次数"（:30 + Presenter:75）—— 以及 `list`(**数组**)。

    `list` 元素（`__dealWithInfo`（:120-137）+ `Presenter:84-98` 逐行读出来的）：
        `id`(数，兑换时原样回给 `buy_sect_supportGoods`) / `state`(数 0=未解锁 1=可缴纳)
        `titleText` / `contentText` / `unlockText`（都按 `setString` 给**字符串**，空串安全）
    她 `state==1` 才显示「缴纳」按钮，`state==0` 才显示 `unlockText`（`:89-91`）。

    内容 = `family/sectBuildDonate.lua`（68 条，商品/建材全取她表里的真键）；
    门槛读 `family/sectBuildDonate.lua.unlockcondition` + `work/teacherbuild_state.json` 的真建筑等级。
    """
    family_id = _s(ctx.param('familyId') or ctx.param('family_id'))
    fams = _families()
    if not family_id or family_id not in fams:
        return ctx.fail('需要加入门派才能进入', '★ 易物堂列表·familyId=%r 不是 family.lua 里的门派' % family_id,
                        errcode=1)
    items = []
    ready = 0
    for e in _sect_shop_entries(st):
        ok = _sect_unlocked(ctx, e)
        if ok:
            ready += 1
        items.append({
            'id': _num(e.get('id')),
            'state': 1 if ok else 0,
            'titleText': _s(e.get('titleText')),
            'contentText': _s(e.get('contentText')),
            'unlockText': '' if ok else _s(e.get('unlockText')),
        })
    limit = _num(st['sect'].get('limit'), 10)
    times = _num(st['sect'].get('exchangeTimes'), 0)
    st['sect']['familyId'] = family_id
    _save(ctx, st)
    return ctx.ok({
        'exchangeLimit': limit,
        'exchangeTimes': times,
        'list': items,
    }, '★ 师门易物堂列表（%d 条，其中 %d 条已解锁；数据取自 family/sectBuildDonate.lua；'
        '本日剩余交易 %d 次）' % (len(items), ready, max(0, limit - times)))


def _ep_buy_sect_support(ctx, st):
    """`buy_sect_supportGoods`：`TeacherBuildResExchangeStore:buyGoods`（:63）读
    `gainList`(数组 {id,number}) / `costList`(数组 {id,number}) /
    `currencies`(数组 {id,number}，id ∈ donate/renown/sgbpoint/gbpoint/reputation) / `msg`(可选)。

    ★ `id` 用她表里的**属性名**（`bmaterials1`/`amartial`/`dmartial`/…），
      因为她在回调里用 `Role:getCHAttrName(id)` 取中文名——给假 id 就是空字符串。
      扣减：货币类走 `items_currency`，建材/贡献类走本模块 state 的 `sect.materials`
      （见 `_sect_have` 的说明），**真扣、不够就整体拒绝**。
    """
    family_id = _s(ctx.param('familyId') or ctx.param('family_id'))
    reward_id = _s(ctx.param('id'))
    fams = _families()
    if not family_id or family_id not in fams:
        return ctx.fail('需要加入门派才能进入', '★ 易物堂·familyId=%r 不是 family.lua 里的门派' % family_id, errcode=1)
    entry = _find_sect_entry(st, reward_id)
    if entry is None:
        return ctx.fail('兑换项不存在', '★ 易物堂·rewardId=%r 不在 sectBuildDonate.lua 里' % reward_id, errcode=1)
    ic = _ic()
    st['sect'].setdefault('materials', {})
    for c in (entry.get('cost') or []):
        cid = _s(c.get('id'))
        need = _num(c.get('number'))
        if _sect_have(ctx, st, cid) < need:
            return ctx.fail('%s不足' % ic.currency_name(cid),
                            '★ 易物堂·%s 不足（有 %d，需 %d）'
                            % (ic.currency_name(cid), _sect_have(ctx, st, cid), need),
                            errcode=1)
    for c in (entry.get('cost') or []):
        if not _sect_spend(ctx, st, _s(c.get('id')), _num(c.get('number'))):
            return ctx.fail('%s不足' % ic.currency_name(_s(c.get('id'))),
                            '★ 易物堂·%s 扣减时才发现不足（并发），整单拒绝' % _s(c.get('id')), errcode=1)
    gain_list = []
    for g in (entry.get('gain') or []):
        gid = _s(g.get('id'))
        n = _num(g.get('number'))
        gain_list.append({'id': gid, 'number': _sect_gain(ctx, st, gid, n)})
    cost_list = [{'id': _s(c.get('id')), 'number': _num(c.get('number'))} for c in (entry.get('cost') or [])]
    cur = []
    for cid in SECT_CURRENCIES + SECT_ATTRS[:5]:
        cur.append({'id': cid, 'number': _sect_have(ctx, st, cid)})
    st['sect']['exchangeTimes'] = _num(st['sect'].get('exchangeTimes')) + 1
    st['sect']['familyId'] = family_id
    _log(ctx, st, '易物堂兑换 id=%s in %s：花 %s 得 %s' % (reward_id, family_id, cost_list, gain_list))
    _save(ctx, st)
    return ctx.ok({
        'gainList': gain_list,
        'costList': cost_list,
        'currencies': cur,
        'msg': '已兑换「%s」' % (_s(entry.get('titleText')) or reward_id),
    }, '★ 师门易物堂兑换（%s：花 %s 得 %s）'
        % (_s(entry.get('titleText')), cost_list, gain_list))


_HANDLERS = {
    'get_board': _ep_get_board,
    'canInherit': _ep_can_inherit,
    'check_email_white': _ep_check_email_white,
    'exchange_yashi_welfare_reward': _ep_exchange_yashi,
    'join_family': _ep_join_family,
    'get_sect_supportShop': _ep_get_sect_support_shop,
    'buy_sect_supportGoods': _ep_buy_sect_support,
    'pvp_roleData_verify': _ep_pvp_verify,
    'report_gain_log': _ep_report_gain_log,
    'check_user_gain_log': _ep_check_user_gain_log,
    'count_single_record': _ep_count_single_record,
    'get_recharge_benefits_info': _ep_recharge_info,
    'get_recharge_benefits_reward': _ep_recharge_reward,
    'get_challengemap_task_info': _ep_cm_task_info,
    'get_challengemap_task_reward': _ep_cm_task_reward,
    'get_merchant_event_info': _ep_merchant_event_info,
    'get_merchant_store_list': _ep_merchant_store_list,
    'buy_merchant_goods': _ep_buy_merchant_goods,
}


def handle(ctx):
    fn = _HANDLERS.get(ctx.endpoint)
    if fn is None:
        return None
    st = _st(ctx)
    return fn(ctx, st)
