# -*- coding: utf-8 -*-
# ================= 离线包路径根（fz_make_offline_bundle.py 自动注入） =================
# 手机上整个服务端就是一个目录，表在哪、状态写哪，全部相对包根算。
# （有的模块原来把绝对路径写死，本身没 import os —— 这里一并补上）
import os
import os as _osp


def _off_find_bundle(_f):
    """从模块所在目录往上找包根（认 fz_boot_server.py）。
    ★ fz_api/*.py 的 __file__ 在 <根>/fz_api/ 下，直接 dirname 会算错一层。"""
    _d = _osp.path.dirname(_osp.path.abspath(_f))
    for _ in range(6):
        if _osp.path.exists(_osp.path.join(_d, 'fz_boot_server.py')):
            return _d
        _u = _osp.path.dirname(_d)
        if _u == _d:
            break
        _d = _u
    return _osp.path.dirname(_osp.path.abspath(_f))


_OFF_BUNDLE = _off_find_bundle(__file__)
_OFF_FZ_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_fz')
_OFF_INK_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_ink')
_OFF_WORK_ROOT = _OFF_BUNDLE
# =====================================================================================
# ★ 2026-10-04 商城空货架修复：客户端资源表解析——PC 开发树优先，设备上自动回退
#   到包内 client_fz 副本（jhserver/client_fz = fangzhi_lua_dec 的同步拷贝）。
def _fz_res(*parts):
    base = os.path.join(_OFF_FZ_ROOT, 'res', 'script')
    if not os.path.isdir(base):
        base = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            '..', 'client_fz', 'res', 'script')
    return os.path.join(base, *parts)

# -*- coding: utf-8 -*-
"""师门建设 / 师门任务（TeacherBuildSystem）—— 师门建设面板的 **7 个按钮动作**。

契约来源（都在她 `assets/src` 里逐个读过，`data.<字段>` 是应答回调里真正读的）：

  * 接口 URL / 上行参数：`app/extends/HttpManager.lua`（另一份 `app/extends/Http/HttpManager.lua` 同名同参）
      start_teacherBuild_task   {taskId, familyId}            → 回调只读 data.startTime（数字）
      stop_teacherBuild_task    {taskId, familyId}            → 回调不读 data
      finish_teacherBuild_task  {taskId, familyId}            → data.reward(表，元素 [id,num]) /
                                                                 data.taskNumDay / reputation /
                                                                 sgbpoint / renown（全是数字）/ data.msg(字符串，可选)
      speedUp_teacherBuild_task {taskId, cost, familyId}      → data.cost / data.speedUpTime（数字）
      build_teacherBuild        {buildTypeId, familyId}       → 回调不读 data
      donate_teacherBuild       {buildTypeId, familyId, donateId, donateState, currencyVersion}
                                                              → data.renown / data.donate / data.buildTeacherExp
                                                                （数字）/ data.currencyVersion（数字，可省）/
                                                                data.reward.upresources / .addRenown / .addDonate
                                                                （数字，必须都给）/ data.msg(字符串，可选)
                                                                errcode==4 时还要 data.buildTeacherExp
      upgrade_teacherBuild      {buildTypeId, familyId}       → data.buildLv / data.renown（数字）

  * 模型：`app/models/TeacherBuildSystem/TeacherBuildSystem.lua`（上行参数怎么拼、回调怎么读）
  * 面板：`app/presenters/TeacherBuild/*.lua`
      TeacherBuildInfoPresenter（兴建按钮 :204-231）
      TeacherBuildDonatePresenter（捐献按钮 :101-149，读 reward 三个字段）
      TeacherBuildUpgradePresenter（名位升级按钮 :91-110）
      TeacherBuildGuaJiPresenter（完成日常 :142-180 / 终止日常 :182-232）
      TeacherBuildSpeedUpPresenter（加速 :249-259）
      TeacherBuildTaskPresenter（开始日常 :86-117）
  * 状态常量：`app/models/TeacherBuildSystem/TeacherBuildConst.lua`
      BuildStateType={None=0,BuildIng=1}；TaskStateType/TaskCdType/TaskType 见该文件

内容**全部取自她自己的资源表**（`C:\\apkwork\\fangzhi_lua_dec\\assets\\res\\script\\family\\`，
经 `work/fz_luatable.py` 的 `load_lua_table` 解析，取 `["1"]` 那一层，familyId 不同就退回第一层）：

  * `sectLevel.lua`        师门等级门槛 prosperity 0/1540/3180/5790/10110/16230/22750/37150/52450/71950
  * `sectBuildInfo.lua`    17 种建筑（buildingid 100 勤务阁 … 116 易物堂）× 各等级
                           字段：buildid/buildingid/buildname/buildlv/maxupresources(升级所需修筑度)/
                           cescalation(升名位消耗的资历)/condition([[“sgbpoint”,N]] 名位门槛)/
                           conditiontext/donateid/effectid/builddescribe/effecttext
                           —— 建筑等级由 `buildTeacherExp` 落在哪个 maxupresources 区间决定（她 :845 getBuildByExp）
  * `sectBuildDonate.lua`  捐献档位：donateid → donatecondition([[“bmaterialsN”,个数]]) / upresources(修筑度) /
                           renown / donate / titletext / donatetext
  * `sectBuildEffect.lua`  建筑效果（taskul=日常次数上限、materialsul=建材上限…）
  * `tasks.lua`            师门日常 233 条：taskid/type/name/camp/time(小时)/awards([[属性id,数量]])/
                           awardtext/cd/unlockcondition

真实状态推进：`work/teacherbuild_state.json`（`ctx.load_json/save_json`），按 familyId 分档：
  gbpoint/sgbpoint/reputation/renown/donate/diligent/taskNumDay/bmaterials1..6
  + builds{buildingid:{buildTeacherExp,buildLv,state,buildStartTime,targetLv,needExp}}
  + task{taskId,startTime,speedUpTime,endTime,name,type}
  `build_*` 记兴建、`donate_*` 加修筑度/资历/佳绩并消耗建材、`upgrade_*` 消耗资历升名位、
  `start_*` 记开始时间、`finish_*` 结算她的 `awards`、`speedUp_*` 按 5 分钟/点提前完成时间。

★ 本模块还导出 `snapshot(ctx)`：给 `fz_boot_server.py` 的 `get_teacherBuild_info` / `get_teacherBuild_list`
  用同一份存档作答（否则面板显示的数值永远是那几个写死的常量，和这里的推进对不上）。
  —— 本文件不改别人的文件，接线由 fz_boot_server 的所有者做。

已知的**刻意偏差 / 还没做**（都写在注释里）：
  1. 首次建档给一笔启动资源（见下面 START_* 常量），因为本服没有账号存档；
  2. 建材不足时回 errcode=1（她原版是 2/3，客户端收到 2/3 会回查 `get_teacherBuild_donateInfo`，
     而那个接口目前是 fz_boot_server 的空壳：只给 buildTeacherExp/list，缺 donateNum/donateMax/donateList
     ⇒ 会在 `TeacherBuildDonatePresenter:setTextDonateNum` 拼接 nil 时崩、被 xpcall 吞掉 ⇒ 面板冻住）；
  3. `get_teacherBuild_tasks` / `get_teacherBuild_items` / `get_teacherBuild_donateInfo` 三个**列表**接口
     不在本模块的 7 个里，且 fz_boot_server 里已先行 return（路由顺序在 fz_api dispatch 之前），
     现在回的都是空表 ⇒ 日常任务列表是空的、捐献列表是空的。要真能点，得让那三个接口改成读本模块的
     `snapshot(ctx)` / `donate_list(ctx)`。
"""
import os
import time

NAME = 'teacher_build'
TITLE = '师门建设/师门任务'
ENDPOINTS = [
    'build_teacherBuild',
    'donate_teacherBuild',
    'start_teacherBuild_task',
    'finish_teacherBuild_task',
    'stop_teacherBuild_task',
    'speedUp_teacherBuild_task',
    'upgrade_teacherBuild',
    # ★ 读数接口也归本模块：**面板数值和按钮必须同源**，否则面板显示 0 修筑度/0 名位、
    #   按钮却按存档算，对不上。（路由已经放在 fz_boot_server 最前面 ⇒ 模块优先于旧的写死常量。）
    'get_teacherBuild_info',
    'get_teacherBuild_list',
    'get_teacherBuild_tasks',
    'get_teacherBuild_donateInfo',
]

STATE = 'teacherbuild_state.json'

_RES_FAMILY = _fz_res('family')
_HERE_WORK = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# ---------------------------------------------------------------- 启动资源
# 本服没有账号存档，第一次碰到某个 familyId 时给一笔启动值。
# 出处（不是凭空造）：gbpoint 5790 / diligent 10 与 fz_boot_server 里 `get_teacherBuild_info`
# 现在回给她的常量一致（对应 sectLevel 的 sectlevel=4）；建材 360/种 = 她
# `sectBuildInfo` 1 级储宝库说明里那句"提升建筑材料储存上限到360个"（6 种 × `materialsul` 60）；
# sgbpoint 60 是为了让她表里门槛最低的几个名位（恩义祠 12 / 叙功堂 15 / 撷英阁 18 …）现在就能升。
START_GBPOINT = 5790
START_SGBPOINT = 60
START_RENOWN_LIMIT = 100
START_DILIGENT = 10
START_DILIGENT_LIMIT = 100
START_BMATERIAL = 360

# 她的 TeacherBuildSpeedUpPresenter:84-87 写死了"1 点 = 5 分钟"（可加速时间 cost*5 分钟）
SPEEDUP_SECONDS_PER_COST = 300


# ---------------------------------------------------------------- 她的资源表


def _tables():
    """解析她 `res/script/family/*.lua`（只读一次，缓存在函数属性上）。"""
    cache = getattr(_tables, '_cache', None)
    if cache is not None:
        return cache
    want = {
        'level': 'sectLevel.lua',
        'build': 'sectBuildInfo.lua',
        'donate': 'sectBuildDonate.lua',
        'effect': 'sectBuildEffect.lua',
        'task': 'tasks.lua',
    }
    out = {}
    try:
        import sys
        if _HERE_WORK not in sys.path:
            sys.path.insert(0, _HERE_WORK)
        import fz_luatable
        for key, fn in want.items():
            try:
                out[key] = fz_luatable.load_lua_table(os.path.join(_RES_FAMILY, fn))
            except Exception:                 # noqa: BLE001
                out[key] = {}
    except Exception:                         # noqa: BLE001
        out = dict((k, {}) for k in want)
    _tables._cache = out
    return out


def _sub(tbl, family_id):
    """她这些表都长 `{["1"]={...}}`（按师门分档）；取不到就退回第一档。"""
    if not isinstance(tbl, dict):
        return {}
    v = tbl.get(str(family_id))
    if isinstance(v, dict):
        return v
    for k in tbl:
        if isinstance(tbl[k], dict):
            return tbl[k]
    return {}


def _build_index(family_id):
    """{buildingid: [该建筑的各等级条目, 按 buildlv 升序]}（17 种，100…116）。"""
    idx = {}
    for v in _sub(_tables()['build'], family_id).values():
        if not isinstance(v, dict):
            continue
        idx.setdefault(str(v.get('buildingid')), []).append(v)
    for k in idx:
        idx[k].sort(key=lambda e: int(e.get('buildlv') or 0))
    return idx


def _level_by_exp(entries, exp):
    """照抄她 `TeacherBuildSystem:getBuildByExp`(:845)：exp >= maxupresources 的最高等级。"""
    lv = 0
    for e in entries:
        if exp >= int(e.get('maxupresources') or 0):
            lv = int(e.get('buildlv') or 0)
    return lv


def _entry_by_lv(entries, lv):
    for e in entries:
        if int(e.get('buildlv') or 0) == int(lv):
            return e
    return None


def _next_need_exp(entries, exp):
    """照抄她 `getBuildUpgradeNeedExp`(:909)：下一级的 maxupresources；满级返回 None。"""
    cur = _level_by_exp(entries, exp)
    for e in entries:
        if int(e.get('buildlv') or 0) == cur + 1:
            return int(e.get('maxupresources') or 0)
    return None


def _today():
    return time.strftime('%Y-%m-%d')


# ---------------------------------------------------------------- 存档
def _new_build(bid):
    return {'buildTypeId': bid, 'buildTeacherExp': 0, 'buildLv': 0, 'state': 0,
            'buildStartTime': 0, 'targetLv': 0, 'needExp': 0}


def _new_family(build_ids):
    f = {
        'gbpoint': START_GBPOINT,
        'sgbpoint': START_SGBPOINT,
        'reputation': 0,
        'renown': 0,
        'renownLimit': START_RENOWN_LIMIT,
        'donate': 0,
        'diligent': START_DILIGENT,
        'diligentLimit': START_DILIGENT_LIMIT,
        'featscount': 0,
        'taskNumDay': 0,
        'day': _today(),
        'builds': dict((b, _new_build(b)) for b in build_ids),
        'task': {},
    }
    for i in range(1, 7):
        f['bmaterials%d' % i] = START_BMATERIAL
    return f


def _fam(ctx, st):
    """取出（必要时建档）本次请求对应的师门存档。返回 (family_id, 档, 建筑索引)。"""
    family_id = str(ctx.param('familyId') or ctx.headers.get('familyId') or '1')
    idx = _build_index(family_id)
    if not isinstance(st.get(family_id), dict):
        st[family_id] = _new_family(sorted(idx))
    f = st[family_id]
    f.setdefault('builds', {})
    for bid in idx:
        b = f['builds'].get(bid)
        if not isinstance(b, dict):
            f['builds'][bid] = _new_build(bid)
        else:
            for k, v in _new_build(bid).items():
                b.setdefault(k, v)
    f.setdefault('task', {})
    for i in range(1, 7):
        f.setdefault('bmaterials%d' % i, START_BMATERIAL)
    f.setdefault('taskNumDay', 0)
    if f.get('day') != _today():              # 跨天重置"本日已完成日常"
        f['day'] = _today()
        f['taskNumDay'] = 0
    return family_id, f, idx


def _task_limit(f, idx):
    """日常次数上限：勤务阁 名位 1 级 → 4（她表里 effectid 1000 `{"taskul",1}`，文案"上限到4"）。"""
    effects = _sub(_tables()['effect'], '1')
    taskul = 0
    for bid, b in f['builds'].items():
        lv = int(b.get('buildLv') or 0)
        for e in idx.get(bid, []):
            if int(e.get('buildlv') or 0) > lv:
                break
            for eid in (e.get('effectid') or []):
                eff = (effects.get(str(eid)) or {}).get('effect') or []
                if len(eff) >= 2 and eff[0] == 'taskul':
                    taskul = max(taskul, int(eff[1]))
    return 4 + max(0, taskul - 1)


def _task_of(family_id, task_id):
    return _sub(_tables()['task'], family_id).get(str(task_id))


def _apply_reward(f, aid, num):
    """结算 `tasks.lua` 的 `awards`（[[属性id,数量]]）—— 属性 id 即 Role:getCHAttrName 的键。"""
    aid = str(aid)
    try:
        num = int(float(num))
    except (TypeError, ValueError):
        return None
    if aid.startswith('bmaterials') or aid in ('reputation', 'sgbpoint', 'gbpoint',
                                               'renown', 'donate', 'diligent', 'featscount'):
        f[aid] = int(f.get(aid) or 0) + num
        return f[aid]
    return None


def _build_view(f, idx, bid):
    """列表项结构 —— 她 `TeacherBuildSystem.lua:25-32` 的注释就是权威。"""
    b = f['builds'].get(bid) or _new_build(bid)
    return {'buildTypeId': str(bid),
            'buildTeacherExp': int(b.get('buildTeacherExp') or 0),
            'buildLv': int(b.get('buildLv') or 0),
            'state': int(b.get('state') or 0)}


def snapshot(ctx):
    """★ 给 `fz_boot_server.py` 的 `get_teacherBuild_info` / `get_teacherBuild_list` 用。

    返回 (info, build_list)：字段与 `TeacherBuildSystem:__initData`(:96-122) 一一对应，
    guajiInfo 非空时客户端会认为"日常进行中"。

        import fz_api.teacher_build as TB
        info, lst = TB.snapshot(ctx)
    """
    st = ctx.load_json(STATE, {})
    family_id, f, idx = _fam(ctx, st)
    ctx.save_json(STATE, st)
    task = f.get('task') or {}
    guaji = {}
    if task.get('taskId'):
        guaji = {'taskId': str(task['taskId']),
                 'startTime': int(task.get('startTime') or 0),
                 'speedUpTime': int(task.get('speedUpTime') or 0)}
    info = {
        'gbpoint': int(f.get('gbpoint') or 0),
        'sgbpoint': int(f.get('sgbpoint') or 0),
        'reputation': int(f.get('reputation') or 0),
        'renown': int(f.get('renown') or 0),
        'renownLimit': int(f.get('renownLimit') or 0),
        'diligent': int(f.get('diligent') or 0),
        'diligentLimit': int(f.get('diligentLimit') or 0),
        'donate': int(f.get('donate') or 0),
        'featscount': int(f.get('featscount') or 0),
        'taskNumDay': int(f.get('taskNumDay') or 0),
        'taskNumLimit': _task_limit(f, idx),
        'guajiInfo': guaji,
        'familyStates': [],
    }
    for i in range(1, 7):
        info['bmaterials%d' % i] = int(f.get('bmaterials%d' % i) or 0)
    return info, [_build_view(f, idx, b) for b in sorted(idx)]


def donate_list(ctx, build_type_id=None):
    """★ 给 `get_teacherBuild_donateInfo` 用的捐献档位（取自 `sectBuildDonate.lua`）。

    返回 (buildTeacherExp, [{donateId, state}, ...])；她 `TeacherBuildDonatePresenter:47-57`
    读 donateNum / donateMax / donateList。
    """
    st = ctx.load_json(STATE, {})
    family_id, f, idx = _fam(ctx, st)
    dids = set()
    entries = idx.get(str(build_type_id), [])
    exp = 0
    if entries:
        b = f['builds'].get(str(build_type_id)) or _new_build(str(build_type_id))
        exp = int(b.get('buildTeacherExp') or 0)
        for e in entries:
            if int(e.get('buildlv') or 0) == _level_by_exp(entries, exp):
                dids = set(str(x) for x in (e.get('donateid') or []))
                break
    donate = _sub(_tables()['donate'], family_id)
    out = []
    for did in sorted(donate):
        if dids and did not in dids:
            continue
        out.append({'donateId': str(did), 'state': 0})
    return exp, out


# ---------------------------------------------------------------- 应答小工具
def _fail_data(ctx, errcode, errmsg, data, note=''):
    """带 data 的错误应答（她 `donate_teacherBuild` 的 errcode==4 分支要读 data.buildTeacherExp）。"""
    payload = dict(data or {})
    payload['dataVer'] = ctx.deps['next_dataver']()
    return ctx.enc({'errcode': errcode, 'errmsg': errmsg, 'data': payload,
                    'rand_t': time.time()}), note


# ---------------------------------------------------------------- 接口
def handle(ctx):
    ep = ctx.endpoint
    if ep not in ENDPOINTS:
        return None

    now = int(time.time())
    st = ctx.load_json(STATE, {})
    family_id, f, idx = _fam(ctx, st)
    # ★★ 2026-10-01 老板："论武堂只能提高到 2 级"。
    #   名位升级有**两道门槛**（`upgrade_teacherBuild` 里的 `cur+1 > exp_lv`）：
    #     ① 建筑等级 `exp_lv` 由**修筑度** `buildTeacherExp` 决定（只有捐献才涨）；
    #     ② 个人名位 `buildLv` 只能一级一级往上。
    #   而「捐献」要求**建筑材料**（`sectBuildDonate.donatecondition`，如 bmaterials1×5），
    #   建材是日常任务一点点攒的 ⇒ 卡在 2 级就是这个原因。
    #   私服里把六种建材**补满**（和"1 银两、不限购的测试礼包"一个思路），捐献就能一直点。
    if int(START_BMATERIAL) <= 999:
        for _i in range(1, 7):
            _k = 'bmaterials%d' % _i
            if int(f.get(_k) or 0) < 99999:
                f[_k] = 99999
        ctx.save_json(STATE, st)

    def save(note):
        ctx.save_json(STATE, st)
        return note

    # ---------------------------------------------------- 读数（面板与按钮同源）
    if ep == 'get_teacherBuild_info':
        # `TeacherBuildSystem:__initData`(:96-122) 逐个读；`getSectLevelData`(:512)
        # 用 `gbpoint >= v.prosperity` 比大小 ⇒ 必须是数字。
        info, _lst = snapshot(ctx)
        return ctx.ok(info, '★ 师门建设信息（来自存档，非写死）')

    if ep == 'get_teacherBuild_list':
        # ★★ 2026-10-01 关键修复（老板截图：师门建筑面板只有「建筑列表」标题、下面全空）：
        #   `TeacherBuildSystem:getTeacherBuildData`（`TeacherBuildSystem.lua:684-700`）
        #   把**整个应答 `data`** 直接塞给 `setBuildList(data)`，而
        #   `TeacherBuildListPresenter:setListViewBuildList`（presenter:52）是
        #       `local buildList = self.__buildList` … `for i,v in ipairs(buildList)`
        #   ⇒ 回 `{'list': [...], 'gbpoint': …, 'dataVer': …}` 时，`data` 是一个
        #     **没有数组部分**的表 ⇒ `ipairs` 遍历 **0 次** ⇒ 列表永远空白
        #     （服务端日志却写着"17 种"，所以这个 bug 一直看不出来）。
        #   **必须回裸数组**。`dataVer` 不是这里要的（`getTeacherBuildData` 不读它；
        #   要 `dataVer` 的是走 `__saveAction` 的那批接口）。
        _info, lst = snapshot(ctx)
        return ctx.ok(lst, '★ 师门建筑列表（%d 种，裸数组）' % len(lst))

    if ep == 'get_teacherBuild_donateInfo':
        # `TeacherBuildDonatePresenter:47-57` 读 donateNum / donateMax / donateList
        bid = str(ctx.param('buildTypeId') or (ctx.args[0] if ctx.args else '') or '')
        exp, dl = donate_list(ctx, bid)
        return ctx.ok({'buildTeacherExp': exp, 'donateNum': len(dl), 'donateMax': len(dl),
                       'donateList': dl}, '★ 捐献信息（%d 档）' % len(dl))

    if ep == 'get_teacherBuild_tasks':
        # `setTaskNumDay(data.taskNumDay)` / `setTaskNumLimit(data.taskNumLimit)`，
        # 列表给 `TeacherBuildTaskPresenter:__taskList`：条目 {taskId,state,cdTime}，
        #   state 取 TeacherBuildConst.TaskStateType(0未解锁/1解锁/2冷却)，taskId 必须是
        #   `tasks.lua` 里真有的键（否则她 `getTask()` 里 assert 崩）。
        info, _lst = snapshot(ctx)
        tasks_tbl = _sub(_tables()['task'], family_id)
        cur = (f.get('task') or {}).get('taskId')
        out = []
        for i, key in enumerate(list(tasks_tbl.keys())[:40]):
            out.append({'taskId': str(key),
                        'state': 2 if str(key) == str(cur) else (1 if i < 8 else 0),
                        'cdTime': 0})
        return ctx.ok({'taskNumDay': info.get('taskNumDay'), 'taskNumLimit': info.get('taskNumLimit'),
                       'list': out}, '★ 师门日常任务（%d 条）' % len(out))

    # ---------------------------------------------------------- 兴建师门建筑
    if ep == 'build_teacherBuild':
        # 契约：回调只判 isOk（`TeacherBuildInfoPresenter:217-228`），data 不读；
        #       她把该建筑 state 改成 BuildIng(1)、其它建筑的 state 清回 None(0)（:639-647）。
        bid = str(ctx.param('buildTypeId') or '')
        entries = idx.get(bid)
        if not entries:
            return ctx.fail('建筑不存在（buildTypeId=%s）' % bid, '★ 师门兴建：未知建筑')
        b = f['builds'].setdefault(bid, _new_build(bid))
        exp = int(b.get('buildTeacherExp') or 0)
        if _next_need_exp(entries, exp) is None:      # 已顶到最高等级，没什么可兴建的了
            return ctx.fail('该建筑已达到最高等级', '★ 师门兴建：已满级')
        for other, ob in f['builds'].items():
            ob['state'] = 0
        b['state'] = 1                      # TeacherBuildConst.BuildStateType.BuildIng
        b['buildStartTime'] = now
        b['targetLv'] = _level_by_exp(entries, exp) + 1
        b['needExp'] = _next_need_exp(entries, exp) or 0
        ctx.log('[师门建设] 兴建 %s（%s）目标名位/建筑等级 %s，需修筑度 %s'
                % (bid, entries[0].get('buildname'), b['targetLv'], b['needExp']))
        return ctx.ok({'buildTypeId': bid, 'state': 1,
                       'buildTeacherExp': exp, 'buildLv': int(b.get('buildLv') or 0),
                       'buildStartTime': now, 'needExp': b['needExp'],
                       'msg': '开始兴建%s' % entries[0].get('buildname', '')},
                      save('★ 师门兴建（%s %s）' % (bid, entries[0].get('buildname'))))

    # ---------------------------------------------------------- 捐献建筑材料
    if ep == 'donate_teacherBuild':
        bid = str(ctx.param('buildTypeId') or '')
        did = str(ctx.param('donateId') or '')
        entries = idx.get(bid)
        if not entries:
            return ctx.fail('建筑不存在（buildTypeId=%s）' % bid, '★ 师门捐献：未知建筑')
        donate = _sub(_tables()['donate'], family_id).get(did)
        if not isinstance(donate, dict):
            return ctx.fail('捐献档位不存在（donateId=%s）' % did, '★ 师门捐献：未知档位')
        # 注：不按当前建筑等级条目里的 `donateid` 白名单卡（她那个名单是给"面板上显示哪几档"用的，
        #     真正的门槛是 `donatecondition` 的建材 + `unlockcondition`；见本文件 donate_list()）
        b = f['builds'].setdefault(bid, _new_build(bid))
        exp = int(b.get('buildTeacherExp') or 0)

        # 她 `isMaxBuildLevel`(:889)：经验已顶到最高等级 ⇒ errcode=4（客户端 PopText 后关面板）
        if _next_need_exp(entries, exp) is None:
            return _fail_data(ctx, 4, '该建筑已达到最高等级',
                              {'buildTeacherExp': exp, 'buildLv': int(b.get('buildLv') or 0),
                               'state': int(b.get('state') or 0)},
                              save('★ 师门捐献：建筑已满级'))

        # 建材门槛取自 `sectBuildDonate.donatecondition`，例 [["bmaterials1", 5]]
        need = []
        for cond in (donate.get('donatecondition') or []):
            if isinstance(cond, list) and len(cond) >= 2:
                need.append((str(cond[0]), int(cond[1])))
        lack = [(k, n) for k, n in need if int(f.get(k) or 0) < n]
        # ★ 建材不足回 errcode=1（她原版 2/3 会让客户端去查 donateInfo，
        #   那个接口目前是空壳、缺 donateNum/donateMax/donateList ⇒ 会拼 nil 崩、UI 冻住）
        if lack:
            return ctx.fail('建筑材料不足：%s' % '、'.join('%s 需%d' % (k, n) for k, n in lack),
                            '★ 师门捐献：建材不足')
        for k, n in need:
            f[k] = int(f.get(k) or 0) - n

        up = int(donate.get('upresources') or 0)
        add_renown = int(donate.get('renown') or 0)
        add_donate = int(donate.get('donate') or 0)
        b['buildTeacherExp'] = exp + up
        f['renown'] = int(f.get('renown') or 0) + add_renown
        f['donate'] = int(f.get('donate') or 0) + add_donate
        # 修筑度顶到目标等级 ⇒ 兴建完成，state 回 None(0)
        if int(b.get('state') or 0) == 1 and b.get('needExp') and b['buildTeacherExp'] >= int(b['needExp']):
            b['state'] = 0
            b['targetLv'] = 0
            b['needExp'] = 0

        cv = ctx.int_param('currencyVersion', 0)
        data = {
            'renown': int(f['renown']),
            'donate': int(f['donate']),
            'buildTeacherExp': int(b['buildTeacherExp']),
            'buildLv': int(b.get('buildLv') or 0),
            'state': int(b.get('state') or 0),
            'sgbpoint': int(f.get('sgbpoint') or 0),
            'currencyVersion': cv,
            'reward': {'upresources': up, 'addRenown': add_renown, 'addDonate': add_donate},
            'msg': '%s：修筑度+%d' % (donate.get('titletext') or '捐献', up),
        }
        ctx.log('[师门建设] 捐献 %s → 建筑 %s：修筑度+%d 资历+%d 佳绩+%d（现 %d）'
                % (did, bid, up, add_renown, add_donate, b['buildTeacherExp']))
        return ctx.ok(data, save('★ 师门捐献（%s：修筑度+%d）' % (bid, up)))

    # ---------------------------------------------------------- 升级建筑名位
    if ep == 'upgrade_teacherBuild':
        bid = str(ctx.param('buildTypeId') or '')
        entries = idx.get(bid)
        if not entries:
            return ctx.fail('建筑不存在（buildTypeId=%s）' % bid, '★ 师门名位升级：未知建筑')
        b = f['builds'].setdefault(bid, _new_build(bid))
        cur = int(b.get('buildLv') or 0)
        exp = int(b.get('buildTeacherExp') or 0)
        exp_lv = _level_by_exp(entries, exp)          # 建筑等级（由修筑度决定）
        nxt = _entry_by_lv(entries, cur + 1)
        if nxt is None:
            return ctx.fail('当前名位等级已是最高级', '★ 师门名位升级：满级')
        if cur + 1 > exp_lv:
            return ctx.fail('建筑等级不足（建筑%d级，需%d级才能开放该名位）' % (exp_lv, cur + 1),
                            '★ 师门名位升级：建筑等级不足')
        cost = int(nxt.get('cescalation') or 0)       # 消耗资历（她 `getCescalation`）
        need_sgb = 0
        for cond in (nxt.get('condition') or []):
            if isinstance(cond, list) and len(cond) >= 2 and str(cond[0]) == 'sgbpoint':
                need_sgb = int(cond[1])
        if int(f.get('sgbpoint') or 0) < need_sgb:
            return ctx.fail('贡献昌盛度不足（需%d，现有%d）' % (need_sgb, int(f.get('sgbpoint') or 0)),
                            '★ 师门名位升级：昌盛度不足')
        if int(f.get('renown') or 0) < cost:
            return ctx.fail('资历不足（需%d，现有%d）' % (cost, int(f.get('renown') or 0)),
                            '★ 师门名位升级：资历不足')
        f['renown'] = int(f['renown']) - cost
        b['buildLv'] = cur + 1
        ctx.log('[师门建设] 名位升级 %s：%d → %d，消耗资历 %d' % (bid, cur, cur + 1, cost))
        return ctx.ok({'buildLv': cur + 1, 'renown': int(f['renown']), 'cost': cost,
                       'buildTypeId': bid, 'buildTeacherExp': exp,
                       'sgbpoint': int(f.get('sgbpoint') or 0),
                       'msg': '名位升级成功'},
                      save('★ 师门名位升级（%s → %d 级）' % (bid, cur + 1)))

    # ---------------------------------------------------------- 开始师门日常
    if ep == 'start_teacherBuild_task':
        # 契约：`TeacherBuildSystem:329-349` 只读 data.startTime，然后自己算
        #       endTime = startTime + task.time*3600 - speedUpTime
        tid = str(ctx.param('taskId') or '')
        task = _task_of(family_id, tid)
        if not isinstance(task, dict):
            # 给错 taskId 她 `getTask()` 里是 assert ⇒ 会崩，必须在这里挡住
            return ctx.fail('任务不存在（taskId=%s）' % tid, '★ 师门日常：未知任务')
        if (f.get('task') or {}).get('taskId'):
            return ctx.fail('已有进行中的师门日常', '★ 师门日常：已有进行中')
        limit = _task_limit(f, idx)
        if int(f.get('taskNumDay') or 0) >= limit:
            return ctx.fail('本日师门日常已完成上限（%d/%d）' % (int(f.get('taskNumDay') or 0), limit),
                            '★ 师门日常：已达上限')
        hours = float(task.get('time') or 0)
        end = now + int(hours * 3600)
        f['task'] = {'taskId': tid, 'startTime': now, 'speedUpTime': 0, 'endTime': end,
                     'name': task.get('name') or '', 'type': int(task.get('type') or 1)}
        ctx.log('[师门建设] 开始日常 %s（%s）%s 小时，%d → %d'
                % (tid, task.get('name'), task.get('time'), now, end))
        return ctx.ok({'startTime': now, 'endTime': end, 'taskId': tid, 'speedUpTime': 0,
                       'taskNumDay': int(f.get('taskNumDay') or 0), 'taskNumLimit': limit},
                      save('★ 师门日常开始（%s %s）' % (tid, task.get('name'))))

    # ---------------------------------------------------------- 完成师门日常
    if ep == 'finish_teacherBuild_task':
        # 契约：`TeacherBuildSystem:381-408` 读 data.reward / taskNumDay / reputation / sgbpoint / renown；
        #       `TeacherBuildGuaJiPresenter:157-170` 按 ipairs 遍历 data.reward 里每条 [id, num]
        task = f.get('task') or {}
        tid = str(task.get('taskId') or '')
        if not tid:
            return ctx.fail('没有进行中的师门日常', '★ 师门日常：没有进行中')
        if now + 5 < int(task.get('endTime') or 0):
            left = int(task['endTime']) - now
            return ctx.fail('师门日常尚未完成（还剩%d分%d秒）' % (left // 60, left % 60),
                            '★ 师门日常：还没到时间')
        cfg = _task_of(family_id, tid) or {}
        awards = cfg.get('awards') or []
        reward = []
        for a in awards:
            if isinstance(a, list) and len(a) >= 2:
                reward.append([str(a[0]), str(a[1])])
                _apply_reward(f, a[0], a[1])
        limit = _task_limit(f, idx)
        f['taskNumDay'] = min(int(f.get('taskNumDay') or 0) + 1, limit)
        f['task'] = {}
        ctx.log('[师门建设] 完成日常 %s（%s）：%s' % (tid, cfg.get('name'), reward))
        return ctx.ok({'reward': reward, 'taskNumDay': int(f['taskNumDay']), 'taskNumLimit': limit,
                       'reputation': int(f.get('reputation') or 0),
                       'sgbpoint': int(f.get('sgbpoint') or 0),
                       'renown': int(f.get('renown') or 0),
                       'gbpoint': int(f.get('gbpoint') or 0),
                       'msg': '完成师门日常：%s' % (cfg.get('name') or '')},
                      save('★ 师门日常完成（%s）' % tid))

    # ---------------------------------------------------------- 终止师门日常
    if ep == 'stop_teacherBuild_task':
        # 契约：回调不读 data（`TeacherBuildSystem:356-373`），清掉挂机信息就行
        old = (f.get('task') or {}).get('taskId')
        f['task'] = {}
        ctx.log('[师门建设] 终止日常 %s' % old)
        return ctx.ok({'taskNumDay': int(f.get('taskNumDay') or 0),
                       'taskNumLimit': _task_limit(f, idx),
                       'msg': '已终止师门日常'},
                      save('★ 师门日常终止（%s）' % old))

    # ---------------------------------------------------------- 加速师门日常
    if ep == 'speedUp_teacherBuild_task':
        # 契约：`TeacherBuildSystem:416-436` 读 data.cost / data.speedUpTime（都是数字），
        #       然后 diligent -= cost、speedUpTime += data.speedUpTime
        task = f.get('task') or {}
        if not task.get('taskId'):
            return ctx.fail('没有进行中的师门日常', '★ 师门日常加速：没有进行中')
        cost = ctx.int_param('cost', 1)
        if cost <= 0:
            cost = 1
        have = int(f.get('diligent') or 0)
        if have < cost:
            return ctx.fail('勤建之志不足（需%d，现有%d）' % (cost, have), '★ 师门日常加速：资源不足')
        secs = cost * SPEEDUP_SECONDS_PER_COST
        f['diligent'] = have - cost
        task['speedUpTime'] = int(task.get('speedUpTime') or 0) + secs
        task['endTime'] = int(task.get('endTime') or 0) - secs
        f['task'] = task
        ctx.log('[师门建设] 加速日常 %s：消耗 %d，提前 %d 秒（剩余到 %d）'
                % (task.get('taskId'), cost, secs, task['endTime']))
        return ctx.ok({'cost': cost, 'speedUpTime': secs, 'diligent': int(f['diligent']),
                       'endTime': int(task['endTime']),
                       'msg': '加速成功'},
                      save('★ 师门日常加速（%d 点 → %d 秒）' % (cost, secs)))

    return None
