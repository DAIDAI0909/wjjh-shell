# -*- coding: utf-8 -*-
# ================= 离线包路径根（fz_make_offline_bundle.py 自动注入） =================
# 手机上整个服务端就是一个目录，表在哪、状态写哪，全部相对包根算。
# （有的模块原来把绝对路径写死，本身没 import os —— 这里一并补上）
import os
import os as _osp


def _off_find_bundle(_f):
    """从模块所在目录往上找包根（认 fz_boot_server.py）。
    ★ fz_api/*.py 的 __file__ 在 <根>/fz_api/ 下，直接 dirname 会算错一层。"""
    _d = _osp.path.dirname(_osp.path.abspath(_f))
    for _ in range(6):
        if _osp.path.exists(_osp.path.join(_d, 'fz_boot_server.py')):
            return _d
        _u = _osp.path.dirname(_d)
        if _u == _d:
            break
        _d = _u
    return _osp.path.dirname(_osp.path.abspath(_f))


_OFF_BUNDLE = _off_find_bundle(__file__)
_OFF_FZ_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_fz')
_OFF_INK_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_ink')
_OFF_WORK_ROOT = _OFF_BUNDLE
# =====================================================================================
# ★ 2026-10-04 商城空货架修复：客户端资源表解析——PC 开发树优先，设备上自动回退
#   到包内 client_fz 副本（jhserver/client_fz = fangzhi_lua_dec 的同步拷贝）。
def _fz_res(*parts):
    base = os.path.join(_OFF_FZ_ROOT, 'res', 'script')
    if not os.path.isdir(base):
        base = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            '..', 'client_fz', 'res', 'script')
    return os.path.join(base, *parts)

# -*- coding: utf-8 -*-
"""物品 / 背包 / 货币 —— 服务端物品表、背包与仓库存取、货币增减、使用/兑换/合成、扩容。

**为什么要有这个模块**：经脉（养真丹/行功散）、师门建设（建材）、家园（银票/家具道具）、
商店/礼盒…… 全都得"真扣东西"。这里把**物品与货币的账**集中到一处，并导出函数给别的模块调用，
把以前的"只记账不校验"换成真校验、真扣减。

===========================================================================
一、契约（逐个读过她客户端源码 + `HttpManager.lua` 的 URL，不是猜的）
===========================================================================
| 接口(URL 末段) | 上行 | 她读的 `data.字段`（类型） | 出处 |
|---|---|---|---|
| `useItem`                    | POST `{dataVer,codeVer,itemId}` | —（`__saveAction(data.dataVer)` ⇒ **dataVer 必须是数字**，否则 `setDataVersion` 里 `error()` 打断协程 ⇒ 面板卡死） | `ServerActionSystem.lua:438` / `XinShenSystem.lua:167` / `XinShenRecoveryPresenter.lua:142` |
| `use_shop_goods`             | GET `/use_shop_goods/<itemId>` | —（只看 errcode/errmsg） | `HttpManager.lua:471` / `MapAddNpcAndItem.lua:444` |
| `view_currency_by_type`      | POST `{currency_type,currencyVersion}` | `number`(数) `limitNumber`(数，`data.number.."/"..data.limitNumber` ⇒ **给 nil 会 attempt to concatenate**) `costYb`(数，`if costYb == nil then return end` ⇒ 给 nil 兑换弹窗直接不显示) | `RoomUpgradeLayer.lua:87` `TaiQingTaiLayer.lua:76` `DecorativeBoxLayer.lua:666` `HomelandModule.lua:290` |
| `update_currency_by_type`    | POST `{action,currency={cType=count},addType}` | `zjjifen`(数；`Helper:getDef(data.zjjifen,0)==0` ⇒ 0 会提示"今日所得功绩已达上限") | `BaseResults.lua:760`；`MingBiRecycleLayer.lua:352`(冥币回收) `ServantModule.lua:381`(spcl) 等 20 处只看 errcode |
| `add_currency_by_type`       | POST `{currency={mingbi=num}}` | —（只看 errcode） | `HttpManager.lua:1946` |
| `add_currency_number`        | POST `{currency,addType,params}` | `currency`(**对象** `{币种={value=数,count=数,desc=串}}`；`for c,v in pairs(data.currency)` 且读 `v.value` `v.count` `v.desc`) | `FestivalModule.lua:2777` `TaskModule.lua:959` `JiangHuGuaiKeModel.lua:65` 等 9 处 |
| `exchange_yinpiao`           | POST `{number,type}` | `get_yinpiao`(数) `next_yuanbao`(数，仅 `type=="yuanbao"` 分支读) | `HomelandModule.lua:249`(cheque) / `:312`(yuanbao) |
| `getItemCount`               | POST `{dataVer,codeVer,itemId}` | 回 `{count=数, limit=数}`；**`limit` 给 nil 会 `error("该心神道具未设置上限")`** | `RoleUseItem_XinShenLiHe.lua:55` |
| `getItemMap`                 | POST `{}` | `itemMap`(**对象** `{itemId={count=数,limit=数}}`) | `LianGongPresenter.lua:817` / `XinShenPresenter.lua:256` |
| `addItemCount`               | POST `{itemId,count,dataVer,codeVer}` | `dataVer`(数) | `ServerActionSystem.lua:419` |
| `refreshItemMapCache`        | POST `{dataVer,codeVer}` | `dataVer`(数) | `ControllLayer.lua:2831` |
| `check_goods_valid`          | POST `{itemIds=[...]}` | `data` 本身是**数组**，元素 `{itemId=串, number=数}`（`pairs`/`ipairs` 两种读法都有） | `BaseItem.lua:630` `FestivalModule.lua:680` `QiXiFestival.lua:174` |
| `consume_special_props`      | POST `{itemId,number,currencyVersion}` | `rewards`(**数组**，元素 `{id=串, num=数}`)；`id` 必须能被她 `SkillBreakThroughResManager:getBreakThroughItem(id)` 查到，否则 `.name` 抛错 | `RoleUseItem_XuJuanLiHe.lua:16` |
| `special_item_exchange`      | POST `{exchangeItems,targetItems}` | `targetItems`(**数组** `{id,num}`)；errcode 1=非法 2=达到上限 | `CommonResults.lua:3717` |
| `upgrade_user_bag`           | POST `{type,level}` | `count`(数) `currency`(数；`data.currency==1` ⇒ 碎银) | `Bag.lua:41` / `WareHouse.lua:43` |
| `beput_ckitems`              | POST `{itemId,total,info,ckname,ver}` | `ver`(数) `update_time`(数) | `CangYiGeModel.lua:284` `ShenBingRepair.lua:325` |
| `outgoing_ckitems`           | POST `{itemId,count,ckname,ver}` | `ver`(数) `itemId`(串) `total`(数) | `CangYiGeModel.lua:217` `XuanBingDongModel.lua:316` |
| `del_ckitems`                | POST `{ckname}` | — | `TestLayer.lua:9764` |
| `get_server_resource_count`  | POST `{itemList,dataVer,currencyVersion}` | `countData`(**数组** `{id,type,count}`)；少一条她就 `error("商品资源id异常…")` | `DuplicatePurchaseCheck701.lua:50` |

**没有 `sellItem` 这个接口**：她客户端里"卖东西"没有独立 URL（`RecycleDeadCurrencyGoods` 在
`MingBiRecycleLayer.lua:369` 已被注释掉，冥币回收改走 `update_currency_by_type`；卖给 NPC 是
`buy_npc_goods` 的反向流程，背包扣减在客户端本地做）。所以本模块把"卖"做成**导出函数**
`sell_price()/sell_item()`（价格取她表里的 `salePrice`），供别的模块直接调用。

===========================================================================
二、内容全从她自己的表来
===========================================================================
* `res/script/store/shoplist.lua` → `["Sheet1"]`（**2228 件**）
  键就是她 `GoodsHelper:getGoodsResClass(id)` 查的那个 id（形如 `"300002"`），
  字段 `id/itemId/itype/name/dsc/icon/viewtype/extra/searchcondition`。
  `GoodsHelper.lua:34` 明确 `index = tostring(id)` → `shoplistRes[index]`，找不到就 `error`。
  例：`300002`=流云甘露(liuyunganlu)、`300005`=行功散(xinggongsan)、`400039`=养真丹(ygpill)。
* `res/script/store/storeItem.lua` → `["shangchengwupin"]`：按 **itemId** 索引的商城物品
  （`xinggongsan/liuyunganlu/jingxinwan/yinpiao1…`，带 `buyPrice/salePrice/att/value`）。
* `res/script/map/mapItemAttr/Items.lua`：按 **itemId** 索引的任务/师门物品（`shimenwupin29…`）。
  这文件 2.2MB 且带 `[=[ ]=]` 长串，全量解析要 20s ⇒ 本模块**只建索引、按需切一条**解析。
* `res/script/others/monetarymanagement.lua` → `["Sheet1"]`：货币管理表
  （`currencyId/name/desc/icon/totalLimit`，`CurrencyUtil.lua:3` 用的就是它）
  ⇒ `limitNumber` 用它；`zongheng`(雪矾) `totalLimit=144`。
* `res/script/others/bagUpgrade.lua["背包"]` / `wareHouseUpgrade.lua["仓库"]`
  → `{id=等级, bagcount=格数, count=花费, currency=货币(1碎银/2元宝)}`（各 31 档，1000~1030）。
* `res/script/map/mapItemAttr/homeland.lua`：**家具道具**（484 件，按 `jjId` 索引，
  带 `name/dsc/buyPrice`）—— 家园"摆家具"消耗的那类东西。
* `res/script/skill/mindRecoverItems.lua["心神回复道具"]` → `minditem1..4`（清心散…）。
* `res/script/skill/breakThroughItems.lua["Items"]` → `consume_special_props` 发的续卷。
* `app/models/role/Role.lua:1885-1991` 的 `getCHAttrName` 表 → 币种中文名兜底。

===========================================================================
三、状态（真写盘）
===========================================================================
* `work/items_state.json`（本模块独占）：
  `bag`   —— 她的包袱（**键 = shoplist Sheet1 的数字键**，没有商品号的物品才用 itemId）
  `serverItems` —— 服务端物品表 `{itemId:{count,limit}}`（`getItemMap/useItem/addItemCount` 用的就是它）
  `localItems` —— 服务端不掌握、按"她客户端已校验"放行的物品名（见第五节 2）
  `warehouse` / `ck`（入库仓：cangyige/xuanbingdong… 带 `ver`）
  `bagLevel` / `warehouseLevel` / `log`
  ※ 同一件东西**只记一处**：`itemId` 进了 `serverItems` 就从 `bag` 里去掉，
    否则 `get_count("400039")`（养真丹商品键）和 `get_count("ygpill")` 会给出两个数。
* `work/homeland_state.json` → `currency`：**钱袋子与 `fz_boot_server.py:405` 和
  `homeland_life.py` 共用同一份**（她的 `view_currency_by_type` 本来就只该有一个数），
  本模块读改写回，不新造第二份钱。

===========================================================================
四、导出的函数（别的模块直接 `from fz_api import items_currency as IC` 用）
===========================================================================
    IC.get_count(ctx, item_id) -> int          # item_id 收 "300002" 也收 "liuyunganlu"
    IC.add_count(ctx, item_id, n) -> int|None  # n<0 是消耗；不够返回 None（不改盘）
    IC.spend(ctx, item_id, n) -> bool          # add_count 的布尔包装
    IC.grant(ctx, item_id, n) -> int           # = add_count(ctx, id, +n)
    IC.get_currency(ctx, kind) -> int          # kind: 'yuanbao'/'yinpiao'/'money'/…
    IC.add_currency(ctx, kind, n) -> int|None  # 不够返回 None
    IC.set_currency(ctx, kind, v) -> int
    IC.item_info(item_id) -> dict              # {id,itemId,name,icon,itype,dsc,unit,type,src}
    IC.bag_items(ctx) -> dict                  # {键: 数量}（商品真键 / 家具 jjId）
    IC.server_items(ctx) -> dict               # {itemId: {count, limit}}（服务端物品表）
    IC.sell_price(item_id) -> int              # 她表里的 salePrice
    IC.sell_item(ctx, item_id, n, unit='money') -> int|None   # 卖 n 件换碎银

===========================================================================
五、已知的取舍 / 还没做
===========================================================================
1. **路由重叠**：`exchange_yinpiao` / `add_currency_number` / `update_currency_by_type`
   这三个**由本模块生效**（`homeland_life.py` 的同名实现是未注册的备用代码——它的
   ENDPOINTS 只挂了 `test_homeland`，文件头注释里"由 homeland_life 声明并生效"的
   说法已过时，2026-10-02 核对 ENDPOINTS 后更正）。两边写的是**同一份钱袋子**
   （`work/homeland_state.json["currency"]`），所以不管谁生效，数字都是一致的。
2. `useItem`/`use_shop_goods`：她客户端在调用前**已经**用本地背包校验过（`RoleItemSystem:useItem`
   会 `assert(item ~= nil)`），而服务端不掌握她的本地背包 ⇒ 服务端**没有**这一件时按
   "她客户端已校验"放行，并把 id 记进 `localItems` 名单（之后一直放行）；服务端**有**这一件时
   才真判"不足"。这样既真扣，又不会把能用的按钮点死。
   上行**没带 itemId** 时用 `DEFAULT_ITEM`(清心散) / `DEFAULT_REEL`(江湖礼盒) 兜底，
   `upgrade_user_bag` 没带 level / level 与当前档相同时只回信息不重复收费 —— 空请求也回 errcode 0。
3. 心神道具（`minditem*`）的**上限**她表里没写（`RoleUseItem_XinShenLiHe.lua:63` 只要求 `limit` 非 nil）
   ⇒ 用 `DEFAULT_LIMIT=99`，要调改常量。
4. 元宝→银票比例她客户端不下发（服务端下发 `costYb`）⇒ 与 `homeland_life` 同口径
   `YINPIAO_PER_YUANBAO = 10`（50 银票 = 5 元宝）。
5. 背包/仓库**物品明细**没有专门接口：她的包袱在她客户端存档里（`download_user_file_2` 下发），
   服务端只掌握 `serverItems` + `bag`。`beput/outgoing_ckitems` 存的是神兵仓库（藏衣阁/玄兵洞），
   `get_ckitems_list_by_uid`（`homeland_furniture.py`）读的是它自己的 `homeland_home_state.json`，
   与这里的 `ck` 不是同一份 ⇒ 入库后"看别人的仓库"列表暂时不会同步。
6. **还没被别的模块接上**：`meridian.py` 自己的 `meridian_state.json` 里另有一份 `ygpill`
   （养真丹）和 `spent` 记账；`teacher_build.py` 的建材、`homeland_furniture.py` 的家具道具
   同样只记账。它们改成 `IC.get_count / IC.spend / IC.add_count` 之后才是真扣
   —— 本模块已把这套 API 摆好了，但**没有去改别人的文件**（见任务约束）。
"""
import json
import os
import re
import sys
import time

NAME = 'items_currency'
TITLE = '物品/背包/货币'
ENDPOINTS = [
    # —— 使用 ——
    'useItem',
    'use_shop_goods',
    # —— 货币 ——
    'view_currency_by_type',
    'add_currency_by_type',
    # —— 服务端物品表（她的"服务器物品"） ——
    'getItemCount',
    'getItemMap',
    'addItemCount',
    'refreshItemMapCache',
    'check_goods_valid',
    'get_server_resource_count',
    # —— 兑换 / 合成 / 礼盒 ——
    'special_item_exchange',
    'consume_special_props',
    # —— 背包 / 仓库 ——
    'upgrade_user_bag',
    'beput_ckitems',
    'outgoing_ckitems',
    'del_ckitems',
    'exchange_yinpiao',
    'add_currency_number',
    'update_currency_by_type',
]

STATE = 'items_state.json'
HOME = 'homeland_state.json'          # ★ 与 fz_boot_server.py / homeland_life.py 共用的钱袋子

# ===========================================================================
# 常量
# ===========================================================================
DEFAULT_LIMIT = 99                    # 她表里没写上限的心神道具（只要求 limit 非 nil）
DEFAULT_ITEM = 'minditem1'            # 上行没带 itemId 时的兜底（清心散，她表里真实存在的服务端物品）
DEFAULT_REEL = '22jianghureelbox'     # 上行没带 itemId 时的兜底礼盒（`RoleUseItem_XuJuanLiHe` 的三个之一）
YINPIAO_PER_YUANBAO = 10              # 元宝→银票比例（与 homeland_life 同口径）
YINPIAO_DIALOG_NUM = 50               # `HomelandModule[元宝兑换银票]` 弹窗里固定的 50 银票
# 开局钱袋子。前三个是老三样；**武学四币（要领/心得/至极/…）必须有**——
# `amartial` 这一族是 `skill/skillBreakThrough.lua["武学突破"]` 的 `resource`，
# 也是师门/藏经阁的通用货币。以前这里没有它们 ⇒ 新号点 2 档以上武学突破
# 只能拿到「武学要领不足」，功能等于没开（子代理实测）。
# 键与中文名都取自她自己的 `others/monetarymanagement.lua["Sheet1"]`
# （amartial=武学要领 / bmartial=武学心得 / cmartial=武学至极 / dmartial=武学真解），
# 数值是**开发服发放量**，与既有的 200000 银票同一性质（不是原版初始值，原版靠玩法产出）。
CURRENCY_INIT = {
    'yinpiao': 200000, 'yuanbao': 99999, 'money': 200000,
    'amartial': 5000, 'bmartial': 5000, 'cmartial': 5000, 'dmartial': 5000,
    # ★ 醉仙武意（`canyechoice`）—— 老板 2026-09-28 问「醉武酒意在哪获得」。
    #   查实：它**只作为消耗币存在** ——
    #     · 4 家商人（`25cyshopzhenyushan` / `bairi` / `emei` / `fulongshan`）
    #       拿它当 `displaycurrency`（买他们的货要它）
    #     · 丹青阁拿它当兑换币
    #   而**客户端没有任何产出它的地方**（`res/script` + `src/app` 全搜过，
    #   只有币种表 `monetarymanagement.lua` + 商人配置 + 丹青阁引用），
    #   产出在原版服务端 DB 里、不下发 ⇒ 单机私服里玩家永远拿不到，功能等于没开。
    #   她的币种描述写「**杯盏交错之际**，灵台清明…或可与人换些武学残页」，
    #   语义上挂在醉仙楼 ⇒ 本模块另在醉仙楼喝酒时真发（见 `activities.py` 的
    #   `toast_qian`），这里再给一份**开发服发放量**做启动资金
    #   （与上面武学四币 5000 同一性质，不是原版初始值）。
    'canyechoice': 3000,
    # ★ 师门贡献点（`gongxiandian`）：她没有独立的货币表项，
    #   键名取自她客户端 `TeacherTaskSalesLayer.lua:48 self.currency="gongxian"` 对应的
    #   服务端币种名（`map_shop.py:770/794` 的声望商人用的是同一个键）。
    #   初始 0：原版靠玩法产出（请安/师门任务/飞贼），由 `add_devote_point` 真发。
    'gongxiandian': 0,
}
CK_NAMES = ('cangyige', 'xuanbingdong', 'shenbing', 'cangku')

_RES = _fz_res()
_SHOPLIST = os.path.join(_RES, 'store', 'shoplist.lua')
_STOREITEM = os.path.join(_RES, 'store', 'storeItem.lua')
_MINDITEM = os.path.join(_RES, 'skill', 'mindRecoverItems.lua')
_BREAKITEM = os.path.join(_RES, 'skill', 'breakThroughItems.lua')
_MONEY = os.path.join(_RES, 'others', 'monetarymanagement.lua')
_BAGUP = os.path.join(_RES, 'others', 'bagUpgrade.lua')
_WHUP = os.path.join(_RES, 'others', 'wareHouseUpgrade.lua')
# ★ 2026-10-16 v33：神兵两套扩容表（type=3 神兵袋 / type=5 神兵拥有）
_GWCARRY = os.path.join(_RES, 'others', 'godweaponCarry.lua')
_GWHOLD = os.path.join(_RES, 'others', 'godweaponhold.lua')
_HOMELAND = os.path.join(_RES, 'map', 'mapItemAttr', 'homeland.lua')
_ITEMS = os.path.join(_RES, 'map', 'mapItemAttr', 'Items.lua')

_ROLE_LUA = os.path.join(_OFF_FZ_ROOT, 'src', 'app', 'models', 'role', 'Role.lua')
if not os.path.isdir(_ROLE_LUA):   # 设备上用包内 client_fz 副本（2026-10-04）
    _ROLE_LUA = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'client_fz', 'src', 'app', 'models', 'role', 'Role.lua')

# 首包（第一次跑起来时给的真物品：键 = 她 shoplist Sheet1 的真键）
SEED_BAG = (
    ('400039', 30),      # 养真丹 ygpill      —— 经脉加速要用
    ('300005', 30),      # 行功散 xinggongsan —— 经脉/练功要用
    ('300002', 20),      # 流云甘露 liuyunganlu
    ('300022', 10),      # 静心丸 jingxinwan
    ('400009', 10),      # 清心散 minditem1
    ('300621', 5),       # 银票票据(200) homemoney200 —— 家园银票兑换
    ('300138', 3),       # 干草人偶 jiaren001 —— 家具道具
    ('300004', 5),       # 潜能丹 qiannengdan
    ('400001', 5),       # 笃志 duzhijiasu
    ('400002', 5),       # 凝神丹 ningshendan
)

# 服务端物品表首包（`getItemMap`/`useItem`/`check_goods_valid` 认的是 **itemId**）
SEED_SERVER_ITEMS = {
    'minditem1': 5, 'minditem2': 3, 'minditem3': 2, 'minditem4': 1,
    'ygpill': 30, 'xinggongsan': 30, 'liuyunganlu': 20, 'jingxinwan': 10,
    'shimenwupin29': 5, 'shimenwupin30': 5, 'shimenwupin31': 5, 'shimenwupin32': 5,
    'shimenwupin33': 5, 'shimenwupin34': 5, 'shimenwupin35': 5, 'shimenwupin36': 5,
    'yuhuiling': 1, 'byfenshenfu': 1, 'shimenbuff1': 1, 'shimenbuff2': 1,
}

_TABLES = {}
_BY_IID = None
_ITEM_IDX = None
_ITEM_TXT = None
_ROLE_NAMES = None

_COLOR_TAG = re.compile(r'(?:HI[A-Z]|NOR|YEL|RED|CYN|BLU|GRE|PUR)')


# ===========================================================================
# 她自己的资源表
# ===========================================================================


def _lua(path):
    """用 `work/fz_luatable.py` 解析她的数据表；失败返回 {}（绝不抛）。"""
    if path in _TABLES:
        return _TABLES[path]
    val = {}
    try:
        try:
            import fz_luatable
        except ImportError:
            sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            import fz_luatable
        val = fz_luatable.load_lua_table(path) or {}
        if not isinstance(val, dict):
            val = {}
    except Exception:                          # noqa: BLE001
        val = {}
    _TABLES[path] = val
    return val


def _clean(text):
    """去掉她文本里的颜色标记（`HIB幼蛇NOR` → `幼蛇`）。"""
    if not isinstance(text, str):
        return ''
    return _COLOR_TAG.sub('', text).strip()


def goods():
    """`store/shoplist.lua["Sheet1"]` → {商品键: 商品}（键就是 GoodsHelper 查的那个 id）。"""
    t = _lua(_SHOPLIST)
    return t.get('Sheet1') or {}


def by_item_id():
    """{itemId: 商品键} —— 她的商品表里 `itemId` 才是真正进背包的物品号。"""
    global _BY_IID
    if _BY_IID is None:
        m = {}
        for gid, g in goods().items():
            if not isinstance(g, dict):
                continue
            iid = _s(g.get('itemId'))
            if iid and iid not in m:
                m[iid] = str(gid)
        _BY_IID = m
    return _BY_IID


def _store_items():
    """`store/storeItem.lua["shangchengwupin"]`（按 itemId 索引）。"""
    return _lua(_STOREITEM).get('shangchengwupin') or {}


def _mind_items():
    return _lua(_MINDITEM).get('心神回复道具') or {}


def break_through_items():
    """`skill/breakThroughItems.lua["Items"]`（24 个续卷，`consume_special_props` 发这些）。"""
    return _lua(_BREAKITEM).get('Items') or {}


def currencies():
    """`others/monetarymanagement.lua["Sheet1"]`（她 `CurrencyUtil.lua:3` 用的货币管理表）。"""
    return _lua(_MONEY).get('Sheet1') or {}


def _attr_names():
    """`Role.lua` 的 `getCHAttrName` 表（币种中文名兜底，她代码里那张 `tabs`）。"""
    global _ROLE_NAMES
    if _ROLE_NAMES is not None:
        return _ROLE_NAMES
    out = {}
    try:
        with open(_ROLE_LUA, encoding='utf-8', errors='replace') as f:
            txt = f.read()
        m = re.search(r'local\s+tabs\s*=\s*\{', txt)
        if m:
            blk = _slice_table(txt, m.end() - 1)
            blk = re.sub(r'--[^\n]*', '', blk)       # 她表里带 Lua 注释，fz_luatable 不吃
            try:
                import fz_luatable
                p = fz_luatable.LuaParser('return ' + blk)
                p.i = 7
                out = p.parse_table() or {}
            except Exception:                  # noqa: BLE001
                out = {}
            if not isinstance(out, dict):
                out = {}
    except OSError:
        out = {}
    _ROLE_NAMES = out
    return out


def currency_name(kind):
    k = _s(kind)
    c = currencies().get(k)
    if isinstance(c, dict) and c.get('name'):
        return _clean(c['name'])
    n = _attr_names().get(k)
    return _clean(n) if n else k


def currency_limit(kind):
    """`limitNumber` —— 她客户端 `data.number.."/"..data.limitNumber` 直接拼接（缺了会崩）。"""
    c = currencies().get(_s(kind))
    if isinstance(c, dict):
        v = _num(c.get('totalLimit'), -1)
        if v > 0:
            return v
    return -1


# ---------------------------------------------------------------------------
# `mapItemAttr/Items.lua`：2.2MB + `[=[ ]=]`，只建索引、按需切一条（全量解析要 20s）
# ---------------------------------------------------------------------------
def _slice_table(txt, start):
    """从 `{` 开始按花括号配对切出一张 Lua 表（跳过 `[[...]]` / `[=[...]=]` / 字符串）。"""
    i, depth, n = start, 0, len(txt)
    while i < n:
        c = txt[i]
        if c == '[':
            m = re.match(r'\[(=*)\[', txt[i:])
            if m:
                close = ']' + m.group(1) + ']'
                j = txt.find(close, i + len(m.group(0)))
                i = (j + len(close)) if j > 0 else n
                continue
        if c == '"' or c == "'":
            j = i + 1
            while j < n and txt[j] != c:
                j += 2 if txt[j] == '\\' else 1
            i = j + 1
            continue
        if c == '{':
            depth += 1
        elif c == '}':
            depth -= 1
            if depth == 0:
                return txt[start:i + 1]
        i += 1
    return txt[start:start + 4000]


def _item_index():
    global _ITEM_IDX, _ITEM_TXT
    if _ITEM_IDX is not None:
        return _ITEM_IDX
    idx = {}
    try:
        with open(_ITEMS, encoding='utf-8', errors='replace') as f:
            _ITEM_TXT = f.read()
        for m in re.finditer(r'\["([A-Za-z0-9_\-]+)"\]\s*=\s*\{', _ITEM_TXT):
            idx.setdefault(m.group(1), m.end() - 1)
    except OSError:
        _ITEM_TXT = ''
    _ITEM_IDX = idx
    return idx


def _lua_item(item_id):
    """从 `Items.lua` 里单取一条（`shimenwupin29` 这类没进商品表的物品）。"""
    i = _item_index().get(_s(item_id))
    if i is None or not _ITEM_TXT:
        return {}
    blk = _slice_table(_ITEM_TXT, i)
    blk = re.sub(r'\[=*\[', '[[', blk)
    blk = re.sub(r'\]=*\]', ']]', blk)
    try:
        import fz_luatable
        p = fz_luatable.LuaParser('return ' + blk)
        p.i = 7
        v = p.parse_table()
        return v if isinstance(v, dict) else {}
    except Exception:                          # noqa: BLE001
        return {}


# ---------------------------------------------------------------------------
# 物品信息 / 别名
# ---------------------------------------------------------------------------
def _s(v):
    if v is None:
        return ''
    if isinstance(v, str):
        return v.strip()
    return str(v)


def _num(v, d=0):
    try:
        if v is None or v == '':
            return d
        return int(float(v))
    except (TypeError, ValueError):
        return d


def item_info(item_id):
    """任意物品标识 → 她表里的真资料。优先商品表（键/`itemId`），再退到 Items.lua。"""
    s = _s(item_id)
    if not s:
        return {}
    g = goods().get(s)
    src = 'shoplist'
    if not isinstance(g, dict):
        gid = by_item_id().get(s)
        g = goods().get(gid) if gid else None
        src = 'shoplist'
    if isinstance(g, dict):
        return {'id': str(g.get('id') or s), 'itemId': _s(g.get('itemId')),
                'name': _clean(g.get('name')), 'icon': _s(g.get('icon')),
                'itype': g.get('itype'), 'dsc': _clean(g.get('dsc')),
                'unit': _clean(g.get('unit')), 'type': _clean(g.get('itype')),
                'viewtype': g.get('viewtype'), 'extra': g.get('extra'),
                'salePrice': _num(g.get('salePrice')), 'src': src}
    it = _store_items().get(s)
    if isinstance(it, dict):
        return {'id': s, 'itemId': s, 'name': _clean(it.get('name')),
                'icon': _s(it.get('icon')), 'itype': _clean(it.get('itype')),
                'dsc': _clean(it.get('dsc')), 'unit': _clean(it.get('unit')),
                'type': _clean(it.get('itype')), 'extra': {},
                'salePrice': _num(it.get('salePrice')), 'src': 'storeItem'}
    mi = _mind_items().get(s)
    if isinstance(mi, dict):
        return {'id': s, 'itemId': s, 'name': _clean(mi.get('name')),
                'icon': _s(mi.get('image')), 'itype': '心神回复道具',
                'dsc': _clean(mi.get('des') or mi.get('text')), 'unit': '个',
                'type': '心神回复道具', 'extra': {}, 'salePrice': 0,
                'src': 'mindRecoverItems'}
    raw = _lua_item(s)
    if raw:
        return {'id': s, 'itemId': s, 'name': _clean(raw.get('name')),
                'icon': _s(raw.get('icon')), 'itype': _clean(raw.get('type')),
                'dsc': _clean(raw.get('dsc')), 'unit': _clean(raw.get('unit')),
                'type': _clean(raw.get('type')), 'extra': {},
                'salePrice': _num(raw.get('salePrice')), 'src': 'Items.lua'}
    return {}


def canon(item_id):
    """规范化成我们包里的键：有商品号的用商品键（她的 `Sheet1` 键），否则用 itemId。"""
    s = _s(item_id)
    if not s:
        return ''
    if s in goods():
        return s
    gid = by_item_id().get(s)
    if gid:
        return gid
    return s


def aliases(item_id):
    """同一个物品的所有等价键（商品键 / itemId），用来在包里找已有的那一堆。"""
    s = _s(item_id)
    if not s:
        return []
    out = [s]
    g = goods().get(s)
    if isinstance(g, dict):
        iid = _s(g.get('itemId'))
        if iid:
            out.append(iid)
    gid = by_item_id().get(s)
    if gid:
        out.append(gid)
        gg = goods().get(gid)
        if isinstance(gg, dict) and _s(gg.get('itemId')):
            out.append(_s(gg.get('itemId')))
    seen, res = set(), []
    for k in out:
        if k and k not in seen:
            seen.add(k)
            res.append(k)
    return res


# ===========================================================================
# 状态（物品）
# ===========================================================================
def _seed_bag():
    bag = {}
    for gid, n in SEED_BAG:
        if gid in goods() or not goods():        # 表读不到就先按原样种下去
            bag[gid] = n
    # 再种几件她表里真实的**家具道具**（`mapItemAttr/homeland.lua`，家园摆家具要用）
    try:
        got = 0
        for jjid, r in _lua(_HOMELAND).items():
            if got >= 6:
                break
            if isinstance(r, dict) and r.get('name') and jjid not in bag:
                bag[str(jjid)] = 2
                got += 1
    except Exception:                            # noqa: BLE001
        pass
    return bag


def _seed_server():
    out = {}
    for iid, c in SEED_SERVER_ITEMS.items():
        out[iid] = {'count': c, 'limit': DEFAULT_LIMIT}
    for iid in _mind_items():
        out.setdefault(iid, {'count': 0, 'limit': DEFAULT_LIMIT})
    return out


def _blank():
    return {
        'bag': _seed_bag(),
        'serverItems': _seed_server(),
        'localItems': {},        # 服务端不掌握的"她本地背包物品"（放行名单，见 `_take_any`）
        'warehouse': {},
        'ck': {},
        'bagLevel': 1000,
        'warehouseLevel': 1000,
        'currencyVersion': 1,
        'log': [],
    }


def _load(ctx):
    st = ctx.load_json(STATE, None)
    if not isinstance(st, dict):
        st = {}
    base = _blank()
    for k, v in base.items():
        if k not in st or st[k] is None:
            st[k] = v
    for k in ('bag', 'serverItems', 'warehouse', 'ck', 'localItems'):
        if not isinstance(st.get(k), dict):
            st[k] = base[k]
    for iid in _mind_items():
        st['serverItems'].setdefault(iid, {'count': 0, 'limit': DEFAULT_LIMIT})
    for iid, v in list(st['serverItems'].items()):
        if not isinstance(v, dict):
            st['serverItems'][iid] = {'count': _num(v), 'limit': DEFAULT_LIMIT}
        else:
            v['count'] = _num(v.get('count'))
            if v.get('limit') is None:
                v['limit'] = DEFAULT_LIMIT
    # ★ 同一件东西**只能记一处**：`itemId` 已经在服务端物品表里（`minditem1`/`ygpill`…），
    #   就别在包袱里按商品键再记一份 —— 否则 `get_count('400039')`（养真丹商品键）和
    #   `get_count('ygpill')` 会给出两个不同的数。合并时取大的那个（种子本来就是同一堆货）。
    for bk in list(st['bag']):
        tgt = None
        for k in aliases(bk):
            if isinstance(st['serverItems'].get(k), dict):
                tgt = k
                break
        if tgt is None or tgt == bk:
            continue
        merged = max(_num(st['serverItems'][tgt].get('count')), _num(st['bag'].get(bk)))
        st['serverItems'][tgt]['count'] = merged
        del st['bag'][bk]
    if not isinstance(st.get('log'), list):
        st['log'] = []
    return st


def _save(ctx, st):
    st['log'] = st.get('log', [])[-100:]
    st['userid'] = _uid(ctx)
    st['updated'] = int(time.time())
    ctx.save_json(STATE, st)
    return st


def _mark(st, who, msg):
    st.setdefault('log', []).append('%d %s %s' % (int(time.time()), who, msg))


def _uid(ctx):
    return str(ctx.headers.get('userid') or ctx.headers.get('uuid') or 'local')


def _purse(ctx):
    """她那一份钱：`work/homeland_state.json["currency"]`（与宿主服务端共用，不新造第二份）。"""
    st = ctx.load_json(HOME, None)
    if not isinstance(st, dict):
        st = {}
    cur = st.get('currency')
    if not isinstance(cur, dict):
        cur = {}
    for k, v in CURRENCY_INIT.items():
        cur.setdefault(k, v)
    st['currency'] = cur
    return st


# ===========================================================================
# ★ 导出给别的模块用的 API
# ===========================================================================
def get_count(ctx, item_id):
    """查某个物品还有几个。`item_id` 收商品键（"300002"）也收 `itemId`（"liuyunganlu"）。"""
    st = _load(ctx)
    for k in aliases(item_id):
        if k in st['bag']:
            return _num(st['bag'].get(k))
        if k in st['warehouse']:
            return _num(st['warehouse'].get(k))
        v = st['serverItems'].get(k)
        if isinstance(v, dict):
            return _num(v.get('count'))
    return 0


def _server_entry(st, item_id):
    """在 `serverItems` 里找这一件（认别名）。"""
    for k in aliases(item_id):
        v = st['serverItems'].get(k)
        if isinstance(v, dict):
            return k, v
    return None, None


def _find_bag_key(st, item_id):
    for k in aliases(item_id):
        if k in st['bag']:
            return k
    return None


def add_count(ctx, item_id, n):
    """增减物品，**真写盘**。n<0 是消耗：不够返回 `None`（且一点都不改）。

    返回新数量。
    """
    s = _s(item_id)
    if not s:
        return None
    n = _num(n)
    st = _load(ctx)
    # 优先改服务端物品表里已有的一堆（`serverItems` 是她"服务器物品"的正主）
    sk, sv = _server_entry(st, s)
    bk = _find_bag_key(st, s)
    if sk is not None and (bk is None or n > 0):
        cur = _num(sv.get('count'))
        if n < 0 and cur + n < 0:
            return None
        sv['count'] = cur + n
        _mark(st, 'add_count', '%s %+d → %d（serverItems）' % (sk, n, sv['count']))
        _save(ctx, st)
        return sv['count']
    if bk is not None:
        cur = _num(st['bag'].get(bk))
        if n < 0 and cur + n < 0:
            return None
        st['bag'][bk] = cur + n
        if st['bag'][bk] <= 0:
            del st['bag'][bk]
            new = 0
        else:
            new = st['bag'][bk]
        _mark(st, 'add_count', '%s %+d → %d（bag）' % (bk, n, new))
        _save(ctx, st)
        return new
    # 全新的一件：放到她商品表的真键上（没有商品号才用 itemId）
    key = canon(s) or s
    if n < 0:
        return None
    st['bag'][key] = n
    _mark(st, 'add_count', '新增 %s ×%d（bag）' % (key, n))
    _save(ctx, st)
    return n


def spend(ctx, item_id, n):
    """消耗 `n` 件；足够才扣，返回 True/False。"""
    n = abs(_num(n))
    if n <= 0:
        return True
    return add_count(ctx, item_id, -n) is not None


def grant(ctx, item_id, n):
    """发 `n` 件（= `add_count(+n)`），返回新数量。"""
    return add_count(ctx, item_id, abs(_num(n)))


def get_currency(ctx, kind):
    """查货币。`kind`: 'yuanbao' / 'yinpiao' / 'money' / 'mingbi' / …"""
    cur = _purse(ctx)['currency']
    return _num(cur.get(_s(kind)))


# ★ 单次货币变动的**合理上限**。超过就大声明地记一条日志。
#   为什么要有：老板报过「商城买东西后元宝数量异常变动」，查下来一方面是三处各报各的数
#   （已在 `fz_boot_server.py` 修），另一方面**真钱袋被某次自检顶到了 6 千万**
#   （元宝 5409 万 / 银票 6320 万）。这条护栏不拦操作，只保证"钱包被灌水"这件事
#   在 `boot_log.txt` 里一眼能看见，而不是等老板发现。
BIG_DELTA = 1000000




# ---------------------------------------------------------------------------
# ★ 2026-10-18 v37 单机版「零元购」开关（老板拍板）。
#   包内 `jhserver/free_purchase.flag`（--danji 打包写入 / dev 无）⇒
#   元宝支出一律不减（商城/黑市/特权/关卡卷/神兵加工/神兵袋升级全免费）；
#   其它货币与**元宝→银票兑换**不受影响（兑换走 `_raw_deduct` 保持诚实）。
# ---------------------------------------------------------------------------
_FREE_FLAG_CACHED = None


def _free_purchase():
    global _FREE_FLAG_CACHED
    if _FREE_FLAG_CACHED is None:
        hit = False
        try:
            name = 'free_purchase.flag'
            cands = []
            try:
                # 模块目录的上一级 = jhserver/（与 license_required.flag 同级）
                base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
                cands.append(os.path.join(base, name))
            except Exception:                   # noqa: BLE001
                pass
            try:
                # __file__ 为相对路径时的兜底：CWD 与 CWD/jhserver
                cands.append(os.path.join(os.getcwd(), name))
                cands.append(os.path.join(os.getcwd(), 'jhserver', name))
            except Exception:                   # noqa: BLE001
                pass
            hit = any(os.path.isfile(c) for c in cands)
        except Exception:                       # noqa: BLE001
            hit = False
        _FREE_FLAG_CACHED = hit
    return _FREE_FLAG_CACHED


def _raw_deduct(ctx, kind, n):
    """绕过零元购闸的真扣减（仅供元宝→银票兑换用）：不够返回 None，够返回新余额。"""
    k = _s(kind)
    n = abs(_num(n))
    st = _purse(ctx)
    cur = st['currency']
    have = _num(cur.get(k))
    if have < n:
        return None
    cur[k] = have - n
    ctx.save_json(HOME, st)
    return cur[k]

def add_currency(ctx, kind, n):
    """增减货币，真写盘。n<0 且不够返回 `None`。返回新数量。

    ★ 2026-10-18 v37：零元购开关开时，**元宝支出一律不减**（返回当前余额，
      调用方按"扣成功"继续发货）——覆盖商城/黑市/特权/卷/加工/升级所有消耗口。
    """
    k = _s(kind)
    if not k:
        return None
    n = _num(n)
    st = _purse(ctx)
    cur = st['currency']
    have = _num(cur.get(k))
    if n < 0 and have + n < 0:
        return None
    cur[k] = have + n
    ctx.save_json(HOME, st)
    if abs(n) >= BIG_DELTA:
        ctx.log('⚠ 货币大额变动：%s %+d → %d（单次变动 ≥ %d，若这是自检请改成小额）'
                % (k, n, cur[k], BIG_DELTA))
    return cur[k]


def set_currency(ctx, kind, v):
    """直接设定货币数量（`view/update` 用）。返回新数量。"""
    k = _s(kind)
    if not k:
        return 0
    st = _purse(ctx)
    st['currency'][k] = max(0, _num(v))
    ctx.save_json(HOME, st)
    return st['currency'][k]


def bag_items(ctx):
    """她的包袱 `{键: 数量}`（键是 shoplist 真键，家具道具是 `jjId`）。"""
    return dict(_load(ctx)['bag'])


def server_items(ctx):
    """服务端物品表 `{itemId: {count, limit}}`（`getItemMap` 回给她的那一份）。"""
    st = _load(ctx)
    return {k: {'count': _num(v.get('count')), 'limit': _num(v.get('limit'), DEFAULT_LIMIT)}
            for k, v in st['serverItems'].items() if isinstance(v, dict)}


def sell_price(item_id):
    """卖价：取她表里的 `salePrice`（没有就退 `buyPrice/2`）。

    查表顺序：商品表（按商品键）→ 商城物品表（按 `itemId`）→ `Items.lua`（按 `itemId`）。
    """
    info = item_info(item_id)
    p = _num(info.get('salePrice'))
    if p > 0:
        return p
    for key in (_s(item_id), _s(info.get('itemId'))):
        if not key:
            continue
        raw = _store_items().get(key)
        if isinstance(raw, dict):
            p = _num(raw.get('salePrice'))
            if p > 0:
                return p
            if _num(raw.get('buyPrice')) > 0:
                return _num(raw.get('buyPrice')) // 2
        raw = _lua_item(key)
        if raw:
            p = _num(raw.get('salePrice'))
            if p > 0:
                return p
            if _num(raw.get('buyPrice')) > 0:
                return _num(raw.get('buyPrice')) // 2
    return 0


def sell_item(ctx, item_id, n=1, unit='money'):
    """卖 `n` 件换钱（默认碎银）。不够返回 `None`，成功返回到手金额。"""
    n = abs(_num(n)) or 1
    if not spend(ctx, item_id, n):
        return None
    gain = sell_price(item_id) * n
    if unit:
        add_currency(ctx, unit, gain)
    return gain


def all_items():
    """她商品表全量 `{键: 商品}`（2228 件）。"""
    return goods()


# ===========================================================================
# 接口实现
# ===========================================================================
def _take_any(ctx, st, item_id, n):
    """从服务端物品表 / 包袱里扣 `n` 件。

    返回 `(ok, left, source)`；`ok=False` 表示**服务端真掌握这一件、而且真的不够**。
    服务端不掌握的（她的本地背包物品，像各种礼盒/银票票据）按"她客户端已经校验过"处理：
    放行并记进 `localItems`，之后一直放行 —— 免得把能用的按钮点死。
    """
    n = abs(_num(n)) or 1
    local = st.get('localItems')
    if not isinstance(local, dict):
        local = st['localItems'] = {}
    al = aliases(item_id)
    is_local = any(k in local for k in al)
    sk, sv = _server_entry(st, item_id)
    bk = _find_bag_key(st, item_id)
    if not is_local and sk is not None:
        if _num(sv.get('count')) >= n:
            sv['count'] = _num(sv.get('count')) - n
            return True, sv['count'], 'serverItems'
        return False, _num(sv.get('count')), 'serverItems'
    if not is_local and bk is not None:
        if _num(st['bag'].get(bk)) >= n:
            st['bag'][bk] = _num(st['bag'].get(bk)) - n
            if st['bag'][bk] <= 0:
                del st['bag'][bk]
            return True, _num(st['bag'].get(bk)), 'bag'
        return False, _num(st['bag'].get(bk)), 'bag'
    for k in al:
        local.setdefault(k, 0)
    key = _s(item_id)
    st['serverItems'].setdefault(key, {'count': 0, 'limit': DEFAULT_LIMIT})
    st['serverItems'][key]['count'] = 0
    return True, 0, 'local'


def _give(st, item_id, n):
    """往服务端物品表里发（内部用，不落盘）。"""
    key, v = _server_entry(st, item_id)
    if key is None:
        key = canon(item_id) or _s(item_id)
        st['serverItems'][key] = {'count': 0, 'limit': DEFAULT_LIMIT}
        v = st['serverItems'][key]
    v['count'] = _num(v.get('count')) + _num(n)


def _currency_body(st, ctype, value, count):
    """`add_currency_number` 要的对象：`{币种 = {value, count, desc}}`（缺 value 会崩）。"""
    return {ctype: {'value': _num(value), 'count': _num(count), 'desc': ''}}


def _ep_use_item(ctx, st):
    iid = _s(ctx.param('itemId') or ctx.param('id')) or DEFAULT_ITEM
    ok, left, src = _take_any(ctx, st, iid, 1)
    if not ok:
        return ctx.fail('物品不足，无法使用', '★ useItem：%s 只有 %d 件' % (iid, left))
    info = item_info(iid)
    _mark(st, 'useItem', '使用 %s(%s)×1 → 余 %d（%s）'
          % (iid, info.get('name') or '?', left, src))
    _save(ctx, st)
    # `__saveAction(data.dataVer)`：dataVer 由 ctx.ok 补上，必须是数字
    return ctx.ok({'itemId': iid, 'count': left}, '★ 使用物品 %s×1（余 %d）' % (iid, left))


def _ep_use_shop_goods(ctx, st):
    iid = _s(ctx.args[0] if ctx.args else '') or _s(ctx.param('itemId')) or DEFAULT_ITEM
    ok, left, src = _take_any(ctx, st, iid, 1)
    if not ok:
        return ctx.fail('物品不足，无法使用', '★ use_shop_goods：%s 只有 %d 件' % (iid, left))
    info = item_info(iid)
    _mark(st, 'use_shop_goods', '使用商城物品 %s(%s)×1 → 余 %d（%s）'
          % (iid, info.get('name') or '?', left, src))
    _save(ctx, st)
    return ctx.ok({'itemId': iid, 'count': left},
                  '★ 使用商城物品 %s×1（余 %d）' % (iid, left))


def _ep_view_currency(ctx, st):
    kind = _s(ctx.param('currency_type') or 'yinpiao')
    n = get_currency(ctx, kind)
    cost_yb = int((YINPIAO_DIALOG_NUM + YINPIAO_PER_YUANBAO - 1) // YINPIAO_PER_YUANBAO)
    cv = _num(st.get('currencyVersion'), 1)
    _mark(st, 'view_currency_by_type', '%s = %d' % (kind, n))
    # `number` `limitNumber` `costYb` 都必须是数字：前两个会被 `..` 拼接，后者 nil 会让兑换弹窗直接 return
    return ctx.ok({'number': n, 'currency_type': kind, 'limitNumber': currency_limit(kind),
                   'costYb': cost_yb, 'yuanbao': get_currency(ctx, 'yuanbao'),
                   'currencyVersion': cv},
                  '★ 查货币 %s(%s) = %d' % (kind, currency_name(kind), n))


def _currency_req(ctx):
    """上行 `currency` 兼容三种写法：`{cType=count}` / `[{id,count}]` / `[[id,count]]`。"""
    obj = ctx.body_obj if isinstance(ctx.body_obj, dict) else {}
    cur = obj.get('currency')
    out = []
    if isinstance(cur, dict):
        for k, v in cur.items():
            if isinstance(v, dict):
                out.append((_s(k), _num(v.get('value') if v.get('value') is not None else v.get('count'))))
            else:
                out.append((_s(k), _num(v)))
    elif isinstance(cur, list):
        for it in cur:
            if isinstance(it, dict):
                out.append((_s(it.get('id') or it.get('currencyId')), _num(it.get('count') or it.get('num'))))
            elif isinstance(it, (list, tuple)) and len(it) >= 2:
                out.append((_s(it[0]), _num(it[1])))
    if not out:
        for k in ('currency_type', 'type', 'name', 'cType'):
            v = ctx.param(k)
            if v:
                out.append((_s(v), ctx.int_param('count') or ctx.int_param('number')))
                break
    return [x for x in out if x[0]]


def _route_activity_token(ctx, kind, n):
    """★ 2026-10-03 客户要求：货币礼包里补活动代币（香囊钥匙/鞭炮/佳酿/好运通宝/冥币）。

    这些不是钱袋子里的钱，而是**各活动自己的服务端计数**（客户实测"货币礼包里没有
    地府密钥和香囊钥匙、年兽鞭炮、醉仙楼的佳酿、好运通宝"）。客户端镜像分支
    （`fz_patch_role_attr.py` 的 `_purseKinds`）会对这些 kind 把 addAttr 转成
    `update_currency_by_type` 打到这里；这里按 kind 路由进对应活动的账本。
    返回 (显示名, 新数量)；不是代币返回 None（走正常钱袋）。
    """
    k = _s(kind)
    if n == 0:
        return None
    if k == 'mingbi':
        # 冥币（地府的货币，中元节活动用）就在钱袋里
        left = add_currency(ctx, 'mingbi', n)
        return ('冥币', left) if left is not None else None
    if k == 'nian_bianpao':
        import fz_api.activities as _act
        stt = ctx.load_json(_act.STATE, {})
        d = stt.setdefault('nian', {'count': 6, 'bianpao': 8, 'state': {},
                                    'drive': 0, 'claimed': {}})
        d['bianpao'] = max(0, _num(d.get('bianpao'), 8) + n)
        ctx.save_json(_act.STATE, stt)
        return ('鞭炮', d['bianpao'])
    if k == 'sachet_key':
        import fz_api.activities as _act
        stt = ctx.load_json(_act.STATE, {})
        d = stt.setdefault('sachet', {'currency': 40, 'level': {}, 'got': {}})
        d['currency'] = max(0, _num(d.get('currency'), 40) + n)
        ctx.save_json(_act.STATE, stt)
        return ('香囊钥匙', d['currency'])
    if k == 'baiduo':
        import fz_api.activities as _act
        stt = ctx.load_json(_act.STATE, {})
        d = stt.setdefault('toast', {'count': 6, 'baiduo': 10, 'state': {},
                                     'drink': 0})
        d['baiduo'] = max(0, _num(d.get('baiduo'), 10) + n)
        ctx.save_json(_act.STATE, stt)
        return ('佳酿', d['baiduo'])
    if k == 'lucky_coin':
        # 好运通宝（江湖好运来）——action_festival 的账本
        stf = ctx.load_json('action_festival_state.json', {})
        d = stf.setdefault('lucky', {'total': 0, 'exchange': 0, 'refresh': 0,
                                     'goods': None})
        d['total'] = max(0, _num(d.get('total'), 0) + n)
        ctx.save_json('action_festival_state.json', stf)
        return ('好运通宝', d['total'])
    return None


def _ep_update_currency(ctx, st):
    action = _s(ctx.param('action') or 'add').lower()
    req = _currency_req(ctx)
    if not req:
        return ctx.fail('货币参数为空', '★ update_currency_by_type：上行没有 currency')
    sign = -1 if action in ('remove', 'sub', 'cost', 'reduce') else 1
    granted = 0
    changed = {}
    for kind, cnt in req:
        # ★ 先过活动代币路由（香囊钥匙/鞭炮/佳酿/好运通宝/冥币），不是代币才进钱袋
        routed = _route_activity_token(ctx, kind, sign * cnt)
        if routed is not None:
            changed[kind] = routed[1]
            continue
        # 她 `BaseResults.lua:760` 读 `data.zjjifen`（当前战绩积分），0 会被当成"已达今日上限"
        left = add_currency(ctx, kind, sign * cnt)
        if left is None:
            left = get_currency(ctx, kind)
            if sign < 0:
                # 不够就按她客户端的"不给就提示"走：errcode 1 ⇒ PopText(errmsg)
                return ctx.fail('%s不足' % currency_name(kind),
                                '★ 扣 %s 失败（只有 %d，需要 %d）' % (kind, left, cnt))
        changed[kind] = left
        if kind == 'zjjifen' and sign > 0:
            granted = cnt
    st['currencyVersion'] = _num(st.get('currencyVersion'), 1) + 1
    _mark(st, 'update_currency_by_type', '%s %s → %s'
          % (action, ','.join('%s %+d' % (k, sign * c) for k, c in req), changed))
    _save(ctx, st)
    first = req[0][0]
    return ctx.ok({'zjjifen': granted, 'number': changed.get(first, 0),
                   'currency_type': first, 'currency': changed,
                   'currencyVersion': st['currencyVersion']},
                  '★ 货币 %s：%s' % (action, ','.join('%s=%d' % (k, v) for k, v in changed.items())))


def _ep_add_currency_by_type(ctx, st):
    req = _currency_req(ctx)
    if not req:
        req = [('mingbi', ctx.int_param('num') or ctx.int_param('count') or 1)]
    out = {}
    for kind, cnt in req:
        left = add_currency(ctx, kind, abs(cnt) or 1)
        out[kind] = _num(left)
    _mark(st, 'add_currency_by_type', ','.join('%s+%d' % (k, abs(c) or 1) for k, c in req))
    _save(ctx, st)
    cur = {}
    for k, v in out.items():
        cur.update(_currency_body(st, k, 0, v))
    return ctx.ok({'currency': cur},
                  '★ 加货币 %s' % ','.join('%s=%d' % (k, v) for k, v in out.items()))


def _ep_add_currency_number(ctx, st):
    req = _currency_req(ctx)
    out = {}
    for kind, cnt in req:
        if cnt < 0:
            left = add_currency(ctx, kind, cnt)
            if left is None:
                left = get_currency(ctx, kind)
        else:
            left = add_currency(ctx, kind, cnt)
        out[kind] = (_num(left), cnt)
    if not out:
        # 她那边可能只传 addType（挂机结算）：没有币种就回空对象，`MapIsEmpty` 会兜住
        out = {}
    _mark(st, 'add_currency_number',
          'addType=%s %s' % (ctx.param('addType'), ','.join('%s%+d' % (k, v[1]) for k, v in out.items())))
    _save(ctx, st)
    body = {}
    for k, (cnt, val) in out.items():
        body.update(_currency_body(st, k, val, cnt))
    return ctx.ok({'currency': body, 'addType': _s(ctx.param('addType'))},
                  '★ 网络属性变更：%s' % (','.join('%s%+d' % (k, v[1]) for k, v in out.items()) or '无'))


def _ep_exchange_yinpiao(ctx, st):
    number = ctx.int_param('number')
    kind = _s(ctx.param('type')).lower()
    if kind in ('yuanbao', '2', '3', 'gold'):
        wallet = get_currency(ctx, 'yuanbao')
        cost = number if number > 0 else min(wallet, YINPIAO_DIALOG_NUM // YINPIAO_PER_YUANBAO)
        if wallet < cost:
            return ctx.fail('元宝不足，当前只有%d元宝。' % wallet, '★ 兑换银票：元宝不足')
        add = max(1, cost) * YINPIAO_PER_YUANBAO
        left = add_currency(ctx, 'yuanbao', -cost)
        add_currency(ctx, 'yinpiao', add)
        _mark(st, 'exchange_yinpiao', '元宝兑换银票：-%d 元宝 / +%d 银票' % (cost, add))
        _save(ctx, st)
        # `HomelandModule.lua:312` 读 `data.get_yinpiao` + `data.next_yuanbao`
        return ctx.ok({'get_yinpiao': add, 'next_yuanbao': _num(left), 'costYb': cost},
                      '★ 元宝兑换银票（+%d 银票 / 余 %d 元宝）' % (add, _num(left)))
    # cheque：`result.arg2 - 1`（0..3）对应 homemoney200/1500/2500/5000
    order = ('homemoney200', 'homemoney1500', 'homemoney2500', 'homemoney5000')
    amounts = {'homemoney200': 200, 'homemoney1500': 1500,
               'homemoney2500': 2500, 'homemoney5000': 5000}
    idx = number if 0 <= number < len(order) else 0
    key = kind if kind in amounts else order[idx]
    add = amounts.get(key, 200)
    add_currency(ctx, 'yinpiao', add)
    _mark(st, 'exchange_yinpiao', '票据兑换银票：%s → +%d' % (key, add))
    _save(ctx, st)
    return ctx.ok({'get_yinpiao': add, 'next_yuanbao': get_currency(ctx, 'yuanbao')},
                  '★ 票据兑换银票 +%d' % add)


def _ep_get_item_count(ctx, st):
    iid = _s(ctx.param('itemId')) or DEFAULT_ITEM
    key, v = _server_entry(st, iid)
    if v is None:
        return ctx.ok({'count': get_count(ctx, iid), 'limit': DEFAULT_LIMIT, 'itemId': iid},
                      '★ 物品数量 %s（不在服务端表里，按包袱算）' % iid)
    # 她 `RoleUseItem_XinShenLiHe.lua:63` 读 `itemData.limit`（nil 会 error）
    return ctx.ok({'count': _num(v.get('count')), 'limit': _num(v.get('limit'), DEFAULT_LIMIT),
                   'itemId': iid},
                  '★ 物品数量 %s = %d/%d' % (iid, _num(v.get('count')), _num(v.get('limit'), DEFAULT_LIMIT)))


def _ep_get_item_map(ctx, st):
    item_map = {}
    for k, v in st['serverItems'].items():
        if isinstance(v, dict):
            item_map[k] = {'count': _num(v.get('count')),
                           'limit': _num(v.get('limit'), DEFAULT_LIMIT)}
    # `LianGongPresenter.lua:817` / `XinShenPresenter.lua:256` 读 `data.itemMap`（对象！）
    return ctx.ok({'itemMap': item_map}, '★ 服务端物品表（%d 种）' % len(item_map))


def _ep_add_item_count(ctx, st):
    iid = _s(ctx.param('itemId')) or DEFAULT_ITEM
    n = ctx.int_param('count')
    key, v = _server_entry(st, iid)
    if v is None:
        key = canon(iid) or iid
        st['serverItems'][key] = {'count': 0, 'limit': DEFAULT_LIMIT}
        v = st['serverItems'][key]
    if n < 0 and _num(v.get('count')) + n < 0:
        return ctx.fail('物品不足', '★ addItemCount：%s 只有 %d，要 %d' % (iid, _num(v.get('count')), n))
    v['count'] = _num(v.get('count')) + n
    _mark(st, 'addItemCount', '%s %+d → %d' % (key, n, v['count']))
    _save(ctx, st)
    # `ServerActionSystem.lua:419` → `__saveAction(data.dataVer, ...)` ⇒ 必须有数字 dataVer
    return ctx.ok({'itemId': key, 'count': v['count']},
                  '★ 物品增减 %s %+d（现 %d）' % (key, n, v['count']))


def _ep_refresh_item_map_cache(ctx, st):
    for iid in _mind_items():
        st['serverItems'].setdefault(iid, {'count': 0, 'limit': DEFAULT_LIMIT})
    _mark(st, 'refreshItemMapCache', '刷新物品表缓存（%d 种）' % len(st['serverItems']))
    _save(ctx, st)
    return ctx.ok({'itemMap': {k: {'count': _num(v.get('count')),
                                   'limit': _num(v.get('limit'), DEFAULT_LIMIT)}
                               for k, v in st['serverItems'].items() if isinstance(v, dict)}},
                  '★ 刷新服务端物品表缓存')


def _ok_list(ctx, arr, note):
    """`data` **本身就是数组**的应答（`check_goods_valid`）。

    ★ 不能写 `ctx.ok(arr)`：`Ctx.ok` 缺 `dataVer` 时会 `dict(data)`，
    对**非空数组**会 `ValueError: dictionary update sequence element #0 has length 2; 2 is required`
    （空数组侥幸能过 ⇒ 探测不带参数时看不出来！）。她那边 `BaseHttp:createGetResponseFunction`
    把 `data` 原样透传，本来也不需要 `dataVer`。
    """
    return ctx.enc({'errcode': 0, 'data': arr, 'rand_t': time.time()}), note


def _ep_check_goods_valid(ctx, st):
    obj = ctx.body_obj if isinstance(ctx.body_obj, dict) else {}
    ids = obj.get('itemIds')
    if not isinstance(ids, list):
        ids = [ctx.param('itemIds')] if ctx.param('itemIds') else []
    out = []
    for it in ids:
        if isinstance(it, dict):
            it = it.get('id') or it.get('itemId')
        iid = _s(it)
        if not iid:
            continue
        # 她 `BaseItem.lua:630` / `FestivalModule.lua:680` 读 `v.itemId` 与 `v.number`
        out.append({'itemId': iid, 'number': get_count(ctx, iid)})
    return _ok_list(ctx, out, '★ 校验 %d 件物品（数组，元素带 itemId/number）' % len(out))


def _ep_server_resource_count(ctx, st):
    obj = ctx.body_obj if isinstance(ctx.body_obj, dict) else {}
    lst = obj.get('itemList')
    if not isinstance(lst, list):
        lst = []
    rows = []
    for it in lst:
        if not isinstance(it, dict):
            continue
        rid = _s(it.get('id'))
        rtype = _num(it.get('type'))
        if not rid:
            continue
        # type 10 = 货币管理表新货币 / 5 = 缓存数据货币 ⇒ 走钱袋子；4、6 = 服务器物品
        cnt = get_currency(ctx, rid) if rtype in (5, 10) else get_count(ctx, rid)
        # 她 `DuplicatePurchaseCheck701.lua:62` 少一条就 error（被吞 ⇒ 卡死）⇒ 必须每条都回
        rows.append({'id': rid, 'type': rtype, 'count': cnt})
    return ctx.ok({'countData': rows}, '★ 服务器资源数量（%d 条）' % len(rows))


def _ep_special_item_exchange(ctx, st):
    obj = ctx.body_obj if isinstance(ctx.body_obj, dict) else {}

    def _pairs(v):
        out = []
        if isinstance(v, list):
            for it in v:
                if isinstance(it, dict):
                    out.append((_s(it.get('id')), _num(it.get('num') or it.get('count'))))
                elif isinstance(it, (list, tuple)) and len(it) >= 2:
                    out.append((_s(it[0]), _num(it[1])))
        elif isinstance(v, dict):
            for k, n in v.items():
                out.append((_s(k), _num(n)))
        return [(a, b) for a, b in out if a]

    exch = _pairs(obj.get('exchangeItems'))
    target = _pairs(obj.get('targetItems'))
    if not exch or not target:
        # 上行没给清单就是空动作（她客户端只有拿到 `result.arg2/arg3` 才会调）
        return ctx.ok({'targetItems': []}, '★ 特殊物品兑换：上行没有清单，空动作')
    for iid, n in exch:
        if get_count(ctx, iid) < n:
            # 她 `CommonResults.lua:3731`：errcode 1 = 非法
            return ctx.fail('物品不足，无法兑换', '★ 特殊物品兑换：%s 只有 %d，要 %d'
                            % (iid, get_count(ctx, iid), n), 1)
    for iid, n in exch:
        add_count(ctx, iid, -n)
    for iid, n in target:
        grant(ctx, iid, n)
    _mark(st, 'special_item_exchange', '%s → %s'
          % (','.join('%s×%d' % x for x in exch), ','.join('%s×%d' % x for x in target)))
    _save(ctx, st)
    return ctx.ok({'targetItems': [{'id': i, 'num': n} for i, n in target]},
                  '★ 特殊物品兑换：%s → %s'
                  % (','.join('%s×%d' % x for x in exch), ','.join('%s×%d' % x for x in target)))


def _reel_reward(item_id):
    """礼盒开出哪一卷（`breakThroughItems["Items"]` 里的真 id）。

    她 `RoleUseItem_XuJuanLiHe.lua:21` 会用 `info.id` 去查表并取 `.name`，
    查不到就抛错（被吞 ⇒ 卡面），所以**只能发她表里真实存在的 id**。
    """
    items = break_through_items()
    pref = {'22jianghureelbox': ('江湖',), '22menpaireelbox': ('门派',),
            '22quanreelbox': ('江湖', '门派')}.get(_s(item_id))
    keys = sorted(items.keys())
    if pref:
        for k in keys:
            nm = _clean((items.get(k) or {}).get('name'))
            if any(p in nm for p in pref):
                return k
    for k in keys:
        if '续卷' in _clean((items.get(k) or {}).get('name')):
            return k
    return keys[0] if keys else ''


def _ep_consume_special_props(ctx, st):
    iid = _s(ctx.param('itemId')) or DEFAULT_REEL
    n = max(1, ctx.int_param('number') or 1)
    ok, left, src = _take_any(ctx, st, iid, n)
    if not ok:
        return ctx.fail('物品不足', '★ consumeSpecialProps：%s 只有 %d，要 %d' % (iid, left, n))
    rid = _reel_reward(iid)
    rewards = []
    if rid:
        _give(st, rid, 1)
        rewards.append({'id': rid, 'num': 1})
    st['currencyVersion'] = _num(st.get('currencyVersion'), 1) + 1
    nm = _clean((break_through_items().get(rid) or {}).get('name')) or rid
    _mark(st, 'consume_special_props', '消耗 %s×%d → %s×1' % (iid, n, rid))
    _save(ctx, st)
    # `rewards` 必须是**数组**，元素带 id/num
    return ctx.ok({'rewards': rewards, 'currencyVersion': st['currencyVersion'],
                   'itemId': iid, 'count': left},
                  '★ 开启 %s：获得 %s×1' % (iid, nm))


def _upgrade_table(kind):
    """扩容档位表 → {等级: 配置}。

    kind：1=背包(`bagUpgrade.lua["背包"]`) / 2=仓库(`wareHouseUpgrade.lua["仓库"]`)
          / 3=神兵袋(`godweaponCarry.lua`) / 5=神兵拥有(`godweaponhold.lua`)
    ★ 2026-10-16 v33：3/5 原来落到 else 分支被当「背包」查表 —— 客户端的
      `ShenBingWareHouse:upgrade` 发 type=3、`ShenBingDuanZao` 发 type=5，
      背包表档位是 1000 起、神兵表是 1 起 ⇒ 查不到 ⇒ 回「仓库已达最高等级」，
      客户「花元宝也升不上去」。这里按 kind 取对的表。
    """
    if kind == 2:
        t = _lua(_WHUP)
        node = t.get('仓库')
    elif kind == 3:
        t = _lua(_GWCARRY)
        node = t.get('Sheet1')
    elif kind == 5:
        t = _lua(_GWHOLD)
        node = t.get('Sheet1')
    else:
        t = _lua(_BAGUP)
        node = t.get('背包')
    out = {}
    if isinstance(node, dict):
        for k, v in node.items():
            if isinstance(v, dict):
                out[_num(v.get('id'), _num(k))] = v
    return out


def _ep_upgrade_user_bag(ctx, st):
    kind = ctx.int_param('type') or 1
    level = ctx.int_param('level')
    cfg = _upgrade_table(kind)
    # ★ 2026-10-16 v33：3=神兵袋 / 5=神兵拥有（各自的档位从 1 起，默认 1 级）
    label = {1: '背包', 2: '仓库', 3: '神兵袋', 5: '神兵拥有'}.get(kind, '仓库')
    _lvl_key = {1: 'bagLevel', 2: 'warehouseLevel',
                3: 'shenbingCarryLevel', 5: 'shenbingHoldLevel'}.get(kind, 'warehouseLevel')
    cur_level = _num(st.get(_lvl_key), 1 if kind in (3, 5) else 1000)
    if level <= 0:
        # 上行没带等级（探测/异常请求）：回当前等级
        level = cur_level if cur_level in cfg else (1000 if 1000 in cfg else (min(cfg) if cfg else 1000))
    node = cfg.get(level)
    if node is None:
        return ctx.fail('%s已达最高等级' % label, '★ %s扩容：等级 %d 不在她的表里' % (label, level))
    cost = _num(node.get('count'))
    cur = _num(node.get('currency'))
    space = _num(node.get('bagcount'))
    unit = {1: 'money', 2: 'yuanbao'}.get(cur)
    unit_name = {1: '碎银', 2: '元宝'}.get(cur, '碎银')
    if level == cur_level:
        # 已经在这一档了：只回信息，**不重复收费**（她客户端只会请求 `_BagLevel+1`）
        return ctx.ok({'count': cost, 'currency': cur if cur else 1, 'level': level,
                       'bagcount': space, 'type': kind},
                      '★ %s当前 %d 格（`%s` 第 %d 档，未扣费）' % (label, space, label, level))
    if cost > 0 and unit and get_currency(ctx, unit) < cost:
        return ctx.fail('%s不足，升级%s需要%d%s'
                        % (currency_name(unit), label, cost, currency_name(unit)),
                        '★ %s扩容：%s 不够（%d/%d）'
                        % (label, currency_name(unit), get_currency(ctx, unit), cost))
    if cost > 0 and unit:
        add_currency(ctx, unit, -cost)
    st[_lvl_key] = level
    # `Bag.lua:8` 的 `CurrencyType`：1=碎银 2=元宝（`cur` 是**货币编码**，不是币种名）
    unit_name = {1: '碎银', 2: '元宝'}.get(cur, '碎银')
    _mark(st, 'upgrade_user_bag', '%s → %d 级/%d 格，花费 %d %s' % (label, level, space, cost, unit_name))
    _save(ctx, st)
    # `Bag.lua:46`：`if data.count then` + `CurrencyType[tostring(data.currency)]` ⇒ 两个都得是数字
    return ctx.ok({'count': cost, 'currency': cur if cur else 1, 'level': level,
                   'bagcount': space, 'type': kind},
                  '★ %s扩容到 %d 格（花 %d %s）' % (label, space, cost, unit_name))


def _ck(st, ckname):
    box = st['ck'].get(ckname)
    if not isinstance(box, dict):
        box = {'ver': 1, 'items': {}, 'update_time': int(time.time())}
        st['ck'][ckname] = box
    if not isinstance(box.get('items'), dict):
        box['items'] = {}
    box['ver'] = _num(box.get('ver'), 1)
    return box


def _ep_beput_ckitems(ctx, st):
    ckname = _s(ctx.param('ckname') or ctx.param('ckName') or 'shenbing')
    iid = _s(ctx.param('itemId')) or DEFAULT_ITEM
    total = ctx.int_param('total') or 1
    ok, left, src = _take_any(ctx, st, iid, total)
    if not ok:
        return ctx.fail('物品不足，无法入库', '★ 入库：%s 只有 %d' % (iid, left))
    box = _ck(st, ckname)
    key = canon(iid) or iid
    box['items'][key] = _num(box['items'].get(key)) + total
    box['ver'] = _num(box.get('ver'), 1) + 1
    box['update_time'] = int(time.time())
    _mark(st, 'beput_ckitems', '%s 入库 %s×%d（ver=%d）' % (ckname, key, total, box['ver']))
    _save(ctx, st)
    # `CangYiGeModel.lua:284` 读 `data.ver` 与 `data.update_time`
    return ctx.ok({'ver': box['ver'], 'update_time': box['update_time'],
                   'itemId': key, 'total': total},
                  '★ %s 入库 %s×%d' % (ckname, key, total))


def _ep_outgoing_ckitems(ctx, st):
    ckname = _s(ctx.param('ckname') or ctx.param('ckName') or 'shenbing')
    iid = _s(ctx.param('itemId')) or DEFAULT_ITEM
    cnt = max(1, ctx.int_param('count') or 1)
    box = _ck(st, ckname)
    key = None
    for k in aliases(iid):
        if k in box['items']:
            key = k
            break
    untracked = key is None
    if untracked:
        # 服务端没记过这一件（她的仓库明细在客户端存档里）⇒ 按她客户端已校验处理，放行
        key = canon(iid) or iid
        box['items'][key] = 0
    have = _num(box['items'].get(key))
    if have < cnt and not untracked:
        return ctx.fail('仓库里没有这么多', '★ 出库：%s 只有 %d，要 %d' % (key, have, cnt))
    box['items'][key] = have - cnt
    if box['items'][key] <= 0:
        del box['items'][key]
    _give(st, key, cnt)              # 出库 → 回到服务端物品表（她那边同时也会 addItemCount）
    box['ver'] = _num(box.get('ver'), 1) + 1
    box['update_time'] = int(time.time())
    _mark(st, 'outgoing_ckitems', '%s 出库 %s×%d（ver=%d）' % (ckname, key, cnt, box['ver']))
    _save(ctx, st)
    # `CangYiGeModel.lua:217` 读 `data.ver` `data.itemId` `data.total`
    return ctx.ok({'ver': box['ver'], 'itemId': key, 'total': cnt,
                   'update_time': box['update_time']},
                  '★ %s 出库 %s×%d' % (ckname, key, cnt))


def _ep_del_ckitems(ctx, st):
    ckname = _s(ctx.param('ckname') or ctx.param('ckName') or 'shenbing')
    box = _ck(st, ckname)
    n = len(box['items'])
    box['items'] = {}
    box['ver'] = _num(box.get('ver'), 1) + 1
    box['update_time'] = int(time.time())
    _mark(st, 'del_ckitems', '清空 %s（%d 件）' % (ckname, n))
    _save(ctx, st)
    return ctx.ok({'ver': box['ver'], 'ckname': ckname}, '★ 清空仓库 %s（%d 件）' % (ckname, n))


_HANDLERS = {
    'useItem': _ep_use_item,
    'use_shop_goods': _ep_use_shop_goods,
    'view_currency_by_type': _ep_view_currency,
    'update_currency_by_type': _ep_update_currency,
    'add_currency_by_type': _ep_add_currency_by_type,
    'add_currency_number': _ep_add_currency_number,
    'exchange_yinpiao': _ep_exchange_yinpiao,
    'getItemCount': _ep_get_item_count,
    'getItemMap': _ep_get_item_map,
    'addItemCount': _ep_add_item_count,
    'refreshItemMapCache': _ep_refresh_item_map_cache,
    'check_goods_valid': _ep_check_goods_valid,
    'get_server_resource_count': _ep_server_resource_count,
    'special_item_exchange': _ep_special_item_exchange,
    'consume_special_props': _ep_consume_special_props,
    'upgrade_user_bag': _ep_upgrade_user_bag,
    'beput_ckitems': _ep_beput_ckitems,
    'outgoing_ckitems': _ep_outgoing_ckitems,
    'del_ckitems': _ep_del_ckitems,
}


def handle(ctx):
    ep = ctx.endpoint
    fn = _HANDLERS.get(ep)
    if fn is None:
        return None
    st = _load(ctx)
    return fn(ctx, st)
