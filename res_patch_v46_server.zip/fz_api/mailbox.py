# -*- coding: utf-8 -*-
# ================= 离线包路径根（fz_make_offline_bundle.py 自动注入） =================
# 手机上整个服务端就是一个目录，表在哪、状态写哪，全部相对包根算。
# （有的模块原来把绝对路径写死，本身没 import os —— 这里一并补上）
import os
import os as _osp


def _off_find_bundle(_f):
    """从模块所在目录往上找包根（认 fz_boot_server.py）。
    ★ fz_api/*.py 的 __file__ 在 <根>/fz_api/ 下，直接 dirname 会算错一层。"""
    _d = _osp.path.dirname(_osp.path.abspath(_f))
    for _ in range(6):
        if _osp.path.exists(_osp.path.join(_d, 'fz_boot_server.py')):
            return _d
        _u = _osp.path.dirname(_d)
        if _u == _d:
            break
        _d = _u
    return _osp.path.dirname(_osp.path.abspath(_f))


_OFF_BUNDLE = _off_find_bundle(__file__)
_OFF_FZ_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_fz')
_OFF_INK_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_ink')
_OFF_WORK_ROOT = _OFF_BUNDLE
# =====================================================================================
# ★ 2026-10-04 商城空货架修复：客户端资源表解析——PC 开发树优先，设备上自动回退
#   到包内 client_fz 副本（jhserver/client_fz = fangzhi_lua_dec 的同步拷贝）。
def _fz_res(*parts):
    base = os.path.join(_OFF_FZ_ROOT, 'res', 'script')
    if not os.path.isdir(base):
        base = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            '..', 'client_fz', 'res', 'script')
    return os.path.join(base, *parts)

# -*- coding: utf-8 -*-
"""江湖邮驿（邮箱）—— 1:1 还原她的 `MailBoxModel` 契约。

契约来源（她的 lua，逐个读过）：
  * `assets/src/app/models/MailBox/MailBoxModel.lua`
      - `getEmails`      → `get_email_info`        读 `data.emailList`(数组) / `data.emailMaxNum`(数字)
      - `readEmail`      → `read_email`            读 `data.expired_time`(数字，剩余秒)
      - `deleteEmail`    → `delete_email/<id>`     只读 errcode(0 删成功 / 2 已过期)
      - `getEmailReward` → `get_email_reward`      读 `data.loc_items / net_items / loc_attrs /
                                                    net_attrs / new_currencys / title_items /
                                                    msg / expired_time / is_get /
                                                    dataVer / currencyVersion`
      - `getAllEmailRewardList` → `get_email_rewards_list`
                                 读上面那 6 个奖励数组（`mergeAllEmailRewardData`，缺一个都崩）
      - `getAllEmailReward`     → `get_all_email_rewards`
                                 读 6 个奖励数组 + `msg` + `is_getList[{id,expired_time}]`
      - `deleteIsFinishEmails`  → `delete_processed_emails`  读 `data.delete_ids`(数组)
      - `createRetrievables` / `receiveReward` 读每个附件的 `{id,num,state,onlyId}`
  * `assets/src/app/views/layer/MailBoxLayer/MailBoxLayer.lua`（列表/弹窗 UI）
      - 列表项读邮件本体：`id / title / is_read / is_get / expired_time`
      - `initPopData` 读 `title / contents / is_get / 6 类附件`
      - 附件状态必须是 `MailBoxConstants.StateName` 的键（0 未领取 / 1 已领取 / 2 逾限），
        否则 `error("附件状态异常"..v.state)` ⇒ 被 xpcall 吞掉 ⇒ UI 整体卡死
      - ⚠ `expired_time` 是**剩余秒数**（`Helper:sec3timeDsc` 按秒算天/时/分，且每帧自减），
        不是 unix 时间戳；`<=0` 会被判"此邮件已过期"。
  * `assets/src/app/models/MailBox/MailBoxConstants.lua`
      - `UnRead=0 / IsRead=1`；`NotAward=0 / UnGetAward=1 / GetAward=2`
      - `OneItemUnGet=0 / OneItemIsGet=1 / OneItemExceedLimit=2`

数据来源（她自己的资源表，运行期惰性解析，取不到就退化成内置的那几封真邮件文本）：
  * 物品 id / 名称 / 图标：`res/script/store/shoplist.lua` 的 `["Sheet1"]`（键形如 "300002"，
    正是 `GoodsHelper:getGoodsResClass(id)` / `Item:getOneItemByKey(id)` 查的那张表）
  * 称号 id / 称号文本：`res/script/roleTitle/newRoleTitleConf.lua` 的 `["1"]`
    （正是 `RoleTitleResManager:getBasicTitleClassById` 查的表；id 形如 "50170"）
  * 属性名可读性：`res/script/others/monetarymanagement.lua` 的 `Sheet1`
    （`Role:getCHAttrName` 先查货币表；这里只用 exp/pot/money 这类一定认识的老属性）

状态：`work/mailbox_state.json` —— 读信 / 领取 / 删除都真写盘，再拉 `get_email_info` 就是改过的值。
"""
import os
import copy
import time

NAME = 'mailbox'
TITLE = '邮箱/江湖邮驿'
ENDPOINTS = [
    'get_email_info',
    'get_email_reward',
    'get_email_rewards_list',
    'read_email',
    'delete_email',              # 单封删除：URL 是 `delete_email/<id>`（她面板上每封的「删除」）
    'delete_processed_emails',
    'get_all_email_rewards',
]

STATE = 'mailbox_state.json'

RES = _fz_res()
SHOPLIST = RES + r'/store/shoplist.lua'
TITLECONF = RES + r'/roleTitle/newRoleTitleConf.lua'

EMAIL_MAX_NUM = 50

# 附件状态（MailBoxConstants）
ITEM_UNGET, ITEM_ISGET, ITEM_EXCEED = 0, 1, 2
# 邮件状态
NOT_AWARD, UNGET_AWARD, GET_AWARD = 0, 1, 2
UNREAD, ISREAD = 0, 1

DAY = 24 * 60 * 60

# ---- 内置的几封"真"邮件（附件 id 全是 shoplist["Sheet1"] 里真有的键）----
SEED_MAILS = [
    {
        'id': 1,
        'title': '江湖邮驿·开箱礼',
        'contents': '少侠远来，一路风尘。\n\n这是江湖邮驿为你留的一份开箱礼：流云甘露二份、凝神丹五颗。\n'
                    '点开此信即可领取，愿少侠行侠仗义、快意恩仇。',
        'is_read': UNREAD,
        'is_get': UNGET_AWARD,
        'expired_days': 30,
        'loc_items': [
            {'id': '300002', 'num': 2, 'state': ITEM_UNGET},   # 流云甘露
            {'id': '400002', 'num': 5, 'state': ITEM_UNGET},   # 凝神丹
        ],
        'loc_attrs': [
            {'id': 'pot', 'num': 200, 'state': ITEM_UNGET},    # 潜能
        ],
    },
    {
        'id': 2,
        'title': '门派嘉奖·初入江湖',
        'contents': '掌门有言：\n\n你入门未久便能勤修不辍，特赐「小有侠义」称号一枚，'
                    '另赏武学要领二十卷。望你日后扬我门楣。',
        'is_read': UNREAD,
        'is_get': UNGET_AWARD,
        'expired_days': 30,
        'loc_items': [
            {'id': '400040', 'num': 20, 'state': ITEM_UNGET},  # 武学要领
        ],
        'title_items': [
            {'id': '50174', 'num': 1, 'state': ITEM_UNGET},    # 旷世大侠（newRoleTitleConf["1"]）
        ],
    },
    {
        'id': 3,
        'title': '系统告示·江湖规矩',
        'contents': '一、江湖恩怨，生死自负。\n二、副本所得，出本方定。\n'
                    '三、邮件储存：未读三十日，已处理三日，逾期自毁。\n\n—— 江湖驿丞 谨启',
        'is_read': ISREAD,
        'is_get': NOT_AWARD,       # 纯文本邮件：会被"删除已处理邮件"回收
        'expired_days': 30,
    },
]

_ITEM_CACHE = {}




def _lua_table(path, sheet=None):
    """用 `work/fz_luatable.py` 解析她的一张表；失败返回 {}（绝不抛异常）。"""
    try:
        import fz_luatable
        t = fz_luatable.load_lua_table(path)
    except Exception:                          # noqa: BLE001
        return {}
    if not isinstance(t, dict):
        return {}
    if sheet is not None:
        v = t.get(sheet)
        return v if isinstance(v, dict) else {}
    return t


def _shop():
    """`res/script/store/shoplist.lua["Sheet1"]` —— 物品货架键（"300002"）→ {name, icon, ...}。"""
    c = _ITEM_CACHE.get('shop')
    if c is None:
        c = _lua_table(SHOPLIST, 'Sheet1')
        _ITEM_CACHE['shop'] = c
    return c


def _titles():
    """`res/script/roleTitle/newRoleTitleConf.lua["1"]` —— 称号 id → {text, color, ...}。"""
    c = _ITEM_CACHE.get('title')
    if c is None:
        c = _lua_table(TITLECONF, '1')
        _ITEM_CACHE['title'] = c
    return c


# ---------------------------------------------------------------- 附件工具
def _seed_att(src, mail_id, kind, idx):
    """把一个附件补齐成她 UI 需要的 {id,num,state,onlyId,[name]} 对象。"""
    o = {
        'id': src.get('id'),
        'num': int(src.get('num') or 1),
        'state': int(src.get('state') or ITEM_UNGET),
        'onlyId': src.get('onlyId') or ('%s_%s_%d_%d' % (kind, mail_id, idx, int(src.get('num') or 1))),
    }
    if kind == 'net_items' and not o.get('name'):
        o['name'] = src.get('name') or ('道具%s' % o['id'])
    return o


def _norm_mail(m, now):
    """把落盘/种子邮件补成完整契约对象。"""
    exp = m.get('expire_at')
    if not isinstance(exp, (int, float)) or exp <= 0:
        exp = now + int(m.get('expired_days') or 30) * DAY
    out = {
        'id': int(m.get('id') or 0),
        'title': str(m.get('title') or ''),
        'contents': str(m.get('contents') or ''),
        'is_read': int(m.get('is_read') or UNREAD),
        'is_get': int(m.get('is_get') or NOT_AWARD),
        'expire_at': int(exp),
        'expired_time': max(0, int(exp) - int(now)),      # ★ 她读的是"剩余秒"
    }
    for k in ('loc_items', 'net_items', 'loc_attrs', 'net_attrs', 'new_currencys', 'title_items'):
        out[k] = [_seed_att(x, out['id'], k, i) for i, x in enumerate(m.get(k) or [])
                  if isinstance(x, dict) and x.get('id') is not None]
    if out['is_get'] == UNGET_AWARD and not any(out[k] for k in
                                               ('loc_items', 'net_items', 'loc_attrs', 'net_attrs',
                                                'new_currencys', 'title_items')):
        out['is_get'] = NOT_AWARD                          # 附件空了就别谎称可领
    return out


def _state(ctx):
    st = ctx.load_json(STATE, None)
    if not isinstance(st, dict):
        st = {}
    now = int(time.time())
    # ★ 只在**第一次**（文件里没有 mails 键）撒种子；`mails: []` 是"玩家清空了邮驿"，
    #   不能当成没初始化 —— 否则删完邮件再一拉，种子邮件又全回来了。
    if 'mails' not in st or not isinstance(st.get('mails'), list):
        st['mails'] = []
        for s in SEED_MAILS:
            st['mails'].append({
                'id': s['id'], 'title': s['title'], 'contents': s['contents'],
                'is_read': s['is_read'], 'is_get': s['is_get'],
                'expire_at': now + int(s.get('expired_days') or 30) * DAY,
            })
            tgt = st['mails'][-1]
            for k in ('loc_items', 'net_items', 'loc_attrs', 'net_attrs', 'new_currencys', 'title_items'):
                if s.get(k):
                    tgt[k] = copy.deepcopy(s[k])
        st['currencyVersion'] = int(st.get('currencyVersion') or 1)
        st['next_id'] = max([m['id'] for m in st['mails']] or [0]) + 1
    st.setdefault('currencyVersion', 1)
    st.setdefault('next_id', 1)
    return st


def _save(ctx, st):
    ctx.save_json(STATE, st)


def _mails(ctx, st, now):
    out = []
    for m in st.get('mails') or []:
        if not isinstance(m, dict):
            continue
        out.append(_norm_mail(m, now))
    return out


def _find(st, mid):
    for m in st.get('mails') or []:
        if isinstance(m, dict) and str(m.get('id')) == str(mid):
            return m
    return None


def _reward_lists(mail):
    """把一封邮件的 6 类附件摊成 `mergeAllEmailRewardData` 认的 6 个数组。"""
    out = {}
    for k in ('loc_items', 'net_items', 'loc_attrs', 'net_attrs', 'new_currencys', 'title_items'):
        out[k] = []
        for i, x in enumerate(mail.get(k) or []):
            if not isinstance(x, dict) or x.get('id') is None:
                continue
            o = {'id': x.get('id'), 'num': int(x.get('num') or 1), 'state': int(x.get('state') or 0),
                 'onlyId': x.get('onlyId') or ('%s_%s_%d' % (k, mail.get('id'), i))}
            if k == 'net_items':
                o['name'] = x.get('name') or ('道具%s' % o['id'])
            out[k].append(o)
    return out


def _unclaimed(state_mail):
    return bool(any(
        isinstance(x, dict) and int(x.get('state') or 0) != ITEM_ISGET
        for k in ('loc_items', 'net_items', 'loc_attrs', 'net_attrs', 'new_currencys', 'title_items')
        for x in (state_mail.get(k) or [])))


def _processed(state_mail):
    """她面板上写的规则：已领取完毕的含附件邮件 / 已阅读的纯文本邮件，储存 3 天后可清。

    ⇒ 只有这两类能进"删除已处理邮件"；已读但附件没领完的**不能删**（否则玩家会丢附件）。
    """
    has_att = any(state_mail.get(k) for k in
                  ('loc_items', 'net_items', 'loc_attrs', 'net_attrs', 'new_currencys', 'title_items'))
    if has_att:
        return int(state_mail.get('is_get') or 0) == GET_AWARD and not _unclaimed(state_mail)
    return int(state_mail.get('is_read') or 0) == ISREAD


def _mark_all_get(state_mail):
    for k in ('loc_items', 'net_items', 'loc_attrs', 'net_attrs', 'new_currencys', 'title_items'):
        for x in (state_mail.get(k) or []):
            if isinstance(x, dict):
                x['state'] = ITEM_ISGET
    state_mail['is_get'] = GET_AWARD


def _all_reward_lists(st):
    """全部"未领取完"邮件的附件合并 —— get_email_rewards_list 要的量身结构。"""
    out = {k: [] for k in ('loc_items', 'net_items', 'loc_attrs', 'net_attrs',
                           'new_currencys', 'title_items')}
    for m in st.get('mails') or []:
        if not isinstance(m, dict) or int(m.get('is_get') or 0) != UNGET_AWARD:
            continue
        r = _reward_lists(m)
        for k in out:
            out[k].extend(r[k])
    return out


def _empty_rewards():
    return {k: [] for k in ('loc_items', 'net_items', 'loc_attrs', 'net_attrs',
                            'new_currencys', 'title_items')}


def handle(ctx):
    ep = ctx.endpoint
    now = int(time.time())
    st = _state(ctx)

    # ------------------------------------------------ 拉邮件列表
    if ep == 'get_email_info':
        mails = _mails(ctx, st, now)
        # 过期邮件自动清（她那边也是"到期自动删除"）
        alive = [m for m in mails if m['expired_time'] > 0]
        if len(alive) != len(mails):
            st['mails'] = [m for m in (st.get('mails') or [])
                           if int(m.get('expire_at') or 0) > now]
            _save(ctx, st)
        mails = alive
        ctx.log('[邮箱] 拉列表：%d/%d 封' % (len(mails), EMAIL_MAX_NUM))
        return ctx.ok({'emailList': mails, 'emailMaxNum': EMAIL_MAX_NUM},
                      '★ 邮件列表（%d 封，附件取自 shoplist.lua）' % len(mails))

    # ------------------------------------------------ 读信（顺带写已读）
    if ep == 'read_email':
        mid = ctx.param('id')
        if mid is None and ctx.args:
            mid = ctx.args[0]
        m = _find(st, mid)
        if m is None:
            return ctx.fail('这封邮件已经不在邮驿里了', '★ 读信：邮件不存在（id=%s）' % mid, errcode=2)
        if int(m.get('expire_at') or 0) <= now:
            return ctx.fail('此邮件已过期，无法打开', '★ 读信：已过期（id=%s）' % mid, errcode=2)
        m['is_read'] = ISREAD
        _save(ctx, st)
        out = _norm_mail(m, now)
        ctx.log('[邮箱] 读信 id=%s 《%s》' % (out['id'], out['title']))
        return ctx.ok(out, '★ 读信《%s》（剩余 %d 秒）' % (out['title'], out['expired_time']))

    # ------------------------------------------------ 删单封
    if ep == 'delete_email':
        mid = ctx.args[0] if ctx.args else ctx.param('id')
        m = _find(st, mid)
        if m is None:
            return ctx.fail('这封邮件已经不在邮驿里了', '★ 删信：邮件不存在（id=%s）' % mid, errcode=2)
        if int(m.get('expire_at') or 0) <= now:
            return ctx.fail('此邮件已过期，无法删除', '★ 删信：已过期（id=%s）' % mid, errcode=2)
        st['mails'] = [x for x in (st.get('mails') or [])
                       if not (isinstance(x, dict) and str(x.get('id')) == str(mid))]
        _save(ctx, st)
        ctx.log('[邮箱] 删除邮件 id=%s' % mid)
        return ctx.ok({}, '★ 删除邮件（id=%s）' % mid)

    # ------------------------------------------------ 删"已处理"邮件
    if ep == 'delete_processed_emails':
        keep, gone = [], []
        for m in st.get('mails') or []:
            if not isinstance(m, dict):
                continue
            if _processed(m):
                gone.append(m.get('id'))
            else:
                keep.append(m)
        st['mails'] = keep
        _save(ctx, st)
        ctx.log('[邮箱] 清理已处理邮件 %d 封：%s' % (len(gone), gone))
        return ctx.ok({'delete_ids': gone}, '★ 删除已处理邮件（%d 封）' % len(gone))

    # ------------------------------------------------ 单封领奖
    if ep == 'get_email_reward':
        mid = ctx.param('id')
        m = _find(st, mid)
        if m is None or int(m.get('expire_at') or 0) <= now:
            return ctx.fail('此邮件已过期，无法领取', '★ 领奖：邮件不存在/已过期（id=%s）' % mid, errcode=2)
        got = _reward_lists(m)
        if int(m.get('is_get') or 0) == UNGET_AWARD:
            _mark_all_get(m)
        st['currencyVersion'] = int(st.get('currencyVersion') or 1) + 1
        _save(ctx, st)
        data = dict(got)
        data['msg'] = '已领取《%s》的全部附件' % (m.get('title') or '')
        data['expired_time'] = max(0, int(m.get('expire_at') or 0) - now)
        data['is_get'] = int(m.get('is_get') or 0)
        data['currencyVersion'] = st['currencyVersion']
        ctx.log('[邮箱] 领奖 id=%s → %s' % (mid, {k: len(v) for k, v in got.items()}))
        return ctx.ok(data, '★ 领取邮件奖励《%s》' % (m.get('title') or ''))

    # ------------------------------------------------ 全部可领列表
    if ep == 'get_email_rewards_list':
        data = _all_reward_lists(st)
        return ctx.ok(data, '★ 全部可领奖励列表（%s）'
                      % {k: len(v) for k, v in data.items()})

    # ------------------------------------------------ 一键全领
    if ep == 'get_all_email_rewards':
        data = _all_reward_lists(st)
        is_get_list = []
        for m in st.get('mails') or []:
            if not isinstance(m, dict) or int(m.get('is_get') or 0) != UNGET_AWARD:
                continue
            _mark_all_get(m)
            is_get_list.append({'id': m.get('id'),
                                'expired_time': max(0, int(m.get('expire_at') or 0) - now)})
        st['currencyVersion'] = int(st.get('currencyVersion') or 1) + 1
        _save(ctx, st)
        data['msg'] = '已领取全部邮件附件' if is_get_list else ''
        data['is_getList'] = is_get_list
        data['expired_ids'] = []
        data['currencyVersion'] = st['currencyVersion']
        ctx.log('[邮箱] 一键全领 %d 封' % len(is_get_list))
        return ctx.ok(data, '★ 领取所有邮件奖励（%d 封）' % len(is_get_list))

    return None
