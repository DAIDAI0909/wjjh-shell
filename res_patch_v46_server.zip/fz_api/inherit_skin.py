# -*- coding: utf-8 -*-
# ================= 离线包路径根（fz_make_offline_bundle.py 自动注入） =================
# 手机上整个服务端就是一个目录，表在哪、状态写哪，全部相对包根算。
# （有的模块原来把绝对路径写死，本身没 import os —— 这里一并补上）
import os
import os as _osp


def _off_find_bundle(_f):
    """从模块所在目录往上找包根（认 fz_boot_server.py）。
    ★ fz_api/*.py 的 __file__ 在 <根>/fz_api/ 下，直接 dirname 会算错一层。"""
    _d = _osp.path.dirname(_osp.path.abspath(_f))
    for _ in range(6):
        if _osp.path.exists(_osp.path.join(_d, 'fz_boot_server.py')):
            return _d
        _u = _osp.path.dirname(_d)
        if _u == _d:
            break
        _d = _u
    return _osp.path.dirname(_osp.path.abspath(_f))


_OFF_BUNDLE = _off_find_bundle(__file__)
_OFF_FZ_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_fz')
_OFF_INK_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_ink')
_OFF_WORK_ROOT = _OFF_BUNDLE
# =====================================================================================
# ★ 2026-10-04 商城空货架修复：客户端资源表解析——PC 开发树优先，设备上自动回退
#   到包内 client_fz 副本（jhserver/client_fz = fangzhi_lua_dec 的同步拷贝）。
def _fz_res(*parts):
    base = os.path.join(_OFF_FZ_ROOT, 'res', 'script')
    if not os.path.isdir(base):
        base = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            '..', 'client_fz', 'res', 'script')
    return os.path.join(base, *parts)

# -*- coding: utf-8 -*-
"""继承/转生/换皮/属性点洗点/自创武学补充/武学记录学习/地宫古迹任务 —— 1:1 还原她的接口。

契约出处（都在 `C:\\apkwork\\ink_dec\\src\\app` 里，逐个读过回调体）：

继承/转生（`views/layer/InheritLayer/`、`models/inherit/Inherit.lua`）
  * `createNextRoleTask`  ← `HttpManager:CreateHeir(heirName)`，上行 `{name}`
        `InheritSetNameLayer.lua:96-129` 回调读 `data.userid`(字符串) / `data.name`；
        **errcode==3 是"名字已存在"**，她那边照样读 `data.userid`+`data.name` 继续走。
  * `finishNextRoleTask`  ← `HttpManager:inherit(...)`，上行
        `{roleData={roleData}, dataVer=..., currencyVersion=...}` + 头 `userid`；
        `Inherit.lua:633-668` 回调**只认 errcode**：0=传承成功（Game:restart）、
        **6=已经传承过了**、其它 → PopText(errmsg)。
  * `get_chuanchen_user_info` ← `HttpManager:getInheritHistoryRoleAttr(data)`
        上行正文就是一个**字符串数组**（`Inherit.lua:177` 传 `{"zhengqi","xingzhen"}`）；
        回调读 `data[1].zhengqi`(数字) 与 `data[1].xingzhen.effectsCount.<effectId>`(数字)
        —— `effectsCount` 必须是**表**，她拿它 `pairs()` 再查 `script.others.zouxuejing` 的
        `effect[id].value`。`data` 直接用 `MapIsEmpty` 判空 ⇒ **回 `[]` 是合法"没数据"**。

学艺/请教（`InheritConsultLayer.lua:112,233`）
  * `get_other_skills` ← `HttpManager:getOtherSkills(inheritIndex)`，上行 `{inheritIndex}`
        回调读 `data.userid`(字符串，再当 `studyOtherSkill` 的入参) 与
        `data.list`(**表**：`for skillId, exp in pairs(data.list)` ⇒ 技能id→经验 的字典)。
  * `study_other_skill` ← `HttpManager:studyOtherSkill(userid, skillid)`，
        上行 `{userid, skill}`；回调**只认 errcode**（0 → 本地记经验）。

换皮（`models/ChangeHouseSkin/ChangeHouseSkin.lua:203,225`）
  * `buy_ui_theme`  ← `HttpManager:buyUiTheme(uiId)`，URL 尾段带参数 `buy_ui_theme/<uiId>`；
        回调读 **`data.remove`(数字)**：`self.__canghuangling = math.max(self.__canghuangling - data.remove, 0)`
        ⇒ 少这个字段直接 `attempt to perform arithmetic on a nil value`。
  * `use_ui_theme`  ← `HttpManager:useUiTheme(uiId)`，URL 尾段带参数 `use_ui_theme/<uiId>`；
        回调只认 errcode：**0=使用成功 / 2=皮肤已在使用中**，两者都走成功分支。
      皮肤清单本身在 `fz_boot_server.py:697` 的 `get_ui_theme_list` 里给出（7 套），
      皮肤 id 取自 `res/script/skin/UISkinlistConfig.lua` 的 `Sheet1`。

洗点（`models/AttrPointRemove/AttrPointRemove.lua:77,133`）
  * `get_attribute_times` / `remove_attribute_point` ← 无上行参数，POST。
        回调读 **`data.count` / `data.cooltime` / `data.num` / `data.remove`**，
        四个都过 `tonumber()`；`count`=上限、`num`=剩余、`cooltime`=冷却秒、`remove`=单次元宝价。
        冷却在客户端算：`self.__endTime = GetTime() + self.__removeCoolTime`。

自创武学补充（`models/SelfCreatedSkillSystem/SelfCreatedSkillPropSystem.lua:22`；
`presenters/selfCreatedSkill/zhaoImprovedPool/ZhaoCreatePropPresenter.lua:66-76`、
`ZhaoImprovedPoolPresenter.lua:82-92`）
  * `get_propList` ← `HttpManager:getPropList(propType)`，URL 尾段带参数
        `get_propList/<propType>`（1=创作道具 / 2=改良道具）。
        回调把 `data` **当数组 `ipairs`**，逐项读 `v.propId`(字符串) + `v.count`(数字)，
        再用 `SelfCreatedSkillManager:getPropMap(v.propId)` 去 `script.selfCreatedSkill.propMap["Sheet1"]`
        查名字/描述/类型 ⇒ **propId 必须是那张表里的键**，`count` 必须是数字。
        `propMap` 用 `functionType` 区分：1=创作道具 / 2=改良道具。

武学记录/学习（`models/recordAndLearnSKills/recordAndLearnSKills.lua:238,250,321,340`）
  * `record_skill` / `learn_skill` ← 上行 `{skill_id, skill_type}` / `{skill_id}`；回调只认 errcode。
  * `get_record_skills` ← 无上行参数，GET。两处回调读的字段并集：
        `data.record_skills`(数组，`ipairs` 逐项当技能id) —— 已记录的武学；
        `data.dream_skills`(数组) —— **`MapIsEmpty(data.dream_skills == false)` 是她自己的写法
        （把比较结果传进去了），所以这个 `ipairs` 一定会跑，**必须是数组**，给 nil 必崩**；
        `data.learn.currency_cost`(数字) + `data.learn.currency_type`(字符串)
        与 `data.record.currency_cost` + `data.record.currency_type`
        —— 她 `Role:getCHAttrName(currency_type)` 拿去查中文名，两种动作各一套。

地宫古迹任务（`models/SelfCreatedSkillSystem/SelfCreatedSkillTask/SelfCreatedSkillTaskModel.lua`；
`views/layer/ActionLayer/SelfCreatedTaskActionLayer.lua`；
`models/map/MapHandle/Modules/SelfCreatedSkillModule.lua:117-151`；
`models/map/MapHandle/Modules/BaseResults.lua:1097-1110`）
  * `accept_task` / `finish_task` / `reset_task` / `submit_task` / `get_task_info`
        ← 上行 `{task_id, extra}` / `{task_id}`（`task_id` 客户端写死 `"task22"`）。
        `__updateTaskInfo` 逐字段读：
            `state` / `start_time` / `end_time` / `dcount` / `zcount` /
            `extra.roleLv` / `extra.luck` / `extra.kongfu` / `extra.exp`
        其中一个为空她是 `assert(false, "task22 地宫古迹任务更新数据为空值")` ⇒ 全都要给。
        状态常量在她 `Definition.lua:208-216`：3空闲 / 4挂机 / 6已接 / 7待提交 / 9已完成。
        errcode 语义（`SelfCreatedTaskActionLayer.lua:68-152`、`BaseResults.lua:1100-1108`、
        `SelfCreatedSkillModule.lua:127-148`）：
            accept : 0成功 / 1已完成 / 2已接过 / 3当天次数上限
            finish : 0成功 / 2未接取 / 3已提交
            reset  : 0成功 / 1未接取 / 2无需重置 / 3本周已完成
            submit : 0成功 / 1已提交 / 2未接取 / 3尚未完成 / 5超过提交时间
        `submit_task` 成功时回调还读 **`data.task`**(任务对象) 与
            **`data.reward.client.attrs`**(字典：属性名→数值) 和
            **`data.reward.server.currency`**(字典：货币id→数值)、
            **`data.reward.server.selfCreatedItems`**(字典：propMap的id→数量)
            —— 只有 `errcode==0/5` 才读 `data.task`，所以 5 也要带 `task`。

内容全部取自她自己的资源表（`C:\\apkwork\\fangzhi_lua_dec\\assets\\res\\script`，
经 `work/fz_luatable.py`）：
  * `skin/UISkinlistConfig.lua` → `Sheet1`：7 套界面皮肤（default / uijiemian1..6）
  * `selfCreatedSkill/propMap.lua` → `Sheet1`：10 件创作/改良道具（`functionType` 分 1/2）
  * `skill/skill.lua` → `skills`：770 条武学（`id`/`name`/`methods`/`type`/`familyId`）
  * `zhishiSkills/zhishiSkillsParamsConf.lua` → `知识通用参数`：
        `transform_money`(洗点次数上限=5) / `strNeed,dexNeed,conNeed,intNeed`(=30)
  * `map/mapConditionAndResult/fb220.lua` → 地宫古迹（fb220）的
        `完成古迹任务` 里程碑（50/100/200/300/400 点）、
        `历练副本改良道具变化` (glczwanquanchongzhi001 ×1)、`副本无动画跳转` fb02_95
  * `others/monetarymanagement.lua` → `Sheet1`：货币 id→中文名
        （武学要领 amartial / 武学心得 bmartial）
  * `others/zouxuejing.lua` → `effect.<id>.value`：行针特效数值（论道要用）
  * 玩家真实存档 `work/role_store_dev1_raw.json` 的 `skills` / `inheritHistory` / `zhengqi`

持久状态：`work/inherit_skin_state.json`，按 `userid` 分玩家：
    players[<userid>] = {
        heir          : {userid, name, createdAt} | null   取好名的继承人（createNextRoleTask 建的）
        inheritCount  : 已传承次数
        nextRole      : {roleData, dataVer, currencyVersion, at} | null  最近一次交上来的新角色存档
        uiThemes      : [已购买的 uiId]
        usedUiId      : 当前使用的 uiId
        wash          : {count, num, lastTime}   剩余次数/上次洗点时间（冷却按 cooltime 推）
        props         : {propId: count}          自创武学的创作/改良道具
        propActive    : 最近一次使用的道具（记她 `setPropId` 那一步）
        recorded      : [已记录到先贤书案的技能id]
        learned       : [已从书案学会的技能id]
        studied       : [已向前辈请教过的技能id]
        task          : {state, start_time, finish_time, end_time, dcount, zcount,
                         gujiPoint, roleLv, luck, kongfu, exp, rewardTime}
    }

**与原版的已知差异 / 还没做**（诚实列出来，不拿假数据糊）：
  1. `finishNextRoleTask` 只做真实的"接档 + 计次"（把客户端 `role:getTrimData()` 上行的
     整份新角色存档按 `nextRole` 落盘、`inheritCount` +1、`heir` 清空），
     **没有**做原版服务端那一大套"新角色资质继承/门派生灭/背包转移"的换算 ——
     那套公式不在客户端里，公开资料也没有，**不编**。
  2. `study_other_skill` 的真实经验是客户端本地 `addSkillExp` 写的（`InheritConsultLayer:studySkill`），
     服务端只记"这条技能被请教过"；也不扣她的江湖阅历（阅历在存档里，本模块不碰）。
  3. `get_record_skills` 的 `currency_cost` 用 **1**（`record_skill`/`learn_skill` 各扣 1 个），
     因为 `武学要领(amartial)`/`武学心得(bmartial)` 这两张货币在 `monetarymanagement.lua` 里
     只有 id/名字、**没有单价字段**，原版单价在服务端配置里；这是唯一一个本模块自己定的常数。
  4. 地宫古迹的"完成线"用她 fb220 里真实存在的里程碑最大值 **400 点**（`rlt_digonglevel04`）；
     `accept_task` 没有做"当天次数上限"（errcode=3 那条），因为客户端与服务端配置里
     **都没有每日次数表**，不另造；只拦"本周已完成"与"状态不对"。
  5. `use_create_prop` / `use_improve_prop` 是**别人的接口**（`self_created_skill.py` 的 docstring
     里声明"不在本模块接口里"，但全仓 `fz_api/*.py` 里两个都没实现，仍是宽容占位），
     本模块按分工清单实现；若 `fz_api/__init__.py` 的撞车检测报重复，以模块名排序在前的为准。
  6. 本目录用到的 `canInherit`（`Inherit.lua:624` 的传承前置校验）与
     `upload_wash_attribute_record`（`AttrPointRemove.lua:232` 的上报）
     **不在我的 JSON 清单里**，没有实现，只在本条里报告给上级。
"""
import os
import re
import threading
import time
import traceback

NAME = 'inherit_skin'
TITLE = '继承/转生/换皮/属性点/自创武学补充/学艺'
ENDPOINTS = [
    # —— 继承 / 转生 ——
    'createNextRoleTask',
    'finishNextRoleTask',
    'get_chuanchen_user_info',
    # —— 学艺（向历代前辈请教）——
    'get_other_skills',
    'study_other_skill',
    # —— 换皮 ——
    'buy_ui_theme',
    'use_ui_theme',
    # —— 洗点 ——
    'get_attribute_times',
    'remove_attribute_point',
    # —— 自创武学补充（道具）——
    'get_propList',
    'use_create_prop',
    'use_improve_prop',
    # —— 武学记录 / 学习 ——
    'get_record_skills',
    'learn_skill',
    'record_skill',
    # —— 地宫古迹任务（自创武学任务）——
    'accept_task',
    'finish_task',
    'get_task_info',
    'reset_task',
    'submit_task',
]

STATE = 'inherit_skin_state.json'
ROLE_STATE = 'role_store_dev1_raw.json'          # 玩家真实存档（skills / inheritHistory / zhengqi）
RES_DIR = _fz_res()

# ---- 她 `Definition.lua:208-216` 的任务状态常量 ----
TASK_STATE_IDLE = 3
TASK_STATE_ACCEPT = 6
TASK_STATE_TO_SUBMIT = 7
TASK_STATE_COMPLETE = 9

TASK_ID = 'task22'                                # `SelfCreatedSkillTaskModel.lua:7`

# ---- 洗点：`AttrPointRemove.lua:25-31` 的客户端硬编码默认 ----
WASH_COOLTIME = 3600 * 12                         # 单次冷却 12 小时
WASH_PRICE = 300                                  # 单次 300 元宝
WASH_ATTR_NEED = {'str': 30, 'dex': 30, 'con': 30, 'int': 30}   # 兜底；真值读参数表

# 先贤书案的两种花费：`others/monetarymanagement.lua` 里真实存在的两种货币
RECORD_CURRENCY = 'amartial'                      # 武学要领（记录）
LEARN_CURRENCY = 'bmartial'                       # 武学心得（学习）
# ★ 唯一一个本模块自定的常数，原因见模块 docstring 第 3 条（她的货币表里没有单价）
SKILL_COST = 1

# 地宫古迹的完成线：她 fb220 `rlt_digonglevel00..04` 的真实里程碑
GUJI_MILESTONES = [50, 100, 200, 300, 400]
GUJI_FINISH = max(GUJI_MILESTONES)

# 她 fb220 里真实会掉的改良道具（`rlt_getitem02`）
GUJI_PROP_ID = 'glczwanquanchongzhi001'

# ---------------------------------------------------------------------------
# 资源表（懒加载 + 缓存；任何一张读不到都退化成 {}，绝不让接口抛异常）
# ---------------------------------------------------------------------------
_RES = {}
_RES_READY = False
_RES_LOCK = threading.Lock()

# `zhishiSkillsParamsConf.lua` 用了 `[=[...]=]` 长括号字符串，`fz_luatable` 解析不了
# （实测 `ValueError: 无法识别值 '[=[{...'`）⇒ 这里**只用正则抽 `["key"]={["content"]=...}`**，
# 不做整表解析，拿到的都是她表里的真实值。
_PARAM_RE = re.compile(
    r'\["((?:[^"\\]|\\.)*)"\]=\{?\["content"\]\s*=\s*'
    r'(?:\[\[(.*?)\]\]|\[=\[(.*?)\]=|(-?[0-9.]+))', re.S)




def _num(v, default=0):
    """她表里的数字可能是 int/float/数字字符串，统一成 int/float。"""
    if isinstance(v, bool) or v is None:
        return default
    if isinstance(v, (int, float)):
        return v
    try:
        f = float(str(v).strip())
    except (TypeError, ValueError):
        return default
    return int(f) if f.is_integer() else f


def _key(v):
    """表键统一成字符串（她 lua 表里既有 `["1"]` 也有 `[1]`）。"""
    if v is None:
        return ''
    if isinstance(v, bool):
        return 'true' if v else 'false'
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v).strip()


def _load_table(*rel):
    try:
        import fz_luatable
        t = fz_luatable.load_lua_table(os.path.join(RES_DIR, *rel))
        return t if isinstance(t, dict) else {}
    except Exception:                                  # noqa: BLE001
        return {}


def _load_zhi_shi_params():
    """读 `zhishiSkills/zhishiSkillsParamsConf.lua` 的 `知识通用参数`（长括号字符串用正则抽）。"""
    out = {}
    try:
        p = os.path.join(RES_DIR, 'zhishiSkills', 'zhishiSkillsParamsConf.lua')
        with open(p, encoding='utf-8', errors='replace') as f:
            txt = f.read()
    except OSError:
        return out
    for m in _PARAM_RE.finditer(txt):
        k = m.group(1)
        raw = m.group(2) if m.group(2) is not None else (
            m.group(3) if m.group(3) is not None else m.group(4))
        if raw is None:
            continue
        out[_key(k)] = raw.strip()
    return out


def _ensure_res():
    global _RES_READY
    if _RES_READY:
        return
    with _RES_LOCK:
        if _RES_READY:
            return
        # 皮肤：`skin/UISkinlistConfig.lua` → Sheet1（7 套）
        skin = _load_table('skin', 'UISkinlistConfig.lua')
        _RES['ui_skin'] = skin.get('Sheet1') or skin or {}
        # 自创武学道具：`selfCreatedSkill/propMap.lua` → Sheet1（10 件）
        pm = _load_table('selfCreatedSkill', 'propMap.lua')
        _RES['prop_map'] = {_key(k): v for k, v in (pm.get('Sheet1') or pm or {}).items()}
        # 武学：`skill/skill.lua` → skills（770 条）
        sk = _load_table('skill', 'skill.lua')
        _RES['skill'] = sk.get('skills') or {}
        # 知识通用参数
        _RES['param'] = _load_zhi_shi_params()
        # 行针特效数值：`others/zouxuejing.lua` → effect.<id>.value
        zx = _load_table('others', 'zouxuejing.lua')
        _RES['xingzhen'] = zx.get('effect') or {}
        _RES_READY = True


def _res(name, default=None):
    _ensure_res()
    v = _RES.get(name)
    return default if v is None else v


def _param(key, default=0):
    """从 `知识通用参数` 取一个值（数字就转数字，否则回原字符串）。"""
    v = _res('param', {}).get(_key(key))
    if v is None:
        return default
    try:
        return int(str(v).strip())
    except (TypeError, ValueError):
        try:
            return float(str(v).strip())
        except (TypeError, ValueError):
            return v


def _wash_limit():
    """洗点次数上限：她 `TRANSFORM_MONEY = transform_money`（真值 5）。"""
    return int(_num(_param('transform_money', 5), 5)) or 5


def _attr_need():
    """四种属性的洗点下限：她 `strNeed/dexNeed/conNeed/intNeed`（真值都是 30）。"""
    out = dict(WASH_ATTR_NEED)
    for attr, key in (('str', 'strNeed'), ('dex', 'dexNeed'),
                      ('con', 'conNeed'), ('int', 'intNeed')):
        out[attr] = int(_num(_param(key, out[attr]), out[attr]))
    return out


# ---------------------------------------------------------------------------
# 状态
# ---------------------------------------------------------------------------
def _load(ctx):
    st = ctx.load_json(STATE, {})
    if not isinstance(st, dict):
        st = {}
    if not isinstance(st.get('players'), dict):
        st['players'] = {}
    return st


def _uid(ctx):
    """她客户端上行头就是 `userid` / `uuid`（`BaseHttp.lua:145-146`），大小写兜一下。"""
    h = ctx.headers if isinstance(ctx.headers, dict) else {}
    for k in ('userid', 'uuid'):
        if h.get(k):
            return _key(h[k])
    for k, v in h.items():
        if str(k).lower() in ('userid', 'uuid') and v:
            return _key(v)
    return _key(ctx.param('userid')) or 'default'


def _role_state(ctx):
    """读玩家真实存档（`role_store_dev1_raw.json`）——用于 skills / inheritHistory / zhengqi。"""
    d = ctx.load_json(ROLE_STATE, None)
    return d if isinstance(d, dict) else {}


def _me(ctx, st):
    uid = _uid(ctx)
    p = st['players'].setdefault(uid, {})
    if not isinstance(p.get('heir'), dict):
        p['heir'] = None
    p['inheritCount'] = int(_num(p.get('inheritCount'), 0))
    if not isinstance(p.get('uiThemes'), list):
        p['uiThemes'] = []
    if not isinstance(p.get('usedUiId'), str):
        p['usedUiId'] = 'default'
    w = p.get('wash')
    if not isinstance(w, dict):
        w = {}
    w['count'] = int(_num(w.get('count'), _wash_limit())) or _wash_limit()
    w['num'] = int(_num(w.get('num'), w['count']))
    w['lastTime'] = _num(w.get('lastTime'), 0)
    p['wash'] = w
    if not isinstance(p.get('props'), dict) or not p['props']:
        # ★ 2026-10-17 v36（客户要求"自创神功的材料都加一下"）：道具账本空 → 全 10 种各 99。
        #   自创道具是**服务端账本**（`get_propList` 下发 / `use_create_prop` 扣），
        #   不是背包物品 ⇒ 直给账本就是"把材料都加上"。propMap 动态取键，表增减自动跟随。
        #   客户报名字对照：复思之书/重思之书/弃定之书=glczwanquanchongzhi001/003/002 ✓；
        #   "神功书卷"=开启系统钥匙（客户端保底直开，见 Role.lua v36）；铸意/守御/疾行/夺元
        #   卷轴游戏里不存在（客户记岔），全集以 propMap 为准：启发/灵感/神思/节源卷轴
        #   + 精研/超群/跃兴/复思/弃定/重思之书。
        p['props'] = {pid: 99 for pid in (_res('prop_map', {}) or {})}
    for k in ('recorded', 'learned', 'studied'):
        if not isinstance(p.get(k), list):
            p[k] = []
    if not isinstance(p.get('task'), dict):
        p['task'] = None
    return p


# ---------------------------------------------------------------------------
# 换皮（皮肤）—— 清单与 `fz_boot_server.py:697` 的 get_ui_theme_list 保持同一套 id
# ---------------------------------------------------------------------------
_SKIN_NAMES = {'default': '默认界面'}

# ★★ 2026-09-28 修「苍黄翻复」bug：**皮肤"已购"必须只有一个口径**
#
# 症状（老板报）：设置 → 苍黄翻复 里 7 套皮肤都显示「使用」（列表回 `isBuy=1`），
#   但点「使用」弹「尚未拥有该皮肤」（本函数用 `p['uiThemes']` 判，而那本是**空的**）。
#
# 根因：**两个接口读两份账**
#   * `get_ui_theme_list` → 在 `fz_boot_server.py` 的浅实现里**写死 7 套 isBuy=1**
#   * `use_ui_theme`       → 在本模块，查 `inherit_skin_state.json` 的 `uiThemes`（实测 `[]`）
#   ⇒ 列表说"你有"，使用说"你没有"。老板第十一轮反复纠正的就是这个病（"三处各报各的数"）。
#
# 处理：本模块**只认服务端发的那份解锁清单**（`get_ui_theme_list` 的 `isBuy`），
#   把"已购"状态按需**落到账本**里（懒同步），而不是另立一份空账反过来否决列表。
#   哪天要改成"皮肤要真买"，把 `get_ui_theme_list` 的 isBuy 改成按账本出、并把这里
#   的懒同步关掉即可 —— **两处必须同时改，否则这个 bug 立刻复发。**
def _skin_is_unlocked(ui_id, p):
    """这件皮肤现在能不能"使用"。

    ★ 开发服档位：**全部解锁**（与 `fz_boot_server.py` 的 `get_ui_theme_list` 同口径，
      那 7 套的 `isBuy` 恒为 1）。所以这里**直接放行**，
      **不往 `uiThemes` 里写**（`uiThemes` 是"真买过"的账，不该被"全解锁"污染；
       否则账本会被当成发放清单，列表的 isBuy 会跟着乱）。

    哪天要改成"皮肤要真买"：把 `get_ui_theme_list` 的 `isBuy` 改成按这份账出，
    并把下面改成 `return ui_id in p['uiThemes']` —— **两处必须一起改。**
    """
    return True


def _skin_ids():
    """她 `skin/UISkinlistConfig.lua` 的 `Sheet1` 键（default / uijiemian1..6）。"""
    ids = [_key(k) for k in _res('ui_skin', {})]
    if not ids:
        ids = ['default'] + ['uijiemian%d' % i for i in range(1, 7)]
    return ids


def _skin_name(ui_id):
    if ui_id in _SKIN_NAMES:
        return _SKIN_NAMES[ui_id]
    m = re.match(r'^uijiemian(\d+)$', ui_id)
    if m:
        return '界面皮肤 %s' % m.group(1)
    return ui_id


def _skin_price(ui_id):
    """皮肤价钱：`UISkinlistConfig.lua` 里**没有价格字段**（只有 7 个 uiId 的开关映射），
    原版价钱在服务端 ⇒ 这里只认表里真有的 `yuanbao`（没有就是 0），不另造价目。"""
    rec = _res('ui_skin', {}).get(ui_id)
    if isinstance(rec, dict):
        return int(_num(rec.get('yuanbao'), 0))
    return 0


def _buy_ui_theme(ctx, p):
    ui_id = _key(ctx.args[0] if ctx.args else ctx.param('uiId'))
    if not ui_id:
        return ctx.fail('皮肤id为空', '★ 购买皮肤失败：没有 uiId'), False
    if ui_id not in _skin_ids():
        return ctx.fail('皮肤不存在', '★ 购买皮肤失败：%s 不在 UISkinlistConfig' % ui_id), False
    if ui_id in p['uiThemes']:
        # errcode=2 在她那边表示"已拥有"
        return ctx.fail('该皮肤已经拥有了', '★ 购买皮肤失败：已拥有 %s' % ui_id, errcode=2), False
    price = _skin_price(ui_id)
    p['uiThemes'].append(ui_id)
    ctx.log('[inherit_skin] 购买皮肤 %s（%s）扣 %d' % (ui_id, _skin_name(ui_id), price))
    # ★ 她 `ChangeHouseSkin:buyUI` 读 `data.remove` 做减法 ⇒ 这个字段必须有
    return ctx.ok({'remove': price, 'uiId': ui_id},
                  '★ 购买皮肤《%s》（-元宝 %d）' % (_skin_name(ui_id), price)), True


def _use_ui_theme(ctx, p):
    ui_id = _key(ctx.args[0] if ctx.args else ctx.param('uiId'))
    if not ui_id:
        return ctx.fail('皮肤id为空', '★ 使用皮肤失败：没有 uiId'), False
    if ui_id not in _skin_ids():
        return ctx.fail('皮肤不存在', '★ 使用皮肤失败：%s 不在 UISkinlistConfig' % ui_id), False
    if ui_id == p['usedUiId']:
        # 她 `ChangeHouseSkin:useUI` 里 errcode==2 也走成功分支（"皮肤已在使用中"）
        return ctx.fail('该皮肤已在使用中', '★ 使用皮肤：%s 已在用' % ui_id, errcode=2), False
    if ui_id != 'default' and not _skin_is_unlocked(ui_id, p):
        return ctx.fail('尚未拥有该皮肤', '★ 使用皮肤失败：未购买 %s' % ui_id), False
    p['usedUiId'] = ui_id
    return ctx.ok({'uiId': ui_id}, '★ 使用皮肤《%s》' % _skin_name(ui_id)), True


# ---------------------------------------------------------------------------
# 洗点
# ---------------------------------------------------------------------------
def _wash_payload(p):
    """★ 她读 `data.count` / `data.cooltime` / `data.num` / `data.remove`，四个都要数字。"""
    w = p['wash']
    return {
        'count': int(w['count']),
        'cooltime': WASH_COOLTIME,
        'num': int(w['num']),
        'remove': WASH_PRICE,
    }


def _get_attribute_times(ctx, p):
    return ctx.ok(_wash_payload(p),
                  '★ 洗点次数 %d/%d（冷却 %d 秒 / 单价 %d 元宝）'
                  % (p['wash']['num'], p['wash']['count'], WASH_COOLTIME, WASH_PRICE)), False


def _remove_attribute_point(ctx, p):
    w = p['wash']
    limit = _wash_limit()
    if w['count'] != limit:                 # 参数表被她改过时跟着走
        w['count'] = limit
        if w['num'] > limit:
            w['num'] = limit
    if w['num'] <= 0:
        return ctx.fail('洗点次数已用完', '★ 洗点失败：剩余次数为 0'), False
    left = time.time() - _num(w.get('lastTime'), 0)
    if w.get('lastTime') and left < WASH_COOLTIME:
        return ctx.fail('洗点冷却中，还需 %d 秒' % int(WASH_COOLTIME - left),
                        '★ 洗点失败：冷却中（剩 %d 秒）' % int(WASH_COOLTIME - left)), False
    w['num'] -= 1
    w['lastTime'] = time.time()
    ctx.log('[inherit_skin] 洗点一次，剩余 %d/%d' % (w['num'], w['count']))
    return ctx.ok(_wash_payload(p),
                  '★ 洗点成功（剩余 %d/%d 次，-元宝 %d）'
                  % (w['num'], w['count'], WASH_PRICE)), True


# ---------------------------------------------------------------------------
# 自创武学补充：道具池
# ---------------------------------------------------------------------------
def _prop_record(prop_id):
    return _res('prop_map', {}).get(_key(prop_id))


def _prop_function_type(prop_id):
    rec = _prop_record(prop_id)
    if isinstance(rec, dict):
        try:
            return int(_num(rec.get('functionType'), 0))
        except (TypeError, ValueError):
            return 0
    return 0


def _prop_matches_type(prop_id, ptype):
    """`getPropList/<propType>`：1=创作道具（卷轴）/ 2=改良道具（书卷）。

    她 `propMap` 里 `functionType`：1=创作卷轴（启发/灵感/神思/节源）、
    2=提升品质的书卷（精研/超群/跃兴）、3=重构同品质招式（复思之书）、
    4=重置词缀（弃定/重思）。后三类 `type` 都是"书卷"，在客户端是同一条
    `ZhaoImprovedPoolPresenter`（改良池）里用的 ⇒ 都算 propType 2。
    她表里将来新增的、这边认不出的 `functionType` **不静默丢掉**，两个池都列。
    """
    ft = _prop_function_type(prop_id)
    if ft == 0:
        return True                       # 认不出的，宁可多给也别让她面板空着
    return ft == 1 if ptype == 1 else ft != 1


def _prop_list(ctx, p):
    # URL 尾段带参数：`get_propList/<propType>`（1创作道具 / 2改良道具）
    ptype = int(_num(ctx.args[0] if ctx.args else ctx.param('propType'), 1))
    out = []
    for pid, cnt in p['props'].items():
        if not isinstance(cnt, (int, float)) or cnt <= 0:
            continue
        if not isinstance(_prop_record(pid), dict):
            continue                  # 不在她 propMap 里的 id 一律不给她（她会 index nil）
        if not _prop_matches_type(pid, ptype):
            continue
        # ★ 她逐项读 `v.propId` + `v.count`，propId 拿去查 propMap
        out.append({'propId': _key(pid), 'count': int(cnt)})
    out.sort(key=lambda d: _key(d.get('propId')))
    return ctx.ok(out, '★ %s道具列表（%d 种）'
                  % ('创作' if ptype == 1 else '改良', len(out))), False


def _apply_creation_prop(ctx, p, prop_id, *, improve, extra=None):
    pid = _key(prop_id)
    rec = _prop_record(pid)
    if not isinstance(rec, dict):
        return ctx.fail('道具不存在', '★ 使用道具失败：%s 不在 propMap' % pid), False
    have = int(_num(p['props'].get(pid), 0))
    if have <= 0:
        return ctx.fail('你没有这个道具', '★ 使用道具失败：%s 数量为 0' % pid), False
    p['props'][pid] = have - 1
    p['propActive'] = {
        'propId': pid,
        'name': rec.get('name') or pid,
        'functionType': _prop_function_type(pid),
        'successRateAdd': _num(rec.get('successRateAdd'), 0),
        'at': int(time.time()),
    }
    ctx.log('[inherit_skin] 使用%s道具 %s（%s），剩 %d'
            % ('改良' if improve else '创作', pid, rec.get('name'), p['props'][pid]))
    payload = {
        'result': True,
        'propId': pid,
        'name': rec.get('name') or '',
        'count': int(p['props'][pid]),
        'successRateAdd': _num(rec.get('successRateAdd'), 0),
        'dsc': rec.get('dsc') or '',
        'useDsc': rec.get('useDsc') or '',
    }
    # ★ 2026-10-17 v36e：改良书把**变换后的新招式**并进应答（extra={'zhaos': ...}）——
    #   她 ZhaoInfoPresenter 拿 data.zhaos 覆盖当前招式，缺了就是"不立刻生效"。
    #   ★ 只能在 ctx.ok **之前**并——ctx.ok 返回的第一个元素已经是加密应答，动不了。
    if isinstance(extra, dict) and extra:
        payload.update(extra)
    return ctx.ok(payload, '★ 使用%s道具《%s》（剩 %d）'
       % ('改良' if improve else '创作', rec.get('name') or pid, p['props'][pid])), True


def _use_create_prop(ctx, p):
    # ★ 2026-10-17 v36c：客户端 `HttpManager:useCreateProp` 上行的字段名是 **prop**
    #   （`{prop=propId, lv, skillId}`），原来只读 propId/prop_id/id ⇒ 恒空 ⇒
    #   弹「道具不存在」（服务端日志实锤：『使用道具失败： (空) 不在 propMap』）。
    prop_id = ctx.param('prop') or ctx.param('propId') or ctx.param('prop_id') or ctx.param('id')
    return _apply_creation_prop(ctx, p, prop_id, improve=False)


def _use_improve_prop(ctx, p):
    # ★ v36c：改良道具同款——客户端 `useImproveProp` 上行也是 `{prop=...}`。
    prop_id = ctx.param('prop') or ctx.param('propId') or ctx.param('prop_id') or ctx.param('id')
    # ★★ 2026-10-17 v36c：改良书做**真变换**——她 `ZhaoInfoPresenter` 拿应答的
    #   `data.zhaos` 覆盖当前招式，只回道具信息 ⇒ "招式数据为空"＝看起来没效果。
    #   顺序：先变换（失败不扣道具）→ 再扣道具账本 → 应答带 {zhaos=新招式}。
    try:
        import fz_api.self_created_skill as _sc
    except Exception:                                   # noqa: BLE001
        _sc = None
    zhao_index = _num(ctx.param('zhaoIndex') or ctx.param('zhao_index'), 0)
    skill_id = ctx.param('skillId') or ctx.param('skill_id')
    new_zhao, err = (None, '改良功能未就绪')
    if _sc is not None and hasattr(_sc, 'improve_zhao_public'):
        new_zhao, err = _sc.improve_zhao_public(ctx, prop_id, skill_id, zhao_index)
    if new_zhao is None:
        # ★ v36e：fail 必须返回 (reply, dirty) 二元组——单值会让 handle 的
        #   `reply, dirty = fn(...)` unpack 崩掉 ⇒ 客户端弹「网络连接失败」。
        return ctx.fail(err or '无法使用', '★ 改良失败：%s' % err), False
    # ★ v36e：zhaos 在 ctx.ok 之前并入 payload（加密后注入是无效的——enc 过的是密文）。
    resp, dirty = _apply_creation_prop(ctx, p, prop_id, improve=True,
                                       extra={'zhaos': new_zhao})
    return resp, dirty


# ---------------------------------------------------------------------------
# 武学记录 / 学习（先贤书案）
# ---------------------------------------------------------------------------
def _skill_rec(sid):
    return _res('skill', {}).get(_key(sid))


def _skill_exists(sid):
    return isinstance(_skill_rec(sid), dict)


def _skill_name(sid):
    rec = _skill_rec(sid)
    if isinstance(rec, dict) and rec.get('name'):
        return str(rec['name'])
    return _key(sid)


def _is_jianghu_skill(sid):
    """江湖武学：她 `skill/skill.lua` 里没有 `familyId` 的那些（门派武学都带 familyId）。"""
    rec = _skill_rec(sid)
    if not isinstance(rec, dict):
        return False
    return not _key(rec.get('familyId'))


def _get_record_skills(ctx, p):
    """★ 她两处回调读的字段并集，`dream_skills` 那段必须给数组（见模块 docstring）。"""
    recorded = [_key(x) for x in p['recorded'] if _skill_exists(x)]
    # 可记录的：玩家真实存档里学过、且是江湖武学、且还没记到书案上的
    rs = _role_state(ctx)
    skills = rs.get('skills') if isinstance(rs.get('skills'), dict) else {}
    candidates = [s for s in (_key(k) for k in skills)
                  if _is_jianghu_skill(s) and s not in recorded]
    return ctx.ok({
        'record_skills': recorded,
        'dream_skills': [],                       # 梦境门派武学：她自己的写法令这个 ipairs 一定跑
        'record': {'currency_cost': SKILL_COST, 'currency_type': RECORD_CURRENCY},
        'learn': {'currency_cost': SKILL_COST, 'currency_type': LEARN_CURRENCY},
        # 额外给一份候选（她当前版本没读它，多给不会崩；方便以后接）
        'can_record_skills': candidates,
    }, '★ 先贤书案：已记录 %d 门 / 可记录 %d 门' % (len(recorded), len(candidates))), False


def _record_skill(ctx, p):
    sid = _key(ctx.param('skill_id') or ctx.param('skillId'))
    if not _skill_exists(sid):
        return ctx.fail('没有这门武学', '★ 记录失败：%s 不在她 skill.lua' % sid), False
    if sid in p['recorded']:
        return ctx.fail('%s 武学已记录到先贤书案中' % _skill_name(sid),
                        '★ 记录失败：%s 已记录' % sid, errcode=2), False
    p['recorded'].append(sid)
    ctx.log('[inherit_skin] 记录武学 %s（%s）' % (sid, _skill_name(sid)))
    return ctx.ok({'skill_id': sid,
                   'record': {'currency_cost': SKILL_COST,
                              'currency_type': RECORD_CURRENCY}},
                  '★ 记录武学《%s》' % _skill_name(sid)), True


def _learn_skill(ctx, p):
    sid = _key(ctx.param('skill_id') or ctx.param('skillId'))
    if not _skill_exists(sid):
        return ctx.fail('没有这门武学', '★ 学习失败：%s 不在她 skill.lua' % sid), False
    if sid not in p['recorded']:
        return ctx.fail('该武学尚未记录到先贤书案', '★ 学习失败：%s 未记录' % sid, errcode=2), False
    if sid not in p['learned']:
        p['learned'].append(sid)
    ctx.log('[inherit_skin] 从书案学会 %s（%s）' % (sid, _skill_name(sid)))
    return ctx.ok({'skill_id': sid,
                   'learn': {'currency_cost': SKILL_COST,
                             'currency_type': LEARN_CURRENCY}},
                  '★ 学会武学《%s》' % _skill_name(sid)), True


# ---------------------------------------------------------------------------
# 继承 / 转生 / 学艺
# ---------------------------------------------------------------------------
def _create_next_role_task(ctx, p):
    """`HttpManager:CreateHeir(heirName)` —— 上行 `{name}`，回调读 `data.userid`/`data.name`。"""
    name = str(ctx.param('name') or '').strip()
    if not name:
        return ctx.fail('名字不能为空', '★ 取继承人名字失败：空名字'), False
    old = p.get('heir')
    if isinstance(old, dict) and _key(old.get('name')) == name and old.get('userid'):
        # 重名：她那边 errcode==3 也照样读 data.userid + data.name 继续走流程
        return ctx.ok({'userid': _key(old.get('userid')), 'name': name},
                      '★ 名字已存在，复用继承人 %s' % old.get('userid')), False
    heir_uid = 'heir_%s_%d' % (_uid(ctx), int(time.time()))
    p['heir'] = {'userid': heir_uid, 'name': name, 'createdAt': int(time.time())}
    ctx.log('[inherit_skin] 继承人取名为《%s》，userid=%s' % (name, heir_uid))
    return ctx.ok({'userid': heir_uid, 'name': name}, '★ 继承人取名《%s》' % name), True


def _finish_next_role_task(ctx, p):
    """`HttpManager:inherit(...)` —— 回调只认 errcode：0 成功 / 6 已经传承过了 / 其它 PopText。"""
    # ★ 2026-10-03 老板要求：取消"只能传承 5 次"的上限（客户端 Role_Inherit:canInherit /
    #   Inherit:insertInheritHistory 的同款拦截已一并放开），只保留等级门槛。
    # if int(_num(p.get('inheritCount'), 0)) >= 5:
    #     return ctx.fail('已经传承五次，无法继续传承', '★ 传承失败：已满 5 次', errcode=6), False
    role_data = ctx.param('roleData')
    data_ver = ctx.param('dataVer')
    cur_ver = ctx.param('currencyVersion')
    p['nextRole'] = {
        'roleData': role_data,
        'dataVer': data_ver,
        'currencyVersion': cur_ver,
        'at': int(time.time()),
    }
    p['inheritCount'] = int(_num(p.get('inheritCount'), 0)) + 1
    p['heir'] = None
    ctx.log('[inherit_skin] 传承成功：第 %d 次（dataVer=%s currencyVersion=%s roleData=%s）'
            % (p['inheritCount'], data_ver, cur_ver,
               'yes' if isinstance(role_data, (dict, list)) else 'no'))
    return ctx.ok({'inheritCount': p['inheritCount'], 'userid': _uid(ctx)},
                  '★ 传承成功（第 %d 次）' % p['inheritCount']), True


def _get_chuanchen_user_info(ctx, p):
    """`getInheritHistoryRoleAttr(data)` —— `Inherit.lua:177` 上行是**字符串数组**，
    回调读 `data[1].zhengqi`(数字) 与 `data[1].xingzhen.effectsCount.<id>`(数字)。

    她问的是「历代传承角色」的属性 ⇒ 从玩家真实存档的 `inheritHistory` 取**最后一位**前辈：
      * 没有前辈（`inheritHistory` 为空）→ 回 `[]`，她 `MapIsEmpty(data)` 直接 return（合法"没数据"）；
      * 有前辈 → 回 `[{zhengqi, xingzhen:{effectsCount:{...}}}]`。
    ★ `effectsCount` 里的 effectId 必须能在她 `others/zouxuejing.lua` 的 `effect` 里查到，
      否则她 `effectData.value` 会 index nil（`Inherit.lua:208-217`）。
    """
    want = ctx.body_obj if isinstance(ctx.body_obj, list) else []
    if isinstance(ctx.body_obj, dict) and isinstance(ctx.body_obj.get('_value'), list):
        want = ctx.body_obj['_value']
    want = [_key(w) for w in want] or ['zhengqi', 'xingzhen']

    rs = _role_state(ctx)
    hist = rs.get('inheritHistory')
    if not isinstance(hist, list) or not hist:
        return ctx.ok([], '★ 历代传承角色属性：还没有前辈（回空列表）'), False

    last = hist[-1] if isinstance(hist[-1], dict) else {}
    xingzhen = _res('xingzhen', {})
    effects = {}
    xz = last.get('xingzhen')
    if isinstance(xz, dict):
        ec = xz.get('effectsCount')
        if isinstance(ec, dict):
            for k, v in ec.items():
                if _key(k) in xingzhen:                  # 只给查得到的，防她 index nil
                    effects[_key(k)] = _num(v, 0)
        elif isinstance(ec, list):
            for item in ec:
                if isinstance(item, dict) and _key(item.get('id')) in xingzhen:
                    effects[_key(item.get('id'))] = _num(item.get('count'), 0)
    zhengqi = _num(last.get('zhengqi'), _num(rs.get('zhengqi'), 0))

    row = {}
    for w in want:
        if w == 'zhengqi':
            row['zhengqi'] = zhengqi
        elif w == 'xingzhen':
            row['xingzhen'] = {'effectsCount': effects}
        else:
            # 她要什么就给什么，值从她的存档里原样取（取不到给 0，绝不给 nil）
            row[w] = last.get(w, 0)
    return ctx.ok([row], '★ 历代传承角色属性（%s）' % ','.join(want)), False


def _other_skill_pool(ctx, p):
    """可请教的武学：前辈遗产里真实存在的那些（`parentSkills` 对应的她 `skill.lua` 条目）。"""
    rs = _role_state(ctx)
    hist = rs.get('inheritHistory')
    pool, seen = [], set()
    if isinstance(hist, list) and hist:
        last = hist[-1] if isinstance(hist[-1], dict) else {}
        for it in (last.get('parentSkills') or []):
            if isinstance(it, dict):
                sid = _key(it.get('id'))
                if sid and sid not in seen and _skill_exists(sid):
                    seen.add(sid)
                    pool.append({'id': sid, 'exp': _num(it.get('exp'), 0)})
    if not pool:
        # 没有遗产记录时退回"玩家自己学过、且不是门派武学"的那批（她
        # `Inherit:insertInheritHistory` 也是这么往 `parentSkills` 里塞的）
        skills = rs.get('skills') if isinstance(rs.get('skills'), dict) else {}
        for sid in skills:
            if _is_jianghu_skill(sid) and _key(sid) not in seen:
                seen.add(_key(sid))
                rec = skills[sid] if isinstance(skills.get(sid), dict) else {}
                pool.append({'id': _key(sid), 'exp': _num(rec.get('exp'), 0)})
    return pool


def _get_other_skills(ctx, p):
    """`getOtherSkills(inheritIndex)` —— 回调读 `data.userid`(字符串) + `data.list`(表: id→经验)。"""
    idx = int(_num(ctx.param('inheritIndex') or (ctx.args[0] if ctx.args else 1), 1)) or 1
    rs = _role_state(ctx)
    hist = rs.get('inheritHistory')
    parent_uid = _uid(ctx)
    if isinstance(hist, list) and 1 <= idx <= len(hist):
        rec = hist[idx - 1] if isinstance(hist[idx - 1], dict) else {}
        parent_uid = _key(rec.get('userid')) or parent_uid
    lst = {}
    for it in _other_skill_pool(ctx, p):
        lst[_key(it['id'])] = _num(it['exp'], 0)
    # ★ `data.list` 必须是表（她 `pairs`），`data.userid` 必须是字符串
    return ctx.ok({'userid': parent_uid, 'list': lst, 'inheritIndex': idx},
                  '★ 前辈可请教的武学 %d 门（前辈 userid=%s）' % (len(lst), parent_uid)), False


def _study_other_skill(ctx, p):
    """`studyOtherSkill(userid, skillid)` —— 上行 `{userid, skill}`；回调只认 errcode。"""
    sid = _key(ctx.param('skill') or ctx.param('skill_id') or ctx.param('skillId'))
    if not _skill_exists(sid):
        return ctx.fail('前辈没有这门武学', '★ 请教失败：%s 不在她 skill.lua' % sid), False
    pool = {_key(x['id']) for x in _other_skill_pool(ctx, p)}
    if pool and sid not in pool:
        return ctx.fail('前辈没有这门武学', '★ 请教失败：前辈遗产里没有 %s' % sid, errcode=2), False
    if sid not in p['studied']:
        p['studied'].append(sid)
    ctx.log('[inherit_skin] 向 %s 请教《%s》' % (ctx.param('userid'), _skill_name(sid)))
    return ctx.ok({'skill': sid, 'userid': _key(ctx.param('userid'))},
                  '★ 向前辈请教《%s》' % _skill_name(sid)), True


# ---------------------------------------------------------------------------
# 地宫古迹任务（task22）
# ---------------------------------------------------------------------------
def _new_task(ctx, p):
    """她 `__getLocalRoleTaskInfo` 的默认值 + `TestLayer:3354` 里的真实字段。"""
    now = int(time.time())
    return {
        'task_id': TASK_ID,
        'state': TASK_STATE_IDLE,
        'start_time': now,
        'finish_time': 0,
        'end_time': 0,
        'dcount': 0,
        'zcount': 0,
        'gujiPoint': 0,
        'roleLv': int(_num(ctx.param('roleLv'), 0)),
        'luck': _num(ctx.param('luck'), 0),
        'kongfu': _num(ctx.param('kongfu'), 0),
        'exp': _num(ctx.param('exp'), 0),
        'rewardTime': 0,
    }


def _task_payload(t):
    """★ 她 `__updateTaskInfo` 逐字段读这些（含 `extra.*`），一个都不能少。"""
    return {
        'task_id': TASK_ID,
        'state': int(_num(t.get('state'), TASK_STATE_IDLE)),
        'start_time': int(_num(t.get('start_time'), 0)),
        'finish_time': int(_num(t.get('finish_time'), 0)),
        'end_time': int(_num(t.get('end_time'), 0)),
        'dcount': int(_num(t.get('dcount'), 0)),
        'zcount': int(_num(t.get('zcount'), 0)),
        'extra': {
            'gujiPoint': _num(t.get('gujiPoint'), 0),
            'roleLv': int(_num(t.get('roleLv'), 0)),
            'luck': _num(t.get('luck'), 0),
            'kongfu': _num(t.get('kongfu'), 0),
            'exp': _num(t.get('exp'), 0),
        },
    }


def _apply_extra(t, ctx):
    """把上行 `extra` 里的角色快照写进任务（她 `acceptTask` 上行 `{roleLv,luck,kongfu,exp}`）。"""
    ex = ctx.param('extra')
    if isinstance(ex, dict):
        for k in ('roleLv', 'luck', 'kongfu', 'exp', 'gujiPoint'):
            if ex.get(k) is not None:
                t[k] = _num(ex.get(k), t.get(k))
    else:
        for k in ('roleLv', 'luck', 'kongfu', 'exp'):
            v = ctx.param(k)
            if v is not None:
                t[k] = _num(v, t.get(k))


def _accept_task(ctx, p):
    t = p.get('task') or _new_task(ctx, p)
    _apply_extra(t, ctx)
    state = int(_num(t.get('state'), TASK_STATE_IDLE))
    if state == TASK_STATE_COMPLETE:
        p['task'] = t
        return ctx.fail('任务已完成，无法接取。', '★ 接取失败：本周已完成', errcode=1), True
    if state == TASK_STATE_ACCEPT:
        p['task'] = t
        return ctx.fail('已经接取过该任务，无需重复接取。', '★ 接取失败：已接取', errcode=2), True
    t['state'] = TASK_STATE_ACCEPT
    t['start_time'] = int(time.time())
    t['finish_time'] = 0
    t['end_time'] = 0
    p['task'] = t
    ctx.log('[inherit_skin] 接取地宫古迹任务 task22')
    return ctx.ok(_task_payload(t), '★ 接取地宫古迹任务'), True


def _finish_task(ctx, p):
    """`finishTask(task_id, extra)` —— `SelfCreatedSkillModule.lua:127` 上行 `{gujiPoint=N}`。
    她那边 errcode 语义：0 成功 / 2 未接取 / 3 已提交。"""
    t = p.get('task')
    if not isinstance(t, dict):
        return ctx.fail('任务未接取，无法完成', '★ 完成失败：没有任务记录', errcode=2), False
    state = int(_num(t.get('state'), TASK_STATE_IDLE))
    if state in (TASK_STATE_TO_SUBMIT, TASK_STATE_COMPLETE):
        return ctx.fail('任务已提交，无法完成', '★ 完成失败：已提交/待提交', errcode=3), False
    if state != TASK_STATE_ACCEPT:
        return ctx.fail('任务未接取，无法完成', '★ 完成失败：状态 %d' % state, errcode=2), False

    point = 0
    ex = ctx.param('extra')
    if isinstance(ex, dict):
        point = _num(ex.get('gujiPoint'), 0)
    if not point:
        point = _num(ctx.param('gujiPoint'), 0)
    t['gujiPoint'] = _num(t.get('gujiPoint'), 0) + point
    t['finish_time'] = int(time.time())
    t['dcount'] = int(_num(t.get('dcount'), 0)) + 1
    if _num(t['gujiPoint'], 0) >= GUJI_FINISH:
        t['state'] = TASK_STATE_TO_SUBMIT
    p['task'] = t
    ctx.log('[inherit_skin] 地宫古迹进度 %s/%d（本次 +%s）' % (t['gujiPoint'], GUJI_FINISH, point))
    return ctx.ok(_task_payload(t),
                  '★ 地宫古迹进度 %s/%s（+%s）' % (t['gujiPoint'], GUJI_FINISH, point)), True


def _reset_task(ctx, p):
    """`resetTask(task_id)` —— 进 fb220 前调；errcode 语义：0成功 / 1未接取 / 2无需重置 / 3本周已完成。"""
    t = p.get('task')
    if not isinstance(t, dict) or int(_num(t.get('state'), TASK_STATE_IDLE)) == TASK_STATE_IDLE:
        return ctx.fail('地宫古迹任务未接取，请先接取该任务。',
                        '★ 重置失败：未接取', errcode=1), False
    if int(_num(t.get('state'), TASK_STATE_IDLE)) == TASK_STATE_COMPLETE:
        return ctx.fail('地宫任务本周已完成，请下周再来。',
                        '★ 重置失败：本周已完成', errcode=3), False
    t['gujiPoint'] = 0
    t['start_time'] = int(time.time())
    t['finish_time'] = 0
    t['end_time'] = 0
    t['state'] = TASK_STATE_ACCEPT
    p['task'] = t
    ctx.log('[inherit_skin] 重置地宫古迹进度（重新进副本）')
    return ctx.ok(_task_payload(t), '★ 重置地宫古迹任务进度'), True


def _guji_reward():
    """提交奖励：**只给资源表里真实存在的东西**。

    * `server.selfCreatedItems`：她 fb220 里真实会掉的那件改良道具
      （`rlt_getitem02` → `glczwanquanchongzhi001`「复思之书」×1，id 在她 propMap 里）。
      过滤掉 propMap 里查不到的 id —— 她那边 `getPropMap(itemId).name` 会 index nil。
    * `server.currency` / `client.attrs`：原版的服务器奖励配置不在客户端里 ⇒ **回空字典**，
      她 `MapIsEmpty(...)` 判空跳过，不崩、也不凭空造数值。
    """
    items = {}
    if isinstance(_prop_record(GUJI_PROP_ID), dict):
        items[GUJI_PROP_ID] = 1
    return {
        'client': {'attrs': {}},
        'server': {'currency': {}, 'selfCreatedItems': items},
    }


def _submit_task(ctx, p):
    """`submitTask(task_id)` —— 回调读 `data.task` + `data.reward.{client.attrs,server.*}`。
    errcode 语义：0 成功 / 1 已提交 / 2 未接取 / 3 尚未完成 / 5 超过提交时间。"""
    t = p.get('task')
    if not isinstance(t, dict):
        return ctx.fail('提交失败，任务未接取。', '★ 提交失败：没有任务记录', errcode=2), False
    state = int(_num(t.get('state'), TASK_STATE_IDLE))
    if state == TASK_STATE_COMPLETE:
        return ctx.fail('任务已提交，无需重复提交。', '★ 提交失败：已提交', errcode=1), False
    if state == TASK_STATE_IDLE:
        return ctx.fail('提交失败，任务未接取。', '★ 提交失败：未接取', errcode=2), False
    if state != TASK_STATE_TO_SUBMIT:
        return ctx.fail('提交失败，任务尚未完成。',
                        '★ 提交失败：状态 %d 未完成' % state, errcode=3), False

    reward = _guji_reward()
    for pid, cnt in reward['server']['selfCreatedItems'].items():
        p['props'][_key(pid)] = int(_num(p['props'].get(_key(pid)), 0)) + int(_num(cnt, 0))
    t['state'] = TASK_STATE_COMPLETE
    t['zcount'] = int(_num(t.get('zcount'), 0)) + 1
    t['end_time'] = int(time.time())
    t['rewardTime'] = int(time.time())
    p['task'] = t
    ctx.log('[inherit_skin] 提交地宫古迹任务，发放 %s' % (reward['server']['selfCreatedItems'],))
    return ctx.ok({'task': _task_payload(t), 'reward': reward}, '★ 提交地宫古迹任务'), True


def _get_task_info(ctx, p):
    t = p.get('task')
    if not isinstance(t, dict):
        t = _new_task(ctx, p)
        p['task'] = t
        return ctx.ok(_task_payload(t), '★ 地宫古迹任务信息（首次，状态 %d）'
                      % TASK_STATE_IDLE), True
    return ctx.ok(_task_payload(t), '★ 地宫古迹任务信息（状态 %d）'
                  % int(_num(t.get('state'), TASK_STATE_IDLE))), False


# ---------------------------------------------------------------------------
# 路由
# ---------------------------------------------------------------------------
# 处理器统一返回 `((应答, 说明), 是否需要落盘)` 的二元组，`handle` 负责写盘。
_HANDLERS = {
    'createNextRoleTask': _create_next_role_task,
    'finishNextRoleTask': _finish_next_role_task,
    'get_chuanchen_user_info': _get_chuanchen_user_info,
    'get_other_skills': _get_other_skills,
    'study_other_skill': _study_other_skill,
    'buy_ui_theme': _buy_ui_theme,
    'use_ui_theme': _use_ui_theme,
    'get_attribute_times': _get_attribute_times,
    'remove_attribute_point': _remove_attribute_point,
    'get_propList': _prop_list,
    'use_create_prop': _use_create_prop,
    'use_improve_prop': _use_improve_prop,
    'get_record_skills': _get_record_skills,
    'learn_skill': _learn_skill,
    'record_skill': _record_skill,
    'accept_task': _accept_task,
    'finish_task': _finish_task,
    'get_task_info': _get_task_info,
    'reset_task': _reset_task,
    'submit_task': _submit_task,
}


def handle(ctx):
    ep = ctx.endpoint
    fn = _HANDLERS.get(ep)
    if fn is None:
        return None                                     # 不是我的接口
    try:
        st = _load(ctx)
        p = _me(ctx, st)
        reply, dirty = fn(ctx, p)
        if dirty:
            ctx.save_json(STATE, st)
        return reply
    except Exception as e:                              # noqa: BLE001
        ctx.log('[inherit_skin] %s 异常：%s\n%s' % (ep, e, traceback.format_exc()))
        # 读接口给"空但类型正确"的兜底，避免她回调里 index/拼接 nil 直接卡死 UI
        if ep == 'get_chuanchen_user_info':
            return ctx.ok([], '★ 历代传承角色属性兜底（内部异常）')
        if ep == 'get_other_skills':
            return ctx.ok({'userid': _uid(ctx), 'list': {}},
                          '★ 前辈武学兜底（内部异常）')
        if ep == 'get_propList':
            return ctx.ok([], '★ 道具列表兜底（内部异常）')
        if ep == 'get_record_skills':
            return ctx.ok({'record_skills': [], 'dream_skills': [],
                           'record': {'currency_cost': SKILL_COST,
                                      'currency_type': RECORD_CURRENCY},
                           'learn': {'currency_cost': SKILL_COST,
                                     'currency_type': LEARN_CURRENCY}},
                          '★ 先贤书案兜底（内部异常）')
        if ep in ('get_attribute_times', 'remove_attribute_point'):
            return ctx.ok({'count': _wash_limit(), 'cooltime': WASH_COOLTIME,
                           'num': 0, 'remove': WASH_PRICE},
                          '★ 洗点信息兜底（内部异常）')
        if ep == 'buy_ui_theme':
            return ctx.ok({'remove': 0, 'uiId': ''}, '★ 购买皮肤兜底（内部异常）')
        if ep == 'use_ui_theme':
            return ctx.ok({'uiId': ''}, '★ 使用皮肤兜底（内部异常）')
        if ep in ('accept_task', 'finish_task', 'get_task_info', 'reset_task'):
            now = int(time.time())
            return ctx.ok({
                'task_id': TASK_ID, 'state': TASK_STATE_IDLE,
                'start_time': now, 'finish_time': 0, 'end_time': 0,
                'dcount': 0, 'zcount': 0,
                'extra': {'gujiPoint': 0, 'roleLv': 0, 'luck': 0, 'kongfu': 0, 'exp': 0},
            }, '★ 地宫古迹任务兜底（内部异常）')
        if ep == 'submit_task':
            now = int(time.time())
            return ctx.ok({
                'task': {'task_id': TASK_ID, 'state': TASK_STATE_IDLE,
                         'start_time': now, 'finish_time': 0, 'end_time': 0,
                         'dcount': 0, 'zcount': 0,
                         'extra': {'gujiPoint': 0, 'roleLv': 0, 'luck': 0,
                                   'kongfu': 0, 'exp': 0}},
                'reward': {'client': {'attrs': {}},
                           'server': {'currency': {}, 'selfCreatedItems': {}}},
            }, '★ 提交任务兜底（内部异常）')
        return ctx.fail('服务器内部错误：%s' % e, '★ %s 异常' % ep)
