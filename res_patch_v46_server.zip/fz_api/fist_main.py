# -*- coding: utf-8 -*-
# ================= 离线包路径根（fz_make_offline_bundle.py 自动注入） =================
# 手机上整个服务端就是一个目录，表在哪、状态写哪，全部相对包根算。
# （有的模块原来把绝对路径写死，本身没 import os —— 这里一并补上）
import os
import os as _osp


def _off_find_bundle(_f):
    """从模块所在目录往上找包根（认 fz_boot_server.py）。
    ★ fz_api/*.py 的 __file__ 在 <根>/fz_api/ 下，直接 dirname 会算错一层。"""
    _d = _osp.path.dirname(_osp.path.abspath(_f))
    for _ in range(6):
        if _osp.path.exists(_osp.path.join(_d, 'fz_boot_server.py')):
            return _d
        _u = _osp.path.dirname(_d)
        if _u == _d:
            break
        _d = _u
    return _osp.path.dirname(_osp.path.abspath(_f))


_OFF_BUNDLE = _off_find_bundle(__file__)
_OFF_FZ_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_fz')
_OFF_INK_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_ink')
_OFF_WORK_ROOT = _OFF_BUNDLE
# =====================================================================================
# ★ 2026-10-04 商城空货架修复：客户端资源表解析——PC 开发树优先，设备上自动回退
#   到包内 client_fz 副本（jhserver/client_fz = fangzhi_lua_dec 的同步拷贝）。
def _fz_res(*parts):
    base = os.path.join(_OFF_FZ_ROOT, 'res', 'script')
    if not os.path.isdir(base):
        base = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            '..', 'client_fz', 'res', 'script')
    return os.path.join(base, *parts)

# -*- coding: utf-8 -*-
"""拳脚（FistFoot）主系统 —— **12 个接口** 的 1:1 还原实现。

===========================================================================
本模块接管了哪些接口 / 原先由 `fz_boot_server.py` 的浅分支兜底
===========================================================================
`fz_boot_server.py:1915-1928` 里那段 `if 'fist' in path:` 会把**所有**带 fist 的
请求一律回一份「accpoint/reflectExp/feelPoint/characterPoint 全 0、guajiInfo 空、
branchInfo 五个分支全空」的**死数据**。UI 能画出来，但**任何操作都不推进**
（修行完不成、分支阅历永远 0）。

本模块（`fz_api/fist_main.py`）通过 `fz_api/__init__.py` 的
`ENDPOINTS` 路由**接管**下面这 12 个真实接口（模块优先于 boot 浅分支，
所以 boot 那段 `if 'fist' in path` 对这 12 个端点不再生效、
仍然只给 `get_fistFootShop_*` 之类没被模块认领的 fist 路径兜底）：

    createFistInfo            → create_fist_info
    getFistFootInFo           → get_fist_info
    getFistTasks              → get_fist_tasks
    startFistTask             → start_fist_task
    stopFistTask              → stop_fist_task
    finishFistTask            → finish_fist_task
    speedUpFistTask           → expedite_fist_task
    updataFistFlag            → updata_fist_flag
    get_fist_tasks            （同上，下划线原样注册）
    start_fist_task           （同上）
    stop_fist_task            （同上）
    finish_fist_task          （同上）
    expedite_fist_task        （同上）
    reset_fist_technique      → reset_fist_technique（客户端函数名 resetTalentPage）

**没有接管**（故意不动）：`get_fistFootShop_info` / `buy_fistFootShop_dailyGoods`
/ `buy_fistFootShop_specialOffer` / `set_fistFootShop_dailyCost` ——
那 4 个由 `fz_api/activities.py:777+` 实现。
另外 `upgrade_technique` / `grasp_technique_feature` / `replace_technique_feature`
/ `get_talent_info` / `switch_talent_page` / `get_characterPool_info`
由 `fz_api/fist_liangong.py` 实现（那 6 个不在本模块清单里，不能抢）。

===========================================================================
一、接口 URL 与上行参数（逐个读客户端代码确认，不是猜的）
===========================================================================
客户端模型层 `app/models/FistFootSystem/FistFootSystem.lua`（Lua 方法名）
→ `app/models/ServerAction/ServerActionSystem.lua`（`ServerActionSystem:xxx`）
→ `app/extends/Http/HttpManager.lua`（URL + 上行 JSON）三层。URL 都在
`HttpManager.lua`：

| Lua 方法 | URL（DOMAIN 之后） | 上行 | HttpManager.lua |
|---|---|---|---|
| `createFistInfo`     | `create_fist_info`        | `{dataVer, codeVer}` | :4911-4914 |
| `getFistFootInFo`    | **`get_fist_info`**       | `{dataVer, codeVer}` | :4919-4922 |
| `startFistTask`      | `start_fist_task`         | `{taskId, dataVer, codeVer}` | :4928-4931 |
| `stopFistTask`       | `stop_fist_task`          | `{taskId, dataVer, codeVer}` | :4933-4936 |
| `finishFistTask`     | `finish_fist_task`        | `{taskId, bagEnough, dataVer, codeVer}` | :4938-4941 |
| `speedUpFistTask`    | **`expedite_fist_task`**  | `{taskId, cost, dataVer, codeVer}` | :4943-4946 |
| `updataFistFlag`     | **`updata_fist_flag`**    | `{addFlags, deleteFlags, dataVer, codeVer}` | :4978-4981 |
| `getFistTasks`       | `get_fist_tasks`          | `{dataVer, codeVer}` | :4983-4986 |
| `resetTalentPage`    | **`reset_fist_technique`**| `{techniquePageId, dataVer, codeVer}` | :4963-4966 |

★ 注意三个**函数名与 URL 不一致**的（这是最容易踩的坑）：
  `getFistFootInFo`→`get_fist_info`、`speedUpFistTask`→`expedite_fist_task`、
  `resetTalentPage`→`reset_fist_technique`。
★ 任务类 4 个接口的 URL 本身就是下划线（`start_fist_task` 等），
  所以 `ENDPOINTS` 里驼峰名与下划线名**都注册**（驼峰名是任务书里给的清单，
  下划线名才是真客户端实际发的）。

**每个应答的 `data.dataVer` 必须是数字**：`ServerActionSystem.lua:463/480/506/529/
554/579/769` 全是 `self:__saveAction(data.dataVer, ...)`，而 `__saveAction` 会
`setDataVersion()`，拿到非数字直接 `error()` 打断协程 ⇒ 界面卡死。
本模块所有回包都走 `ctx.ok()`，它会自动补数字 `dataVer`。

===========================================================================
二、下行字段契约（客户端真读的字段 + 出处）
===========================================================================
`FistFootSystem:initData`（`FistFootSystem.lua:142-156`）**逐字段**读：
    data.accpoint      → :147 `setAccpoint`
    data.guajiInfo     → :149 `setGuaJiInfo`
    data.reflectExp    → :151 `setReflectExp`
    data.branchInfo    → :153 → `__initTelentPageData`
    data.feelPoint     → :161 `setFeelPoint`（在 `__initTelentPageData` 里）
    data.characterPoint→ :155 `setCharacterPoint`
`__initBranchInfo`（:164-181）对 `branchInfo` 的**每一项**读：
    v.exp / v.costTechnique / v.techniqueList / v.characterInUse / v.characterUnused
    （`characterInUse`/`characterUnused` 走 `MapIsEmpty`，给 `{}` 或 `[]` 都行）
`branchInfo[type].techniqueList` 的**元素**（`FistFootSystem.lua:186-190` +
`PlayerFistFootTechnique:serialization` `PlayerFistFootTechnique.lua:139-153`）：
    `{id=, lv=, branchId=}`（`id`/`branchId` 取 `techniqueLevel.skillid` / `.type`）
`characterInUse` / `characterUnused` 的元素（`PlayerFistFootTechnique.lua:110-137`）：
    `{techniqueId=, characterId=}`
★ `characterInUse` 里给的 `characterId` **必须**能让客户端
  `FistFootResManager:getCharacterData(id, 技巧当前等级)` 查得到
  （否则 `assert` 抛错）；本模块只回它自己写过的、已经过同一校验的值。

`guajiInfo`（挂机对象，`FistFootSystem.lua:596-621` / `FistFootGuaJiPresenter.lua:28-30,
116-120`）：非空表示"正在修行中"，读
    `guajiInfo.taskId` / `guajiInfo.startTime` / `guajiInfo.speedUpTime`
    （结束时间 = `startTime + task.time*3600 - speedUpTime`）。
★ 空表 `{}` 表示**没有在修行**（`isGuaJi() = not MapIsEmpty(...)`），
  绝不能用 `{taskId=..., startTime=0, speedUpTime=0}` 表示"没在挂机"。

| 接口 | 客户端读的 `data.*` | 出处 |
|---|---|---|
| `create_fist_info` | （`FistFootSystem.lua:113` 只要求 `not MapIsEmpty(data)`；然后 `initData` 全量读） | :108-123 |
| `get_fist_info`    | 同 `create_fist_info`（`errcode==2` = 拳脚系统未开启） | `ServerActionSystem.lua:473-490` |
| `start_fist_task`  | **`startTime`**（unix 秒） | `FistFootSystem.lua:629-638` |
| `stop_fist_task`   | 不读字段（只看 `ok`） | `FistFootSystem.lua:653-667` |
| `finish_fist_task` | **`reward`**（数组，元素格式 = 任务表 `awards` 的 `{type, arg2, arg3}`）、**`feelPoint`**、可选 `msg` | `FistFootSystem.lua:700-721` + `FistFootGuaJiPresenter.lua:164-200` |
| `expedite_fist_task` | **`cost`**、**`speedUpTime`** | `FistFootSystem.lua:675-692` |
| `updata_fist_flag` | 不读字段 | `FistFootSystem.lua:955-968` |
| `get_fist_tasks`   | **`list`**（数组，元素 `{taskId, state, cdTime?}`） | `FistFootMenuPresenter.lua:99-112` → `FistFootTaskPresenter.lua:31-33,79-154` |
| `reset_fist_technique` | **`resetCount`**、`feelPoint`、**`branchInfo`** | `TalentPagePresenter.lua:226-241` + `FistFootSystem.lua:875-904` + `BasicTalentPage.lua:14-20` |

`get_fist_tasks` 的 `state` 取值来自 `FistFootConst.lua:15-19`
`TaskStateType = {Lock=0, Unlock=1, Cd=2}`；`FistFootTaskPresenter.lua:101/105/113`
三分支分别读 `task.opentext` / `task.name`+`awardtext`+`time` / `cdTime`。
⇒ `state` **必须是数字 0/1/2**，且 `Cd` 时 `cdTime` 必须是**数字秒**。

`finish_fist_task` 的 `reward` 元素语义（`FistFootConst.lua:29-34` +
`FistFootSystem.lua:729-750`）：
    `[1, branchId, exp]`=分支阅历、`[2, exp]`=潜思经验、
    `[3, itemId, n]`=道具（`bagEnough==1` 时客户端本地 `addItemCount`）、
    `[4, "accpoint"|"characterPoint", n]`=服务器资源。
★ `FistFootGuaJiPresenter.lua:168-186` 会 `ipairs(data.reward)` 并对**每个元素**
  `v[1]/v[2]/v[3]` 取下标 ⇒ `reward` 必须是**数组**（给 `[]` 也比给 `{}` 安全）。

===========================================================================
三、状态与真记账（state = `fist_main_state.json`）
===========================================================================
`_load` / `_save` 沿用 `fist_liangong.py` 的写法。落盘内容：
    unlocked        None=没创建过（`get_fist_info` 回 errcode=2）/ True=已开启
    accpoint        固身元气（加速资源）
    reflectExp      潜思经验（`finish_fist_task` 的 `[2, exp]` 真加）
    feelPoint       感悟点数
    characterPoint  特性见解（`[4,"characterPoint",n]` 真加）
    branchExp       {"10010": 阅历}（`[1, branchId, exp]` 真加）
    costTechnique   分支已投入感悟点（给 `get_fist_info` 回读）
    techLv / charInUse / charUnused / pageReset / currPageIndex
                    **跨模块读**：这几个由 `fist_liangong.py` 记账并写它自己的
                    `fist_liangong_state.json`（`upgrade_technique` /
                    `grasp_technique_feature` 都写在那边）。本模块**只读不写**，
                    在 `fist_main_state.json` 里存 `mirror`（自己的副本）。
    tasks           {"taskId": {"finish":ts, "cdEnd":ts, "count":n}}
    guaji           {"taskId","startTime","speedUpTime"} 或 None
    flags           ["标记id"] —— 由 `updata_fist_flag` 写入（任务解锁标记）
    log             最近 120 条记账流水

**真记账的 4 处**：
  1) `finish_fist_task` —— 按 `tasks.lua` 的 `awards` 真加 branchExp / reflectExp /
     characterPoint，道具走 `items_currency.grant`（真发货）。
  2) `expedite_fist_task` —— 真扣 `accpoint`、真加 `speedUpTime`（1 点 = 3600 秒）。
  3) `updata_fist_flag` —— 真加/删标记，`get_fist_tasks` 的解锁判定真读它。
  4) `reset_fist_technique` —— 真写 `pageReset[页码]+1`、真清该页技巧/特性、
     真扣 `yuanbao`（真钱袋 `items_currency`，不够就 errcode=1 不假装成功）。

===========================================================================
四、数值全部来自她自己的配表（`C:\\apkwork\\fangzhi_lua_dec\\assets\\res\\script`）
===========================================================================
  * `fistFoot/tasks.lua["1"]` —— 146 条修行任务真表（`taskid / type / name /
    conblevel / contlevel / sign / opentext / awardtext / awards / time(小时) /
    incidentsid / starttime / endtime / cd / displaytype`）。
  * `fistFoot/branchLevel.lua["1"]` —— 5 分支 × 500 级，`{id, level, type, exp, damage}`，
    用来把 `branchExp` 换算成「锻境等级」（`FistFootSystem:getBranchLv` :518-528）。
  * `fistFoot/techniqueLevel.lua["1"]` —— 技巧 `{skillid, skilllv, type, jqdamage,
    skillcon, papool, resource}`，用来判技巧属于哪个分支。
  * `fistFoot/techniqueReset.lua["1"]` —— 回溯消耗 `{recall, type=1(元宝), count}`。
  * `fistFoot/fistFootConst.lua["data"]` —— `unlockFlag="fistsfeetmapwc"` /
    `unlockLevel=306` / `skillpageUL=10` / `characterfrequency=20`。
  * `fistFoot/baseLevel.lua["1"]` —— 潜思经验 → 潜思等级 `{basislv, exp}`。
  * `fistFoot/character.lua` / `characterPool.lua` —— 特性真表（校验 characterId）。
"""

import math
import os
import sys
import time

NAME = 'fist_main'
TITLE = '拳脚主系统（修行任务/挂机/加速/标记/分支与潜思阅历）'

# ★ 任务书给的 12 个名字 + 客户端实际发的下划线 URL，两套都注册（见文件头说明）
ENDPOINTS = [
    'createFistInfo',
    'getFistFootInFo',
    'getFistTasks',
    'startFistTask',
    'stopFistTask',
    'finishFistTask',
    'speedUpFistTask',
    'updataFistFlag',
    'updata_fist_flag',
    'get_fist_tasks',
    'create_fist_info',
    'get_fist_info',
    'start_fist_task',
    'stop_fist_task',
    'finish_fist_task',
    'expedite_fist_task',
    'reset_fist_technique',
]

STATE = 'fist_main_state.json'
# `fist_liangong.py` 的账本（技巧等级/特性/心得页码在那边记）——只读用来对齐
LIANGONG_STATE = 'fist_liangong_state.json'

KNOWN_UNCERTAIN = """\
1) `accpoint`（固身元气）与 `feelPoint`（感悟点数）**产出源查不到**：
   `tasks.lua` 全部 146 条的 `awards` 只有 4 种 —— `[1,branchId,exp]`(90 条)、
   `[2,exp]`(11 条,潜思经验)、`[3,itemId,n]`(36 条,剧情道具)、
   `[4,"characterPoint",n]`(7 条,特性见解)；**没有一条给 `accpoint` 或 `feelPoint`**。
   她表里也没有别的 fistFoot 产出表 ⇒ 本模块从 0 起，`expedite_fist_task` 在
   `accpoint` 不够时回 errcode=1 弹提示（不发明数值、不假装成功）。
   `costTechnique`（已投入感悟点）由 `fist_liangong.upgrade_technique` 记，
   本模块只回读镜像值。
2) `reflectExp`（潜思经验）的**等级换算**只用于校验/日志：`baseLevel.lua` 有
   `{basislv, exp}`，本模块不因此改变回包字段（客户端自己算等级）。
3) **`unlocked`（拳脚系统是否开启）只能由 `create_fist_info` 置真**：
   客户端 `isOpenSystem()`（`FistFootSystem.lua:233-238`）读的是
   `getInheritFlag("fistsfeetmapwc")==1 and lv>=306`，服务端**没有**对应字段
   （她的角色存档 `roles/full.json._inherit_flags` 里确实是 `"fistsfeetmapwc": 1`，
   但服务端不改她的存档）。所以只能用本模块自己的 `unlocked` 记账：
   没调过 `create_fist_info` 时 `get_fist_info` 回 `errcode=2`（客户端弹 errmsg，
   不 error 不卡界面，`ServerActionSystem.lua:481-482`）；调过之后一直回全量数据。
   ⇒ **已存在的存档不会被误判为"未开启"**：只要客户端走过一次前置任务
   （`CommonResults.lua:3836-3847` 的"完成拳脚系统前置任务"）就会建立状态。
4) **`conblevel` 只校验"分支 × 锻境等级"**（真表结构 = `{分支id, 需求锻境等级}`，
   例 `[10010, 110]`；`branchLevel.lua` 换算时取「`exp >= row.exp` 的最大 `level`」，
   和客户端 `FistFootSystem:getBranchLv` :518-528 一致）：分支阅历换算出的
   锻境等级 **< 需求** ⇒ `state=Lock(0)`（`FistFootTaskPresenter.lua:101-104`
   走 `opentext` 灰字分支，安全）。
   ★ **未确认**：`conblevel=[10010, 1]`（`tasks.lua:50201010101` 这种**没有任何
     `sign` 的入门锻体任务**）用"严格 `<`"判定时，一个新号（分支阅历 0 ⇒ 锻境等级 0）
     也进不去 ⇒ **`锻体` 页签初次打开只有"未解锁"**。但表里 1..5 型任务的最低 `conblevel`
     恰好都是 1、而 `branchLevel` 的最小 `level` 也是 1（`exp=1`），
     说明"等级 0 算不算达标"这个口径**表里查不到**（她客户端不校验这个，
     是服务端的事）。本模块按**字面严格 `<`** 处理（宁可锁着也不放行），
     要放宽就把 `_task_state` 里那行改成 `<= need`/`need - 1`。
     **不引入任何编造的初始阅历**：新号就是 0 阅历、5 个分支全 0。
   **`contlevel` 在 146 条里全是空表**，所以"技巧等级门槛"这一维度**无法校验**，
   一律按通过处理（同样是未确认，不是我们编的）。
5) **`sign`（任务解锁标记）**：90/146 条有 `sign`，由地图事件
   `CommonResults.lua:3848-3867`（"更新拳脚系统标记"）经 `updata_fist_flag` 下发。
   本模块真记账这串标记；`state` 的 Unlock 判定 = `sign` 为空 **或** 标记已在本模块账上。
   ⇒ **刚从官方存档搬过来的号，标记是她在客户端 `setInheritFlag` 里存的**，
   服务端读不到（不改她的存档）⇒ 这些任务首屏会是 Lock；走一次对应地图事件即解锁。
6) **`starttime`/`endtime` 过期判定**：146 条里 15 条 `endtime=2022`、13 条 `2002`、
   11 条 `2023`（都已过期），107 条 `2037`（有效）。过期的本模块一律
   `state=Lock(0)`（安全分支），**不猜**是否复刻服该延长。若复刻服要用它们，
   需另开"活动时间"表（不在本模块）。
7) **`cd`（冷却）**：146 条里 95 条是 `{1}` = `TaskCdType.None`（做完立即刷新），
   51 条是 `{3,1,3,0,0,0}` = `Fixed`（固定周/点刷新）。本模块只对
   **`Interval(2)`** 做真冷却记账（`cdEnd = 完成时间 + cd[2]`）；`None` 不加冷却；
   `Fixed` 因为"第 3 个参数是周几、第 4 个是 0 点"的口径在表里**没有任何一条
   `Interval` 样例可对照**，保守按"不加冷却"处理（未确认）。
8) **`accpoint`/`reflectExp` 的初始值**：`roles/full.json` 里**没有**这几个字段
   （只有 `_inherit_flags.fistsfeetmapwc`），所以不可能从存档读出来；
   一律从 0 起（等于她服务端那份账，不是我们编的）。
9) **`reset_fist_technique` 的"页 ↔ 分支/技巧"映射查不到**（这是本模块最不确定的一处）：
   客户端 `TalentPagePresenter:setResetCount(resetCount)`（:84-94）把 `resetCount`
   当 `techniqueReset.recall` 的**下标**去查"本次"消耗；
   `FistFootSystem:resetTalentPage`（:875-904）读 `data.feelPoint` + `data.branchInfo`；
   `BasicTalentPage.lua:14-20` 还要 `feelPoint` + `branchInfo`。
   但 `fistFootConst.skillpageUL=10`（页数上限 10）与
   `FistFootSystem.lua:19-83` 默认表的 **5 个分支**对不上，
   `FistFootResManager` 里也**没有**"页 → 技巧/分支"的表。
   ⇒ 本模块保守按「**一页 = 一个分支**」（第 1 页 10010 … 第 5 页 10050，6..10 页
     `%5` 复用）折算：只影响**回溯清空哪个分支的技巧**和**退多少感悟点**，
     不影响面板其它数值。要改口径只需改 `_tech_ids_of_page` / `_page_spent_feel`。
   "退回多少感悟点"她表里也没有专门字段，只有每级消耗 `techniqueLevel.skillcon`，
   本模块按"该分支技巧逐级 skillcon 求和"退回（**按表推算，不是抄来的字段**）。
   真账 `techLv` 在 `fist_liangong.py`，本模块**只读不改**，所以用
   `st['cleared'][页码].techIds` 在自己这边把清掉的技巧过滤出面板
   （`_cleared_ids`），保证"回溯后面板真的空了"。
10) **元宝消耗走真钱袋**：`items_currency.add_currency(ctx,'yuanbao',-count)`
    （`fist_liangong.py:556-577` 同样把 `yuanbao` 记在
    `homeland_state.json["currency"]`）。不够就 errcode=1，**不假装成功**。
    她客户端那边 `User:getRole():getCHAttrName("yuanbao")` 只是显示货币名，
    真正的元宝是服务端下发角色属性，所以这是唯一的账。
11) **技巧/特性数据是"镜像"**：`techLv`/`charInUse`/`charUnused`
    的真账在 `fist_liangong.py`（`upgrade_technique` /
    `grasp_technique_feature` / `replace_technique_feature` / `switch_talent_page`）。
    本模块 `get_fist_info` 把它的 `fist_liangong_state.json` 读进来做镜像，
    让面板的"技巧数量/谙技/已领悟特性"不空。**本模块绝不回写它**。
12) **`get_fist_tasks` 一次回全部 146 条**（客户端 `FistFootTaskPresenter:initTaskList`
    :163-185 自己按 `SkillClassifyManager` 三分法归类到"锻体/技巧/砺炼"三个页签），
    服务端不筛分支 —— 少回一条那个页签就少一行。
"""

# ---------------------------------------------------------------------------
# 她的资源表
# ---------------------------------------------------------------------------
RES_ROOT = _fz_res()
RES_TASKS = os.path.join(RES_ROOT, 'fistFoot', 'tasks.lua')
RES_BRANCH_LEVEL = os.path.join(RES_ROOT, 'fistFoot', 'branchLevel.lua')
RES_TECHNIQUE_LEVEL = os.path.join(RES_ROOT, 'fistFoot', 'techniqueLevel.lua')
RES_TECHNIQUE_RESET = os.path.join(RES_ROOT, 'fistFoot', 'techniqueReset.lua')
RES_BASE_LEVEL = os.path.join(RES_ROOT, 'fistFoot', 'baseLevel.lua')
RES_CHARACTER = os.path.join(RES_ROOT, 'fistFoot', 'character.lua')
RES_FIST_CONST = os.path.join(RES_ROOT, 'fistFoot', 'fistFootConst.lua')

ROLE_FULL = 'roles/full.json'

# 分支类型（`FistFootSystem.lua:19-83` 默认表 + `branchLevel.lua` 的 `type`）
BRANCHES = ('10010', '10020', '10030', '10040', '10050')

# 每点加速资源换多少"秒"的修行时间（`SpeedUpGuaJiPresenter.lua:80-87`：
#   cost*5 分钟 = cost*300 秒展示，但 `setSpeedTime` 用的是 cost*3600，
#   而 `FistFootSystem.lua:684` 把 `data.speedUpTime` 直接加进 `speedUpTime`，
#   `FistFootGuaJiPresenter.lua:117` 又是 `startTime + time*3600 - speedUpTime`
#   ⇒ 秒/点 = 3600。取 3600，并在 7) 里注明口径。）
SPEEDUP_SECONDS_PER_POINT = 3600
# 1 点加速资源最少要"真的"减掉多久（`SpeedUpGuaJiPresenter.lua:37-51`：5 分钟为一档）
SPEEDUP_MIN_UNIT_SECONDS = 300

_TABLES = {}




def _here():
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _lua_table(path):
    """用 `work/fz_luatable.py` 解析她的数据表；失败返回 {}（绝不抛）。"""
    if path in _TABLES:
        return _TABLES[path]
    val = {}
    try:
        try:
            import fz_luatable
        except ImportError:
            sys.path.insert(0, _here())
            import fz_luatable
        val = fz_luatable.load_lua_table(path) or {}
        if not isinstance(val, dict):
            val = {}
    except Exception:                          # noqa: BLE001
        val = {}
    _TABLES[path] = val
    return val


def _num(v, d=0):
    try:
        if v is None or v == '' or isinstance(v, bool):
            return d
        return int(float(v))
    except (TypeError, ValueError):
        return d


def _s(v):
    return '' if v is None else str(v)


def _now():
    return int(time.time())


def _uid(ctx):
    return str(ctx.headers.get('userid') or ctx.headers.get('uuid') or 'local')


# ---------------------------------------------------------------------------
# 读她的表
# ---------------------------------------------------------------------------
def _fist_conf(key, default=None):
    """`fistFootConst.lua["data"][key].content`。"""
    t = _lua_table(RES_FIST_CONST)
    row = (t.get('data') or {}).get(_s(key))
    if isinstance(row, dict) and 'content' in row:
        return row.get('content')
    return default


def _tasks():
    """`tasks.lua["1"]` → {taskId(str): row}（146 条真表）。"""
    t = _lua_table(RES_TASKS)
    raw = t.get('1') or {}
    out = {}
    for k, v in (raw or {}).items():
        if isinstance(v, dict):
            out[_s(v.get('taskid') or k)] = v
    return out


def _branch_rows():
    """`branchLevel.lua["1"]` → {type(str): {level(int): row}}。"""
    key = '__branch_rows__'
    if key in _TABLES:
        return _TABLES[key]
    t = _lua_table(RES_BRANCH_LEVEL)
    idx = {b: {} for b in BRANCHES}
    for v in (t.get('1') or {}).values():
        if not isinstance(v, dict):
            continue
        ty = _s(v.get('type'))
        lv = _num(v.get('level'))
        if ty and lv:
            idx.setdefault(ty, {})[lv] = v
    _TABLES[key] = idx
    return idx


def _branch_lv(branch, exp):
    """`FistFootSystem:getBranchLv`（:518-528）：取 exp >= row.exp 的最大 level。"""
    lv = 0
    for l, row in (_branch_rows().get(_s(branch)) or {}).items():
        if _num(exp) >= _num(row.get('exp')):
            lv = max(lv, _num(l))
    return lv


def _technique_rows():
    """`techniqueLevel.lua["1"]` → {skillid(str): {skilllv(int): row}}。"""
    key = '__tech_rows__'
    if key in _TABLES:
        return _TABLES[key]
    t = _lua_table(RES_TECHNIQUE_LEVEL)
    idx = {}
    for v in (t.get('1') or {}).values():
        if not isinstance(v, dict):
            continue
        sid = _s(v.get('skillid'))
        lv = _num(v.get('skilllv'))
        if sid and lv:
            idx.setdefault(sid, {})[lv] = v
    _TABLES[key] = idx
    return idx


def _tech_branch(skill_id):
    """技巧属于哪个拳脚分支（`techniqueLevel.type`）。取最低级那行最稳。"""
    grp = _technique_rows().get(_s(skill_id)) or {}
    if not grp:
        return ''
    return _s(grp[min(grp)].get('type'))


def _tech_resets():
    """`techniqueReset.lua["1"]` → {recall(int): row}。"""
    t = _lua_table(RES_TECHNIQUE_RESET)
    out = {}
    for v in (t.get('1') or {}).values():
        if isinstance(v, dict):
            out[_num(v.get('recall'))] = v
    return out


def _characters():
    """`character.lua["1"]` → {peculiarityid(str): {level(int): row}}。"""
    key = '__char_rows__'
    if key in _TABLES:
        return _TABLES[key]
    t = _lua_table(RES_CHARACTER)
    idx = {}
    for v in (t.get('1') or {}).values():
        if not isinstance(v, dict):
            continue
        pid = _s(v.get('peculiarityid'))
        lv = _num(v.get('level'))
        if pid and lv:
            idx.setdefault(pid, {})[lv] = v
    _TABLES[key] = idx
    return idx


def _char_ok(cid, lv):
    """该特性在该等级真有记录？（`FistFootResManager:getCharacterData` 会 assert）"""
    return _num(lv) in (_characters().get(_s(cid)) or {})


def _page_count():
    n = _num(_fist_conf('skillpageUL', 10), 10)
    return n if n > 0 else 10


# ---------------------------------------------------------------------------
# 状态
# ---------------------------------------------------------------------------
def _blank():
    return {
        'version': 0,
        'unlocked': None,          # None=没建过（get_fist_info 回 errcode=2）/ True
        'accpoint': 0,
        'reflectExp': 0,
        'feelPoint': 0,
        'characterPoint': 0,
        'branchExp': {},           # {"10010": 阅历}
        'costTechnique': {},       # {"10010": 已投入感悟点}（镜像）
        'mirror': {},              # fist_liangong 的技巧/特性快照（**只读**，不落盘）
        'cleared': {},             # {"页码": {"recall":n,"at":ts,"branch":id,
                                   #            "techIds":[...],"feel":n}}（回溯清空过）
        'tasks': {},               # {"taskId": {"finish":ts,"cdEnd":ts,"count":n}}
        'guaji': None,             # {"taskId","startTime","speedUpTime"}
        'flags': [],               # updata_fist_flag 记下的任务解锁标记
        'log': [],
    }


def _load(ctx):
    st = ctx.load_json(STATE, None)
    if not isinstance(st, dict):
        st = {}
    for k, v in _blank().items():
        if k not in st:
            st[k] = v
    for k in ('branchExp', 'costTechnique', 'tasks', 'cleared'):
        if not isinstance(st.get(k), dict):
            st[k] = {}
    if not isinstance(st.get('pageReset'), dict):
        st['pageReset'] = {}
    if not isinstance(st.get('flags'), list):
        st['flags'] = []
    if not isinstance(st.get('log'), list):
        st['log'] = []
    if not isinstance(st.get('mirror'), dict):
        st['mirror'] = {}
    g = st.get('guaji')
    if not isinstance(g, dict) or not _s(g.get('taskId')):
        st['guaji'] = None
    st['_mirror'] = _read_mirror(ctx)          # 不进盘，只在本次请求里用
    return st


def _save(ctx, st):
    st = dict(st)
    st.pop('_mirror', None)                    # 镜像只读，不落盘
    st['log'] = st.get('log', [])[-120:]
    st['userid'] = _uid(ctx)
    st['updated'] = _now()
    ctx.save_json(STATE, st)
    return st


def _mark(st, who, msg):
    st.setdefault('log', []).append('%d %s %s' % (_now(), who, msg))


def _bump(st):
    st['version'] = _num(st.get('version')) + 1
    return st['version']


def _read_mirror(ctx):
    """只读 `fist_liangong.py` 的账（技巧/特性/心得页在那边记）。"""
    try:
        d = ctx.load_json(LIANGONG_STATE, None)
    except Exception:                          # noqa: BLE001
        return {}
    if not isinstance(d, dict):
        return {}
    out = {}
    for k in ('techLv', 'charInUse', 'charUnused', 'pageReset',
              'feelPoint', 'characterPoint', 'currPageIndex'):
        if k in d and d[k] is not None:
            out[k] = d[k]
    return out


def _mirror(st, key, default):
    v = (st.get('_mirror') or {}).get(key)
    if v is None:
        return default
    return v


# ---------------------------------------------------------------------------
# 分支阅历 / 潜思经验
# ---------------------------------------------------------------------------
def _branch_exp_of(st, branch):
    return _num((st.get('branchExp') or {}).get(_s(branch)))


def _add_branch_exp(st, branch, exp):
    b = _s(branch)
    st.setdefault('branchExp', {})[b] = _branch_exp_of(st, b) + _num(exp)
    return st['branchExp'][b]


# ---------------------------------------------------------------------------
# 分支数据（`branchInfo` 的构造）
# ---------------------------------------------------------------------------
def _cleared_ids(st):
    """被 `reset_fist_technique` 清空过的技巧 id 集合（所有页加起来）。

    ★ 为什么要过滤：`techLv` 的真账在 `fist_liangong.py`，本模块**只读不改**它，
      所以"回溯把该页技巧清空"这件事只能在本模块自己的账上体现 ——
      否则 `get_fist_info` 会把刚被回溯掉的技巧又画回去（两边不一致）。
    """
    out = set()
    for rec in (st.get('cleared') or {}).values():
        if isinstance(rec, dict):
            for tid in (rec.get('techIds') or []):
                out.add(_s(tid))
    return out


def _technique_list_of(st, branch):
    """该分支的 `techniqueList`：`{技巧id: {id, lv, branchId}}`。

    技巧等级真账在 `fist_liangong.py` 的 `techLv`（`upgrade_technique` 写它）。
    只收 `techniqueLevel.type` 真等于该分支的（否则客户端
    `PlayerFistFootTechnique:create(id, lv)` 会把技巧挂错分支、谙技值串台）。
    """
    out = {}
    tech_lv = _mirror(st, 'techLv', {}) or {}
    if not isinstance(tech_lv, dict):
        return out
    gone = _cleared_ids(st)
    for tid, lv in tech_lv.items():
        tid = _s(tid)
        lv = _num(lv)
        if not tid or lv <= 0 or tid in gone:
            continue
        if _tech_branch(tid) != _s(branch):
            continue
        if not (_technique_rows().get(tid) or {}).get(lv):
            continue                            # 客户端 `getTechniqueData` 会 assert
        out[tid] = {'id': tid, 'lv': lv, 'branchId': _s(branch)}
    return out


def _effects_of(st, branch, which):
    """`characterInUse` / `characterUnused` → [{techniqueId, characterId}]。

    ★ 只回**能通过客户端 `getCharacterData(cid, 技巧当前等级)` 校验**的条目
      （`FistFootSystem.lua:208/:228` 会 assert 抛错 ⇒ 界面卡死）。
    """
    out = []
    src = _mirror(st, which, {}) or {}
    if not isinstance(src, dict):
        return out
    techs = _technique_list_of(st, branch)
    for tid, ids in src.items():
        tid = _s(tid)
        lv = _num((techs.get(tid) or {}).get('lv'))
        if not lv:
            continue
        for cid in (ids if isinstance(ids, list) else []):
            cid = _s(cid)
            if cid and _char_ok(cid, lv):
                out.append({'techniqueId': tid, 'characterId': cid})
    return out


def _branch_info(st, branch):
    return {
        'exp': _branch_exp_of(st, branch),
        'costTechnique': _num((st.get('costTechnique') or {}).get(_s(branch))),
        'techniqueList': _technique_list_of(st, branch),
        'characterInUse': _effects_of(st, branch, 'charInUse'),
        'characterUnused': _effects_of(st, branch, 'charUnused'),
    }


def _all_branch_info(st, only_branch=None):
    """5 个分支都给全（`FistFootSystem:__getBranchInfoDataByType` 未知分支直接 assert）。"""
    if only_branch is not None:
        return {_s(only_branch): _branch_info(st, only_branch)}
    return {b: _branch_info(st, b) for b in BRANCHES}


def _guaji_dto(st):
    g = st.get('guaji')
    if not isinstance(g, dict) or not _s(g.get('taskId')):
        return {}
    return {
        'taskId': _s(g.get('taskId')),
        'startTime': _num(g.get('startTime')),
        'speedUpTime': _num(g.get('speedUpTime')),
    }


def _fist_dto(st):
    """`get_fist_info` / `create_fist_info` 的整份下行（字段见文件头第二节）。"""
    return {
        'accpoint': _num(st.get('accpoint')),
        'reflectExp': _num(st.get('reflectExp')),
        'feelPoint': _num(_mirror(st, 'feelPoint', st.get('feelPoint'))),
        'characterPoint': _num(_mirror(st, 'characterPoint', st.get('characterPoint'))),
        'branchInfo': _all_branch_info(st),
        'guajiInfo': _guaji_dto(st),
    }


# ---------------------------------------------------------------------------
# 修行任务：状态判定
# ---------------------------------------------------------------------------
def _task_ts(pair):
    """`[Y,M,D,h,m,s]` → unix 秒（用本机时区，和 `getTime` 给客户端的时间同源）。"""
    if not isinstance(pair, (list, tuple)) or len(pair) < 6:
        return 0
    try:
        return int(time.mktime((int(pair[0]), int(pair[1]), int(pair[2]),
                                int(pair[3]), int(pair[4]), int(pair[5]), 0, 0, -1)))
    except (TypeError, ValueError):
        return 0


def _task_in_window(row, now=None):
    """starttime/endtime 窗口内？（表里 39 条已过期，见 KNOWN_UNCERTAIN 6）"""
    now = _now() if now is None else now
    s, e = _task_ts(row.get('starttime')), _task_ts(row.get('endtime'))
    if s and now < s:
        return False
    if e and now > e:
        return False
    return True


def _conbranch(row):
    """`conblevel=[分支id, 需求锻境等级]` → (branch, lv)；不是 10010..10050 就回 ('',0)。"""
    cb = row.get('conblevel')
    if isinstance(cb, (list, tuple)) and len(cb) >= 2 and _s(cb[0]) in BRANCHES:
        return _s(cb[0]), _num(cb[1])
    return '', 0


def _task_state(st, row, now=None):
    """`FistFootConst.TaskStateType`：0=Lock / 1=Unlock / 2=Cd。

    判定顺序（每一步都只在"她表里真有依据"时才拦）：
      ① ~~时间窗过期~~ → **已按老板指示停用**（见下）
      ② `sign` 标记没在账上 → Lock
      ③ `conblevel` 锻境等级不够 → Lock
      ④ `cd=[Interval, 秒...]` 且还没到点 → Cd
      否则 Unlock。

    ★★ 老板 2026-09-28 指示（方案 A）：
      「肯定选择A呀，必然不能让这种限时问题阻碍游戏完整度」
      ⇒ **时间窗不再造成 Lock**。理由：私服跑在 2026 年，而表里
        39/146 条任务的 `endtime` 停在 2022-10-14（当时的活动），
        其中就有锻体链 **2 级唯一的任务**（`108010101 重阳雕花`）——
        照原样判定会把整条修行链卡死在 1 级。
      `_task_in_window()` 保留（仍可单独调用做展示/诊断），只是**不再参与解锁判定**。
    """
    now = _now() if now is None else now
    sign = _s(row.get('sign'))
    if sign and sign not in (st.get('flags') or []):
        return 0
    branch, need = _conbranch(row)
    if branch and _branch_lv(branch, _branch_exp_of(st, branch)) < need:
        return 0
    rec = (st.get('tasks') or {}).get(_s(row.get('taskid'))) or {}
    cd = row.get('cd')
    # `FistFootConst.lua:22-26` TaskCdType: None=1 / Interval=2 / Fixed=3
    if isinstance(cd, (list, tuple)) and cd and _num(cd[0]) == 2 and len(cd) >= 2:
        end = _num(rec.get('cdEnd'))
        if end and now < end:
            return 2
    return 1


def _cd_seconds(row):
    """Interval 冷却秒数（`cd=[2, 秒]`）。Fixed/None 都不加冷却（见 KNOWN_UNCERTAIN 7）。"""
    cd = row.get('cd')
    if isinstance(cd, (list, tuple)) and len(cd) >= 2 and _num(cd[0]) == 2:
        return max(0, _num(cd[1]))
    return 0


def _task_list(st):
    """`get_fist_tasks` 的 `list`：全部 146 条（客户端自己分三个页签）。"""
    now = _now()
    out = []
    for tid, row in _tasks().items():
        item = {'taskId': _s(tid), 'state': _task_state(st, row, now)}
        if item['state'] == 2:
            rec = (st.get('tasks') or {}).get(_s(tid)) or {}
            item['cdTime'] = max(0, _num(rec.get('cdEnd')) - now)
        out.append(item)
    out.sort(key=lambda d: (_num(d['taskId']), ))
    return out


# ---------------------------------------------------------------------------
# 奖励
# ---------------------------------------------------------------------------
def _apply_awards(ctx, st, row):
    """按 `tasks.lua.awards` 真记账，返回 `finish_fist_task` 要回的 `reward` 数组。

    元素格式**和她的 `awards` 完全一致**（`[type, arg2, arg3]`），因为
    `FistFootGuaJiPresenter.lua:168-186` 是按这个格式 `ipairs` 读的。
    """
    out = []
    for a in (row.get('awards') or []):
        if not isinstance(a, (list, tuple)) or not a:
            continue
        ty = _num(a[0])
        a2 = a[1] if len(a) > 1 else ''
        a3 = _num(a[2]) if len(a) > 2 else 0
        if ty == 1:                             # 分支阅历
            _add_branch_exp(st, a2, a3)
            out.append([1, _s(a2), a3])
        elif ty == 2:                           # 潜思经验
            st['reflectExp'] = _num(st.get('reflectExp')) + _num(a2)
            out.append([2, _num(a2)])
        elif ty == 3:                           # 剧情道具（真发货）
            iid = _s(a2)
            if iid and a3:
                mod = _items()
                sent = False
                if mod is not None:
                    try:
                        sent = bool(mod.grant(ctx, iid, a3))
                    except Exception:           # noqa: BLE001
                        sent = False
                if not sent:
                    _mark(st, 'award', '★ 道具 %s ×%d 没入包（物品模块不可用）' % (iid, a3))
                else:
                    _mark(st, 'award', '道具 %s ×%d 已入包' % (iid, a3))
            out.append([3, iid, a3])
        elif ty == 4:                           # 服务器资源
            key = _s(a2)
            if key == 'accpoint':
                st['accpoint'] = _num(st.get('accpoint')) + a3
            elif key == 'characterPoint':
                st['characterPoint'] = _num(st.get('characterPoint')) + a3
            else:
                # 表里目前只有上面两种（见 KNOWN_UNCERTAIN 1），别的键保守只记账
                _mark(st, 'award', '★ 未确认的 Net 资源 %s ×%d（只记账，未落到任何账本）'
                      % (key, a3))
            out.append([4, key, a3])
    return out


def _items():
    """`fz_api/items_currency.py`（真钱袋 / 真背包）。拿不到就回 None。"""
    try:
        try:
            from fz_api import items_currency
        except ImportError:
            sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
            import items_currency                       # type: ignore
        return items_currency
    except Exception:                          # noqa: BLE001
        return None


def _get_yuanbao(ctx):
    mod = _items()
    if mod is None:
        return None
    try:
        return _num(mod.get_currency(ctx, 'yuanbao'))
    except Exception:                          # noqa: BLE001
        return None


def _spend_yuanbao(ctx, n):
    """真扣元宝；不够回 False。"""
    mod = _items()
    if mod is None:
        return False
    try:
        return mod.add_currency(ctx, 'yuanbao', -abs(_num(n))) is not None
    except Exception:                          # noqa: BLE001
        return False


# ---------------------------------------------------------------------------
# 角色（只为 `create_fist_info` 的前置校验提供依据；只读，绝不改存档）
# ---------------------------------------------------------------------------
def _read_role():
    try:
        import json
        p = os.path.join(_here(), ROLE_FULL)
        with open(p, encoding='utf-8') as f:
            d = json.load(f)
        if isinstance(d, list):
            d = d[0] if d else {}
        return d if isinstance(d, dict) else {}
    except Exception:                          # noqa: BLE001
        return {}


def _role_lv():
    return _num(_read_role().get('lv'))


# ---------------------------------------------------------------------------
# 12 个接口的实现
# ---------------------------------------------------------------------------
def _ep_create_fist_info(ctx, st):
    """`create_fist_info` —— 「完成拳脚系统前置任务」建号。

    契约：`FistFootSystem.lua:108-123` → `initData(data)` 全量读；
    `ServerActionSystem.lua:463` 要 `data.dataVer`。
    `CommonResults.lua:3836-3847` 是地图事件入口。
    本模块在此**置 `unlocked=True`** 并回整份初始数据（全 0 结构，不是死数据：
    之后 `finish_fist_task` / `expedite_fist_task` 会真的改这些数）。
    """
    first = st.get('unlocked') is not True
    st['unlocked'] = True
    for b in BRANCHES:
        st.setdefault('branchExp', {}).setdefault(b, 0)
        st.setdefault('costTechnique', {}).setdefault(b, 0)

    # ★ 老板 2026-09-28 报「点击锻炼臂力 → 任务还未解锁」。
    # 根因是**死锁**：`branchLevel.lua` 里 1 级门槛 `exp >= 1`，
    #   而入门任务 `50201010101 锻炼臂力` 要 `conblevel=[10010,1]`；
    #   `_branch_lv(branch, 0)` = 0 ⇒ 判定 Lock ⇒ 永远点不动，
    #   而阅历又只能靠修行任务给（`FistFootSystem.lua:735 addBranchExp` 只在完成时调）。
    # ⇒ 首次开启时给每条分支**留 1 点启动阅历**（正好 1 级）。
    #   入门任务本身奖励 +10 阅历（`awards=[[1,10010,10]]`）⇒ 立刻到 2 级，能自己往下走。
    # ⚠️ 只在**首次**开启时给，二次调用不会白送（`first` 守卫）。
    if first:
        for b in BRANCHES:
            if _num(st['branchExp'].get(b)) < 1:
                st['branchExp'][b] = 1

    _mark(st, 'createFistInfo', '拳脚系统开启（lv=%d，unlockLevel=%s%s）'
          % (_role_lv(), _s(_fist_conf('unlockLevel', '?')),
             '，首次送 1 点启动阅历' if first else ''))
    _bump(st)
    _save(ctx, st)
    return ctx.ok(_fist_dto(st),
                  '%s拳脚系统信息（5 分支 %s）'
                  % ('★ 建成 ' if first else '★ 已开启，重发 ', '/'.join(BRANCHES)))


def _ep_get_fist_info(ctx, st):
    """`get_fist_info` —— 拳脚面板全量数据。

    契约：`FistFootSystem.lua:125-140` `pullData` → `initData`；
    `ServerActionSystem.lua:473-490`：`errcode==2` = 拳脚系统还未开启
    （客户端走 `callback(false, errmsg)` 弹提示，**不 error、不卡界面**）。
    """
    if st.get('unlocked') is not True:
        _save(ctx, st)
        return ctx.fail('拳脚系统还未开启', '★ get_fist_info：本号还没走过'
                        '「完成拳脚系统前置任务」（create_fist_info）⇒ errcode=2',
                        errcode=2)
    _save(ctx, st)
    g = st.get('guaji')
    return ctx.ok(_fist_dto(st),
                  '★ 拳脚信息（固身元气 %d / 潜思 %d / 感悟 %d / 特性见解 %d / %s）'
                  % (_num(st.get('accpoint')),
                     _num(st.get('reflectExp')),
                     _num(_mirror(st, 'feelPoint', st.get('feelPoint'))),
                     _num(_mirror(st, 'characterPoint', st.get('characterPoint'))),
                     ('修行中 %s' % _s(g.get('taskId'))) if g else '未修行'))


def _ep_get_fist_tasks(ctx, st):
    """`get_fist_tasks` —— 全部修行任务 + 每条的 `state`。"""
    if st.get('unlocked') is not True:
        return ctx.fail('拳脚系统还未开启', '★ get_fist_tasks：拳脚系统未开启')
    lst = _task_list(st)
    _save(ctx, st)
    from collections import Counter
    c = Counter(d['state'] for d in lst)
    return ctx.ok({'list': lst},
                  '★ 修行任务 %d 条（可修行 %d / 冷却 %d / 未解锁 %d）'
                  % (len(lst), c.get(1, 0), c.get(2, 0), c.get(0, 0)))


def _task_of(ctx):
    return _s(ctx.param('taskId') or ctx.param('taskid') or
              (ctx.args[0] if ctx.args else ''))


def _ep_start_fist_task(ctx, st):
    """`start_fist_task` —— 开始修行（挂机）。

    契约：`FistFootSystem.lua:629-646` 读 **`data.startTime`** 并写进本地
    `guajiInfo{taskId,startTime,speedUpTime=0}`；`FistFootGuaJiPresenter.lua:117`
    用它算结束时间 ⇒ `startTime` 必须是**服务端 unix 秒**。
    校验：系统已开 / 任务在表里 / 任务 state 是 Unlock / 没有另一条在修行中。
    """
    if st.get('unlocked') is not True:
        return ctx.fail('拳脚系统还未开启', '★ start_fist_task：拳脚系统未开启')
    tid = _task_of(ctx)
    row = _tasks().get(tid)
    if row is None:
        return ctx.fail('任务不存在', '★ start_fist_task：taskId=%r 不在 tasks.lua' % tid)
    if isinstance(st.get('guaji'), dict) and _s(st['guaji'].get('taskId')):
        cur = _s(st['guaji']['taskId'])
        if cur == tid:
            return ctx.fail('该任务已在修行中',
                            '★ start_fist_task：%s 已在修行中' % tid)
        return ctx.fail('已有任务在修行中，请先完成或终止',
                        '★ start_fist_task：当前在修行 %s' % cur)
    state = _task_state(st, row)
    if state == 0:
        return ctx.fail('任务还未解锁',
                        '★ start_fist_task：%s state=Lock（sign=%s / conblevel=%s / 窗口 %s）'
                        % (tid, _s(row.get('sign')), row.get('conblevel'),
                           _task_in_window(row)))
    if state == 2:
        return ctx.fail('任务冷却中',
                        '★ start_fist_task：%s 冷却中' % tid)
    start = _now()
    st['guaji'] = {'taskId': tid, 'startTime': start, 'speedUpTime': 0}
    _mark(st, 'startFistTask', '%s（%s，%s 小时）startTime=%d'
          % (tid, _s(row.get('name')), _num(row.get('time')), start))
    _bump(st)
    _save(ctx, st)
    return ctx.ok({'startTime': start},
                  '★ 开始修行 %s（%s）' % (tid, _s(row.get('name'))))


def _ep_stop_fist_task(ctx, st):
    """`stop_fist_task` —— 中途终止（**不发奖励**）。

    契约：`FistFootSystem.lua:653-667` 成功即把本地 `guajiInfo` 清空；
    `FistFootGuaJiPresenter.lua:219-230` 的弹窗文案就是"终止修行会无法获取修行奖励"。
    """
    if st.get('unlocked') is not True:
        return ctx.fail('拳脚系统还未开启', '★ stop_fist_task：拳脚系统未开启')
    tid = _task_of(ctx)
    g = st.get('guaji')
    if not isinstance(g, dict) or not _s(g.get('taskId')):
        return ctx.fail('当前没有修行中的任务', '★ stop_fist_task：本号未在修行')
    if tid and _s(g.get('taskId')) != tid:
        return ctx.fail('任务不匹配', '★ stop_fist_task：上行 %s ≠ 在修行 %s'
                        % (tid, _s(g.get('taskId'))))
    old = _s(g.get('taskId'))
    st['guaji'] = None
    _mark(st, 'stopFistTask', '%s 终止（无奖励）' % old)
    _bump(st)
    _save(ctx, st)
    return ctx.ok({}, '★ 终止修行 %s（不发奖励，与她弹窗文案一致）' % old)


def _ep_finish_fist_task(ctx, st):
    """`finish_fist_task` —— 完成修行，**真发奖励**。

    契约（逐字段）：
      * `FistFootSystem.lua:700-721`：`data.reward` → `getFistTaskReward(bagEnough,
        data.reward)`；`data.feelPoint` → `setFeelPoint`；`data.msg` 可选弹字。
      * `FistFootGuaJiPresenter.lua:164-200`：`data.reward` 是**数组**，
        逐项 `v[1]/v[2]/v[3]` 弹"获得：xxx"；`v[1]==3` 且 `bagEnough==1` 时
        `Item:getOneItemByKey(v[2])`（**道具号的格式必须合法**，所以直接回她表里
        `awards` 的原样条目，绝不自己编）。
    校验：必须在修行中 + 任务 id 匹配 + 时间到
      （`isCompleteGuaJi` = `now >= startTime + time*3600 - speedUpTime`，
       `FistFootSystem.lua:600-606`；客户端按钮只在到点后才出现，
       服务端仍拦一次，防止改包提前领）。
    """
    if st.get('unlocked') is not True:
        return ctx.fail('拳脚系统还未开启', '★ finish_fist_task：拳脚系统未开启')
    tid = _task_of(ctx)
    row = _tasks().get(tid)
    if row is None:
        return ctx.fail('任务不存在', '★ finish_fist_task：taskId=%r 不在 tasks.lua' % tid)
    g = st.get('guaji')
    if not isinstance(g, dict) or _s(g.get('taskId')) != tid:
        return ctx.fail('没有在修行该任务',
                        '★ finish_fist_task：在修行 %s，上行 %s'
                        % (_s((g or {}).get('taskId')) or '无', tid))
    need = _num(row.get('time')) * 3600
    done_at = _num(g.get('startTime')) + need - _num(g.get('speedUpTime'))
    if _now() < done_at:
        return ctx.fail('修行还未完成',
                        '★ finish_fist_task：%s 还需 %d 秒' % (tid, done_at - _now()))
    reward = _apply_awards(ctx, st, row)
    st['guaji'] = None
    rec = st.setdefault('tasks', {}).setdefault(tid, {})
    rec['finish'] = _now()
    rec['count'] = _num(rec.get('count')) + 1
    cd = _cd_seconds(row)
    rec['cdEnd'] = (_now() + cd) if cd else 0
    _mark(st, 'finishFistTask', '%s 完成，奖励 %s' % (tid, reward))
    _bump(st)
    _save(ctx, st)
    return ctx.ok({
        'reward': reward,
        'feelPoint': _num(_mirror(st, 'feelPoint', st.get('feelPoint'))),
        'characterPoint': _num(_mirror(st, 'characterPoint', st.get('characterPoint'))),
    }, '★ 完成 %s（%s）→ 奖励 %s'
        % (tid, _s(row.get('name')), reward or '无'))


def _ep_expedite_fist_task(ctx, st):
    """`expedite_fist_task`（Lua 名 `speedUpFistTask`）—— 加速修行。

    契约：`FistFootSystem.lua:675-692` 读 **`data.cost`**（本地 `accpoint -= cost`）
    与 **`data.speedUpTime`**（本地 `guajiInfo.speedUpTime += speedUpTime`）；
    `FistFootGuaJiPresenter.lua:117` 把 `speedUpTime` 当**秒**从剩余时间里减。
    口径（`SpeedUpGuaJiPresenter.lua:44-51,80-87`）：1 点 = 1 档 = 5 分钟展示，
    但 `setSpeedTime`（:80-82）与 `FistFootSystem.lua:682-684` 的加法都用 `cost*3600`
    ⇒ 每点减 3600 秒（=1 小时）。★ 这是**两处口径不一致**的地方（展示用 300 秒/点、
    计算用 3600 秒/点），本模块按**计算那一路**（3600）走，因为
    `startTime + time*3600 - speedUpTime`（`FistFootGuaJiPresenter.lua:117`）
    才是真正决定"修行还剩多久"的式子；见 `KNOWN_UNCERTAIN` 第 7 条姊妹说明。
    """
    if st.get('unlocked') is not True:
        return ctx.fail('拳脚系统还未开启', '★ expedite_fist_task：拳脚系统未开启')
    tid = _task_of(ctx)
    row = _tasks().get(tid)
    if row is None:
        return ctx.fail('任务不存在', '★ expedite_fist_task：taskId=%r 不在 tasks.lua' % tid)
    g = st.get('guaji')
    if not isinstance(g, dict) or _s(g.get('taskId')) != tid:
        return ctx.fail('没有在修行该任务', '★ expedite_fist_task：不在修行 %s' % tid)
    cost = _num(ctx.param('cost'))
    if cost <= 0:
        return ctx.fail('加速数量错误', '★ expedite_fist_task：cost=%r' % ctx.param('cost'))
    have = _num(st.get('accpoint'))
    if cost > have:
        return ctx.fail('固身元气不足',
                        '★ expedite_fist_task：需要 %d 点固身元气，当前 %d' % (cost, have))
    reduce = cost * SPEEDUP_SECONDS_PER_POINT
    need = _num(row.get('time')) * 3600
    left = _num(g.get('startTime')) + need - _num(g.get('speedUpTime')) - _now()
    if left <= 0:
        return ctx.fail('修行已完成，无需加速',
                        '★ expedite_fist_task：%s 已到点' % tid)
    if reduce > left:
        # 只扣"刚好够减完"的点数（`SpeedUpGuaJiPresenter.lua:44-51` 的上限算法）
        cost = int(math.ceil(left / float(SPEEDUP_SECONDS_PER_POINT)))
        if cost <= 0:
            cost = 1
        if cost > have:
            return ctx.fail('固身元气不足',
                            '★ expedite_fist_task：减完还需 %d 点，当前 %d' % (cost, have))
        reduce = cost * SPEEDUP_SECONDS_PER_POINT
    st['accpoint'] = have - cost
    g['speedUpTime'] = _num(g.get('speedUpTime')) + reduce
    _mark(st, 'speedUpFistTask', '%s 加速 %d 点（-%d 秒，余固身元气 %d）'
          % (tid, cost, reduce, st['accpoint']))
    _bump(st)
    _save(ctx, st)
    return ctx.ok({'cost': cost, 'speedUpTime': reduce},
                  '★ 加速 %s：耗 %d 固身元气，减 %d 秒（余 %d）'
                  % (tid, cost, reduce, st['accpoint']))


def _flags_of(ctx, key):
    v = ctx.param(key)
    if v is None:
        return []
    if isinstance(v, (list, tuple)):
        return [_s(x) for x in v if _s(x)]
    # 她地图事件是 `string.split(result.arg2, ";")` 后整表下发；
    # 探针可能给 "a;b" 或 "a,b"（宽容处理）
    txt = _s(v)
    for sep in (';', ',', '|'):
        if sep in txt:
            return [x for x in (_s(y).strip() for y in txt.split(sep)) if x]
    return [txt] if txt else []


def _ep_updata_fist_flag(ctx, st):
    """`updata_fist_flag` —— 更新修行任务解锁标记。

    契约：`FistFootSystem.lua:955-968` 只看 ok，**不读 data 字段** ⇒ 回 `{}`；
    上行 `{addFlags=[], deleteFlags=[]}`（`HttpManager.lua:4978-4981`），
    调用方是地图事件「更新拳脚系统标记」（`CommonResults.lua:3848-3867`，
    参数是 `;` 分隔串）与 `FistFootSystem:repairFistFootFlag`（:1177-1230）与
    Debug 面板（`TestLayer.lua:4168-4212`）。
    真记账：写进 `st['flags']`，`get_fist_tasks` 的 `sign` 判定真读它。
    ★ **不做 `unlocked` 门禁**：她地图事件里"更新拳脚系统标记"与"完成拳脚系统前置
      任务"是两条独立 result（`CommonResults.lua:3836-3867`），标记可能先到。
    """
    add = _flags_of(ctx, 'addFlags')
    dele = _flags_of(ctx, 'deleteFlags')
    if not add and not dele:
        return ctx.fail('标记参数为空', '★ updata_fist_flag：addFlags/deleteFlags 都空')
    have = list(st.get('flags') or [])
    for f in add:
        if f not in have:
            have.append(f)
    for f in dele:
        if f in have:
            have.remove(f)
    st['flags'] = have
    _mark(st, 'updataFistFlag', '+%s -%s' % (add, dele))
    _bump(st)
    _save(ctx, st)
    # `FistFootSystem.lua:961` 只看 ok，不读字段 ⇒ 回空 dict（`ctx.ok` 自动补 dataVer）
    return ctx.ok({},
                  '★ 拳脚标记：+%d -%d（现有 %d 个）' % (len(add), len(dele), len(have)))


def _page_spent_feel(st, page_index):
    """某一页"已投入的感悟点"（= 该页技巧逐级 `skillcon` 求和）。

    ★ 口径是**按表推算**、不是抄来的字段：她表里没有"每页已投入感悟点"，
      只有每级的消耗 `techniqueLevel.skillcon`（`fist_liangong._ep_upgrade_technique`
      也是拿它扣的）。见 `KNOWN_UNCERTAIN` 第 9 条（要改就改这一个函数）。
    """
    total = 0
    for tid in _tech_ids_of_page(st, page_index):
        lv = _num((_mirror(st, 'techLv', {}) or {}).get(tid))
        grp = _technique_rows().get(tid) or {}
        for l in range(2, lv + 1):
            total += _num((grp.get(l) or {}).get('skillcon'))
    return total


def _tech_ids_of_page(st, page_index):
    """"第 `page_index` 页有哪些技巧" —— 她表里**没有**页↔技巧/分支的映射。

    ★ 未确认（`KNOWN_UNCERTAIN` 第 9 条）：`FistFootSystem.lua:19-83` 的默认
      `branchInfo` 是 **5 个分支 = 5 项**，而 `skillpageUL=10`（页码上限 10），
      两者对不上；`FistFootResManager` 里也没有"页 → 技巧"的表。
      本模块保守按"**一页 = 一个分支**"（第 1 页 10010 拳法 … 第 5 页 10050 腿法；
      6..10 页按 `% 5` 复用）折算，并且**只影响回溯退款/清空的范围**，
      不影响面板的其它数值。
    """
    p = _num(page_index)
    if p <= 0:
        return []
    branch = BRANCHES[(p - 1) % len(BRANCHES)]
    gone = _cleared_ids(st)
    out = []
    for tid in (_mirror(st, 'techLv', {}) or {}).keys():
        tid = _s(tid)
        if tid and tid not in gone and _tech_branch(tid) == branch:
            out.append(tid)
    return out


def _ep_reset_fist_technique(ctx, st):
    """`reset_fist_technique`（Lua 名 `resetTalentPage`）—— 技巧回溯（重置心得页）。

    契约（三处都要给全，缺一个客户端就炸）：
      * `HttpManager.lua:4963-4966` 上行 `{techniquePageId, dataVer, codeVer}`
      * `FistFootSystem.lua:875-904` 成功回调：`data.feelPoint` → `setFeelPoint`；
        **`pairs(data.branchInfo)`** 逐分支读 `costTechnique / techniqueList /
        characterInUse / characterUnused`（`branchInfo` 缺了直接 `pairs(nil)` 报错）
      * `TalentPagePresenter.lua:226-241`：`data.resetCount` → `setResetCount`
        （:84-94 把它当 `techniqueReset.recall` 下标查**本次**消耗）；
        `BasicTalentPage:create(data)` 还要 `data.feelPoint` + `data.branchInfo`
    真记账：`pageReset[页码]+1`、清空该页技巧/特性（本地镜像）、真扣元宝。
    """
    if st.get('unlocked') is not True:
        return ctx.fail('拳脚系统还未开启', '★ reset_fist_technique：拳脚系统未开启')
    page = _num(ctx.param('techniquePageId') or ctx.param('pageNum') or
                (ctx.args[0] if ctx.args else ''))
    pages = _page_count()
    if page <= 0 or page > pages:
        return ctx.fail('页码错误', '★ reset_fist_technique：techniquePageId=%s 越界（1..%d）'
                        % (page, pages))
    page_reset = _mirror(st, 'pageReset', {}) or {}
    recall = _num((page_reset or {}).get(_s(page)))
    rows = _tech_resets()
    if not rows:
        return ctx.fail('回溯配置缺失',
                        '★ reset_fist_technique：techniqueReset.lua 读不到')
    nxt = recall + 1
    conf = rows.get(nxt) or rows[max(rows)]
    cost = _num((conf or {}).get('count'))
    cur_type = _num((conf or {}).get('type'))       # `FistFootConst.ResetTalentCurrType.YuanBao=1`
    if cur_type not in (0, 1):
        return ctx.fail('回溯货币类型未确认',
                        '★ reset_fist_technique：techniqueReset.type=%s（表里只有 1=元宝）'
                        % cur_type)
    have = _get_yuanbao(ctx)
    if have is not None and have < cost:
        return ctx.fail('元宝不足',
                        '★ reset_fist_technique：第 %d 次回溯需 %d 元宝，当前 %d'
                        % (nxt, cost, have))
    if have is not None and cost > 0:
        if not _spend_yuanbao(ctx, cost):
            return ctx.fail('元宝不足',
                            '★ reset_fist_technique：扣 %d 元宝失败' % cost)
    branch = BRANCHES[(page - 1) % len(BRANCHES)]
    tech_ids = _tech_ids_of_page(st, page)
    refund = _page_spent_feel(st, page)
    st.setdefault('pageReset', {})[_s(page)] = nxt
    st.setdefault('cleared', {})[_s(page)] = {
        'recall': nxt, 'at': _now(), 'branch': branch,
        'techIds': tech_ids, 'feel': refund,
    }
    _mark(st, 'resetFistTechnique',
          '第 %d 页回溯（第 %d 次，-%d 元宝，退回感悟点 +%d，清空技巧 %s）'
          % (page, nxt, cost, refund, tech_ids))
    _bump(st)
    _save(ctx, st)
    # `FistFootSystem.lua:885-895` 对 `data.branchInfo` 走 `pairs` 且逐分支读
    # `costTechnique/techniqueList/characterInUse/characterUnused` ⇒ 5 个分支都得在。
    bi = _all_branch_info(st)
    reset_count = len([1 for v in (st.get('pageReset') or {}).values() if _num(v) > 0])
    return ctx.ok({
        'resetCount': reset_count,
        'feelPoint': _num(_mirror(st, 'feelPoint', st.get('feelPoint'))) + refund,
        'branchInfo': bi,
    }, '★ 技巧回溯：第 %d 页（=分支 %s）→ 第 %d 次（-%d 元宝，退 %d 感悟点，'
        '清空 %d 个技巧，累计回溯 %d 页）'
        % (page, branch, nxt, cost, refund, len(tech_ids), reset_count))


# ---------------------------------------------------------------------------
# 路由
# ---------------------------------------------------------------------------
_HANDLERS = {
    # 任务书清单里的驼峰名（客户端不走这些 URL，但注册上更稳）
    'createFistInfo': _ep_create_fist_info,
    'getFistFootInFo': _ep_get_fist_info,
    'getFistTasks': _ep_get_fist_tasks,
    'startFistTask': _ep_start_fist_task,
    'stopFistTask': _ep_stop_fist_task,
    'finishFistTask': _ep_finish_fist_task,
    'speedUpFistTask': _ep_expedite_fist_task,
    'updataFistFlag': _ep_updata_fist_flag,
    # 客户端 `HttpManager.lua` 真正发的 URL
    'create_fist_info': _ep_create_fist_info,
    'get_fist_info': _ep_get_fist_info,
    'get_fist_tasks': _ep_get_fist_tasks,
    'start_fist_task': _ep_start_fist_task,
    'stop_fist_task': _ep_stop_fist_task,
    'finish_fist_task': _ep_finish_fist_task,
    'expedite_fist_task': _ep_expedite_fist_task,
    'updata_fist_flag': _ep_updata_fist_flag,
    'reset_fist_technique': _ep_reset_fist_technique,
}


def handle(ctx):
    ep = ctx.endpoint
    fn = _HANDLERS.get(ep)
    if fn is None:
        return None                     # 不是我的接口
    st = _load(ctx)
    return fn(ctx, st)
