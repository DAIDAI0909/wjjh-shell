# -*- coding: utf-8 -*-
# ================= 离线包路径根（fz_make_offline_bundle.py 自动注入） =================
# 手机上整个服务端就是一个目录，表在哪、状态写哪，全部相对包根算。
# （有的模块原来把绝对路径写死，本身没 import os —— 这里一并补上）
import os
import os as _osp


def _off_find_bundle(_f):
    """从模块所在目录往上找包根（认 fz_boot_server.py）。
    ★ fz_api/*.py 的 __file__ 在 <根>/fz_api/ 下，直接 dirname 会算错一层。"""
    _d = _osp.path.dirname(_osp.path.abspath(_f))
    for _ in range(6):
        if _osp.path.exists(_osp.path.join(_d, 'fz_boot_server.py')):
            return _d
        _u = _osp.path.dirname(_d)
        if _u == _d:
            break
        _d = _u
    return _osp.path.dirname(_osp.path.abspath(_f))


_OFF_BUNDLE = _off_find_bundle(__file__)
_OFF_FZ_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_fz')
_OFF_INK_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_ink')
_OFF_WORK_ROOT = _OFF_BUNDLE
# =====================================================================================
# ★ 2026-10-04 商城空货架修复：客户端资源表解析——PC 开发树优先，设备上自动回退
#   到包内 client_fz 副本（jhserver/client_fz = fangzhi_lua_dec 的同步拷贝）。
def _fz_res(*parts):
    base = os.path.join(_OFF_FZ_ROOT, 'res', 'script')
    if not os.path.isdir(base):
        base = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            '..', 'client_fz', 'res', 'script')
    return os.path.join(base, *parts)

# -*- coding: utf-8 -*-
"""挑战副本 / 挑战地图 —— 1:1 还原她的 `ChallengeMapSystem` 契约。

契约来源（她的 lua，逐个读过）：
  * `assets/src/app/models/ChallengeMap/ChallengeMapSystem.lua`
      - `enterChallengeMap`        → `challengemap_enter`
            读 `data.level`（数字，`role:getLv() < level` → 等级不足）
            读 `data.sign`（对象；`sign[1]`/`sign[2]` 拿去 `role:getFlag(sign[1])` 比对，
            所以必须是 **对象**，给 nil 也可能被 `sign and sign[1]` 跳过后没事，但给字符串必崩）
      - `challengeMapConfirmConsume` → `challengemap_confirm_consume`（只读 errcode）
      - `challengeMapFinish`         → `challengemap_finish`  读 `data.award_id`（字符串）
            `award_id` 会被喂给 `RewardManager:getRewardArrayWithRewardSchemeWithoutRestriction`，
            **该策略 id 查不到时 RewardManager 直接 error() ⇒ 应答回调被 xpcall 吞掉 ⇒ 客户端卡死**，
            所以这里只回她在 `rewardScheme.lua` 里真有的策略 id（155 张副本的 awardId 全部命中）。
      - `challengeMapGetAward`       → `challengemap_award`
            读 `data.award_list`（数组，元素 `{type,id,num}`，逐条 `getAward` 后送
            `ChallengeMapFinishPresenter:setListViewReward` 再读 id/num/type；**缺了必崩**）
            读 `data.msg`（字符串，可空） / `data.currencyVersion`（数字）
      - `challengeMapIsCustoms`     → `challengemap_is_customs`（只读 errcode，data 不读）
      - `reEnterChallengemap`       → `reenter_challengemap`
            读 `data.challengemap`（对象） → `data.challengemap.map_id`（字符串）
            再 `ChallengeMapResource:getMapInfoById(map_id)`，**map_id 必须是 mapInfo 的键**，
            否则 `__enterMap` → `createMap` 里 assert 失败 ⇒ 卡死。
  * `assets/src/app/models/ChallengeMap/ChallengeMapConstant.lua`
      - `FinishType.Normal=1 / Faster=2`
      - `RewardType.Loc_Item=1 / Loc_Attr=2 / net_Res=3 / BasicTitle=4`
  * `assets/src/app/models/ChallengeMap/ChallengeMapResource.lua`
      - 副本表 = `script.challengeMap.mapInfo["map"]`；标记表 = `script.challengeMap.flags["flag"]`

数据来源（她自己的资源表，运行期惰性解析）：
  * `res/script/challengeMap/mapInfo.lua` 的 `["map"]` —— 副本 id / 名称 / 等级 / 章节 / 奖励策略 /
    资源奖励 `rsesources=[["amartial",45],...]` / `sign` / `ExpendItem`（155 张，全用上）
  * `res/script/store/shoplist.lua` 的 `["Sheet1"]` —— `rsesources` 里的 `itemId` 反查成
    `Item:getOneItemByKey` 认的货架键（形如 "400040"），155 张副本的 rsesources 全部能反查到

状态：`work/challengemap_state.json` —— 进入 / 扣料 / 通关 / 领奖都真写盘。
"""
import os
import copy
import time

NAME = 'challenge_map'
TITLE = '挑战地图/挑战副本'
ENDPOINTS = [
    'challengemap_enter',
    'challengemap_finish',
    'challengemap_award',
    'challengemap_confirm_consume',
    'challengemap_is_customs',
    'reenter_challengemap',
]

STATE = 'challengemap_state.json'

RES = _fz_res()
MAPINFO = RES + r'/challengeMap/mapInfo.lua'
SHOPLIST = RES + r'/store/shoplist.lua'
REWARDSCHEME = RES + r'/rewardScheme.lua'

# ChallengeMapConstant.RewardType
RT_ITEM, RT_ATTR, RT_NET, RT_TITLE = 1, 2, 3, 4

_CACHE = {}




def _lua_table(path, sheet=None):
    try:
        import fz_luatable
        t = fz_luatable.load_lua_table(path)
    except Exception:                          # noqa: BLE001
        return {}
    if not isinstance(t, dict):
        return {}
    if sheet is not None:
        v = t.get(sheet)
        return v if isinstance(v, dict) else {}
    return t


def _maps():
    """`res/script/challengeMap/mapInfo.lua["map"]` —— 副本 id → 副本配置。"""
    c = _CACHE.get('map')
    if c is None:
        c = _lua_table(MAPINFO, 'map')
        _CACHE['map'] = c
    return c


def _shop():
    c = _CACHE.get('shop')
    if c is None:
        c = _lua_table(SHOPLIST, 'Sheet1')
        _CACHE['shop'] = c
    return c


def _shop_by_itemid():
    """`itemId`（如 'amartial'）→ 货架键（如 '400040'）。"""
    c = _CACHE.get('shop_rev')
    if c is None:
        c = {}
        for k, v in _shop().items():
            iid = v.get('itemId') if isinstance(v, dict) else None
            if iid is not None:
                c.setdefault(str(iid), str(k))
        _CACHE['shop_rev'] = c
    return c


def _schemes():
    c = _CACHE.get('scheme')
    if c is None:
        c = _lua_table(REWARDSCHEME, 'rewardScheme')
        _CACHE['scheme'] = c
    return c


def _map_info(map_id):
    return _maps().get(str(map_id)) or {}


def _default_map_id():
    m = _maps()
    for k in ('tzfb0101',):                    # 她的第一张普通副本（天龙诡寺）
        if k in m:
            return k
    for k, v in m.items():
        if isinstance(v, dict) and v.get('type') == 1:
            return k
    return next(iter(m), '')


def _award_id(mi):
    """只回她 `rewardScheme.lua` 里真有的策略 id —— 查不到会被 RewardManager error() 吞掉。"""
    aid = str(mi.get('awardId') or '')
    if aid and aid in _schemes():
        return aid
    for k, v in _schemes().items():
        if isinstance(v, dict) and v.get('type') == '策略':
            return k
    return ''


def _award_list_from_map(mi):
    """副本表 `rsesources=[["amartial",45],...]` → `{type,id,num}`（id 用 shoplist 的键）。"""
    rev = _shop_by_itemid()
    shop = _shop()
    out = []
    for r in mi.get('rsesources') or []:
        if not isinstance(r, (list, tuple)) or len(r) < 2:
            continue
        iid = str(r[0])
        num = int(r[1] or 1)
        key = rev.get(iid)
        if key and key in shop:
            out.append({'type': RT_ITEM, 'id': key, 'num': num,
                        'name': (shop.get(key) or {}).get('name') or iid})
        else:
            out.append({'type': RT_ATTR, 'id': iid, 'num': num, 'name': iid})
    return out


def _clean_award_list(raw, mi):
    """把上行 `award_list` 擦成完整对象；空就用她副本表里的 rsesources。"""
    out = []
    if isinstance(raw, (list, tuple)):
        for it in raw:
            if not isinstance(it, dict):
                continue
            o = {'type': int(it.get('type') or RT_ITEM),
                 'id': it.get('id'),
                 'num': int(it.get('num') or 1)}
            if o['id'] is None:
                continue
            o['id'] = str(o['id'])
            out.append(o)
    return out or _award_list_from_map(mi)


def _state(ctx):
    st = ctx.load_json(STATE, None)
    if not isinstance(st, dict):
        st = {}
    st.setdefault('current_map', '')           # 正在进行的副本（reenter 用）
    st.setdefault('entered', {})               # map_id → 进入次数
    st.setdefault('consumed', {})              # map_id → 已扣的 {id:num}
    st.setdefault('finished', {})              # map_id → 通关次数
    st.setdefault('awarded', {})               # map_id → 领奖次数
    st.setdefault('award_id', '')              # 上次 finish 回的策略 id
    st.setdefault('award_list', [])
    st.setdefault('currencyVersion', 1)
    return st


def _save(ctx, st):
    ctx.save_json(STATE, st)


def handle(ctx):
    ep = ctx.endpoint
    st = _state(ctx)

    # ------------------------------------------------ 进入前：等级 / 标记
    if ep == 'challengemap_enter':
        map_id = str(ctx.param('map_id') or (ctx.args[0] if ctx.args else '') or _default_map_id())
        mi = _map_info(map_id)
        if not mi:
            return ctx.fail('找不到这个副本（%s）' % map_id, '★ 进入副本：未知 map_id=%s' % map_id)
        sign = mi.get('sign')
        if not isinstance(sign, (list, tuple)) or len(sign) < 2:
            sign = {}                          # 必须给对象：她读 sign[1]/sign[2]
        st['current_map'] = map_id
        st['entered'][map_id] = int(st['entered'].get(map_id) or 0) + 1
        _save(ctx, st)
        data = {
            'level': int(mi.get('level') or 1),        # 数字
            'sign': list(sign) if sign else {},        # 对象
            'challengemap': {'map_id': map_id},        # 对象（reenter 走同一套）
            'map_id': map_id,
            'msg': '',
        }
        ctx.log('[挑战地图] 进入前查询 %s《%s》lv=%s（第 %d 次）'
                % (map_id, mi.get('name') or '', data['level'], st['entered'][map_id]))
        return ctx.ok(data, '★ 挑战副本进入信息《%s》' % (mi.get('name') or map_id))

    # ------------------------------------------------ 确认扣料
    if ep == 'challengemap_confirm_consume':
        map_id = str(ctx.param('map_id') or (ctx.args[0] if ctx.args else '') or _default_map_id())
        mi = _map_info(map_id)
        raw = ctx.param('consume_map') or (ctx.body_obj or {}).get('consume_map')
        consume_map = []
        if isinstance(raw, (list, tuple)):
            for it in raw:
                if isinstance(it, dict) and it.get('id') is not None:
                    consume_map.append({'id': str(it.get('id')), 'num': int(it.get('num') or 1)})
        st['consumed'][map_id] = {c['id']: c['num'] for c in consume_map}
        st['current_map'] = map_id
        _save(ctx, st)
        ctx.log('[挑战地图] 确认扣料 %s → %s' % (map_id, consume_map))
        return ctx.ok({'map_id': map_id, 'consume_map': consume_map, 'msg': ''},
                      '★ 确认扣除副本消耗（%d 项）' % len(consume_map))

    # ------------------------------------------------ 通关结算（回奖励策略 id）
    if ep == 'challengemap_finish':
        map_id = str(ctx.param('map_id') or (ctx.args[0] if ctx.args else '') or _default_map_id())
        finish_type = int(ctx.int_param('finish_type', 1) or 1)
        mi = _map_info(map_id)
        if not mi:
            return ctx.fail('找不到这个副本（%s）' % map_id, '★ 通关：未知 map_id=%s' % map_id)
        aid = _award_id(mi)
        st['finished'][map_id] = int(st['finished'].get(map_id) or 0) + 1
        st['current_map'] = ''
        st['award_id'] = aid
        st['award_list'] = _award_list_from_map(mi)
        _save(ctx, st)
        data = {
            'award_id': aid,                            # 字符串，必须能在 rewardScheme 里查到
            'map_id': map_id,
            'finish_type': finish_type,
            'msg': '',
            'currencyVersion': int(st['currencyVersion']),
        }
        ctx.log('[挑战地图] 通关 %s《%s》 finish_type=%s → 策略 %s（第 %d 次）'
                % (map_id, mi.get('name') or '', finish_type, aid, st['finished'][map_id]))
        return ctx.ok(data, '★ 挑战副本通关《%s》（奖励策略 %s）' % (mi.get('name') or map_id, aid))

    # ------------------------------------------------ 领奖（回 award_list）
    if ep == 'challengemap_award':
        map_id = str(ctx.param('map_id') or (ctx.args[0] if ctx.args else '') or _default_map_id())
        mi = _map_info(map_id)
        grant_type = int(ctx.int_param('type', 1) or 1)      # 1 直接发放 / 2 背包不足走邮件
        raw = ctx.param('award_list') or (ctx.body_obj or {}).get('award_list')
        award_list = _clean_award_list(raw, mi)
        st['awarded'][map_id] = int(st['awarded'].get(map_id) or 0) + 1
        st['award_list'] = copy.deepcopy(award_list)
        st['currencyVersion'] = int(st.get('currencyVersion') or 1) + 1
        _save(ctx, st)
        data = {
            'award_list': award_list if grant_type == 1 else [],
            'msg': '' if grant_type == 1 else '背包已满，奖励已通过江湖邮驿发放。',
            'map_id': map_id,
            'isEmail': 1 if grant_type == 2 else 0,
            'currencyVersion': int(st['currencyVersion']),
        }
        ctx.log('[挑战地图] 领奖 %s《%s》 type=%s → %d 项'
                % (map_id, mi.get('name') or '', grant_type, len(data['award_list'])))
        return ctx.ok(data, '★ 领取挑战副本奖励《%s》（%d 项）'
                      % (mi.get('name') or map_id, len(data['award_list'])))

    # ------------------------------------------------ 能否"匆匆了事"
    if ep == 'challengemap_is_customs':
        map_id = str(ctx.param('map_id') or (ctx.args[0] if ctx.args else '') or _default_map_id())
        mi = _map_info(map_id)
        done = int(st['finished'].get(map_id) or 0) > 0 or int(st['awarded'].get(map_id) or 0) > 0
        ctx.log('[挑战地图] 快速通关资格 %s → %s' % (map_id, done))
        return ctx.ok({'is_customs': 1 if done else 0, 'map_id': map_id,
                       'strain': int(mi.get('strain') or 0), 'msg': ''},
                      '★ 挑战副本快速通关资格（%s）' % ('可' if done else '不可'))

    # ------------------------------------------------ 重进未完成副本
    if ep == 'reenter_challengemap':
        map_id = str(st.get('current_map') or '')
        if not map_id or not _map_info(map_id):
            return ctx.fail('当前没有未完成的挑战副本', '★ 重进副本：没有进行中的副本')
        mi = _map_info(map_id)
        data = {
            'challengemap': {'map_id': map_id, 'level': int(mi.get('level') or 1),
                             'name': mi.get('name') or ''},
        }
        ctx.log('[挑战地图] 重进未完成副本 %s《%s》' % (map_id, mi.get('name') or ''))
        return ctx.ok(data, '★ 重进挑战副本《%s》' % (mi.get('name') or map_id))

    return None
