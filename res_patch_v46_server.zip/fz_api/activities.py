# -*- coding: utf-8 -*-
# ================= 离线包路径根（fz_make_offline_bundle.py 自动注入） =================
# 手机上整个服务端就是一个目录，表在哪、状态写哪，全部相对包根算。
# （有的模块原来把绝对路径写死，本身没 import os —— 这里一并补上）
import os
import os as _osp


def _off_find_bundle(_f):
    """从模块所在目录往上找包根（认 fz_boot_server.py）。
    ★ fz_api/*.py 的 __file__ 在 <根>/fz_api/ 下，直接 dirname 会算错一层。"""
    _d = _osp.path.dirname(_osp.path.abspath(_f))
    for _ in range(6):
        if _osp.path.exists(_osp.path.join(_d, 'fz_boot_server.py')):
            return _d
        _u = _osp.path.dirname(_d)
        if _u == _d:
            break
        _d = _u
    return _osp.path.dirname(_osp.path.abspath(_f))


_OFF_BUNDLE = _off_find_bundle(__file__)
_OFF_FZ_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_fz')
_OFF_INK_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_ink')
_OFF_WORK_ROOT = _OFF_BUNDLE
# =====================================================================================
# ★ 2026-10-04 商城空货架修复：客户端资源表解析——PC 开发树优先，设备上自动回退
#   到包内 client_fz 副本（jhserver/client_fz = fangzhi_lua_dec 的同步拷贝）。
def _fz_res(*parts):
    base = os.path.join(_OFF_FZ_ROOT, 'res', 'script')
    if not os.path.isdir(base):
        base = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            '..', 'client_fz', 'res', 'script')
    return os.path.join(base, *parts)

# -*- coding: utf-8 -*-
"""活动类面板（夺宝 / 名武录 / 名人录 / 藏经阁 / 仓库活动 / 限时历练 /
丹青阁 / 每日任务 / 醉仙楼 / 香囊秘格 / 淬炼商店 / 拳脚商店 / 幸运盒子 / 年兽 / 消耗计划）。

契约全部逐个读自她客户端（不是猜的）：
  * `app/models/Action/JiangHuDuoBao.lua`          —— get_lottery_treasure_list / buy_lottery_treasure_currency /
                                                      lottery_treasure_result / lottery_treasure_reward
  * `app/models/Action/JiangHuMingWuLuAction.lua`  —— get_mingwu_lottery_list / do_mingwu_lottery /
                                                      detection_goods / employ_materials（=checkItemIsCanUse）
  * `app/models/Action/JiangHuYiRenLuAction.lua`   —— get_mingren_lottery_list
  * `app/models/Action/CangJingGe.lua`             —— get_sutra_pavilion_list / get_sutra_pavilion_goods /
                                                      buy_sutra_pavilion_goods
  * `app/models/Action/WareHouseActivity.lua`      —— get_treasury_info / get_treasury_reward /
                                                      treasury_lottery / enter_next_treasury
  * `app/models/Action/LimitedTimeExperience.lua`  —— get_training_task_list
  * `app/models/Action/DanQingGe.lua`              —— get_danqing_pavilion_info / get_danqing_pavilion_reward /
                                                      exchange_danqing_pavilion_item
  * `app/models/Action/DailyTasksActivity.lua`     —— get_daily_task_list / get_daily_task_reward /
                                                      add_daily_task_point
  * `app/models/Action/DrinkMore.lua`              —— get_toast_reward_list / get_toast_reward / toast_qian
  * `app/models/Action/XiangNangMiGe.lua`          —— get_sachet_attic_new_list
  * `app/models/Action/CuiLianCaiLiaoStore.lua`    —— get_cuiLianCaiLiao_store_list /
                                                      buy_cuiLianCaiLiao_store_goods /
                                                      exchange_cuiLianCaiLiao_store_integral /
                                                      get_cuiLianCaiLiao_store_reward
  * `app/models/Action/FistFootShop.lua`           —— get_fistFootShop_info / buy_fistFootShop_dailyGoods /
                                                      buy_fistFootShop_specialOffer / set_fistFootShop_dailyCost
  * `app/models/Action/NewRandomGift.lua`          —— get_luck_box_list（幸运盒子/随机礼包）
  * `app/models/Action/NianBeast.lua`              —— get_expel_reward_list（年兽）
  * `app/views/layer/ActionLayer/ConsumeWingLayer.lua` + `DailyJiFuLayer.lua`
                                                   —— get_spend_plan_gift_list / receive_spend_plan_gift_list
  * `app/presenters/Activity/JiangHuDuoBaoPresenters.lua`（`payCurrencyInfo.desc/icon/price/buyLimit`）

内容来源（全部是**她自己的表**，不另造假数据）：
  * 商品货架：`res/script/activity/shoplist.lua` 的 `Sheet1` 键（"100001" 这种），
    已由 `work/tmp_actgoods.py` 抽成 `work/boot_templates/api_v5_activity_goods.json`（40 件带 icon/name/dsc）。
    ★ 给客户端当 `id` 的必须是这个**表键**，不是 `itemId`（`GoodsHelper:getGoodsResClass` 查的是键）。
  * 每日任务：`res/script/activity/dailyTask.lua` `Sheet1`（11 条真任务，读 id/taskid/name/dsc/points）
  * 仓库活动进度奖：`res/script/activity/wareHouseProgressAwards.lua` `Sheet1`（gift={商品id,数量}, condition）
  * 仓库活动随机奖：`res/script/activity/wareHouseRandomAwards.lua` `Sheet1`（gift/gifttype/weight/jackpottype）
  * 限时历练任务：`res/script/others/limitedTimeExperience.lua` `Sheet1`（tasktype/name/dsc/score/scondition）
  * 拳脚商店：`res/script/activity/fistFoot/dayConf.lua`（天数设定）/ `costConf.lua`（消耗设定）/
    `rewardConf.lua`（奖励设定 goodsId+price）
  * 名武录兑换：`res/script/others/jianghumingwulu.lua`；名人录兑换：`res/script/others/jianghuyirenlu.lua`

★ 三条铁律（踩过的坑）：
  1. 数值字段一个都不能少（`num/times/point/state/number/price/stock/...`）——少一个就是
     `attempt to compare nil`，被她的 xpcall 吞掉 ⇒ **客户端整体卡死**（不是弹窗）。
  2. 该是对象的不能给字符串（`currency` / `exchange_currency` / `buy_good` / `payCurrencyInfo`），
     该是数组的不能用 map（`button` / `detail_desc` / `gift_ids` / `rewards` / `list`）。
  3. `end_time` 必须是**未来**的 unix 秒；`progress_award_states` / 各 `state` / `dailySelectList`
     这些"改状态"的字段一律 `ctx.load_json/save_json` 落盘，再读是改过的值。

状态文件：`work/activities_state.json`（所有面板共用一份，按 action 名分组）。
"""
import json
import os
import re
import time

NAME = 'activities'
TITLE = '活动类面板（夺宝/名武录/名人录/藏经阁/仓库活动/限时历练/丹青阁/每日任务/醉仙楼/香囊秘格/淬炼商店/拳脚商店）'
ENDPOINTS = [
    # 江湖夺宝
    'get_lottery_treasure_list', 'buy_lottery_treasure_currency',
    'lottery_treasure_result', 'lottery_treasure_reward',
    # 名武录（旧珍品阁）
    'get_mingwu_lottery_list', 'do_mingwu_lottery', 'detection_goods', 'employ_materials',
    # 名人录
    'get_mingren_lottery_list',
    # 藏经阁
    'get_sutra_pavilion_list', 'get_sutra_pavilion_goods', 'buy_sutra_pavilion_goods',
    # 仓库活动
    'get_treasury_info', 'get_treasury_reward', 'treasury_lottery', 'enter_next_treasury',
    # 限时历练
    'get_training_task_list',
    # 丹青阁
    'get_danqing_pavilion_info', 'get_danqing_pavilion_reward', 'exchange_danqing_pavilion_item',
    # 每日任务
    'get_daily_task_list', 'get_daily_task_reward', 'add_daily_task_point',
    # 醉仙楼
    'get_toast_reward_list', 'get_toast_reward', 'toast_qian',
    # 香囊秘格
    'get_sachet_attic_new_list',
    # 淬炼材料商店
    'get_cuiLianCaiLiao_store_list', 'buy_cuiLianCaiLiao_store_goods',
    'exchange_cuiLianCaiLiao_store_integral', 'get_cuiLianCaiLiao_store_reward',
    # 拳脚商店 / 幸运盒子 / 年兽 / 消耗计划
    'get_fistFootShop_info', 'buy_fistFootShop_dailyGoods', 'buy_fistFootShop_specialOffer',
    'set_fistFootShop_dailyCost', 'get_luck_box_list', 'get_expel_reward_list',
    'receive_spend_plan_gift_list', 'get_spend_plan_gift_list',
]

STATE = 'activities_state.json'
RES_ROOT = _fz_res()

COLOR = re.compile(r'(HIG|HIY|HIB|HIM|HIR|CYN|YEL|BLU|GRN|NOR|RED|WHT)')
FAR_FUTURE = int(time.time()) + 365 * 86400


# ----------------------------------------------------------------------
# 通用工具
# ----------------------------------------------------------------------


def _int(v, d=0):
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return d


#: ★ 本模块历史上只有 `_int`；拳脚商店那批代码（照 `fist_main` 的风格写的）
#:   用的是 `_num` / `_s` ⇒ 这里给两个别名，别让 `NameError` 在运行时才炸。
_num = _int


def _s(v):
    return '' if v is None else str(v)


def _strip_color(s):
    return COLOR.sub('', s or '')


#: ★ 客户端 `Item:getOneItemByKey` 认的 **所有**表（`Item.lua:349-359`）：
#:     local itemResList = { "Items","drItems","drequipment","mask","equipment",
#:                           "homeland","appearance","created","fondDrItems" }
#:   外加 `:324` 的兜底 `storeItem.shangchengwupin`。
#:
#: ⚠️ 教训（2026-09-28 自查纠正）：我原来只查 `Items.lua` 一张表，
#:   于是把 **`mask.lua` 里的面具**（`mianju*`）、`drItems` 等表里的物品
#:   误判成"客户端不认" ⇒ 从货架目录里**误删了合法物品** ⇒ 活动面板点开是空的。
#:   现在按真实表集合合并。
_ITEM_TABLES = ('Items', 'drItems', 'drequipment', 'mask', 'equipment',
                'homeland', 'appearance', 'created', 'fondDrItems')
_ITEM_DIR = _fz_res('map', 'mapItemAttr')
_STOREITEM = _fz_res('store', 'storeItem.lua')
_VALID_ITEMIDS = None


def _valid_itemids():
    """客户端 `getOneItemByKey` 认得的所有 itemId（拿不到就回 None = 不校验）。"""
    global _VALID_ITEMIDS
    if _VALID_ITEMIDS is None:
        ids = set()
        try:
            import fz_luatable
            import os as _os
            for tb in _ITEM_TABLES:
                p = _os.path.join(_ITEM_DIR, tb + '.lua')
                if not _os.path.exists(p):
                    continue
                t = fz_luatable.load_lua_table(p) or {}
                sub = t.get('Sheet1') or t
                if not isinstance(sub, dict):
                    continue
                for k, v in sub.items():
                    if isinstance(v, dict) and v.get('id'):
                        ids.add(str(v['id']))
                    else:
                        ids.add(str(k))
            if _os.path.exists(_STOREITEM):
                si = fz_luatable.load_lua_table(_STOREITEM) or {}
                ids |= {str(k) for k in (si.get('shangchengwupin') or {})}
            # ★★ 我们自己往客户端表里加过的东西（测试礼包等）不在上面那几张**原版**表里，
            #    由 `work/fz_make_test_packs.py` 写进 `work/client_items_extra.json`。
            #    不并进来的话，货架会把这些合法物品当成"客户端不认"给筛掉。
            try:
                _extra_f = _os.path.join(_os.path.dirname(_os.path.dirname(
                    _os.path.abspath(__file__))), 'client_items_extra.json')
                if _os.path.exists(_extra_f):
                    import json as _json
                    with open(_extra_f, encoding='utf-8') as _fh:
                        ids |= {str(x) for x in (_json.load(_fh).get('items') or [])}
            except Exception:                     # noqa: BLE001
                pass
        except Exception as e:                    # noqa: BLE001
            print('[activities] itemId 表集合读取失败，跳过校验：%r' % e)
            _VALID_ITEMIDS = set()
        _VALID_ITEMIDS = ids or set()
    return _VALID_ITEMIDS or None


#: 已知**客户端真的不认**的 itemId（逐个人工核过，且不属于上面任何一张表）。
#: 目前为空 —— L3a 那次列的 `mianju*` / `qiannengdan` 等是**我误判**，
#: 它们在 `mask.lua` / `drItems.lua` 里，是合法物品。
_KNOWN_BAD_ITEMIDS = set()


def _itemid_ok(item_id):
    """这个 itemId 客户端认不认？"""
    iid = _s(item_id)
    if not iid or iid in _KNOWN_BAD_ITEMIDS:
        return False
    v = _valid_itemids()
    return True if v is None else (iid in v)


def _goods_catalog(ctx):
    """她 `activity/shoplist.lua` 抽出来的活动商品（40 件带 icon/name/dsc）。

    返回 [(id, itemId, name, dsc, icon), ...]，id 是**商品表键**。

    ★★ 2026-09-28 修：**过滤掉 itemId 客户端不认的条目**。
      之前这里是"有什么发什么"，于是把 `qiannengdan` / `yinpiao` / `mianju10xx`
      这类**不在 `Items.lua` 里的 itemId** 发给了客户端，
      客户端 `Item:getItemByKey` 拿到 nil ⇒ 面板在 `__dealWithRewardInfo` 里崩，
      表现就是老板说的「**面板打不开**」（藏经阁、江湖名人录都是这个死法）。
    """
    cache = getattr(_goods_catalog, '_cache', None)
    if cache is None:
        rows = []
        p = os.path.join(ctx.deps['here'], 'boot_templates',
                         'api_v5_activity_goods.json')
        try:
            with open(p, encoding='utf-8') as f:
                rows = json.load(f)
        except (OSError, ValueError):
            rows = []
        cache = []
        skipped = []
        for g in rows:
            if not g.get('id'):
                continue
            iid = _s(g.get('itemId'))
            if not _itemid_ok(iid):
                skipped.append(iid or '(空)')
                continue
            cache.append((str(g['id']), iid, _strip_color(g.get('name')),
                          _strip_color(g.get('dsc')), g.get('icon') or ''))
        if skipped:
            print('[activities] 物品目录剔除 %d 件（itemId 客户端不认）：%s'
                  % (len(skipped), ','.join(sorted(set(skipped))[:12])))
        _goods_catalog._cache = cache
    return cache



def _goods(ctx, idx=0):
    """按序号取一件活动商品（越界就绕回来），返回 dict 形式。"""
    cat = _goods_catalog(ctx)
    if not cat:
        return {'id': '100001', 'itemId': 'mianju1180', 'name': '江湖珍宝',
                'dsc': '', 'icon': 'Image/UI/StoreUI/mianju.png'}
    gid, item_id, name, dsc, icon = cat[idx % len(cat)]
    return {'id': gid, 'itemId': item_id, 'name': name, 'dsc': dsc, 'icon': icon}


def _goods_by_id(ctx, gid):
    """按商品表键找一件；找不到就绕到第 0 件（绝不给客户端一个查不到的 id）。"""
    cat = _goods_catalog(ctx)
    for i, row in enumerate(cat):
        if row[0] == str(gid):
            return _goods(ctx, i)
    try:
        return _goods(ctx, int(str(gid)) % max(1, len(cat)))
    except (TypeError, ValueError):
        return _goods(ctx, 0)


def _goods_n(ctx, start, n, step=1):
    """取 n 件不重复的商品（她表里 40 件足够铺满任何面板）。"""
    cat = _goods_catalog(ctx)
    total = max(1, len(cat))
    return [_goods(ctx, (start + i * step) % total) for i in range(n)]


def _pick_goods_ids(ctx, wanted, n):
    """优先用 wanted 里列的商品表键；凑不满就用货架顺序补齐。"""
    out = []
    cat_ids = {r[0] for r in _goods_catalog(ctx)}
    for gid in wanted:
        if len(out) >= n:
            break
        if str(gid) in cat_ids:
            out.append(str(gid))
    i = 0
    while len(out) < n:
        g = _goods(ctx, i)
        if g['id'] not in out:
            out.append(g['id'])
        i += 1
        if i > 200:
            break
    return out


def _lua_table(rel):
    """解析她 `res/script/**` 里的数据表（返回 Sheet1 或整表）。"""
    cache = getattr(_lua_table, '_cache', None)
    if cache is None:
        cache = {}
        _lua_table._cache = cache
    if rel in cache:
        return cache[rel]
    val = {}
    try:
        import fz_luatable
        t = fz_luatable.load_lua_table(os.path.join(RES_ROOT, rel))
        val = t.get('Sheet1') or t
    except Exception:                          # noqa: BLE001
        val = {}
    cache[rel] = val
    return val


def _lua_rows(rel):
    """把 Lua 表转成「有序行列表」（数字键的表按 key 排序）。"""
    t = _lua_table(rel)
    if isinstance(t, dict):
        keys = list(t.keys())
        try:
            keys.sort(key=lambda k: float(k))
        except (TypeError, ValueError):
            keys.sort(key=lambda k: str(k))
        return [t[k] for k in keys if isinstance(t[k], dict)]
    if isinstance(t, list):
        return [v for v in t if isinstance(v, dict)]
    return []


def _reward_goods(g):
    """她所有 `data.rewards` / `data.reward` / `prize` 都吃 `{id=商品表键, num=数量}`。

    ★★ 2026-10-03 教训：这条**只准喂"显示"路径**（`getGiftRewardText` 等
      `GoodsHelper:getGoodsResClass(id)` 按商品表键查名子的地方）。
      凡是客户端拿来 `role:addItemCount(id, n)` 的**发货**应答，
      `id` 必须是**真物品 id**（`g['itemId']`），否则客户端 9 张物品表查无此 id
      ⇒ 静默 return ⇒ 弹字照出、背包永远空（客户实测：醉梦生/丹青阁/天缘奇盒）。
      发货一律用 `_grant_goods`。
    """
    return {'id': g['id'], 'num': 1}


def _grant_goods(g, num=1):
    """发货版奖励条目（**仅限 A2 直发路径**）：`id` = **真物品 id**。

    ★★ 2026-10-03 二轮审计：客户端发货有两条路——
      A1 `GoodsHelper:fromNetworkGrantGoods`（藏经阁 CangJingGe.lua:232 / 醉仙楼
         DrinkMore.lua:136,286 / 府库 WareHouseActivity.lua:162 / 年兽 NianBeast / 历练）：
         按 **shoplist 商品键**查表换算入包 ⇒ 用 `_reward_goods`（商品键）；
      A2 模型回调直接 `addItemCount(v.id)`（夺宝 JiangHuDuoBao.lua:164 / 丹青阁
         DanQingGe.lua:131 / 奇盒 NewRandomGift.lua:157）：按真物品 id 查物品表 ⇒ 用本函数。
    """
    return {'id': g['itemId'], 'num': _num(num, 1), 'number': _num(num, 1),
            'name': g.get('name') or '', 'type': 1, 'icon': g.get('icon') or ''}


def _reward_entry(g, num=1):
    """丹青阁的 `showList` 条目走的是 **goodsId/name/num**（`DanQingGePresenter:109/132-133`）。"""
    return {'goodsId': g['id'], 'name': g['name'], 'num': num, 'id': g['id']}


# ===========================================================================
# ★★ 拳脚商店（活动名「通武积市」）—— 老板 2026-09-28 报「购买不成功」后完整实现
#
# 修复前那版是**假的**：货从全局活动商品表按下标凑数（发的 `300005 行功散` /
# `300006 洗颜水`），字段名是 `id`/`num`，也不扣元宝、不发资源。
#
# 她自己的三张配置表（`res/script/activity/fistFoot/`）才是准的：
#   costConf.lua   [消耗设定].yuanbao = {minlimit=200, maxlimit=2000, multiple=3,
#                                        rewards=[["1",25],["2",75]], icon=...}
#   rewardConf.lua [奖励设定] = {"1":{price=10, goodsId="400003"(固身元气)},
#                                "2":{price=20, goodsId="400008"(特性见解)}}
#   dayConf.lua    [天数设定] = {"1":{discount=100, probability=[90,6,4],
#                                     bonus=[100,110,120], rewards=[["1",25],["2",75]]}, ...}
#
# 数量公式（逐字抄她 `FistFootShop.lua`）：
#   每日：`ceilDayItemNum`  (:338-346)
#        num = floor(numAdd × daySelectCost × quota ÷ price)
#        其中 numAdd = dayConf.bonus[tierId]/100、quota = rewards[i][2]/100
#   特惠：`ceilSpecialOfferItemNum` (:356-362)
#        num = floor(discountRate × costNum × quota ÷ price)
#        costNum 上限 = daySelectCost × multiple(3)
#
# ★ `itype=6` = `SERVER_RESTORE_RES`（**服务端可回溯资源**）：
#   客户端 `GoodsHelper.__grantGood` 的 switch 里**没有 6 这个分支** ⇒ 它只
#   `PopText("获得xxx*N")` 做展示，**真发放必须服务端做**（本模块在此落账）。
# ===========================================================================
_FIST_REWARD_KEY = 'activity/fistFoot/rewardConf.lua'
_FIST_COST_KEY = 'activity/fistFoot/costConf.lua'
_FIST_DAY_KEY = 'activity/fistFoot/dayConf.lua'


def _fist_reward_conf():
    """`[奖励设定]` → {档id(str): {price:int, goodsId:str}}。"""
    t = _lua_table(_FIST_REWARD_KEY)
    return t.get('奖励设定') or {}


def _fist_cost_conf():
    """`[消耗设定].yuanbao` → 元宝范围/步长/占比/图标。"""
    t = _lua_table(_FIST_COST_KEY)
    return (t.get('消耗设定') or {}).get('yuanbao') or {}


def _fist_day_conf():
    """`[天数设定]` → {天id(str): 行}。"""
    t = _lua_table(_FIST_DAY_KEY)
    return t.get('天数设定') or {}


def _fist_quota():
    """道具占比：`costConf.rewards` 形如 `[["1",25],["2",75]]` ⇒ {'1':0.25,'2':0.75}。"""
    out = {}
    for pair in (_fist_cost_conf().get('rewards') or []):
        if isinstance(pair, (list, tuple)) and len(pair) >= 2:
            out[str(pair[0])] = _num(pair[1]) / 100.0
    return out or {'1': 0.25, '2': 0.75}


def _fist_reward_rows(nums):
    """`{档id: 数量}` → 客户端要的 `[{goodsId, number}]`。

    ★ 字段名必须 `goodsId` + `number`：`FistFootShopBuyDayConfirmPresenter.lua:71-77`
      读 `rewardData.goodsId` → `GoodsHelper:getGoodsResClass(goodsId)`（拿不到会 `error`），
      再读 `rewardData.number`。给成 `id`/`num` 客户端会**报错或显示 0**。
    """
    conf = _fist_reward_conf()
    out = []
    for rid, n in nums.items():
        c = conf.get(str(rid)) or {}
        gid = _s(c.get('goodsId'))
        if gid and n > 0:
            out.append({'goodsId': gid, 'number': int(n)})
    return out


def _fist_grant(ctx, nums):
    """真发资源：`400003`(固身元气=accpoint) / `400008`(特性见解=characterPoint)。

    走 `fist_main` 的账本（`accpoint` 在那边，`expedite_fist_task` 才用得上）；
    顺手也把 `400005/400006` 这类 `itype` 别的货记进日志，避免静默丢货。
    """
    got = []
    for rid, n in (nums or {}).items():
        c = _fist_reward_conf().get(str(rid)) or {}
        gid = _s(c.get('goodsId'))
        if not gid or n <= 0:
            continue
        if gid == '400003':
            _fist_add_resource(ctx, 'accpoint', n)
            got.append('固身元气×%d' % n)
        elif gid == '400008':
            _fist_add_resource(ctx, 'characterPoint', n)
            got.append('特性见解×%d' % n)
        else:
            got.append('%s×%d（未落账本）' % (gid, n))
    return got


def _fist_add_resource(ctx, key, n):
    """把数量加到 `fist_main` 的账本上（`accpoint` / `characterPoint`）。"""
    try:
        import fz_api.fist_main as _fm
        st = ctx.load_json(_fm.STATE, {}) or {}
        st[key] = _num(st.get(key)) + _num(n)
        _fm._bump(st)
        ctx.save_json(_fm.STATE, st)
        return True
    except Exception as e:                        # noqa: BLE001
        print('[拳脚商店] 发 %s×%s 失败：%r' % (key, n, e))
        return False
    

def _state(ctx):
    st = ctx.load_json(STATE, {})
    if not isinstance(st, dict):
        st = {}
    st.setdefault('duobao', {'currency': 5000, 'pay': 100, 'times': 0, 'state': 0,
                             'gem_idx': 0, 'bought': 0, 'rewarded': False})
    st.setdefault('mingwu', {'currency': 800, 'exchange': 200, 'times': 0,
                             'rewarded': []})
    st.setdefault('mingren', {'currency': 0, 'exchange': 60, 'mingtie': 21, 'times': 0})
    st.setdefault('cjg', {'buy_times': 0, 'state': {}, 'bought': []})
    st.setdefault('treasury', {'n1': 30, 'n2': 0, 'floor': 1, 'progress': {},
                               'drawn': {}})
    st.setdefault('training', {'point': 120, 'done': {}, 'got': {}, 'tasks': None})
    st.setdefault('danqing', {'currency': 60, 'state': {}, 'buy': {}})
    st.setdefault('daily', {'point': 0, 'state': {}, 'tasks': None, 'got': {}})
    st.setdefault('toast', {'count': 6, 'baiduo': 10, 'state': {}, 'drink': 0})
    st.setdefault('nian', {'count': 6, 'bianpao': 8, 'state': {}, 'drive': 0,
                           'claimed': {}})
    st.setdefault('sachet', {'currency': 40, 'level': {}, 'got': {}})
    st.setdefault('cuilian', {'integral': 120, 'bought': {}, 'stock': {}})
    st.setdefault('fist', {'dayCost': 200, 'discount': 100, 'dailySelect': [],
                           'specialState': 1})
    # ★★ 2026-10-03 老板定案：活动代币**直接常驻 99999**（不再依赖货币礼包入账——
    #   客户端镜像链路对旧装客户端不生效）。每次状态装载都强制回满 ⇒ 面板永远满额。
    st['nian']['bianpao'] = 99999                     # 鞭炮（驱赶年兽）
    st['sachet']['currency'] = 99999                  # 香囊钥匙（香囊秘格）
    st['toast']['baiduo'] = 99999                     # 佳酿/白堕（醉仙楼·举杯共饮）
    st['treasury']['n1'] = 99999                      # 密钥（地仓府库开箱）
    st.setdefault('luckbox', {'buy_times': 0, 'state': {}, 'idx': 0})
    st.setdefault('spend', {'money': 0, 'list': {}})
    return st


def _cur(gid, name, count):
    """`currency` / `exchange_currency` 是**对象**（她读 .id/.name/.count）。"""
    return {'id': gid, 'name': name, 'count': count}


def _gift_pool(ctx, start, kinds=3, per=3):
    """醉仙楼/年兽用的 `gifts_list`：map 键（字符串）→ 商品数组。
    ★ 值必须是**数组**且非空：`#v.gift_ids`、`v.gift_ids[1]`、`#rewards` 都会读。
    """
    out = {}
    for k in range(kinds):
        out[str(k + 1)] = [_reward_goods(g) for g in _goods_n(ctx, start + k * per, per)]
    return out


def _blank_map():
    """醉仙楼/年兽 `reserved_blank`：**键必须是 "1"/"10"/"50"**
    （`DrinkMorePresenters:202/214/226`、`NianBeastPresenters:131/143/155` 按这三个数字取）。
    """
    return {'1': 2, '10': 20, '50': 100, '2': 4, '5': 10}


def _reward_rows(ctx, start, n, rtype_split=None, count=None, claimed=None):
    """`{rid, state, gift_ids(数字数组，非空), rtype, award_limit}` —— 醉仙楼/年兽共用。
    ★ `gift_ids` 里的数字必须是 `gifts_list` 的**键**，否则 `getGiftRewardText` 取到 nil。
    ★ `rtype` 只能是 1（个人）或 2（集体），别的值两边的列表都不收。
    ★ 2026-10-03 修「年兽奖励领取不了」：原来 state 硬编码（rid 3-6 永远 0），
      客户端 `NianBeastPresenters:231` 见 state==0 直接拦"未达到对应的驱赶次数"，
      请求根本发不出去。现在传 `count`（驱赶进度）与 `claimed`（已领集合）进来：
      state = 2 已领 / 1 进度达标可领 / 0 未达标。
    """
    rows = []
    for i in range(n):
        rid = i + 1
        limit = (i + 1) * 5
        if count is None:
            state = 1 if i < 2 else 0
        else:
            if claimed and str(rid) in claimed:
                state = 2
            else:
                state = 1 if _int(count, 0) >= limit else 0
        rows.append({
            'rid': rid, 'state': state,
            # 前两条给两个组合奖励（走多选界面），其余给单个
            'gift_ids': [1, 2] if i == 0 else [i % 3 + 1],
            'rtype': 1 if i < 3 else 2,
            'award_limit': limit,
            'exchange_id': 3 if i == 1 else None,
        })
    return rows


# ----------------------------------------------------------------------
# 江湖夺宝  `app/models/Action/JiangHuDuoBao.lua`
# ----------------------------------------------------------------------
def _duobao(ctx):
    return _duobao_detail(ctx, None)


def _duobao_detail(ctx, st):
    """`JiangHuDuoBao:init`（:40-87）读的字段，一个不少。

    ★ 容易翻车的几处（都有 presenter / UI 行号）：
      - `lottery_gem.rewardType` 必给（`MDB:143`）；`lottery_gem.rewards[1]` 必须存在
        （`PDB:104`）；同一对象还当奖励面板用，读 `.icon/.text`（`UDB:160-163`）。
      - `gem_list` 条目：`.level` 只能是 **1/2/3**（`MDB:264` 查 LEVELNAME 的键），
        `.num` 必给（`UDB:137 "剩余："..tostring(itemInfo.num)`），
        `.rewards` 是 `[{rid=...}]`（`PDB:115-116`），`.icon/.text` 给 UI。
      - `payCurrencyInfo` 四个字段都要数字/字符串：`buyLimit` 参与
        `maxBuyNumber - buyNumber >= 1` 算术（`BuyCurrencyPresenter:114`），`price` 参与乘法。
      - `is_empty_pool` 命名是**反的**：`checkIsEmptyPool()` 在 `== 0` 时返回 true
        （`MDB:150`）⇒ 有奖池要给 **1**。
    """
    if st is None:
        st = _state(ctx)
    d = st['duobao']
    gems = []
    for i in range(9):
        g = _goods(ctx, i + 3)
        gems.append({
            'level': i % 3 + 1, 'rid': g['id'], 'id': g['id'], 'itemId': g['itemId'],
            'name': g['name'], 'icon': g['icon'], 'number': 1, 'num': 1,
            'text': g['name'], 'type': 1, 'showType': 1,
            'rewards': [{'rid': g['id'], 'id': g['id'], 'name': g['name'],
                         'icon': g['icon'], 'number': 1, 'type': 1}],
        })
    cur = gems[d['gem_idx'] % len(gems)]
    # `checkRewardTypeIsSelect` 读 `_rewardInfo.rewardType`；==2 弹多选界面
    gem = {'rewardType': 1, 'text': cur['name'], 'icon': cur['icon'],
           'rewards': [{'rid': cur['rid'], 'id': cur['id'], 'name': cur['name'],
                        'icon': cur['icon'], 'number': 1, 'type': 1, 'num': 1}]}
    pay = _goods(ctx, 2)
    return {
        'act_name': '江湖夺宝', 'name': '江湖夺宝',
        'detail_desc': ['消耗夺宝令抽取珍宝，抽满必得传说珍宝。',
                        '夺宝令可在商城用元宝购买。'],
        # ★ curr_lottery_times/currency_num/pay_num/lottery_status 都是数字，少一个就 attempt to compare
        'currency_name': '夺宝令', 'currency_num': d['currency'],
        'curr_lottery_times': d['times'], 'pay_num': d['pay'],
        'pay_currency_type': 'money', 'pay_currency_num': d['currency'],
        'lottery_status': d['state'],
        'lottery_gem': gem,
        # `getPayCurrencyName/getPayCurrencyBuyLimit/BuyCurrencyPresenter` 读 .name/.buyLimit/.desc/.icon/.price
        'currencyVersion': 0,
        'payCurrencyInfo': {
            'id': 'duobaoling', 'name': '夺宝令', 'count': d['currency'],
            'price': 50, 'buyLimit': 99, 'desc': '使用后可参与江湖夺宝一次。',
            'icon': pay['icon'] or 'Image/UI/StoreUI/lingpai2.png',
        },
        # ★ 有奖池 = 1（命名是反的）
        'is_empty_pool': 1,
        'gem_list': gems,
    }


# ----------------------------------------------------------------------
# 名武录 / 名人录  `JiangHuMingWuLuAction.lua` / `JiangHuYiRenLuAction.lua`
# ----------------------------------------------------------------------
def _exchange_conf(rel):
    """她 `jianghumingwulu.lua` / `jianghuyirenlu.lua` 的兑换配置行。"""
    rows = _lua_rows(rel)
    out = []
    for i, r in enumerate(rows[:8]):
        gid = r.get('goodsId') or r.get('id')
        out.append({
            'id': r.get('id') or (i + 1),
            'itemId': r.get('itemId') or '',
            'name': _strip_color(r.get('name')) or '名人馈赠',
            'title': _strip_color(r.get('title')) or '',
            'introText': _strip_color(r.get('introText')) or '',
            'thankText': '',
            'need': _int(r.get('need'), (i + 1) * 10),
            'pic': r.get('pic') or '',
            'mianju': r.get('mianju') or '',
            'rewardType': 1,
            'goodsId': str(gid) if gid is not None else '',
            'time': _int(r.get('time'), 0),
        })
    return out


def _mingwu_body(ctx, act_id, st, is_mingren):
    """名武录（`JiangHuMingWuLuAction:init` :131-189）与名人录（`JiangHuYiRenLuAction:init` :92-135）
    读的是**同一套**字段：
      act_id / act_name / detail_time(必给，`desc = desc .. data.detail_time .. "\\n"`) /
      detail_desc(数组) / end_time / lottery_list / act_times(数字) /
      button（**至少 2 条**，两边 presenter 都是 `for i = 1, 2`）/
      exchange_currency{id,name,count} / currency{id,name,count} / buy_good{id,itemId,name}

    ★★ 两个名字相同但**类型相反**的坑：
      - `lottery_list` 的条目她 UI 只读 `.name/.icon/.number/.showType`
        （`JiangHuYiRenLuAction2UI:74/80`）—— 读的是 `number`，不是 `num`！
      - `button` 条目名不一样：名武录读 `.removeCurrency`（`MMW:318`），
        名人录读 `.removeYb`（`PYR:125`）⇒ 两个键都给上。
      - `act_times` 必须等于她本地兑换表 `jianghumingwulu/yirenlu` 里的 `time` 值，
        给错了兑换列表就是空的（⇒ `getExchangeRewardInfo(1)` 返回 nil ⇒ 崩）。表里是 **1**。
      - 名人录额外读 `baifangmingtie`(tonumber) 和 `yuanbao`(数字)。
    """
    key = 'mingren' if is_mingren else 'mingwu'
    d = st[key]
    conf = _exchange_conf('others/jianghuyirenlu.lua' if is_mingren
                          else 'others/jianghumingwulu.lua')
    lottery = []
    for i, g in enumerate(_goods_n(ctx, 4, 8)):
        lottery.append({
            'id': g['id'], 'itemId': g['itemId'], 'name': g['name'], 'icon': g['icon'],
            'number': 1, 'num': 1, 'itype': 1, 'inde': 0, 'price': (i + 1) * 10,
            'dsc1': g['dsc'], 'dsc2': g['dsc'][:24], 'share': '',
            'to': 0, 'from': 0, 'showType': 1 if i < 4 else 0, 'prob': 1.0 / 8,
        })
    cur_name = '异人名帖' if is_mingren else '江湖令'
    exc_name = '拜会名帖' if is_mingren else '武学名录'
    body = {
        'act_id': act_id, 'act_name': '江湖名人录' if is_mingren else '江湖名武录',
        'detail_time': '长期开放', 'detail_desc': [
            '每次抽奖必定获得一件武学珍宝。' if not is_mingren else '每次抽奖必定获得一件异人珍宝。',
            '抽奖获得的兑换币可在下方兑换珍稀奖励。'],
        'end_time': FAR_FUTURE,
        'lottery_list': lottery,
        'exchange_currency': _cur('yirenitem1' if is_mingren else 'wuxueminglu',
                                  exc_name, d.get('exchange', 0)),
        'currency': _cur('yirenitem1' if is_mingren else 'jianghuling', cur_name, d['currency']),
        'buy_good': {'id': 5580, 'itemId': 'yxjianghuling1', 'name': cur_name},
        # ★ 两边 presenter 都写死 index 1/2；`times` 要参与 `-`/`<`/`..`，`removeCurrency`/`removeYb` 同理
        'button': [
            {'name': '抽一次', 'times': 1, 'removeCurrency': 80, 'removeYb': 80,
             'imagePath': 'Image/UI/StoreUI/lingpai2.png'},
            {'name': '抽五次', 'times': 5, 'removeCurrency': 400, 'removeYb': 400,
             'imagePath': 'Image/UI/StoreUI/lingpai2.png'},
        ],
        # ★ 必须等于她本地兑换表里的 time（那张表 time=1 的条目最多）
        'act_times': 1,
    }
    if is_mingren:
        # `JiangHuYiRenLuAction:init` 读 `tonumber(data.baifangmingtie)` 和 `data.yuanbao`
        body['baifangmingtie'] = d['mingtie']
        body['yuanbao'] = 9999
    return body, conf, lottery


def _exchange_note(conf):
    """把兑换配置里能用的挑出来（兑换列表她是从**客户端**表建的，
    服务端只需保证 currency/exchange_currency/act_times 对得上）。"""
    return [c for c in conf if c.get('need') is not None][:6]


# ----------------------------------------------------------------------
# 藏经阁  `CangJingGe.lua`（★ 客户端跑的是**覆盖层**版本，契约见 `_cjg_list`）
# ----------------------------------------------------------------------
#: 雅士折扣信息：`discount` 是**降价比例**（UI 文案「残页降价10%」⇒ 0.1），
#: `count` 是每个档位可用折扣的次数。缺这个字段会让覆盖层的 presenter 崩。
_CJG_YASHI_DISCOUNT = {'discount': 0.1, 'count': 1}

_SKILL_KEYS = None


def _skill_keys():
    """`skill/skill.lua` 里所有武学 id（判"这个物品带的是不是一门真武学"）。"""
    global _SKILL_KEYS
    if _SKILL_KEYS is None:
        keys = set()
        try:
            import fz_luatable
            t = fz_luatable.load_lua_table(os.path.join(RES_ROOT, 'skill', 'skill.lua')) or {}
            sub = t.get('skills') or t
            if isinstance(sub, dict):
                for k, v in sub.items():
                    if isinstance(v, dict) and v.get('id'):
                        keys.add(str(v['id']))
                    else:
                        keys.add(str(k))
        except Exception as e:                    # noqa: BLE001
            print('[activities] skill.lua 读取失败，藏经阁不按 skillid 过滤：%r' % e)
        _SKILL_KEYS = keys or None
    return _SKILL_KEYS


def _item_skill_ok(item_id):
    """客户端 `CangJingGe.lua:313-323` 会 `Item → skillid → Skill:getSkill → .name`，
    itemAttr 或 skill 任一为 nil 就崩（面板打不开）⇒ 藏经阁只发"带真 skillid"的物品。"""
    iid = _s(item_id)
    if not iid or not _itemid_ok(iid):
        return False
    try:
        import fz_api.items_currency as _ic
        raw = _ic._lua_item(iid) or {}
        sid = _s(raw.get('skillid'))
        keys = _skill_keys()
        return bool(sid) and (keys is None or sid in keys)
    except Exception:                             # noqa: BLE001
        return False


def _cjg_catalog(ctx):
    """藏经阁专用目录：**shoplist 商品**里"itemId 带真武学 skillid"的那批（书页/秘籍类）。

    ★ 两个硬条件（2026-10-03 二轮排查定的）：
      1. goodsId 必须是 **shoplist 键**——客户端 `GoodsHelper:getGoodsResClass(goodsId)`
         只认它，找不到直接 error；
      2. 该商品 itemId 指向的**物品**必须带 `skillid` 且能对上 `skill.lua`——
         客户端还要 `Item.skillid → Skill:getSkill → .name` 一路取下去。
      （第一版只按条件 2 从活动 40 件目录里筛 ⇒ 一件都不剩 ⇒ 兜底又放回全量，
        等于没修。现在直接从她 shoplist 全表扫，合格商品 247 件。）
    """
    cache = getattr(_cjg_catalog, '_cache', None)
    if cache is None:
        cache = []
        try:
            import fz_api.action_festival as _af
            for g in _af._cat():
                if not _item_skill_ok(g.get('itemId')):
                    continue
                cache.append((str(g['id']), str(g['itemId']),
                              _strip_color(g.get('name')), _strip_color(g.get('dsc')),
                              g.get('icon') or ''))
        except Exception as e:                    # noqa: BLE001
            print('[activities] 藏经阁目录扫描失败：%r' % e)
        if not cache:                              # 全被筛光的兜底（不该发生）
            cache = list(_goods_catalog(ctx))
        print('[activities] 藏经阁目录：%d 件（带真 skillid 的 shoplist 商品）' % len(cache))
        _cjg_catalog._cache = cache
    return cache


def _cjg_goods(ctx, idx=0):
    cat = _cjg_catalog(ctx)
    gid, item_id, name, dsc, icon = cat[idx % len(cat)]
    return {'id': gid, 'itemId': item_id, 'name': name, 'dsc': dsc, 'icon': icon}


def _cjg_goods_n(ctx, start, n):
    total = max(1, len(_cjg_catalog(ctx)))
    return [_cjg_goods(ctx, (start + i) % total) for i in range(n)]


def _cjg_goods_by_id(ctx, gid):
    """按商品键在**藏经阁目录**（247 件）里取一件；找不到回第 0 件。

    ★★ 2026-10-03 修「藏经阁买完没生效」第二层：购买/领取原来用 `_goods_by_id`
      （**40 件活动目录**），货架键（如 500577）不在里面 ⇒ `int(rid) % 40` 取模
      落到别的商品 —— 扣钱发错货、state 键对不上货架行 ⇒ 面板永远 state=0。
    """
    cat = _cjg_catalog(ctx)
    want = _s(gid)
    for i, row in enumerate(cat):
        if row[0] == want:
            return _cjg_goods(ctx, i)
    return _cjg_goods(ctx, 0)


def _cjg_list(ctx, st):
    """`CangJingGe:init` + `__dealWithRewardInfo`（**覆盖层版本**，比 APK 版新）。

    ★★ 老板 2026-09-28 报「藏经阁点不开」。根因：**客户端跑的是热更新覆盖层的
      `CangJingGe.lua` / `CangJingGePresenter.lua`**（`ls` 确认在
      `updatePath_android_2.1.02/src/app/...`，9/27 更新过），它比 APK 反编译版多要一个字段：

        `CangJingGe.lua:92`      self._yaShiDiscountInfo = data.yashiDiscountInfo
        `CangJingGePresenter:130` local discountInfo = getYaShiDiscountInfo()
        `CangJingGePresenter:131` local discount = math.floor(discountInfo.discount*100)  ← 崩在这
        `CangJingGe.lua:279`      _yaShiBuyInfo[...] < self._yaShiDiscountInfo.count

      `data.yashiDiscountInfo` 没下发 ⇒ 它是 **nil** ⇒ `:131` 读 `.discount` 抛
      `attempt to index a nil value` ⇒ `__initUI` 中断 ⇒ **面板打不开**。

      语义（从 UI 文案反推，`res/Layer/ActionUI/CangJingGeUI.lua:328` 写「残页降价**10%**」）：
        `yashiDiscountInfo = {'discount': 降价比例, 'count': 雅士折扣可用次数}`
        * `discount` 给 **0.1**（= 降价 10%）⇒ 客户端 `floor(0.1*100)=10`，与文案一致；
        * `count` 给 **1**（每个档位可用 1 次折扣）。

      另外 `discountPrice`（客户端**只显示、不重算**，`CangJingGe.lua:287/304`）
      要与 `discount` 自洽 ⇒ 给 `floor(原价 × 0.9)`。
    """
    d = st['cjg']
    rows, pool = [], []
    # ★ 2026-10-03 修「藏经阁打不开」第二轮：itemId 校验后仍崩——
    #   `CangJingGe.lua:313-323` 还要 `Item.skillid → Skill:getSkill(itemAttr.skillid) → .name`，
    #   物品没带 skillid（或指向不存在的武学）就 nil 崩。货架/奖池只从"带真武学"的目录里挑。
    for i, g in enumerate(_cjg_goods_n(ctx, 8, 12)):
        state = _int(d['state'].get(g['id']), 0)
        orig = 150 + i * 10
        rows.append({
            'id': g['id'], 'goodsId': g['id'], 'number': 1,
            'levelType': i % 5 + 1, 'state': state,
            'price': 100 + i * 10,
            # ★ 与 yashiDiscountInfo.discount(0.1) 自洽：雅士价 = 原价 × 0.9
            'discountPrice': int(orig * 0.9),
            'originalCost': orig, 'currencyName': '元宝',
            'stock': 10 - (i % 5),
            # ★ 2026-10-03：state=1（已购待领）时客户端
            #   `CangJingGePresenter:214 checkCanGetReward(v.rewards)` 读它判背包 ⇒ 必须给
            'rewards': [{'id': g['id'], 'num': 1}],
        })
    for i, g in enumerate(_cjg_goods_n(ctx, 20, 10)):
        pool.append({'levelType': i % 5 + 1, 'goodsId': g['id'], 'number': 1})
    yashi = {}
    for lv in range(1, 6):
        yashi[str(lv)] = {str(n): (1 if (lv + n) % 2 == 0 else 0) for n in (1, 3, 5)}
    return {
        'act_name': '藏经阁', 'detail_desc': ['用元宝购买武学残页，每日可购买多次。',
                                            '江湖雅士购买残页享折扣。'],
        'buy_times': d['buy_times'], 'buy_limit': 30,
        'refresh_currency': 'yuanbao', 'refresh_cost': 100,
        'yashiDiscountStatus': yashi, 'yashiExpiredTime': FAR_FUTURE,
        # ★★ 覆盖层必需：缺了它 `CangJingGePresenter:131` 直接崩（面板打不开）
        'yashiDiscountInfo': _CJG_YASHI_DISCOUNT,
        'list': rows, 'rewardPool': pool,
    }


# ----------------------------------------------------------------------
# 仓库活动（地仓府库）  `WareHouseActivity.lua`
# ----------------------------------------------------------------------
def _treasury_info(ctx, st):
    """`WareHouseActivity:getActionInfo`（:33-75）读：
      act_name / detail_desc(数组) / help_desc / secret_num1 / secret_num2 /
      progress_award_states（**数组**，1-based 索引 = `script/activity/wareHouseProgressAwards.lua`
        的行号，值 0未达标/1可领/2已领；`WareHousePresentrs:100` 是 `states[i]`，给少了 index-of-nil）/
      random_award_list{floorNum, random_awards}
    ★ `random_awards` 必须**至少 9 条**（`WareHousePresentrs:172` 是 `for i = 1, 9`），
      每条读 `state`（0 关着 / 非 0 已开）与 `awardId`（非 0 时才能是 nil，
      `getRandomAwardRes(awardId)` 查的是 `wareHouseRandomAwards[tonumber(id)]` 的键）。
      `id` 客户端**不读**（只给服务端自己对账用）。
    """
    d = st['treasury']
    prog = _lua_rows('activity/wareHouseProgressAwards.lua')
    rnd = _lua_rows('activity/wareHouseRandomAwards.lua')
    n_prog = max(6, len(prog))
    states = [_int(d['progress'].get(str(i + 1)), 0) for i in range(n_prog)]
    awards = []
    for i in range(12):
        row = rnd[i] if i < len(rnd) else {}
        gift = row.get('gift') or []
        # ★ awardId 必须是 wareHouseRandomAwards 的**键**（1-based 行号）
        aid = i + 1 if i < len(rnd) else 0
        g = _goods_by_id(ctx, gift[0]) if gift else _goods(ctx, i)
        awards.append({
            'id': i + 1, 'state': _int(d['drawn'].get(str(i + 1)), 0),
            'awardId': aid, 'num': _int(gift[1], 1) if gift else 0,
            'gifttype': _int(row.get('gifttype'), 1),
            'jackpottype': _int(row.get('jackpottype'), 1),
            'icon': g['icon'], 'name': g['name'],
            'comment': _strip_color(row.get('comment')) or g['name'],
        })
    return {
        'act_name': '地仓府库', 'detail_desc': ['消耗密钥开启宝箱，逐层深入府库。',
                                              '每层都有大奖，通关可得进度奖励。'],
        'help_desc': '密钥可通过日常活动获得。',
        'secret_num1': d['n1'], 'secret_num2': d['n2'],
        'progress_award_states': states,
        'random_award_list': {'floorNum': d['floor'], 'random_awards': awards},
    }


# ----------------------------------------------------------------------
# 限时历练  `LimitedTimeExperience.lua`
# ----------------------------------------------------------------------
def _training_info(ctx, st):
    """`getTrainingTaskList` 回调（:52-88）读：
      act_name / detail_desc(数组) / point / refresh_cost / completion_times / task_limit /
      reward_list[{rid,state,grade,reward_ids,exchange_id}] /
      reward_pool_list（map：tostring(rid) -> 商品数组）/
      task_list[{id,state,name,desc,score}]
    ★ `reward_ids` 必须是**数字数组**：`LimitedTimeExperiencePresenters:109/119` 读
      `#rewardIds > 1`、`rewardIds[1]`、`pairs(giftIdList)`。
    ★ `grade` 进 `v.grade.."积分"` 和排序比较，必给数字。
    """
    d = st['training']
    cfg = _lua_rows('others/limitedTimeExperience.lua')
    tasks = []
    pool = {}
    for i in range(3):
        row = cfg[i % len(cfg)] if cfg else {}
        tasks.append({
            'id': i + 1,
            'state': _int(d['done'].get(str(i + 1)), 1 if i == 0 else 0),
            'name': _strip_color(row.get('name')) or ('历练任务%d' % (i + 1)),
            'desc': _strip_color(row.get('dsc')) or '完成指定历练目标。',
            'score': _int(row.get('score'), 20 + i * 10),
            'tasktype': row.get('tasktype') or '',
        })
    rl = []
    for i in range(4):
        rid = i + 1
        pool[str(rid)] = [_reward_goods(g) for g in _goods_n(ctx, 30 + i * 2, 2)]
        rl.append({'rid': rid, 'state': _int(d['got'].get(str(rid)), 1 if i == 0 else 0),
                   'grade': i + 1, 'reward_ids': [rid], 'exchange_id': rid,
                   'reward': pool[str(rid)]})
    return {
        'act_name': '限时历练', 'detail_desc': ['完成任务获得历练分，累积历练分领取奖励。',
                                              '历练分越高奖励越好。'],
        'point': d['point'], 'refresh_cost': 100,
        'completion_times': len([t for t in tasks if t['state'] == 1]),
        'task_limit': 3, 'reward_list': rl, 'reward_pool_list': pool,
        'task_list': tasks, 'tasktype_pool': [t.get('tasktype') for t in tasks if t.get('tasktype')],
    }


# ----------------------------------------------------------------------
# 丹青阁  `DanQingGe.lua`
# ----------------------------------------------------------------------
#: 丹青阁用的币种 id —— **必须**是客户端 `res/script/others/monetarymanagement.lua`
#: 里真有的键（`CurrencyUtil:getCurrencyName` 对未知 id 会 `assert` 崩）。
#: 那张表 22 个币种里没有"丹青积分"，而丹青阁发的是武学残页 ⇒ 用 `canyechoice`（醉仙武意）。
_DANQING_CURRENCY_ID = 'canyechoice'

#: 客户端币种表（id → {name, icon, ...}），只读一次
_CURRENCY_TAB = None


def _currency_res():
    """读客户端 `others/monetarymanagement.lua` 的 `Sheet1`（id → 币种行）。"""
    global _CURRENCY_TAB
    if _CURRENCY_TAB is None:
        try:
            t = _lua_table('others/monetarymanagement.lua')
            _CURRENCY_TAB = (t.get('Sheet1') or t) if isinstance(t, dict) else {}
        except Exception:                         # noqa: BLE001
            _CURRENCY_TAB = {}
    return _CURRENCY_TAB


def _currency_display_name(cid):
    """币种显示名（客户端认不出这个 id 就直接回 id，便于发现错误）。"""
    row = _currency_res().get(_s(cid)) or {}
    return _s(row.get('name')) or _s(cid)


def _currency_entry(cid, num):
    """`data.currencyList` 的条目：覆盖层 `getCurrencyNumByCurrencyId` 找 `v.id == cid`、读 `v.num`。"""
    row = _currency_res().get(_s(cid)) or {}
    return {'id': _s(cid), 'name': _s(row.get('name')) or _s(cid),
            'num': _num(num), 'icon': _s(row.get('icon')), 'unit': _s(cid)}


def _query_currency(ctx, cid):
    """从**真钱袋**查币值（`items_currency`，落在 `homeland_state.json`）。

    ★ 别在活动自己的 state 里另存一份余额 —— 那会造成"两份账"
      （面板显示 0、实际有钱，或反过来）。这条以前踩过。
    """
    try:
        import fz_api.items_currency as _ic
        return _num(_ic.get_currency(ctx, cid))
    except Exception as e:                        # noqa: BLE001
        print('[activities] 查币 %s 失败：%r' % (cid, e))
        return 0


def _danqing_list(ctx, st):
    """`DanQingGe:init` + `__dealWithList` 的**覆盖层版本**契约。

    ★★ 老板 2026-09-28 报「丹青阁点击了没反应」。根因：
      **客户端实际跑的是热更新覆盖层的 `DanQingGe.lua`，比 APK 反编译版新。**
      覆盖层多了一套"按币种 id 查名"的机制：
        `DanQingGe.lua:62   self._currencyList = data.currencyList`    ← 我原来没下发
        `DanQingGe.lua:83   getCurrencyNameByCurrencyId(id) → CurrencyUtil:getCurrencyName(id)`
        `DanQingGePresenter.lua:86 读 itemInfo.currencyId`             ← 我原来没下发
      `CurrencyUtil:getCurrencyName` 对 nil **直接 assert 失败**
      （`CurrencyUtil.lua:103`）⇒ `__initUI` 中断 ⇒ **面板打不开**。
      logcat 证据：
        `CurrencyUtil.lua:103 in 'getCurrencyNameByCurrencyId'`
        `DanQingGePresenter.lua:86 in '__initUI'`

    ⚠️ **`currencyId` 必须是客户端 `res/script/others/monetarymanagement.lua` 里
       真有的键**（那张表一共 22 个）。服务端原来给的 `currency_name='丹青积分'`
       **不在表里**，是我编的字符串。丹青阁发的是武学残页 ⇒ 用
       **`canyechoice`（醉仙武意）** 最贴切。

    覆盖层还要 `discount` / `rewardNumber` / `reduplicate` / `retrievaltype`（给全）。
    """
    d = st['danqing']
    cur_id = _DANQING_CURRENCY_ID
    cur_name = _currency_display_name(cur_id)
    out = []
    for i in range(4):
        rid = str(i + 1)
        rewards = [_reward_entry(g, 1) for g in _goods_n(ctx, 32 + i * 2, 2)]
        out.append({
            'id': i + 1, 'text': '珍品奖励%d' % (i + 1),
            'state': _int(d['state'].get(str(i + 1)), 1 if i == 0 else 0),
            'rewardType': 1 if i % 2 == 0 else 2,
            'price': 20 + i * 10, 'buyTimes': _int(d['buy'].get(str(i + 1)), 0),
            'totalTimes': 3, 'reward': rewards,
            'showList': {rid: rewards},
            # ★ 覆盖层新增字段：缺 `currencyId` 会在 __initUI 里 assert 崩
            'currencyId': cur_id, 'discount': 1.0,
            'rewardNumber': 1, 'reduplicate': 0, 'retrievaltype': 0,
        })
    return {
        'act_name': '丹青阁',
        'detail_desc': ['用%s兑换名家真迹。' % cur_name, '每日可兑换次数有限。'],
        # 覆盖层已不用 currency_name/currency_number，留着不碍事
        'currency_name': cur_name, 'currency_number': _query_currency(ctx, cur_id),
        # ★ `getCurrencyNumByCurrencyId` 用 `ipairs(data.currencyList)` 找 `v.id == currencyId`
        #   读 `v.num` —— **这个数必须来自真钱袋**（`items_currency`），
        #   不能另存一份（老板之前吃过"两份账"的亏：面板显示 0、实际有钱）。
        'currencyList': [_currency_entry(cur_id, _query_currency(ctx, cur_id))],
        'list': out,
    }


# ----------------------------------------------------------------------
# 每日任务  `DailyTasksActivity.lua`
# ----------------------------------------------------------------------
def _daily_info(ctx, st):
    """`DailyTasksActivity:init`（:34-63）读：
      act_name / detail_desc(数组) / daily_point / task_list / reward_list
    ★★ `task_list` 的条目字段是 **`tid`**，不是 `id`！
      `DailyTasksActivityPresenters:70-72` 是 `local id = v.tid` 然后
      `getTaskConfig(v.tid)` —— 给 `id` 的话 `task` 是 nil，紧接着 `task.name` 直接崩。
      名字/描述/积分她是从**本地** `script.activity.dailyTask` 取的（服务端只回 tid+state）。
    ★ `reward_list` 条目读 `state`/`rid`/`grade`/`reward`（`reward` 是 1..n 连续数组）。
    ★ 一个 `state` 表管两边：`d['state'][tid]` 是任务状态，`d['got'][rid]` 是宝箱领取状态，
      两者用**同一套全局 id**（1..11 任务 / 101.. 宝箱），所以领奖后再读面板状态是改过的。
    """
    d = st['daily']
    cfg = _lua_rows('activity/dailyTask.lua')
    tasks = []
    for i, row in enumerate(cfg):
        tid = _int(row.get('id'), i + 1)
        tasks.append({
            'tid': tid, 'id': tid,
            'state': _int(d['state'].get(str(tid)), 0),
            'name': _strip_color(row.get('name')) or ('每日任务%d' % tid),
            'desc': _strip_color(row.get('dsc')) or '',
            'score': _int(row.get('points'), 10),
            'points': _int(row.get('points'), 10),
        })
    rl = []
    for i in range(4):
        # ★ 宝箱 id 用 101.. 段，避免和任务 id 1..11 撞键
        rid = 101 + i
        rewards = [_reward_goods(g) for g in _goods_n(ctx, 34 + i * 2, 2)]
        rl.append({'rid': rid,
                   'state': _int(d.get('got', {}).get(str(rid)), 1 if i == 0 else 0),
                   'grade': (i + 1) * 20, 'point': (i + 1) * 20,
                   'reward': rewards, 'reward_ids': [rid]})
    return {
        'act_name': '每日任务', 'detail_desc': ['完成每日任务累积活跃积分。',
                                              '积分达标可领取宝箱奖励。'],
        'daily_point': d['point'], 'task_list': tasks, 'reward_list': rl,
    }


# ----------------------------------------------------------------------
# 醉仙楼 / 年兽  `DrinkMore.lua` / `NianBeast.lua`
# ----------------------------------------------------------------------
def _toast_info(ctx, st):
    """`DrinkMore:getActionInfo`（:46-88）读：
      act_name / detail_desc(数组) / help_desc / personal_count / collective_count /
      baiduo(数字) / reserved_blank（map: tostring(num)->数字） / is_toast(布尔) /
      gifts_list（map: tostring(giftId)->商品数组） /
      list[{rid,state,gift_ids(数字数组),rtype,award_limit,exchange_id}] /
      expel_reward（商品数组）
    ★ `#v.gift_ids > 1`、`v.gift_ids[1]` ⇒ gift_ids 必须是**非空数字数组**；
      里面的数字还得是 `gifts_list` 的键（`getGiftRewardText` 取不到就 nil）。
    ★ `reserved_blank` 的键必须是 "1"/"10"/"50"（`DrinkMorePresenters:202/214/226`）。
    ★ `rtype` 只能 1/2，别的值两边的列表都不收（面板空白）。
    """
    d = st['toast']
    return {
        'act_name': '醉仙楼', 'detail_desc': ['共饮一次可获得奖励，共饮次数越多奖励越好。',
                                             '组团共饮可领取团队奖励。'],
        'help_desc': '共饮需要消耗酒钱，酒钱可用碎银购买。',
        'personal_count': d['count'], 'collective_count': max(0, d['count'] - 2),
        'baiduo': d['baiduo'], 'reserved_blank': _blank_map(), 'is_toast': False,
        'gifts_list': _gift_pool(ctx, 36),
        'list': _reward_rows(ctx, 36, 6),
        'expel_reward': [_reward_goods(g) for g in _goods_n(ctx, 38, 3)],
    }


def _nian_info(ctx, st):
    """`NianBeast:getActionInfo`（:50-88）读：跟醉仙楼同一套，
    但数字字段叫 `bianpao`（不是 `baiduo`）；年兽没有 `is_toast`。

    ★ 2026-10-03：`count` 现在会随"驱赶年兽"真涨（`action_festival._h_expel_nian`
      也写这份状态），档位 state 按进度/已领集合算——不再永远 0。
    """
    d = st['nian']
    return {
        'act_name': '年兽', 'detail_desc': ['用爆竹驱赶年兽，驱赶成功可得奖励。',
                                          '全服驱赶进度达标可领集体奖励。'],
        'help_desc': '爆竹可用元宝购买。',
        'personal_count': d['count'], 'collective_count': max(0, d['count'] - 2),
        'bianpao': d['bianpao'], 'baiduo': d['bianpao'],
        'reserved_blank': _blank_map(),
        'is_toast': False,
        'gifts_list': _gift_pool(ctx, 30),
        'list': _reward_rows(ctx, 30, 6, count=d.get('count'),
                             claimed=d.get('claimed') or {}),
        'expel_reward': [_reward_goods(g) for g in _goods_n(ctx, 34, 3)],
    }


# ----------------------------------------------------------------------
# 香囊秘格  `XiangNangMiGe.lua`
# ----------------------------------------------------------------------
def _sachet_info(ctx, st):
    """`XiangNangMiGe:init`（:44-78）+ `__dealWithRewardLevelInfo`/`__dealWithRewardInfo`：
      name / detail_desc(数组) / currency_name / currency_number / help_text /
      exchange_list[{text,status,rewardLevel,type,rewardIds,exchangeId}] /
      rewards（map：tostring(档次) -> {text,price,rewards:[商品数组]}）

    ★★ 踩坑（老板 2026-09-28 报「香囊秘阁打不开」）：
      `rewardIds` / `exchangeId` 必须是**数字**，不能是字符串！
      客户端 `__dealWithRewardInfo` 里做的是 `_info.id = tonumber(k)`（**数字**），
      而 `getRewardById(id)` 用 `if reward.id == id` 逐个比 —— Lua 的
      `1 == "1"` 是 **false** ⇒ 查不到 ⇒ `currReward` 为 nil ⇒
      `XiangNangMiGePresenters.lua:110` 读 `currReward.price` 直接**抛异常**
      ⇒ `__initUI` 中断 ⇒ **面板根本不显示**（logcat: `stack traceback: ... :111: in function '__initUI'`）。
      （`exchangeId` 同理：`:98` 也走 `getRewardById(itemInfo.exchangeId)`。）
      注意 `rewards` 的**键**仍必须是字符串（客户端自己 `tonumber(k)`，两边都对得上）。
    """
    d = st['sachet']
    levels = []
    for i in range(3):
        levels.append({
            'rewardLevel': i + 1, 'text': '第%d格' % (i + 1),
            'status': _int(d['level'].get(str(i + 1)), 0 if i == 0 else 1),
            'type': 1 if i % 2 == 0 else 2,
            # ★ 数字！字符串会让客户端 getRewardById 查不到（见上）
            'rewardIds': [i + 1], 'exchangeId': i + 1,
        })
    rewards = {}
    for i in range(3):
        rewards[str(i + 1)] = {
            'text': '香囊第%d格奖励' % (i + 1), 'price': (i + 1) * 10,
            'rewards': [_reward_goods(g) for g in _goods_n(ctx, 20 + i * 2, 2)],
        }
    return {
        'name': '香囊秘格', 'detail_desc': ['用香囊钥匙开启秘格，领取格中奖励。',
                                          '解锁越多格，奖励越丰厚。'],
        'currency_name': '香囊钥匙', 'currency_number': d['currency'],
        'help_text': '香囊钥匙可通过活动获得。',
        'exchange_list': levels, 'rewards': rewards,
    }


# ----------------------------------------------------------------------
# 淬炼材料商店  `CuiLianCaiLiaoStore.lua`
# ----------------------------------------------------------------------
_CUI_TYPES = ['剑', '刀', '枪棍', '鞭', '双持', '乐器', '暗器']


def _cuilian_list(ctx, st):
    """`CuiLianCaiLiaoStore:init`（:48-86）+ `__dealWithGoodsInfo`/`__dealWithExchangeInfo`：
      act_name / detail_desc(数组) / integral_number / integral_limit /
      currency_list[{id,name,number}] /
      buy_list[{id,type,state,rewards:[{id,num}],text,price:[{number,priceUnit}],stock,original_price}] /
      exchange_list[{id,type,goodsId,integral}]
      ★ `v.price[1].number` / `v.price[1].priceUnit`、`v.rewards` 用 pairs 遍历、`#` 不能少。
    """
    d = st['cuilian']
    cur_list = [
        {'id': 'like_point', 'name': '侠义值', 'number': 200},
        {'id': 'liujinye', 'name': '流金液', 'number': 80},
        {'id': 'suiyin', 'name': '碎银', 'number': 5000},
    ]
    buy = []
    for i in range(9):
        g = _goods(ctx, 10 + i)
        buy.append({
            'id': g['id'], 'goodsId': g['id'], 'type': _CUI_TYPES[i % len(_CUI_TYPES)],
            'state': _int(d['bought'].get(g['id']), 0),
            'rewards': [_reward_goods(g)],
            'text': '%s材料包' % g['name'],
            'price': [{'number': 20 + i * 10, 'priceUnit': 'like_point'}],
            'stock': 5 - (i % 3), 'original_price': 60 + i * 10,
        })
    exc = []
    for i in range(6):
        g = _goods(ctx, 24 + i)
        exc.append({'id': i + 1, 'type': _CUI_TYPES[i % len(_CUI_TYPES)],
                    'goodsId': g['id'], 'integral': (i + 1) * 15})
    return {
        'act_name': '淬炼材料商店', 'detail_desc': ['用侠义值购买淬炼材料，',
                                                 '多余材料可兑换成流金液。'],
        'integral_number': d['integral'], 'integral_limit': 500,
        'currency_list': cur_list, 'buy_list': buy, 'exchange_list': exc,
    }


# ----------------------------------------------------------------------
# 拳脚商店  `FistFootShop.lua`
# ----------------------------------------------------------------------
def _fist_shop(ctx, st):
    """`FistFootShop:getFistFootShopInfo`（:51-87）读：
      activityName / activityDesc(数组) / dailyDefaultCost / dailySelectCost /
      specialOfferState / specialOfferStartDate / specialOfferOrder{cost,useDiscountRate,gain} /
      discountRate / dailySelectList（数组，`#` 取长度）
    ★ 全是数字的字段一个不能少（`== 0` / `..` / `math.max(x - GetTime(),0)` 都会崩）：
      - `dailyDefaultCost`、`dailySelectCost`（`math.floor(numAdd*daySelectCost*quota/price)`）
      - `specialOfferStartDate` 必须是 **unix 秒**（`math.max(specialOfferStartDate - GetTime(),0)`）
      - `dailySelectList` 必须是**数组**（`#dailySelectList`、`ipairs`）
      - `specialOfferOrder.gain` 条目读的是 **goodsId / number**（`FistFootShopPresenter:136-140`）
    """
    d = st['fist']
    _fist_state_fix(d)
    cost = _fist_cost_conf()
    quota = _fist_quota()
    # 特惠"已用基数/已支付元宝"的回显：按当前折扣率 + 每日数×multiple 算一次真值
    max_cost = _num(d.get('dayCost'), 200) * _num(cost.get('multiple'), 3)
    gain_nums = {}
    for rid, q in quota.items():
        gain_nums[rid] = _fist_special_num(rid, _num(d['discount']) / 100.0, max_cost, q)
    return {
        'activityName': '通武积市',
        'activityDesc': ['每日可支付一次元宝，领取固身元气与特性见解。',
                         '累计支付天数越多，特惠基数越高。'],
        'dailyDefaultCost': _num(cost.get('minlimit'), 200),
        'dailySelectCost': _num(d['dayCost']),
        'specialOfferState': _num(d['specialState']),
        # ★ unix 秒（未来），不能给 "20250101"
        'specialOfferStartDate': FAR_FUTURE,
        'specialOfferOrder': {
            'cost': max_cost, 'useDiscountRate': _num(d['discount']),
            # ★ `FistFootShopPresenter:136-140` 读 `gain` 条目的 **goodsId / number**
            'gain': _fist_reward_rows(gain_nums),
        },
        'discountRate': _num(d['discount']),
        'dailySelectList': list(d['dailySelect']),
        'shopDayList': _lua_rows(_FIST_DAY_KEY),
        'costConf': cost,
    }


def _bump_dataver(st):
    """把 `st['dataVer']` 加一（客户端 `setDataVersion(data.dataVer)` 用）。"""
    st['dataVer'] = _num(st.get('dataVer')) + 1
    return st['dataVer']


def _fist_state_fix(d):
    """补齐/纠正 `st['fist']` 的字段。

    ★ 踩过的坑：`setdefault('fist', {...'dayCost':200...})` 对**已存在**的 dict 不生效，
      所以老板那份早期的 `dayCost: 0` 一直留着 ⇒ 面板卡在「请先设置每日支付元宝」，
      而客户端第一天本该用 `dailyDefaultCost` 直接付。这里兜一次。
    """
    if _num(d.get('dayCost')) <= 0:
        d['dayCost'] = _num(_fist_cost_conf().get('minlimit'), 200)
    d.setdefault('discount', 100)
    d.setdefault('dailySelect', [])
    d.setdefault('specialState', 1)
    if _num(d.get('discount')) <= 0:
        d['discount'] = 100
    return d


def _fist_day_cost(d):
    """本次要扣的元宝数：未自设过就用每日默认（`dailyDefaultCost`）。"""
    return _num(d.get('dayCost')) or _num(_fist_cost_conf().get('minlimit'), 200)


def _fist_day_bonus(day_id, tier):
    """`dayConf[day].bonus[tier]/100`；缺就用 1.0。"""
    row = _fist_day_conf().get(str(day_id)) or {}
    bonus = row.get('bonus') or []
    idx = max(1, _num(tier, 1))
    if 1 <= idx <= len(bonus):
        return _num(bonus[idx - 1], 100) / 100.0
    return 1.0


def _fist_day_nums(day_id, tier, day_cost):
    """每日档位的 `{档id: 数量}`：`floor(bonus × dayCost × quota / price)`。"""
    conf = _fist_reward_conf()
    bonus = _fist_day_bonus(day_id, tier)
    out = {}
    for rid, q in _fist_quota().items():
        price = max(1, _num((conf.get(rid) or {}).get('price'), 1))
        out[rid] = int(bonus * day_cost * q / price)
    return out


def _fist_roll_tier(day_id, forced=None):
    """摇概率档：`dayConf[day].probability = [90,6,4]` → 档 1/2/3。

    ★ `tierId` **不是玩家选的档位**，是**服务器摇出来的中奖档**
      （`ActionLayer` 只是把 `data.tierId` 回显、并 `table.insert` 进 `dailySelectList`）。
      档位决定 `bonus`（100/110/120 ⇒ ×1.0/1.1/1.2）。
    """
    if forced:
        return max(1, min(3, _num(forced, 1)))
    row = _fist_day_conf().get(str(day_id)) or {}
    prob = row.get('probability') or [100, 0, 0]
    total = sum(_num(x) for x in prob) or 100
    r = _rand_int(1, total)
    acc = 0
    for i, p in enumerate(prob, 1):
        acc += _num(p)
        if r <= acc:
            return i
    return 1


def _rand_int(lo, hi):
    """闭区间随机整数（`random` 没在模块顶部导入，这里按需拿）。"""
    import random
    if hi <= lo:
        return lo
    return random.randint(lo, hi)


def _fist_special_num(rid, rate, cost, quota):
    """特惠数量：`floor(rate × cost × quota / price)`（她 `:356-362`）。"""
    conf = _fist_reward_conf()
    price = max(1, _num((conf.get(rid) or {}).get('price'), 1))
    return int(rate * cost * quota / price)


# ----------------------------------------------------------------------
# 幸运盒子  `NewRandomGift.lua`
# ----------------------------------------------------------------------
def _luck_box(ctx, st):
    """`NewRandomGift:init`（:44-81）读：
      act_name / detail_desc(数组) / buy_times / buy_limit / refresh_currency / refresh_cost /
      list[{icon,name,number,buy_cost,buy_currency,state,dis_cost,aft_price,rid,itype,id}] /
      display_list[{rtype,text}]

    ★★ 2026-10-03 修「点刷新没反应」：她刷新走的是**同一个接口**带 `is_refresh="Y"`
      （`HttpManager:getLuckBoxList` 第 3 参），服务端原来**不理这个标记**、永远回同一批货
      ⇒ 面板原样重画一遍 = 老板看到的"没反应"。现在：
        · 货架从 state 的 `keys` 出（不是写死下标），刷新时真换一批；
        · 刷新按面板显示扣 100 元宝（`NewRandomGiftPresenters` 弹窗写的是 100），
          元宝不够回 errcode 1（她 PopText(errmsg)）；
        · 刷新清空已领取标记（新一轮），`buy_times` 是活动期购买总数**不清**。
    """
    d = st['luckbox']
    is_refresh = _s(ctx.param('is_refresh') or ctx.param('isRefresh'))
    cat = _goods_catalog(ctx)
    total = max(1, len(cat))
    # 货架：state 里存**目录下标**（刷新重摇），没有就按默认 16..24 摇一批
    if not isinstance(d.get('keys'), list) or not d['keys']:
        d['keys'] = [(16 + i) % total for i in range(9)]
    if is_refresh == 'Y':
        import fz_api.items_currency as _ic
        if _ic.get_currency(ctx, 'yuanbao') < 100:
            return ctx.fail('元宝不足，无法刷新（需要 100 元宝）',
                            '★ 幸运盒刷新：元宝不足')
        _ic.add_currency(ctx, 'yuanbao', -100)
        import random as _rnd
        rnd = _rnd.Random(int(time.time() * 1000))
        d['keys'] = rnd.sample(range(total), min(9, total))
        d['state'] = {}                     # 新一轮：领取标记清空
        d['idx'] = _int(d.get('idx'), 0) + 1
        ctx.save_json(STATE, st)
    keys = d['keys']
    rows = []
    for i, k in enumerate(keys):
        g = _goods(ctx, int(k))
        state = _int(d['state'].get(g['id']), 0 if i % 3 else 1)
        rows.append({
            'rid': g['id'],
            # ★ 2026-10-03 修「天缘奇盒无法领取」：客户端 `NewRandomGift.lua:243`
            #   把行 `id` 塞进 `_info.rewards`，领取前 `__checkCanGetReward` 按它
            #   `getOneItemByKey` 查物品表——商品键查无 ⇒ 弹"无法找到该资源"把领取拦死。
            #   ⇒ 行 `id` 给**真物品 id**；请求用的 rid 另有字段（客户端发 v.rid）。
            'id': g['itemId'], 'itemId': g['itemId'],
            'icon': g['icon'], 'name': g['name'], 'number': 1,
            'buy_cost': 100 + i * 10, 'buy_currency': 'yuanbao',
            'dis_cost': (100 + i * 10) * 8 // 10, 'aft_price': 0 if i % 3 == 2 else 20,
            'state': state, 'itype': 1,
        })
    disp = [{'rtype': 1, 'text': '门派奖励道具：%s' % _goods(ctx, 16)['name']},
            {'rtype': 2, 'text': '珍贵奖励道具：%s' % _goods(ctx, 20)['name']},
            {'rtype': 3, 'text': '稀有奖励道具：%s' % _goods(ctx, 24)['name']},
            {'rtype': 4, 'text': '普通奖励道具：%s' % _goods(ctx, 28)['name']}]
    return {
        'act_name': '幸运盒子', 'detail_desc': ['开启幸运盒子可获得随机奖励。',
                                              '刷新可更换本轮的奖励。'],
        'buy_times': d['buy_times'], 'buy_limit': 30,
        'refresh_currency': 'yuanbao', 'refresh_cost': 100,
        'list': rows, 'display_list': disp,
    }


# ----------------------------------------------------------------------
# 消耗计划礼物  `ConsumeWingLayer.lua` / `DailyJiFuLayer.lua`
# ----------------------------------------------------------------------
_SPEND_TIERS = [30, 100, 300]


def _spend_plan(ctx, st, act_id=''):
    """「消耗/充值计划奖励」——**两个客户端两套契约**，按 `activityId` 分派。

    ★★ 老板 2026-09-28 报「豪礼贺国岁点不开」。根因：这个端点被两个活动共用，
      而两者要的**结构完全不同**：

      * `consume_wing`（江湖狂欢礼包等）→ `ConsumeWingLayer.lua`
        要 `config.base[金额] = [{itemId,number,name,imagePath,showType,...}]`
        + `config.strategy_id` + `list` + `shopping_money`（下面「原实现」保留）。
      * `haoli_heguosui`（**豪礼贺国岁**）→ `GuoQingKuangHuanLayer.lua`
        要 `spend_yuanbao` / `first_yuanbao` / `second_yuanbao` /
        `yuanbaoplan_reward.first|second`（每项 `{idNum,name,image,timeText,
        itemId="<goodsId>,<num>;<goodsId>,<num>"}`）/ `status[tostring(idNum)]`
        （0 未解锁 / 1 可领 / 2 已领）。
        `:239` 把 `item_data.itemId` 按 `;` 再按 `,` 拆成 `{itemId: count}`，
        收货走 `role:addItemCount(itemId, count)` ⇒ **itemId 必须是客户端认的物品号**。
    """
    d = st['spend']
    if _s(act_id) == 'haoli_heguosui':
        def _tier(i, money):
            gs = [_goods(ctx, 6 + i * 2), _goods(ctx, 7 + i * 2), _goods(ctx, 8 + i * 2)]
            return {
                'idNum': i + 1,
                'name': '累计充值 %d 元宝' % money,
                'image': gs[0]['icon'],
                'timeText': '长期开放',
                # ★ 2026-10-03：客户端 `GuoQingKuangHuanLayer:239` 拆开后
                #   `addItemCount(itemId, count)` ⇒ 必须真物品 id，不能是商品表键
                'itemId': ';'.join('%s,%d' % (g['itemId'], n)
                                   for g, n in zip(gs, (1, 2, 3))),
                'id': i + 1,
            }
        first = [_tier(i, m) for i, m in enumerate(_SPEND_TIERS)]
        second = [_tier(i, m * 2) for i, m in enumerate(_SPEND_TIERS)]
        status = {str(i + 1): _int(d['list'].get(str(m)), 1 if i == 0 else 0)
                  for i, m in enumerate(_SPEND_TIERS)}
        return {
            'spend_yuanbao': _int(d.get('money'), 0),
            'first_yuanbao': _SPEND_TIERS[0] if _SPEND_TIERS else 30,
            'second_yuanbao': (_SPEND_TIERS[0] * 2) if _SPEND_TIERS else 60,
            'yuanbaoplan_reward': {'first': first, 'second': second},
            'status': status,
        }
    base = {}
    for i, money in enumerate(_SPEND_TIERS):
        g0 = _goods(ctx, 6 + i * 2)
        g1 = _goods(ctx, 7 + i * 2)
        g2 = _goods(ctx, 8 + i * 2)
        base[str(money)] = [
            {'itemId': g0['id'], 'id': g0['id'], 'name': g0['name'], 'number': 1,
             'imagePath': g0['icon'], 'showType': 1, 'nameDes': '', 'isVirtual': 0,
             'count': 1},
            {'itemId': g1['id'], 'id': g1['id'], 'name': g1['name'], 'number': 2,
             'imagePath': g1['icon'], 'showType': 1, 'nameDes': '', 'isVirtual': 0,
             'count': 2},
            {'itemId': g2['id'], 'id': g2['id'], 'name': g2['name'], 'number': 3,
             'imagePath': g2['icon'], 'showType': 1, 'nameDes': '', 'isVirtual': 0,
             'count': 3},
        ]
    lst = {}
    for i, money in enumerate(_SPEND_TIERS):
        lst[str(money)] = _int(d['list'].get(str(money)), 1 if i == 0 else 0)
    return {
        'config': {'base': base, 'strategy_id': 1},
        'list': lst, 'shopping_money': d['money'],
    }


# ======================================================================
# 路由
# ======================================================================
def handle(ctx):
    ep = ctx.endpoint
    st = _state(ctx)

    # ---------------- 江湖夺宝 ----------------
    if ep == 'get_lottery_treasure_list':
        return ctx.ok(_duobao_detail(ctx, st), '★ 江湖夺宝面板')

    if ep == 'buy_lottery_treasure_currency':
        n = _int(ctx.param('number') or ctx.param('num'), 1) or 1
        d = st['duobao']
        d['currency'] += max(1, n)
        d['bought'] += max(1, n)
        ctx.save_json(STATE, st)
        return ctx.ok({'status': 0, 'currency_num': d['currency'],
                       'currencyVersion': 0}, '★ 夺宝买令（+%d）' % max(1, n))

    if ep == 'lottery_treasure_result':
        d = st['duobao']
        g = _goods(ctx, d['gem_idx'] + 3)
        d['currency'] = max(0, d['currency'] - d['pay'])
        d['times'] += 1
        d['state'] = 1
        d['gem_idx'] = (d['gem_idx'] + 1) % 9
        ctx.save_json(STATE, st)
        # ★ 2026-10-03：`id` 给**真物品 id**——客户端抽中/领取两条路都会拿它 addItemCount
        return ctx.ok({'rewards': {'text': g['name'], 'rid': g['id'],
                                   'id': g['itemId'], 'name': g['name'],
                                   'number': 1, 'type': 1},
                       'status': 1, 'currency_num': d['currency'],
                       'curr_lottery_times': d['times'], 'currencyVersion': 0},
                      '★ 夺宝抽奖（得 %s）' % g['name'])

    if ep == 'lottery_treasure_reward':
        rid = ctx.param('rewardId') or ctx.param('rid')
        g = _goods_by_id(ctx, rid) if rid else _goods(ctx, 3)
        d = st['duobao']
        d['state'] = 0
        d['rewarded'] = True
        d['currency'] += 200            # 抽中即返一点，方便连续体验
        ctx.save_json(STATE, st)
        # ★ 2026-10-03 修「醉梦生领了背包没有」：`rewards.id` 原来=商品表键(300003)，
        #   客户端 `JiangHuDuoBao.lua:164 addItemCount(rewards.id)` 查无此 id 静默失败。
        #   改成真物品 id（jiu106）。
        return ctx.ok({
            'rewards': {'id': g['itemId'], 'itemId': g['itemId'], 'name': g['name'],
                        'number': 1, 'type': 1, 'icon': g['icon'],
                        'rid': g['id']},
            'msg': '领取成功', 'yashi_expired_time': FAR_FUTURE,
            'currencyVersion': 0, 'currency_num': d['currency'],
        }, '★ 夺宝领奖（%s → %s）' % (g['name'], g['itemId']))

    # ---------------- 名武录 / 名人录 ----------------
    if ep in ('get_mingwu_lottery_list', 'get_mingren_lottery_list'):
        is_yiren = (ep == 'get_mingren_lottery_list')
        act_id = (ctx.args[0] if ctx.args else '') or ('jianghuyirenlu' if is_yiren
                                                       else 'jianghumingwu')
        body, _conf, _lot = _mingwu_body(ctx, act_id, st, is_yiren)
        return ctx.ok(body, '★ %s面板（%d 件奖品）'
                      % ('江湖名人录' if is_yiren else '江湖名武录', len(_lot)))

    if ep == 'do_mingwu_lottery':
        is_yiren = str(ctx.args[0] if ctx.args else '').find('yiren') >= 0
        times = _int(ctx.args[1] if is_yiren and len(ctx.args) > 1
                     else (ctx.args[0] if ctx.args else 1), 1) or 1
        key = 'mingren' if is_yiren else 'mingwu'
        d = st[key]
        # `JiangHuMingWuLuAction:doLottery`（:330-363）：
        #   prize 数组每项读 sendFrom / itemId / number / name（name 进 `..`，必给）
        #   ★ 这里 `exchange_currency` 和 `currency` 是**数字**（`setCurrencyCount(data.currency)`），
        #     和 get_*_lottery_list 里同名但是**对象** —— 千万不要统一类型。
        #   名人录还读 `yuanbao` / `baifangmingtie`（数字）。
        prize = []
        for i in range(min(9, max(1, times))):
            g = _goods(ctx, 4 + (d['times'] + i) % 8)
            prize.append({'sendFrom': 'client', 'itemId': g['itemId'], 'id': g['id'],
                          'name': g['name'], 'number': 1, 'icon': g['icon'],
                          'type': 1, 'itype': 1})
        d['times'] += max(1, times)
        d['currency'] = max(0, d['currency'] - 80 * max(1, times))
        d['exchange'] = d.get('exchange', 0) + max(1, times)
        ctx.save_json(STATE, st)
        body = {'prize': prize, 'currency': d['currency'],
                'exchange_currency': d.get('exchange', 0), 'currencyVersion': 0}
        if is_yiren:
            body['yuanbao'] = 9999
            body['baifangmingtie'] = d['mingtie'] + max(1, times)
            d['mingtie'] = body['baifangmingtie']
        return ctx.ok(body, '★ %s抽奖 ×%d' % ('名人录' if is_yiren else '名武录',
                                              max(1, times)))

    if ep == 'detection_goods':
        # `JiangHuMingWuLuAction:__exchangeItem`（:432-441）读 `data.numbers`，
        # `tonumber(data.numbers) < tonumber(reward.need)` ⇒ 必须是数字或数字串
        gid = ctx.args[0] if ctx.args else (ctx.param('goodsId') or 'yirenitem1')
        d = st['mingren']
        return ctx.ok({'numbers': d.get('exchange', 0), 'id': gid, 'name': '拜会名帖',
                       'count': d.get('exchange', 0)}, '★ 检测物品数量（%s）' % gid)

    if ep == 'employ_materials':
        # 她 `checkItemIsCanUse(id, num, cb)` → `data.numbers`（用后剩余数量）
        d = st['mingren']
        d['exchange'] = max(0, d.get('exchange', 0) - 1)
        ctx.save_json(STATE, st)
        return ctx.ok({'numbers': d.get('exchange', 0), 'status': 1, 'msg': '兑换成功'},
                      '★ 消耗兑换币（剩 %d）' % d.get('exchange', 0))

    # ---------------- 藏经阁 ----------------
    if ep == 'get_sutra_pavilion_list':
        return ctx.ok(_cjg_list(ctx, st), '★ 藏经阁面板')

    if ep in ('get_sutra_pavilion_goods', 'buy_sutra_pavilion_goods'):
        rid = ctx.param('rewardId') or (ctx.args[1] if len(ctx.args) > 1
                                        else (ctx.args[0] if ctx.args else ''))
        # ★ 二层修复：必须按**藏经阁目录**解析（原 _goods_by_id 是活动 40 件目录，
        #   货架键不在里面会取模乱落——见 _cjg_goods_by_id 注释）
        g = _cjg_goods_by_id(ctx, rid) if rid else _cjg_goods(ctx, 8)
        d = st['cjg']
        if ep == 'get_sutra_pavilion_goods':
            # `CangJingGe.lua:232` 走 **A1 fromNetworkGrantGoods**（按商品键查表换算入包）
            #   ⇒ 2026-10-03 二轮审计：必须发**商品键**（v10 发真物品 id 反而查无）
            d['state'][g['id']] = 2
            ctx.save_json(STATE, st)
            return ctx.ok({'reward': _reward_goods(g), 'msg': '领取成功',
                           'currencyVersion': 0},
                          '★ 藏经阁领奖（%s，A1 商品键）' % g['name'])
        d['buy_times'] += 1
        # ★★ 2026-10-03 修「藏经阁买完没生效」：官方是**两步制**——
        #   state 0=可购买 → 1=已购待领取（面板亮「领取」按钮，点了走 doReward 真发货）
        #   → 2=已领取（灰）。原来购买直接标 2 ⇒ 领取按钮永远出不来 ⇒ 货永远拿不到。
        #   （她客户端 buyGoods 回调只弹"购买成功"，发货在 doReward 那一步。）
        d['state'][g['id']] = 1
        ctx.save_json(STATE, st)
        return ctx.ok({'msg': '购买成功，请点击「领取」拿到物品', 'buy_times': d['buy_times'],
                       'reward': _reward_goods(g),
                       'currencyVersion': 0},
                      '★ 藏经阁购买（%s，第 %d 次，A1 商品键，state→1 待领取）' % (g['name'], d['buy_times']))

    # ---------------- 仓库活动 ----------------
    if ep == 'get_treasury_info':
        return ctx.ok(_treasury_info(ctx, st), '★ 地仓府库面板')

    if ep == 'treasury_lottery':
        d = st['treasury']
        idx = ctx.param('indexList') or ctx.body_obj.get('indexList') or [1]
        if not isinstance(idx, list):
            idx = [idx]
        ids = []
        for i, one in enumerate(idx[:12]):
            g = _goods(ctx, 8 + (d['floor'] + i) % 12)
            d['drawn'][str(one)] = 1
            ids.append(g['id'])
        d['n1'] = max(0, d['n1'] - len(ids))
        d['n2'] += len(ids)
        d['_pending'] = ids
        ctx.save_json(STATE, st)
        states = [_int(d['progress'].get(str(i + 1)), 0) for i in range(6)]
        return ctx.ok({'awardIds': ids, 'progress_award_states': states,
                       'currencyVersion': 0},
                      '★ 地仓府库抽奖（%d 个格子）' % len(ids))

    if ep == 'get_treasury_reward':
        d = st['treasury']
        ids = d.get('_pending') or []
        if not ids:
            ids = [ _goods(ctx, 8)['id'] ]
        # ★ 二轮审计：WareHouseActivity.lua:162 走 **A1 fromNetworkGrantGoods**
        #   ⇒ 发商品键（v10 的 _grant_goods 反而查无）
        rows = [_reward_goods(_goods_by_id(ctx, i)) for i in ids]
        idx = ctx.param('indexList') or []
        if not isinstance(idx, list):
            idx = [idx]
        for one in idx:
            k = str(one)
            if ctx.param('rewardType') in (1, '1'):
                d['progress'][k] = 2
            else:
                d['drawn'][k] = 1
        d['_pending'] = []
        ctx.save_json(STATE, st)
        return ctx.ok({'awardIds': ids, 'rewards': rows, 'msg': '领取成功',
                       'currencyVersion': 0}, '★ 地仓府库领奖（%d 件）' % len(rows))

    if ep == 'enter_next_treasury':
        d = st['treasury']
        d['floor'] += 1
        d['drawn'] = {}
        ctx.save_json(STATE, st)
        info = _treasury_info(ctx, st)
        return ctx.ok({'random_award_list': info['random_award_list'],
                       'progress_award_states': info['progress_award_states'],
                       'currencyVersion': 0},
                      '★ 地仓府库下一层（第 %d 层）' % d['floor'])

    # ---------------- 限时历练 ----------------
    if ep == 'get_training_task_list':
        body = _training_info(ctx, st)
        st['training']['tasks'] = body['task_list']
        ctx.save_json(STATE, st)
        return ctx.ok(body, '★ 限时历练（%d 个任务）' % len(body['task_list']))

    # ---------------- 丹青阁 ----------------
    if ep == 'get_danqing_pavilion_info':
        return ctx.ok(_danqing_list(ctx, st), '★ 丹青阁面板')

    if ep == 'get_danqing_pavilion_reward':
        rid = _int(ctx.param('rewardId') or (ctx.args[1] if len(ctx.args) > 1 else 0), 1)
        d = st['danqing']
        out = []
        for i, g in enumerate(_goods_n(ctx, 32 + (rid - 1) * 2, 2)):
            # ★ 2026-10-03：发货 id=真物品 id（DanQingGe.lua:115 addItemCount(v.id)）
            out.append({'id': g['itemId'], 'name': g['name'], 'number': 1,
                        'type': 1, 'icon': g['icon'], 'num': 1})
        d['state'][str(rid)] = 2
        d['got'] = d.get('got', {})
        d['got'][str(rid)] = 1
        ctx.save_json(STATE, st)
        # `DanQingGe:doReward`（:107-143）遍历 `data.rewards` 读 type/id/number/name；另读 msg/yashi_expired_time
        return ctx.ok({'rewards': out, 'msg': '领取成功',
                       'yashi_expired_time': FAR_FUTURE, 'currencyVersion': 0},
                      '★ 丹青阁领奖（档 %d，%d 件）' % (rid, len(out)))

    if ep == 'exchange_danqing_pavilion_item':
        rid = _int(ctx.param('rewardId') or (ctx.args[2] if len(ctx.args) > 2 else 1), 1)
        d = st['danqing']
        cur_id = _DANQING_CURRENCY_ID
        # 档位价格要跟面板一致（`_danqing_list` 里 price = 20 + i*10）
        price = 20 + max(0, rid - 1) * 10
        # ★ 真扣真钱袋（不是在活动 state 里另存一份余额）
        try:
            import fz_api.items_currency as _ic
            have = _query_currency(ctx, cur_id)
            if have < price:
                return ctx.fail('%s不足（需要 %d，现有 %d）'
                                % (_currency_display_name(cur_id), price, have),
                                '★ 丹青阁兑换：%s 不足 %d/%d'
                                % (cur_id, have, price))
            _ic.add_currency(ctx, cur_id, -price)
        except Exception as e:                    # noqa: BLE001
            return ctx.fail('扣除失败', '★ 丹青阁兑换：钱袋异常 %r' % e)
        d['buy'][str(rid)] = d['buy'].get(str(rid), 0) + 1
        ctx.save_json(STATE, st)
        # ★★ 2026-10-03 修「丹青阁兑换后背包没有」：原来这里只扣钱、回一句 msg——
        #   客户端 `DanQingGe:exchangeReward`（:90-105）也**只弹 msg、不加背包**，
        #   两边都没发货 ⇒ 钱花了货蒸发。现在服务端把该档货物以**真物品 id**
        #   放进 `rewards` 数组，客户端补丁（DanQingGe.lua，见 fz_bake SRC_FROM_PLAIN）
        #   会遍历它逐件 addItemCount。
        out = [{'id': g['itemId'], 'name': g['name'], 'number': 1, 'type': 1,
                'icon': g['icon'], 'num': 1}
               for g in _goods_n(ctx, 32 + (rid - 1) * 2, 2)]
        return ctx.ok({'msg': '兑换成功', 'rewards': out,
                       'currency_number': _query_currency(ctx, cur_id),
                       'currencyVersion': 0},
                      '★ 丹青阁兑换（档 %d，扣 %s×%d，发 %d 件）'
                      % (rid, _currency_display_name(cur_id), price, len(out)))

    # ---------------- 每日任务 ----------------
    if ep == 'get_daily_task_list':
        body = _daily_info(ctx, st)
        st['daily']['tasks'] = body['task_list']
        ctx.save_json(STATE, st)
        return ctx.ok(body, '★ 每日任务（%d 条）' % len(body['task_list']))

    if ep == 'get_daily_task_reward':
        # 她 `getDailyTaskReward(rid, ...)` 的 rid 是**宝箱 id**（`_daily_info` 里给的是 101+i）
        rid = _int(ctx.param('rid') or (ctx.args[0] if ctx.args else 0), 101)
        if rid < 100:
            rid += 100                      # 兼容她万一传 1..4 的本地序号
        d = st['daily']
        d.setdefault('got', {})
        d['got'][str(rid)] = 2
        ctx.save_json(STATE, st)
        # `DailyTasksActivity:doReward`（:151-173）读 `data.reward`（商品数组）/msg
        rows = [_reward_goods(g) for g in _goods_n(ctx, 34 + (rid - 101) * 2, 2)]
        return ctx.ok({'reward': rows, 'msg': '领取成功', 'currencyVersion': 0},
                      '★ 每日任务领奖（档 %d）' % rid)

    if ep == 'add_daily_task_point':
        # `DailyTasksActivity:addDailyTaskPoint`（:178-190）读 `data.addPoint`（数字，`> 0` 比较）
        add = 20
        d = st['daily']
        tt = ctx.param('taskType') or (ctx.args[0] if ctx.args else '')
        if tt:
            cfg = _lua_rows('activity/dailyTask.lua')
            for i, row in enumerate(cfg):
                if str(row.get('taskid')) == str(tt):
                    add = _int(row.get('points'), 20)
                    d['state'][str(_int(row.get('id'), i + 1))] = 1
                    break
        d['point'] += add
        ctx.save_json(STATE, st)
        return ctx.ok({'addPoint': add, 'daily_point': d['point']},
                      '★ 每日任务加分（+%d ⇒ %d）' % (add, d['point']))

    # ---------------- 醉仙楼 ----------------
    if ep == 'get_toast_reward_list':
        return ctx.ok(_toast_info(ctx, st), '★ 醉仙楼面板')

    if ep == 'get_toast_reward':
        rid = _int(ctx.param('rewardId') or ctx.param('rid')
                   or (ctx.args[0] if ctx.args else 0), 1)
        d = st['toast']
        d['state'][str(rid)] = 2
        ctx.save_json(STATE, st)
        # ★ 二轮审计：DrinkMore.lua:286 走 **A1 fromNetworkGrantGoods** ⇒ 发商品键
        rows = [_reward_goods(g) for g in _goods_n(ctx, 36 + (rid - 1) * 2, 2)]
        return ctx.ok({'rewards': rows, 'newDataVer': 1, 'msg': '领取成功'},
                      '★ 醉仙楼领奖（档 %d，A1 商品键）' % rid)

    if ep == 'toast_qian':
        n = _int(ctx.param('number') or ctx.param('num')
                 or (ctx.args[0] if ctx.args else 1), 1) or 1
        n = max(1, n)
        d = st['toast']
        d['drink'] += n
        d['count'] += n
        d['baiduo'] = max(0, d['baiduo'] - 1)
        # ★★ 老板 2026-09-28 问「醉武酒意在哪获得」。
        #   `canyechoice`（醉仙武意）**只作为消耗币存在**（4 家商人 + 丹青阁用它结算），
        #   客户端**没有任何产出它的地方**，产出在原版服务端 DB 里、不下发。
        #   她的币种描述写「**杯盏交错之际**，灵台清明，忽有所悟，得武学之妙，
        #   或可与人换些武学残篇」⇒ 语义就挂在**醉仙楼喝酒**。
        #   这里在共饮时真发：每次 `醉仙武意 + 60×n`（与 row 里的商品奖励并存）。
        _canye_gain = 60 * n
        try:
            import fz_api.items_currency as _ic
            _ic.add_currency(ctx, 'canyechoice', _canye_gain)
        except Exception as e:                    # noqa: BLE001
            print('[醉仙楼] 发醉仙武意失败：%r' % e)
        ctx.save_json(STATE, st)
        # ★ 二轮审计：DrinkMore.lua:136 走 **A1 fromNetworkGrantGoods** ⇒ 发商品键
        rows = [_reward_goods(g) for g in _goods_n(ctx, 36 + d['drink'] % 4, 2)]
        # `DrinkMore:doDrink`（:122-151）读 `data.baiduo`（数字） / `data.rewards` / `data.dataVer`
        return ctx.ok({'baiduo': d['baiduo'], 'rewards': rows,
                       'msg': '共饮成功，醉仙武意 +%d' % _canye_gain},
                      '★ 醉仙楼共饮 ×%d（醉仙武意 +%d）' % (n, _canye_gain))

    # ---------------- 香囊秘格 ----------------
    if ep == 'get_sachet_attic_new_list':
        return ctx.ok(_sachet_info(ctx, st), '★ 香囊秘格面板')

    # ---------------- 淬炼材料商店 ----------------
    if ep == 'get_cuiLianCaiLiao_store_list':
        return ctx.ok(_cuilian_list(ctx, st), '★ 淬炼材料商店面板')

    if ep == 'buy_cuiLianCaiLiao_store_goods':
        gid = ctx.param('id') or (ctx.args[1] if len(ctx.args) > 1
                                  else (ctx.args[0] if ctx.args else ''))
        g = _goods_by_id(ctx, gid)
        d = st['cuilian']
        d['bought'][g['id']] = 1
        d['stock'][g['id']] = max(0, 5 - _int(d['stock'].get(g['id']), 0))
        ctx.save_json(STATE, st)
        return ctx.ok({'msg': '购买成功', 'currencyVersion': 0},
                      '★ 淬炼商店购买（%s）' % g['name'])

    if ep == 'exchange_cuiLianCaiLiao_store_integral':
        gid = ctx.param('id') or (ctx.args[1] if len(ctx.args) > 1
                                  else (ctx.args[0] if ctx.args else ''))
        g = _goods_by_id(ctx, gid)
        d = st['cuilian']
        d['integral'] = max(0, d['integral'] - 15)
        ctx.save_json(STATE, st)
        # `CuiLianCaiLiaoStore:doExchange`（:192-217）遍历 `data.items`，
        #   `math.abs(goodsInfo.num)` ⇒ num 必须是数字
        return ctx.ok({'items': [{'id': 'liujinye', 'num': -15},
                                 {'id': g['id'], 'num': 1}],
                       'msg': '兑换成功', 'integral_number': d['integral'],
                       'currencyVersion': 0}, '★ 淬炼商店兑换（%s）' % g['name'])

    if ep == 'get_cuiLianCaiLiao_store_reward':
        rid = ctx.param('rid') or (ctx.args[0] if ctx.args else '')
        g = _goods_by_id(ctx, rid) if rid else _goods(ctx, 10)
        rows = [_reward_goods(g)]
        # `doReward`（:170-190）读 `data.rewards` / `data.msg` / `data.yashi_expired_time`
        return ctx.ok({'rewards': rows, 'msg': '领取成功',
                       'yashi_expired_time': FAR_FUTURE, 'currencyVersion': 0},
                      '★ 淬炼商店领奖（%s）' % g['name'])

    # ---------------- 拳脚商店 ----------------
    if ep == 'get_fistFootShop_info':
        return ctx.ok(_fist_shop(ctx, st), '★ 拳脚商店面板')

    if ep == 'set_fistFootShop_dailyCost':
        d = _fist_state_fix(st['fist'])
        cost = _fist_cost_conf()
        lo = _num(cost.get('minlimit'), 200)
        hi = _num(cost.get('maxlimit'), 2000)
        want = _int(ctx.param('daySelectCost') or ctx.param('cost')
                    or (ctx.args[0] if ctx.args else 0), d['dayCost'])
        # 按她的范围夹紧（低于下限会给 0 ⇒ 面板又卡在"请先设置"）
        d['dayCost'] = max(lo, min(hi, want)) if want > 0 else lo
        ctx.save_json(STATE, st)
        return ctx.ok({'dailySelectCost': d['dayCost'], 'msg': '设置成功',
                       'dataVer': _num(st.get('dataVer'))},
                      '★ 拳脚商店设置每日消耗（%d，范围 %d~%d）'
                      % (d['dayCost'], lo, hi))

    if ep == 'buy_fistFootShop_dailyGoods':
        # `buyFistFootShopDailyGoods`（:117-147）读 discountRate / specialOfferState /
        #   tierId（table.insert 进 dailySelectList）/ dataVer / reward / msg
        #   ★ `reward` 条目读 **goodsId / number**（`FistFootShopBuyDayConfirmPresenter:71-79`）
        d = _fist_state_fix(st['fist'])
        day = max(1, _int(ctx.param('dayId') or ctx.param('tierId')
                          or (ctx.args[0] if ctx.args else 1), 1))
        if day in [int(x) for x in d['dailySelect'] if str(x).isdigit()]:
            return ctx.fail('已完成支付，不可重复支付',
                            '★ 拳脚商店：第 %d 天已支付过' % day)

        day_cost = _fist_day_cost(d)
        # 真有每日档位表：本次按"第几次支付"决定折扣与 bonus
        conf = _fist_day_conf()
        row = conf.get(str(day)) or conf.get(str(min(len(conf) or 1, day))) or {}
        # ★ `tierId` 是**服务器摇出的中奖档**（客户端只回显），不是玩家选的
        tier = _fist_roll_tier(day)

        # ★ 真扣元宝（不够就拒，并说清差多少）
        try:
            import fz_api.items_currency as _ic
            have = _num(_ic.get_currency(ctx, 'yuanbao'))
            if have < day_cost:
                return ctx.fail('元宝不足（需要 %d，现有 %d）' % (day_cost, have),
                                '★ 通武积市：元宝不足 %d/%d' % (have, day_cost))
            if not _ic.add_currency(ctx, 'yuanbao', -day_cost):
                return ctx.fail('扣除元宝失败',
                                '★ 通武积市：add_currency(yuanbao,-%d) 返回失败' % day_cost)
        except Exception as e:                    # noqa: BLE001
            return ctx.fail('扣除元宝失败', '★ 通武积市：钱袋模块异常 %r' % e)

        nums = _fist_day_nums(day, tier, day_cost)
        got = _fist_grant(ctx, nums)
        d['dailySelect'].append(day)
        # 折扣率：她的 `dayConf` 给每天一个 discount，取"已支付天数"那档，上限 300
        nxt = conf.get(str(day + 1)) or {}
        d['discount'] = min(300, max(_num(d['discount']),
                                     _num(row.get('discount'), 100),
                                     _num(nxt.get('discount'), 0)))
        if len([x for x in d['dailySelect'] if str(x).isdigit()]) >= 7:
            d['specialState'] = 1                # 满 7 天 ⇒ 特惠可买
        _bump_dataver(st)
        ctx.save_json(STATE, st)
        return ctx.ok({'discountRate': d['discount'], 'specialOfferState': d['specialState'],
                       'tierId': tier, 'dayId': day,
                       'reward': _fist_reward_rows(nums), 'msg': '购买成功',
                       'dataVer': _num(st.get('dataVer'))},
                      '★ 通武积市·每日支付 第%d天 扣%d元宝 → %s'
                      % (day, day_cost, '、'.join(got) or '无'))

    if ep == 'buy_fistFootShop_specialOffer':
        # `buyFistFootShopSpecialOffer`（:155-187）读 specialOfferCost / useDiscountRate /
        #   reward / specialOfferState / dataVer / msg
        d = _fist_state_fix(st['fist'])
        cost = _fist_cost_conf()
        if _num(d['specialState']) == 2:
            return ctx.fail('已购买过特惠', '★ 通武积市：特惠已买过（state=2）')
        day_cost = _fist_day_cost(d)
        hi = day_cost * _num(cost.get('multiple'), 3)
        lo = _num(cost.get('minlimit'), 200)
        want = _int(ctx.param('specialOfferCost') or (ctx.args[0] if ctx.args else 0), hi)
        pay = max(lo, min(hi, want)) if want > 0 else hi
        rate = max(100, _num(d['discount'])) / 100.0

        try:
            import fz_api.items_currency as _ic
            have = _num(_ic.get_currency(ctx, 'yuanbao'))
            if have < pay:
                return ctx.fail('元宝不足（需要 %d，现有 %d）' % (pay, have),
                                '★ 通武积市特惠：元宝不足 %d/%d' % (have, pay))
            if not _ic.add_currency(ctx, 'yuanbao', -pay):
                return ctx.fail('扣除元宝失败',
                                '★ 通武积市特惠：add_currency 失败')
        except Exception as e:                    # noqa: BLE001
            return ctx.fail('扣除元宝失败', '★ 通武积市特惠：钱袋模块异常 %r' % e)

        nums = {rid: _fist_special_num(rid, rate, pay, q)
                for rid, q in _fist_quota().items()}
        got = _fist_grant(ctx, nums)
        d['specialState'] = 2
        _bump_dataver(st)
        ctx.save_json(STATE, st)
        return ctx.ok({'specialOfferCost': pay, 'useDiscountRate': _num(d['discount']),
                       'reward': _fist_reward_rows(nums), 'specialOfferState': 2,
                       'msg': '购买成功', 'dataVer': _num(st.get('dataVer'))},
                      '★ 通武积市·特惠 扣%d元宝（基数%d%%）→ %s'
                      % (pay, _num(d['discount']), '、'.join(got) or '无'))

    # ---------------- 幸运盒子 ----------------
    if ep == 'get_luck_box_list':
        return ctx.ok(_luck_box(ctx, st), '★ 幸运盒子面板')

    # ---------------- 年兽 ----------------
    if ep == 'get_expel_reward_list':
        return ctx.ok(_nian_info(ctx, st), '★ 年兽面板')

    # ---------------- 消耗计划礼物 ----------------
    if ep == 'get_spend_plan_gift_list':
        # ★ URL 尾段是 `activityId`（`get_spend_plan_gift_list/haoli_heguosui`）；
        #   两个活动共用这个端点但**契约不同**，见 `_spend_plan` 的说明。
        _spend_act = _s(ctx.args[0] if ctx.args else '') or \
            _s(ctx.param('activityId') or ctx.param('activity_id'))
        return ctx.ok(_spend_plan(ctx, st, _spend_act),
                      '★ 消耗/充值计划奖励表（activityId=%s，%s契约）'
                      % (_spend_act or '?',
                         '豪礼贺国岁' if _spend_act == 'haoli_heguosui' else '消耗计划'))

    if ep == 'receive_spend_plan_gift_list':
        # 两个客户端两套上行：
        #   * `ConsumeWingLayer:rewardFunc` → `{reward_lv=<金额>}`，应答读 `data.data{name,number}`
        #   * `GuoQingKuangHuanLayer:receiveReward` → `{idNum=<1/2/3 档序号>}`（URL 尾段是 activityId）
        lv = _int(ctx.param('reward_lv') or ctx.param('idNum')
                  or (ctx.args[1] if len(ctx.args) > 1 else 0), 0)
        d = st['spend']
        keys = [str(x) for x in _SPEND_TIERS]
        if lv in (1, 2, 3) and str(lv) not in keys:
            key = keys[lv - 1]              # 1/2/3 是档序号 ⇒ 映到真金额
        else:
            key = str(lv) if str(lv) in keys else keys[0]
        d['list'][key] = 2
        d['money'] = max(d['money'], _int(key, 10))
        ctx.save_json(STATE, st)
        g = _goods(ctx, 6)
        return ctx.ok({'data': {'name': g['name'], 'number': 1, 'id': g['id']},
                       'shopping_money': d['money'], 'list': d['list']},
                      '★ 消耗计划领奖（档 %s）' % key)

    return None


# ======================================================================
# TODO 未做 / 已知问题（本轮**不**写半成品，留给下一轮）：
#   1. 不在本次接口清单、故未接的动作接口：
#      藏经阁刷新、`buy_luck_box_good` / `get_luck_box_good`、
#      `expel_nian` / `get_expel_reward`、`exchange_award_to_sachet_new`、
#      `refresh_training_task_list` / `get_training_task_reward` / `add_training_task_point`、
#      `do_mingren_lottery`（名人录抽奖；照 `do_mingwu_lottery` 抄即可，只是 act_times 分支不同）。
#   2. `get_danqing_pavilion_reward` / `get_daily_task_reward` 没做真实"背包容量校验"，
#      `get_treasury_reward` / `treasury_lottery` 也没做"格子是否已抽"的二次校验
#      （只回成功 + 落盘改状态）。`dataVer`/`currencyVersion` 目前固定 0，
#      等接入她 `ServerActionSystem` 的版本号体系时再对齐。
#   3. ★ 客户端自身缺陷（不是服务端能修的，实测会崩，报给老板）：
#      `app/presenters/Activity/JiangHuYiRenLuActionPresenters.lua:59/61` 调了
#      `setTextRewardClickFunc` 和 `showAllRewardsDialog`，这两个方法在
#      `app/views/ui/ActionUI/JiangHuYiRenLuAction2UI.lua` 里**根本不存在**
#      ⇒ 打开「江湖名人录」会 `attempt to call method (a nil value)`。
#      （名武录的 presenter 不调这两个方法，所以名武录正常。）
#   4. `return` 里给的是明文 dict；写盘用 `work/activities_state.json`（所有面板共用一份）。
# ======================================================================
