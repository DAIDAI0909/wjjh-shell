# -*- coding: utf-8 -*-
# ================= 离线包路径根（fz_make_offline_bundle.py 自动注入） =================
# 手机上整个服务端就是一个目录，表在哪、状态写哪，全部相对包根算。
# （有的模块原来把绝对路径写死，本身没 import os —— 这里一并补上）
import os
import os as _osp


def _off_find_bundle(_f):
    """从模块所在目录往上找包根（认 fz_boot_server.py）。
    ★ fz_api/*.py 的 __file__ 在 <根>/fz_api/ 下，直接 dirname 会算错一层。"""
    _d = _osp.path.dirname(_osp.path.abspath(_f))
    for _ in range(6):
        if _osp.path.exists(_osp.path.join(_d, 'fz_boot_server.py')):
            return _d
        _u = _osp.path.dirname(_d)
        if _u == _d:
            break
        _d = _u
    return _osp.path.dirname(_osp.path.abspath(_f))


_OFF_BUNDLE = _off_find_bundle(__file__)
_OFF_FZ_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_fz')
_OFF_INK_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_ink')
_OFF_WORK_ROOT = _OFF_BUNDLE
# =====================================================================================
# ★ 2026-10-04 商城空货架修复：客户端资源表解析——PC 开发树优先，设备上自动回退
#   到包内 client_fz 副本（jhserver/client_fz = fangzhi_lua_dec 的同步拷贝）。
def _fz_res(*parts):
    base = os.path.join(_OFF_FZ_ROOT, 'res', 'script')
    if not os.path.isdir(base):
        base = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            '..', 'client_fz', 'res', 'script')
    return os.path.join(base, *parts)

# -*- coding: utf-8 -*-
"""★ 合体武学宝箱（老板 2026-09-28 定的设计）

设计：**一个箱子 = 一门武学的全套书页 + 该武学全部主动技能残页**，统一 500 元宝。

## 分栏

★ 老板 2026-09-28 先定「一半放限时、一半放神功，限时放不容易获取的」，
再追加指示「**神功与限时的物品互换**」⇒ 现为：

| 页签 | 内容 | 个数 |
| --- | --- | --- |
| **限时** | 容易获取的：每日福袋系列 | **58** |
| **神功** | 不容易获取的：残篇礼盒 / 器名即武学名的失传神功专箱 / 活动礼包 | **64** |

摆哪个页签由 `fz_boot_server.py` 的货架代码决定，**本文件不代表页签**。
判据：`newfudai*`（每日产出）算易，其余算难。
⚠️ 表里**没有** `dropScheme` 等来源字段可查，这是基于箱子类型的**可辩护近似**，
   不是从原版运行数据得出的精确难度；要精确须原版服务端库。

## 数量按原版配置，不是拍脑袋

| 体系 | 配置来源 | 每张要几个 |
| --- | --- | --- |
| 武学（`skills`，171 本） | `book/bookSkills.lua` | **各 1**（`pageCount1..5` 全为 1）⇒ 集齐可学 |
| 主动技能（`activeZhao`，448 个） | 同上 | **10 / 5 / 2 / 1**（10 最常见）⇒ 一个技能要 N 张 |

★ 老板亲自说明的规则：「一般武学是成套的才能学习成功，并且会消耗对应页数，
  第一次学习只能提升一级」—— 已在 `bookSkills.lua` 里逐项核对成立。

## ★★ 关键实现约束（踩过的坑，别改回去）

1. **开箱是客户端本地行为**：`RoleUseItem_Confirm.lua:39-40` → `Item:getChestRewardByKey()`，
   依据是**箱子自己的 `rwId1..N`**。
   ⇒ 残页奖励 id 必须**写进箱子的 rwId**（`work/tmp_patch_combo_rwids.py` 干的活）。
2. **客户端读的是热更新覆盖层，不是 APK**：
   `/data/data/com.zzxxa.mud/files/updatePath_android_2.1.02/res/script/map/mapItemAttr/Items.lua`
   ⇒ 改表必须用 `work/fz_deploy_devlua.py` 部署（**另一套 AES key**），
     并 `work/fz_push_local_md5list.py` 同步**设备** md5 清单，否则「文件损坏，请重启游戏」。
3. `itype=10`（不是 12）：`:362` 的 12 是"神功虚拟物品"⇒买完**不进背包**；
   宝箱必须真进背包才能开 ⇒ 走 10。

数据源：`combo_requirements.json` + `combobox_plan.json`
"""

import os  # noqa: E402

#: 统一售价（老板定）
COMBO_PRICE = 500

#: icon：客户端没有专属箱图，借卷轴类
COMBO_ICON = 'Image/UI/StoreUI/shujuan1.png'

#: ── 原版物品表（读真描述用）────────────────────────────────
#: ★ 老板 2026-09-28 指出：商城购买框里那段「江湖失传已久的神功…」
#:   **是我自己编的**，而背包里显示的那段才是原版 `Items.lua` 的 `dsc`。
#:   原版每个箱子本来就带各自不同的 `dsc`（例：`newfudai180` 是
#:   「凭运气能开出戏曲面具(惊鸿燕)、烈火鞭法任意残篇、静心丸、流云甘露、
#:   行功散、潜能丹中的一种」），被我统一覆盖掉了。
#:   ⇒ 现在改成**真读她的表**，一个字都不编。
#:
#: 读的是**反编译出来的 APK 表**（服务端在 PC 上，够不着设备的覆盖层；
#: 覆盖层的改动只加 `rwId`，没动 `dsc`，所以两边描述一致）。
_MAPATTR = os.path.join(
    _fz_res('map', 'mapItemAttr'))

_VDESC = {}




def _vanilla(item_id):
    """取原版物品条目（`Items.lua`）。读不到就返回空 dict，不抛。"""
    if not _VDESC:
        try:
            import fz_luatable
            _VDESC['_T'] = fz_luatable.load_lua_table(
                os.path.join(_MAPATTR, 'Items.lua')) or {}
        except Exception:                          # noqa: BLE001
            _VDESC['_T'] = {}
    return _VDESC['_T'].get(item_id) or {}


def vanilla_dsc(item_id):
    """原版物品的 `dsc`（真描述）。空表/缺项时返回 ''。"""
    return str((_vanilla(item_id) or {}).get('dsc') or '')


def vanilla_name(item_id):
    """原版物品的 `name`（含她的染色标记，如 `BLU七星迷踪步NOR`）。"""
    return str((_vanilla(item_id) or {}).get('name') or '')


def vanilla_icon(item_id):
    """原版物品若有专属商城图就用它，否则退回卷轴图。

    客户端 `StoreDialogLayer.lua:102` 找 `Image/UI/StoreUI/<itemId>.png`，
    存在才显示 ⇒ 我们只能给「存在的图名」，给了不存在的图名会**整个不显示**。
    """
    v = _vanilla(item_id) or {}
    for k in ('storeIcon', 'icon', 'image'):
        n = str(v.get(k) or '')
        if n:
            return n
    return COMBO_ICON


#: ── 分栏清单 ──────────────────────────────────────────────
#: 「限时」页签：不容易获取的（64 个）
HARD_IDS = [
    'qixingmizongbubox1',
    'essenceDevouredbox1',
    'soulBreakInFlashbox',
    'spiritBindCirclesbox1',
    'ImperishableFormbox1',
    'immolCallMysticbox1',
    'wulangbaguagunbox1',
    'DefyingDeathbox1',
    'stygSoulGraspClawbox1',
    'eightGatLtaStaffbox1',
    'huaxuyinbox',
    'yinfengzhuabox1',
    'hidingSkyStridebox1',
    'tianyanxinjingbox1',
    'deceiveHvnsFWbox1',
    'disartBlazClawbox',
    'soulSevFixSunbox',
    'FearlessBattlebox1',
    'wuhenjinbox2',
    'brightLunaSwordbox',
    'xlfdbox',
    'wuhenjinbox',
    'zhuxianqinyinbox1',
    'flowCloudsInkSilsbox1',
    'mortalAnnalsbox1',
    'ClearRippleGripWoodbox1',
    'vastBladebox',
    'baimangbianfabox1',
    'purifyMindbox1',
    'frenzBoneWhipbox1',
    'esoterPrimordReturnbox1',
    'hundLegPiercSoulHookbox1',
    'antiinvasionSingbox',
    'shenxingbaibianbox1',
    'ghstStlHvnStepbox1',
    'EarthlyRealmEightTunesbox1',
    'purifyHellAxebox1',
    'OldTreeBreakWavebox1',
    'bloodbaneFrenzybox1',
    'chilianlingbobox1',
    'chilianlingbobox2',
    'yuenvjianfabox1',
    'soulStepStridebox1',
    'peripateticismgunbox',
    'caiweijianfabox1',
    'greenWindHuanbox',
    'fengbaojinxingqubox1',
    '2021jhshbox01',
    'qianhunliecanyebox1',
    '2021jhshbox02',
    '2021jhshbox13',
    '2021jhshbox12',
    '2021jhshbox08',
    '2021jhshbox07',
    '2021jhshbox10',
    '2021jhshbox03',
    '2021jhshbox05',
    '2021jhshbox11',
    '2021jhshbox06',
    '2021jhshbox14',
    '2021jhshbox09',
    '2021jhshbox04',
    '21qybaogelibao1',
    '21yunyinglibao3',
]

#: 「神功」页签：容易获取的（58 个）
EASY_IDS = [
    'newfudai180',
    'newfudai216',
    'newfudai126',
    'newfudai162',
    'newfudai198',
    'newfudai54',
    'newfudai90',
    'newfudai114',
    'newfudai150',
    'newfudai186',
    'newfudai222',
    'newfudai78',
    'newfudai132',
    'newfudai168',
    'newfudai204',
    'newfudai60',
    'newfudai96',
    'newfudai111',
    'newfudai147',
    'newfudai183',
    'newfudai219',
    'newfudai75',
    'newfudai120',
    'newfudai156',
    'newfudai192',
    'newfudai228',
    'newfudai84',
    'newfudai129',
    'newfudai165',
    'newfudai201',
    'newfudai57',
    'newfudai93',
    'newfudai123',
    'newfudai159',
    'newfudai195',
    'newfudai231',
    'newfudai87',
    'newfudai102',
    'newfudai138',
    'newfudai174',
    'newfudai210',
    'newfudai66',
    'newfudai105',
    'newfudai141',
    'newfudai177',
    'newfudai213',
    'newfudai69',
    'newfudai135',
    'newfudai171',
    'newfudai207',
    'newfudai63',
    'newfudai99',
    'newfudai117',
    'newfudai153',
    'newfudai189',
    'newfudai225',
    'newfudai81',
    'newfudai51',
]

#: itemId -> {name, skillid, pages{id:数量}, canye{id:数量}}（共 122 个）
COMBO_BOXES = {
    'qixingmizongbubox1': {
        'name': '七星迷踪步',
        'skillid': 'qixingmizongbu',
        'pages': {
            'qixingmizongbu1': 1,
            'qixingmizongbu2': 1,
            'qixingmizongbu3': 1,
            'qixingmizongbu4': 1,
            'qixingmizongbu5': 1,
        },
        'canye': {
            'piaowuzongcanye': 10,
            'qisheyuncanye': 10,
        },
    },
    'essenceDevouredbox1': {
        'name': '万毒蚀魄',
        'skillid': 'essenceDevoured',
        'pages': {
            'essenceDevoured1': 1,
            'essenceDevoured2': 1,
            'essenceDevoured3': 1,
            'essenceDevoured4': 1,
            'essenceDevoured5': 1,
        },
        'canye': {
            'consumeSymbiocanye': 10,
            'doomBaneSealcanye': 10,
        },
    },
    'soulBreakInFlashbox': {
        'name': '三息断魂',
        'skillid': 'soulBreakInFlash',
        'pages': {
            'soulBreakInFlash1': 1,
            'soulBreakInFlash2': 1,
            'soulBreakInFlash3': 1,
            'soulBreakInFlash4': 1,
            'soulBreakInFlash5': 1,
        },
        'canye': {
            'rotPoisonDartscanye': 10,
            'corrosionBoneNeedlecanye': 10,
        },
    },
    'spiritBindCirclesbox1': {
        'name': '三魂归阴环',
        'skillid': 'spiritBindCircles',
        'pages': {
            'spiritBindCircles1': 1,
            'spiritBindCircles2': 1,
            'spiritBindCircles3': 1,
            'spiritBindCircles4': 1,
            'spiritBindCircles5': 1,
        },
        'canye': {
            'bindingBonescanye': 10,
            'breakingBonescanye': 10,
        },
    },
    'ImperishableFormbox1': {
        'name': '不坏身',
        'skillid': 'ImperishableForm',
        'pages': {
            'ImperishableForm1': 1,
            'ImperishableForm2': 1,
            'ImperishableForm3': 1,
            'ImperishableForm4': 1,
            'ImperishableForm5': 1,
        },
        'canye': {
            'RightPathNoCalamitiescanye': 10,
        },
    },
    'immolCallMysticbox1': {
        'name': '丰沮道藏',
        'skillid': 'immolCallMystic',
        'pages': {
            'immolCallMystic1': 1,
            'immolCallMystic2': 1,
            'immolCallMystic3': 1,
            'immolCallMystic4': 1,
            'immolCallMystic5': 1,
        },
        'canye': {
            'immolGetAtkcanye': 10,
            'mysticLoseCalmcanye': 10,
        },
    },
    'wulangbaguagunbox1': {
        'name': '五郎八卦棍',
        'skillid': 'wulangbaguagun',
        'pages': {
            'wulangbaguagun1': 1,
            'wulangbaguagun2': 1,
            'wulangbaguagun3': 1,
            'wulangbaguagun4': 1,
            'wulangbaguagun5': 1,
        },
        'canye': {
            'qibafangcanye': 10,
        },
    },
    'DefyingDeathbox1': {
        'name': '何惧死',
        'skillid': 'DefyingDeath',
        'pages': {
            'DefyingDeath1': 1,
            'DefyingDeath2': 1,
            'DefyingDeath3': 1,
            'DefyingDeath4': 1,
            'DefyingDeath5': 1,
        },
        'canye': {
            'RegardDeathAsLifecanye': 10,
            'ResurrectTheDeadcanye': 10,
        },
    },
    'stygSoulGraspClawbox1': {
        'name': '催魂冥爪',
        'skillid': 'stygSoulGraspClaw',
        'pages': {
            'stygSoulGraspClaw1': 1,
            'stygSoulGraspClaw2': 1,
            'stygSoulGraspClaw3': 1,
            'stygSoulGraspClaw4': 1,
            'stygSoulGraspClaw5': 1,
        },
        'canye': {
            'sevenfoldChokecanye': 10,
        },
    },
    'eightGatLtaStaffbox1': {
        'name': '八门八煞棍',
        'skillid': 'eightGatLtaStaff',
        'pages': {
            'eightGatLtaStaff1': 1,
            'eightGatLtaStaff2': 1,
            'eightGatLtaStaff3': 1,
            'eightGatLtaStaff4': 1,
            'eightGatLtaStaff5': 1,
        },
        'canye': {
            'gdnGenDmncanye': 10,
            'rebirthFireLicanye': 10,
        },
    },
    'huaxuyinbox': {
        'name': '华胥引',
        'skillid': 'huaxuyin',
        'pages': {
            'huaxuyin1': 1,
            'huaxuyin2': 1,
            'huaxuyin3': 1,
            'huaxuyin4': 1,
            'huaxuyin5': 1,
        },
        'canye': {
            'shenyoucanye': 10,
        },
    },
    'yinfengzhuabox1': {
        'name': '哭魂夜爪',
        'skillid': 'yinfengzhua',
        'pages': {
            'yinfengzhua1': 1,
            'yinfengzhua2': 1,
            'yinfengzhua3': 1,
            'yinfengzhua4': 1,
        },
        'canye': {
            'suotianlongdicanye': 5,
        },
    },
    'hidingSkyStridebox1': {
        'name': '天藏步',
        'skillid': 'hidingSkyStride',
        'pages': {
            'hidingSkyStride1': 1,
            'hidingSkyStride2': 1,
            'hidingSkyStride3': 1,
            'hidingSkyStride4': 1,
            'hidingSkyStride5': 1,
        },
        'canye': {
            'hideEssenceRecedeFormcanye': 10,
            'bizarreUnsettlingcanye': 10,
        },
    },
    'tianyanxinjingbox1': {
        'name': '天衍心经',
        'skillid': 'tianyanxinjing',
        'pages': {
            'tianyanxinjing1': 1,
            'tianyanxinjing2': 1,
            'tianyanxinjing3': 1,
            'tianyanxinjing4': 1,
            'tianyanxinjing5': 1,
        },
        'canye': {
            'jiedaocanye': 10,
        },
    },
    'deceiveHvnsFWbox1': {
        'name': '弥天玄步',
        'skillid': 'deceiveHvnsFW',
        'pages': {
            'deceiveHvnsFW1': 1,
            'deceiveHvnsFW2': 1,
            'deceiveHvnsFW3': 1,
            'deceiveHvnsFW4': 1,
            'deceiveHvnsFW5': 1,
        },
        'canye': {
            'widespreadFogcanye': 10,
            'multipleNecrosiscanye': 10,
        },
    },
    'disartBlazClawbox': {
        'name': '拆离折火爪',
        'skillid': 'disartBlazClaw',
        'pages': {
            'disartBlazClaw1': 1,
            'disartBlazClaw2': 1,
            'disartBlazClaw3': 1,
            'disartBlazClaw4': 1,
            'disartBlazClaw5': 1,
        },
        'canye': {
            'spewFlameBegetWindcanye': 10,
        },
    },
    'soulSevFixSunbox': {
        'name': '断魂定巽指',
        'skillid': 'soulSevFixSun',
        'pages': {
            'soulSevFixSun1': 1,
            'soulSevFixSun2': 1,
            'soulSevFixSun3': 1,
            'soulSevFixSun4': 1,
            'soulSevFixSun5': 1,
        },
        'canye': {
            'flameQuenchWindcanye': 10,
        },
    },
    'FearlessBattlebox1': {
        'name': '无惧战',
        'skillid': 'FearlessBattle',
        'pages': {
            'FearlessBattle1': 1,
            'FearlessBattle2': 1,
            'FearlessBattle3': 1,
            'FearlessBattle4': 1,
            'FearlessBattle5': 1,
        },
        'canye': {
            'BoldAndUncaringcanye': 10,
            'AdvantageCowEnemycanye': 10,
        },
    },
    'wuhenjinbox2': {
        'name': '无痕劲',
        'skillid': 'wuhenjin',
        'pages': {
            'wuhenjin1': 1,
            'wuhenjin2': 1,
            'wuhenjin3': 1,
            'wuhenjin4': 1,
        },
        'canye': {
            'pokongcanye': 5,
        },
    },
    'brightLunaSwordbox': {
        'name': '月华剑法',
        'skillid': 'brightLunaSword',
        'pages': {
            'brightLunaSword1': 1,
            'brightLunaSword2': 1,
            'brightLunaSword3': 1,
            'brightLunaSword4': 1,
            'brightLunaSword5': 1,
        },
        'canye': {
            'coldMoonExpelcanye': 10,
            'silverIlluminationcanye': 10,
        },
    },
    'xlfdbox': {
        'name': '月特惠(探花飞刀)',
        'skillid': 'xiaolifeidao',
        'pages': {
            'xiaolifeidao1': 1,
            'xiaolifeidao2': 1,
            'xiaolifeidao3': 1,
            'xiaolifeidao4': 1,
            'xiaolifeidao5': 1,
        },
        'canye': {
            'liwuxufacanye': 10,
        },
    },
    'wuhenjinbox': {
        'name': '月特惠(无痕劲)',
        'skillid': 'wuhenjin',
        'pages': {
            'wuhenjin1': 1,
            'wuhenjin2': 1,
            'wuhenjin3': 1,
            'wuhenjin4': 1,
        },
        'canye': {
            'pokongcanye': 5,
        },
    },
    'zhuxianqinyinbox1': {
        'name': '朱弦琴音',
        'skillid': 'zhuxianqinyin',
        'pages': {
            'zhuxianqinyin1': 1,
            'zhuxianqinyin2': 1,
            'zhuxianqinyin3': 1,
            'zhuxianqinyin4': 1,
            'zhuxianqinyin5': 1,
        },
        'canye': {
            'hunduancanye': 10,
        },
    },
    'flowCloudsInkSilsbox1': {
        'name': '流云墨影',
        'skillid': 'flowCloudsInkSils',
        'pages': {
            'flowCloudsInkSils1': 1,
            'flowCloudsInkSils2': 1,
            'flowCloudsInkSils3': 1,
            'flowCloudsInkSils4': 1,
            'flowCloudsInkSils5': 1,
        },
        'canye': {
            'inkSilsProfAuracanye': 10,
        },
    },
    'mortalAnnalsbox1': {
        'name': '浮世录',
        'skillid': 'mortalAnnals',
        'pages': {
            'mortalAnnals1': 1,
            'mortalAnnals2': 1,
            'mortalAnnals3': 1,
            'mortalAnnals4': 1,
            'mortalAnnals5': 1,
        },
        'canye': {
            'luckTroubleCoexistcanye': 10,
            'eraseEvilStemIllscanye': 10,
        },
    },
    'ClearRippleGripWoodbox1': {
        'name': '清涟揽木手',
        'skillid': 'ClearRippleGripWood',
        'pages': {
            'ClearRippleGripWood1': 1,
            'ClearRippleGripWood2': 1,
            'ClearRippleGripWood3': 1,
            'ClearRippleGripWood4': 1,
        },
        'canye': {
            'DeepStreamSinkWoodcanye': 10,
        },
    },
    'vastBladebox': {
        'name': '溟涨刀法',
        'skillid': 'vastBlade',
        'pages': {
            'vastBlade1': 1,
            'vastBlade2': 1,
            'vastBlade3': 1,
            'vastBlade4': 1,
            'vastBlade5': 1,
        },
        'canye': {
            'toweringTurbidWavecanye': 10,
            'waveCrashingSandcanye': 10,
        },
    },
    'baimangbianfabox1': {
        'name': '灵蟒鞭术',
        'skillid': 'baimangbianfa',
        'pages': {
            'baimangbianfa1': 1,
            'baimangbianfa2': 1,
            'baimangbianfa3': 1,
            'baimangbianfa4': 1,
            'baimangbianfa5': 1,
        },
        'canye': {
            'bianzoulongshecanye': 10,
        },
    },
    'purifyMindbox1': {
        'name': '焚净经',
        'skillid': 'purifyMind',
        'pages': {
            'purifyMind1': 1,
            'purifyMind2': 1,
            'purifyMind3': 1,
            'purifyMind4': 1,
            'purifyMind5': 1,
        },
        'canye': {
            'cyanLotusFocuscanye': 10,
            'goldCrowPulsecanye': 10,
        },
    },
    'frenzBoneWhipbox1': {
        'name': '狂骨鞭法',
        'skillid': 'frenzBoneWhip',
        'pages': {
            'frenzBoneWhip1': 1,
            'frenzBoneWhip2': 1,
            'frenzBoneWhip3': 1,
            'frenzBoneWhip4': 1,
            'frenzBoneWhip5': 1,
        },
        'canye': {
            'furyDeludeAfflictcanye': 10,
            'seizeEverFibcanye': 10,
        },
    },
    'esoterPrimordReturnbox1': {
        'name': '玄冥归藏决',
        'skillid': 'esoterPrimordReturn',
        'pages': {
            'esoterPrimordReturn1': 1,
            'esoterPrimordReturn2': 1,
            'esoterPrimordReturn3': 1,
            'esoterPrimordReturn4': 1,
            'esoterPrimordReturn5': 1,
        },
        'canye': {
            'temperReservcanye': 10,
            'soulwardAegiscanye': 10,
        },
    },
    'hundLegPiercSoulHookbox1': {
        'name': '百足刺魂钩',
        'skillid': 'hundLegPiercSoulHook',
        'pages': {
            'hundLegPiercSoulHook1': 1,
            'hundLegPiercSoulHook2': 1,
            'hundLegPiercSoulHook3': 1,
            'hundLegPiercSoulHook4': 1,
            'hundLegPiercSoulHook5': 1,
        },
        'canye': {
            'rifSpineShredcanye': 10,
            'centiBindcanye': 10,
        },
    },
    'antiinvasionSingbox': {
        'name': '破虏吟',
        'skillid': 'antiinvasionSing',
        'pages': {
            'antiinvasionSing1': 1,
            'antiinvasionSing2': 1,
            'antiinvasionSing3': 1,
            'antiinvasionSing4': 1,
            'antiinvasionSing5': 1,
        },
        'canye': {
            'thunderAttackcanye': 10,
            'embattledSongcanye': 10,
        },
    },
    'shenxingbaibianbox1': {
        'name': '神行天步',
        'skillid': 'shenxingbaibian',
        'pages': {
            'shenxingbaibian1': 1,
            'shenxingbaibian2': 1,
            'shenxingbaibian3': 1,
            'shenxingbaibian4': 1,
            'shenxingbaibian5': 1,
        },
        'canye': {
            'shenxingbaibiancanye': 10,
        },
    },
    'ghstStlHvnStepbox1': {
        'name': '窃天鬼步',
        'skillid': 'ghstStlHvnStep',
        'pages': {
            'ghstStlHvnStep1': 1,
            'ghstStlHvnStep2': 1,
            'ghstStlHvnStep3': 1,
            'ghstStlHvnStep4': 1,
            'ghstStlHvnStep5': 1,
        },
        'canye': {
            'prstCngldSoulcanye': 10,
            'stlBrthHeavencanye': 10,
        },
    },
    'EarthlyRealmEightTunesbox1': {
        'name': '红尘八音',
        'skillid': 'EarthlyRealmEightTunes',
        'pages': {
            'EarthlyRealmEightTunes1': 1,
            'EarthlyRealmEightTunes2': 1,
            'EarthlyRealmEightTunes3': 1,
            'EarthlyRealmEightTunes4': 1,
            'EarthlyRealmEightTunes5': 1,
        },
        'canye': {
            'EightTrialBreakHeartcanye': 10,
            'EnthralledGoldDreamcanye': 10,
        },
    },
    'purifyHellAxebox1': {
        'name': '罗刹诛罪斧',
        'skillid': 'purifyHellAxe',
        'pages': {
            'purifyHellAxe1': 1,
            'purifyHellAxe2': 1,
            'purifyHellAxe3': 1,
            'purifyHellAxe4': 1,
            'purifyHellAxe5': 1,
        },
        'canye': {
            'cleaveKillcanye': 10,
            'startleSpiritcanye': 10,
        },
    },
    'OldTreeBreakWavebox1': {
        'name': '苍木破浪腿',
        'skillid': 'OldTreeBreakWave',
        'pages': {
            'OldTreeBreakWave1': 1,
            'OldTreeBreakWave2': 1,
            'OldTreeBreakWave3': 1,
            'OldTreeBreakWave4': 1,
        },
        'canye': {
            'DragonBranchWatercanye': 10,
        },
    },
    'bloodbaneFrenzybox1': {
        'name': '血煞狂刀',
        'skillid': 'bloodbaneFrenzy',
        'pages': {
            'bloodbaneFrenzy1': 1,
            'bloodbaneFrenzy2': 1,
            'bloodbaneFrenzy3': 1,
            'bloodbaneFrenzy4': 1,
            'bloodbaneFrenzy5': 1,
        },
        'canye': {
            'bloodbrandcanye': 10,
            'crimsonTemperedcanye': 10,
        },
    },
    'chilianlingbobox1': {
        'name': '赤练凌波',
        'skillid': 'chilianlingbo',
        'pages': {
            'chilianlingbo1': 1,
            'chilianlingbo2': 1,
            'chilianlingbo3': 1,
            'chilianlingbo4': 1,
            'chilianlingbo5': 1,
        },
        'canye': {
            'feiliancanye': 10,
        },
    },
    'chilianlingbobox2': {
        'name': '赤练凌波宝箱',
        'skillid': 'chilianlingbo',
        'pages': {
            'chilianlingbo1': 1,
            'chilianlingbo2': 1,
            'chilianlingbo3': 1,
            'chilianlingbo4': 1,
            'chilianlingbo5': 1,
        },
        'canye': {
            'feiliancanye': 10,
        },
    },
    'yuenvjianfabox1': {
        'name': '越女剑法',
        'skillid': 'yuenvjianfa',
        'pages': {
            'yuenvjianfa1': 1,
            'yuenvjianfa2': 1,
            'yuenvjianfa3': 1,
            'yuenvjianfa4': 1,
            'yuenvjianfa5': 1,
        },
        'canye': {
            'zhuyingjianqicanye': 10,
            'jirentujincanye': 10,
        },
    },
    'soulStepStridebox1': {
        'name': '踏魂虚渡步',
        'skillid': 'soulStepStride',
        'pages': {
            'soulStepStride1': 1,
            'soulStepStride2': 1,
            'soulStepStride3': 1,
            'soulStepStride4': 1,
            'soulStepStride5': 1,
        },
        'canye': {
            'multiVeilBladecanye': 10,
            'primordialReturncanye': 10,
        },
    },
    'peripateticismgunbox': {
        'name': '逍遥棍法',
        'skillid': 'peripateticismgun',
        'pages': {
            'peripateticismgun1': 1,
            'peripateticismgun2': 1,
            'peripateticismgun3': 1,
            'peripateticismgun4': 1,
            'peripateticismgun5': 1,
        },
        'canye': {
            'xiaoyaoyiguncanye': 10,
            'qiankungundingcanye': 10,
        },
    },
    'caiweijianfabox1': {
        'name': '采薇剑法',
        'skillid': 'caiweijianfa',
        'pages': {
            'caiweijianfa1': 1,
            'caiweijianfa2': 1,
            'caiweijianfa3': 1,
            'caiweijianfa4': 1,
            'caiweijianfa5': 1,
        },
        'canye': {
            'guzhuaocanye': 10,
            'shouyangguicanye': 10,
        },
    },
    'greenWindHuanbox': {
        'name': '青岚环诀',
        'skillid': 'greenWindHuan',
        'pages': {
            'greenWindHuan1': 1,
            'greenWindHuan2': 1,
            'greenWindHuan3': 1,
            'greenWindHuan4': 1,
            'greenWindHuan5': 1,
        },
        'canye': {
            'flysandwalkrockcanye': 10,
            'windqicloudyongcanye': 10,
        },
    },
    'fengbaojinxingqubox1': {
        'name': '风暴进行曲',
        'skillid': 'fengbaojinxingqu',
        'pages': {
            'fengbaojinxingqu1': 1,
            'fengbaojinxingqu2': 1,
            'fengbaojinxingqu3': 1,
            'fengbaojinxingqu4': 1,
            'fengbaojinxingqu5': 1,
        },
        'canye': {
            'wuhenzhifengcanye': 10,
            'fusuzhifengcanye': 10,
        },
    },
    '2021jhshbox01': {
        'name': '九龙鞭法残篇礼盒',
        'skillid': 'jiulongbianfa',
        'pages': {
            'jiulongbianfa1': 1,
            'jiulongbianfa2': 1,
            'jiulongbianfa3': 1,
            'jiulongbianfa4': 1,
            'jiulongbianfa5': 1,
        },
        'canye': {
            'jiulongshitiancanye': 10,
        },
    },
    'qianhunliecanyebox1': {
        'name': '千魂裂残篇礼盒',
        'skillid': 'qianhunlie',
        'pages': {
            'qianhunlie1': 1,
            'qianhunlie2': 1,
            'qianhunlie3': 1,
            'qianhunlie4': 1,
            'qianhunlie5': 1,
        },
        'canye': {
            'xiaogushacanye': 10,
        },
    },
    '2021jhshbox02': {
        'name': '哭魂夜爪残篇礼盒',
        'skillid': 'yinfengzhua',
        'pages': {
            'yinfengzhua1': 1,
            'yinfengzhua2': 1,
            'yinfengzhua3': 1,
            'yinfengzhua4': 1,
        },
        'canye': {
            'suotianlongdicanye': 5,
        },
    },
    '2021jhshbox13': {
        'name': '夺魂秘册残篇礼盒',
        'skillid': 'duohunmice',
        'pages': {
            'duohunmice1': 1,
            'duohunmice2': 1,
            'duohunmice3': 1,
            'duohunmice4': 1,
            'duohunmice5': 1,
        },
        'canye': {
            'qiguanzhoushencanye': 10,
        },
    },
    '2021jhshbox12': {
        'name': '往生功残篇礼盒',
        'skillid': 'wangshenggong',
        'pages': {
            'wangshenggong1': 1,
            'wangshenggong2': 1,
            'wangshenggong3': 1,
            'wangshenggong4': 1,
            'wangshenggong5': 1,
        },
        'canye': {
            'wangshengjilecanye': 10,
        },
    },
    '2021jhshbox08': {
        'name': '惊波棍法残篇礼盒',
        'skillid': 'jingbogunfa',
        'pages': {
            'jingbogunfa1': 1,
            'jingbogunfa2': 1,
            'jingbogunfa3': 1,
            'jingbogunfa4': 1,
            'jingbogunfa5': 1,
        },
        'canye': {
            'jingshicanye': 10,
        },
    },
    '2021jhshbox07': {
        'name': '猗兰十章残篇礼盒',
        'skillid': 'yilanshizhang',
        'pages': {
            'yilanshizhang1': 1,
            'yilanshizhang2': 1,
            'yilanshizhang3': 1,
            'yilanshizhang4': 1,
            'yilanshizhang5': 1,
        },
        'canye': {
            'ruqirusucanye': 10,
        },
    },
    '2021jhshbox10': {
        'name': '藏狐步残篇礼盒',
        'skillid': 'canghubu',
        'pages': {
            'canghubu1': 1,
            'canghubu2': 1,
            'canghubu3': 1,
            'canghubu4': 1,
            'canghubu5': 1,
        },
        'canye': {
            'hucangcanye': 10,
        },
    },
    '2021jhshbox03': {
        'name': '藏锋刀法残篇礼盒',
        'skillid': 'cangfengdaofa',
        'pages': {
            'cangfengdaofa1': 1,
            'cangfengdaofa2': 1,
            'cangfengdaofa3': 1,
            'cangfengdaofa4': 1,
            'cangfengdaofa5': 1,
        },
        'canye': {
            'daorenduofengcanye': 10,
        },
    },
    '2021jhshbox05': {
        'name': '追影随风枪残篇礼盒',
        'skillid': 'zhuiyingsuifengqiang',
        'pages': {
            'zhuiyingsuifengqiang1': 1,
            'zhuiyingsuifengqiang2': 1,
            'zhuiyingsuifengqiang3': 1,
            'zhuiyingsuifengqiang4': 1,
        },
        'canye': {
            'fengdingtiannancanye': 10,
        },
    },
    '2021jhshbox11': {
        'name': '逆焰功残篇礼盒',
        'skillid': 'niyangong',
        'pages': {
            'niyangong1': 1,
            'niyangong2': 1,
            'niyangong3': 1,
            'niyangong4': 1,
            'niyangong5': 1,
        },
        'canye': {
            'yanhuoliaoyuancanye': 10,
        },
    },
    '2021jhshbox06': {
        'name': '铁血誓剑残篇礼盒',
        'skillid': 'tiexueshijian',
        'pages': {
            'tiexueshijian1': 1,
            'tiexueshijian2': 1,
            'tiexueshijian3': 1,
            'tiexueshijian4': 1,
            'tiexueshijian5': 1,
        },
        'canye': {
            'yixueweishicanye': 10,
        },
    },
    '2021jhshbox14': {
        'name': '阴阳归一环残篇礼盒',
        'skillid': 'yinyangguiyihuan',
        'pages': {
            'yinyangguiyihuan1': 1,
            'yinyangguiyihuan2': 1,
            'yinyangguiyihuan3': 1,
            'yinyangguiyihuan4': 1,
            'yinyangguiyihuan5': 1,
        },
        'canye': {
            'yinyanghuanzhencanye': 10,
        },
    },
    '2021jhshbox09': {
        'name': '飞影十三逝残篇礼盒',
        'skillid': 'feiyingshisanshi',
        'pages': {
            'feiyingshisanshi1': 1,
            'feiyingshisanshi2': 1,
            'feiyingshisanshi3': 1,
            'feiyingshisanshi4': 1,
            'feiyingshisanshi5': 1,
        },
        'canye': {
            'shuangyingshicanye': 10,
        },
    },
    '2021jhshbox04': {
        'name': '骤雨狂风斧残篇礼盒',
        'skillid': 'zhouyukuangfengfu',
        'pages': {
            'zhouyukuangfengfu1': 1,
            'zhouyukuangfengfu2': 1,
            'zhouyukuangfengfu3': 1,
            'zhouyukuangfengfu4': 1,
        },
        'canye': {
            'baoyuzhouluocanye': 10,
        },
    },
    '21qybaogelibao1': {
        'name': '卿云宝阁武学礼包',
        'skillid': 'baimangbianfa',
        'pages': {
            'baimangbianfa1': 1,
            'baimangbianfa2': 1,
            'baimangbianfa3': 1,
            'baimangbianfa4': 1,
            'baimangbianfa5': 1,
        },
        'canye': {
            'bianzoulongshecanye': 10,
        },
    },
    '21yunyinglibao3': {
        'name': '盛唐隐武卷',
        'skillid': 'tianyanxinjing',
        'pages': {
            'tianyanxinjing1': 1,
            'tianyanxinjing2': 1,
            'tianyanxinjing3': 1,
            'tianyanxinjing4': 1,
            'tianyanxinjing5': 1,
        },
        'canye': {
            'jiedaocanye': 10,
        },
    },
    'newfudai180': {
        'name': '一月每日福袋',
        'skillid': 'liehuobianfa',
        'pages': {
            'shuye79': 1,
            'shuye80': 1,
            'shuye81': 1,
            'shuye82': 1,
        },
        'canye': {
            'qinlueruhuocanye': 2,
        },
    },
    'newfudai216': {
        'name': '一月每日福袋',
        'skillid': 'xiaoyaowuxiangjian',
        'pages': {
            'shuye25': 1,
            'shuye26': 1,
            'shuye27': 1,
            'shuye28': 1,
            'shuye29': 1,
        },
        'canye': {
            'wuxingwuxiangcanye': 10,
            'yufengxiaoyaocanye': 10,
        },
    },
    'newfudai126': {
        'name': '七月每日福袋',
        'skillid': 'xiaoyaowuxiangjian',
        'pages': {
            'shuye25': 1,
            'shuye26': 1,
            'shuye27': 1,
            'shuye28': 1,
            'shuye29': 1,
        },
        'canye': {
            'wuxingwuxiangcanye': 10,
            'yufengxiaoyaocanye': 10,
        },
    },
    'newfudai162': {
        'name': '七月每日福袋',
        'skillid': 'fanliangyidaofa',
        'pages': {
            'shuye108': 1,
            'shuye109': 1,
            'shuye110': 1,
            'shuye111': 1,
        },
        'canye': {
            'sixiangbaguacanye': 5,
        },
    },
    'newfudai198': {
        'name': '七月每日福袋',
        'skillid': 'hualingliushuizhang',
        'pages': {
            'shuye89': 1,
            'shuye90': 1,
            'shuye91': 1,
            'shuye92': 1,
        },
        'canye': {
            'shizherusicanye': 2,
        },
    },
    'newfudai54': {
        'name': '七月每日福袋',
        'skillid': 'xianyindaofa',
        'pages': {
            'shuye20': 1,
            'shuye21': 1,
            'shuye22': 1,
            'shuye23': 1,
            'shuye24': 1,
        },
        'canye': {
            'xianwaizhiyincanye': 10,
            'xianyouzaiercanye': 10,
        },
    },
    'newfudai90': {
        'name': '七月每日福袋',
        'skillid': 'wuxingquan',
        'pages': {
            'wuxingquan2': 1,
            'wuxingquan3': 1,
            'wuxingquan4': 1,
            'wuxingquan5': 1,
        },
        'canye': {
            'taisuicanye': 2,
        },
    },
    'newfudai114': {
        'name': '三月每日福袋',
        'skillid': 'zhuiyingsuifengqiang',
        'pages': {
            'zhuiyingsuifengqiang1': 1,
            'zhuiyingsuifengqiang2': 1,
            'zhuiyingsuifengqiang3': 1,
            'zhuiyingsuifengqiang4': 1,
        },
        'canye': {
            'fengdingtiannancanye': 10,
        },
    },
    'newfudai150': {
        'name': '三月每日福袋',
        'skillid': 'zhuiyingsuifengqiang',
        'pages': {
            'zhuiyingsuifengqiang1': 1,
            'zhuiyingsuifengqiang2': 1,
            'zhuiyingsuifengqiang3': 1,
            'zhuiyingsuifengqiang4': 1,
        },
        'canye': {
            'fengdingtiannancanye': 10,
        },
    },
    'newfudai186': {
        'name': '三月每日福袋',
        'skillid': 'hualingliushuizhang',
        'pages': {
            'shuye89': 1,
            'shuye90': 1,
            'shuye91': 1,
            'shuye92': 1,
        },
        'canye': {
            'shizherusicanye': 2,
        },
    },
    'newfudai222': {
        'name': '三月每日福袋',
        'skillid': 'jiangxingpoegou',
        'pages': {
            'jiangxingpoegou1': 1,
            'jiangxingpoegou2': 1,
            'jiangxingpoegou3': 1,
            'jiangxingpoegou4': 1,
            'jiangxingpoegou5': 1,
        },
        'canye': {
            'eguanmanyingcanye': 10,
        },
    },
    'newfudai78': {
        'name': '三月每日福袋',
        'skillid': 'liushiyunxingshenfa',
        'pages': {
            'shuye36': 1,
            'shuye37': 1,
            'shuye38': 1,
        },
        'canye': {
            'tianhuojianglincanye': 2,
        },
    },
    'newfudai132': {
        'name': '九月每日福袋',
        'skillid': 'yinyangdaoluanrenfa',
        'pages': {
            'yinyangdaoluanren1': 1,
            'yinyangdaoluanren2': 1,
            'yinyangdaoluanren3': 1,
            'yinyangdaoluanren4': 1,
        },
        'canye': {
            'yinyangtiaohecanye': 5,
        },
    },
    'newfudai168': {
        'name': '九月每日福袋',
        'skillid': 'jiangxingpoegou',
        'pages': {
            'jiangxingpoegou1': 1,
            'jiangxingpoegou2': 1,
            'jiangxingpoegou3': 1,
            'jiangxingpoegou4': 1,
            'jiangxingpoegou5': 1,
        },
        'canye': {
            'eguanmanyingcanye': 10,
        },
    },
    'newfudai204': {
        'name': '九月每日福袋',
        'skillid': 'liehuobianfa',
        'pages': {
            'shuye79': 1,
            'shuye80': 1,
            'shuye81': 1,
            'shuye82': 1,
        },
        'canye': {
            'qinlueruhuocanye': 2,
        },
    },
    'newfudai60': {
        'name': '九月每日福袋',
        'skillid': 'baimangbianfa',
        'pages': {
            'baimangbianfa1': 1,
            'baimangbianfa2': 1,
            'baimangbianfa3': 1,
            'baimangbianfa4': 1,
            'baimangbianfa5': 1,
        },
        'canye': {
            'bianzoulongshecanye': 10,
        },
    },
    'newfudai96': {
        'name': '九月每日福袋',
        'skillid': 'yinyangdaoluanrenfa',
        'pages': {
            'yinyangdaoluanren1': 1,
            'yinyangdaoluanren2': 1,
            'yinyangdaoluanren3': 1,
            'yinyangdaoluanren4': 1,
        },
        'canye': {
            'yinyangtiaohecanye': 5,
        },
    },
    'newfudai111': {
        'name': '二月每日福袋',
        'skillid': 'baimangbianfa',
        'pages': {
            'baimangbianfa1': 1,
            'baimangbianfa2': 1,
            'baimangbianfa3': 1,
            'baimangbianfa4': 1,
            'baimangbianfa5': 1,
        },
        'canye': {
            'bianzoulongshecanye': 10,
        },
    },
    'newfudai147': {
        'name': '二月每日福袋',
        'skillid': 'yechagunfa',
        'pages': {
            'shuye69': 1,
            'shuye70': 1,
            'shuye71': 1,
            'shuye72': 1,
            'shuye73': 1,
        },
        'canye': {
            'xunshanyechacanye': 2,
        },
    },
    'newfudai183': {
        'name': '二月每日福袋',
        'skillid': 'yinyangdaoluanrenfa',
        'pages': {
            'yinyangdaoluanren1': 1,
            'yinyangdaoluanren2': 1,
            'yinyangdaoluanren3': 1,
            'yinyangdaoluanren4': 1,
        },
        'canye': {
            'yinyangtiaohecanye': 5,
        },
    },
    'newfudai219': {
        'name': '二月每日福袋',
        'skillid': 'yinyangdaoluanrenfa',
        'pages': {
            'yinyangdaoluanren1': 1,
            'yinyangdaoluanren2': 1,
            'yinyangdaoluanren3': 1,
            'yinyangdaoluanren4': 1,
        },
        'canye': {
            'yinyangtiaohecanye': 5,
        },
    },
    'newfudai75': {
        'name': '二月每日福袋',
        'skillid': 'zhouyukuangfengfu',
        'pages': {
            'zhouyukuangfengfu1': 1,
            'zhouyukuangfengfu2': 1,
            'zhouyukuangfengfu3': 1,
            'zhouyukuangfengfu4': 1,
        },
        'canye': {
            'baoyuzhouluocanye': 10,
        },
    },
    'newfudai120': {
        'name': '五月每日福袋',
        'skillid': 'fanliangyidaofa',
        'pages': {
            'shuye108': 1,
            'shuye109': 1,
            'shuye110': 1,
            'shuye111': 1,
        },
        'canye': {
            'sixiangbaguacanye': 5,
        },
    },
    'newfudai156': {
        'name': '五月每日福袋',
        'skillid': 'xiaoyaowuxiangjian',
        'pages': {
            'shuye25': 1,
            'shuye26': 1,
            'shuye27': 1,
            'shuye28': 1,
            'shuye29': 1,
        },
        'canye': {
            'wuxingwuxiangcanye': 10,
            'yufengxiaoyaocanye': 10,
        },
    },
    'newfudai192': {
        'name': '五月每日福袋',
        'skillid': 'jiangxingpoegou',
        'pages': {
            'jiangxingpoegou1': 1,
            'jiangxingpoegou2': 1,
            'jiangxingpoegou3': 1,
            'jiangxingpoegou4': 1,
            'jiangxingpoegou5': 1,
        },
        'canye': {
            'eguanmanyingcanye': 10,
        },
    },
    'newfudai228': {
        'name': '五月每日福袋',
        'skillid': 'yinyangdaoluanrenfa',
        'pages': {
            'yinyangdaoluanren1': 1,
            'yinyangdaoluanren2': 1,
            'yinyangdaoluanren3': 1,
            'yinyangdaoluanren4': 1,
        },
        'canye': {
            'yinyangtiaohecanye': 5,
        },
    },
    'newfudai84': {
        'name': '五月每日福袋',
        'skillid': 'qianhunlie',
        'pages': {
            'qianhunlie1': 1,
            'qianhunlie2': 1,
            'qianhunlie3': 1,
            'qianhunlie4': 1,
            'qianhunlie5': 1,
        },
        'canye': {
            'xiaogushacanye': 10,
        },
    },
    'newfudai129': {
        'name': '八月每日福袋',
        'skillid': 'wuhenjin',
        'pages': {
            'wuhenjin1': 1,
            'wuhenjin2': 1,
            'wuhenjin3': 1,
            'wuhenjin4': 1,
        },
        'canye': {
            'pokongcanye': 5,
        },
    },
    'newfudai165': {
        'name': '八月每日福袋',
        'skillid': 'qinlonggong',
        'pages': {
            'qinlonggong1': 1,
            'qinlonggong2': 1,
            'qinlonggong3': 1,
            'qinlonggong4': 1,
            'qinlonggong5': 1,
        },
        'canye': {
            'canglongtuokuncanye': 10,
        },
    },
    'newfudai201': {
        'name': '八月每日福袋',
        'skillid': 'xiaoyaowuxiangjian',
        'pages': {
            'shuye25': 1,
            'shuye26': 1,
            'shuye27': 1,
            'shuye28': 1,
            'shuye29': 1,
        },
        'canye': {
            'wuxingwuxiangcanye': 10,
            'yufengxiaoyaocanye': 10,
        },
    },
    'newfudai57': {
        'name': '八月每日福袋',
        'skillid': 'jiangshibufa',
        'pages': {
            'jiangshibufa2': 1,
            'jiangshibufa3': 1,
            'jiangshibufa4': 1,
            'jiangshibufa5': 1,
        },
        'canye': {
            'sierbujiangcanye': 5,
        },
    },
    'newfudai93': {
        'name': '八月每日福袋',
        'skillid': 'xiaolifeidao',
        'pages': {
            'xiaolifeidao1': 1,
            'xiaolifeidao2': 1,
            'xiaolifeidao3': 1,
            'xiaolifeidao4': 1,
            'xiaolifeidao5': 1,
        },
        'canye': {
            'liwuxufacanye': 10,
        },
    },
    'newfudai123': {
        'name': '六月每日福袋',
        'skillid': 'cangfengdaofa',
        'pages': {
            'cangfengdaofa1': 1,
            'cangfengdaofa2': 1,
            'cangfengdaofa3': 1,
            'cangfengdaofa4': 1,
            'cangfengdaofa5': 1,
        },
        'canye': {
            'daorenduofengcanye': 10,
        },
    },
    'newfudai159': {
        'name': '六月每日福袋',
        'skillid': 'yinyangdaoluanrenfa',
        'pages': {
            'yinyangdaoluanren1': 1,
            'yinyangdaoluanren2': 1,
            'yinyangdaoluanren3': 1,
            'yinyangdaoluanren4': 1,
        },
        'canye': {
            'yinyangtiaohecanye': 5,
        },
    },
    'newfudai195': {
        'name': '六月每日福袋',
        'skillid': 'feixianjianfa',
        'pages': {
            'shuye16': 1,
            'shuye17': 1,
            'shuye18': 1,
            'shuye19': 1,
        },
        'canye': {
            'yijianxilaicanye': 5,
        },
    },
    'newfudai231': {
        'name': '六月每日福袋',
        'skillid': 'liehuobianfa',
        'pages': {
            'shuye79': 1,
            'shuye80': 1,
            'shuye81': 1,
            'shuye82': 1,
        },
        'canye': {
            'qinlueruhuocanye': 2,
        },
    },
    'newfudai87': {
        'name': '六月每日福袋',
        'skillid': 'baimangbianfa',
        'pages': {
            'baimangbianfa1': 1,
            'baimangbianfa2': 1,
            'baimangbianfa3': 1,
            'baimangbianfa4': 1,
            'baimangbianfa5': 1,
        },
        'canye': {
            'bianzoulongshecanye': 10,
        },
    },
    'newfudai102': {
        'name': '十一月每日福袋',
        'skillid': 'liehuobianfa',
        'pages': {
            'shuye79': 1,
            'shuye80': 1,
            'shuye81': 1,
            'shuye82': 1,
        },
        'canye': {
            'qinlueruhuocanye': 2,
        },
    },
    'newfudai138': {
        'name': '十一月每日福袋',
        'skillid': 'xiaoyaowuxiangjian',
        'pages': {
            'shuye25': 1,
            'shuye26': 1,
            'shuye27': 1,
            'shuye28': 1,
            'shuye29': 1,
        },
        'canye': {
            'wuxingwuxiangcanye': 10,
            'yufengxiaoyaocanye': 10,
        },
    },
    'newfudai174': {
        'name': '十一月每日福袋',
        'skillid': 'jiangxingpoegou',
        'pages': {
            'jiangxingpoegou1': 1,
            'jiangxingpoegou2': 1,
            'jiangxingpoegou3': 1,
            'jiangxingpoegou4': 1,
            'jiangxingpoegou5': 1,
        },
        'canye': {
            'eguanmanyingcanye': 10,
        },
    },
    'newfudai210': {
        'name': '十一月每日福袋',
        'skillid': 'liehuobianfa',
        'pages': {
            'shuye79': 1,
            'shuye80': 1,
            'shuye81': 1,
            'shuye82': 1,
        },
        'canye': {
            'qinlueruhuocanye': 2,
        },
    },
    'newfudai66': {
        'name': '十一月每日福袋',
        'skillid': 'baimangbianfa',
        'pages': {
            'baimangbianfa1': 1,
            'baimangbianfa2': 1,
            'baimangbianfa3': 1,
            'baimangbianfa4': 1,
            'baimangbianfa5': 1,
        },
        'canye': {
            'bianzoulongshecanye': 10,
        },
    },
    'newfudai105': {
        'name': '十二月每日福袋',
        'skillid': 'baiyuantongbeiquan',
        'pages': {
            'baiyuantongbiquan1': 1,
            'baiyuantongbiquan2': 1,
            'baiyuantongbiquan3': 1,
            'baiyuantongbiquan4': 1,
        },
        'canye': {
            'suqinbeijiancanye': 2,
        },
    },
    'newfudai141': {
        'name': '十二月每日福袋',
        'skillid': 'jiayishengong',
        'pages': {
            'jiayishengong1': 1,
            'jiayishengong2': 1,
            'jiayishengong3': 1,
            'jiayishengong4': 1,
            'jiayishengong5': 1,
        },
        'canye': {
            'poerhoulicanye': 5,
        },
    },
    'newfudai177': {
        'name': '十二月每日福袋',
        'skillid': 'feixianjianfa',
        'pages': {
            'shuye16': 1,
            'shuye17': 1,
            'shuye18': 1,
            'shuye19': 1,
        },
        'canye': {
            'yijianxilaicanye': 5,
        },
    },
    'newfudai213': {
        'name': '十二月每日福袋',
        'skillid': 'jiangxingpoegou',
        'pages': {
            'jiangxingpoegou1': 1,
            'jiangxingpoegou2': 1,
            'jiangxingpoegou3': 1,
            'jiangxingpoegou4': 1,
            'jiangxingpoegou5': 1,
        },
        'canye': {
            'eguanmanyingcanye': 10,
        },
    },
    'newfudai69': {
        'name': '十二月每日福袋',
        'skillid': 'wuxudaofa',
        'pages': {
            'wuxudaofa1': 1,
            'wuxudaofa2': 1,
            'wuxudaofa3': 1,
            'wuxudaofa4': 1,
        },
        'canye': {
            'xiongnianequancanye': 5,
        },
    },
    'newfudai135': {
        'name': '十月每日福袋',
        'skillid': 'wangshenggong',
        'pages': {
            'wangshenggong1': 1,
            'wangshenggong2': 1,
            'wangshenggong3': 1,
            'wangshenggong4': 1,
            'wangshenggong5': 1,
        },
        'canye': {
            'wangshengjilecanye': 10,
        },
    },
    'newfudai171': {
        'name': '十月每日福袋',
        'skillid': 'xiaoyaowuxiangjian',
        'pages': {
            'shuye25': 1,
            'shuye26': 1,
            'shuye27': 1,
            'shuye28': 1,
            'shuye29': 1,
        },
        'canye': {
            'wuxingwuxiangcanye': 10,
            'yufengxiaoyaocanye': 10,
        },
    },
    'newfudai207': {
        'name': '十月每日福袋',
        'skillid': 'feixianjianfa',
        'pages': {
            'shuye16': 1,
            'shuye17': 1,
            'shuye18': 1,
            'shuye19': 1,
        },
        'canye': {
            'yijianxilaicanye': 5,
        },
    },
    'newfudai63': {
        'name': '十月每日福袋',
        'skillid': 'tiannvsanhuashou',
        'pages': {
            'tiannvsanhuashou1': 1,
            'tiannvsanhuashou2': 1,
            'tiannvsanhuashou3': 1,
        },
        'canye': {
            'bafengbudongcanye': 1,
        },
    },
    'newfudai99': {
        'name': '十月每日福袋',
        'skillid': 'wuxingquan',
        'pages': {
            'wuxingquan2': 1,
            'wuxingquan3': 1,
            'wuxingquan4': 1,
            'wuxingquan5': 1,
        },
        'canye': {
            'taisuicanye': 2,
        },
    },
    'newfudai117': {
        'name': '四月每日福袋',
        'skillid': 'yechagunfa',
        'pages': {
            'shuye69': 1,
            'shuye70': 1,
            'shuye71': 1,
            'shuye72': 1,
            'shuye73': 1,
        },
        'canye': {
            'xunshanyechacanye': 2,
        },
    },
    'newfudai153': {
        'name': '四月每日福袋',
        'skillid': 'wuxingquan',
        'pages': {
            'wuxingquan2': 1,
            'wuxingquan3': 1,
            'wuxingquan4': 1,
            'wuxingquan5': 1,
        },
        'canye': {
            'taisuicanye': 2,
        },
    },
    'newfudai189': {
        'name': '四月每日福袋',
        'skillid': 'wuxingquan',
        'pages': {
            'wuxingquan2': 1,
            'wuxingquan3': 1,
            'wuxingquan4': 1,
            'wuxingquan5': 1,
        },
        'canye': {
            'taisuicanye': 2,
        },
    },
    'newfudai225': {
        'name': '四月每日福袋',
        'skillid': 'qinlonggong',
        'pages': {
            'qinlonggong1': 1,
            'qinlonggong2': 1,
            'qinlonggong3': 1,
            'qinlonggong4': 1,
            'qinlonggong5': 1,
        },
        'canye': {
            'canglongtuokuncanye': 10,
        },
    },
    'newfudai81': {
        'name': '四月每日福袋',
        'skillid': 'liehuobianfa',
        'pages': {
            'shuye79': 1,
            'shuye80': 1,
            'shuye81': 1,
            'shuye82': 1,
        },
        'canye': {
            'qinlueruhuocanye': 2,
        },
    },
    'newfudai51': {
        'name': '每日福袋',
        'skillid': 'tiexueshijian',
        'pages': {
            'tiexueshijian1': 1,
            'tiexueshijian2': 1,
            'tiexueshijian3': 1,
            'tiexueshijian4': 1,
            'tiexueshijian5': 1,
        },
        'canye': {
            'yixueweishicanye': 10,
        },
    },
}


def is_combo_box(iid):
    """反查：itemId 是不是合体箱。"""
    return iid in COMBO_BOXES


def box_total(info):
    """一开总共给几件。"""
    return sum(info['pages'].values()) + sum(info['canye'].values())


def _rows(ids):
    """按 id 顺序生成货架行。

    ★ `itype=10`（不是 12）：`StoreLayer.lua:526` 用 `itype == 10 or 12` 弹数量框，
      但 `:362` 的 `itype == 12`（神功虚拟物品）**买完不进背包** ——
      而宝箱必须真进背包才能开，所以走 10（`:366` 的 else ⇒ `addItemCount`）。

    ★ 描述用**原版物品自己的 `dsc`**（老板 2026-09-28 指出：之前那段
      「江湖失传已久的神功…」是我编的，背包里显示的才是真描述）。
      购买框 `StoreDialogLayer.lua:23,69-80` 读 `dsc1`+`dsc2`（`desc1.."\\n"..desc2`），
      所以把原版 `dsc` 放 `dsc1`、`dsc2` 留空（与原版商城其他商品同一形态）。
    """
    rows = []
    for iid in ids:
        info = COMBO_BOXES.get(iid)
        if not info:
            continue
        dsc = vanilla_dsc(iid)
        rows.append({
            'id': iid, 'itemId': iid,
            'name': info['name'],
            'dsc': dsc, 'dsc1': dsc, 'dsc2': '',
            'icon': vanilla_icon(iid),
            'price': COMBO_PRICE, 'priceUnit': 'yuanbao',
            'number': 1, 'itype': 10, 'type': 10, 'unit': '个',
            'share': '', 'discount': 1, 'isBuy': 0,
        })
    return rows


def hard_shelf_rows():
    """「不容易获取的 64 个」货架行。

    ★ 摆哪个页签由 `fz_boot_server.py` 决定，本函数**不代表页签**：
      老板 2026-09-28 追加指示「神功与限时互换」⇒ 现由「神功」页签调用。
    """
    return _rows(HARD_IDS)


def combo_shelf_rows():
    """「每日福袋系列 58 个」货架行。

    ★ 同上：现由「限时」页签调用（互换后）。
    """
    return _rows(EASY_IDS)
