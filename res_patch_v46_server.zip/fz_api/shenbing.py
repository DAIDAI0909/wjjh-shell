# -*- coding: utf-8 -*-
# ================= 离线包路径根（fz_make_offline_bundle.py 自动注入） =================
# 手机上整个服务端就是一个目录，表在哪、状态写哪，全部相对包根算。
# （有的模块原来把绝对路径写死，本身没 import os —— 这里一并补上）
import os
import os as _osp


def _off_find_bundle(_f):
    """从模块所在目录往上找包根（认 fz_boot_server.py）。
    ★ fz_api/*.py 的 __file__ 在 <根>/fz_api/ 下，直接 dirname 会算错一层。"""
    _d = _osp.path.dirname(_osp.path.abspath(_f))
    for _ in range(6):
        if _osp.path.exists(_osp.path.join(_d, 'fz_boot_server.py')):
            return _d
        _u = _osp.path.dirname(_d)
        if _u == _d:
            break
        _d = _u
    return _osp.path.dirname(_osp.path.abspath(_f))


_OFF_BUNDLE = _off_find_bundle(__file__)
_OFF_FZ_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_fz')
_OFF_INK_ROOT = _osp.path.join(_OFF_BUNDLE, 'client_ink')
_OFF_WORK_ROOT = _OFF_BUNDLE
# =====================================================================================
# ★ 2026-10-04 商城空货架修复：客户端资源表解析——PC 开发树优先，设备上自动回退
#   到包内 client_fz 副本（jhserver/client_fz = fangzhi_lua_dec 的同步拷贝）。
def _fz_res(*parts):
    base = os.path.join(_OFF_FZ_ROOT, 'res', 'script')
    if not os.path.isdir(base):
        base = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            '..', 'client_fz', 'res', 'script')
    return os.path.join(base, *parts)

# -*- coding: utf-8 -*-
"""神兵 —— 武器打造 / 升级 / 淬炼 / 藏兵洞（`views/layer/ShenBingLayer`、`models/ShenBing`、
`models/skill/skillBreakThrough`）。

===========================================================================
一、契约（逐个读过她的客户端源码 + `app/extends/Http/HttpManager.lua` 的 URL）
===========================================================================
★ 权威 HttpManager 是 `app/extends/Http/HttpManager.lua`（`Loader.lua:272`
  `HttpManagerEx = require("app.extends.Http.HttpManager")`）；`app/extends/HttpManager.lua`
  是旧的重复副本，参数个数都不一样（`skillBreakThrough` 少一个 currencyVersion）。
  一律以后者（`extends/Http/`）为准。

| 接口(URL 末段) | 上行 | 她读的 `data.字段`（类型） | 出处 |
|---|---|---|---|
| `contains_blocked_word` GET/POST `{s}` | 名字 | **只看 errcode**：`0` 放行；`1` 表示"含屏蔽词"，她再用本地词库报出错词；其它 `PopText(errmsg)` | `ShenBingNameLayer.lua:425-493` |
| `get_random_weapon_desc/<wType>` GET | 武器类型号 | `weapon_out`(**串**) `weapon_in`(**串**) —— `string.gsub(data.weapon_out,"$N",...)` ⇒ **给 nil/数字直接 attempt to concatenate** | `XiuLi.lua:286-304` |
| `get_weapon_cuilian_num` POST `{wid,itemId}` | 武器 id | **`data` 本身就是映射表** `{淬炼材料id = 成功次数}`：`for k,v in pairs(data) do cuilianTimes = v + cuilianTimes` ⇒ ①**不能带 `dataVer`**（会被当次数累加）②值必须是**数字** | `RongBingLayer.lua:89-129` |
| `incr_weapon_cuilian_num` POST `{wid,results,sum}` | `results={材料id={sucNum,defNum}}` | **只看 errcode**（`data` 不读） | `ShenBingCuiLianLayer.lua:452` / `ShenBingNPCCuiLianLayer.lua:498` / `ShenBingAutoCuiLianDetailLayer.lua:517` |
| `make_weapon` POST `{weapon_type,weapon_name,weapon_color}` | 类型号/名字/颜色号 | `desc`(串) `out`(串) `weapon_in`(串) —— 调用点已被她注释掉（`DaZao.lua:597-612`），但契约是 `self:setDesc(data.desc,data.out,data.weapon_in)` | `DaZao.lua:597-612`（注释残留）+ `permissive_stub.json` |
| `upgrade_weapon` POST `params2` | `{weapon_type,weapon_name,weapon_color,weapon_gold_level,weapon_neili_level,weapon_neilicast,weapon_goldcast}` | `desc`(**串**，`Text_Weapon_Desc:setString(data.desc)` ⇒ 数字会让 cocos 绑定报错) | `ShenBingLayer.lua:792-882`(内力) / `:1007-1070`(黄金) |
| `remove_yuanbao/<num>/<trans_id>` GET | 元宝数/流水号 | `data` 只要**非空**：`MapIsEmpty(data)` 为空时她 `PopText("网络异常")`；`errcode==0` 才算扣成功 | `XiuLi.lua:331-356`（`SHENBING_JIAGONG_PAYYUANBAO=30`，`Definition.lua:170`） |
| `update_data_state` POST `{id,state}` | 数据标识/状态 | **只看 errcode**（`data` 不读） | `XuanBingDongOld.lua:255` / `CangYiGeOld.lua:224` |
| `get_user_shenbings` GET | — | `shenBingItems`(**数组**，元素至少 `id` `typeDesc`)：`pairs(shenBings)` + `shenBing.id` + `shenBing.typeDesc` | `ShenBingRepair.lua:592-614` |
| `martial_upgrade` POST `{id,martial_id,currencyVersion}` | 下一突破id/武学id | `reitem_list`(**数组**，元素 `{id,num}`，被 `ipairs` + `addItemCount(v.id,-v.num)`)；`currencyVersion`(数)；**`currency_list`(对象，必须含 `amartial/bmartial/cmartial/dmartial` 四个数)** | `SkillBreakThroughSystem.lua:156-178` → `SkillBreakPopPresent.lua:85` → `SkillBreakThroughPresent.lua:22-28,62-67`（少一个键就 `attempt to index a nil value`） |
| `zhao_upgrade` POST `{id,zhao_id,currencyVersion}` | 下一突破id/招式id | `reitem_list`(**数组**) `currencyVersion`(数) | `SkillBreakThroughSystem.lua:223-239` → `ZhaoBreakPopPresent.lua:81` |

**上行正文是密文**，`ctx.param()` 已解好明文；URL 参数走 `ctx.args`。

===========================================================================
二、内容全从她自己的资源表来（没有一条是我编的）
===========================================================================
* `res/script/others/godweapon/weaponTakeOffDesc.lua`（161 条，7 种 `equipmenttype`）
  → `Takedes`(回鞘=`weapon_in`) / `Weardes`(拔剑=`weapon_out`) / `desid` / `equipmenttype`。
* `res/script/others/godweapon/weaponDesc.lua`（75 行）→ 重量/硬度/坚韧度的措辞
  （`weight1`/`hard1`/`Tenacity1` 是 `"下界;上界"` 区间 + `*dsc` 措辞），
  按 `ShenBingDesc.lua:6-46,176-185` 的规则建索引。
* `res/script/others/godweapon/weaponAppearanceDesc.lua`（49 条）→ 外观描述
  `weapontype1..7` = 剑/刀/棍/鞭/双持/乐器/暗器（顺序见 `ShenBingDesc.lua:111-123`）。
* `res/script/others/godweapon/weaponSpecials.lua`（84 条）→ 特性文本 `specialtext`。
* `res/script/others/godweapon/itemOfFurnaceInfo.lua`（348 条）→ 锻造基础属性
  `Forgingdamage/Forginghardness/Forgingtoughness/Forgingweight/Forgingcharacteristics/
  Forgingdsc/Forgingcolor`，按 `(itemid, forgingweapon)` 查（`ShenBingDuanZao.lua:97-107`）。
  老的"第一批神兵"统一用 `duanzaocailiao2`(镔铁) + 长剑/长刀/长棍/长鞭
  （`ShenBingDuanZao.lua:858-876` 的 `transBaseList`），这里照抄。
* `res/script/others/godweapon/cuiLianOfWepon.lua` → 淬炼材料 `Cuilianid` 白名单
  （`ShenBingCuiLianLayer.lua:658-666` 用的就是它）。
* `res/script/others/officalMaskWords{1,2,3}.lua` + `others/gameMaskWords.lua`
  → 屏蔽词（共 58000 条；`MaskWordsConfig.lua:getBaseMaskWords()` 读的就是这几张表）。
* `res/script/skill/skillBreakThrough.lua["武学突破"]`（11 档）→ `resource`(货币消耗) `reitem`(道具)
* `res/script/skill/zhaoBreakThrough.lua["技能突破"]`（89 条，9 组 `activeSkillType`）→ `reitem`
* `res/script/skill/breakThroughItems.lua["Items"]`（24 张续卷）→ 名字（报错文案用）
* `res/script/skill/activeZhao.lua`（8.4MB，只按需 regex 建 `招式名→activeSkillType` 索引，
  不做全量解析）→ 校验 `zhao_upgrade` 的 `zhao_id` 与 `id` 是否同一类招式。
* **她的存档**（`work/saves/<md5(uuid|userid)[:16]>.json`，取自
  `fz_boot_server.py:551-603` 的 `save_upload/save_download`；没有就退 `work/roles/full.json`）
  → `shenBingItems`（她客户端真正持有的神兵本体，1:1 的"历史存档神兵数据"）。

===========================================================================
三、状态（真写盘）
===========================================================================
`work/shenbing_state.json`（本模块独占，不碰别人的钱/背包）：
```
shenbings   {武器id: {神兵本体…}}        —— make_weapon/upgrade_weapon 落的服务端镜像
cuilian     {武器id: {材料id: {suc,def}}} —— incr_weapon_cuilian_num 的账（get_weapon_cuilian_num 回它）
cuilianSum  {武器id: 她上报的 cuilianCount}
datastate   {数据标识: 状态}             —— update_data_state
forgeCount / currencyVersion / log / userid / updated
```
**元宝一律走 `fz_api/items_currency.py` 导出的接口**（`IC.get_currency/add_currency/spend/
get_count/currency_name`），本模块**不另存一份钱**；突破的货币消耗（`amartial` 武学要领…）
也走同一份钱袋子 `work/homeland_state.json["currency"]`。

===========================================================================
四、已知的取舍 / 还没做（诚实清单）
===========================================================================
1. **背包/冶炼箱里的物品是客户端权威**：`ShenBingObserveLayer.lua` / `XuanBingDong.lua` /
   `FixLayer/ShenBingDuanQiLayer.lua` 里 `role:getItemCount("shenitem1")` 读的是**她客户端背包**，
   服务端不伪造背包，也不替她扣这些。本模块只管神兵本体的打造/升级/淬炼数据。
2. `get_weapon_cuilian_num` **故意不带 `dataVer`**（见上表），空表就是"没淬炼过"。
   服务端账本从空开始 ⇒ 先于服务端的淬炼次数补不回来（她 `shenBingItems[].cuilianitems`
   在现版客户端里只被初始化、从不写入，所以没有更好的真数据源）。
3. `upgrade_weapon` 的 `desc`：升级本身**不改**重量/硬度/坚韧度（只改 damage/lv），
   所以描述本该不变。服务端按"存档里的这把神兵 → 服务端镜像 → 镔铁基础值"顺序取真属性重算
   （`ShenBingDesc:getShenBingDesc` 的 Python 移植）。上行**没带武器 id**，
   只能按 `weapon_name`+`weapon_type` 匹配，匹配不到就退基础值 ⇒ 淬炼过又匹配不上的武器，
   描述里的重量/硬度措辞可能是基础档而不是当前档。**这是已知缺口，不是假数据。**
4. `make_weapon` 她客户端已把调用注释掉（`DaZao.lua:604`），所以打造走的是她本地流程；
   服务端这条接口按契约把 `desc/out/weapon_in` 都给全，并把神兵落到 `shenbings` 里。
5. 武学突破的 `resource` 是货币（`amartial` 武学要领等）。**目前没有别的模块发放这些货币**，
   所以新号点突破会拿到"武学要领不足"这个真业务门（`items_currency` 里 `amartial` 还是 0）。
6. 不属于我清单、但确实缺的：`get_ckitems_list`（玄兵洞/藏衣阁仓库清单）在分工表里属于
   **`shop_store`**，`get_goods`/`upload_client_data`/`upload_weapon_repair_log` 也不是我的，
   我按"别人的接口别碰"没动它们。
"""
import hashlib
import json
import os
import random
import re
import sys
import time

NAME = 'shenbing'
TITLE = '神兵·锻造/淬炼/升级/藏兵洞'
ENDPOINTS = [
    'contains_blocked_word',
    'get_random_weapon_desc',
    'get_user_shenbings',
    'get_weapon_cuilian_num',
    'incr_weapon_cuilian_num',
    'make_weapon',
    'martial_upgrade',
    'remove_yuanbao',
    'update_data_state',
    'upgrade_weapon',
    'zhao_upgrade',
]

STATE = 'shenbing_state.json'

# ===========================================================================
# 她的资源表
# ===========================================================================
_RES = _fz_res()
_GODWEAPON = os.path.join(_RES, 'others', 'godweapon')
_T_TAKEOFF = os.path.join(_GODWEAPON, 'weaponTakeOffDesc.lua')
_T_WDESC = os.path.join(_GODWEAPON, 'weaponDesc.lua')
_T_APPEAR = os.path.join(_GODWEAPON, 'weaponAppearanceDesc.lua')
_T_SPECIAL = os.path.join(_GODWEAPON, 'weaponSpecials.lua')
_T_FURNACE = os.path.join(_GODWEAPON, 'itemOfFurnaceInfo.lua')
_T_CUILIAN = os.path.join(_GODWEAPON, 'cuiLianOfWepon.lua')
_T_MASK = [os.path.join(_RES, 'others', n) for n in
           ('officalMaskWords1.lua', 'officalMaskWords2.lua', 'officalMaskWords3.lua',
            'gameMaskWords.lua')]
_T_SKILL_BRE = os.path.join(_RES, 'skill', 'skillBreakThrough.lua')
_T_ZHAO_BRE = os.path.join(_RES, 'skill', 'zhaoBreakThrough.lua')
_T_BRE_ITEM = os.path.join(_RES, 'skill', 'breakThroughItems.lua')
_T_ACTIVE_ZHAO = os.path.join(_RES, 'skill', 'activeZhao.lua')

# 武器类型号 ↔ 她表里的 `equipmenttype` / `weapontype1..7`
#   1..4 与 `ShenBingLayer.lua:775-778`、`DaZao.lua:591-594` 的 Type 完全一致；
#   5..7 的顺序取自 `ShenBingDesc.lua:114-120` 的 facade 表。
WTYPE = {1: '剑', 2: '刀', 3: '棍', 4: '鞭', 5: '双持', 6: '乐器', 7: '暗器'}
WTYPE_R = {v: k for k, v in WTYPE.items()}
# 老"第一批神兵"的基础材料与锻造兵器名（`ShenBingDuanZao.lua:858-876` transBaseList）
BASE_ITEM = 'duanzaocailiao2'                       # 镔铁
BASE_BTYPE = {1: '长剑', 2: '长刀', 3: '长棍', 4: '长鞭'}
CURRENCY_LIST_KEYS = ('amartial', 'bmartial', 'cmartial', 'dmartial')
YELLOW = 'HIY'
SHENBING_LV_LIMIT = 100                             # `SHENBING_LV_LIMIT`（她客户端常量）

_LOADS = {}
_MASK_WORDS = None
_ZHAO_TYPE = None
_ZHAO_TXT = None




def _lua(path):
    """用 `work/fz_luatable.py` 解析她的数据表；失败返回 `{}`（绝不抛）。"""
    if path in _LOADS:
        return _LOADS[path]
    val = {}
    try:
        try:
            import fz_luatable
        except ImportError:                     # 以 work 为 cwd 直接跑时
            sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            import fz_luatable
        val = fz_luatable.load_lua_table(path) or {}
        if not isinstance(val, dict):
            val = {}
    except Exception:                           # noqa: BLE001
        val = {}
    _LOADS[path] = val
    return val


def take_off():
    """`godweapon/weaponTakeOffDesc.lua` → {id: 条目}（161 条）。"""
    return _lua(_T_TAKEOFF)


def furnace_info():
    """`godweapon/itemOfFurnaceInfo.lua` → {id: 条目}（348 条）。"""
    return _lua(_T_FURNACE)


def _furnace_by(item_id, forging_weapon):
    """按 `(itemid, forgingweapon)` 取锻造基础属性（`ShenBingDuanZao.lua:97-107`）。"""
    for v in furnace_info().values():
        if isinstance(v, dict) and v.get('itemid') == item_id \
                and v.get('forgingweapon') == forging_weapon:
            return v
    return {}


def cuilian_materials():
    """`godweapon/cuiLianOfWepon.lua` → {淬炼材料id: 条目}（键是 `Cuilianid`）。"""
    out = {}
    for v in _lua(_T_CUILIAN).values():
        if isinstance(v, dict) and v.get('Cuilianid'):
            out.setdefault(str(v['Cuilianid']), v)
    return out


def _split_range(text, default_up=100000):
    """`"0;10"` / `"180;"` / `"45;55"` → (down, up)，缺的按她 `Helper:getDef` 的默认值
    （`ShenBingDesc.lua:36-39`：down 默认 0、up 默认 100000）。"""
    parts = _s(text).split(';')

    def _n(x, d):
        try:
            return int(float(x))
        except (TypeError, ValueError):
            return d
    return _n(parts[0] if parts else '', 0), _n(parts[1] if len(parts) > 1 else '', default_up)


def weapon_desc_rows():
    """`weaponDesc.lua` 按 `ShenBingDesc.lua:6-46` 建索引：
    {兵器类型: {'weight':[{down,up,dsc}], 'yindu':[…], 'rendu':[…]}}。"""
    out = {}
    for v in _lua(_T_WDESC).values():
        if not isinstance(v, dict) or not v.get('weapontype2'):
            continue
        wt = str(v['weapontype2'])
        node = out.setdefault(wt, {'weight': [], 'yindu': [], 'rendu': []})
        for key, field in (('weight', 'weight1'), ('yindu', 'hard1'), ('rendu', 'Tenacity1')):
            down, up = _split_range(v.get(field))
            node[key].append({'down': down, 'up': up, 'dsc': _s(v.get(field + 'dsc'))})
    return out


def _desc_of(key, value, wtype):
    """`ShenBingDesc:getDesc`：`up >= v and down < v` 的那一条的 `*dsc`。"""
    rows = weapon_desc_rows().get(_s(wtype), {}).get(key) or []
    try:
        v = float(value)
    except (TypeError, ValueError):
        return ''
    for row in rows:
        if row['up'] >= v and row['down'] < v:
            return row['dsc']
    return ''


def _facade(look_id, wtype):
    """`ShenBingDesc:getWeaponFacade`：`facade[weaponLookId][weapon.type]`。"""
    if look_id is None or look_id == '':
        return ''
    node = _lua(_T_APPEAR).get(str(look_id))
    if not isinstance(node, dict):
        return ''
    idx = WTYPE_R.get(_s(wtype))
    if not idx:
        return ''
    return _s(node.get('weapontype%d' % idx))


def _effect_text(eff_id):
    """`weaponSpecials.lua` 的 `specialtext`（`ShenBingDesc:getEffctOne/Two/Three`）。"""
    if not eff_id:
        return ''
    for v in _lua(_T_SPECIAL).values():
        if isinstance(v, dict) and _s(v.get('specialid')) == _s(eff_id):
            return _s(v.get('specialtext'))
    return ''


def block_words():
    """她自己的屏蔽词（`MaskWordsConfig:getBaseMaskWords` 读的那几张表，58000 条）。"""
    global _MASK_WORDS
    if _MASK_WORDS is not None:
        return _MASK_WORDS
    words = []
    for p in _T_MASK:
        t = _lua(p)
        node = t.get('Sheet1') if isinstance(t, dict) else None
        if not isinstance(node, dict):
            continue
        for v in node.values():
            if isinstance(v, dict) and v.get('word'):
                w = _s(v['word'])
                if w:
                    words.append(w)
    _MASK_WORDS = words
    return words


def blocked_in(text):
    """等价于 `Helper:isMaskOff`（Trie `findInStr`）：串里含任一词就命中。"""
    s = _s(text)
    if not s:
        return ''
    for w in block_words():
        if w and w in s:
            return w
    return ''


def skill_break():
    """`skill/skillBreakThrough.lua["武学突破"]`（11 档）。"""
    t = _lua(_T_SKILL_BRE)
    node = t.get('武学突破') if isinstance(t, dict) else None
    return node if isinstance(node, dict) else {}


def zhao_break():
    """`skill/zhaoBreakThrough.lua["技能突破"]`（89 条）。"""
    t = _lua(_T_ZHAO_BRE)
    node = t.get('技能突破') if isinstance(t, dict) else None
    return node if isinstance(node, dict) else {}


def break_item_name(item_id):
    t = _lua(_T_BRE_ITEM)
    node = t.get('Items') if isinstance(t, dict) else None
    v = node.get(_s(item_id)) if isinstance(node, dict) else None
    return _s(v.get('name')) if isinstance(v, dict) else ''


def zhao_skill_type(zhao_id):
    """`skill/activeZhao.lua`（8.4MB）→ 招式名 → `activeSkillType`。按需 regex 建索引，
    不整表解析（一张 8.4MB 的表全量 parse 太慢）。取不到返回 None（调用方跳过校验）。"""
    global _ZHAO_TYPE, _ZHAO_TXT
    if _ZHAO_TYPE is None:
        idx = {}
        try:
            with open(_T_ACTIVE_ZHAO, encoding='utf-8', errors='replace') as f:
                _ZHAO_TXT = f.read()
            for m in re.finditer(r'\["([A-Za-z0-9_\-]+)"\]=\{\["activeSkillType"\]=(\d+)',
                                 _ZHAO_TXT):
                idx.setdefault(m.group(1), int(m.group(2)))
        except OSError:
            idx = {}
        _ZHAO_TYPE = idx
    v = _ZHAO_TYPE.get(_s(zhao_id))
    return v


# ===========================================================================
# 小工具
# ===========================================================================
def _s(v):
    if v is None:
        return ''
    if isinstance(v, str):
        return v.strip()
    if isinstance(v, float) and v == int(v):
        return str(int(v))
    return str(v)


def _num(v, d=0):
    try:
        if v is None or v == '':
            return d
        return int(float(v))
    except (TypeError, ValueError):
        return d


def _fnum(v, d=0.0):
    try:
        if v is None or v == '':
            return d
        return float(v)
    except (TypeError, ValueError):
        return d


# ★ 她的名字**带颜色前缀**：`DaZao.lua:46-63,563` 里
#   `shenBingweapon.name = colorname..name`（colorname 是 `RED`/`GRN`/`YEL`… 颜色标签），
#   而 `upgrade_weapon` 上行送的正是这个带前缀的名字 ⇒ 比对前必须剥掉，
#   否则永远匹配不到存档/镜像里的那把神兵。
_COLOR_TAG = re.compile(r'^(?:HI[A-Z]|NOR|YEL|RED|CYN|BLU|GRE|GRN|PUR|WHT|MAG|HIR|HIG|HIB|HIC)+')


def _plain_name(s):
    return _COLOR_TAG.sub('', _s(s)).strip()


def _same_name(a, b):
    a, b = _plain_name(a), _plain_name(b)
    return bool(a) and a == b


def _pairs(v):
    """她的 `{{"amartial",20}}` 被解析成 `{1:['amartial',20]}`（dict）；
    写成数组时是 list。两种都吃，返回 `[[k, n], …]`。"""
    out = []
    if isinstance(v, dict):
        for item in v.values():
            out.append(item)
    elif isinstance(v, list):
        out = list(v)
    res = []
    for item in out:
        if isinstance(item, (list, tuple)) and len(item) >= 2:
            res.append((item[0], _num(item[1])))
    return res


def _uid(ctx):
    return str(ctx.headers.get('userid') or ctx.headers.get('uuid') or 'local')


def _ok_raw(ctx, data, note):
    """`ctx.ok` 对**字典**会自动补 `dataVer`。`get_weapon_cuilian_num` 的应答
    本身就是一张"材料→次数"的字典（她 `pairs` 求和），补进去会被当次数算
    ⇒ 这里手工组装，**不补 dataVer**（她的 `BaseHttp:createGetResponseFunction`
    并不校验 dataVer，只有走 `__saveAction` 的接口才需要）。"""
    return ctx.enc({'errcode': 0, 'data': data, 'rand_t': time.time()}), note


# ===========================================================================
# 状态
# ===========================================================================
def _load(ctx):
    st = ctx.load_json(STATE, None)
    if not isinstance(st, dict):
        st = {}
    for k, d in (('shenbings', {}), ('cuilian', {}), ('cuilianSum', {}),
                 ('datastate', {}), ('log', [])):
        if not isinstance(st.get(k), type(d)):
            st[k] = d
    if not isinstance(st.get('forgeCount'), int):
        st['forgeCount'] = _num(st.get('forgeCount'))
    if not isinstance(st.get('currencyVersion'), int):
        st['currencyVersion'] = _num(st.get('currencyVersion'), 1) or 1
    return st


def _save(ctx, st):
    st['log'] = (st.get('log') or [])[-100:]
    st['userid'] = _uid(ctx)
    st['updated'] = int(time.time())
    ctx.save_json(STATE, st)
    return st


def _mark(st, msg):
    st.setdefault('log', []).append('%d %s' % (int(time.time()), msg))


# ===========================================================================
# 她的存档（客户端权威的神兵本体就在这儿）
# ===========================================================================
def _read_json(path):
    try:
        with open(path, encoding='utf-8', errors='replace') as f:
            d = json.load(f)
    except Exception:                           # noqa: BLE001
        return None
    if isinstance(d, list):                     # `download_user_file_2` 下发的是 [角色档, …]
        for x in d:
            if isinstance(x, dict) and x:
                return x
        return None
    return d if isinstance(d, dict) else None


def _save_path(ctx):
    here = ctx.deps.get('here') or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    uuid = ctx.headers.get('uuid') or 'nouuid'
    userid = ctx.headers.get('userid') or '0'
    # 与 `fz_boot_server.py:551-603` 的 save_upload/save_download 同一把钥匙
    key = hashlib.md5(('%s|%s' % (uuid, userid)).encode()).hexdigest()[:16]
    return here, os.path.join(here, 'saves', key + '.json')


def _role_save(ctx):
    """她的角色档：优先她自己上传的 `saves/<key>.json`，退 `roles/full.json`
    （`--role ours` 时服务端下发的就是我们这份）。谁手里有非空 `shenBingItems` 就用谁。"""
    here, save = _save_path(ctx)
    cands = [_read_json(save), _read_json(os.path.join(here, 'roles', 'full.json'))]
    for d in cands:
        if isinstance(d, dict) and d.get('shenBingItems'):
            return d
    for d in cands:
        if isinstance(d, dict) and d:
            return d
    return {}


def _save_shenbings(ctx):
    """存档里的神兵列表（数组，1-based；她 `shenBingItems` 就是数组）。"""
    d = _role_save(ctx)
    v = d.get('shenBingItems')
    if isinstance(v, dict):                     # 容错：万一存成映射
        v = [x for _, x in sorted(v.items(), key=lambda kv: _num(kv[0]))]
    if not isinstance(v, list):
        return []
    return [x for x in v if isinstance(x, dict)]


def _find_in_save(ctx, weapon_id=None, name='', wtype=''):
    """按 id / 名字（**颜色前缀不敏感**）/ 类型在存档里找那把神兵。"""
    items = _save_shenbings(ctx)
    if weapon_id:
        for w in items:
            if _s(w.get('id')) == _s(weapon_id):
                return w
    if name:
        for w in items:
            if _same_name(w.get('name'), name):
                return w
    if wtype:
        hit = [w for w in items if _s(w.get('type')) == _s(wtype)]
        if len(hit) == 1:
            return hit[0]
    return None


# ===========================================================================
# 神兵描述（`ShenBingDesc:getShenBingDesc` 的 1:1 移植，`ShenBingDesc.lua:324-399`）
# ===========================================================================
def weapon_desc(w):
    """武器描述：typeDesc + 外观 + 重量 + 硬度 + 坚韧 + 特效1..3，`，` 连、`。` 收尾。"""
    if not isinstance(w, dict):
        return ''
    type_desc = _s(w.get('typeDesc'))
    if _num(w.get('wanhaodu'), 100) == 0:
        return (type_desc + '，如今它已经损坏。') if type_desc else '如今它已经损坏。'
    wtype = _s(w.get('type'))
    parts = []
    if type_desc:
        parts.append(type_desc)
    look = _facade(w.get('weaponLookId'), wtype)
    if look and look != '暂无描述':
        parts.append(look)
    for key, field in (('weight', 'weight'), ('yindu', 'yindu'), ('rendu', 'rendu')):
        d = _desc_of(key, w.get(field), wtype)
        if d:
            parts.append(d)
    for i in (1, 2, 3):
        d = _effect_text(w.get('effct%d' % i))
        if d:
            parts.append(d)
    if not parts:
        return ''
    return '，'.join(parts) + '。'


def _pick_takeoff(wtype):
    """从 `weaponTakeOffDesc` 里随机一条该兵器的拔剑/回鞘描述
    （`ShenBingDuanZao:getequipDescAndGetOffDesc`，`ShenBingDuanZao.lua:325-340`）。"""
    rows = [v for v in take_off().values()
            if isinstance(v, dict) and _s(v.get('equipmenttype')) == _s(wtype)]
    if not rows:
        return {}
    return random.choice(rows)


def _random_look_id():
    ids = [k for k in _lua(_T_APPEAR).keys()]
    return random.choice(ids) if ids else ''


def _base_weapon(wtype, name='', color=None):
    """用她 `itemOfFurnaceInfo` 里镔铁 + 长剑/长刀/长棍/长鞭 的基础值拼一把神兵
    （与 `ShenBingDuanZao.lua:858-905` 的 transBaseList 完全同源）。"""
    btype = BASE_BTYPE.get(_num(wtype), '')
    base = _furnace_by(BASE_ITEM, btype) if btype else {}
    wt = WTYPE.get(_num(wtype), '剑')
    desc_row = _pick_takeoff(wt)
    return {
        'id': '',
        'name': _s(name) or btype,
        'type': wt,
        'bType': btype or _s(base.get('forgingweapon')),
        'wpType': '神兵',
        'damage': _num(base.get('Forgingdamage')),
        'yindu': _num(base.get('Forginghardness')),
        'rendu': _num(base.get('Forgingtoughness')),
        'weight': _num(base.get('Forgingweight')),
        'effctNum': _num(base.get('Forgingcharacteristics')),
        'wanhaodu': 100,
        'typeDesc': _s(base.get('Forgingdsc')),
        'nameColor': _s(base.get('Forgingcolor')) or 'CYN',
        'colorid': _num(color, 1),
        'weaponLookId': _random_look_id(),
        'equipDescId': _s(desc_row.get('desid')),
        'status': 2,
        'canEquip': 1,
        'cuilianCount': 0,
        'cuilianFailedCount': 0,
        'useNeiLi': 0,
    }


# ===========================================================================
# 货币 / 物品（一律走 items_currency 导出的接口，不另存一份钱）
# ===========================================================================
def _IC():
    try:
        from fz_api import items_currency as IC
    except ImportError:                         # noqa: BLE001
        import items_currency as IC             # type: ignore
    return IC


def _currency_list(ctx):
    """`currency_list` 的四个数 —— 她 `SkillBreakThroughPresent:initData` 会直接
    `martialData.amartial`，缺一个键就 `attempt to index a nil value`（回调里被 xpcall 吞掉）。"""
    IC = _IC()
    return {k: _num(IC.get_currency(ctx, k)) for k in CURRENCY_LIST_KEYS}


def _pay(ctx, currency_cost, item_cost):
    """先全查、再全扣（绝不扣一半）。返回 `(ok, 缺什么的中文说明)`。"""
    IC = _IC()
    for ctype, need in currency_cost:
        need = _num(need)
        if need <= 0:
            continue
        have = _num(IC.get_currency(ctx, ctype))
        if have < need:
            return False, '%s不足（需要%d，现有%d）' % (IC.currency_name(ctype), need, have)
    for iid, need in item_cost:
        need = _num(need)
        if need <= 0:
            continue
        have = _num(IC.get_count(ctx, iid))
        if have < need:
            nm = break_item_name(iid) or IC.item_info(iid).get('name') or iid
            return False, '%s不足（需要%d，现有%d）' % (nm, need, have)
    for ctype, need in currency_cost:
        if _num(need) > 0:
            IC.add_currency(ctx, ctype, -_num(need))
    for iid, need in item_cost:
        if _num(need) > 0:
            IC.spend(ctx, iid, _num(need))
    return True, ''


# ===========================================================================
# 接口
# ===========================================================================
def _ep_contains_blocked_word(ctx, st):
    """POST `{s}`。她自己的 58000 条屏蔽词（`officalMaskWords*` + `gameMaskWords`）。
    `errcode=0` 放行；`errcode=1` = 命中屏蔽词（她再用本地 `Helper:isMaskOff`
    找出那个词来提示，所以这里只给状态）。"""
    s = ctx.param('s')
    if s is None:
        s = ctx.body_obj.get('s') if isinstance(ctx.body_obj, dict) else None
    s = _s(s)
    if not s:
        return ctx.fail('名字不能为空', '★ 名字校验：没带 s 参数')
    hit = blocked_in(s)
    if hit:
        return ctx.fail('%s 是非法词汇，请更换后再试。' % hit,
                        '★ 名字校验：命中屏蔽词「%s」' % hit, errcode=1)
    return ctx.ok({}, '★ 名字校验通过（对照她 %d 条屏蔽词）' % len(block_words()))


def _ep_get_random_weapon_desc(ctx, st):
    """GET `/get_random_weapon_desc/<wType>`。返回她 `weaponTakeOffDesc` 里同兵器的
    一条随机拔剑/回鞘描述。`weapon_out`=`Weardes`(拔)，`weapon_in`=`Takedes`(回鞘)，
    `$N`/`$w` 占位符照原样给（她自己在回调里 gsub）。"""
    arg = ctx.args[0] if ctx.args else ''
    raw = _s(arg)
    if raw in WTYPE_R:                                  # 直接给了中文兵器名
        wtype = raw
    else:
        wtype = WTYPE.get(_num(raw, 1), '剑')
    row = _pick_takeoff(wtype)
    if not row:
        return ctx.fail('没有找到%s的拔剑/回鞘描述' % wtype,
                        '★ 随机拔剑描述：weaponTakeOffDesc 里没有 equipmenttype=%s' % wtype)
    out = _s(row.get('Weardes'))
    inn = _s(row.get('Takedes'))
    if not out or not inn:
        return ctx.fail('配置缺少拔剑/回鞘描述', '★ 随机拔剑描述：desid=%s 字段不全' % row.get('desid'))
    return ctx.ok({'weapon_out': out, 'weapon_in': inn,
                   'desid': _s(row.get('desid')), 'weapon_type': WTYPE_R.get(wtype, 1)},
                  '★ 随机%s拔剑/回鞘描述（%s）' % (wtype, row.get('desid')))


def _ep_get_weapon_cuilian_num(ctx, st):
    """POST `{wid,itemId}`。**返回裸映射** `{淬炼材料id: 成功次数}`，不带 `dataVer`
    （她 `for k,v in pairs(data)` 会把每个值加起来算熔兵返料）。"""
    wid = _s(ctx.param('wid'))
    item_id = _s(ctx.param('itemId'))
    if not wid:
        return ctx.fail('缺少武器标识', '★ 淬炼次数：没带 wid')
    out = {}
    rec = st['cuilian'].get(wid)
    if isinstance(rec, dict):
        for k, v in rec.items():
            n = _num(v.get('suc')) if isinstance(v, dict) else _num(v)
            if n > 0:
                out[str(k)] = n
    saved = _find_in_save(ctx, weapon_id=wid)
    if isinstance(saved, dict) and isinstance(saved.get('cuilianitems'), dict):
        for k, v in saved['cuilianitems'].items():      # 老存档里真有的那份，取大的
            n = _num(v)
            if n > out.get(str(k), 0):
                out[str(k)] = n
    if item_id:
        out = {item_id: out.get(item_id, 0)}
    return _ok_raw(ctx, out, '★ %s 的淬炼次数（%d 种材料，回裸映射不带 dataVer）'
                   % (wid, len(out)))


def _ep_incr_weapon_cuilian_num(ctx, st):
    """POST `{wid,results,sum}`。`results = {材料id:{sucNum,defNum}}`。
    真记账（材料 id 对着她 `cuiLianOfWepon` 的 `Cuilianid` 白名单校验），只看 errcode。"""
    wid = _s(ctx.param('wid'))
    results = ctx.param('results')
    if not isinstance(results, (dict, list)):
        results = ctx.body_obj.get('results') if isinstance(ctx.body_obj, dict) else None
    if not wid:
        return ctx.fail('缺少武器标识', '★ 淬炼上传：没带 wid')
    if not isinstance(results, dict) or not results:
        return ctx.fail('缺少淬炼结果', '★ 淬炼上传：没带 results（%s）' % type(results).__name__)
    allow = cuilian_materials()
    bad = [k for k in results if allow and _s(k) not in allow]
    if bad and len(bad) == len(results):
        return ctx.fail('非法的淬炼材料', '★ 淬炼上传：%s 不在 cuiLianOfWepon.Cuilianid 里'
                        % ','.join(_s(x) for x in bad[:3]))
    rec = st['cuilian'].setdefault(wid, {})
    if not isinstance(rec, dict):
        rec = st['cuilian'][wid] = {}
    add_suc = add_def = 0
    for k, v in results.items():
        if not isinstance(v, dict):
            continue
        suc = max(0, _num(v.get('sucNum')))
        dfn = max(0, _num(v.get('defNum')))
        node = rec.setdefault(_s(k), {'suc': 0, 'def': 0})
        if not isinstance(node, dict):
            node = rec[_s(k)] = {'suc': 0, 'def': 0}
        node['suc'] = _num(node.get('suc')) + suc
        node['def'] = _num(node.get('def')) + dfn
        add_suc += suc
        add_def += dfn
    total = _num(ctx.param('sum'))
    st['cuilianSum'][wid] = max(_num(st['cuilianSum'].get(wid)), total)
    _mark(st, 'incr_cuilian %s +%d成功/+%d失败（她报的成功总数=%d）'
          % (wid, add_suc, add_def, total))
    _save(ctx, st)
    return ctx.ok({'wid': wid, 'sucNum': add_suc, 'defNum': add_def,
                   'cuilianCount': sum(_num(x.get('suc')) for x in rec.values()
                                       if isinstance(x, dict))},
                  '★ 淬炼记账 %s：成功 %d / 失败 %d' % (wid, add_suc, add_def))


def _ep_make_weapon(ctx, st):
    """POST `{weapon_type,weapon_name,weapon_color}`。她 `DaZao.lua:604` 已把调用注释掉，
    但契约在：`self:setDesc(data.desc,data.out,data.weapon_in)`。
    属性全取 `itemOfFurnaceInfo`（镔铁 + 长剑/长刀/长棍/长鞭），落进服务端镜像。"""
    wtype = _num(ctx.param('weapon_type'))
    name = _s(ctx.param('weapon_name'))
    color = _num(ctx.param('weapon_color'), 1)
    if not wtype:
        return ctx.fail('缺少武器类型', '★ 打造神兵：没带 weapon_type')
    if wtype not in BASE_BTYPE:
        return ctx.fail('只有剑/刀/棍/鞭可以锻造', '★ 打造神兵：weapon_type=%s 不在 1..4' % wtype)
    if not name:
        return ctx.fail('名字不能为空', '★ 打造神兵：没带 weapon_name')
    hit = blocked_in(name)
    if hit:
        return ctx.fail('%s 是非法词汇，请更换后再试。' % hit,
                        '★ 打造神兵：名字命中屏蔽词「%s」' % hit)
    w = _base_weapon(wtype, name=name, color=color)
    st['forgeCount'] = _num(st.get('forgeCount')) + 1
    w['id'] = 'weapon_%d' % (st['forgeCount'] + 100000)     # 与 `forgeCount` 同源、保证唯一
    w['desc'] = weapon_desc(w)
    row = _pick_takeoff(w['type'])
    w['equipDescId'] = _s(row.get('desid')) or w.get('equipDescId')
    st['shenbings'][w['id']] = w
    _mark(st, 'make_weapon %s(%s) id=%s' % (name, w['type'], w['id']))
    _save(ctx, st)
    return ctx.ok({'desc': w['desc'], 'out': _s(row.get('Weardes')),
                   'weapon_in': _s(row.get('Takedes')),
                   'id': w['id'], 'name': name, 'weapon_type': wtype},
                  '★ 打造神兵：%s（%s，%s）' % (name, w['type'], w.get('typeDesc')))


def _ep_upgrade_weapon(ctx, st):
    """POST `params2`（内力/黄金两条分支都会调）。她只读 `data.desc`（**必须是字符串**）。
    升级不改重量/硬度/坚韧度 ⇒ 拿真属性重算一遍描述还给她。"""
    wtype = _num(ctx.param('weapon_type'))
    name = _s(ctx.param('weapon_name'))
    if not wtype:
        return ctx.fail('缺少武器类型', '★ 升级神兵：没带 weapon_type')
    if not name:
        return ctx.fail('缺少武器名字', '★ 升级神兵：没带 weapon_name')
    wt = WTYPE.get(wtype, '剑')
    # ① 服务端镜像（make_weapon 落过）→ ② 她的存档（客户端权威）→ ③ 她表里的基础值
    w = None
    for rec in st['shenbings'].values():
        if isinstance(rec, dict) and _same_name(rec.get('name'), name) \
                and _s(rec.get('type')) == wt:
            w = dict(rec)
            break
    if w is None:
        saved = _find_in_save(ctx, name=name, wtype=wt)
        if isinstance(saved, dict):
            w = dict(saved)
    if w is None:
        w = _base_weapon(wtype, name=name, color=_num(ctx.param('weapon_color'), 1))
    w['type'] = w.get('type') or wt
    w['gold_level'] = _num(ctx.param('weapon_gold_level'))
    w['neili_level'] = _num(ctx.param('weapon_neili_level'))
    w['neilicast'] = _fnum(ctx.param('weapon_neilicast'))
    w['goldcast'] = _fnum(ctx.param('weapon_goldcast'))
    desc = weapon_desc(w)
    if not desc:
        desc = _s(w.get('typeDesc')) or ('这是一把%s' % wt)
    key = _s(w.get('id')) or ('name:%s|%s' % (wt, _plain_name(name)))
    w['id'] = key
    w['name'] = _s(w.get('name')) or name
    st['shenbings'][key] = w
    _mark(st, 'upgrade_weapon %s(%s) 内力累计=%s 黄金累计=%s'
          % (name, wt, w['neilicast'], w['goldcast']))
    _save(ctx, st)
    return ctx.ok({'desc': desc, 'id': key, 'name': name,
                   'weapon_gold_level': w['gold_level'], 'weapon_neili_level': w['neili_level']},
                  '★ 升级神兵：%s（%s）新描述 %d 字' % (name, wt, len(desc)))


def _ep_remove_yuanbao(ctx, st):
    """GET `/remove_yuanbao/<num>/<trans_id>`。真扣她那一份钱（`items_currency`），
    `data` 必须**非空**（她 `MapIsEmpty(data)` ⇒ "网络异常"）。"""
    num = _num(ctx.args[0]) if ctx.args else 0
    trans_id = _s(ctx.args[1]) if len(ctx.args) > 1 else ''
    if num <= 0:
        return ctx.fail('消耗数量不正确', '★ 消耗元宝：num=%s' % (ctx.args[0] if ctx.args else ''))
    if not trans_id:
        return ctx.fail('缺少交易流水号', '★ 消耗元宝：没带 trans_id')
    IC = _IC()
    left = IC.add_currency(ctx, 'yuanbao', -num)
    if left is None:
        have = _num(IC.get_currency(ctx, 'yuanbao'))
        return ctx.fail('元宝不足', '★ 消耗元宝：要 %d，只有 %d' % (num, have))
    _mark(st, 'remove_yuanbao -%d（流水 %s）→ %d' % (num, trans_id, left))
    _save(ctx, st)
    return ctx.ok({'yuanbao': left, 'num': num, 'trans_id': trans_id,
                   'cost': num, 'type': 'yuanbao'},
                  '★ 消耗元宝 %d（流水 %s），余 %d' % (num, trans_id, left))


def _ep_update_data_state(ctx, st):
    """POST `{id,state}`（`XuanBingDongOld`/`CangYiGeOld` 收藏入库用）。只看 errcode。"""
    did = ctx.param('id')
    if did is None:
        did = ctx.body_obj.get('id') if isinstance(ctx.body_obj, dict) else None
    did = _s(did)
    if not did:
        return ctx.fail('缺少数据标识', '★ 收藏状态：没带 id')
    state = _s(ctx.param('state')) or '0'
    st['datastate'][did] = state
    _mark(st, 'update_data_state %s → %s' % (did, state))
    _save(ctx, st)
    return ctx.ok({'id': did, 'state': state}, '★ 数据状态：%s → %s' % (did, state))


def _ep_get_user_shenbings(ctx, st):
    """GET。把她存档里的神兵当作"历史存档神兵数据"回给她；缺 `typeDesc` 的
    用 `itemOfFurnaceInfo` 的 `Forgingdsc` 按 `bType` 补（`ShenBingRepair.lua:535-543`）。"""
    items = _save_shenbings(ctx)
    out = []
    for w in items:
        node = dict(w)
        if not _s(node.get('typeDesc')):
            btype = _s(node.get('bType'))
            td = ''
            for v in furnace_info().values():
                if isinstance(v, dict) and _s(v.get('forgingweapon')) == btype:
                    td = _s(v.get('Forgingdsc'))
                    break
            if td:
                node['typeDesc'] = td
        node['id'] = _s(node.get('id'))
        out.append(node)
    # 服务端镜像里、存档里没有的那些也一起回（保证她修描述时能看到全量）
    have = {_s(w.get('id')) for w in out}
    for k, rec in st['shenbings'].items():
        if isinstance(rec, dict) and _s(rec.get('id')) not in have and _s(k) not in have:
            out.append(dict(rec))
    return ctx.ok({'shenBingItems': out},
                  '★ 历史存档神兵 %d 把（存档 %d + 服务端镜像 %d）'
                  % (len(out), len(items), len(st['shenbings'])))


def _ep_martial_upgrade(ctx, st):
    """POST `{id,martial_id,currencyVersion}`。内容取 `skillBreakThrough.lua["武学突破"]`。
    她读：`reitem_list`(数组) / `currencyVersion`(数) / **`currency_list`(四货币对象)**。"""
    bid = _s(ctx.param('id'))
    if not bid:
        return ctx.fail('缺少突破配置', '★ 武学突破：没带 id')
    row = skill_break().get(bid)
    if not isinstance(row, dict):
        return ctx.fail('突破配置不存在', '★ 武学突破：skillBreakThrough["武学突破"]["%s"] 没有' % bid)
    cost_cur = _pairs(row.get('resource'))
    cost_item = _pairs(row.get('reitem'))
    ok, why = _pay(ctx, cost_cur, cost_item)
    if not ok:
        return ctx.fail(why, '★ 武学突破 id=%s（%d档→%d级）：%s'
                        % (bid, _num(row.get('class')), _num(row.get('Blevel')), why))
    st['currencyVersion'] = _num(st.get('currencyVersion'), 1) + 1
    reitem = [{'id': _s(i), 'num': _num(n)} for i, n in cost_item]
    cur_list = _currency_list(ctx)
    _mark(st, 'martial_upgrade %s（武学 %s）花 %s / %s'
          % (bid, _s(ctx.param('martial_id')), cost_cur, cost_item))
    _save(ctx, st)
    data = {'reitem_list': reitem, 'currencyVersion': st['currencyVersion'],
            'currency_list': cur_list}
    data.update(cur_list)
    return ctx.ok(data, '★ 武学突破 %s：→ %s 级（reitem_list %d 条，currency_list 已带全）'
                  % (bid, _num(row.get('Blevel')), len(reitem)))


def _ep_zhao_upgrade(ctx, st):
    """POST `{id,zhao_id,currencyVersion}`。内容取 `zhaoBreakThrough.lua["技能突破"]`。"""
    bid = _s(ctx.param('id'))
    zid = _s(ctx.param('zhao_id'))
    if not bid:
        return ctx.fail('缺少突破配置', '★ 招式突破：没带 id')
    row = zhao_break().get(bid)
    if not isinstance(row, dict):
        return ctx.fail('突破配置不存在', '★ 招式突破：zhaoBreakThrough["技能突破"]["%s"] 没有' % bid)
    ztype = zhao_skill_type(zid) if zid else None
    if ztype is not None and _num(row.get('activeSkillType')) != ztype:
        return ctx.fail('突破配置与招式不匹配',
                        '★ 招式突破：id=%s 属于 activeSkillType=%s，而 %s 是 %s'
                        % (bid, row.get('activeSkillType'), zid, ztype))
    cost_item = _pairs(row.get('reitem'))
    ok, why = _pay(ctx, [], cost_item)
    if not ok:
        return ctx.fail(why, '★ 招式突破 id=%s（%d重）：%s'
                        % (bid, _num(row.get('Blevel')), why))
    st['currencyVersion'] = _num(st.get('currencyVersion'), 1) + 1
    reitem = [{'id': _s(i), 'num': _num(n)} for i, n in cost_item]
    cur_list = _currency_list(ctx)
    _mark(st, 'zhao_upgrade %s（招式 %s）花 %s' % (bid, zid, cost_item))
    _save(ctx, st)
    data = {'reitem_list': reitem, 'currencyVersion': st['currencyVersion'],
            'currency_list': cur_list, 'zhao_id': zid}
    data.update(cur_list)
    return ctx.ok(data, '★ 招式突破 %s：→ %d 重（%s）'
                  % (bid, _num(row.get('Blevel')), why or '无消耗'))


_HANDLERS = {
    'contains_blocked_word': _ep_contains_blocked_word,
    'get_random_weapon_desc': _ep_get_random_weapon_desc,
    'get_user_shenbings': _ep_get_user_shenbings,
    'get_weapon_cuilian_num': _ep_get_weapon_cuilian_num,
    'incr_weapon_cuilian_num': _ep_incr_weapon_cuilian_num,
    'make_weapon': _ep_make_weapon,
    'martial_upgrade': _ep_martial_upgrade,
    'remove_yuanbao': _ep_remove_yuanbao,
    'update_data_state': _ep_update_data_state,
    'upgrade_weapon': _ep_upgrade_weapon,
    'zhao_upgrade': _ep_zhao_upgrade,
}


def handle(ctx):
    fn = _HANDLERS.get(ctx.endpoint)
    if fn is None:
        return None                             # 不是我的接口
    st = _load(ctx)
    return fn(ctx, st)
