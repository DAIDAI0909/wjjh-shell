# -*- coding: utf-8 -*-
"""私服存档快照 —— 让"回到昨天"在我们自己的服上成为一定能做到的事。

为什么要它：2026-09-29 老板问"存档能恢复到昨天吗"。
  查下来发现两件事：
    1) 官方那个 app 的存档在官方服务器上，我们手上没有它的历史副本 ⇒ 回不去；
    2) **我们自己**的服务端也只在启停时留下一份覆盖式的 roles/full.json，
       没有按日期的历史 ⇒ 万一出事，同样回不去。
  所以补上第 2 条：每次（至少每天一次）把 roles/ 和 saves/ 复制成带时间戳的快照。

用法：
    python fz_snapshot.py                 # 手动存一份（同一天已存过就不重复）
    python fz_snapshot.py --force         # 强制再存一份
    python fz_snapshot.py --list          # 列出已有快照
    python fz_snapshot.py --restore <名>  # 把某个快照的 roles/saves 还原回去

  服务端 `fz_boot_server.py` 启动时会自动调用一次（`--no-snapshot` 可关）。
"""
import argparse
import datetime
import os
import shutil
import sys

# ★ 千万别在这里 `sys.stdout = io.TextIOWrapper(...)`：
#   本模块会被 fz_boot_server.py import，而那边已经包过一次 stdout，
#   再包一次会让旧句柄失效 —— 实测直接把服务端搞崩（ValueError: I/O operation on closed file）。
#   要改编码只在自己的 __main__ 里 reconfigure。

HERE = os.path.dirname(os.path.abspath(__file__))
BACKUP_ROOT = os.path.join(HERE, 'backups')
WATCH = ('roles', 'saves')          # 相对 HERE
KEEP = 60                            # 最多保留多少份


def _stamp(force_date_only=True):
    now = datetime.datetime.now()
    return now.strftime('%Y%m%d')


def existing():
    if not os.path.isdir(BACKUP_ROOT):
        return []
    return sorted(d for d in os.listdir(BACKUP_ROOT)
                  if os.path.isdir(os.path.join(BACKUP_ROOT, d)))


def snapshot(force=False, tag=None):
    day = _stamp()
    name = tag or day
    dest = os.path.join(BACKUP_ROOT, name)
    if os.path.isdir(dest) and not force:
        print('今天已经存过：%s（要再存一份用 --force）' % name)
        return dest
    if os.path.isdir(dest) and force:
        # 同一天多次：加时分后缀，不覆盖
        name = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        dest = os.path.join(BACKUP_ROOT, name)
    os.makedirs(dest, exist_ok=True)
    saved = []
    for sub in WATCH:
        src = os.path.join(HERE, sub)
        if not os.path.isdir(src):
            continue
        dst = os.path.join(dest, sub)
        shutil.copytree(src, dst)
        for root, _dirs, files in os.walk(dst):
            if '__pycache__' in root:
                shutil.rmtree(root, ignore_errors=True)
                continue
            for f in files:
                saved.append(os.path.relpath(os.path.join(root, f), dest))
    print('快照 %s：%d 个文件（%s）' % (name, len(saved), ', '.join(WATCH)))
    # 清理过老的
    snaps = existing()
    while len(snaps) > KEEP:
        old = snaps.pop(0)
        shutil.rmtree(os.path.join(BACKUP_ROOT, old), ignore_errors=True)
        print('  清理旧快照 %s' % old)
    return dest


def restore(name):
    src = os.path.join(BACKUP_ROOT, name)
    if not os.path.isdir(src):
        print('没有这个快照：%s' % name)
        return 2
    for sub in WATCH:
        s = os.path.join(src, sub)
        if not os.path.isdir(s):
            continue
        d = os.path.join(HERE, sub)
        # 还原前先把现状另存一份，避免"还原错了就没了"
        cur = os.path.join(BACKUP_ROOT, 'before_restore_' + datetime.datetime.now().strftime('%Y%m%d_%H%M%S'), sub)
        if os.path.isdir(d):
            os.makedirs(os.path.dirname(cur), exist_ok=True)
            shutil.copytree(d, cur)
        if os.path.isdir(d):
            shutil.rmtree(d)
        shutil.copytree(s, d)
        print('已还原 %s <- %s（原状备份在 %s）' % (sub, name, os.path.relpath(cur, BACKUP_ROOT)))
    print('★ 记得重启 fz_boot_server.py 让还原生效')
    return 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--force', action='store_true')
    ap.add_argument('--list', action='store_true')
    ap.add_argument('--restore')
    ap.add_argument('--tag')
    a = ap.parse_args()
    if a.list:
        for s in existing():
            p = os.path.join(BACKUP_ROOT, s)
            n = sum(len(f) for _r, _d, f in os.walk(p))
            print('%-24s %d 个文件' % (s, n))
        return 0
    if a.restore:
        return restore(a.restore)
    snapshot(force=a.force, tag=a.tag)
    return 0


if __name__ == '__main__':
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    except Exception:                            # noqa: BLE001
        pass
    sys.exit(main())
