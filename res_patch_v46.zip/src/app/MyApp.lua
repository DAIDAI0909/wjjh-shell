
local MyApp = class("MyApp", cc.load("mvc").AppBase)

function MyApp:onCreate()
    math.randomseed(os.time())
end

function MyApp:onEnterBackground()
	if FILE_IS_LOADING == true then
		Record:updateUpload()

		User:save()
		-- 友盟统计 登出
		Mob.profileSignOff()
	end
end

function MyApp:onEnterForeground()
	if FILE_IS_LOADING == true then
		-- add by XiaoZhiWei 2017/12/05 10:19:08 华为手机白屏的问题
		MainControllLayer:uniqueDelayFunc("foreground", 0.5, function()
			HttpManagerEx:getTime(function(status, errcode, errmsg, data, isEncrypted)
				if status == 200 and errcode == 0 and data.time ~= nil then
					BACKGROUND_TIME = BACKGROUND_TIME + tonumber(data.time) - WEB_TIME
					WEB_TIME = tonumber(data.time)
					if device.platform == "android" then
						YXHelper:setWebTime(WEB_TIME)
					else
					end
					NETWORK_STATE = 1
		    		return true
				end
			end, IS_SHOW_WAITING, HTTP_MANAGER_RETRY_TYPE_RETRY)
		end)

		-- 友盟统计 登入
		if User:getUserId() > 0 then
			Mob.profileSignIn(User:getUserId())
		end
	end

	-- [M4-06 onEnterForeground 恢复投递] app 回前台(从 MUD 归来就是这条路)时,
	-- 领取 Java 静态槽里的 MUD 战斗并启动主世界骨骼战斗。onEnable 不是恢复事件(实测),
	-- 主界面创建拾取只管冷启动;这是热恢复的唯一通路。
	pcall(function()
		if type(mud_fight_start) ~= "function" then
			return
		end
		if m4KeepFontAlive then
			m4KeepFontAlive()
		end
		local luaj = require("cocos.cocos2d.luaj")
		local ok2, ret = luaj.callStaticMethod("com/zwyouto/main/Util", "getMudFightJson", {}, "()Ljava/lang/String;")
		if ok2 and type(ret) == "string" and ret ~= "" then
			print("[M4] 前台恢复领取 MUD 战斗")
			mud_fight_start(ret)
		end
	end)
end

-- [2026-10-07 定调·M4] MUD 战斗桥:Java onResume 经 callLuaGlobalFunctionWithString 调入
-- 数据:mudmaind 096 帧推来 {foe_team=挑战图队伍id};玩家=主世界真身(User:getRole())
-- [M4-06] MUD 战斗桥:096 帧推来 JSON -> 主世界真骨骼战斗(呆呆真身 vs 挑战图 NPC 队)
-- 演出与 MUD 服务器侧战斗并行;结束点「继续」走 openMud 回 MUD(胜/败/平/逃同一处理)
-- [M4-06 v93] 字体锚:战斗页用 Font/default.ttf;退场后层切换会 removeUnusedTextures,
-- 把它的纹理释放掉而 FontAtlasCache 留死图集→下一场建文本 native SIGSEGV(实锤)。
-- 常驻一个隐形标签使该字体纹理 refcount>=2,清缓存不碰它。
m4_font_anchor_label = m4_font_anchor_label or nil

-- [M4-06 v94] 拦截 Game:freeMemorySmart 跳过 removeUnusedTextures:
-- 它会释放战斗页字体纹理而 FontAtlasCache 留死图集,下一场战斗建文本 native SIGSEGV
-- (tombstone_05 实锤 FontAtlas::prepareLetterDefinitions)。保留精灵帧清理,纹理清理跳过。
local function m4PatchFreeMemory()
    if m4_freemem_patched then
        return
    end
    pcall(function()
        if type(Game) ~= "table" or type(Game.freeMemorySmart) ~= "function" then
            return
        end
        Game.freeMemorySmart = function(self)
            pcall(function()
                cc.SpriteFrameCache:getInstance():removeUnusedSpriteFrames()
            end)
            -- 原本这里还有 getTextureCache():removeUnusedTextures()——故意跳过
        end
        m4_freemem_patched = true
        print("[M4] freeMemorySmart 已去纹理清理化")
    end)
end

-- [M4-06 v95] 再冻结自动释放纹理:游戏自定义的 cleanUnuseAutoReleaseTextures 会周期性
-- (ControllLayer ft/6)把闲着的纹理收走——两场战斗之间字体纹理正好闲着=被收=下场上崩。
local function m4PatchAutoRelease()
    if m4_autorel_patched then
        return
    end
    pcall(function()
        if type(Game) ~= "table" or type(Game.cleanUnuseAutoReleaseTextures) ~= "function" then
            return
        end
        Game.cleanUnuseAutoReleaseTextures = function(self, ft)
            -- 故意 no-op
        end
        m4_autorel_patched = true
        print("[M4] 自动释放纹理已冻结")
    end)
end

m4_font_anchors = m4_font_anchors or nil
local function m4KeepFontAlive()
    m4PatchFreeMemory()
    m4PatchAutoRelease()
    if m4_font_anchors ~= nil then
        return
    end
    -- [M4-06 v96] 电池阵:两种字体 × 12..72 步进4 的图集全部按住(隐形空标签)。
    local anchors = {}
    local okall = true
    pcall(function()
        local scene = cc.Director:getInstance():getRunningScene()
        if not scene then
            okall = false
            return
        end
        for _, font in ipairs({ "Font/default.ttf", "Font/HYCFS.ttf" }) do
            for size = 12, 72, 4 do
                local okl, lbl = pcall(function()
                    return cc.Label:createWithTTF(" ", font, size)
                end)
                if okl and lbl then
                    lbl:setVisible(false)
                    scene:addChild(lbl)
                    table.insert(anchors, lbl)
                end
            end
        end
    end)
    if okall and #anchors > 0 then
        m4_font_anchors = anchors
        print("[M4] 字体锚阵已常驻: " .. #anchors .. " 个")
    end
end

function mud_fight_start(json_str)
    -- [M4-06] 真机两轮实测:onResume 投递常落在引擎重启窗口——User:getRole() 抛错被
    -- 静默带崩整个函数(连重试都开不出来)。这里全 pcall 化+失败重试,永不静默死。
    print("[M4] called n=" .. tostring(mud_fight_retry_n))
    if mud_fight_busy then
        print("[M4] 上一场演出未结束,跳过")
        return
    end
    local okr, role = pcall(function()
        return User and User.getRole and User:getRole()
    end)
    local okd, scene = pcall(function()
        return cc.Director:getInstance():getRunningScene()
    end)
    if not okr then role = nil end
    if not okd then scene = nil end

    local function scheduleRetry(reason)
        local n = (tonumber(mud_fight_retry_n) or 0) + 1
        if n > 60 then
            mud_fight_retry_n = nil
            print("[M4] 放弃: " .. tostring(reason))
            return
        end
        mud_fight_retry_n = n
        print("[M4] 重试#" .. n .. " (" .. tostring(reason) .. ")")
        pcall(function()
            scheduler.performWithDelayGlobal(function()
                mud_fight_start(json_str)
            end, 2.0)
        end)
    end

    local function fetchJavaJson()
        return pcall(function()
            local luaj = require("cocos.cocos2d.luaj")
            local okc, ret = luaj.callStaticMethod("com/zwyouto/main/Util", "getMudFightJson", {}, "()Ljava/lang/String;")
            if okc and type(ret) == "string" and #ret > 1 then
                return ret
            end
            return nil
        end)
    end
    local function validJson(s)
        if type(s) ~= "string" or #s < 2 then
            return false
        end
        local okj, data = pcall(json.decode, s)
        return okj and type(data) == "table" and data.me ~= nil
    end

    -- [M4-06] json 自愈:闭包跨 VM 重启会损坏(实测 "json 无效"),Java 槽里永远是最新一场;
    -- 失效就重取,重取后仍无效走重试(槽可能稍后更新)。
    if not validJson(json_str) then
        local okf, j = fetchJavaJson()
        if okf and validJson(j) then
            json_str = j
            print("[M4] 已从 Java 槽刷新 json")
        end
    end
    if not validJson(json_str) then
        scheduleRetry("json 无效(槽里也没有)")
        return
    end

    if not role or not scene then
        scheduleRetry("未就绪 role=" .. tostring(role ~= nil) .. " scene=" .. tostring(scene ~= nil))
        return
    end

    if m4KeepFontAlive then
        m4KeepFontAlive()
    end
    -- [M4-06 v97] 同 VM 第二场战斗必崩(引擎内部空指针,3/3 复现)→ 结束当前主游戏 Activity 冷启全新 VM;
    -- 新版 VM 主界面拾取静态槽后 m4_vm_battles 归零,本场以"首场"跑=稳。
    m4_vm_battles = tonumber(m4_vm_battles) or 0
    if m4_vm_battles >= 1 then
        print("[M4] 本 VM 已打过一场,重启战斗宿主(全新 VM)")
        m4_vm_battles = -1
        local luaj = require("cocos.cocos2d.luaj")
        -- [M4-06 v100] 杀进程+Alarm 拉起全新进程(重启 Activity 不够,native 状态跨活动存活)
        luaj.callStaticMethod("com/zwyouto/main/Util", "restartBattleProcess", {}, "()V")
        mud_fight_busy = nil
        return
    end
    if m4_vm_battles == -1 then
        -- [M4-06 v99] 新 VM 首个前台轮询(比主界面拾取早):消费哨兵归零、不重启;
        -- 槽里的战斗等冷启动完成后由主界面拾取启动(那时 C++/GL 上下文全新=battle#1 等效)。
        m4_vm_battles = 0
        print("[M4] 新VM首前台:计数归零,等拾取开打")
        return
    end
    local okstart, err = pcall(function()
        -- [M4-06] 引导期 require 失败会留下 sentinel 毒标记(报 "loop or previous error",
        -- 且按类型扫描扫不到,实测两轮)——改用名册:每次重试前按名字清掉整条战斗链,
        -- 清完 require 就是全新加载;引导完成后必然成功。
        -- [M4-06] 毒标记子树清理:实测按类型扫(false/userdata)扫不到 sentinel,但按名清有效。
        -- 索性无条件清掉整个战斗系统子树(app.FightSystem.* + 挑战图资源),重试即全新加载。
        local _cleared = 0
        for _k, _v in pairs(package.loaded) do
            if type(_k) == "string" and (_k:find("^app%.FightSystem%.") or _k:find("^app%.models%.ChallengeMap%.")) then
                package.loaded[_k] = nil
                _cleared = _cleared + 1
            end
        end
        print("[M4] 子树清理: " .. _cleared .. " 个")
        -- 探针(sentinel 真身+两张表是否同一张)
        local _nv = package.loaded["app.FightSystem.FightRole.NpcFightCharacter"]
        print("[M4] probe pkg.loaded[NpcFightCharacter]=" .. type(_nv) .. "/" .. tostring(_nv))
        local _reg = debug.getregistry()
        local _L = _reg and _reg["_LOADED"]
        print("[M4] probe reg._LOADED==package.loaded: " .. tostring(_L == package.loaded))
        if _L ~= nil then
            local _nv2 = _L["app.FightSystem.FightRole.NpcFightCharacter"]
            print("[M4] probe registry[NpcFightCharacter]=" .. type(_nv2) .. "/" .. tostring(_nv2))
        end

        local M4_MODS = {
            "app.FightSystem.Factory.CharacterFactory.ChallengeMapFightNpcBuilder",
            "app.FightSystem.Factory.CharacterFactory.ChallengeMapFightPlayerBuilder",
            "app.FightSystem.Factory.CharacterFactory.NpcCharacterBuilder",
            "app.FightSystem.Factory.CharacterFactory.CharacterByRoleFactory",
            "app.FightSystem.FightRunner",
            "app.FightSystem.Fight.FightFinishCallback",
            "app.FightSystem.Fight.BattleSystem",
            "app.models.ChallengeMap.ChallengeMapResource",
        }
        for _, _mn in ipairs(M4_MODS) do
            if package.loaded[_mn] ~= nil then
                package.loaded[_mn] = nil
            end
        end
        local okj, data = pcall(json.decode, tostring(json_str))
        if not okj or type(data) ~= "table" then
            error("json 二次校验失败")
        end
        local function reqx(n)
            local okl, mod = xpcall(function()
                return require(n)
            end, function(e)
                return tostring(e) .. "\nTRACE>> " .. debug.traceback("", 2)
            end)
            if not okl then
                error("require失败[" .. n .. "]: " .. tostring(mod))
            end
            return mod
        end
        -- [M4-06] NPC 用游戏实战验证过的构建器:ChallengeMapFightNpcBuilder 是死代码
        -- (稳定期也 NewClass parent=boolean 崩,独立于缓存),对齐 ChallengeMapBattleRunner。
        local BasicNpcBuilder = reqx("app.FightSystem.FightCharacterBuilder.NPCBuilder.BasicMapNpcFightCharacterBuilder")
        local NpcBuilderConfig = reqx("app.models.ChallengeMap.MapBattle.ChallengeMapFightNpcBuilderConfig")
        local LocalPlayerBuilder = reqx("app.FightSystem.FightCharacterBuilder.LocalPlayerFightCharacterBuilder")
        local FightRunner = reqx("app.FightSystem.FightRunner")
        local FightFinishCallback = reqx("app.FightSystem.Fight.FightFinishCallback")
        local ChallengeMapResource = reqx("app.models.ChallengeMap.ChallengeMapResource")

        local l = LocalPlayerBuilder:create(role, {}):buildCharacter()
        if not l then
            error("玩家角色构建失败")
        end
        l:setTeamId("team_1")
        l:setPosIndex(1)
        l:setPlayer(true)

        local teamId = tonumber(data.foe_team) or 1001
        local team_info = ChallengeMapResource:getInstance():getNpcTeamMapById(teamId)
        if not team_info then
            error("敌队 " .. tostring(teamId) .. " 没找到")
        end
        local r = {}
        for i = 1, 3 do
            local bgId = team_info["pos" .. tostring(i) .. "NPCbgID"]
            local attrId = team_info["pos" .. tostring(i) .. "AttributeID"]
            if bgId and bgId ~= 0 and attrId then
                local level = team_info["pos" .. tostring(i) .. "AttributeLevel"]
                local name = team_info["pos" .. tostring(i) .. "NPCname"]
                -- [M4-06 v92] 主位换成 MUD 实际对手名(模型仍是挑战图队,但显示对上)
                local foe_display_name = (i == 1 and type(data.foe) == "table" and data.foe.name) or name
                name = foe_display_name
                local position = 3 + i
                local cfg = NpcBuilderConfig:create(name, level, attrId, bgId, position)
                local builder = BasicNpcBuilder:create(cfg)
                local npc = builder:buildCharacter()
                if npc then
                    npc:setTeamId("team_2")
                    npc:setPosIndex(position)
                    table.insert(r, npc)
                end
            end
        end
        if #r == 0 then
            error("敌队成员为空")
        end

        local finishCallback = FightFinishCallback:create()
        local function backToMud(fight)
            mud_fight_busy = nil
            pcall(function()
                MainControllLayer:resumeUpdate()
            end)
            local luaj = require("cocos.cocos2d.luaj")
            -- [M4-06 v92] 直推保活的 mudmaind 前台=秒回不断会(不走 openMud 登录页);
            -- [M4-06 v101] 但"战斗重启引导"的新进程里 mudmaind 是裸启动(无登录握手)接不上,
            -- 这种回程必须走 openMud(正常登录链)。标志由主界面拾取时置位(槽有货=重启引导)。
            if m4_restart_boot then
                m4_restart_boot = nil
                luaj.callStaticMethod("com/zwyouto/main/Util", "openMud", {}, "()V")
            else
                local okb = luaj.callStaticMethod("com/zwyouto/main/Util", "backToMud", {}, "()V")
                if not okb then
                    luaj.callStaticMethod("com/zwyouto/main/Util", "openMud", {}, "()V")
                end
            end
        end
        finishCallback:setWinCallbackFunc(backToMud)
        finishCallback:setLoseCallbackFunc(backToMud)
        finishCallback:setDrawCallbackFunc(backToMud)
        finishCallback:setRunawayFunc(backToMud)

        mud_fight_busy = true
        pcall(function()
            MainControllLayer:pauseUpdate()
        end)
        print("[M4] mapFightRun 启动")
        m4_vm_battles = (tonumber(m4_vm_battles) or 0) + 1
    FightRunner:mapFightRun({l}, r, finishCallback)
    end)

    if not okstart then
        print("[M4] 启动失败: " .. tostring(err))
        mud_fight_busy = nil
        scheduleRetry(err)
        return
    end

    mud_fight_retry_n = nil
    -- 真正启动成功后才清 Java 静态槽(否则 MainLayer 兜底领取会重放同一场)
    pcall(function()
        local luaj = require("cocos.cocos2d.luaj")
        luaj.callStaticMethod("com/zwyouto/main/Util", "clearMudFightJson", {}, "()V")
    end)
end

-- 加密标记
MyApp.isEncrypted = true
return MyApp
