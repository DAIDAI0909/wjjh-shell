--[[
Descripttion: 
version: 
Author: LvBin
Date: 2023-01-30 16:52:58
--]]
local NewClass = require("third.class.NewClass")
local AbstractUseItem = require("app.models.role.item.UseItem.AbstractRoleUseItem")

local RoleUseItem_Special = {}

function RoleUseItem_Special:__doUseItem()
    local item = self._item
    local role = self._role

    -- ★ 2026-10-09 sb06 行囊清理符（方案A，老板拍板）：本地批量出售，不联网。
    --   规则=把背包里所有"可出售"的物品一次性清出背包（按其 priceUnit 计价换钱，0 价杂物只清不给钱）；
    --   保留：任务类物品、神兵、身上装备中/准备中的兵器、损坏兵器——其余全清。
    if item.id == "testpack_clearbag" then
        local DialogALayer = require("app.views.layer.DialogLayer.DialogALayer")
        local dialog = DialogALayer:getInstance()
        dialog:hide()
        dialog:show("使用行囊清理符：\n\n将背包中所有可出售的物品一次性卖成银钱（杂物也随之清出背包）。\n任务物品、神兵、身上装备与准备中的兵器会保留。\n\n是否确定？")
        local function sb06_do_clean()
            local target = User:getRole()
            local snapshot = {}
            for i, v in ipairs(target:getItems()) do
                table.insert(snapshot, {itemId = v.itemId, count = v.count, id = v.id, wanhaodu = v.wanhaodu})
            end
            local shareUnit = {money = true, gold = true, yuanbao = true, yinpiao = true, meiyu = true, gongxiandian = true}
            local kinds, total = 0, 0
            for i, v in ipairs(snapshot) do
                local itemAttr = Item:getOneItemByKey(v.itemId)
                local canClean = itemAttr ~= nil
                    and itemAttr.id ~= "testpack_clearbag"
                    and itemAttr.wpType ~= "神兵"
                    and itemAttr.type ~= "任务"
                    and (itemAttr.type ~= "特殊" or itemAttr.id == "testpack_clearbag")
                    and not (v.wanhaodu == 0)
                if canClean and not target:checkItemIsEquip(v.id) and not target:checkIsPrepareWeapon(v.id) then
                    local priceUnit = itemAttr.priceUnit
                    if priceUnit == nil or priceUnit == "" or priceUnit == false or not shareUnit[priceUnit] then
                        priceUnit = "money"
                    end
                    local gain = (tonumber(itemAttr.salePrice) or 0) * v.count
                    if gain > 0 then
                        target:addAttr(priceUnit, gain)
                        total = total + gain
                    end
                    target:addItemCount(v.itemId, -v.count)
                    kinds = kinds + 1
                end
            end
            target:addItemCount("testpack_clearbag", -1)
            PopText("行囊清理：清出 " .. kinds .. " 种杂物")
            RichPrint("main", "HIY行囊清理符：清出 " .. kinds .. " 种物品，换得银钱若干（合计 " .. total .. "）。NOR")
        end
        dialog:setButton1("确定", sb06_do_clean)
        dialog:setButton2("取消", function()
        end)
        dialog:setWeChatVisible(false)
        return true
    end


    --@desc 使用物品，获得服务器奖励
    if item.rewardid ~= "" and item.rewardid ~= nil and item.rewardid ~= 0 then
        self:__getWebReward(3,item.rewardid,role)
    elseif item.rewardIds ~= "" and item.rewardIds ~= nil and item.rewardIds ~= 0 then
        self:__getWebReward(1,item.rewardIds,role)
    end

    return true
end

--@desc 获服务器奖励
function RoleUseItem_Special:__getWebReward(rewardType,rewardId,role)
    local item = self._item

    if rewardType == nil or rewardId == nil or MapIsEmpty(role) then
        return
    end

    local context = {
        params = {
            rewardType = rewardType,
            rewardId = rewardId,
            roleAttr = {lv = role:getLv(), menpaiId = role:getFamilyId(), qiMax = role:getFinalAttr("qiMax"), neiliMax = role:getFinalAttr("neiliMax")}
        },
        role = role,
        map = User:getRole():getCurrMap(),
        callback = function(rewardData)
            role:addItemCount(item.id , -1)
            PopText("消耗"..item.name.."X1")

            -- ★ 2026-10-22 v40：礼包**获得提示**（老板实测"点了只弹礼包名、像没反应"）。
            --   服务端已发货，但原版回调从不展示获得了什么 ⇒ 特殊类礼包全部"看着没生效"。
            --   这里按服务端应答通用展示：net_attrTab/loc_attrTab（属性）、item2/item1（物品名）。
            local function v40_show_rewards(data)
                if type(data) ~= "table" then return end
                local role2 = User:getRole()
                local ATTR_CN = {
                    accpoint = "固身元气", characterPoint = "特性见解", reflectExp = "感悟",
                    feelPoint = "感悟点", breathVal = "真气", exp = "经验", pot = "潜能",
                    jqdamage = "谙技",
                    money = "碎银", yuanbao = "元宝", yinpiao = "银票", gold = "黄金",
                    qi = "气血", neili = "内力", qiMax = "气血上限", neiliMax = "内力上限",
                    jing = "精力", jingMax = "精力上限", zhengqi = "侠义正气",
                }
                local got = {}
                for _, key in ipairs({"net_attrTab", "loc_attrTab"}) do
                    local t = data[key]
                    if type(t) == "table" then
                        for k, v in pairs(t) do
                            local cn = ATTR_CN[tostring(k)] or role2:getCHAttrName(tostring(k)) or tostring(k)
                            if tonumber(v) and tonumber(v) ~= 0 then
                                table.insert(got, cn .. " +" .. tostring(math.floor(tonumber(v))))
                            end
                        end
                    end
                end
                for _, key in ipairs({"item2", "item1"}) do
                    local t = data[key]
                    if type(t) == "table" then
                        for k, v in pairs(t) do
                            if tonumber(v) and tonumber(v) > 0 then
                                local it = Item:getOneItemByKey(tostring(k))
                                local nm = (it and it.name) or tostring(k)
                                table.insert(got, nm .. "×" .. tostring(math.floor(tonumber(v))))
                            end
                        end
                    end
                end
                if #got > 0 then
                    RichPrint("main", "HIY你获得了：" .. table.concat(got, "、") .. "！NOR")
                end
            end
            v40_show_rewards(rewardData)

            self:__onUseAft()
        end
    }

    -- ★★ 2026-10-08 单机版补丁（老板实测"打开的礼包没有生效"根因）：
    --   原版这里 `User:getRole():getDreamSystem():getWebReward(context)` ——
    --   **主世界（非梦境）getDreamSystem() 返回 nil** ⇒ 调用链在发请求之前就
    --   `attempt to index a nil value` 崩掉（被 xpcall 吞掉 ⇒ 表象=点"使用"毫无反应），
    --   这正是三个梦境礼包此前只能"购买时记账"、点开没反应的原因。
    --   而 DreamSystem:getWebReward 本身只是 `RewardManager2:getWebReward(context)` 一层
    --   转发（见 DreamSystem.lua:2208）——主世界直接调 RewardManager2 语义完全一致。
    --   修=主世界回退直调 RewardManager2 ⇒ 特殊类物品在主世界背包里点"使用"也能发货。
    local drSystem = User:getRole():getDreamSystem()
    if drSystem then
        drSystem:getWebReward(context)
    else
        local RewardManager2 = require("app.models.reward.RewardManager2")
        RewardManager2:getWebReward(context)
    end
end


return NewClass("RoleUseItem_Special", {AbstractUseItem}, RoleUseItem_Special)
