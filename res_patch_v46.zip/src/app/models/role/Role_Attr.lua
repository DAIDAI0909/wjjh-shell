print("FZPROBE_ROLE_ATTR_V1")
local Role_Attr = {}
local RoleTitleConst = require("app.models.role.titleSystem.RoleTitleConst")
local SkillResManager = require("app.models.skill.SkillResManager")
local GameConst = require("app.models.game.GameConst")
--@RefType [src.app.models.skill.BasicSkill.BasicSkill#BasicSkill]
local BasicSkill = require("app.models.skill.BasicSkill.BasicSkill")
local Family = require("app.models.family.Family")
local NaturalAttrAdjustmentConst = require("app.models.role.attr.NaturalAttributePlan.NaturalAttrAdjustmentConst")

-- 年龄描述
local ageDsc =
{
	{age = 0, dsc = "十多岁"},
	{age = 20, dsc = "二十来岁"},
	{age = 25, dsc = "二十多岁"},
	{age = 30, dsc = "三十来岁"},
	{age = 35, dsc = "三十多岁"},
	{age = 40, dsc = "四十来岁"},
	{age = 45, dsc = "四十多岁"},
	{age = 50, dsc = "五十来岁"},
	{age = 55, dsc = "五十多岁"},
	{age = 60, dsc = "六十来岁"},
	{age = 65, dsc = "六十多岁"},
	{age = 70, dsc = "七十来岁"},
	{age = 75, dsc = "七十多岁"},
}

-- 气血状态描述
local qiDsc =
{
	{qi = 0, dsc = "HIR受伤过重，已经有如风中残烛，随时都可能断气"},
	{qi = 5, dsc = "HIR受伤过重，已经奄奄一息，命在旦夕了"},
	{qi = 10, dsc = "HIR伤重之下已经难以支撑，眼看就要倒在地上"},
	{qi = 20, dsc = "RED受了相当重的伤，只怕会有生命危险"},
	{qi = 30, dsc = "RED已经伤痕累累，正在勉力支撑著不倒下去"},
	{qi = 40, dsc = "RED气息粗重，动作开始散乱，看来所受的伤著实不轻"},
	{qi = 60, dsc = "HIY受伤不轻，看起来状况并不太好"},
	{qi = 80, dsc = "HIY受了几处伤，不过似乎并不碍事"},
	{qi = 90, dsc = "HIY看起来可能受了点轻伤"},
	{qi = 95, dsc = "HIG似乎受了点轻伤，不过光从外表看不大出来"},
	{qi = 100, dsc = "HIG气血充盈，并没有受伤"},
}

-- 战斗中, 状态描述
local fightQiDesc =
{
	{qi = 0, dsc = "HIR$n已经陷入半昏迷状态，随时都可能摔倒晕去。"},
	{qi = 10, dsc = "HIR$n摇头晃脑、歪歪斜斜地站都站不稳，眼看就要倒在地上。"},
	{qi = 20, dsc = "RED$n看起来已经力不从心了。"},
	{qi = 30, dsc = "RED$n已经一副头重脚轻的模样，正在勉力支撑著不倒下去。"},
	{qi = 40, dsc = "RED$n似乎十分疲惫，看来需要好好休息了。"},
	{qi = 60, dsc = "HIY$n气喘嘘嘘，看起来状况并不太好。"},
	{qi = 80, dsc = "HIY$n动作似乎开始有点不太灵光，但是仍然有条不紊。"},
	{qi = 90, dsc = "HIY$n看起来可能有些累了。"},
	{qi = 95, dsc = "HIG$n似乎有些疲惫，但是仍然十分有活力。"},
	{qi = 100, dsc = "HIG$n看起来充满活力，一点也不累。"},
}

local RoleAttrDesc = require("app.models.role.attrDescText.RoleAttrDesc")
-- 相貌描述
local looksDsc = RoleAttrDesc:getLooksDsc()

-- 角色属性初始化, 用来通过公式矫正角色属性, 以及恢复满血状态
function Role_Attr:initAttr()
	return self:callModuleFunc("initAttr")
end

-- 玩家属性变化时 判断是否有联动变化
function Role_Attr:checkAttr(name)
	return self:callModuleFunc("checkAttr", name)
end

-- 获得基础属性
function Role_Attr:getBaseAttr(name)
	return self:callModuleFunc("getBaseAttr", name)
end

-- 设置属性
function Role_Attr:setAttr(name, var)
	if self == User:getRole() and table.keyof(NaturalAttrAdjustmentConst.ATTR_TYPE, name) then
		return 
	end

	return self:callModuleFunc("setAttr", name, var)
end

-- 获取属性`
function Role_Attr:getAttr(name)
	return self:callModuleFunc("getAttr", name)
end

-- 获取属性值（取值为数字类型的属性值）
function Role_Attr:getNumAttr(name)
	return self:callModuleFunc("getNumAttr", name)
end

-- 添加属性（只用于数字类型）
function Role_Attr:addAttr(name, var)
	-- ===================== ★ 测试礼包伪属性（我们加的 · 2026-09-29） =====================
	-- 这两个不是真属性，只是借"属性奖励"这条通道让测试礼包能一键发东西。
	-- 客户端开箱只认 属性 / 物品 两类奖励，而"把技能设到 500 级""发全部书页"
	-- 走 addAttr 最省事，两条开箱代码路径都会调到这里。
	-- ---- 公共小工具（一次只给少量；只在最后 notify 一次，避免背包界面被重建很多次）----
	local function _fzPut(arr, role, itemId, cnt)
		for i = 1, #arr do
			local e = arr[i]
			if e and e.itemId == itemId then
				e.count = (e.count or 0) + cnt
				return
			end
		end
		arr[#arr + 1] = role:createSafeItem(
			{ id = role:getItemOnlyId(), count = cnt, itemId = itemId })
	end
	local function _fzRandByType(role, pool, n, per)
		if #pool == 0 then
			return 0
		end
		if role.items == nil then role.items = {} end
		local seen, got = {}, 0
		for _try = 1, n * 40 do
			if got >= n or got >= #pool then
				break
			end
			local id = pool[math.random(1, #pool)]
			if not seen[id] then
				seen[id] = true
				got = got + 1
				_fzPut(role.items, role, id, per)
			end
		end
		return got
	end
	if name == "testRandSkill" or name == "testRandKnow" then
		-- 【随机武学宝箱】/【知识宝箱】：各随机学会**一门**没学过的。
		--   ★ 奖池是**服务端算好的 id 名单**（嵌进下面的 POOL），覆盖**所有门派**的武学：
		--     武学 686 门（江湖/少林/华山/天竞门/雪山寺/拜日教/问情宫/全真教/丐帮…）
		--     知识类 64 门（兵法战策/禅宗心法/丹匮玄功/长生诀…）
		--   不靠客户端表字段分类（之前那样会把池子算空 ⇒ 弹"已经全学会了"）。
		local wantKnow = (name == "testRandKnow")
		local POOL = wantKnow and { "bingfazhance", "changshengjueyang", "changshengjueyin", "chanzongxinfa", "dachengboregong", "dankuixuangong", "daoxuexinfa", "dislodgeDistracting", "duanzaozhishu", "dushushizi", "guanxingshu", "innatePointSwitch", "jianghudushu", "jiaohuajuehuo", "jibenduji", "jiguananqi", "kuihuaxinfa", "kwTransform", "langrenmindskill", "liandanshu", "lubanshu", "luoyuejiaxun", "luoyuezhuanggui", "meirongshu", "meridianConvert", "miaosuanzhishu", "mingjiaojiaoyi", "mizongxinfa", "mojiajiguanshu", "qihuangzhishu", "qimenwuxing", "qinqishuhua", "qufengshu", "shalangjue", "shengcaizhidao", "shenghuolingfa", "shengsibu", "shenzhaojing003", "sifangzalu", "stGammaSutra", "tangmenmishu", "tiezhangbanggui", "wudujing", "wumuyishu", "wuxianshu", "wuxingdunfa", "wuzuoshu", "xiangmashu", "xiangmianshu", "xingxiududian", "xingyunlu", "xiyudujing", "yangsheshu", "yangxinjue", "yirongshu", "yongyemishu", "youmingjiaoyi", "zhanxingshu", "zhengaoxuanjing", "zhengqijue", "zhongzhizhishu", "zhougongzhishu", "zhuizongshu", "zouxueshisijing" } or { "AcalanathaRule", "AscendCosmos", "AzoicHook", "BearEightHardships", "BigDipperSowrdVII", "BodhiBirding", "BreakSandAndArmy", "BurnDownlswd", "ClearRippleGripWood", "ColdToadQigong", "CtrlColdAbyss", "CurseRitualDance", "DaybreakerPunch", "DefyingDeath", "DesperateTreadstar", "DouKuiIV", "DrunkDragonSubdue", "DrunkFlipSky", "EarthlyRealmEightTunes", "EnterFormationSong", "FacingDeathSolo", "FearlessBattle", "FlappyCrane", "FormulaBigDipper", "GoldenAscensionStep", "GrapHeartTenThunder", "HarmonyNatureSteps", "HeavenReversalFinger", "HeavenlyAscendingToad", "ImmortalPace", "ImperishableForm", "JudgeFatePen", "JupiterProphecy", "MoonWaxesWwanes", "MountainStep", "MysticSunFist", "NirvanaPurify", "NourishPoisonInsect", "OccultCraneFeather", "OldTreeBreakWave", "PeachBlossomSong", "PeachBlossomSound", "PeakCalmScroll", "PhaselessSwordMight", "PolarTransHeartSutra", "QuakeMartialEssence", "RainbowChasingSun", "RidingThunderSkySoarer", "RoamingDesert", "ScatteredStarRain", "ShadowyStrike", "ShakeDesertTiger", "ShatteringJadeKnife", "SixPhaseConfusion", "SpringAutumnSwordplay", "StealDivineLongevity", "StepFogShadowless", "SupremeNarayanMethod", "SyncreticGoldRing", "TiangangZhuaIII", "TigerEndImpass", "TigerGuardVariable", "TitanSword", "TransformDragon", "TreasureChronicle", "TriUnityRighteousPalm", "TrigramGridStep", "UncertainDeadAlive", "VengeanceFinger", "ViewOfHeart", "WindController", "YinYangEsoterica", "aluohanshengong", "anranxiaohunzhang", "antiinvasionSing", "anyingfuxiang", "babinazhajifa", "baguadaofa", "bahuanggong", "baihuacuoquan", "bailianjiaojingong", "baimangbianfa", "baishengdaofa", "baiyuanjianfa", "baiyuanjianfa1", "baiyuantongbeiquan", "bajidaqiangshu", "bajiquan", "banchengjue", "baniaochaofengqiang", "bawangqiangfa", "bazhenbaguazhang", "beimingshengong", "benleishou", "biboshengong", "bigDipperZenStick", "biluozhang", "bingpohandao", "bingweimoquan", "bingxuexinfa", "bitaoxinfa", "bixuexinfa", "biyesuifengwu", "biyunxinfa", "bloodbaneFrenzy", "bloodilySword", "boluomishou", "borezhang", "brightLunaDuskyCandle", "brightLunaSword", "budongmingwangjian", "caiweijianfa", "calmTideStepWaves", "cangfengdaofa", "canghubu", "canglangbianfa", "canglongzhuri", "cangxueguyingshi", "canhezhi", "chan", "chanchubufa", "chanhunsuo", "chansiqinnashou", "chijiayangshagong", "chilianlingbo", "chilianshenzhang", "chixinqingchangjian", "chongguangnei", "chongguangqing", "chousuizhang", "chuanhuaraoshu", "chuanyunshou", "chuanyuntui", "chunfengkuaiyidaofa", "chunfengkuaiyidaofa1", "chunyanggong", "cibeidao", "closeShaveMagic", "cuixinzhang", "dagoubangfa", "dajingangquan", "dajingangshenzhang", "daluoyanshou", "damojian", "damoshenchanzhangfa", "daojianguizhen", "dasongyangzhang", "dazangzhangxueyinshou", "dealIron1", "dealIron11", "dealIron12", "dealIron13", "dealIron14", "dealIron15", "dealIron2", "dealIron3", "dealIron4", "dealIron5", "deceiveHvnsFW", "dingzibu", "disartBlazClaw", "douzhuanxingyi", "douzhuanxingyizhang", "dualGrooveIronGar1", "dualGrooveIronGar11", "dualGrooveIronGar12", "dualGrooveIronGar13", "dualGrooveIronGar14", "dualGrooveIronGar15", "dualGrooveIronGar2", "dualGrooveIronGar3", "dualGrooveIronGar4", "dualGrooveIronGar5", "duanjiajian", "duanjinsuigu", "duanshiyiyangzhi", "duantijing", "duanyunfu", "duanzhilixianqin", "dugujiujian", "duhuojian", "dulongshenzhuagong", "duohunmice", "duoluoyezhi", "duominglianhuanjian", "dushazhang", "duzhuojianfa", "duzhuojianfa1", "eightGatLtaStaff", "emeijiuyanggong", "emptyCharacteristics", "esoterPrimordReturn", "essenceDevoured", "fangshenshu", "fanliangyidaofa", "feifengbian", "feixianjianfa", "feixingshu", "feixueyingmeizhang", "feiyanhuixiang", "feiyingshisanshi", "fengbaojinxingqu", "fengjuancanyungong", "fengmozhangfa", "fengshanjianfa", "fengshenjue", "fengyunshou", "flowCloudsInkSils", "flyingLeaf", "forbearancePairSword", "frenzBoneWhip", "fuguanglueying", "fuhuquan", "fuhuzhang", "fumoguangmingquan", "fumojian", "fuyueliuyunzhi", "gaogejianfa", "geludaofa", "getWetLotusSprout", "ghstStlHvnStep", "gouyao", "grabwindtoadhand", "greenWindHuan", "guisha", "guisuomishu1", "guiyoushenfa", "guiyuantunafa", "hamagong", "hanbingguizhua", "hanbingmianzhang", "hanshanzhangfa", "hantianshenshou", "hanxingbada", "hanxuebianfa", "haotianzhang", "heishasishijiuzhua", "heishazhang", "hengshan_sword", "hengshanjianfa", "heqidao", "hidInAbyss", "hidingSkyStride", "honghuashengong", "houquan", "huagongdafa", "huagumianzhang", "hualingliushuizhang", "huashanjianfa", "huashanneigong", "huaxinggong", "huaxuyin", "huifengfuliujian", "huifengluoyanjian", "huiyanxinfa", "hujiadaofa", "hujiadaofa1", "hujiaquanfa", "hundLegPiercSoulHook", "huntianqigong", "hunyuangong", "hunyuanyiqigong", "hunyuanzhang", "huoyandao", "immolCallMystic", "invisibleShadow", "itavanaBreakBarrier", "jiangshibufa", "jiangwangguibu", "jiangwangguibu2", "jiangxingpoegou", "jiayishengong", "jiazixuanjixinfa", "jimiezhua", "jinchuibashi", "jincuodaofa", "jindingmianzhang", "jinfenglu", "jingangxiangmochu", "jingangyujiamuquan", "jingbogunfa", "jinghaishengong", "jinghongzhaoying", "jinguangdaofa", "jingxinjing", "jingyixinfa", "jinhuoruyihuan", "jinyangong", "jinyuquan", "jiugongliuhezhang", "jiulongbianfa", "jiutianxianglongtui", "jiuyangshengong", "jiuyinbaguzhua", "jiuyinbaituopian", "jiuyinzhenjing", "jubaoquan", "jueqingbianfa", "kaitianfufa", "knightCodeConduct", "kongmingquan", "kuaihuojianfa", "kuaihuoshisanzhang", "kuangfengkuaijian", "kuihuadafa", "kuihuafeiying", "kunlunzhang", "kurongchangong", "kusangbangfa", "lanhuafuxueshou", "lanshashou", "lanyeshenzhang", "lanyeshenzhang2", "lengyueshengong", "liangshixinfa", "liangyijianfa", "liehuobianfa", "liehuojian", "lieyandao", "lihejiuchai", "lingboweibu", "linghexinfa1", "lingshequan", "lingshezhangfa", "lingxiaoxinfa", "lingxiyizhi", "lingxubu", "lingyuanmishu", "lingyuanxinfa", "linjishierzhuang", "liuhezhang", "liumaishenjian", "liumangshenquan", "liushiyunxingshenfa", "liuxingganyuebiao", "liuxingguaifa", "liuyinzhuihunjian", "liuyuejianwu", "longwujiutianshou", "longxiangboregong", "longxingboji", "longyinjue", "longzhuagong", "luanpifengjianfa", "luanqisha", "luanyuzhangfa", "luaoyuanmingliuquanshu", "lunhuijianfa", "lunhuijianfa2", "lunhuixinfa", "luohanquan", "luohuashisanjian", "luorishenquan", "luoyingshenjian", "luoyingshenjianzhang", "luoyuejianfa", "luoyuejianfa1", "mailudaofa", "mangfutiequan", "manjianghongjianfa", "mantianhuayu", "mantianxing", "meihuashengong", "meinvquan", "mengbishenghuajing", "mengtianzhang", "miaojiajianfa", "mingjunjingong", "mingyugong", "mizhijianfa", "mizhizhangfa", "mizongdashouyin", "mohezhi", "mortalAnnals", "murongdaofa", "murongjianfa", "musicTemperament", "nianhuazhi", "niaozhuo", "niyangong", "paiyuntuishou", "panshishengong", "panyangzhang", "peijiangjunshizhangfa", "peripateticismgun", "pianxianbufa", "piaomiaoshenfa", "piaoyibufa", "pilibiao", "pingweifenjinquan", "pishipoyuquan", "pixiejianfa", "pocaishou", "pomopimajianfa", "poyunshou", "puduzhang", "purifyHellAxe", "purifyMind", "putixinfa", "qianhunlie", "qianjinjue", "qiankundanuoyi", "qianlongfeidun", "qianlonghubaoxinfa", "qianzhuwandushou", "qibaotianlanwu", "qijingjianzhang", "qimenwuzhuan", "qingchengcuixinzang", "qingchengliuhedao", "qingdianzilei", "qingdianzilei1", "qingdishengong", "qingfengbufa", "qingfushenfa", "qingmingxuangong", "qingpingzhi", "qingshejianfa", "qingyunshou", "qinlonggong", "qinnashou", "qishadaofa", "qishajian", "qishangquan", "qiugeqidao", "qiulinshiye", "qiuyannanhui", "qixianwuyinjian", "qixingfentianshou", "qixinghuanwei", "qixingjianfa", "qixingmizongbu", "qixingxingyishou", "qixingxuanlingjianfa", "quanzhenjianfa", "ranmudaofa", "raozhiroujianfa", "ribengujianshu", "ribenguwushu", "riyuebianfa", "riyuelun", "riyuelun1", "rollingDragon", "ruanhongzhusuo", "rulaiqianyeshou", "ruyidaofa", "ruyingsuixingtui", "sacrePyricStep", "sanhuajudingzhang", "sanhuazhang", "sanshenfodao", "sanshoubapu", "sanyinwugongzhua", "satashenfa", "sevenRhymeFootwork", "shaolinshenfa", "shaolintantui", "shaolinwuyingjian", "shaolinzuigun", "shayixinfa", "shedaoqigong", "sheduqiqiao", "shenghuoshengong", "shengongguifu", "shengsibo", "shenguhuoxinliu", "shenkongxing", "shenlongbashi", "shenlongdiwangquan", "shenlongtuifa", "shenlongxinfa", "shenmenshisanjian", "shentuoxueshanzhang", "shenxingbaibian", "shenyuangong", "shexingdiaoshou", "sheyao", "shibashoutiezhangyingou", "shierdishaqi", "shilikuangdao", "shizhenjue", "shockmountaintoadleg", "shouxinjie", "shuishangpiao", "shuiyunbianfa", "sihaisanjianggong", "siqijianfa", "sixiangbufa", "songfengjianfa", "songshanjianfa", "souguyingzhuagong", "soulBreakInFlash", "soulSevFixSun", "soulStepStride", "spiritBindCircles", "stygSoulGraspClaw", "suohougong", "suolian", "suxinjianfa", "taijijian", "taijiquan", "taijishengong", "taiquan2", "taishanjianfa", "taixuangong", "taixuangong2", "taiyangshenzhua", "taizuchangquan", "takongxubu", "tanzhishentong", "tashaxing", "taxuewuhen", "ti", "tiancantuifa", "tianchangzhangfa", "tiangangquanfa", "tiangangzhixuefa", "tianleipo", "tianlongchangong", "tianluobufa", "tianluodiwangshi", "tianmodafa", "tianmodao", "tianmojian", "tianmoquanfa", "tianmozhang", "tianmozhi", "tianmozhi1", "tiannanbufa", "tiannvsanhuashou", "tianshanliuyangzhang", "tianshanzhangfa", "tianshanzhemeishou", "tianwangbuxinzhenfa", "tianxingzhengqigong1", "tianyanxinjing", "tianyidaofa", "tianyuqijian", "tianzhufozhi", "tiebushan1", "tiexueshijian", "tiezhangmifa", "tiezhangzhangfa", "tingfengjing", "tiyunzong", "tongbiliuhezhang", "tripleStringSound", "tsxiaowuxianggong", "vastBlade", "wangshenggong", "wanxiangshoujian", "wanzaikonglingzhangfa", "weijinxinfa", "weijinxinfa2", "weituochu", "weituogun", "weituozhang", "whistlingTemperament", "wuchangjiasuoshou", "wuchangzhang", "wudangmianyanbu", "wudangmianzhang", "wudinggou", "wudiweijian", "wudugoufa", "wudushengong", "wuduyanluobu", "wugongyao", "wuhenjin", "wuhuduanmendao", "wulangbaguagun", "wuliangjianfa", "wulongjiaozhutui", "wuluoqingyanzhang", "wuqichaoyangjian", "wuqituifa", "wuqituifa2", "wushashenzhang", "wuxiangjiezhi", "wuxingdong", "wuxingquan", "wuxingzhi", "wuxudaofa", "wuyingfeidao", "wuyingtui", "wuyinmifa", "wuyinrumengjue", "wuyunqixianjian", "wuzhanmei", "wuzhengxinfa", "xianglongshibazhang", "xiangmozhangfa", "xianluoji", "xiantianqigong", "xianyindaofa", "xiaolifeidao", "xiaowuxianggong", "xiaoyaowuxiangjian", "xiaoyaoyou", "xiezici", "xikuangyijuan", "xinbawangqiangfa", "xingyiquanfa", "xinmingyugong", "xinshenghuolingfa", "xiuluodao", "xiuluojuemingdaofa", "xixingdafa", "xiyuesanshenjian", "xiyutiezhengyin", "xuanfengsaoyetui", "xuanhualiuquanfa", "xuanmingshenzhang", "xuantianbingcanzhang", "xuantianwujigong", "xuantianwuqingzhi", "xuantiejianfa", "xuanyuanfufa", "xuanyuexinfa", "xuedaodaofa", "xueshanjianfa", "xunleijianfa", "yangjiaqiangfa", "yanlingshenfa", "yanshuangfei", "yanxingdaofa", "yanyunpiaomiaobufa", "yao", "yechagunfa", "yidaoliu", "yidaoliujianshu", "yijinjingshengong", "yilanshizhang", "yinfengzhua", "yingfengzhulangbu", "yingliubadaoshu", "yingzhuagong", "yinsuojinling", "yinyangdaoluanrenfa", "yinyangguiyihuan", "yiqigong", "yitianjianfa", "yitianjianfa1", "yitiantulonggong", "yixingbufa", "yiyangzhi", "yizhichan", "youhunniyinggong1", "youlongshenfa", "youmingguizhua", "yuanyanglianhuantui", "yueguangjian", "yuejiaqiangfa", "yuenvjianfa", "yueyingwubu", "yunlongbianfa", "yunlongjian", "yunlongshenfa", "yunlongshengong", "yunlongshou", "yunlongzhua", "yunvjianfa", "yunvshenfa", "yunvxinfa", "yuxianjue2", "yuxiaojianfa", "zhaixinggong", "zhaohunshibajian", "zhentianquan", "zhenyangwujigong", "zhizhuyao", "zhongyueshenfeng", "zhougongjianfa", "zhoutiangong", "zhouyukuangfengfu", "zhuihundduomingjian", "zhuihunduomingbiao", "zhuiyingsuifengqiang", "zhuo", "zhuoguqin", "zhutianhuashenbu", "zhuxianqinyin", "zimuzhenfa", "zixiashengong", "zuibaxiangunfa", "zuixianwangyuebu" }
		local SkillHelper = require("app.models.skill.SkillHelper")
		if self.skills == nil then self.skills = {} end
		local pool = {}
		for i = 1, #POOL do
			-- 判"学没学过"两道保险：先问官方 getLv，再看存档表（忘忧丹清过表 ⇒ 应判为没学）
			local lv, has = 0, false
			local okL = pcall(function() lv = SkillHelper:getLv(self, POOL[i]) end)
			if okL and tonumber(lv) and tonumber(lv) > 0 then
				has = true
			else
				local t = self:getAttr("skills") or self.skills
				if type(t) == "table" and t[POOL[i]] ~= nil then
					has = true
				end
			end
			if not has then
				pool[#pool + 1] = POOL[i]
			end
		end
		if #pool == 0 then
			-- ★ 兜底（2026-10-01 老板踩过"池子判空 ⇒ 什么都不给"）：判重不准也从全池随机给一门，
			--   反正 setSkillLv 对已学的只是重置经验，不会出错。
			pool = POOL
		end
		if #pool == 0 then
			PopText("奖池是空的，先不发了")
			return
		end
		local sid = pool[math.random(1, #pool)]
		pcall(function() SkillHelper:setSkillLv(self, sid, 1) end)
		local nm = sid
		local okT, tab = pcall(function()
			return requireWithEncrypt("script.skill.skill")
		end)
		if okT and type(tab) == "table" then
			local L = (type(tab.skills) == "table" and tab.skills) or tab
			if type(L[sid]) == "table" and L[sid].name then
				nm = L[sid].name
			end
		end
		MessageCenter:notify("AttrChangeAfterEvent", { role = self, attrName = "skills" })
		PopText((wantKnow and "知识宝箱：学会 " or "随机武学宝箱：学会 ") .. tostring(nm) ..
			"（还剩 " .. (#pool - 1) .. " 门没学）")
		return
	end
	if name == "testLearnAllSkills" then
		-- 【武学总纲】直接学会客户端表里的**全部武学**（含知识类/氪金/限时那些平时拿不到的）
		--   走官方 setter `SkillHelper:setSkillLv(role, sid, 1)`，等级先给 1（满级包再拉满）。
		local SkillHelper = require("app.models.skill.SkillHelper")
		local ok, tab = pcall(function()
			return requireWithEncrypt("script.skill.skill")
		end)
		if not ok or type(tab) ~= "table" then
			PopText("武学表读不到，先不发了")
			return
		end
		local list = (type(tab.skills) == "table" and tab.skills)
			or (type(tab.Skills) == "table" and tab.Skills) or tab
		if self.skills == nil then self.skills = {} end
		local n, skipped = 0, 0
		for sid, cfg in pairs(list) do
			-- 只认"真武学"：键是字符串、值是表、且表里有 id（避开 Sheet2 / 正气需求 这些元键）
			if type(sid) == "string" and type(cfg) == "table" and cfg.id ~= nil then
				local okx = pcall(function() SkillHelper:setSkillLv(self, sid, 1) end)
				if okx then
					n = n + 1
				else
					skipped = skipped + 1
				end
			end
		end
		MessageCenter:notify("AttrChangeAfterEvent", { role = self, attrName = "skills" })
		PopText("武学总纲：学会 " .. n .. " 门武学（跳过 " .. skipped .. " 门）")
		return
	end
	if name == "testForgetAllSkills" then
		-- 【忘忧丹】忘记所有武学 + 主动技能（技能洗点）
		local n1 = 0
		if type(self.skills) == "table" then
			for _ in pairs(self.skills) do n1 = n1 + 1 end
		end
		local n2 = 0
		if type(self.activeZhaos) == "table" then
			for _ in pairs(self.activeZhaos) do n2 = n2 + 1 end
		end
		self.skills = {}
		self.activeZhaos = {}
		self.preparedActiveZhao = {}
		if type(self.prePrepareSkill) == "table" then self.prePrepareSkill = {} end
		MessageCenter:notify("AttrChangeAfterEvent", { role = self, attrName = "skills" })
		PopText("忘忧丹：已忘记 " .. n1 .. " 门武学、" .. n2 .. " 个主动技能（可重新学）")
		return
	end
	if name == "testChangeFamily" then
		-- 【易门丹】退出门派（清掉门派归属）⇒ 之后可以重新拜师选门派
		local old = self.family
		local nm = ""
		if type(old) == "table" and old.name then nm = tostring(old.name) end
		self.family = {}
		self:setAttr("family", {})
		pcall(function() self:setAttr("familyName", "") end)
		MessageCenter:notify("AttrChangeAfterEvent", { role = self, attrName = "family" })
		PopText("易门丹：已退出门派" .. (nm ~= "" and ("（原：" .. nm .. "）") or "") .. "，现在可以重新拜师")
		return
	end
	if name == "testMeridianBreak100" then
		-- 【经脉冲脉丹】吃下之后：**每次冲穴必定成功（100%）**
		--   实现方式是打一个角色标记，真正的"必定成功"在 `Meridian.lua:getRandomEventState`
		--   里（我们那边加了一句：有这个标记就 `event = 1`，1 = 冲穴成功）。
		--   游戏自己本来就有这个钩子（`:698` 的 `getTimeLimitFlag("冲穴成功")`），
		--   只是那个是一次性的；我们这个是永久的。
		--   标记写在角色身上 ⇒ 跟着存档走，重登也在。
		self:setAttr("fzBreak100", 1)
		PopText("经脉冲脉丹：从现在起，每一次冲穴都是必定成功（100%）")
		return
	end
	if name == "testHiddenBreak100" then
		-- 【隐脉冲脉丹】吃下之后：**每次隐脉冲脉必定成功（100%）**
		--   隐脉的冲脉是**服务端判定**的（`start_thoroughfare_vessel` 的 errcode），
		--   所以这里也打一个标记，服务端那边认这个标记后一律回成功。
		self:setAttr("fzHiddenBreak100", 1)
		PopText("隐脉冲脉丹：从现在起，每一次隐脉冲脉都是必定成功（100%）")
		return
	end
	if name == "testHomeLevelUpLocal" then
		-- 【一键提升地契/房契·客户端立刻生效】
		--   ★ 为什么必须客户端也改：`Homeland.fq` 是**客户端那份账**（`FangQiModel.lua:64-88`
		--     写的就是 `fq.mid` / `fq.fqId` / `fq.dpId`），而 `BaseMap:isUserMap()`
		--     （`BaseMap.lua:4262`）判的是 `self.mid == fq.mid`。服务端改了档但客户端
		--     这一份不变的话，当场看不到变化，而且下次上传会把旧的盖回去。
		--   ★ `fq` 必须整成**表**（不是数组）—— 数组形态下 `fq.mid` 是 nil，管家就不认人。
		if type(self.Homeland) ~= "table" then self.Homeland = {} end
		local hl = self.Homeland
		local fq = hl.fq
		if type(fq) == "table" and fq[1] ~= nil and fq.mid == nil then
			local merged = {}
			for _i = 1, #fq do
				if type(fq[_i]) == "table" then
					for _k, _v in pairs(fq[_i]) do merged[_k] = _v end
				end
			end
			fq = merged
		end
		if type(fq) ~= "table" then fq = {} end
		fq.id = fq.id or "fq100"
		fq.type = fq.type or "房契"
		fq.name = fq.name or "阳口悬钟"
		fq.fqId = "yangzhou152"        -- 顶级房型（huxing012 / 63 间房）
		fq.dpId = "yangzhou152"        -- ★ 真 dpId（`房屋地皮` 里没有 dp_ 前缀）
		fq.status = 1                  -- 已搬入
		hl.fq = fq
		hl.roomnum = 63
		hl.dq = hl.dq or {}
		hl.yq = hl.yq or {}
		hl.plant = hl.plant or {}
		hl.dinner = hl.dinner or {}
		MessageCenter:notify("AttrChangeAfterEvent", { role = self, attrName = "Homeland" })
		PopText("一键提升：房契/地契已升到顶级（阳口悬钟 · 63 间房）。回主界面再进家园就生效")
		return
	end
	if name == "testWeaponPack" then
		-- 【测试】武器礼包：1 把随机顶级武器（按 damage 排前列那批）+ 随机 3 种锻造材料 ×10
		--   ★ 一次只给少量（老板 2026-10-01：别一次给太多，重复买慢慢攒）
		local Items = requireWithEncrypt("script.map.mapItemAttr")["Items"]
		local pool = {}
		for k, v in pairs(Items) do
			if type(k) == "string" and v and v.type == "锻造材料" then
				pool[#pool + 1] = k
			end
		end
		local TOP = { "eq2020spring1", "2020week04", "2021xinchungun1", "eq2020cz04", "eq2020cz02", "caidaneq06", "caidaneq05", "caidaneq04", "caidaneq03", "caidaneq02", "20dzeq1", "21laodongweapon01", "eq2020dy01", "eq2020cz01", "20dyleq3", "2021czjfeq1", "eq2020spring2", "eq2020cz03", "22tigerywepon4", "22tigerywepon3" }
		local wid = TOP[math.random(1, #TOP)]
		if self.items == nil then self.items = {} end
		_fzPut(self.items, self, wid, 1)
		local got = _fzRandByType(self, pool, 3, 10)
		MessageCenter:notify("itemChangeEvent", { role = self })
		local wn = (Items[wid] and Items[wid].name) or wid
		PopText("获得顶级武器：" .. wn .. " ×1；另随机锻造材料 " .. got .. " 种 ×10")
		return
	end
	local _grp, _cnt = string.match(name, "^testRandItems_(.+)_(%d+)$")
	if _grp then
		-- 【测试】通用资源礼包：从"某一类资源"里随机挑 n 种，每种给一点
		--   例：testRandItems_淬炼材料_3 / testRandItems_经脉丹药_3 / testRandItems_家园建材_3
		local Items = requireWithEncrypt("script.map.mapItemAttr")["Items"]
		local pool, per = {}, 10
		if _grp == "yunjing" then
			per = 1                      -- ★ 武学云镜（装饰箱 0/144）：每次随机 1 个
		elseif _grp == "经脉丹药" then
			pool = { "jingmai100", "jingmai101", "jingmai102", "jingmai103",
			         "jingmai104", "jingmai105", "jingmai106" }
			per = 5
		elseif _grp == "家园建材" then
			for k, v in pairs(Items) do
				if type(k) == "string" and string.sub(k, 1, 9) == "bmaterials" then
					pool[#pool + 1] = k
				end
			end
			per = 20
		else
			for k, v in pairs(Items) do
				if type(k) == "string" and v and v.type == _grp then
					pool[#pool + 1] = k
				end
			end
			if _grp == "锻造图谱" then per = 1 end
		end
		local n = tonumber(_cnt) or 3
		local got = _fzRandByType(self, pool, n, per)
		MessageCenter:notify("itemChangeEvent", { role = self })
		PopText("随机获得【" .. _grp .. "】" .. got .. " 种 ×" .. per .. "（奖池 " .. #pool .. " 种）")
		return
	end
	local _qingxin = string.match(name, "^testClearInheritFatigue$")
	if _qingxin then
		-- 【清心参茶】继承人疲劳值立刻回满（培养玩法补疲劳用）。
		--   ★ 2026-10-04 老板要求上商城：原版没有任何降疲劳道具（InheritAttrLayer:recovery
		--     每 720 秒+1，一次培养-10），这里走伪属性把疲劳直接拉满并重置恢复计时。
		pcall(function()
			local User = require("app.models.user.User")
			local inh = User:getRoleAttr("inherit")
			if type(inh) == "table" then
				inh.endurance = inh.enduranceMax or 100
				self:setFlag("传承疲劳值恢复时间", 0)
			end
		end)
		PopText("继承人的疲劳值全部恢复了，可以继续培养！")
		return
	end
	local _pfboost = string.match(name, "^testPoisonFormulaBoost$")
	if _pfboost then
		-- 【毒术配方宝箱】随机 3 个毒药配方，把书匣里对应毒术书的研读经验提到需求等级。
		--   ★ 2026-10-05 老板要求上架。配方不落盘（PoisonFormula.userPoisonFormula 是内存表，
		--     每次进主界面 init 按「书匣毒术书研读等级」重推导）⇒ 持久做法 = 提书 exp；
		--     开箱后调 unlockPoisonFormulaByBookLvUp 即时刷新缓存（重登 init 也会保持）。
		local okPF, pfTab = pcall(function()
			return requireWithEncrypt("script.others.poisonformula")
		end)
		if not okPF or type(pfTab) ~= "table" or type(pfTab.peifang) ~= "table" then
			PopText("配方表读取失败，稍后再试")
			return
		end
		local BookLiterary = require("app.models.book.BookLiterary")
		local literaryBox = self:getAttr("literaryBox")
		if MapIsEmpty(literaryBox) then
			PopText("你的书匣里还没有毒术书籍，先把《百毒谱》等放入书匣再来")
			return
		end
		local pool = {}
		for _, pf in pairs(pfTab.peifang) do
			if type(pf) == "table" and pf.type == 0 and pf.belong and pf.level and pf.id then
				for _, book in ipairs(literaryBox) do
					local attr = self:getOneItemByKey(book.itemId)
					if attr and attr.type == "毒术书籍" and attr.id == pf.belong then
						pool[#pool + 1] = pf
						break
					end
				end
			end
		end
		if #pool == 0 then
			PopText("书匣里的毒术书籍没有可参悟的配方")
			return
		end
		local picked, used = {}, {}
		local n = math.min(3, #pool)
		while #picked < n do
			local cand = pool[math.random(1, #pool)]
			if not used[cand.id] then
				used[cand.id] = true
				picked[#picked + 1] = cand
			end
		end
		local PoisonFormula = require("app.models.Poison.PoisonFormula")
		local names = {}
		for _, pf in ipairs(picked) do
			local needExp = BookLiterary:getExp(tonumber(pf.level) or 1)
			for _, book in ipairs(literaryBox) do
				local attr = self:getOneItemByKey(book.itemId)
				if attr and attr.type == "毒术书籍" and attr.id == pf.belong then
					local oldLv = BookLiterary:getLv(tonumber(book.exp) or 0)
					if (tonumber(book.exp) or 0) < needExp then
						book.exp = needExp
					end
					local newLv = BookLiterary:getLv(tonumber(book.exp) or 0)
					pcall(function()
						PoisonFormula:unlockPoisonFormulaByBookLvUp(oldLv, newLv, pf.belong)
					end)
					break
				end
			end
			names[#names + 1] = tostring(pf.name)
		end
		PopText("毒术配方宝箱：你参悟了 " .. table.concat(names, "、") .. " 的炼制之法！")
		return
	end
	local _herbpack = string.match(name, "^testPoisonHerbPack$")
	if _herbpack then
		-- 【百毒药材包】从 59 种制药材料里随机 10 种、每种 ×10。
		--   ★ 这些物品 type=制药材料 ⇒ addItemCount 原生路由进药囊（Role_Item:429），
		--     无需手动塞 medicinalBox。
		local POOL = {
			"duyaoyc001", "duyaoyc002", "duyaoyc003", "duyaoyc004", "duyaoyc005",
			"duyaoyc006", "duyaoyc007", "duyaoyc008", "duyaoyc009", "duyaoyc010",
			"duyaoyc011", "duyaoyc012", "duyaoyc013", "duyaoyc014", "duyaoyc015",
			"duyaoyc016", "duyaoyc017", "duyaoyc018", "duyaoyc019", "duyaoyc020",
			"duyaoyc021", "duyaoyc022", "duyaoyc023", "duyaoyc024", "duyaoyc025",
			"duyaoyc026", "duyaoyc027", "duyaoyc028", "duyaoyc029", "duyaoyc030",
			"duyaoyc031", "duyaoyc032", "duyaoyc033", "duyaoyc034", "duyaoyc035",
			"duyaoyc036", "duyaoyc037", "duyaoyc038", "duyaoyc039", "duyaoyc040",
			"duyaoyc041", "duyaoyc042", "duyaoyc043", "duyaoyc044", "duyaoyc045",
			"duyaoyc046", "duyaoyc047", "duyaoyc048", "duyaoyc049", "duyaoyc050",
			"duyaoyc051", "duyaoyc052", "duyaoyc053", "duyaoyc054", "duyaoyc055",
			"duyaoyc056", "duyaoyc057", "duyaoyc058", "duyaoyc059",
		}
		local Items = requireWithEncrypt("script.map.mapItemAttr")["Items"]
		local picked, used = {}, {}
		while #picked < 10 do
			local cand = POOL[math.random(1, #POOL)]
			if not used[cand] then
				used[cand] = true
				picked[#picked + 1] = cand
			end
		end
		local names = {}
		for _, iid in ipairs(picked) do
			pcall(function() self:addItemCount(iid, 10) end)
			local nm = iid
			local it = type(Items) == "table" and Items[iid]
			if type(it) == "table" and it.name then nm = it.name end
			names[#names + 1] = tostring(nm)
		end
		MessageCenter:notify("itemChangeEvent", { role = self })
		PopText("百毒药材包：获得 " .. table.concat(names, "、") .. " 各×10（都已放进药囊）")
		return
	end
	local _sid = string.match(name, "^testBooks_(.+)$")
	if _sid then
		-- 【测试】单个武学的书页包：只发这一门武学的书页 ×5（不再一次发全表 ⇒ 不卡）
		local Items = requireWithEncrypt("script.map.mapItemAttr")["Items"]
		if self.shuxiang == nil then self.shuxiang = {} end
		local n, nm = 0, _sid
		for k, v in pairs(Items) do
			if type(k) == "string" and v and (v.type == "书页" or v.type == "武学秘宝") and v.skillid == _sid then
				_fzPut(self.shuxiang, self, k, 5)
				if nm == _sid and v.name then nm = v.name end
				n = n + 1
			end
		end
		MessageCenter:notify("itemChangeEvent", { role = self })
		PopText("书页已发放：" .. nm .. " 等 " .. n .. " 种 ×5（都在书箱里）")
		return
	end
	local _lsid = string.match(name, "^testLearnSkill_(.+)$")
	if _lsid then
		-- 【传功丹】学会指定一门武学：等级拉满 + 该武学的主动技能全部学会/拉满 + 自动进槽。
		--   ★ v50 武学改造标准测试通路（照抄 testAllSkillAndZhaoMax 的三段写法，
		--     但只作用于一门，以后每门新武学配一个 testLearnSkill_<武学id> 就能测）。
		local SkillHelper = require("app.models.skill.SkillHelper")
		pcall(function() SkillHelper:setSkillLv(self, _lsid, 600) end)
		local nz, np, nslot = 0, {}, 0
		local okA, azTab = pcall(function()
			return requireWithEncrypt("script.skill.activeZhao")
		end)
		if okA and type(azTab) == "table" then
			-- ★ v52：归属一律用官方索引 skillRelation（含 learnMethod=1 残页类，如独孤九剑·破招）
			local rel = (type(azTab.skillRelation) == "table") and azTab.skillRelation or {}
			if self.activeZhaos == nil then self.activeZhaos = {} end
			for zid, cfg in pairs(rel) do
				if type(zid) == "string" and type(cfg) == "table" and cfg.skillId == _lsid then
					self.activeZhaos[zid] = { id = zid, exp = 999999999 }
					pcall(function() self:addSkillZhaoExp(zid, 999999999) end)
					nz = nz + 1
					np[#np + 1] = zid
				end
			end
			local function inSlot(zid)
				local g = self:getAttr("preparedActiveZhao") or {}
				for _, grp in pairs(g) do
					if type(grp) == "table" then
						for _, v in pairs(grp) do
							if v == zid then return true end
						end
					end
				end
				return false
			end
			table.sort(np)
			local nextSlot = { bingqi = 6, quanjiao = 6 }
			for _, zid in ipairs(np) do
				for _, grp in ipairs({ "bingqi", "quanjiao" }) do
					if nextSlot[grp] >= 1 then
						self:prepareSkillZhao(grp, nextSlot[grp], zid, self:getCurrTypeByWeapon())
						if inSlot(zid) then
							nextSlot[grp] = nextSlot[grp] - 1
							nslot = nslot + 1
							break
						end
					end
				end
			end
		end
		MessageCenter:notify("AttrChangeAfterEvent", { role = self, attrName = "skills" })
		PopText("传功完成：" .. _lsid .. " 已学会并拉满；主动技能 " .. nz .. " 个，自动进槽 " .. nslot .. " 个")
		return
	end
	if name == "testBaseSkillMax1000" then
		-- ★ 2026-10-17 v35（客户要求）：基础武学一键 1000 级。
		--   默认突破档 100001 的 Blevel 就是 1000（官方原生），setSkillLv 的 clamp 正好。
		local SkillHelper = require("app.models.skill.SkillHelper")
		local ids = { "jibenquanjiao", "jibenjianfa", "jibendaofa", "jibenneigong",
		              "jibenqinggong", "jibenzhaojia", "jibenanqi", "jibenbianfa",
		              "jibengunfa", "jibenduji", "jibenqinfa", "jibenshuangchi" }
		local n = 0
		for _, sid in ipairs(ids) do
			SkillHelper:setSkillLv(self, sid, 1000)
			n = n + 1
		end
		PopText("基础武学已设为 1000 级（" .. n .. " 门）")
		return
	end
	if name == "testBaseSkillMax1500" then
		-- ★ 2026-10-17 v35（客户要求）：基础武学一键 1500 级。
		--   官方突破表最高 100011（class=11，Blevel=1100）⇒ 先把突破阶段拉满（面板"已满"），
		--   再按公式直写 1500 级经验（等级→经验是公式 0.015×lv³+1，写入底层不 clamp）。
		local SkillHelper = require("app.models.skill.SkillHelper")
		local BreakRes = require("app.models.skill.skillBreakThrough.SkillBreakThroughResManager")
		local ids = { "jibenquanjiao", "jibenjianfa", "jibendaofa", "jibenneigong",
		              "jibenqinggong", "jibenzhaojia", "jibenanqi", "jibenbianfa",
		              "jibengunfa", "jibenduji", "jibenqinfa", "jibenshuangchi" }
		local maxBreId = BreakRes:getSkillBreakThroughMapByLevel(11).id
		local n = 0
		for _, sid in ipairs(ids) do
			self:setSkillBreId(sid, maxBreId)
			SkillHelper:setRoleSkill(self, sid, { id = sid, exp = SkillHelper:getExp(sid, 1500) })
			n = n + 1
		end
		PopText("基础武学已设为 1500 级（" .. n .. " 门）")
		return
	end
	if name == "testBaseSkillMax" then
		local SkillHelper = require("app.models.skill.SkillHelper")
		local ids = { "jibenquanjiao", "jibenjianfa", "jibendaofa", "jibenneigong",
		              "jibenqinggong", "jibenzhaojia", "jibenanqi", "jibenbianfa",
		              "jibengunfa", "jibenduji", "jibenqinfa", "jibenshuangchi" }
		local n = 0
		for _, sid in ipairs(ids) do
			SkillHelper:setSkillLv(self, sid, 500)
			n = n + 1
		end
		PopText("基础武学已设为 500 级（" .. n .. " 门）")
		return
	end
	if name == "testAllBookAndCanye" then
		-- ★★ 2026-09-29 修（两次）：
		--   ① 不能逐个 `role:addItemCount`：它内部每次都 `MessageCenter:notify` +
		--      `Record:addLog` ⇒ 背包界面被重建 1461 次 ⇒ 卡死。
		--      书页进 `self.shuxiang`、残页进 `self.zhaoShuXiang`（都是数组，
		--      元素形如 `{id=onlyId, count=n, itemId=xxx}`），直接按 itemId 累加/追加，
		--      最后**只通知一次**。
		--   ② 老板反馈"一次给太多" ⇒ 改成**每次随机给 10 种**（页面/残页同一奖池随机，
		--      尽量不重复），可重复购买慢慢集齐。
		local tab = requireWithEncrypt("script.map.mapItemAttr")["Items"]
		if self.shuxiang == nil then self.shuxiang = {} end
		if self.zhaoShuXiang == nil then self.zhaoShuXiang = {} end
		local pool = {}
		for k, v in pairs(tab) do
			local ty = v and v.type
			if ty == "书页" or ty == "武学秘宝" then
				pool[#pool + 1] = { id = k, book = true }
			elseif ty == "秘籍残页" then
				pool[#pool + 1] = { id = k, book = false }
			end
		end
		local total = #pool
		if total == 0 then
			PopText("没有找到书页/残页数据")
			return
		end
		local function put(arr, itemId)
			for i = 1, #arr do
				if arr[i] and arr[i].itemId == itemId then
					arr[i].count = (arr[i].count or 0) + 1
					return
				end
			end
			arr[#arr + 1] = self:createSafeItem(
				{ id = self:getItemOnlyId(), count = 1, itemId = itemId })
		end
		local WANT = 10
		local picked, seen, np, nc = 0, {}, 0, 0
		for _try = 1, WANT * 30 do
			if picked >= WANT or picked >= total then
				break
			end
			local e = pool[math.random(1, total)]
			if not seen[e.id] then
				seen[e.id] = true
				picked = picked + 1
				if e.book then
					put(self.shuxiang, e.id)
					np = np + 1
				else
					put(self.zhaoShuXiang, e.id)
					nc = nc + 1
				end
			end
		end
		MessageCenter:notify("itemChangeEvent", { role = self })
		PopText("随机发放：书页 " .. np .. " 种、残页 " .. nc .. " 种（奖池 " .. total .. " 种）")
		return
	end
	if name == "testRandomMask3" then
		-- 全表扫一遍所有 type=面具 的物品当奖池，然后随机发 3 张（尽量不重复）
		local res = requireWithEncrypt("script.map.mapItemAttr")
		local pool = {}
		for _, tab in pairs(res) do
			if type(tab) == "table" then
				for _, v in pairs(tab) do
					if type(v) == "table" and v.type == "面具" and v.id then
						pool[#pool + 1] = v.id
					end
				end
			end
		end
		if #pool == 0 then
			PopText("没有找到面具数据")
			return
		end
		local got, names, pick = {}, {}, 0
		for _try = 1, 30 do
			if pick >= 3 or pick >= #pool then
				break
			end
			local id = pool[math.random(1, #pool)]
			if not got[id] then
				got[id] = true
				pick = pick + 1
				self:addItemCount(id, 1)
				local attr = self:getOneItemByKey(id)
				local nm = (attr and attr.name) or id
				nm = string.gsub(nm, "%u%u%u", "")
				names[#names + 1] = nm
			end
		end
		PopText("获得面具：" .. table.concat(names, "、"))
		return
	end
	if name == "testXiantianRandom10" then
		-- 【测试】先天属性丹：随机一项"先天属性" +10（臂力/悟性/根骨/身法）
		--   ★ 不能直接 role:addAttr("str", 10)：
		--     Role_Attr:addAttr 开头就有闸门——name 属于 NaturalAttrAdjustmentConst.ATTR_TYPE
		--     （正好是 str/int/con/dex）且角色是玩家时，直接 return（先天四维不许用 addAttr 改）。
		--     所以要改先天属性，必须走官方 setter Role_Attr:setNaturalAttr（内部 setAttr）。
		local stats = { "str", "int", "con", "dex" }
		local label = { str = "臂力", int = "悟性", con = "根骨", dex = "身法" }
		local pick = stats[math.random(1, #stats)]
		local cur = tonumber(self:getAttr(pick)) or 0
		self:setNaturalAttr(pick, cur + 10)
		local now = tonumber(self:getAttr(pick)) or (cur + 10)
		MessageCenter:notify("AttrChangeAfterEvent", { role = self, attrName = pick })
		PopText("服下先天属性丹：先天" .. label[pick] .. " +" .. (now - cur) ..
			"（" .. cur .. " → " .. now .. "）")
		return
	end
	if name == "testAllBooks" then
		-- 【测试】全武学书页包：把**全部** 书页/武学秘宝 各发 5 个（进书箱，不占背包）
		--   老板 2026-09-30 反馈：神功商店的武学宝箱只给武学书页、而且商店里的武学不全
		--   （长生诀、一刀流这些都没有）⇒ 干脆一次把全部书页给他，想要哪门自己学。
		--   （保留 testAllBookAndCanye 的"随机 10 种"，那是慢慢集齐的玩法）
		local tab = requireWithEncrypt("script.map.mapItemAttr")["Items"]
		if self.shuxiang == nil then self.shuxiang = {} end
		local function put(itemId, cnt)
			for i = 1, #self.shuxiang do
				local e = self.shuxiang[i]
				if e and e.itemId == itemId then
					e.count = (e.count or 0) + cnt
					return
				end
			end
			self.shuxiang[#self.shuxiang + 1] = self:createSafeItem(
				{ id = self:getItemOnlyId(), count = cnt, itemId = itemId })
		end
		local n = 0
		for k, v in pairs(tab) do
			local ty = v and v.type
			if type(k) == "string" and (ty == "书页" or ty == "武学秘宝") then
				put(k, 5)
				n = n + 1
			end
		end
		MessageCenter:notify("itemChangeEvent", { role = self })
		PopText("全武学书页已发放：" .. n .. " 种 ×5（都进了书箱，去书箱里学）")
		return
	end
	if name == "testAllCanye" then
		-- 【测试】全主动技能残页包：把**全部** 秘籍残页 各发 5 个（进招式书箱）
		--   主动技能的秘籍就是"秘籍残页"，商店的武学宝箱不带它 ⇒ 这里一次给全。
		local tab = requireWithEncrypt("script.map.mapItemAttr")["Items"]
		if self.zhaoShuXiang == nil then self.zhaoShuXiang = {} end
		local function put(itemId, cnt)
			for i = 1, #self.zhaoShuXiang do
				local e = self.zhaoShuXiang[i]
				if e and e.itemId == itemId then
					e.count = (e.count or 0) + cnt
					return
				end
			end
			self.zhaoShuXiang[#self.zhaoShuXiang + 1] = self:createSafeItem(
				{ id = self:getItemOnlyId(), count = cnt, itemId = itemId })
		end
		local n = 0
		for k, v in pairs(tab) do
			local ty = v and v.type
			if type(k) == "string" and ty == "秘籍残页" then
				put(k, 5)
				n = n + 1
			end
		end
		MessageCenter:notify("itemChangeEvent", { role = self })
		PopText("全主动技能残页已发放：" .. n .. " 种 ×5（都在招式书箱里）")
		return
	end
	if name == "testAllSkillAndZhaoMax" then
		-- 【测试】武学与主动技能满级包：
		--   ① 已经学会的**所有武学**设到一个高等级（600 级；实际会被 getSkillLvLimit 卡在上限）
		--   ② 所有**主动技能**（activeZhaos）经验拉满 ⇒ 等级跟着 skill 等级的上限走
		--      （getZhaoLvLimit 是按 skillLv/100 算的，所以必须先提技能再提主动技能）
		local SkillHelper = require("app.models.skill.SkillHelper")
		local skills = self:getAttr("skills") or self.skills or {}
		local ns, nz = 0, 0
		-- ★ 2026-10-01 老板：满级包也要能提**基础技能**（12 门基础武学，没学过的也一并学会并拉满）
		for _, bid in ipairs({ "jibenquanjiao", "jibenjianfa", "jibendaofa", "jibenneigong",
		                       "jibenqinggong", "jibenzhaojia", "jibenanqi", "jibenbianfa",
		                       "jibengunfa", "jibenduji", "jibenqinfa", "jibenshuangchi" }) do
			SkillHelper:setSkillLv(self, bid, 600)
		end
		skills = self:getAttr("skills") or self.skills or {}
		for sid, _v in pairs(skills) do
			if type(sid) == "string" then
				SkillHelper:setSkillLv(self, sid, 600)
				ns = ns + 1
			end
		end
		local zhaos = self:getAttr("activeZhaos") or self.activeZhaos or {}
		for zid, _v in pairs(zhaos) do
			if type(zid) == "string" then
				self:addSkillZhaoExp(zid, 999999999)
				nz = nz + 1
			end
		end
		-- ★ 顺手把"他已学武学自带的主动技能"直接学会（不用再去凑秘籍残页）。
		--   表路径/结构可能有变，整段 pcall 包起来，失败也不影响前两步。
		local ok, azTab = pcall(function()
			return requireWithEncrypt("script.skill.activeZhao")
		end)
		if ok and type(azTab) == "table" then
			-- ★ v52 修复（老板 2026-10-02 指出：满级包没解锁"要残页才能掌握"的主动技）：
			--   归属一律用官方索引 azTab.skillRelation（zhaoId → {skillId=..}）——
			--   游戏自己的 Skill:initSkillZhaoRelation 就是读它建 zhao→skill 关系。
			--   旧写法在 ActiveZhao 段里找 skillId/learn_id —— learnMethod=1（残页学习）的招式
			--   （如独孤九剑·破招）两样都没有 ⇒ 永远扫不到，一直解锁不了。
			local rel = (type(azTab.skillRelation) == "table") and azTab.skillRelation or {}
			if self.activeZhaos == nil then self.activeZhaos = {} end
			local forced = 0
			for zid, cfg in pairs(rel) do
				if type(zid) == "string" and type(cfg) == "table" then
					local sid = cfg.skillId
					if type(sid) == "string" and skills[sid] ~= nil then
						-- 老板：不想再攒"秘籍残页" ⇒ 直接**写进 activeZhaos**
						--   （存档结构就是 { <zhaoId> = {id=, exp=} }），再顺手拉满经验。
						if self.activeZhaos[zid] == nil then
							forced = forced + 1
						end
						self.activeZhaos[zid] = { id = zid, exp = 999999999 }
						pcall(function() self:addSkillZhaoExp(zid, 999999999) end)
						nz = nz + 1
					end
				end
			end
			if forced > 0 then
				PopText("已学武学的主动技能直接学会：" .. forced .. " 个（含残页类，不用再攒残页）")
			end
		end
		MessageCenter:notify("AttrChangeAfterEvent", { role = self, attrName = "skills" })
		-- ③ 自动"准备"主动技能：战斗界面只显示 preparedActiveZhao 槽位里的招式，
		--    光学会不显示（老板实测）。
		--    用官方 setter Role_ActiveZhao:prepareSkillZhao(zhaoType, index, zhaoId, methodType)：
		--    它自己会校验"该武学是否已准备"+"武器类型是否匹配"，不合法就静默 return，
		--    所以这里放心调用，只对"真的进槽了"计数。
		local function inSlot(zid)
			local g = self:getAttr("preparedActiveZhao") or {}
			for _, grp in pairs(g) do
				if type(grp) == "table" then
					for _, v in pairs(grp) do
						if v == zid then return true end
					end
				end
			end
			return false
		end
		local fresh = {}
		for zid in pairs(self:getAttr("activeZhaos") or {}) do
			if type(zid) == "string" and not inSlot(zid) then
				fresh[#fresh + 1] = zid
			end
		end
		table.sort(fresh)
		local nextSlot = { bingqi = 6, quanjiao = 6 }   -- 从最后一格往前占
		local np = 0
		for _, zid in ipairs(fresh) do
			for _, grp in ipairs({ "bingqi", "quanjiao" }) do
				if nextSlot[grp] >= 1 then
					self:prepareSkillZhao(grp, nextSlot[grp], zid, self:getCurrTypeByWeapon())
					if inSlot(zid) then
						nextSlot[grp] = nextSlot[grp] - 1
						np = np + 1
						break
					end
				end
			end
		end
		PopText("武学满级：" .. ns .. " 门；主动技能拉满：" .. nz ..
			" 个；自动准备进槽位：" .. np .. " 个（武器不对的会被系统拒绝）")
		return
	end
	-- ★ 2026-10-02 老板报「货币礼包用完元宝不增加」：
	--   元宝/银票这类"钱袋货币"的权威账本在**服务端**（homeland_state.json["currency"]），
	--   商城/状态接口回包里的 data.yuanbao 会 setAttr **硬覆盖**本地值（StoreLayer.lua:107、
	--   YuanBaoPayLayer.lua:10、fz_boot_server.get_yuanbao…），光在客户端 addAttr 等于没加。
	--   这里把**服务端钱袋管辖的币种**的正向 addAttr 镜像给服务端
	--   （update_currency_by_type，格式 {action,currency={币种=数}}，服务端 homeland_life 认）。
	--   不 return —— 原生本地加值照常走（弹字/本地显示不受影响）。
	--   money 刻意**不**镜像：她原生代码里 addAttr("money") 是任务/比武/卖东西的常规入账，
	--   其中一部分结算服务端已经入过账，镜像会双份加钱。
	if var ~= nil and var > 0 and self.id == "wanjia" then
		local _purseKinds = {
			yuanbao = true, yinpiao = true,
			amartial = true, bmartial = true, cmartial = true, dmartial = true,
			canyechoice = true, gongxiandian = true,
			-- ★ 2026-10-03 货币礼包补活动代币（服务端 _route_activity_token 路由）：
			--   香囊钥匙 / 鞭炮(年兽) / 佳酿=白堕(醉仙楼) / 好运通宝(江湖好运来) / 冥币(地府)
			sachet_key = true, nian_bianpao = true, baiduo = true,
			lucky_coin = true, mingbi = true,
		}
		if _purseKinds[name] then
			pcall(function()
				local HM = HttpManagerEx
				if HM == nil then
					HM = require("app.extends.Http.HttpManager")
				end
				HM:updateCurrencyByTable("add", { [name] = var }, "fzPack",
					function() end, false)
			end)
		end
	end
	-- =================================================================================
	if table.keyof(NaturalAttrAdjustmentConst.ATTR_TYPE, name) and self.id == "wanjia" then
		return 
	end
	return self:callModuleFunc("addAttr", name, var)
end

-- @author TangJian
-- @time 2017/04/26 01:01:33
-- @desc 得到加成后的属性
function Role_Attr:getFinalAttr(name)
	return self:callModuleFunc("getFinalAttr", name)
end


function Role_Attr:addBuffV2(buffId)
	local id = tonumber(buffId)
	assert(id,"-----Role_Attr:addBuffV2----- buffId不是数字"..buffId)
	return self:callModuleFunc("addBuff",id)
end

function Role_Attr:removeBuffV2(buffId)
	local id = tonumber(buffId)
	assert(id,"-----Role_Attr:removeBuffV2----- buffId不是数字"..buffId)
	return self:callModuleFunc("removeBuff",id)
end

-- 获得加成的属性
function Role_Attr:getBuffAttr(name)
	local value = 0

	if self._roleBuff then
		value = self._roleBuff:getAttr(name)
	end

	return value
end

-- 基本属性
function Role_Attr:getName()
	return Helper:getDef(self.name, "o(=•ェ•=)m")
end

function Role_Attr:getExp()
	local lv = self.lv
	local exp = (0.1 * (lv+4) ^ 3+1)
	if exp < self:getAttr("exp") then
		return self:getAttr("exp")
	end
	return math.floor(exp)
end

function Role_Attr:getLv()
	local exp = self.exp
	if exp == 0 then
		return 1
	end
	local lv = math.floor(((exp-1) / 0.1) ^ (1 / 3)-4)
    return Helper:getRange(lv, 1)
end

-- 获取加力最大值
function Role_Attr:getJiaLiMax()
	local neigongLv, skillLv = self:getSkillLv("jibenneigong"), self:getSkillLv(self:getPrepareSkill("neigong"))
	if not neigongLv or not skillLv then
		return 0
	end
	return math.floor((neigongLv * 0.5 + skillLv) * 0.5)
end

-- 获得武功评价
function Role_Attr:getKongfuDsc()
	local kongfuValue = self:getKongfu()
	local kongfuDsc = SkillResManager:getKongFuDescMap()
	if not kongfuDsc then
		return "看不出武功强弱"
	end
	for i = #kongfuDsc, 1, -1 do
		local dsc = kongfuDsc[i]
		if kongfuValue >= dsc.value then
			return dsc.dsc
		end
	end
	return "看不出武功强弱"
end

function Role_Attr:getKongfuDesc(kongfu)
	local str = "看不出武功强弱"
	if not kongfu then
		return str
	end
	local kongfuDsc = SkillResManager:getKongFuDescMap()
	for i = #kongfuDsc, 1, -1 do
		local dsc = kongfuDsc[i]
		if kongfu >= dsc.value then
			return dsc.dsc
		end
	end
	return str
end

-- 获得武功
function Role_Attr:getKongfu()
	local realWugong = self:getRealWugong()
	local realNeigong = self:getRealNeigong()
	local realQinggong = self:getRealQinggong()
	local realZhaojia = self:getRealZhaojia()
	local currLv = self:getLv()
	local kongfu = (realNeigong + realQinggong + realWugong + realZhaojia + 3 * currLv) / 9
	if DEBUG_MODE == 1 then
		print("realWugong = ",realWugong)
		print("realNeigong = ",realNeigong)
		print("realQinggong = ",realQinggong)
		print("realZhaojia = ",realZhaojia)
		print("currLv = ",currLv)
		print("武功值 = ",kongfu)
	end
	self:setAttr("kongfu", kongfu)
	return kongfu
end

-- 气血状态描述
function Role_Attr:getQiDsc()
	local currQiPercent = (self.qi / self:getCurrQiMax()) * 100
	currQiPercent = math.floor(currQiPercent)
	if PRINT_MODE == 1 then
		print("currQiPercent = "..tostring(currQiPercent))
	end

	-- add by LvBin 2018/02/02 11:45:26 易容术改变气血状态描述
	if self:checkRoleIsPolymorph() then
		currQiPercent = self.polymorph.qi
	end

	for i = #qiDsc, 1, -1 do
		local dsc = qiDsc[i]		
		if currQiPercent >= dsc.qi then
			return dsc.dsc
		end
		
	end
	return qiDsc[1].dsc
end

-- 战斗时气血状况描述
function Role_Attr:getFightQiDesc()
	local currQiPercent = (self.qi / self.qiMax) * 100
	currQiPercent = math.floor(currQiPercent)

	if PRINT_MODE == 1 then
		print("currQiPercent = "..tostring(currQiPercent))
	end

	for i = #fightQiDesc, 1, -1 do
		local dsc = fightQiDesc[i]
		if currQiPercent >= dsc.qi then
			return dsc.dsc
		end
	end
	return "HIR$n体力耗尽，倒在了地上。"
end

-- 加力描述
function Role_Attr:getJialiDsc()
	local desc = "HIG很微妙"
	local percent = math.ceil(Helper:getDef(self.jiaLi, 0) / self:getJiaLiMax() * 100)
	if not percent then
		return "HIG极轻"
	end
	if percent == 0 then
		desc = "HIG极轻"
	elseif 0 < percent and percent <= 20 then
		desc = "HIG很轻"
	elseif 20 < percent and percent <= 40 then
		desc = "HIG不轻"
	elseif 40 < percent and percent <= 60 then
		desc = "HIG不重"
	elseif 60 < percent and percent <= 80 then
		desc = "HIG很重"
	elseif 80 < percent and percent <= 100 then
		desc = "HIG极重"
	else
		desc = "HIG很微妙"
	end
	return desc
end

-- 年龄描述
function Role_Attr:getAgeDsc()
	local currAge = tonumber(self.age)

	-- add by LvBin 2018/02/02 11:30:26 易容术改变年龄描述
	if self:checkRoleIsPolymorph() then
		currAge = self.polymorph.age
	end

	for i = #ageDsc, 1, -1 do
		local dsc = ageDsc[i]				
		if currAge >= dsc.age then
			return dsc.dsc
		end
				
	end
	return "看不出年龄"
end

-- 得到外貌描述
function Role_Attr:getFaceDsc()
	return self:getRoleFaceDsc(self.sex, self:getFinalAttr("looks"), self.equips, self.portrait)
end

-- 根据装备获取外貌描述
function Role_Attr:getRoleFaceDsc(sex, looks, equips, portrait)
	looks = Helper:getDef(looks, 0)
	sex = Helper:getDef(sex, "男")
	equips = Helper:getDef(equips, {})

	if self:checkRoleIsPolymorph() then  --易容改貌
		sex = self.polymorph.sex
		looks = self.polymorph.pLooks
	end
	local desc

	local headItemId = nil
	if type(equips) == "table" then
		if type(equips.head) == "table" then
			headItemId = equips.head.itemId
		end
	end

	-- 面具描述特殊处理
	if headItemId then
		local item = self:getOneItemByKey(headItemId)
		if item ~= nil and item.gradeId then
			local headAttr = self:getMaskSystem():getMaskAttrByMaskIdAndLv(item.gradeId,1)
			if headAttr and headAttr:getMaskDesc() then
				desc = headAttr:getMaskDesc()
			end
		end
		if desc ~= nil then
			return desc
		else
			-- 继续往下走
		end
	end

	-- 头像ID
	if portrait and portrait ~= "" then
		if type(portrait) == "string" then
			portrait = {id = portrait,lv = 1}
		end
		local item = self:getOneItemByKey(portrait.id)
		if item ~= nil and item.gradeId then
			local headAttr = self:getMaskSystem():getMaskAttrByMaskIdAndLv(item.gradeId,portrait.lv)
			if headAttr and headAttr:getMaskDesc() then
				desc = headAttr:getMaskDesc()
			end
		end
		if desc ~= nil then
			return desc
		else
			-- 继续往下走
		end
	end

	local dscs
	if sex == "男" or sex == "male" then
		dscs = looksDsc.male
	elseif sex == "女" or sex == "female" then
		dscs = looksDsc.female
	end

	for i = #dscs, 1, -1 do
		local dsc = dscs[i]
		if dsc and dsc.looks and looks >= dsc.looks then
			return dsc.dsc
		end
	end
	return "看不出长相"
end

--获取江湖容貌描述
function Role_Attr:getJiangHuFaceDsc(sex,looks)
	local dscs
	if sex == "男" or sex == "male" then
		dscs = looksDsc.male
	elseif sex == "女" or sex == "female" then
		dscs = looksDsc.female
	end

	for i = #dscs, 1, -1 do
		local dsc = dscs[i]
		if dsc and dsc.looks and looks >= dsc.looks then
			return dsc.dsc
		end
	end
	return "看不出长相"
end

-- 完整描述获得
-- add by XiaoZhiWei 2017/03/31 11:11:26 增加几个参数,应对策划描述需求调整
--[[
	isNeedAgeDesc  是否需要年龄描述 默认值 true
	isNeedLookDesc 是否需要长相描述 默认值 true
]]
function Role_Attr:getDsc(role, isNeedAgeDesc, isNeedLookDesc , isNeedQiDesc)
	return self:callModuleFunc("getDsc", role, isNeedAgeDesc, isNeedLookDesc , isNeedQiDesc)
end

-- 传承描述获得
function Role_Attr:getInheritDsc()
	local desc = ""
	local cl = "WHT"
	local sex = "他"
	if self.sex == "女" then
		sex = "她"
	elseif self.sex == "野兽" then
		return (self.dsc == nil and "" or tostring(self.dsc))
	end

	local dsc = ""
	if self.dsc then
		dsc = self.dsc
	end

	desc = desc .. cl .. sex .. "曾经看起来约" .. self:getAgeDsc()

	if self:getFaceDsc() ~= nil then
		desc = desc .. "，" .. sex .. cl .. "生得" .. self:getRoleFaceDsc(self.sex, self.looks, nil) .. cl .. "。$N"
	end

	desc = desc .. cl .. sex .. "的武功看来" .. self:getKongfuDsc() .. cl .. "，出手似乎" .. self:getJialiDsc() .. cl .. "。$N"

	desc = desc .. cl .. sex .. "看起来" .. self:getQiDsc() .. "。$N"

	return desc
end

-- 获得他或她
function Role_Attr:getHeOrHer(sex)
	if sex == nil then
		sex = self.sex
	end
	if sex == "男" then
		return "他"
	elseif sex == "女" then
		return "她"
	end
	return ""
end

-- 获得对方与你的关系
function Role_Attr:getRelation(role)
	if self:hasFamily() and role:hasFamily() and self:getFamilyId() == role:getFamilyId() then
		-- add by XiaoZhiWei 2017/03/06 15:02:57 官府称谓特殊处理
		local lvGap = -(role:getFamilyLevel() - self:getFamilyLevel())
		if self:getFamilyId() == "guanfu" then
			if lvGap == 0 then
				return "同僚"
			elseif lvGap <= -1 then
				return "下属"
			else
				return "上司"
			end
		end

		if lvGap == 0 then
			if role:getAttr("sex") == "男" then
				return "师兄"
			else
				return "师姐"
			end
		elseif lvGap == 1 then
			if self.teacherId == role:getAttr("id") then
				return "师父"
			end
			return "师叔"
		elseif lvGap == 2 then
			return "师叔公"
		elseif lvGap == 3 then
			return "师叔祖"
		elseif lvGap == 4 then
			return "太师叔祖"
		elseif lvGap == -1 then
			return "师侄"
		elseif lvGap <= -2 then
			return "徒孙"
		end
	else
		return nil
	end
end

--查看玩家资料
function Role_Attr:getRoleInfoDsc(role)
	local desc = ""
	local cl = "WHT"
	local sex = "他"
	if self.sex == "女" then
		sex = "她"
	elseif self.sex == "野兽" then
		return (self.dsc == nil and "" or tostring(self.dsc))
	end

	if self:checkRoleIsPolymorph() then  --易容改貌
		if self.polymorph.sex == "女" then
			sex = "她"
		else
			sex = "他"
		end
	end

	desc = desc .. cl .. sex .."是"

	--头衔
	local touxian = self:getTouXian()
	desc = desc .. touxian

	--名字
	desc = desc .. self:getName() .. "。\n"

	--传承
	-- if self.chuancheng ~= nil then
	-- 	desc = desc .. cl .. self.chuancheng .. "。\n"
	-- end

	--称号
	desc = desc .. "江湖人称 " .. self:getChengHaoColorName() .. cl .. "。\n"

	--时间
	if self.yueKaValid == "Y" then
		desc = desc .. "于公元" .. Helper:numberCast(Helper:date("%y", self.yuekaTime)) .. "年" .. Helper:numberCast(Helper:date("%m", self.yuekaTime)).. "月".. "加入江湖名士大会" .. cl .. "。\n"
	end

	desc = desc .. "\n"

	desc = desc..cl..sex.."看起来约"..self:getAgeDsc()

	if self:getFaceDsc() ~= nil then
		desc = desc.."，"..sex..cl.."生得"..self:getFaceDsc()..cl.."。\n"
	end

	desc = desc..cl..sex.."的武功看来"..self:getKongfuDsc()..cl.."，出手似乎"..self:getJialiDsc()..cl.."。\n"

	--desc = desc..cl..sex.."看起来"..self:getQiDsc().."。\n\n"

	-- add by XiaoZhiWei 2017/05/16 10:24:16 传承相关描述
	for i,v in ipairs(self.inheritHistory) do
		if i == #self.inheritHistory then
			-- 判断是否有改名
			if v.inheritName ~= self.name then
				v.inheritName = self.name
			end
		end
		desc = desc .. cl .. "公元" .. Helper:numberCast(Helper:date("%y", v.inheritTime)) .. "年" .. Helper:numberCast(Helper:date("%m", v.inheritTime)).. "月" .. Helper:numberCast(Helper:date("%d", v.inheritTime)).. "日" .. " " .. v.parentName .. "将衣钵传与" .. v.inheritName .. "，遂隐退于" .. Map:getDefaultMapById(Map:getMapIdByIndex(v.retireMap)).name .."。\n"
	end

	--武器
	desc = desc.."WHT"..sex.."身上装备着：\n"
	local weapoonName = self:getCurrWeaponName()
	local weapon = self:getEquipByName("weapon")
	if weapon ~= nil then
		if weapon.wpType == "神兵" then
			local itemAttr = self:getOneItemByKey(weapon.itemId)
			weapoonName = itemAttr.colorname .. weapoonName
			desc = desc .. "	□" .. weapoonName .. cl .. "\n"
		elseif weapon then
			desc = desc .. cl .. "	□" .. weapoonName .. cl .. "\n"
		end
	end
	
	local equipsTab =
	{
		[1] = "head",		-- 头帽
		[2] = "cloth",		-- 上装
		[3] = "pants",		-- 下装
		[4] = "belt",		-- 腰带
		[5] = "yaozhui",	-- 腰坠
		[6] = "shoes",		-- 鞋子
		[7] = "necklace",	-- 项链
		[8] = "hand",		-- 手部
		[9] = "ring",		-- 戒指
	}

	for i,v in ipairs(equipsTab) do
		local equip = self:getEquipByName(v)
		if equip and self:getOneItemByKey(equip.itemId) then
			desc = desc .. "	□" .. self:getOneItemByKey(equip.itemId).name .. cl .. "\n"
		end
	end

	--装备外观
	local appearance = self:getAttr("appearance")
	print("装备外观 id  = ",appearance)
	if appearance and appearance ~= "" and appearance ~= "waiguan0"  then
		desc = desc .. "	□" .. self:getOneItemByKey(appearance).name .. cl .. "\n"
	end
	
	return desc
end

-- 称呼
function Role_Attr:getHeCall()
	if self.sex == "男" then
		return "他"
	elseif self.sex == "女" then
		return "她"
	end
	return "它"
end

----- 玩家属性
-- 获取中文 年龄大小
function Role_Attr:getAgeWithChinese()
	local year = self:getAge()

	local str = ""

	str = year.."岁"

	if year == ROLE_AGE_LIMIT then
		return str
	end

	local gamingTime = self:getAttr("gamingTime")

	local month = math.floor(math.mod(gamingTime / 3600/ 24 * 2, 12))

	if month > 0 then
		str = str..month.."月"
	end

	return str
end

-- 获取岁数
function Role_Attr:getAge()
	return self:getNumAttr("age")
end

--年龄计算
function Role_Attr:calculateAge()
	local gamingTime = self:getAttr("gamingTime")
	-- 6天算1年
	local year = math.floor(gamingTime / 3600 / 24 / 12 * 2)
	--初始14岁
	year = 14 + year
	--@desc 限制年龄上限
	if year >= ROLE_AGE_LIMIT then
		year = ROLE_AGE_LIMIT
	end

	self:setAttr("age", year)
end

--获取等效根骨
function Role_Attr:getEffectCon()
	-- if not self.con or type(self.con) ~= "number" then
	-- 	self.con = 0
	-- end
	-- if not self.secCon or type(self.secCon) ~= "number" then
	-- 	self.secCon = 0
	-- end
	-- return tonumber(self.con + (self:getFinalAttr("secCon") * 0.5))
	return self:getFinalAttr("effectCon")
end

-- --获取总悟性
-- function Role_Attr:getTotalInt()
-- 	if not self.int or type(self.int) ~= "number" then
-- 		self.int = 0
-- 	end
-- 	if not self.secInt or type(self.secInt) ~= "number" then
-- 		self.secInt = 0
-- 	end
-- 	-- add by XiaoZhiWei 2017/06/23 10:54:07 修复,先天悟性没有参与计算的bug
-- 	return tonumber(self.int + self:getFinalAttr("secInt"))
-- end

-- 获取等效臂力
function Role_Attr:getEffectStr()
	-- if not self.str or type(self.str) ~= "number" then
	-- 	self.str = 0
	-- end
	-- if not self.secStr or type(self.secStr) ~= "number" then
	-- 	self.secStr = 0
	-- end
	-- return tonumber(self.str + (self:getFinalAttr("secStr") * 0.5))
	return self:getFinalAttr("effectStr")
end

-- 获取等效身法
function Role_Attr:getEffectDex()
	-- if not self.dex or type(self.dex) ~= "number" then
	-- 	self.dex = 0
	-- end
	-- if not self.secDex or type(self.secDex) ~= "number" then
	-- 	self.secDex = 0
	-- end
	-- return tonumber(self.dex + (self:getFinalAttr("secDex") * 0.5))
	return self:getFinalAttr("effectDex")
end

-- 设置精力最大值
function Role_Attr:setJingMax()
	local age = self:getAttr("age")
	local skills = self:getSkills()
	local xfLv = 0
	for k,v in pairs(skills) do
		local skill = Skill:getSkill(k)
		if skill ~= nil then
			if skill.type == SKILL_TYPE_SPECIAL and self:conversionSkillExpAndLv("lv", v.exp) > xfLv then
				xfLv = self:conversionSkillExpAndLv("lv", v.exp)
			end
		else
			print("缺少技能资源  skillId = ",k)
		end
	end
	-- 年龄分段加成精力
	--[[
		14-32 一岁加成24点
		32-50 一岁加成10点
		50-60 一岁加成5点
		60-10000 一岁加成1点
	]]
	local jingMax = 100 + xfLv/2 + Helper:getRange((age-14), 0, 18)*24 + Helper:getRange((age-32), 0, 18)*10 + Helper:getRange((age-50), 0, 10)*5 + Helper:getRange((age-60), 0, 10000)*1
	self:setAttr("jingMax", jingMax)
end

-- 获取精力最大值
function Role_Attr:getJingMax()
	local baseValue = self:getFinalAttr("jingMax") 
	local yueKaAddValue = 0
	local qiXiJingMaxAddValue = 0
	local qiyuCount = 0
	local qiYuCountAddValue = 0
	local xingZhenAddValue = 0

	local jingMax = baseValue
	if self:yueKaIsValid() == true then
		-- 月卡有效 且 当前称号时月卡称号时 精力最大值加100
		jingMax = jingMax + 100
		yueKaAddValue = 100
	end

	-- add by XiaoZhiWei 2017/08/26 13:11:00 七夕精力加成
	do
		qiXiJingMaxAddValue = Helper:getDef(self:getInheritFlag("QiXi_JingMax"), 0)
		jingMax = jingMax + qiXiJingMaxAddValue
	end
	
	--奇遇事件精力上限增加 一次增加100，最大次数13次
	if self.qiyujingCount ~= nil and self.qiyujingCount > 0 then
		jingMax = jingMax + self.qiyujingCount * 100

		qiyuCount = self.qiyujingCount
		qiYuCountAddValue = self.qiyujingCount * 100
	end

	jingMax = jingMax + self:getBuffAttr("xingZhenJingMax")
	
	xingZhenAddValue = self:getBuffAttr("xingZhenJingMax")

	return jingMax, {
		baseValue = baseValue,
		yueKaAddValue = yueKaAddValue,
		qiXiJingMaxAddValue = qiXiJingMaxAddValue,
		qiyuCount = qiyuCount,
		qiYuCountAddValue = qiYuCountAddValue,
		xingZhenAddValue = xingZhenAddValue
	}
end

-- 获取当前气血最大值
function Role_Attr:getCurrQiMax(onlyBaseValue)
	local qiPercent = self:getAttr("qiPercent")
	if not qiPercent or qiPercent > 1 then
		qiPercent = 1
		self:setAttr("qiPercent", 1)
	end

	local qiMax = self:getFinalAttr("qiMax")

	return qiMax * qiPercent
end


-------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------战斗相关公式计算
-- 玩家攻击力 onlyBaseValue 只获取基础的数值
function Role_Attr:getAtk(onlyBaseValue)
	if onlyBaseValue == true then
		return self:getBaseAttr("atk")
	end

	return self:getFinalAttr("atk")
end

-- 玩家加力攻击力
function Role_Attr:getJiaLiAtk()
	local cType = self:getCurrTypeByWeapon()
	if cType == "quanjiao" then
		-- 暂用拳脚1做计算
		cType = "quanjiao1"
	end
	local skillLv, factor = self:getSkillLvAndFactor(cType, "powerAtkRate")
	local jiaLi = self:getFinalAttr("jiaLi")
	if self.neili < jiaLi then
		return 0
	end
	return jiaLi*factor*(1+skillLv/500)*(0.49 + 0.001 *self:getEffectStr())
end

-- 玩家躲闪力 onlyBaseValue 只获取基础的数值
function Role_Attr:getDodge(onlyBaseValue)
	if self.dodgeScaleFactor ~= nil then
		if type( self.dodgeScaleFactor ) ~= "number" or self.dodgeScaleFactor < 0 or self.dodgeScaleFactor > 100 then
			self.dodgeScaleFactor = 1.0
		end

		return self.dodgeScaleFactor * self:getBaseAttr("dodge")
	end

	if onlyBaseValue == true then
		return self:getBaseAttr("dodge")
	end

	return self:getFinalAttr("dodge")
end

-- 玩家防御力 onlyBaseValue 只获取基础的数值
function Role_Attr:getDef(onlyBaseValue)
	if onlyBaseValue == true then
		return self:getBaseAttr("def")
	end

	return self:getFinalAttr("def")
end

-- 玩家伤害力 (加力伤害) onlyBaseValue 只获取基础的数值
-- fightRole 战斗人物
function Role_Attr:getPowerDamage(onlyBaseValue,fightRole)

	if onlyBaseValue == true then
		return self:getBaseAttr("damage")
	end

	local value = self:getFinalAttr("damage")

	-- -- fightRole 没有用到
	-- local weapon = self:getEquipByName("weapon")
	-- local item
	-- if weapon and weapon.itemId then
	-- 	item = self:getOneItemByKey(weapon.itemId)
	-- end
	-- local wpAtk = 0
	-- if item and item.damage then
	-- 	wpAtk = item:getWeaponDamage(self,nil,fightRole)
	-- end

	return value 
end

-- 玩家命中率
function Role_Attr:getHitRate(onlyBaseValue)
	local cType = self:getCurrTypeByWeapon()
	if cType == "quanjiao" then
		-- 暂用拳脚1做计算
		cType = "quanjiao1"
	end
	local skillLv, factor = self:getSkillLvAndFactor(cType, "hitRate")
	-- print(self:getName())
	-- print("Role_Attr:getHitRate() -> ")
	-- print(cType)
	-- print(skillLv)
	-- print(factor)
	-- print(self:getExp())
	-- print(self:getEffectStr())
	local baseValue = (skillLv*15*factor/100+1000+0.5*self:getExp()^0.5)*(1+self:getEffectStr()*0.02)
	if onlyBaseValue then
		return baseValue
	end

	--神兵特性
	local addHit = 0
	local equipWeapon = self:getEquipByName("weapon")
	if equipWeapon ~= nil and equipWeapon ~="拳脚" then
		local weapen = self:getOneItemByKey(equipWeapon.itemId)
		if weapen ~= nil then
			addHit = Helper:getDef(ShenBingEffct:getWeaponExtraHit(weapen,self),0)
		end
		if DEBUG_MODE == 1 then
			print("------------------------兵器特性提升命中----------------------------------",addHit)
		end
	end

	local fistFootAddHit = 0
	if equipWeapon == nil or equipWeapon == "拳脚" then
		local FightRoleFistFootEffect = require("src.app.models.fight.FightRoleFistFootEffect")
		fistFootAddHit = FightRoleFistFootEffect:getHitBuffsValue(self)
	end

	return baseValue + addHit + fistFootAddHit
end

-- 玩家招架
function Role_Attr:getParry(onlyBaseValue)
	if self.parryScaleFactor ~= nil then
		if type( self.parryScaleFactor ) ~= "number" or self.parryScaleFactor < 0 or self.parryScaleFactor > 100 then
			self.parryScaleFactor = 1.0
		end

		return self.parryScaleFactor * self:getBaseAttr("parry")
	end

	if onlyBaseValue == true then
		return self:getBaseAttr("parry")
	end

	return self:getFinalAttr("parry")
end

-- 玩家防护力 总值 onlyBaseValue 只获取基础的数值
function Role_Attr:getFangHu(onlyBaseValue)
	if onlyBaseValue == true then
		return self:getBaseAttr("protect")
	end

	local value = self:getFinalAttr("protect")

	return value
end

-- 获取命中部位保护力
function Role_Attr:getProtect(partName)
	local FightConfig = require("app.models.fight.FightConfig")

	local equipName = FightConfig:getPartEquipName(partName)

	LogSystem:log("旧版战斗：获取命中部位保护力 部位名称 = ",partName," 装备部位 = ",equipName)

	local equip = self:getEquipByName(equipName)
	if not equip then
		return self:getFangHu()
	end
	local item = self:getOneItemByKey(equip.itemId)
	if not item then
		return self:getFangHu()
	end

	return item:getItemAttr("protect")+ self:getFangHu()
end

-- 获取经脉属性加成
function Role_Attr:getMeridianAttrValue(attr)
	local meridian = self.meridian

	if meridian.attrTotal and meridian.attrTotal[attr] then
		return tonumber(meridian.attrTotal[attr])
	end

	return 0
end

-- 获得经脉等级
function Role_Attr:getMeridianLevel()
	local Meridian = require("app.models.Meridian.Meridian")
	local lv = Meridian:getMeridianLv(self.meridianExp)
	return lv
end

-- 判断是否拥有经脉印记
function Role_Attr:isHaveImprintingId(imprintingId)
	return self:getMeridianSystem():currPageHasMeridianImprinting(imprintingId)
end

--获取人物显示时传承者描述
function Role_Attr:getInheritRoleWebDsc()
	local desc = ""
	if MapIsEmpty(self.inheritHistory)==false then
		for i,v in ipairs(self.inheritHistory) do
			if i == #self.inheritHistory then
				-- 判断是否有改名
				if v.inheritName ~= self.name then
					v.inheritName = self.name
				end
			end
			desc = desc .. "WHT" .. "公元" .. Helper:numberCast(Helper:date("%y", v.inheritTime)) .. "年" .. Helper:numberCast(Helper:date("%m", v.inheritTime)).. "月" .. Helper:numberCast(Helper:date("%d", v.inheritTime)).. "日" .. " " .. v.parentName .. "将衣钵传与" .. v.inheritName .. "，遂隐退于" .. Map:getDefaultMapById(Map:getMapIdByIndex(v.retireMap)).name .."。\n"
		end
	end 
	return desc
end

--疲劳值自然恢复
function Role_Attr:spontaneousRecoveryPiJuan()
	local lastTime = self:getFlag("疲劳值刷新时间")
	if lastTime == 0 then 
		self:setFlag("疲劳值刷新时间", GetTime() )
		return
	end
	local diffTime = GetTime() - lastTime
	if diffTime >= 600 then --在线/离线，1小时可得6点疲倦值 10分钟一点
		local value = math.floor(diffTime/600)
		self:addAttr("pijuan",value)
		self:setFlag("疲劳值刷新时间", GetTime() )
	end
end

function Role_Attr:getSelfCreatedSkillData()
	return self:getAttr("selfCreatedSkillData")
end

--清除自创武学数据
function Role_Attr:deleteSelfCreatedSkillData()
    return self:getSelfCreatedSkillSystem():deleteSelfCreatedSkillData()
end

--@desc: 玩家当前fdamge (暂定名-武练)值
--@author:Seven
--@time:2022-09-20 18:00:21
function Role_Attr:getFDamage()
	local value = 0

	local prepSkillId = self:getPrepareSkillIdByType("quanjiao")
	
	if prepSkillId ~= nil then
		local prep_skill = Skill:getSkill(prepSkillId)
		if prep_skill then
			local skillTypes = prep_skill:getSkillTypes()
			for _,skill_type_id in ipairs(skillTypes) do
				if BasicSkill.IsAttackType(skill_type_id) then
					value = self:getFistFootSystem():getBranchDamage(skill_type_id) + value
				end
			end
		end
	end
	
	local standBySkillId = self:getPrepareSkillIdByType("quanjiao2")
	if standBySkillId ~= nil then
		local standBy_skill = Skill:getSkill(standBySkillId)
		if standBy_skill then
			local skillTypes = standBy_skill:getSkillTypes()
			for _,skill_type_id in ipairs(skillTypes) do
				if BasicSkill.IsAttackType(skill_type_id) then
					value = self:getFistFootSystem():getBranchDamage(skill_type_id) + value
				end
			end
		end
	end

	return value 
end

--@desc: 获取拳脚伤害力
--@author:Seven
--@time:2022-09-20 16:36:42
function Role_Attr:getWsdamage()
	-- 拳脚伤害力 = 角色fdamage总值 * fdamage伤害力修正系数
	local currWeaponType = self:getCurrWeaponType()

	if currWeaponType ~= "拳脚" then
		return 0
	end

	local BattleConstConf = require("app.FightSystem.Configuration.BattleConstConf")

	return self:getFDamage() * BattleConstConf:get("wushufdamageCorrectionFactor")
end

--@desc: 经脉化元技能相关存档数据
--@author:Seven
--@time:2023-07-05 14:19:22
--@return: {}
function Role_Attr:getMSkillUseRecord()
    if self.mSkillUseRecord == nil then
        self.mSkillUseRecord = {
            firstUseTime = 0,
            time = 0
        }
    end

    return self.mSkillUseRecord
end

--判断是不是归隐
function Role_Attr:checkRoleisSeclusion()
    return self.isSeclusion == true
end

--设置先天属性
function Role_Attr:setNaturalAttr(name, value)
    if self == User:getRole() and table.keyof(NaturalAttrAdjustmentConst.ATTR_TYPE, name) then
        return self:callModuleFunc("setAttr", name, value)
    end
end

--@desc: 限制角色属性正气值范围
--@author:LvBin
--@time:2024-10-31 12:04:31
--@return
function Role_Attr:limitAttrZhengQiRange()
	if self:getAttr("zhengqi") > 39999999 then
		self:setAttr("zhengqi", 39999999)
	elseif self:getAttr("zhengqi") < -39999999 then
		self:setAttr("zhengqi", -39999999)
	end
end

--@desc: 获取左右互博等级
--@author:LvBin
--@time:2025-01-17 11:43:36
--@return
function Role_Attr:getZuoYouHuBoYinLv()
	local leftRightFightExp = Helper:getDef(self:getAttr("leftRightFightExp"), 0)

	local lv = math.ceil(leftRightFightExp / 100)

	if leftRightFightExp > 99 and leftRightFightExp % 100 == 0 then
		lv = lv + 1
    end

	return math.min(lv,10)
end

--@desc: 获取装饰箱图鉴成就积分
--@author:LvBin
--@time:2025-03-18 16:23:38
--@return
function Role_Attr:getPokedexPoint()
	local point = 0

	local Pokedex = require("script.others.tujian")

	for k,v in pairs(Pokedex["江湖容貌"]) do
		if self:getFlag("江湖容貌图鉴成就" .. v.achievementId) == 1 then
			point = point + v.point
		end
	end

	for k,v in pairs(Pokedex["面具"]) do
		if self:getFlag("面具图鉴成就" .. v.achievementId) == 1 then
			point = point + v.point
		end
	end

	for k,v in pairs(Pokedex["信物"]) do
		if self:getFlag("信物图鉴成就" .. v.achievementId) == 1 then
			point = point + v.point
		end
	end

	return point
end


return Role_Attr